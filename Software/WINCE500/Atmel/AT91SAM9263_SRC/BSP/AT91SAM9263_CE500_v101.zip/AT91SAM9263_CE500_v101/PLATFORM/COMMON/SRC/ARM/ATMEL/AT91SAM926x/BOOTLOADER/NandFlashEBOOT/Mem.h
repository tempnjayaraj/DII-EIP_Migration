//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/NandFlashEBOOT/Mem.h
//!
//! \brief		StaticMalloc & StaticMemcpy (We can't link to malloc during bootloader, so we use static 64kB space)
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/NandFlashEBOOT/NandIds.c $
//!   $Author: ltourlonias $
//!   $Revision: 657 $
//!   $Date: 2007-04-10 16:52:09 +0200 (mar., 10 avr. 2007) $
//! \endif
//!
//! 
//-----------------------------------------------------------------------------
//! \addtogroup	NandFlash
//! @{
//!

#ifndef __NAND_MEM__
#define __NAND_MEM__

#include <windows.h>

#define AT91SAM926XEK_FMD_MAPPING	0x80050000	// Base RAM address for malloc/free emulation

void* StaticMalloc(DWORD dwSizeInBytes);
void* StaticMemcpy(void* dest, const void* src, size_t count);
void StaticFree(void *ptr);

#endif

//! @}
//! @}
