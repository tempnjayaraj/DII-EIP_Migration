//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/TIMER/timer.c
//!
//! \brief		The system timer management
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/TIMER/timer.c $
//!   $Author: pblanchard $
//!   $Revision: 1090 $
//!   $Date: 2007-07-13 07:07:28 -0700 (Fri, 13 Jul 2007) $
//! \endif
//-----------------------------------------------------------------------------

//! \addtogroup	TIMER
//! @{

#include <windows.h>
#include <nkintr.h>
#include <oal.h>

#include "AT91SAM926x_interface.h"
#include "AT91SAM926x.h"
#include "AT91SAM926x_oal_timer.h"

#ifdef OAL_TIMEBOMB
#include "at91sam926x_timebomb.h"
#define DEFAULT_TIMER_TIME_BOMB			DEFAULT_TIME_BOMB
static UINT64 g_resetTime = 0;
#endif //OAL_TIMEBOMB


/*! \var g_InLongIdle 
\brief this variable indicates if the system is currently in a long idle (idle with a sleep period greater than one tick)
*/
static BOOL g_InLongIdle = FALSE;


//-----------------------------------------------------------------------------
//! \fn       BOOL OALTimerInit (UINT32 msecPerSysTick, UINT32 countsPerMSec, UINT32 countsMargin)
//!
//!	\brief    This function gets the current RTC value
//!
//!	\param    msecPerSysTick Defines the system-tick period
//! \param    countsPerMSec Timer input clock frequency.
//! \param    countsMargin Specifies the safe time range, in ticks, in which the timer can be modified without errors
//!
//!	\return   TRUE indicates success
//! \return   FALSE indicates failure
//-----------------------------------------------------------------------------
BOOL OALTimerInit (UINT32 msecPerSysTick, UINT32 countsPerMSec, UINT32 countsMargin)
{
	DWORD dwMCKdiv16PerMSec;

	RETAILMSG(1,(TEXT("+OALTimerInit\r\n")));


	dwMCKdiv16PerMSec = (AT91SAM926x_GetMasterClock(FALSE/* do not use Shadow*/) / 1000) / 16;
	RETAILMSG(1,(TEXT("Test : 0x%x\r\n"),dwMCKdiv16PerMSec));

#ifdef OAL_TIMEBOMB
	g_resetTime = (UINT64) (dwMCKdiv16PerMSec) * DEFAULT_TIMER_TIME_BOMB;
#endif

    //Sanity check
    if (!(msecPerSysTick > 0))
    {
        msecPerSysTick = 1;                       
    }
    	
    // Initialize timer state global variable.
    g_oalTimer.countsPerMSec          = dwMCKdiv16PerMSec;
    g_oalTimer.maxPeriodMSec          = (((1<<20)-1) / g_oalTimer.countsPerMSec ) - 1; //This is the max PIV value
    
    if (msecPerSysTick < g_oalTimer.maxPeriodMSec) //Clip the period to its maximum value if needed
    {        
        g_oalTimer.msecPerSysTick         = msecPerSysTick;                      
    } else {
        g_oalTimer.msecPerSysTick         = g_oalTimer.maxPeriodMSec;                      
    }
    
    g_oalTimer.countsPerSysTick       = (g_oalTimer.countsPerMSec * g_oalTimer.msecPerSysTick);
    
	// Actual parameters are equal to default parameters
	g_oalTimer.actualMSecPerSysTick   = g_oalTimer.msecPerSysTick;
    g_oalTimer.actualCountsPerSysTick = g_oalTimer.countsPerSysTick;
    
    g_oalTimer.countsMargin           = countsMargin;
    g_oalTimer.curCounts              = 0;
    
    // Initialize kernel-exported values.
    idleconv     = 1;
    curridlehigh = 0;
	curridlelow = 0;

    // Initialize high resolution timer function pointers
    pQueryPerformanceFrequency = OALTimerQueryPerformanceFrequency;
    pQueryPerformanceCounter   = OALTimerQueryPerformanceCounter;   
	//pOEMUpdateRescheduleTime   = OALTimerUpdateRescheduleTime;

	RETAILMSG(1,(TEXT("g_oalTimer.msecPerSysTick : 0x%x\r\n"),g_oalTimer.msecPerSysTick));
	RETAILMSG(1,(TEXT("g_oalTimer.countsPerMSec : 0x%x\r\n"),g_oalTimer.countsPerMSec));
	RETAILMSG(1,(TEXT("g_oalTimer.countsMargin : 0x%x\r\n"),g_oalTimer.countsMargin));
	RETAILMSG(1,(TEXT("g_oalTimer.maxPeriodMSec : 0x%x\r\n"),g_oalTimer.maxPeriodMSec));
	RETAILMSG(1,(TEXT("g_oalTimer.countsPerSysTick : 0x%x\r\n"),g_oalTimer.countsPerSysTick));
	RETAILMSG(1,(TEXT("g_oalTimer.actualMSecPerSysTick : 0x%x\r\n"),g_oalTimer.actualMSecPerSysTick));
	RETAILMSG(1,(TEXT("g_oalTimer.actualCountsPerSysTick : 0x%x\r\n"),g_oalTimer.actualCountsPerSysTick));
	RETAILMSG(1,(TEXT("g_oalTimer.curCounts : 0x%x\r\n"),g_oalTimer.curCounts));
	
	//Set up the System timer to trigger an interrupt at (1000/msecPerSysTick) Hz
    AT91SAM926x_InitSystemTimer(g_oalTimer.actualMSecPerSysTick, TRUE/*period in ms*/, TRUE/*use interrupts*/);

	RETAILMSG(1,(TEXT("-OALTimerInit\r\n")));

    return(TRUE);
}



extern AT91PS_PITC g_pPITC;

//-----------------------------------------------------------------------------
//! \fn       INT32 OALTimerCountsSinceSysTick()
//!
//!	\brief    This function returns the time that has expired since the current system tick.
//!
//!
//!
//!	\return   the time that has expired since the current system tick.
//-----------------------------------------------------------------------------
INT32 OALTimerCountsSinceSysTick()
{
	DWORD dwResult;
	DWORD dwPIIR = g_pPITC->PITC_PIIR;
	
	dwResult = ((dwPIIR >> 20) * (g_oalTimer.actualCountsPerSysTick))+ (dwPIIR & AT91C_PITC_CPIVMASK);	

	return dwResult;
}




//-----------------------------------------------------------------------------
//! \fn       static DWORD UpdateTimeAndResetPICNT( BOOL bInTimerUpdate)
//!
//!	\brief    This function updates the PITC controller
//!
//! \param    bInTimerUpdate  indicates if the Timer must be updated
//!
//!	\return   New timer value.
//-----------------------------------------------------------------------------
static DWORD UpdateTimeAndResetPICNT( BOOL bInTimerUpdate)
{
	register DWORD u32NbPeriod;
	DWORD dwPIVR = g_pPITC->PITC_PIVR;

	u32NbPeriod = dwPIVR >> 20;
		
    // Update high resolution counter with the time elapsed since the update
	if (!bInTimerUpdate)
	{
		g_oalTimer.curCounts += (u32NbPeriod * g_oalTimer.actualCountsPerSysTick);
	}
	else
	{
		
		g_oalTimer.curCounts += (u32NbPeriod * g_oalTimer.actualCountsPerSysTick) + (dwPIVR & AT91C_PITC_CPIVMASK);
	}

	CurMSec = (UINT32)((g_oalTimer.curCounts / (UINT64)g_oalTimer.countsPerMSec) & 0xFFFFFFFF);


	return dwPIVR & AT91C_PITC_CPIVMASK;
}

//-----------------------------------------------------------------------------
//! \fn       static DWORD resetPITCAndSetNewPeriod(DWORD dwPeriod)
//!
//!	\brief    This function sets a new periode value for the PITC controller
//!
//! \param    dwPeriod new periode for the timer
//!
//!	\return   New timer value.
//-----------------------------------------------------------------------------
static DWORD resetPITCAndSetNewPeriod(DWORD dwPeriod)
{
	DWORD dwDummy;
	BOOL bIntrEnabled = INTERRUPTS_ENABLE(FALSE);
	DWORD loop = 0;

	dwDummy = g_pPITC->PITC_PIVR;
	do 
	{
		g_pPITC->PITC_PIMR = (g_pPITC->PITC_PIIR & AT91C_PITC_CPIVMASK) + 1;
		loop++;
	} while ( (g_pPITC->PITC_PISR & AT91C_PITC_PITS) == 0);

	dwDummy = g_pPITC->PITC_PIVR;
	g_pPITC->PITC_PIMR = dwPeriod | AT91C_PITC_PITEN | AT91C_PITC_PITIEN;

	INTERRUPTS_ENABLE(bIntrEnabled);

	return loop;
}


//-----------------------------------------------------------------------------
//! \fn       UINT32 OALTimerEnterIdle(UINT32 period, UINT32 margin)
//!
//!	\brief    This function sets a new tick system for the idle mode
//!
//! \param    period new periode for the variable tick system in idle mode
//! \param    margin Specifies the safe time range, in ticks, in which the timer can be modified without errors
//!
//!	\return   Always FALSE
//-----------------------------------------------------------------------------
UINT32 OALTimerEnterIdle(UINT32 period, UINT32 margin)
{
	g_InLongIdle = TRUE;
	UpdateTimeAndResetPICNT(TRUE);
	resetPITCAndSetNewPeriod(period);
	return 0;
}

//-----------------------------------------------------------------------------
//! \fn       UINT32 OALTimerExitFromIdle(UINT32 period, UINT32 margin)
//!
//!	\brief    This function sets a new tick system for the run mode
//!
//! \param    period new periode for the variable tick system in run mode
//! \param    margin Specifies the safe time range, in ticks, in which the timer can be modified without errors
//!
//!	\return   Always FALSE
//-----------------------------------------------------------------------------
UINT32 OALTimerExitFromIdle(UINT32 period, UINT32 margin)
{
	g_InLongIdle = FALSE;
	UpdateTimeAndResetPICNT(TRUE);
	resetPITCAndSetNewPeriod(period);
	return 0;	
}

//-----------------------------------------------------------------------------
//! \fn       UINT32 OALTimerIntrHandlerWithILTSupport(DWORD dwCountSinceSysTick)
//!
//!	\brief    This function implements the timer interrupt handler with ILT support
//!
//! \param    dwCountSinceSysTick system tick if OAL_ILTIMING is available
//!
//!	\return   SysIntr value for the System Timer
//-----------------------------------------------------------------------------
UINT32 OALTimerIntrHandlerWithILTSupport(DWORD dwCountSinceSysTick)
{
    UINT32 sysIntr = SYSINTR_NOP;   
	//Just in case the BSP handles the nested interrupts, make sure that we'rent going to be interrupted while playing with the timer
	BOOL bIntrEnabled = INTERRUPTS_ENABLE(FALSE);
	

	if (g_InLongIdle)
	{
		OALTimerExitFromIdle(g_oalTimer.countsPerSysTick,0);
        // Restore original values
        g_oalTimer.actualMSecPerSysTick = g_oalTimer.msecPerSysTick;
        g_oalTimer.actualCountsPerSysTick = g_oalTimer.countsPerSysTick; 
	}
	else
	{
		UpdateTimeAndResetPICNT(FALSE);			
	}

	INTERRUPTS_ENABLE(bIntrEnabled);



#ifdef OAL_TIMEBOMB
	if (g_oalTimer.curCounts > g_resetTime)
	{
		RETAILMSG(1,(TEXT("TIMEBOMB !\r\n")));
		coldReboot();
	}	
#endif


#ifdef OAL_ILTIMING
    if (g_oalILT.active) {
        if (--g_oalILT.counter == 0) {
            sysIntr = SYSINTR_TIMING;
            g_oalILT.counter = g_oalILT.counterSet;
            g_oalILT.isrTime1 = dwCountSinceSysTick;
			g_oalILT.isrTime2 = OALTimerCountsSinceSysTick();			
        }
    }
#endif	

    if ((int)(CurMSec - dwReschedTime) >= 0) 
	{
		sysIntr = SYSINTR_RESCHED;
	}

    return (sysIntr);
}

//! @} end of subgroup TIMER

//! @} end of group OAL

////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/TIMER/timer.c $
////////////////////////////////////////////////////////////////////////////////
//
