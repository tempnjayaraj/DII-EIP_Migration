//-----------------------------------------------------------------------------
//! \addtogroup	WAVEDEV
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//!
//!	\file		Wavedev_ioctl.h
//!
//! \brief		Custom Wavedev IOCTLs declaration file
//!
//! \if cvs
//!   $RCSfile: AT91SAM9263_TSC2200_ioctl.h,v $
//!   $Author: jjhiblot $
//!   $Revision: 1.3 $
//!   $Date: 2006/01/31 14:18:19 $
//! \endif
//!
//! IOControl used by application for interaction with the audio driver
//-----------------------------------------------------------------------------


#ifndef __AT91SAM9263EK_WAVDEV_IOCTL_H__
#define __AT91SAM9263EK_WAVDEV_IOCTL_H__


#define WPDM_PRIVATE WM_USER+10		
#define WPDM_PRIVATE_WRITE_AC97		WPDM_PRIVATE+0 // do a write to the ac 97 register
#define WPDM_PRIVATE_READ_AC97		WPDM_PRIVATE+1 // do a read to the ac 97 register
#define WPDM_PRIVATE_GET_INPUT_VOLUME  WPDM_PRIVATE+2
#define WPDM_PRIVATE_SET_INPUT_VOLUME  WPDM_PRIVATE+3




#endif // #ifndef __NADIA2EK_WAVDEV_IOCTL_H__

// End of Doxygen group TSC
//! @}
//-----------------------------------------------------------------------------
// End of $RCSfile: AT91SAM9263_TSC2200_ioctl.h,v $
//-----------------------------------------------------------------------------
//
