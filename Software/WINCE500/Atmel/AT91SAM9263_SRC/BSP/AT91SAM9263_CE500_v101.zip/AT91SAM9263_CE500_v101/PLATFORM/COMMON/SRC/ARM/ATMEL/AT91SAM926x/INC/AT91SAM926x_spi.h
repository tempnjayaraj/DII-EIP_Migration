///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x_spi.h 
//!
//! \brief		Header for the board-specific SPI functions.
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/AT91SAM926x_spi.h $
//!   $Author: pblanchard $
//!   $Revision: 976 $
//!   $Date: 2007-06-08 07:04:15 -0700 (Fri, 08 Jun 2007) $
//! \endif
//-----------------------------------------------------------------------------


#ifndef AT91SAM926X_SPI_H
#define AT91SAM926X_SPI_H


//Platform specific (this is implemented in the BSP)
extern BOOL HWSPIControllerBoardSpecificPIOInitialization(DWORD dwDevID, WORD wCS);
extern BOOL HWSPIControllerBoardSpecificPIODeinitialization(DWORD dwDevID);

extern BOOL HWSPICSBoardSpecificPIOInitialization(DWORD dwPinNumber);
extern BOOL HWSPICSBoardSpecificPIODeinitialization();

extern BOOL HWSPIControllerBoardSpecificInit();
extern BOOL HWSPIControllerBoardSpecificGetBus();
extern BOOL HWSPIControllerBoardSpecificReleaseBus();

extern void HWSPIControllerBoardSpecificDeInit();

#endif

//! @}

////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/AT91SAM926x_spi.h $
////////////////////////////////////////////////////////////////////////////////
//
