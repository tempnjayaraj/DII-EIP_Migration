//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//-----------------------------------------------------------------------------
//! \file		timer_at91sam9263.c 
//!
//! \brief		The specific timer bootlaoder function
//!
//! \if subversion
///  $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/BOOTLOADER/EBOOT/timer_at91sam9263.c $
//!   $Author: ltourlonias $
//!   $Revision: 874 $
//!   $Date: 2007-05-24 09:03:04 +0200 (jeu., 24 mai 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	EBOOT
//! @{
//!


//------------------------------------------------------------------------------
//                                                                      Includes
//------------------------------------------------------------------------------
// Standard includes
#include <windows.h>
#include <oal_memory.h>
#include <Nkintr.h>

// Atmel includes
#include "AT91SAM9263EK.h"
#include "at91sam9263.h"
#include "AT91SAM926x_interface.h"

extern EBOOT_WatchdogRefresh(void);
//------------------------------------------------------------------------------
//                                                            Exported functions
//------------------------------------------------------------------------------

//--------------------------------------------------------------------------------
//! \brief Get number of tick since timer initialization
//!
//! \return the number of tick
//--------------------------------------------------------------------------------
UINT32 OALGetTickCount()
{
	EBOOT_WatchdogRefresh();
	return AT91SAM926x_Read_Interrupt_Counter()*EBOOT_TIMER_PERIOD + AT91SAM926x_Get_MSec_SinceLastSysTick();
}
UINT32 SC_GetTickCount()
{
	return AT91SAM926x_Read_Interrupt_Counter()*EBOOT_TIMER_PERIOD + AT91SAM926x_Get_MSec_SinceLastSysTick();
}



//--------------------------------------------------------------------------------
//! \brief Hardware init for the timer
//!
//! \return Operation status
//--------------------------------------------------------------------------------
BOOL EBOOT_InitTimer(void)
{
	// Initialize a timer (1000ms, in ms, not by interrupt)
	AT91SAM926x_InitSystemTimer(EBOOT_TIMER_PERIOD, TRUE, FALSE);

	return TRUE;
}

//--------------------------------------------------------------------------------
//! \brief Get nummber of sec since timer init
//!
//! \return the number of second
//--------------------------------------------------------------------------------
DWORD EBOOT_GetCurrentSec(void)
{
	DWORD dwCurrentSec;
	dwCurrentSec = OALGetTickCount();
	dwCurrentSec /= 1000;

	return dwCurrentSec;
}



//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/BOOTLOADER/EBOOT/timer_at91sam9263.c $
//------------------------------------------------------------------------------

//
//! @}
//
//! @}
