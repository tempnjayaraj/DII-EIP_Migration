//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		SPIDriver_reg.c
//!
//! \brief		This file implements some helpers for accessing the registry
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/SPI/SPIDriver_reg.c $
//!   $Author: pblanchard $
//!   $Revision: 984 $
//!   $Date: 2007-06-11 09:19:22 -0700 (Mon, 11 Jun 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	SPI
//! @{
//!

#include <windows.h>
#include <Devload.h>
#include "AT91SAM926x.h"

#include "AT91SAM926x_spi.h"
#include "AT91SAM926x_spi_ioctl.h"
#include "SPIDriver.h"

#define ZONE_INIT 1

// Active Driver
#define SPI_PORT_KEYPATH_VAL_NAME			TEXT("Key")

// SPI CONTROLER KEY
#define SPI_CONTROLLER_BASE_KEYNAME			TEXT("Drivers\\SPIControler")
//#define SPI_CONTROLER_MODE_VAL_NAME			TEXT("Mode")
//#define SPI_CONTROLER_MODE_VAL_LEN			sizeof( DWORD )
#define SPI_CONTROLER_PERIPH_VAL_NAME		TEXT("PeripheralSelect")
#define SPI_CONTROLER_PERIPH_VAL_LEN		sizeof( DWORD)
#define SPI_CONTROLER_CSDECODE_VAL_NAME		TEXT("ChipSelectDecode")
#define SPI_CONTROLER_CSDECODE_VAL_LEN		sizeof( DWORD)		
#define SPI_CONTROLER_CLK_VAL_NAME			TEXT("ClockSelection")
#define SPI_CONTROLER_CLK_VAL_LEN			sizeof( DWORD)
#define SPI_CONTROLER_MODEFAULT_VAL_NAME	TEXT("ModeFaultDetection")
#define SPI_CONTROLER_MODEFAULT_VAL_LEN		sizeof( DWORD)
#define SPI_CONTROLER_LLB_VAL_NAME			TEXT("LoopBackEnable")
#define SPI_CONTROLER_LLB_VAL_LEN			sizeof( DWORD)
#define SPI_CONTROLER_DELAY_VAL_NAME		TEXT("DelayBetweenChipSelects")
#define SPI_CONTROLER_DELAY_VAL_LEN			sizeof( DWORD)
#define SPI_CONTROLER_TXBUFSIZE_VAL_NAME	TEXT("TxBufferSize")
#define SPI_CONTROLER_TXBUFSIZE_VAL_LEN		sizeof( DWORD)
#define SPI_CONTROLER_RXBUFSIZE_VAL_NAME	TEXT("RxBufferSize")
#define SPI_CONTROLER_RXBUFSIZE_VAL_LEN		sizeof( DWORD)



// SPI PORT KEYS
#define SPI_CTRL_INDEX_VAL_NAME			TEXT("SPIController")
#define SPI_CTRL_INDEX_VAL_LEN			sizeof( DWORD )
#define SPI_CS_INDEX_VAL_NAME			TEXT("SPICS")
#define SPI_CS_INDEX_VAL_LEN			sizeof( DWORD )
#define SPI_CS_CFG_VAL_NAME				TEXT("CSSetup")
#define SPI_CS_CFG_VAL_LEN				sizeof( DWORD )
#define SPI_CS_USE_PIO_VAL_NAME			TEXT("UsePIOCS")



//-----------------------------------------------------------------------------
//! \fn			BOOL SPI_GetControlerRegistryData(T_SPI_CONTROLLER_STRUCTURE *pSPICtrl, DWORD devIndex)
//!
//! \brief		Get the SPI configuration from the registry for the SPI controller
//!   
//! \param		pSPICtrl	a pointer to a structure containing the SPI configuration
//! \param		devIndex	the index of the controller
//!
//! \return		\e TRUE indicates success.
//! \return		\e FALSE indicates failure.
//!
//! Get the SPI configuration from the registry for the SPI controller
//-----------------------------------------------------------------------------

BOOL SPI_GetControlerRegistryData(T_SPI_CONTROLLER_STRUCTURE *pSPICtrl, DWORD devIndex)
{		
    LONG    regError;
    HKEY    hKeyControler;
    DWORD   dwDataSize;
    TCHAR   ctrlKeyPath[_MAX_PATH];
	
    wsprintf(ctrlKeyPath,L"%s%d",SPI_CONTROLLER_BASE_KEYNAME,devIndex);
    
    regError = RegOpenKeyEx(
                           HKEY_LOCAL_MACHINE, 
                           ctrlKeyPath, 
                           0,
                           KEY_ALL_ACCESS, 
                           &hKeyControler);
                           
    if ( regError != ERROR_SUCCESS ) 
    {
        DEBUGMSG(ZONE_INIT,
                 (TEXT("Failed to open %s, Error 0x%X\r\n"), 
                  ctrlKeyPath, regError));
        return ( FALSE );        
    }

		
/* Slave mode is not supported

	// Controler Mode
    if ( regError == ERROR_SUCCESS ) 
    {
        dwDataSize = SPI_CONTROLER_MODE_VAL_LEN;
        regError = RegQueryValueEx(
                                  hKeyControler, 
                                  SPI_CONTROLER_MODE_VAL_NAME, 
                                  NULL, 
                                  NULL,
                                  (LPBYTE)(&pSPICtrl->SPI_Mode), 
                                  &dwDataSize);
    }    
*/	
    
/*
	not supported : fixed chip select only !
	// Peripheral Select
    if ( regError == ERROR_SUCCESS ) 
    {
        dwDataSize = SPI_CONTROLER_PERIPH_VAL_LEN;
        regError = RegQueryValueEx(
                                  hKeyControler, 
                                  SPI_CONTROLER_PERIPH_VAL_NAME, 
                                  NULL, 
                                  NULL,
                                  (LPBYTE)(&pSPICtrl->SPI_PeripheralSelect), 
                                  &dwDataSize);
    }
*/

	// ChipSelect Decode
    if ( regError == ERROR_SUCCESS ) 
    {
        dwDataSize = SPI_CONTROLER_CSDECODE_VAL_LEN;
        regError = RegQueryValueEx(
                                  hKeyControler, 
                                  SPI_CONTROLER_CSDECODE_VAL_NAME, 
                                  NULL, 
                                  NULL,
                                  (LPBYTE)(&pSPICtrl->SPI_ChipSelectDecode), 
                                  &dwDataSize);
    }

	// Mode Fault Detection
    if ( regError == ERROR_SUCCESS ) 
    {
        dwDataSize = SPI_CONTROLER_MODEFAULT_VAL_LEN;
        regError = RegQueryValueEx(
                                  hKeyControler, 
                                  SPI_CONTROLER_MODEFAULT_VAL_NAME, 
                                  NULL, 
                                  NULL,
                                  (LPBYTE)(&pSPICtrl->SPI_ModeFaultDetection), 
                                  &dwDataSize);
    }

	// Loop Back Enable
    if ( regError == ERROR_SUCCESS ) 
    {
        dwDataSize = SPI_CONTROLER_LLB_VAL_LEN;
        regError = RegQueryValueEx(
                                  hKeyControler, 
                                  SPI_CONTROLER_LLB_VAL_NAME, 
                                  NULL, 
                                  NULL,
                                  (LPBYTE)(&pSPICtrl->SPI_LoopBackEnable), 
                                  &dwDataSize);
    }
	
	// Delay Between Chip Selects
    if ( regError == ERROR_SUCCESS ) 
    {
        dwDataSize = SPI_CONTROLER_DELAY_VAL_LEN;
        regError = RegQueryValueEx(
                                  hKeyControler, 
                                  SPI_CONTROLER_DELAY_VAL_NAME, 
                                  NULL, 
                                  NULL,
                                  (LPBYTE)(&pSPICtrl->SPI_DelayBetweenChipSelects), 
                                  &dwDataSize);
    }

	// Tx BufferSize
    if ( regError == ERROR_SUCCESS ) 
    {
        dwDataSize = SPI_CONTROLER_TXBUFSIZE_VAL_LEN;
        regError = RegQueryValueEx(
                                  hKeyControler, 
                                  SPI_CONTROLER_TXBUFSIZE_VAL_NAME, 
                                  NULL, 
                                  NULL,
                                  (LPBYTE)(&pSPICtrl->dwTxBufferSize), 
                                  &dwDataSize);
    }
	
	// Rx BufferSize
    if ( regError == ERROR_SUCCESS ) 
    {
        dwDataSize = SPI_CONTROLER_RXBUFSIZE_VAL_LEN;
        regError = RegQueryValueEx(
                                  hKeyControler, 
                                  SPI_CONTROLER_RXBUFSIZE_VAL_NAME, 
                                  NULL, 
                                  NULL,
                                  (LPBYTE)(&pSPICtrl->dwRxBufferSize), 
                                  &dwDataSize);
    }


    RegCloseKey (hKeyControler);
	

    if ( regError != ERROR_SUCCESS ) 
    {
        DEBUGMSG(ZONE_INIT,(TEXT("Failed to get SPI controler registry values, Error 0x%X\r\n"),regError));
        return ( FALSE );
    }

    return ( TRUE );
}

//-----------------------------------------------------------------------------
//!
//! \fn		BOOL SPI_GetRegistryData(T_SPI_INIT_STRUCTURE* pSPIInit, LPCTSTR regKeyPath)
//!
//! \brief	Get the SPI configuration from the registry (for a given SPI Chip Select)
//!   
//! \param	pSPIInit	a pointer to a structure containing the SPI configuration
//! \param	regKeyPath	the registry path given to SPI_Init.
//!
//! \return		\e TRUE indicates success.
//! \return		\e FALSE indicates failure.
//!
//!		Get the SPI configuration from the registry (for a given SPI Chip Select)
//-----------------------------------------------------------------------------

BOOL SPI_GetRegistryData(T_SPI_INIT_STRUCTURE* pSPIInit, LPCTSTR regKeyPath)
{
    LONG    regError;
    HKEY    hKey;
	DWORD	dwDataSize;

	
    DEBUGMSG(ZONE_INIT, (TEXT("Try to open %s\r\n"), regKeyPath));

    hKey = OpenDeviceKey(regKeyPath);
    if ( hKey == NULL ) 
    {
        DEBUGMSG(ZONE_INIT,(TEXT("Failed to open device key %s\r\n"), regKeyPath));
        return ( FALSE );
    }

	
    // Port Configuration
    // Okay, we're ready to try and load our registry data.
    
    dwDataSize = SPI_CTRL_INDEX_VAL_LEN;
    regError = RegQueryValueEx(
                                  hKey, 
                                  SPI_CTRL_INDEX_VAL_NAME, 
                                  NULL, 
                                  NULL,
                                  (LPBYTE)(&pSPIInit->dwDevIndex), 
                                  &dwDataSize);
    


    if ( regError != ERROR_SUCCESS ) 
    {
    	goto error;
    }
    
    dwDataSize = SPI_CS_INDEX_VAL_LEN;
    regError = RegQueryValueEx(
                                  hKey, 
                                  SPI_CS_INDEX_VAL_NAME, 
                                  NULL, 
                                  NULL,
                                  (LPBYTE)(&pSPIInit->wCS), 
                                  &dwDataSize);
    
	pSPIInit->wCSRIndex = pSPIInit->wCS /3;

    if ( regError != ERROR_SUCCESS ) 
    {
    	goto error;
    }
    
    dwDataSize = SPI_CS_CFG_VAL_LEN;
    regError = RegQueryValueEx(
                                  hKey, 
                                  SPI_CS_CFG_VAL_NAME, 
                                  NULL, 
                                  NULL,
                                  (LPBYTE)(&pSPIInit->dwCSCfg), 
                                  &dwDataSize);
    

	if ( regError != ERROR_SUCCESS ) 
    {
    	goto error;
    }
    
	{
		BOOL bError = FALSE;
		DWORD result;
		TCHAR	csPioName[4]; //name is of the foloowing format : xyy or xy where x is A,B,... and yy is between 0 and 31    
        dwDataSize = sizeof(csPioName);

		pSPIInit->dwCSPioPin = -1;
		pSPIInit->dwCSPIOBankNumber = -1;

        result = RegQueryValueEx(
                                  hKey, 
                                  SPI_CS_USE_PIO_VAL_NAME, 
                                  NULL, 
                                  NULL,
                                  (LPBYTE)(csPioName), 
                                  &dwDataSize);
		if (result == ERROR_SUCCESS)
		{
			char cBank;			
			DWORD dwPinNumber;
			DEBUGMSG(1,(TEXT("Using PIO as a SPI Chip Select line for SPI CS %d on Controller %d\r\n"),pSPIInit->wCS,pSPIInit->dwDevIndex));
			if (swscanf(csPioName,L"%c%d",&cBank,&dwPinNumber) == 2)
			{				
				
				if (cBank>='a' && cBank<='z')
				{
					cBank -= 'a';
				}
				else if (cBank>='A' && cBank<='Z')
				{
					cBank -= 'A';
				}
				else
				{
					bError = TRUE;
				}
				
				if (cBank >= NB_PIO_BANK)
				{
					bError = TRUE;
				}

				if (dwPinNumber > 31)
				{				
					bError = TRUE;
				}

				if (bError == FALSE)
				{
					pSPIInit->dwCSPioPin = dwPinNumber;
					pSPIInit->dwCSPIOBankNumber = cBank;
				}
			}
		}
		else
		{			
			DEBUGMSG(1,(TEXT("Not using PIO as a SPI Chip Select line for SPI CS %d on Controller %d\r\n"),pSPIInit->wCS,pSPIInit->dwDevIndex));
		}

		if (bError)
		{
			goto error;
		}
    }
    
    RegCloseKey (hKey);
    return TRUE;
    
error:

    DEBUGMSG(ZONE_INIT,(TEXT("Failed to get SPI registry values, Error 0x%X\r\n"),regError));
    RegCloseKey (hKey);
    return ( FALSE );    

}

//! @}


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/SPI/SPIDriver_reg.c $
////////////////////////////////////////////////////////////////////////////////
//
//! @}
