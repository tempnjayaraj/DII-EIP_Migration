//-----------------------------------------------------------------------------
//! \addtogroup   SPI
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				AT91RM9200_SPIDriver_hw.c
//!
//! \brief				This file implements the hardware dependent part of the SPI driver (it's platform independent)
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/DRIVERS/SPI/AT91RM9200_SPIDriver_hw.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

#include <windows.h>
#include <ceddk.h>
#include "AT91RM9200.h"
#include "lib_AT91RM9200.h"
#include "AT91RM9200_SPIDriver_IOCTL.h"
#include "AT91RM9200_SPIDriver.h"


//-----------------------------------------------------------------------------
//! \brief		This functions is used to turn on or off the SPI controller
//!
//! \param		dwDevID		
//! \param		bPowerUp	1 Enable, 0 Disable
//! \return		TRUE, or FALSE in case of error
//-----------------------------------------------------------------------------
static BOOL setDevicePower(DWORD dwDevID,BOOL bPowerUp)
{
	PHYSICAL_ADDRESS PhysAddr;
	AT91PS_PMC pPMC;

	PhysAddr.LowPart = (DWORD) AT91C_BASE_PMC;
	PhysAddr.HighPart = 0;
	pPMC = (AT91PS_PMC) MmMapIoSpace(PhysAddr,sizeof(AT91S_PMC),FALSE);
	if (pPMC == NULL)
	{
		return FALSE;
	}

	if (bPowerUp)
	{
		pPMC->PMC_PCER = 1 << dwDevID;
	}
	else
	{
		pPMC->PMC_PCDR = 1 << dwDevID;
	}

	MmUnmapIoSpace(pPMC,sizeof(AT91S_PMC));

	return TRUE;
}

//-----------------------------------------------------------------------------
//! \brief		Initial configuration of the SPI controler
//!
//! \param		pSPICtrl	SPI Device		
//! \return		TRUE, or FALSE in case of error
//-----------------------------------------------------------------------------
BOOL HWSPIControllerInit(T_SPI_CONTROLLER_STRUCTURE* pSPICtrl)
{
	// Power up the SPI controller
	if (setDevicePower(pSPICtrl->dwIDIRQ,TRUE) == FALSE)
	{
		return FALSE;
	}

	// Reset the SPI
	pSPICtrl->pSPI->SPI_CR = AT91C_SPI_SWRST;

	//disable PDC and initialize PDC SPI registers
	
	pSPICtrl->pSPI->SPI_PTCR = AT91C_PDC_RXTDIS | AT91C_PDC_TXTDIS;	//disable SPI PDC
	pSPICtrl->pSPI->SPI_RCR=0;
	pSPICtrl->pSPI->SPI_RPR=0;
	pSPICtrl->pSPI->SPI_TCR=0;
	pSPICtrl->pSPI->SPI_TPR=0;
	pSPICtrl->pSPI->SPI_RNCR=0;
	pSPICtrl->pSPI->SPI_RNPR=0;
	pSPICtrl->pSPI->SPI_TNCR=0;
	pSPICtrl->pSPI->SPI_TNPR=0;


	// Configure SPI according to the registry settings
	AT91F_SPI_CfgMode(pSPICtrl->pSPI, 
		AT91C_SPI_MSTR					|		// MasterMode only
		AT91C_SPI_PS_FIXED 				|		// Fixed Peripheral Selection only
		((pSPICtrl->SPI_ChipSelectDecode)?AT91C_SPI_PCSDEC:0) |		// Chip Select Decode
		((pSPICtrl->SPI_ModeFaultDetection)?AT91C_SPI_MODFDIS:0) |	// Mode Fault Detection
		((pSPICtrl->SPI_LoopBackEnable)?AT91C_SPI_LLB:0)	|		// Local LoopBack
		(pSPICtrl->SPI_DelayBetweenChipSelects << 24) );			//Delay Between Chip Selects 

	
	// Enable the SPI
	pSPICtrl->pSPI->SPI_CR = AT91C_SPI_SPIEN;

	return TRUE;
}


//-----------------------------------------------------------------------------
//! \brief		This function deactivates the SPI controller
//!
//! \param		pSPICtrl	SPI Device		
//! \return		TRUE, or FALSE in case of error
//-----------------------------------------------------------------------------
BOOL HWSPIControllerDeinit(T_SPI_CONTROLLER_STRUCTURE* pSPICtrl)
{
	// Disable the SPI
	pSPICtrl->pSPI->SPI_CR = AT91C_SPI_SPIDIS;

	// Power down the SPI controller
	return setDevicePower(pSPICtrl->dwIDIRQ,FALSE);
}

//-----------------------------------------------------------------------------
//! \brief		This functions sets the configuration of the selected Chip Select
//!
//! \param		pSPIInit	SPI Device		
//! \return		TRUE, or FALSE in case of error
//-----------------------------------------------------------------------------
BOOL HWSPICSConfigure(T_SPI_INIT_STRUCTURE* pSPIInit)
{
	pSPIInit->pSPIControllerInfo->pSPI->SPI_CSR[pSPIInit->wCS] = pSPIInit->dwCSCfg;
	return TRUE;
}

//-----------------------------------------------------------------------------
//! \brief		This function is used to select the default Chip Select (Fixed Chip Select Mode)
//! \param		pSPI								SPI Device		
//! \param		dwCSNumber					The Chip select ID
//! \param		dwChipSelectDecode	A flag telling if chip select lines are used to drive a decoder
//-----------------------------------------------------------------------------
static selectChipSelect(AT91PS_SPI pSPI, DWORD dwCSNumber, DWORD dwChipSelectDecode)
{
	DWORD dwChipSelect;

	if (dwChipSelectDecode)
	{
		dwChipSelect = (  (~dwCSNumber) << 16) & AT91C_SPI_PCS;
	}
	else
	{
		dwChipSelect = ((~( 1 << dwCSNumber)) << 16) & AT91C_SPI_PCS;
	}	
	pSPI->SPI_MR = pSPI->SPI_MR & ~AT91C_SPI_PCS | dwChipSelect;
	return TRUE;
}
#define MIN(x,y) ((x)<(y)? (x):(y))

unsigned long HWSPIGetStatus(AT91PS_SPI pSPI)
{
	return (unsigned int)(pSPI->SPI_SR);
}

int HWSPITxBusy (AT91PS_SPI pSPI)
{
	return (!(HWSPIGetStatus(pSPI) & AT91C_SPI_TDRE));
}

int HWSPIRxBusy (AT91PS_SPI pSPI)
{
	return ((HWSPIGetStatus(pSPI) & AT91C_SPI_RDRF));
}

void HWSPIWriteWord(AT91PS_SPI pSPI, unsigned __int16 *iWord)
{
    pSPI->SPI_TDR = (*iWord & 0xFFFF);
}

unsigned __int16 HWSPIReadWord(AT91PS_SPI pSPI)
{
	return (unsigned __int16)((pSPI->SPI_RDR) & 0xFFFF);
}


//-----------------------------------------------------------------------------
//! \param		pOpenContext		SPI Device	
//! \param		pTransactionArray	Transaction	descriptor
//! \param		dwNbTransaction		Number of transactions	
//! \return		TRUE, or FALSE in case of error
//-----------------------------------------------------------------------------
BOOL DoSPITransaction(T_SPI_OPEN_STRUCTURE* pOpenContext,T_SPI_TRANSACTION_ELEMENT_PARAM* pTransactionArray,DWORD dwNbTransaction)
{
	
	AT91PS_SPI  pSPI = pOpenContext->pSPIInfo->pSPIControllerInfo->pSPI;
	T_SPI_CONTROLLER_STRUCTURE* pSPIControllerInfo = pOpenContext->pSPIInfo->pSPIControllerInfo;
	DWORD nextBufferIndex;
	DWORD dwTransacCounter;
	UCHAR* previousRxBuffer;
	DWORD previousRxBufferSize;
	DWORD dwDummy;
	DWORD dwSizeOfData;
	volatile DWORD debug = 1;

	// The Transaction is protected by a critical section
	// we must get the SPI controller for ourselves.
	EnterCriticalSection(&pSPIControllerInfo->csSPIAccess);

	if ((pSPI->SPI_MR & AT91C_SPI_BITS) == AT91C_SPI_BITS_8)
	{
		dwSizeOfData = 1; // 1 byte per sample
	}
	else
	{
		dwSizeOfData = 2; // 2 bytes per sample
	}
	// The transaction descriptor tells which Chip Select must be used, so we select this one	
	selectChipSelect(pSPI, pOpenContext->pSPIInfo->wCS, pSPIControllerInfo->SPI_ChipSelectDecode);


	// The data transfer is done by the PDC. Disable the PDCs before programming them
	pSPI->SPI_PTCR = AT91C_PDC_RXTDIS | AT91C_PDC_TXTDIS;
	
	// reset the pdcs
	pSPI->SPI_RPR = 0;
	pSPI->SPI_RCR = 0;
	pSPI->SPI_TPR = 0;
	pSPI->SPI_TCR = 0;	
	pSPI->SPI_RNCR =0;
	pSPI->SPI_RNPR =0;
	pSPI->SPI_TNCR =0;
	pSPI->SPI_TNPR =0;

	previousRxBuffer = NULL;
	previousRxBufferSize = 0;
	nextBufferIndex = 0;

	
	for (dwTransacCounter = 0;dwTransacCounter < dwNbTransaction; dwTransacCounter++)
	{
		//Check if it's a valid transfer ....
		if ( (pTransactionArray[dwTransacCounter].dwSize == 0) || 
			((pTransactionArray[dwTransacCounter].pRxBuffer == NULL) && (pTransactionArray[dwTransacCounter].pTxBuffer == NULL)))
		{
			continue;
		}

		//if required Copy the transmited data from in the tranmit buffer
		if (pTransactionArray[dwTransacCounter].pTxBuffer)
		{
			memcpy(pSPIControllerInfo->pVirtTxBuffer[nextBufferIndex], pTransactionArray[dwTransacCounter].pTxBuffer, MIN(pSPIControllerInfo->dwTxBufferSize,pTransactionArray[dwTransacCounter].dwSize * dwSizeOfData));
		}		
		
		
		// Setup the PDC
		if (pTransactionArray[dwTransacCounter].pRxBuffer)
		{
			pSPI->SPI_RNPR = pSPIControllerInfo->dwRxBufferPhysicalAddress[nextBufferIndex];
		}
		else
		{
			pSPI->SPI_RNPR = 0;
		}
		if (pTransactionArray[dwTransacCounter].pRxBuffer)
		{
			pSPI->SPI_RNCR = MIN(pSPIControllerInfo->dwRxBufferSize,pTransactionArray[dwTransacCounter].dwSize);
		}
		else
		{
			pSPI->SPI_RNCR = 0;
		}
		if (pTransactionArray[dwTransacCounter].pTxBuffer)
		{
			pSPI->SPI_TNPR = pSPIControllerInfo->dwTxBufferPhysicalAddress[nextBufferIndex];
		}
		else
		{
			pSPI->SPI_TNPR = pSPIControllerInfo->dwRxBufferPhysicalAddress[nextBufferIndex];
		}
		
		//Clear the CS line if needed (see "CSUsePIO" in registry)
		if (pOpenContext->pSPIInfo->pCSPio)
		{
			pOpenContext->pSPIInfo->pCSPio->PIO_CODR = pOpenContext->pSPIInfo->dwCSPioPin;
		}
		// Writing the Transmit Counter actually starts the transfer
		if (pTransactionArray[dwTransacCounter].pTxBuffer)
		{
			pSPI->SPI_TNCR = MIN(pSPIControllerInfo->dwTxBufferSize,pTransactionArray[dwTransacCounter].dwSize);
		}
		else
		{
			pSPI->SPI_TNCR = MIN(pSPIControllerInfo->dwRxBufferSize,pTransactionArray[dwTransacCounter].dwSize);
		}
				


		// Setup the interrupt for trigerring whenever the ReceiveNext and TransmitNext are free
		pSPI->SPI_IDR = 0xFFFFFFFF;
		pSPI->SPI_IER = AT91C_SPI_SPENDRX | AT91C_SPI_SPENDTX;

		dwDummy = pSPI->SPI_RDR;
		//enable the PDC
		pSPI->SPI_PTCR = AT91C_PDC_RXTEN | AT91C_PDC_TXTEN;


		if (dwTransacCounter) //First time doesn't count... 
		{
			while ((pSPI->SPI_SR & (AT91C_SPI_SPENDTX | AT91C_SPI_SPENDRX)) != (AT91C_SPI_SPENDTX | AT91C_SPI_SPENDRX))
			{		
				WaitForSingleObject(pSPIControllerInfo->hInterruptEvent,INFINITE);
				InterruptDone(pSPIControllerInfo->dwSysintr);
			}
		}

		//if required Copy the received data in the buffer (the one previously used because here we're initalizing the buffer for the NEXT transfer)
		if (previousRxBuffer && previousRxBufferSize)
		{
			memcpy(previousRxBuffer,pSPIControllerInfo->pVirtRxBuffer[1-nextBufferIndex],previousRxBufferSize * dwSizeOfData);
		}

		//Toogle the next buffer index (0 -> 1 -> 0 -> ...)
		nextBufferIndex = 1 - nextBufferIndex; 
		
		previousRxBuffer = pTransactionArray[dwTransacCounter].pRxBuffer;
		previousRxBufferSize = pTransactionArray[dwTransacCounter].dwSize;
	}
	

	
	// Setup the interrupt for trigerring when receive and transmit are empty.
	pSPI->SPI_IDR = 0xFFFFFFFF;
	pSPI->SPI_IER = AT91C_SPI_RXBUFF | AT91C_SPI_TXBUFE;

	while ((pSPI->SPI_SR & (AT91C_SPI_RXBUFF | AT91C_SPI_TXBUFE)) != (AT91C_SPI_RXBUFF | AT91C_SPI_TXBUFE))
	{
		WaitForSingleObject(pSPIControllerInfo->hInterruptEvent,INFINITE);
		InterruptDone(pSPIControllerInfo->dwSysintr);
	}

	// Stop the PDCs
	pSPI->SPI_PTCR = AT91C_PDC_RXTDIS | AT91C_PDC_TXTDIS;
	
			
	if (pTransactionArray[dwTransacCounter-1].pRxBuffer == NULL)
	{
		DWORD dwStatus;
		DWORD dwTimeout;
		volatile DWORD dwDelay;
		
#define TX_TIMEOUT	1000
#ifdef DEBUG
#define CS_DELAY_MULTIPLIER	5
#else		
#define CS_DELAY_MULTIPLIER	8
#endif

		// Wait that the transmit register is emptied before raising the CS line
		dwTimeout = TX_TIMEOUT;
		do
		{
			dwStatus = pSPI->SPI_SR;
		}while ((dwTimeout--) &&((dwStatus & AT91C_SPI_TDRE) == 0));

		dwDelay = CS_DELAY_MULTIPLIER * ((pSPI->SPI_CSR[pOpenContext->pSPIInfo->wCS] >> 8) & 0xFF) ;
		while (dwDelay--);

	}	

	//Set the CS line if needed (see "CSUsePIO" in registry)
	if (pOpenContext->pSPIInfo->pCSPio)
	{
		pOpenContext->pSPIInfo->pCSPio->PIO_SODR = pOpenContext->pSPIInfo->dwCSPioPin;
	}


	//if required Copy the last received data in the buffer
	if (previousRxBuffer && previousRxBufferSize)
	{	
		memcpy(previousRxBuffer,pSPIControllerInfo->pVirtRxBuffer[1-nextBufferIndex],previousRxBufferSize * dwSizeOfData);
	}

	//We can now release the access to the SPI controller

	LeaveCriticalSection(&pSPIControllerInfo->csSPIAccess);
	return TRUE;
}

//! @}
