//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//!
//! All rights reserved ADENEO SAS 2005
//-----------------------------------------------------------------------------
//!
//! \file		atapiebiDriver.h
//!
//! \brief		Definitions for IDE ATAPI hard disk driver on EBI bus\n
//!             Based on atapipcmcia.h file
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/AtapiEbi/atapiebiDriver.h $
//!   $Author: pblanchard $
//!   $Revision: 984 $
//!   $Date: 2007-06-11 09:19:22 -0700 (Mon, 11 Jun 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	ATAPIEBI
//! @{
//!

#ifndef __ATAPIEBI_H
#define __ATAPIEBI_H

#include <windows.h>
#include <ceddk.h>
#include <giisr.h>
#include <atamain.h>

#define DISK_IO_TIME_OUT 1000   //!< wait during 1 s the HD interrupt

#ifdef DEBUG
LPTSTR WaitTypes[6] = {
    TEXT("WAIT_TYPE_BUSY"),
    TEXT("WAIT_TYPE_NOT_BUSY"),
    TEXT("WAIT_TYPE_READY"),
    TEXT("WAIT_TYPE_DRQ"),
    TEXT("WAIT_TYPE_DRQ_NOERR"),
    TEXT("WAIT_TYPE_RDY_NOERR")
};
#endif

// Disk/wait conditions
#define WAIT_TYPE_BUSY       1
#define WAIT_TYPE_NOT_BUSY   2
#define WAIT_TYPE_READY      3
#define WAIT_TYPE_DRQ        4 //!< wait for data request
#define WAIT_TYPE_DRQ_NOERR  5 //!< wait for DRQ but ignore the error status bit
#define WAIT_TYPE_RDY_NOERR  6 //!< wait for ready, but ignore error status bit

// Wait length
#define WAIT_TIME_NORMAL     4000
#define WAIT_TIME_LONG       5000

// IST flags (<CPort>->m_dwFlags)
#define ISTFLG_EXIT          1

// Config port undo flags
#define CP_CLNUP_IRQEVENT    1
#define CP_CLNUP_HEVENT      2
#define CP_CLNUP_INTCHNHDNLR 4
#define CP_CLNUP_IST         8

// Maximum read/write sector count
#define MAX_SECT_CNT         128

// Helpful macros
#define PRX_DEVICE_ID_VAL      (_T("DeviceId"))
#define PRX_REG_ALT_STATUS_VAL (_T("AlternateStatusRegisterOffset"))
#define PRX_REG_DRV_CTRL_VAL   (_T("DeviceControlRegisterOffset"))
#define GetDeviceKeyValue      AtaGetRegistryValue

static TCHAR *g_szPCCardATADiskName = (_T("PC Card ATA Disk"));

#define DOUBLEBUFF_SIZE 65536

// Hardware Specific intialisation
extern	BOOL  AT91_IDEConfigure();
extern	VOID  AT91_IDEDeInit();

// herited from CDisk
class CATAPIEBIDisk : public CDisk {
  public:

    BYTE	bDoubleBuf[DOUBLEBUFF_SIZE]; //!< double buffer

    HANDLE	m_hIsr; //!< handle to ISR
    HANDLE	m_hIst; //!< handle to IST

	BOOL	m_fInterruptSupported;    //!< Set based on registry

    // Replace ATA_REG_ALT_STATUS+ATA_REG_DRV_CTRL definitions; the alternate
    // register block of PCMCIA/ATA devices starts at offset 0 bytes
    // from the alternate register block I/O window; the alternate register block
    // of proper PCI ATA devices starts at offset 2 bytes from the alternate
    // register block I/O window

    BYTE	m_bRegAltStatus; //!< ATA_REG_ALT_STATUS
    BYTE	m_bRegDrvCtrl;   //!< ATA_REG_DRV_CTRL

    // Constructors, Destructors

    CATAPIEBIDisk(HKEY hKey);
    ~CATAPIEBIDisk();

    // Base Functions

    virtual VOID ConfigureRegisterBlock(DWORD dwStride);
    virtual BOOL Init(HKEY hActiveKey);
    virtual BOOL ConfigPort();
    virtual BOOL InitController(BOOL fForce = FALSE);
    virtual DWORD GetDeviceInfo(PIOREQ pIOReq);
    virtual DWORD MainIoctl(PIOREQ pIoReq);

    // The following functions are defined as pure virtual in CDisk; a default
    // implementation is provided (that fails)

    virtual VOID EnableInterrupt();
    virtual BOOL WaitForInterrupt(DWORD dwTimeOut);
    virtual BOOL SetupDMA(PSG_BUF pSGBuf, DWORD dwSGCount, BOOL fRead);
    virtual BOOL BeginDMA(BOOL fRead);
    virtual BOOL EndDMA();
    virtual BOOL AbortDMA();
    virtual BOOL CompleteDMA(PSG_BUF pSGBuf, DWORD dwSGCount, BOOL fRead);

private:

    // New Functions

    DWORD ATAWaitForDisk(DWORD dwTimeOut, UCHAR ucDeviceCondition);
    BOOL  ATAIssueIdentify(PIDENTIFY_DATA pId);
    DWORD ATASetSector(DWORD dwStartingSector, DWORD dwSectorsToTransfer, DWORD dwCommand);
    DWORD ATARead(PSG_REQ pSG);
    DWORD ATAWrite(PSG_REQ pSG);
};

#endif // __ATAPIEBI_H

//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/AtapiEbi/atapiebiDriver.h $
//-----------------------------------------------------------------------------
//! @}
