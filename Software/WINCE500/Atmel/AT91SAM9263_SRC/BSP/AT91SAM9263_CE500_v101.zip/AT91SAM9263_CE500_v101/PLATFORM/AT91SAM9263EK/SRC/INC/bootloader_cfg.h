//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//-----------------------------------------------------------------------------
//! \file		bootloader_cfg.h 
//!
//!
//! \if subversion
///   @URL: $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/INC/bootloader_cfg.h $
//!   @author $Author: jjhiblot $
//!   @version $Revision: 854 $
//!   @date $Date: 2007-05-21 14:45:08 +0200 (lun., 21 mai 2007) $
//! \endif
//-----------------------------------------------------------------------------

#ifndef _BOOTLOADER_CFG_H_
#define _BOOTLOADER_CFG_H_

//------------------------------------------------------------------------------
// Defines and Types
//------------------------------------------------------------------------------
// This address where is wrote the bootloader type (communication between 
// Firstboot and eboot)
#define BOOTLOADER_FLASH_CONFIG_ADDR			 (AT91C_IRAM + 0x0)

// Flash type depending of logical base address
#define LOGIC_ADDR_MASK								    0xF0000000
#define DATAFLASH_CS0_LOGIC_BASE_ADDR					0xC0000000
#define DATAFLASH_CS1_LOGIC_BASE_ADDR					0xD0000000
#define NANDFLASH_CS3_LOGIC_BASE_ADDR					0xE0000000


#define DATAFLASH_BOOTLOADER_SETTINGS_LOGICAL_OFFSET	0x00025000
#define DATAFLASH_BOOTLOADER_CODE_LOGICAL_OFFSET		0x00005000

// Location of the windows CE image in the nandflash
#define WINDOWS_CE_IMAGE_FLASH_ADDR_OFFSET				0x00000000
#define WINDOWS_CE_IMAGE_FLASH_LOGIC_ADDR				NANDFLASH_CS3_LOGIC_BASE_ADDR | WINDOWS_CE_IMAGE_FLASH_ADDR_OFFSET


//------------------------------------------------------------------------------
// EBoot Param	!!
//------------------------------------------------------------------------------
#define EBOOT_VERSION_MAJOR             2
#define EBOOT_VERSION_MINOR             0

#define EBOOT_MAX_SIZE					 0x00016800	//90ko
#define EBOOT_SDRAM_ADDR				 AT91C_EBI0_SDRAM


//------------------------------------------------------------------------------
// FirstBoot Param !! these values are also defined in cfg.inc. Modify both files if needed !!
//------------------------------------------------------------------------------
#define FIRSTBOOT_MAX_SIZE				0x00001000	// 4 ko
#define FIRSTBOOT_SRAM_ADDR				AT91C_IRAM	

#endif //_BOOTLOADER_CFG_H_

//! @}
