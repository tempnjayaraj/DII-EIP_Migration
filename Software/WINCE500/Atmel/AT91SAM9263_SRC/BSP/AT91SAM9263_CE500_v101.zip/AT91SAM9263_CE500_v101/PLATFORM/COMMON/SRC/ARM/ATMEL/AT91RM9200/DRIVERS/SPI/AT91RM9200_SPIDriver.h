//-----------------------------------------------------------------------------
//! \addtogroup   SPI
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				AT91RM9200_SPIDriver.h
//!
//! \brief				This file is the header file for the SPI driver
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/DRIVERS/SPI/AT91RM9200_SPIDriver.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------


#ifndef __SPIDRIVER_H__
#define __SPIDRIVER_H__

//////////////////////////////////////////////////////////////////////////////
// Driver Structure
///////////////////////////////////////////////////////////////////////////////
typedef struct {
	AT91PS_SPI		pSPI;			
	HANDLE			hInterruptEvent;
	DWORD			dwIDIRQ;
	DWORD			dwSysintr;
	WORD			wInitCount;
	CRITICAL_SECTION	csSPIAccess;
	
	DWORD			dwTxBufferSize;
	UCHAR*			pVirtTxBuffer[2];
	ULONG			dwTxBufferPhysicalAddress[2];
	DWORD			dwRxBufferSize;
	UCHAR*			pVirtRxBuffer[2];
	ULONG			dwRxBufferPhysicalAddress[2];
	
	DWORD SPI_Mode;
	DWORD SPI_PeripheralSelect;
	DWORD SPI_ChipSelectDecode;
	DWORD SPI_ModeFaultDetection;
	DWORD SPI_LoopBackEnable;
	DWORD SPI_DelayBetweenChipSelects;

} T_SPI_CONTROLLER_STRUCTURE;


typedef struct{
	WORD			wOpenCount;
	WORD			wCS;
	DWORD			dwCSCfg;
	T_SPI_CONTROLLER_STRUCTURE *pSPIControllerInfo;
	DWORD 			dwDevIndex;
	AT91PS_PIO		pCSPio;
	DWORD			dwCSPioPin;
	DWORD			dwCSPIOBankNumber;
}T_SPI_INIT_STRUCTURE;


typedef struct {
	T_SPI_INIT_STRUCTURE *pSPIInfo;
} T_SPI_OPEN_STRUCTURE;


//////////////////////////////////////////////////////////////////////////////
// Define SPI Chip Select
///////////////////////////////////////////////////////////////////////////////
#define SPI_CS0		0
#define SPI_CS1		1
#define SPI_CS2		2
#define SPI_CS3		3

#define READ_BIT			0x8000
#define COMMAND_WORD_SIZE	sizeof(WORD)


// Registry access
extern BOOL SPI_GetRegistryData(T_SPI_INIT_STRUCTURE* pSPIInit, LPCTSTR regKeyPath);
extern BOOL SPI_GetControlerRegistryData(T_SPI_CONTROLLER_STRUCTURE* pSPICtrl, DWORD devIndex);

// Hardware
BOOL HWSPIControllerInit(T_SPI_CONTROLLER_STRUCTURE*);
BOOL HWSPIControllerDeinit(T_SPI_CONTROLLER_STRUCTURE*);
BOOL HWSPICSConfigure(T_SPI_INIT_STRUCTURE*);
BOOL DoSPITransaction(T_SPI_OPEN_STRUCTURE* pOpenContext,T_SPI_TRANSACTION_ELEMENT_PARAM* pTransactionArray,DWORD dwNbTransaction);
BOOL DoSPITransactionADS7843(T_SPI_OPEN_STRUCTURE* pOpenContext,UCHAR ucCmd, WORD* pBufOut, DWORD dwLenOut);

#endif // #ifndef __SPIDRIVER_H__

//! @}

