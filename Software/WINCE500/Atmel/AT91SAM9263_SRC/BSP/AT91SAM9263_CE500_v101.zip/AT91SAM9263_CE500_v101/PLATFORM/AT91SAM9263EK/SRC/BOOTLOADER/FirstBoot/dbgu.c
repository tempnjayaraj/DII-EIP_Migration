//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//-----------------------------------------------------------------------------
//!
//  All rights reserved ADENEO SAS 2005
//!
//! \file		dbgu.c
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/BOOTLOADER/FirstBoot/dbgu.c $
//!   $Author: jjhiblot $
//!   $Revision: 850 $
//!   $Date: 2007-05-21 14:31:43 +0200 (lun., 21 mai 2007) $
//! \endif
//!
//! Debug module to print string to the DBGU channel
//-----------------------------------------------------------------------------
//! \addtogroup	FIRSTBOOT
//! @{

// Local include
#include "dbgu.h"
#include "AT91SAM926x.h"

//-----------------------------------------------------------------------------
//! \fn			char oemfputc(char ch) 
//!
//! \brief		Put char to the dbgu
//!
//! \param		ch	char to send
//!
//! \return		The char sent
//-----------------------------------------------------------------------------
char oemfputc(char ch) 
{
	AT91PS_USART pUSART = (AT91PS_USART)AT91C_BASE_DBGU;
	while (!(pUSART->US_CSR & AT91C_US_TXRDY));
		 pUSART->US_THR = (char)ch;
    return ch; 
}

//-----------------------------------------------------------------------------
//! \fn			int DbgPrint(char *str)
//!
//! \brief		Print a string through the DBGU channel
//!
//! \param		str	string
//!
//! \return		not used
//-----------------------------------------------------------------------------
int DbgPrint(char *str)
{
	while(*str != '\0')
	{
		oemfputc(*str++);
	}
	return 0;
}

//! @}

//! @}
