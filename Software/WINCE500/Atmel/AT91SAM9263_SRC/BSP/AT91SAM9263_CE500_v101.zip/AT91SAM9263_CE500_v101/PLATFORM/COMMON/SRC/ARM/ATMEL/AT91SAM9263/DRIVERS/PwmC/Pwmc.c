//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		Pwmc.c
//!
//! \brief		Common part of the stream driver allowing the management of PWM
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/DRIVERS/PwmC/Pwmc.c $
//!   $Author: pblanchard $
//!   $Revision: 1021 $
//!   $Date: 2007-06-20 08:50:46 -0700 (Wed, 20 Jun 2007) $
//! \endif
//!
//! This driver manages 4 PWM channels on PWM Controller
//-----------------------------------------------------------------------------
//! \addtogroup	PWMC
//! @{

// System include
#include <windows.h>
#include <memory.h>
#include <nkintr.h>
#include <CEDDK.h>
#include <Devload.h>

// Local include
#include "AT91SAM926x.h"
#include "lib_AT91SAM926x.h"
#include "AT91SAM926x_oal_intr.h"
#include "Pwmc_DbgZones.h"
#include "AT91SAM926x_oal_ioctl.h"
#include "AT91SAM9263_pwmc_ioctl.h"
#include "Pwmc.h"

// The dpCurSettings structure for debug zones
#ifdef DEBUG
DBGPARAM dpCurSettings =
{
    TEXT("PWC"),
    {
        TEXT("Init"),
        TEXT("DeInit"),
        TEXT("Open"),
        TEXT("Close"),
        TEXT("Read"),
        TEXT("Write"),
        TEXT("Seek"),
        TEXT("IOCtl"),
        TEXT("na"),
        TEXT("na"),
        TEXT("na"),
        TEXT("na"),
        TEXT("na"),
        TEXT("Info"),
        TEXT("Warning"),
        TEXT("Error")
    }
    , MASK_INIT | MASK_DEINIT | MASK_INFO | MASK_ERROR
};
#endif

//-----------------------------------------------------------------------------
//! \fn			BOOL WINAPI PWC_DllEntry(HANDLE hinstDLL, DWORD dwReason, LPVOID lpvReserved)
//!
//! \brief		This function is the entry point of the Dll driver
//!
//! \param		hinstDLL	DLL instance
//! \param		dwReason	Reason of the call
//! \param		lpvReserved	Not used
//!
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//!
//! This function intialize debug zone when called with the DLL_PROCESS_ATTACH reason
//-----------------------------------------------------------------------------
BOOL WINAPI PWC_DllEntry(HANDLE hinstDLL, DWORD dwReason, LPVOID lpvReserved)
{
    switch(dwReason)
    {
    case DLL_PROCESS_ATTACH:
        DEBUGREGISTER((HMODULE)hinstDLL);
        DEBUGMSG(ZONE_INFO,(TEXT("Pwm Driver: DLL_PROCESS_ATTACH\n")));
   	break;

    case DLL_THREAD_ATTACH:
        DEBUGMSG(ZONE_INFO,(TEXT("Pwm Driver: DLL_THREAD_ATTACH\n")));
	break;

    case DLL_THREAD_DETACH:
        DEBUGMSG(ZONE_INFO,(TEXT("Pwm Driver: DLL_THREAD_DETACH\n")));
	break;
    case DLL_PROCESS_DETACH:
        DEBUGMSG(ZONE_INFO,(TEXT("Pwm Driver: DLL_PROCESS_DETACH\n")));
	break;
#ifdef UNDER_CE
    case DLL_PROCESS_EXITING:
        DEBUGMSG(ZONE_INFO,(TEXT("Pwm Driver: DLL_PROCESS_EXITING\n")));
	break;
    case DLL_SYSTEM_STARTED:
        DEBUGMSG(ZONE_INFO,(TEXT("Pwm Driver: DLL_SYSTEM_STARTED\n")));
	break;
#endif
    }

    return TRUE;
}



//-----------------------------------------------------------------------------
//! \fn			static BOOL ConfigurePWM(T_IOCTLPWC_CONFIG * pPwmConfig, T_PWMC_INIT_STRUCTURE * pDeviceContext)
//!
//! \brief		This function configure the timer-counter controler for a frequency and duty cycles given by the user
//!
//! \param		pPwmConfig		Pointer to a PWM configuration which contains the frequency and the duty cycles
//! \param		pDeviceContext	Pointer to the Device Context
//!
//! \return		\e TRUE indicates success.
//! \return		\e FALSE indicates failure.
//!
//-----------------------------------------------------------------------------
static BOOL ConfigurePWM(T_IOCTLPWC_CONFIG * pPwmConfig, T_PWMC_INIT_STRUCTURE * pDeviceContext)
{	
	DWORD dwMasterClock = 0;
	BOOL bDividerFound,bEnabled;
	DWORD dwLog2Divider,dwDivider,dwCPRD;

	
	DEBUGMSG(ZONE_INFO, (TEXT("->ConfigurePWM\r\n")));

	if (KernelIoControl(IOCTL_HAL_MASTERCLOCK, NULL, 0, &dwMasterClock, sizeof(dwMasterClock), 0) == FALSE)
	{
		DEBUGMSG(ZONE_INFO|ZONE_ERROR, (TEXT("<-ConfigurePWM : KernelIoControl IOCTL_HAL_MASTERCLOCK FAILED\r\n")));
		return FALSE;
	}

	if (pPwmConfig->dwDutyCycle > 100)
	{
		DEBUGMSG(ZONE_ERROR, (TEXT("<-ConfigurePWM : Invalid Duty Cycle (must be between 0 and 100)\r\n")));
		return FALSE;
	}

	bDividerFound = FALSE;
	dwDivider = 1;
	dwLog2Divider = 0;
	
	do
	{
		dwCPRD = ((dwMasterClock / dwDivider) / pPwmConfig->dwFrequency) - 1;

		if ((dwMasterClock / dwDivider) > (pPwmConfig->dwFrequency * PWMC_PRECISION_FACTOR))
		{
			if ((dwMasterClock / dwDivider / pPwmConfig->dwFrequency) < MAX_CPRD)
			{
				bDividerFound = TRUE;			
			}
		}

		if (!bDividerFound)
		{
			dwLog2Divider++;
			dwDivider <<=1;
		}

	} while ((!bDividerFound) && (dwDivider <= MAX_DIVIDER));


	if (!bDividerFound)
	{
		DEBUGMSG(ZONE_ERROR, (TEXT("<-ConfigurePWM : Invalid frequency range\r\n")));
		return FALSE;
	}
	
	bEnabled = (pDeviceContext->pPWMC_VirtualBase->PWMC_SR & (1 << pDeviceContext->dwIndex)) ? TRUE : FALSE;
	
	if (bEnabled)
	{
		pDeviceContext->pPWMC_VirtualBase->PWMC_DIS = 1 << pDeviceContext->dwIndex;
	}

	//! \todo : restart the counter when programming a new period
	pDeviceContext->pPWMC_VirtualBase->PWMC_CH[pDeviceContext->dwIndex].PWMC_CMR = dwLog2Divider;
	pDeviceContext->pPWMC_VirtualBase->PWMC_CH[pDeviceContext->dwIndex].PWMC_CPRDR = dwCPRD;
	pDeviceContext->pPWMC_VirtualBase->PWMC_CH[pDeviceContext->dwIndex].PWMC_CDTYR = (dwCPRD * pPwmConfig->dwDutyCycle) /100;
	pDeviceContext->pPWMC_VirtualBase->PWMC_CH[pDeviceContext->dwIndex].PWMC_CUPDR = (dwCPRD * pPwmConfig->dwDutyCycle) /100;
	
	if (bEnabled)
	{
		pDeviceContext->pPWMC_VirtualBase->PWMC_ENA = 1 << pDeviceContext->dwIndex;
	}

	DEBUGMSG(ZONE_INFO, (TEXT("<-ConfigurePWM : OK\r\n")));
	return TRUE;
}


//-----------------------------------------------------------------------------
//! \fn			static BOOL	GetDefaultParameters(T_IOCTLPWC_CONFIG * pPwmDefaultConfig, T_PWMC_INIT_STRUCTURE * pDeviceContext)
//!
//! \brief		This function retrieves default parameters (frequency and duty cycles) from registry
//!
//! \param		pPwmDefaultConfig	Pointer to a PWM configuration which will contain the default frequency and duty cycles
//! \param		pDeviceContext		Pointer to the Device Context
//!
//! \return		\e TRUE indicates success.
//! \return		\e FALSE indicates failure.
//!
//-----------------------------------------------------------------------------
static BOOL	GetDefaultParameters(T_IOCTLPWC_CONFIG * pPwmDefaultConfig, T_PWMC_INIT_STRUCTURE * pDeviceContext)
{
	BOOL bRet = TRUE;
	DWORD dwSize = 0;

	DEBUGMSG(ZONE_INFO, (TEXT("->GetDefaultParameters\r\n")));
	
	dwSize = sizeof(DWORD);
	if (RegQueryValueEx(pDeviceContext->hKey, TEXT("DefaultFrequency"), NULL, NULL, (LPBYTE)&(pPwmDefaultConfig->dwFrequency), &dwSize) != ERROR_SUCCESS)
	{
		DEBUGMSG(ZONE_INFO|ZONE_ERROR, (TEXT("GetDefaultParameters : RegQueryValueEx DefaultFrequency failed !\r\n")));
		bRet = FALSE;
	}

	dwSize = sizeof(DWORD);
	if (RegQueryValueEx(pDeviceContext->hKey, TEXT("DefaultDutyCycle"), NULL, NULL, (LPBYTE)&(pPwmDefaultConfig->dwDutyCycle), &dwSize) != ERROR_SUCCESS)
	{
		DEBUGMSG(ZONE_INFO|ZONE_ERROR, (TEXT("GetDefaultParameters : RegQueryValueEx DefaultDutyCycle failed !\r\n")));
		bRet = FALSE;
	}

	DEBUGMSG(ZONE_INFO, (TEXT("<-GetDefaultParameters\r\n")));
	return bRet;
}

//-----------------------------------------------------------------------------
//! \fn			DWORD PWC_Init(LPCTSTR pContext, LPCVOID lpvBusContext)
//!
//! \brief		This function initializes the device.
//!
//! Device Manager calls this function as a result of a call to the ActivateDeviceEx 
//! function. When the user starts using a device, such as inserting a PC Card, 
//! Device Manager calls this function to initialize the device. Applications do not call this function. 
//!
//! \param		pContext		Pointer to a string containing the registry path to the active key for the stream interface driver.
//! \param		lpvBusContext	Potentially process-mapped pointer passed as the 
//!								fourth parameter to ActivateDeviceEx. If this driver 
//!								was loaded through legacy mechanisms, then lpvBusContext 
//!								is zero. This pointer, if used, has only been mapped 
//!								again as it passes through the protected server library (PSL).
//!								The <b>PWC_Init</b> function is responsible for performing all protection 
//!								checking. In addition, any pointers referenced through lpvBusContext 
//!								must be remapped with the <b>MapCallerPtr</b> function before they 
//!								can be dereferenced.
//!
//! \return		Returns a handle to the device context created if successful. 
//!	\return		\e zero if not successful.
//-----------------------------------------------------------------------------
DWORD PWC_Init(LPCTSTR pContext, LPCVOID lpvBusContext)
{
    PHYSICAL_ADDRESS    PMC_PhysicalBase;    
	PHYSICAL_ADDRESS    PWMC_PhysicalBase;
	T_PWMC_INIT_STRUCTURE * pDeviceContext;
	DWORD				dwSize;
	DWORD				dwPolarity;
	
	DEBUGMSG(ZONE_INIT, (TEXT("->PWC_Init\r\n")));

	PMC_PhysicalBase.QuadPart = (LONGLONG)AT91C_BASE_PMC;

	pDeviceContext = (T_PWMC_INIT_STRUCTURE *)LocalAlloc(LMEM_ZEROINIT|LMEM_FIXED, sizeof(T_PWMC_INIT_STRUCTURE));

	if (pDeviceContext == 0)
	{
		DEBUGMSG(ZONE_INIT|ZONE_ERROR, (TEXT("<-PWC_Init KO : pDeviceContext NULL pointer !\r\n")));
		goto InitFailed;
	}

	pDeviceContext->pPMC_VirtualBase = (AT91PS_PMC)MmMapIoSpace(PMC_PhysicalBase, sizeof(AT91S_PMC), FALSE);


	pDeviceContext->hKey = OpenDeviceKey(pContext);

	
	dwPolarity = 0xFFFFFFFF;
	dwSize = sizeof(DWORD);
	// Retrieve the index of the device from registry
	if (RegQueryValueEx(pDeviceContext->hKey, TEXT("Polarity"), NULL, NULL, (LPBYTE)&(dwPolarity), &dwSize) != ERROR_SUCCESS)
	{
		DEBUGMSG(ZONE_INIT, (TEXT("<-PWC_Init : RegQueryValueEx Polarity failed ! using default\r\n")));		
		dwPolarity = 1;
	}
	if ((dwPolarity != 0) && (dwPolarity !=1))
	{
		DEBUGMSG(ZONE_INIT, (TEXT("<-PWC_Init : Invalid Polarity failed ! using default\r\n")));		
		dwPolarity = 1;
	}

	dwSize = sizeof(DWORD);
	// Retrieve the index of the device from registry
	if (RegQueryValueEx(pDeviceContext->hKey, TEXT("ChannelIndex"), NULL, NULL, (LPBYTE)&(pDeviceContext->dwIndex), &dwSize) != ERROR_SUCCESS)
	{
		DEBUGMSG(ZONE_INIT|ZONE_ERROR, (TEXT("<-PWC_Init KO : RegQueryValueEx ChannelIndex failed !\r\n")));
		goto InitFailed;
	}
	if (pDeviceContext->dwIndex>MAX_PWMC_CHANNEL)
	{
		DEBUGMSG(ZONE_INIT|ZONE_ERROR, (TEXT("<-PWC_Init KO : Invalid channel index !\r\n")));
		goto InitFailed;
	}
	
	PWMC_PhysicalBase.QuadPart = (LONGLONG)AT91C_BASE_PWMC;

	pDeviceContext->pPWMC_VirtualBase = (AT91PS_PWMC)MmMapIoSpace(PWMC_PhysicalBase, sizeof(AT91S_PWMC), FALSE);
	


	// Power-up the PWMC
	pDeviceContext->pPMC_VirtualBase->PMC_PCER = 1 << AT91C_ID_PWMC;

	// Configure the PWMC
	if (dwPolarity)
	{
		pDeviceContext->pPWMC_VirtualBase->PWMC_MR = 0; //Clock A and B not used, polarity = 1
	}
	else
	{
		pDeviceContext->pPWMC_VirtualBase->PWMC_MR = AT91C_PWMC_CPOL; //Clock A and B not used, polarity = 0;
	}
	pDeviceContext->pPWMC_VirtualBase->PWMC_IDR = 0xFFFFFFFF; //interrupts not used

	// Configuration of PIO is specific to the board
	if (ConfigurePioForPWM(pDeviceContext->dwIndex) == FALSE)
	{
		DEBUGMSG(ZONE_INIT | ZONE_ERROR, (TEXT("PWC_init : ConfigurePioForPWM failed\r\n")));
		goto InitFailed;
	}

	return (DWORD) pDeviceContext;


InitFailed:
	
	DEBUGMSG(ZONE_INIT|ZONE_ERROR, (TEXT("PWC_Init : InitFailed\r\n")));

	if (pDeviceContext->pPMC_VirtualBase != NULL)
	{
		MmUnmapIoSpace(pDeviceContext->pPMC_VirtualBase, sizeof(AT91S_PMC));
	}

	if (pDeviceContext->pPWMC_VirtualBase != NULL)
	{
		MmUnmapIoSpace(pDeviceContext->pPWMC_VirtualBase, sizeof(AT91S_PWMC));
	}

	
	if (pDeviceContext != 0)
	{
		LocalFree(pDeviceContext);
	}
	
	return 0;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL PWC_Deinit(T_PWMC_INIT_STRUCTURE *pDeviceContext)
//!
//! \brief		This function uninitializes the device.
//!
//! \param		pDeviceContext	Pointer to the the device init context. The PWC_Init (Device Manager)
//!								function creates and returns this pointer.
//!
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//!
//! When the user stops using a device, such as when a PC Card is removed from its socket, 
//! Device Manager calls this function. Applications do not call this function. Device Manager 
//! calls the PWC_Deinit driver function as a result of a call to the DeactivateDevice function. 
//! Your stream interface driver should free any resources it has allocated, and then terminate.
//-----------------------------------------------------------------------------
BOOL PWC_Deinit(T_PWMC_INIT_STRUCTURE * pDeviceContext)
{
	BOOL bRet = TRUE;

	DEBUGMSG(ZONE_DEINIT, (TEXT("->PWC_Deinit\r\n")));
	
	//We don't disable the PWMC clock here because other instance of this driver may still use it.
	// We could take count of the instance running and disable it whenever it's necessary.

	if (pDeviceContext != NULL)
	{
		if (pDeviceContext->pPMC_VirtualBase != NULL)
		{
			MmUnmapIoSpace(pDeviceContext->pPMC_VirtualBase, sizeof(AT91S_PMC));
		}

		if (pDeviceContext->pPWMC_VirtualBase != NULL)
		{
			MmUnmapIoSpace(pDeviceContext->pPWMC_VirtualBase, sizeof(AT91S_PWMC));
		}

		if (LocalFree(pDeviceContext) != NULL)
		{
			DEBUGMSG(ZONE_DEINIT|ZONE_ERROR, (TEXT("PWC_Deinit : LocalFree FAILED\r\n")));			
			bRet = FALSE;
		}

		RegCloseKey(pDeviceContext->hKey);
	}
	else
	{
		DEBUGMSG(ZONE_DEINIT|ZONE_ERROR, (TEXT("PWC_Deinit : pDeviceContext = NULL pointer\r\n")));
		bRet = FALSE;
	}

	DEBUGMSG(ZONE_DEINIT, (TEXT("<-PWC_Deinit\r\n")));
	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn			DWORD PWC_Open(T_PWMC_INIT_STRUCTURE *pDeviceContext, DWORD AccessCode, DWORD ShareMode)
//!
//! \brief		This function opens a device for reading, writing, or both.
//!
//! \param		pDeviceContext	Pointer to the the device open context. The <b>PWC_Init</b> (Device Manager)
//!								function creates and returns this identifier.
//! \param		AccessCode		Access code for the device. The access is a combination
//!								of read and write access from <b>CreateFile</b>. 
//! \param		ShareMode		File share mode of the device. The share mode is a combination 
//!								of read and write access sharing from <b>CreateFile</b>. 
//!
//! \return		This function returns a handle that identifies the open context of the device 
//!				to the calling application. If your device can be opened multiple times, use 
//!				this handle to identify each open context.
//!
//! When this function executes, your device should allocate the resources that it needs for 
//! each open context and prepare for operation. This might involve preparing the device for 
//! reading or writing and initializing data structures it uses for operation.
//-----------------------------------------------------------------------------
DWORD PWC_Open(T_PWMC_INIT_STRUCTURE *pDeviceContext , DWORD AccessCode, DWORD ShareMode)
{
	T_PWMC_OPEN_STRUCTURE * pOpenContext;

	DEBUGMSG(ZONE_OPEN, (TEXT("->PWC_Open\r\n")));
	pOpenContext = (T_PWMC_OPEN_STRUCTURE*)LocalAlloc(LMEM_ZEROINIT|LMEM_FIXED, sizeof(T_PWMC_OPEN_STRUCTURE));
	if (pOpenContext == 0)
	{
		DEBUGMSG(ZONE_OPEN|ZONE_ERROR, (TEXT("PWC_Open : pOpenContext NULL pointer\r\n")));
		goto OpenFailed;
	}
	
	// Store device settings for future use
	pOpenContext->pDeviceContext = pDeviceContext;
	
	pOpenContext->dwConfiguredAtLeastOneTime = 0;

	DEBUGMSG(ZONE_OPEN, (TEXT("<-PWC_Open OK\r\n")));
	return (DWORD)pOpenContext;

OpenFailed:

	DEBUGMSG(ZONE_OPEN|ZONE_ERROR, (TEXT("PWC_Open : OpenFailedr\r\n")));
	if (pOpenContext != 0)
	{
		LocalFree(pOpenContext);
	}
	
	DEBUGMSG(ZONE_OPEN|ZONE_ERROR, (TEXT("<-PWC_Open KO\r\n")));
	return 0;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL PWC_Close(T_PWMC_OPEN_STRUCTURE *pOpenContext)
//!
//! \brief		This function closes a device context created by the pOpenContext parameter.
//!
//! \param		pOpenContext	Pointer returned by the <b>PWC_Open</b> (Device Manager) function, 
//!								which is used to identify the open context of the device. 
//!
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//!
//! An application calls the CloseHandle function to stop using a stream interface driver. 
//! The hFile parameter specifies the handle associated with the device context. In response
//! to <b>CloseHandle</b>, the operating system invokes <b>PWC_Close</b>.
//-----------------------------------------------------------------------------
BOOL PWC_Close(T_PWMC_OPEN_STRUCTURE *pOpenContext)
{
	BOOL bRet = TRUE;
	DEBUGMSG(ZONE_CLOSE, (TEXT("->PWC_Close\r\n")));
	
	if (pOpenContext != NULL)
	{
		// Free memory
		if (LocalFree(pOpenContext) != NULL)
		{
			DEBUGMSG(ZONE_CLOSE|ZONE_ERROR, (TEXT("PWC_Close : LocalFree FAILED\r\n")));
			bRet = FALSE;
		}
	}

	DEBUGMSG(ZONE_CLOSE, (TEXT("<-PWC_Close\r\n")));
	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn			DWORD PWC_Read(T_PWMC_OPEN_STRUCTURE *pOpenContext, LPVOID pBuffer, DWORD dwCount)
//!
//! \brief		This function reads data from the device identified by the open context.
//!
//! \param		pOpenContext	Handle to the open context of the device. The <b>PWC_Open</b> 
//!								(Device Manager) function creates and returns this identifier.  
//! \param		pBuffer			Pointer to the buffer that stores the data read from 
//!								the device. This buffer should be at least <i>Count</i> bytes long. 
//! \param		dwCount			Number of bytes to read from the device into <i>pBuffer</i>.
//!
//! \return		\e zero to indicate <i>end-of-file</i>. 
//! \return		\e -1 to indicate an error. 
//! \return		The number of bytes read to indicate success.
//!
//! After an application calls the ReadFile function to read from the device, the operating system
//! invokes this function. The <i>hFile</i> parameter is a handle to the device. The <i>pBuffer</i> parameter 
//! points to the buffer that contains the data read from the device. The <i>dwCount</i> parameter indicates 
//! the number of bytes that the application requests to read from the device.
//-----------------------------------------------------------------------------
DWORD PWC_Read(T_PWMC_OPEN_STRUCTURE *pOpenContext, LPVOID pBuffer, DWORD dwCount)
{
	DEBUGMSG(ZONE_READ, (TEXT("->PWC_Read\r\n")));
	DEBUGMSG(ZONE_READ, (TEXT("<-PWC_Read\r\n")));
	return -1;
}


//-----------------------------------------------------------------------------
//! \fn			DWORD PWC_Write(T_PWMC_OPEN_STRUCTURE *pOpenContext, LPCVOID pBuffer, DWORD dwCount)
//!
//! \brief		This function writes data to the device.
//!
//! \param		pOpenContext	Handle to the open context of the device. The <b>PWC_Open</b> 
//!								(Device Manager) function creates and returns this identifier.  
//! \param		pBuffer			Pointer to the buffer that contains the data to write. 
//!								This buffer should be at least <i>Count</i> bytes long. 
//! \param		dwCount			Number of bytes to write from the <i>pBuffer</i> buffer into the device.
//!
//! \return		The number of bytes  written indicates success
//! \return		\e -1 to indicate an error. 
//!
//! After an application uses the WriteFile function to write to the device, the operating system, 
//! invokes this function. The <i>hFile</i> parameter is a handle to the device. The <i>pBuffer</i> parameter 
//! points to the buffer that contains the data read from the device. The <i>dwCount</i> parameter indicates 
//! the number of bytes that the application requests to write to the device.
//-----------------------------------------------------------------------------
DWORD PWC_Write(T_PWMC_OPEN_STRUCTURE *pOpenContext, LPCVOID pBuffer, DWORD dwCount)
{
	DEBUGMSG(ZONE_WRITE, (TEXT("->PWC_Write\r\n")));
	DEBUGMSG(ZONE_WRITE, (TEXT("<-PWC_Write\r\n")));
	return -1;
}


//-----------------------------------------------------------------------------
//! \fn			DWORD PWC_Seek(T_PWMC_OPEN_STRUCTURE *pOpenContext, long Amount, WORD wType)
//!
//! \brief		This function moves the data pointer in the device.
//!
//! \param		pOpenContext	Handle to the open context of the device. The <b>PWC_Open</b> 
//!								(Device Manager) function creates and returns this identifier.  
//! \param		Amount			Number of bytes to move the data pointer in the device. A positive value 
//!								moves the data pointer toward the end of the file and a negative value 
//!								moves it toward the beginning.
//! \param		wType			Starting point for the data pointer. The following table shows the available values for this parameter.
//!
//! \return		The new data pointer for the device indicates success.
//! \return		\e -1 to indicate an error. 
//!
//! After an application calls the SetFilePointer function to move the data pointer in the device, 
//! the operating system invokes this function. If your device is capable of opening more than once, 
//! this function modifies only the data pointer for the instance specified by <i>pOpenContext</i>.
//-----------------------------------------------------------------------------
DWORD PWC_Seek(T_PWMC_OPEN_STRUCTURE *pOpenContext, long Amount, WORD wType)
{
	DEBUGMSG(ZONE_SEEK, (TEXT("->PWC_Seek\r\n")));
	DEBUGMSG(ZONE_SEEK, (TEXT("<-PWC_Seek\r\n")));
	return -1;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL PWC_IOControl(T_PWMC_OPEN_STRUCTURE *pOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut)
//!
//! \brief		This function sends a command to a device.
//!
//! \param		pOpenContext	Handle to the open context of the device. The <b>PWC_Open</b> 
//!								(Device Manager) function creates and returns this identifier.  
//! \param		dwCode			I/O control operation to perform. These codes are device-specific and 
//!								are usually exposed to developers through a header file. 
//!								Use <b>CTL_CODE</b> macro to generate a driver unique identifier for your iocontrol.
//! \param		pBufIn			Pointer to the buffer containing data to transfer to the device. 
//! \param		dwLenIn			Number of bytes of data in the buffer specified for <i>pBufIn</i>.
//! \param		pBufOut			Pointer to the buffer used to transfer the output data from the device.
//! \param		dwLenOut		Maximum number of bytes in the buffer specified by <i>pBufOut</i>.
//! \param		pdwActualOut	Pointer to the <b>DWORD</b> buffer that this function uses to 
//!								return the actual number of bytes received from the device. 
//!
//! \return		\e TRUE indicates success.
//! \return		\e FALSE indicates failure.
//!
//! An application uses the DeviceIoControl function to specify an operation to perform. The operating system,
//! in turn, invokes the <b>PWC_IOControl</b> function. The <i>dwCode</i> parameter contains the input or output 
//! operation to perform; these codes are usually specific to each device driver and are exposed to application 
//! programmers through a header file that the device driver developer makes available.
//!
//! Available IOControls are :
//!
//!		- IOCTL_PWC_CONFIG	: Configure the Frequency, the Duty Cycle A & B of the PWM signal
//!			- \e pBufIn		: (T_IOCTLPWC_CONFIG *)
//!			- \e pBufOut	: NULL
//!
//!		- IOCTL_PWC_START	: Start the PWM
//!			- \e pBufIn		: NULL
//!			- \e pBufOut	: NULL
//!
//!		- IOCTL_PWC_STOP	: Stop the PWM
//!			- \e pBufIn		: NULL
//!			- \e pBufOut	: NULL
//!
//-----------------------------------------------------------------------------
BOOL PWC_IOControl(T_PWMC_OPEN_STRUCTURE * pOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut)
{
	BOOL bRet = TRUE;
	DWORD dwRCValue = 0;

	DEBUGMSG(ZONE_IOCTL, (TEXT("->PWC_IOControl\r\n")));

	if (pdwActualOut != NULL)
	{
		*pdwActualOut = 0;
	}

	if (pOpenContext == NULL)
	{
		DEBUGMSG(ZONE_IOCTL|ZONE_ERROR, (TEXT("PWC_IOControl : pOpenContext NULL pointer\r\n")));
		DEBUGMSG(ZONE_IOCTL, (TEXT("<-PWC_IOControl KO\r\n")));
		return FALSE;
	}

	switch (dwCode)
	{
		case IOCTL_PWC_CONFIG:
		{		
			T_IOCTLPWC_CONFIG * pPwmConfig;

			if ((pBufIn == NULL) || (dwLenIn != sizeof(T_IOCTLPWC_CONFIG)) || (pBufOut != NULL) || (dwLenOut != 0))
			{
				DEBUGMSG(ZONE_IOCTL|ZONE_ERROR, (TEXT("<-PWC_IOControl : Invalid parameters\r\n")));
				SetLastError(ERROR_INVALID_PARAMETER);
				return FALSE;
			}
			else
			{
				pPwmConfig = (T_IOCTLPWC_CONFIG *) pBufIn;
				if (pPwmConfig->dwFrequency == 0)
				{
					DEBUGMSG(ZONE_IOCTL|ZONE_ERROR, (TEXT("<-PWC_IOControl : Frequency = 0 Hz !!\r\n")));
					SetLastError(ERROR_INVALID_PARAMETER);
					return FALSE;
				}
			}
	
			if (ConfigurePWM(pPwmConfig, pOpenContext->pDeviceContext))
			{
				if (pdwActualOut != NULL)
				{
					*pdwActualOut = sizeof(T_IOCTLPWC_CONFIG);
				}
				// Now the PWM is configured with user parameters
				pOpenContext->dwConfiguredAtLeastOneTime = 1;
			}
		}
		break;

		case IOCTL_PWC_START:
		{
			if ((pBufIn != NULL) || (dwLenIn != 0) || (pBufOut != NULL) || (dwLenOut != 0))
			{
				DEBUGMSG(ZONE_IOCTL|ZONE_ERROR, (TEXT("<-PWC_IOControl : Invalid parameters\r\n")));
				SetLastError(ERROR_INVALID_PARAMETER);
				return FALSE;
			}

			// We can start PWM with default parameters from registry
			if (pOpenContext->dwConfiguredAtLeastOneTime == 0)
			{
				T_IOCTLPWC_CONFIG pwmDefaultConfig;
				if (GetDefaultParameters(&pwmDefaultConfig, pOpenContext->pDeviceContext))
				{
					if (ConfigurePWM(&pwmDefaultConfig, pOpenContext->pDeviceContext))
					{
						// Now the PWM is configured with default parameters
						pOpenContext->dwConfiguredAtLeastOneTime = 1;
					}
				}
			}
			// Enable the clock
			pOpenContext->pDeviceContext->pPWMC_VirtualBase->PWMC_ENA = 1 << pOpenContext->pDeviceContext->dwIndex;
		}
		break;

		case IOCTL_PWC_STOP:
		{
			if ((pBufIn != NULL) || (dwLenIn != 0) || (pBufOut != NULL) || (dwLenOut != 0))
			{
				DEBUGMSG(ZONE_IOCTL|ZONE_ERROR, (TEXT("<-PWC_IOControl : Invalid parameters\r\n")));
				SetLastError(ERROR_INVALID_PARAMETER);
				return FALSE;
			}
			// Disable the clock
			pOpenContext->pDeviceContext->pPWMC_VirtualBase->PWMC_DIS = 1 << pOpenContext->pDeviceContext->dwIndex;
		}
		break;

		default:
			bRet = FALSE;
			DEBUGMSG(ZONE_IOCTL|ZONE_ERROR, (TEXT("PWC_IOControl : IOCTL Unknown !\r\n")));
	}

	DEBUGMSG(ZONE_IOCTL, (TEXT("<-PWC_IOControl\r\n")));
	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn			void PWC_PowerDown(T_PWMC_INIT_STRUCTURE *pDeviceContext)
//!
//! \brief		This function suspends power to the device. It is useful only with devices that can 
//!				power down under software control. Such devices are typically, but not exclusively, PC Cards.
//!
//! \param		pDeviceContext	Pointer to the device context. The call to the <b>PWC_Init</b> 
//!								(Device Manager) function returns this identifier.  
//!
//! \return		none
//!
//! The OS invokes this function to suspend power to a device.
//-----------------------------------------------------------------------------
void PWC_PowerDown(T_PWMC_INIT_STRUCTURE *pDeviceContext)
{

}


//-----------------------------------------------------------------------------
//! \fn			void PWC_PowerUp(T_PWMC_INIT_STRUCTURE *pDeviceContext)
//!
//! \brief		This function restore power to a device.
//!
//! \param		pDeviceContext	Pointer to the device context. The call to the <b>PWC_Init</b> 
//!								(Device Manager) function returns this identifier.  
//!
//! \return		none
//!
//! The OS invokes this function to restore power to a device.
//-----------------------------------------------------------------------------
void PWC_PowerUp(T_PWMC_INIT_STRUCTURE *pDeviceContext)
{

}

//! @}
//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/DRIVERS/PwmC/Pwmc.c $
//-----------------------------------------------------------------------------
//
