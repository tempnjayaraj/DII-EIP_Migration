//-----------------------------------------------------------------------------
//! \addtogroup   Serial
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				AT91RM9200_serial.h
//!
//! \brief				Header for Specific interfaces of Serial driver
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/INC/AT91RM9200_serial.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

#ifndef __AT91RM9200_SERIAL_H__
#define __AT91RM9200_SERIAL_H__


// Specific hardware function
typedef VOID (*LPCLEARRTS)(PVOID pHardwareContext);
typedef VOID (*LPSETRTS)(PVOID pHardwareContext);
typedef VOID (*LPCLEARDTR)(PVOID pHardwareContext);
typedef VOID (*LPSETDTR)(PVOID pHardwareContext);
typedef VOID (*LPCLEARBREAK)(PVOID pHardwareContext);
typedef VOID (*LPSETBREAK)(PVOID pHardwareContext);


/*! \struct T_SERIAL_HW
	\brief Structure given by the board specific part of the driver to the generic part of it.
*/
typedef struct {
	DWORD dwSysIntr;		//!< Device associated sysintr
	DWORD dwBaseAddress;	//!< HW registers base address
	DWORD dwDeviceID;		//!< HW Device ID
	DWORD dwIntMask;		//!< HW Interrupt enable
	
	DWORD dwPDCBaseAddress; //!< HW PDC register base address
	LPCLEARRTS pfnClearRTS;	//!< HW RTS clear management
	LPSETRTS pfnSetRTS;		//!< HW RTS set management
	LPCLEARRTS pfnClearDTR;	//!< HW DTR clear management
	LPSETRTS pfnSetDTR;		//!< HW DTR set management
	LPCLEARRTS pfnClearBreak;	//!< HW Break clear management
	LPSETRTS pfnSetBreak;		//!< HW Break set management
} T_SERIAL_HW;


#endif // #define __AT91RM9200_SERIAL_H__

//! @}
