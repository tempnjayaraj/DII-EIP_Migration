//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!  
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		Pwm.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/Pwm/Pwm.h $
//!   $Author: pblanchard $
//!   $Revision: 984 $
//!   $Date: 2007-06-11 09:19:22 -0700 (Mon, 11 Jun 2007) $
//! \endif
//!
//! Header for Pwm driver
//-----------------------------------------------------------------------------
//! \addtogroup	PWM
//! @{
//!  

#ifndef __PWM_H__
#define __PWM_H__

#define RC_MIN				100		// Minimum of Rc register, to get at least a duty cycle precision of 1/100
#define RC_MAX				0xFFFF	//Max of Rc register
#define TIMER_CLOCK1_DIV	2
#define TIMER_CLOCK2_DIV	8
#define TIMER_CLOCK3_DIV	32
#define TIMER_CLOCK4_DIV	128
#define TIMER_CLOCK5		SLOW_CLOCK_FREQUENCY

#define F1_MAX(dwSrcClock)		(dwSrcClock / (TIMER_CLOCK1_DIV * RC_MIN))
#define F1_MIN(dwSrcClock)		(dwSrcClock / (TIMER_CLOCK1_DIV * RC_MAX))

#define F2_MAX(dwSrcClock)		(dwSrcClock / (TIMER_CLOCK2_DIV * RC_MIN))
#define F2_MIN(dwSrcClock)		(dwSrcClock / (TIMER_CLOCK2_DIV * RC_MAX))

#define F3_MAX(dwSrcClock)		(dwSrcClock / (TIMER_CLOCK3_DIV * RC_MIN))
#define F3_MIN(dwSrcClock)		(dwSrcClock / (TIMER_CLOCK3_DIV * RC_MAX))

#define F4_MAX(dwSrcClock)		(dwSrcClock / (TIMER_CLOCK4_DIV * RC_MIN))
#define F4_MIN(dwSrcClock)		(dwSrcClock / (TIMER_CLOCK4_DIV * RC_MAX))

#define F5_MAX		(TIMER_CLOCK5 / (RC_MIN))
#define F5_MIN		(TIMER_CLOCK5 / (RC_MAX))

/*! \brief Initialization context
	this structure contains the information needed by the driver to manage the hardware that is common to all of its instances
*/
typedef struct {
	AT91PS_PIO	pPIOC_VirtualBase;	//!<Base Address of PIO C
	AT91PS_PMC	pPMC_VirtualBase;	//!<Base Address of PMC
	AT91PS_TC	pTC_VirtualBase;	//!<Base Address of TC
	DWORD		dwIndex;			//!<Index of the peripheral	
	HKEY		hKey;				//!<Registry Key
	CEDEVICE_POWER_STATE CurrentDx;	//!< Driver current power state
} T_PWMINIT_STRUCTURE;

/*! \brief Initialization context
	this structure contains the information needed by the driver to manage the hardware that is specific to a particular instance
*/
typedef struct {
	T_PWMINIT_STRUCTURE * pDeviceContext;	//!<Pointer on a device context
	DWORD dwConfiguredAtLeastOneTime;		//!<Flag to know if the PWM is configured
} T_PWMOPEN_STRUCTURE;

extern BOOL ConfigurePioForPWM(DWORD dwIndex, AT91PS_PMC pPMC_VirtualBase, AT91PS_PIO pPIOC_VirtualBase);

#endif /*__PWM_H__*/

//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/Pwm/Pwm.h $
//-----------------------------------------------------------------------------
//! @}
