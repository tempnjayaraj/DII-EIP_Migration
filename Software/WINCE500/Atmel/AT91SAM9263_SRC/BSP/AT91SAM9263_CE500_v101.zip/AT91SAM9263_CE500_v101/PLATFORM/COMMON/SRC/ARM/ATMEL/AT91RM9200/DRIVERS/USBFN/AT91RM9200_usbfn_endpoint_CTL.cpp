//-----------------------------------------------------------------------------
//! \addtogroup   USBFN
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				AT91RM9200_usbfn_endpoint_ctl.cpp
//!
//! \brief				Implementation of a Control endpoint
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/DRIVERS/USBFN/AT91RM9200_usbfn_endpoint_CTL.cpp $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------
#include <windows.h>
#include <ceddk.h>
#include <ddkreg.h>
#include "AT91RM9200_usbfn.h"
#include "AT91RM9200.h"


#include "AT91RM9200_USBFN_EndPoint.h"
#include "AT91rM9200_USBFN_EndPoint_CTL.h"

#pragma pack(1)
typedef struct {
	unsigned int dwDTERRate;
	char bCharFormat;
	char bParityType;
	char bDataBits;
} CDC_LINE_CODING;
#pragma pack()

typedef enum {
	NO_FRAME_EXPECTED=0,
	CDC_CODING_EXPECTED
} T_EXPECTED_FRAME_TYPE;

USB_DEVICE_REQUEST gConfUdr;

// "C-style" callbacks
void CallBackSetAddressCompleted(AT91RMEndpoint* pCtrlEP,DWORD dwParam)
{
	pCtrlEP->SetAddressCompleted(dwParam);
}
void CallBackSetConfigurationCompleted(AT91RMEndpoint* pCtrlEP,DWORD dwParam)
{
	pCtrlEP->SetConfigurationCompleted(dwParam);
}

void AT91RMEndpointCtrl::SetAddressCompleted(DWORD dwParam)
{

	/*! \note This step must be done AFTER acknowledging the set address request with a zero packet transfer
	*/
	UCHAR ucAddress;

	// The address is a byte.
	if (dwParam > 0xFF)
	{
		RETAILMSG(1,(TEXT("Invalid address (0x%x)\r\n"),dwParam));
		return;
	}

	ucAddress = (UCHAR) dwParam;

	// Set Address
	m_pUsbDevice->m_pUDP->UDP_FADDR = (m_pUsbDevice->m_pUDP->UDP_FADDR & ~AT91C_UDP_FADD) | (ucAddress & AT91C_UDP_FADD);
	

	if (ucAddress)
	{
		// Move the UDP function to the addressed state
		m_pUsbDevice->m_pUDP->UDP_GLBSTATE  |= AT91C_UDP_FADDEN;
	}
	else
	{
		// Move the UDP function to the default state
		m_pUsbDevice->m_pUDP->UDP_GLBSTATE  &= ~(AT91C_UDP_FADDEN | AT91C_UDP_CONFG);
	}


}
void AT91RMEndpointCtrl::SetConfigurationCompleted(DWORD dwParam)
{	
	m_pUsbDevice->m_pUDP->UDP_GLBSTATE  |= AT91C_UDP_CONFG;
	m_pUsbDevice->DeviceNotification(UFN_MSG_PREPROCESSED_SETUP_PACKET, (DWORD) &gConfUdr);
}


//-----------------------------------------------------------------------------
//! \fn			BOOL AT91RMEndpointCtrl:: Init( PUSB_ENDPOINT_DESCRIPTOR pEndpointDesc, BYTE bConfigurationValue, BYTE bInterfaceNumber, BYTE bAlternateSetting)
//! \brief		This function initializes the zero endpoint.
//!
//! \param		pEndpointDesc			Endpoint descriptor
//! \param		bConfigurationValue		Configuration value
//! \param		bInterfaceNumber		Interface number
//! \param		bAlternateSetting		Alternate setting
//!
//! \return		Does the init succeed ?
//!
//-----------------------------------------------------------------------------
BOOL AT91RMEndpointCtrl:: Init( PUSB_ENDPOINT_DESCRIPTOR pEndpointDesc,
            BYTE bConfigurationValue, BYTE bInterfaceNumber, BYTE bAlternateSetting)
{
    Lock();
    BOOL bReturn = FALSE;
    SETFNAME();
    FUNCTION_ENTER_MSG();
    
	// Set in control mode		
    if ( pEndpointDesc && m_pUsbDevice!=NULL && m_dwEndpointIndex < MAX_ENDPOINT_NUMBER) 
	{
        if (AT91RMEndpoint::Init(pEndpointDesc,bConfigurationValue,bInterfaceNumber,bAlternateSetting))
		{
			m_pUsbDevice->EnableEndpointInterrupt(m_dwEndpointIndex,TRUE);
			m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] = m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] & ~AT91C_UDP_EPTYPE | AT91C_UDP_EPTYPE_CTRL;
			bReturn = TRUE;
		}
    }
    Unlock();
    FUNCTION_LEAVE_MSG();
    return bReturn;
}

//-----------------------------------------------------------------------------
//! \brief		This function sends a control status handshake on zero endpoint.
//!
//! \return		ERROR_INVALID_DATA	The data isn't mean to be sent
//! \return		ERROR_SUCCESS		Success
//!
//! This function sends a control status handshake on zero endpoint. Calls IST and DeviceNotification.
//-----------------------------------------------------------------------------
DWORD AT91RMEndpointCtrl::SendControlStatusHandshake(CtrlCallBackInfo* pCallBackInfo)
{
    Lock();
    SETFNAME();
    DWORD dwReturn = ERROR_SUCCESS ;

	if (m_bIgnoreNextHandshakeFromMDD &&  (pCallBackInfo == NULL))
	{
		Unlock();
		return ERROR_SUCCESS;
	}	
	

    if (m_pCurTransfer != NULL) 
	{
		//Cancel the current transfer
		DEBUGMSG(ZONE_TRANSFER | ZONE_WARNING, (_T("%s : There's already a transfer running. Cancelling it to send the zero length packet\r\n"), pszFname));
		CompleteTransfer(UFN_NOT_COMPLETE_ERROR);
	}
	
	// Now no Transfer is running
      
	//Send a zero length packet.
	if (XmitData(NULL,0) != 0)
	{
		DEBUGMSG(ZONE_TRANSFER | ZONE_WARNING, (_T("%s : Xmit data failed\r\n"), pszFname));
	}
	else
	{
		m_pCallBackInfo = pCallBackInfo;
	}
	        
	Unlock();
    return ERROR_SUCCESS;
}

DWORD   AT91RMEndpointCtrl::IST(DWORD dwIRBit)
{
	BYTE fifoData [8];
	static CDC_LINE_CODING cdcLineCoding={115200,0,0,8};
	static T_EXPECTED_FRAME_TYPE nextFrameType = NO_FRAME_EXPECTED;
    Lock();

    BOOL bContinue;
    SETFNAME();
    FUNCTION_ENTER_MSG();

    do
	{
        bContinue = FALSE;        
	

		DEBUGMSG(ZONE_TRANSFER, (_T("Endpoint Zero IST : Status register 0x%08X\r\n"), m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex]));

		DWORD dwStatusRegister = m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex];
		DWORD dwNbBytesReceived;

		if (dwStatusRegister & AT91C_UDP_TXCOMP)
		{
//			DEBUGMSG(ZONE_TRANSFER, (_T("Endpoint Zero IST : TXCOMP\r\n")));
		}

		if (dwStatusRegister & AT91C_UDP_RX_DATA_BK0)
		{
//			DEBUGMSG(ZONE_TRANSFER, (_T("Endpoint Zero IST : RX_DATA_BK0\r\n")));
		}
		if (dwStatusRegister & AT91C_UDP_RXSETUP)
		{
//			DEBUGMSG(ZONE_TRANSFER, (_T("Endpoint Zero IST : RXSETUP ddd\r\n")));
		}
		if (dwStatusRegister & AT91C_UDP_ISOERROR)
		{
//			DEBUGMSG(ZONE_TRANSFER, (_T("Endpoint Zero IST : ISOERROR\r\n")));
		}
		if ((dwStatusRegister & AT91C_UDP_TXPKTRDY) == 0)
		{
//			DEBUGMSG(ZONE_TRANSFER, (_T("Endpoint Zero IST : TXPKTRDY\r\n")));
		}
		else
		{
//			DEBUGMSG(ZONE_TRANSFER, (_T("Endpoint Zero IST : TXPKTRDY (not ready)\r\n")));
		}
		if (dwStatusRegister & AT91C_UDP_FORCESTALL)
		{
//			DEBUGMSG(ZONE_TRANSFER, (_T("Endpoint Zero IST : FORCESTALL\r\n")));
		}
		if (dwStatusRegister & AT91C_UDP_RX_DATA_BK1)
		{
//			DEBUGMSG(ZONE_TRANSFER, (_T("Endpoint Zero IST : RX_DATA_BK1\r\n")));
		}

		if (dwStatusRegister & AT91C_UDP_DTGLE)
		{
//			DEBUGMSG(ZONE_TRANSFER, (_T("Endpoint Zero IST : DTGLE\r\n")));
		}


		if (dwStatusRegister & AT91C_UDP_ISOERROR)
		{
			// Clear the ISOERROR/STALLSENT bit
			m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] &= ~AT91C_UDP_ISOERROR;
			CompleteTransfer(UFN_DEVICE_NOT_RESPONDING_ERROR);
			bContinue = TRUE;
		}


		
		if ((m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] & AT91C_UDP_TXCOMP) || ((1 | dwStatusRegister & AT91C_UDP_TXPKTRDY) == 0))
		{			
			// // The Host has acknowledged our IN packet...  Clear the TXCOMP bit
			if (m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] & AT91C_UDP_TXCOMP)
			{
				m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] &= ~AT91C_UDP_TXCOMP;
			}
			if (m_pCallBackInfo)
			{

				if (m_pCallBackInfo->m_pFnCallBack)
				{
					m_pCallBackInfo->m_pFnCallBack(m_pCallBackInfo->m_pContext,m_pCallBackInfo->m_dwParam);
				}
				delete m_pCallBackInfo;
				m_pCallBackInfo = NULL;				
				bContinue = TRUE;
			}
			
			//Are we currently transferring a IN packet
			if (m_pCurTransfer && (m_pCurTransfer->dwFlags & USB_IN_TRANSFER))
			{
				//Was this the las packet of the transfer ?
				if ((DWORD) m_pCurTransfer->pvPddTransferInfo == AT91RM9200_END_OF_TRANSFER)
				{
					//Tell the MDD that the transfer is complete with no error
					CompleteTransfer(UFN_NO_ERROR);
				}
				// It wasn't the last packet so we try to send the next packet...
				else 
				{
					BOOL bResult;
					DWORD dwToSend;
					dwToSend = MIN(m_pCurTransfer->cbBuffer - m_pCurTransfer->cbTransferred, m_epDesc.wMaxPacketSize);
					
					// If the data amount is less than the fifo limit it will be the last packet.
					// If the data amount is exactly the fifo size, then will send a zero length packet after this one.
					if (dwToSend < m_epDesc.wMaxPacketSize)
					{
						m_pCurTransfer->pvPddTransferInfo = (PVOID) AT91RM9200_END_OF_TRANSFER;
					}			
				
					bResult = XmitData(((UCHAR*)m_pCurTransfer->pvBuffer)+ m_pCurTransfer->cbTransferred, dwToSend);					
				
					if (bResult != dwToSend)
					{
						RETAILMSG(1,(TEXT("IST end point zero, XmitData failed....\r\n")));
						//Tell the MDD that we failed ....						
						CompleteTransfer(UFN_NOT_COMPLETE_ERROR);
					}
					else
					{
						m_pCurTransfer->cbTransferred+= dwToSend;
					}
				}
				bContinue = TRUE;
			}
		}
			
	
		
	
		////////////////////////////////////////////////////////////////////////////////////////////
		// Setup Packet
		////////////////////////////////////////////////////////////////////////////////////////////
		if (dwStatusRegister & AT91C_UDP_RXSETUP)
		{

			dwNbBytesReceived = (dwStatusRegister & AT91C_UDP_RXBYTECNT) >> 16;		
			if (dwNbBytesReceived != 0)
			{
				
				TCHAR strDump[sizeof(fifoData)*7 + 1] = L"\0";

				for (DWORD i = 0; i < dwNbBytesReceived; i++)
				{
					fifoData[i] = m_pUsbDevice->m_pUDP->UDP_FDR[m_dwEndpointIndex];
					swprintf(strDump, (TEXT("%s 0x%02X")), strDump, fifoData[i]);
				}
				DEBUGMSG(ZONE_TRANSFER, (_T("Endpoint Zero IST (RXSETUP): Data received : %s \n"), strDump));
			}


			// This is setup Packet.
			DEBUGMSG(ZONE_TRANSFER, (_T("This is a setup Packet\r\n")));

			if (m_pCurTransfer)
			{
			   // Outstanding transfer.
			   DEBUGMSG(ZONE_TRANSFER, (_T("Endpoint Zero Current Transfer Canceled\r\n")));
			   CompleteTransfer( UFN_CANCELED_ERROR );
			}
			
			union 
			{
				USB_DEVICE_REQUEST udr;
				BYTE dw8Byte[8];
			};

			// Copy the setup packet
			memcpy(dw8Byte, fifoData, MIN(dwNbBytesReceived,sizeof(dw8Byte)));
			
			
			// Set the direction of the transfer according to the request
			// The AT91C_UDP_DIR bit must be set before acknoledging the RXSETUP (see Atmel Datasheet)
			if (udr.bmRequestType & USB_REQUEST_DEVICE_TO_HOST) //Set the direction of the transfer according to the request
			{
				m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] = dwStatusRegister | AT91C_UDP_DIR;
			}
			else
			{
				m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] = dwStatusRegister & ~AT91C_UDP_DIR;
			}
			

			// Acknoledge the setup packet			
			m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] = (m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] & ~AT91C_UDP_RXSETUP);

			// Request display
			DEBUGMSG(ZONE_TRANSFER, (_T("Endpoint Zero Setup bmRequestType = 0x%x, bRequest=0x%x, wValue=0x%x,wIndex=0x%x,wLength=0x%x\n"),
				udr.bmRequestType,udr.bRequest,udr.wValue,udr.wIndex,udr.wLength));
			
			
			bContinue = TRUE ;	

			if (udr.bmRequestType == 0x0 || udr.bmRequestType == 0x80)
			{
				//Standard request .... we're going to ignore stushandshake ack from MMD
				m_bIgnoreNextHandshakeFromMDD = TRUE;
			}
			else
			{
				m_bIgnoreNextHandshakeFromMDD = FALSE;
			}
			
			if (udr.bmRequestType==0 && udr.bRequest == 0x5)
			{
				//The following object will detroyed after the callback is called
				CtrlCallBackInfo* pCtrCallBack = new CtrlCallBackInfo(this,CallBackSetAddressCompleted,udr.wValue);
				m_pUsbDevice->DeviceNotification(UFN_MSG_PREPROCESSED_SETUP_PACKET, (DWORD) &udr);
				m_bIgnoreNextHandshakeFromMDD = TRUE;
				SendControlStatusHandshake(pCtrCallBack);							
			}
			
			else if (udr.bmRequestType==0x0 && udr.bRequest == 0x09)
			{
				 //The following object will detroyed after the callback is called
				CtrlCallBackInfo* pCtrCallBack = new CtrlCallBackInfo(this,CallBackSetConfigurationCompleted,udr.wValue);
				m_pUsbDevice->DeviceNotification(UFN_MSG_PREPROCESSED_SETUP_PACKET, (DWORD) &udr);
				m_bIgnoreNextHandshakeFromMDD = TRUE;
				SendControlStatusHandshake(pCtrCallBack);	
			}
			else
			{
				
				// !!!!! This is for the serial emulation only. Because the current USB device MDD doesn't allow to retreive data from the control endpoint in the client part, we must do it here ... (or rewrite a bit of the MDD)				
				if (udr.bmRequestType==0x21 && udr.bRequest == 0x20)
				{
					nextFrameType = CDC_CODING_EXPECTED;
					//SendControlStatusHandshake(NULL);	
				}
				else if (udr.bmRequestType==0xA1 && udr.bRequest == 0x21)
				{
					XmitData((LPBYTE)&cdcLineCoding,sizeof(cdcLineCoding));
					//SendControlStatusHandshake(NULL);	
				}				// Pass it to the MDD
				
				m_pUsbDevice->DeviceNotification(UFN_MSG_SETUP_PACKET, (DWORD) &udr);
			}

			bContinue = TRUE;

		}

	

		////////////////////////////////////////////////////////////////////////////////////////////
		// Receive Packet
		////////////////////////////////////////////////////////////////////////////////////////////

		if ((dwStatusRegister & AT91C_UDP_RX_DATA_BK0) || (dwStatusRegister & AT91C_UDP_RX_DATA_BK1))
		{
			BOOL bOK = TRUE;
			Sleep(10);

			dwNbBytesReceived = (dwStatusRegister & AT91C_UDP_RXBYTECNT) >> 16;		
			if (dwNbBytesReceived != 0)
			{

#ifdef DEBUG				
				TCHAR strDump[sizeof(fifoData)*7 + 1] = L"\0";
#endif
				for (DWORD i = 0; i < dwNbBytesReceived; i++)
				{
					fifoData[i] = m_pUsbDevice->m_pUDP->UDP_FDR[m_dwEndpointIndex];
#ifdef DEBUG
					swprintf(strDump, (TEXT("%s 0x%02X")), strDump, fifoData[i]);
#endif
				}
				DEBUGMSG(ZONE_TRANSFER, (_T("Endpoint Zero IST (RECEIVE BK): Data received : %s \n"), strDump));
			}


			// Do we have a transfer in progress ?
			if (m_pCurTransfer) 
			{				
				// Is it a OUT transfer ?
				if((m_pCurTransfer->dwFlags & USB_IN_TRANSFER) == 0) 
				{ // Out Data.
					int iToTransfer;
					if (dwNbBytesReceived < m_epDesc.wMaxPacketSize)
					{
						iToTransfer = dwNbBytesReceived;
						m_pCurTransfer->pvPddTransferInfo = (PVOID) AT91RM9200_END_OF_TRANSFER;
					}
					else
					{
						iToTransfer = dwNbBytesReceived;
					}

					int iFreeSpaceInBuffer = m_pCurTransfer->cbBuffer - m_pCurTransfer->cbTransferred;
					
					
					if (iToTransfer > iFreeSpaceInBuffer)
					{
						CompleteTransfer(UFN_CLIENT_BUFFER_ERROR);
					}
					else
					{
						
					
						memcpy(m_pCurTransfer->pvBuffer,fifoData,iToTransfer);							 
						m_pCurTransfer->cbTransferred += iToTransfer;

						if ((DWORD) m_pCurTransfer->pvPddTransferInfo == AT91RM9200_END_OF_TRANSFER)
						{
							CompleteTransfer(UFN_NO_ERROR);
						}
					}																			
				}
				else if (dwNbBytesReceived == 0) // Not a IN transfer ... must an Acknowledge from Host
				{
					DEBUGMSG(ZONE_TRANSFER, (_T("Ack from the host (0x%08X)\n"), m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex]));
					CompleteTransfer(UFN_NO_ERROR);					
					bContinue = TRUE;
				}
				else
				{
					bOK = FALSE;
				}
				

			}


			


			if (bOK)
			{
				if ((m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] & AT91C_UDP_DTGLE) == 0)
				{
					m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] &= ~AT91C_UDP_RX_DATA_BK0;
				}
				else
				{
					m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] &= ~AT91C_UDP_RX_DATA_BK1;
				}
				bContinue = TRUE;
			}

			if (nextFrameType == CDC_CODING_EXPECTED)
			{
				memcpy(&cdcLineCoding,fifoData,min(sizeof(cdcLineCoding),dwNbBytesReceived));
				nextFrameType = NO_FRAME_EXPECTED;
				CtrlCallBackInfo* pCtrCallBack = new CtrlCallBackInfo(this,NULL,0);
				SendControlStatusHandshake(pCtrCallBack);

			}
		}
        
    } while (bContinue);
    
//	DEBUGMSG(1, (_T("Endpoint Zero IST : Status register 0x%08X\r\n"), m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex]));

	
//	m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] |= AT91C_UDP_EPEDS;

	Unlock();
    FUNCTION_LEAVE_MSG();
    return ERROR_SUCCESS;
}

//! @}
