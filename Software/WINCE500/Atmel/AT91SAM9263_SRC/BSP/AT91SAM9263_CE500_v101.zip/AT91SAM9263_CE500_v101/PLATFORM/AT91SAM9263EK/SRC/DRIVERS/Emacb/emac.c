//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//  All rights reserved ADENEO SAS 2005
//
//-----------------------------------------------------------------------------
//! \file		emac.c
//
//! \brief		This file implements the OAL (and bootloader) interface of the Ethernet controller
//
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/Emacb/Emac.c $
//!   $Author: ltourlonias $
//!   $Revision: 684 $
//!   $Date: 2007-04-13 14:35:48 +0200 (ven., 13 avr. 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	EMAC
//! @{


#include <windows.h>
#include <oal.h>
#include <Nkintr.h>

#include "AT91SAM926x.h"
#include "AT91SAM926x_interface.h"
#include "lib_AT91SAM926x.h"
#include "EMAC.h"

//#include "mii.h"

#include "PhyInterface.h"

//#define DUMP 1
#define UNDERRUN 1
#define ETHERNET_BUFFER_BASE_PHYSICAL 0x20059000

extern void OEMWriteDebugString(WCHAR*);

#define INC_MODULO(x,y) (x) < (y-1) ? (x+1) : 0

#define MIN(x,y) ((x)<(y)?(x):(y))

typedef struct {
	DWORD addr;
	DWORD ctrl;
} dma_desc;


	#define RX_BUFFER_SIZE	        128		/* 128 rounded up */
	#define RX_RING_SIZE	        240		/* max number of receive buffers */
	#define RX_RING_BYTES           (RX_RING_SIZE * sizeof(dma_desc))
	//#define RX_DMA_SIZE             RX_RING_BYTES + RX_RING_SIZE * RX_BUFFER_SIZE
	
	#define TX_BUFFER_SIZE	        1536	        /* 1536 rounded up */
	#define TX_RING_SIZE	        16		/* max number of transmit descriptors*/
	#define TX_RING_BYTES           (TX_RING_SIZE * sizeof(dma_desc))
	//#define TX_DMA_SIZE             TX_RING_BYTES + TX_RING_SIZE * TX_BUFFER_SIZE
	
	#define DEF_TX_RING_PENDING	(TX_RING_SIZE - 1)
	
	
	#define RXADDR_USED		0x00000001
	#define RXADDR_WRAP		0x00000002
	
	#define RXBUF_FRMLEN_MASK	0x00000fff
	#define RXBUF_OFFSET_BYTES_MASK	0x00003000
	#define RXBUF_FRAME_START	0x00004000
	#define RXBUF_FRAME_END		0x00008000
	#define RXBUF_TYPEID_MATCH	0x00400000
	#define RXBUF_ADDR4_MATCH	0x00800000
	#define RXBUF_ADDR3_MATCH	0x01000000
	#define RXBUF_ADDR2_MATCH	0x02000000
	#define RXBUF_ADDR1_MATCH	0x04000000
	#define RXBUF_BROADCAST		0x80000000
	
	#define TXBUF_FRMLEN_MASK	0x000007ff
	#define TXBUF_FRAME_END		0x00008000
	#define TXBUF_NOCRC		0x00010000
	#define TXBUF_EXHAUSTED		0x08000000
	#define TXBUF_UNDERRUN		0x10000000
	#define TXBUF_MAXRETRY		0x20000000
	#define TXBUF_WRAP		0x40000000
	#define TXBUF_USED		0x80000000
	
	
	
	#define AT91C_MAN_CODE          (2 << 16)
	#define AT91C_MAN_READ          (2 << 28)
	#define AT91C_MAN_WRITE         (1 << 28)
	#define AT91C_MAN_SOF           (1 << 30)






typedef DWORD dma_addr_t;

typedef struct {
	
	
	unsigned int                     tx_head, tx_tail;
	volatile dma_desc				 *tx_ring;	
	dma_addr_t						 tx_ring_dma;
	void                             *tx_buffers;
	dma_addr_t		                 tx_buffers_dma;    // this is needed when using TCM memory as a
												// frame buffer
	unsigned int                     rx_tail;
	volatile dma_desc				 *rx_ring;
	dma_addr_t						 rx_ring_dma;
	void                             *rx_buffers;
	dma_addr_t						 rx_buffers_dma;
	
} macb_priv;

AT91PS_EMAC g_pEmac;
macb_priv g_MacPriv;

#define DUMP_NSR	1
#define DUMP_ISR	2
#define DUMP_RSR	4
#define DUMP_TSR	8

void dumpEmacStatus(AT91PS_EMAC pEmac, DWORD dwMask)
{
	DWORD dwStatus;
	
	if (dwMask & DUMP_NSR)
	{
		dwStatus = pEmac->EMAC_NSR;
		if (dwStatus)
		{
			EdbgOutputDebugString( "nsr 0x%x\r\n",dwStatus);
		}
	}
	
	if (dwMask & DUMP_ISR)
	{
		dwStatus = pEmac->EMAC_ISR;
		if (dwStatus)
		{
			EdbgOutputDebugString( "isr 0x%x\r\n",dwStatus);
		}
	}
	
	if (dwMask & DUMP_TSR)
	{
		dwStatus = pEmac->EMAC_TSR;
		if (dwStatus)
		{
			EdbgOutputDebugString( "tsr 0x%x\r\n",dwStatus);
		}
	}
	
	if (dwMask & DUMP_RSR)
	{
		dwStatus = pEmac->EMAC_RSR;
		if (dwStatus)
		{
			EdbgOutputDebugString( "rsr 0x%x\r\n",dwStatus);
		}
	}
}



static void at91_macb_init_dma(macb_priv *priv)
{
        int index;
        dma_addr_t addr;

	//RETAILMSG(1,(TEXT("->at91_macb_init_dma %x\r\n"),priv));


	//RETAILMSG(1,(TEXT("at91_macb_init_dma %x\r\n"),priv->tx_ring));

	addr = priv->rx_buffers_dma;
	for (index = 0; index < RX_RING_SIZE; index++) {
	  priv->rx_ring[index].addr = addr;
	  priv->rx_ring[index].ctrl = 0;
	  
	  addr += RX_BUFFER_SIZE;
	}

	priv->rx_ring[RX_RING_SIZE -1].addr |= RXADDR_WRAP;

	
	//RETAILMSG(1,(TEXT("at91_macb_init_dma %x\r\n"),priv->tx_ring));
	addr = priv->tx_buffers_dma;
	for (index = 0; index < TX_RING_SIZE; index++) {
	  priv->tx_ring[index].addr = addr;
	  priv->tx_ring[index].ctrl = TXBUF_USED;

	  addr += TX_BUFFER_SIZE;
	}

	priv->tx_ring[TX_RING_SIZE -1].ctrl |= TXBUF_WRAP;

	priv->rx_tail = priv->tx_tail = priv->tx_head = 0;

	//RETAILMSG(1,(TEXT("<-at91_macb_init_dma \r\n")));
}



static int at91_macb_alloc_sdram(macb_priv *priv)
{
	int size;
	
	//RETAILMSG(1,(TEXT("->at91_macb_alloc_sdram %x\r\n"),priv));

	size = RX_RING_BYTES;
	priv->rx_ring_dma = ETHERNET_BUFFER_BASE_PHYSICAL;
	priv->rx_ring = OALPAtoVA(priv->rx_ring_dma, FALSE);
	
	size = TX_RING_BYTES;
	priv->tx_ring_dma = priv->rx_ring_dma + RX_RING_BYTES;
	priv->tx_ring = OALPAtoVA(priv->tx_ring_dma, FALSE);
	
	size = RX_RING_SIZE * RX_BUFFER_SIZE;
	priv->rx_buffers_dma = priv->tx_ring_dma + TX_RING_BYTES;
	priv->rx_buffers = OALPAtoVA(priv->rx_buffers_dma, FALSE);
	
	size = TX_RING_SIZE * TX_BUFFER_SIZE;
	priv->tx_buffers_dma = priv->rx_buffers_dma + (RX_RING_SIZE * RX_BUFFER_SIZE);
	priv->tx_buffers = OALPAtoVA(priv->tx_buffers_dma, FALSE);
	

	//RETAILMSG(1,(TEXT("<-at91_macb_alloc_sdram\r\n ")));

	return 0;
}


#define NEXT_TX(n)		(((n) + 1) > (TX_RING_SIZE - 1) ? 0 : (n)+1)

#define NEXT_RX(n)		(((n) + 1) > (RX_RING_SIZE - 1) ? 0 : (n)+1)



// Mark DMA descriptors from begin up to and not including end as unused
static void at91_discard_frame(macb_priv *priv, unsigned int begin, 
			       unsigned int end)
{
        unsigned int frag;

	EdbgOutputDebugString( "discard frame %d %d\r\n",begin,end);
	for (frag = begin; frag != end; frag = NEXT_RX(frag))
	{
	  priv->rx_ring[frag].addr &= ~RXADDR_USED;	
	}
}


void ResetRxBuffers(macb_priv *priv)
{
	int index;
    dma_addr_t addr;


	EdbgOutputDebugString( "Reset RX bufferrs\r\n");

	g_pEmac->EMAC_NCR = g_pEmac->EMAC_NCR & ~(AT91C_EMAC_RE);
	g_pEmac->EMAC_RSR = 0xFFFFFFFF;
	

	addr = priv->rx_buffers_dma;
	for (index = 0; index < RX_RING_SIZE; index++) {
	  priv->rx_ring[index].addr = addr;
	  priv->rx_ring[index].ctrl = 0;
	  
	  addr += RX_BUFFER_SIZE;
	}

	priv->rx_ring[RX_RING_SIZE -1].addr |= RXADDR_WRAP;

	priv->rx_tail = 0;
	g_pEmac->EMAC_RBQP = priv->rx_ring_dma;

	g_pEmac->EMAC_NCR = g_pEmac->EMAC_NCR | AT91C_EMAC_RE;

}


static int at91_macb_rx_frame(macb_priv *priv, unsigned int begin, 
			      unsigned int end, char* pData, UINT16 *pLength)
{
    unsigned int len, frag, rx_len = 0;
	//DWORD offset_bytes;


    len = priv->rx_ring[end].ctrl & RXBUF_FRMLEN_MASK;
	/*
	offset_bytes = priv->rx_ring[end].ctrl & RXBUF_OFFSET_BYTES_MASK;
	offset_bytes >>= 12;
	
	len += offset_bytes;
	*/
	{
		DWORD dwNbFrag;
		if (end<begin)
		{
			dwNbFrag = end + RX_RING_SIZE - begin;
		}
		else
		{
			dwNbFrag = end - begin;
		}
		if (len == 0)
		{
			if (dwNbFrag)
			{
				EdbgOutputDebugString("(len / 128) != dwNbFrag !!!!!!!!!!!!!!!!!!! %d -> %d vs %d\r\n",begin,end,len);
			}
		}
		else
		{
			if (((len-1) / 128) != dwNbFrag)
			{
				EdbgOutputDebugString("(len / 128) != dwNbFrag !!!!!!!!!!!!!!!!!!! %d -> %d vs %d\r\n",begin,end,len);
			}
		}
	}

	for (frag = begin; ; frag = NEXT_RX(frag)) 
	{
	  unsigned int frag_len = RX_BUFFER_SIZE;

	  if (rx_len + frag_len > len) {
	    //BUG_ON(frag != end);		
	    frag_len = len - rx_len;
	  }
	  if (rx_len + frag_len > *pLength)
	  {
		  frag_len = *pLength - rx_len;
		  OEMWriteDebugByte('Z');
	  }

	  memcpy(pData + rx_len, (char*) priv->rx_buffers + (RX_BUFFER_SIZE * frag), frag_len);
	  rx_len += RX_BUFFER_SIZE;
	  priv->rx_ring[frag].addr &= ~RXADDR_USED;
	  
	  if (frag == end)
	    break;
	}

	*pLength = len;
	return 0;
}




static int at91_macb_rx(macb_priv *priv, int budget, char* pData, UINT16 *pLength,BOOL bForceRX)
{
    unsigned int tail = priv->rx_tail;
	unsigned int previous = tail;
	int received = 0, first_frag = -1;
	UINT16 wLength;
	BOOL berrorBNA = FALSE;

	
	wLength = *pLength;
	*pLength = 0;
    
	if (g_pEmac->EMAC_RSR & AT91C_EMAC_OVR)
	{
		g_pEmac->EMAC_RSR = AT91C_EMAC_OVR;
//		EdbgOutputDebugString("receive overrun\r\n");
	}

	if (g_pEmac->EMAC_RSR & AT91C_EMAC_BNA)
	{
		berrorBNA = TRUE;
		g_pEmac->EMAC_RSR = AT91C_EMAC_BNA;
		EdbgOutputDebugString("error BNA\r\n");
	}

	if (g_pEmac->EMAC_RSR & AT91C_EMAC_REC)
	{
		g_pEmac->EMAC_RSR = AT91C_EMAC_REC;
	}
	else if (!bForceRX)
	{		
		//EdbgOutputDebugString("no REC + bForceRX == FALSE");
		/*
		*pLength = 0;
		return 0;
		*/
	}

	for(; budget > 0; tail = NEXT_RX(tail)) 
	{
	  DWORD addr, ctrl;	  
	  
	  addr = priv->rx_ring[tail].addr;
	  ctrl = priv->rx_ring[tail].ctrl;

	  /*
	  dev_dbg(&priv->pdev->dev, "rx frag %u: %08lx, %08lx\n",
		  tail, addr, ctrl);
	  */

	  // No new packets were received since last check
	  if (!(addr & RXADDR_USED))
	  {
	//		EdbgOutputDebugString("!(addr & RXADDR_USED)\r\n");
	    break;
	  }

	  //printk(KERN_DEBUG "%s : at91_macb_rx : %d\n\r", priv->ndev->name, 1);

	  if (ctrl & RXBUF_FRAME_START) {
	    //printk(KERN_DEBUG "%s : at91_macb_rx : %d\n\r", priv->ndev->name, 2);
		 //EdbgOutputDebugString( "ctrl & RXBUF_FRAME_START %d\r\n",tail);
	    if (first_frag != -1)
		{
			EdbgOutputDebugString("first_frag != -1)\r\n");
	      at91_discard_frame(priv, first_frag, previous);
		}
	    first_frag = tail;
	  }

	  
	  if (ctrl & RXBUF_FRAME_END) {
	    int dropped;
	    //EdbgOutputDebugString( "ctrl & RXBUF_FRAME_END %d\r\n",tail);
	    if (first_frag == -1)
		{
			EdbgOutputDebugString( "RXBUF_FRAME_END and first_frag == -1\r\n");
		}
	    else
		{//printk(KERN_DEBUG "%s : at91_macb_rx : %d\n\r", priv->ndev->name, 3);
			dropped = at91_macb_rx_frame(priv, first_frag, tail,pData,&wLength);
			*pLength = wLength;
		}
	    first_frag = -1;
	    if (!dropped) {
	      received++;
	      budget--;
	    }
	  }
	  previous = tail;
	}

	if (first_frag != -1)
	  priv->rx_tail = first_frag;
	else 
	  priv->rx_tail = tail;

	if ((received == 0) && (berrorBNA))
	{
		ResetRxBuffers(priv);
	}
	return received;
}


#define TX_RING_GAP(priv)						\
	(TX_RING_SIZE - DEF_TX_RING_PENDING)

#define TX_BUFFS_AVAIL(priv)					\
	(((priv)->tx_tail <= (priv)->tx_head) ?			\
	 (priv)->tx_tail + DEF_TX_RING_PENDING - (priv)->tx_head :	\
	 (priv)->tx_tail - (priv)->tx_head - TX_RING_GAP(priv))

static int at91_macb_start_xmit(macb_priv *priv,char* pData, DWORD dwLength)				
{     
	unsigned int entry;
//	dma_addr_t mapping;
	DWORD ctrl;

	// Check if there is room in the tx ring
	if (TX_BUFFS_AVAIL(priv) < 1) {
		dumpEmacStatus(g_pEmac,DUMP_TSR);
		EdbgOutputDebugString("at91_macb_start_xmit no buf avail\r\n",TX_BUFFS_AVAIL(priv));
		return 1;
	}
	
	entry = priv->tx_head;


	//EdbgOutputDebugString("at91_macb_start_xmit entry = %d\r\n",entry);



//	mapping = priv->tx_ring[entry].addr;

	// Copy skb data in TCM buffer
	memcpy((char *)priv->tx_buffers + entry * TX_BUFFER_SIZE,
	       pData, dwLength);

	ctrl = (dwLength & TXBUF_FRMLEN_MASK);
	ctrl |= TXBUF_FRAME_END;
	if (entry == (TX_RING_SIZE - 1))
	  ctrl |= TXBUF_WRAP;
	
	priv->tx_ring[entry].ctrl = ctrl;

	entry = NEXT_TX(entry);
	priv->tx_head = entry;
	
	g_pEmac->EMAC_NCR |= AT91C_EMAC_TSTART;

	return 0;
}




char OurEmacAddr[6] = {0x02, 0x02, 0x03, 0x04, 0x05, 0x10};

#define AT91C_PHY_ADDR	0


#define AT91C_EMAC_PHY_SOF (0x01 << 30)
#define AT91C_EMAC_PHY_CODE (0x02 << 16)
#define AT91C_EMAC_PHY_BASE_WORD (AT91C_EMAC_PHY_SOF | AT91C_EMAC_PHY_CODE)

#define AT91C_EMAC_READ_PHY (0x02 << 28)
#define AT91C_EMAC_WRITE_PHY (0x01 << 28)
/*
 * Read value stored in a PHY register.
 * Note: MDI interface is assumed to already have been enabled.
 */
void read_phy(AT91PS_EMAC pEmac, unsigned char phy_addr, unsigned char address, DWORD *dwValue)
{
	pEmac->EMAC_MAN = AT91C_EMAC_PHY_BASE_WORD | AT91C_EMAC_READ_PHY | ((phy_addr & 0x1f) << 23) | (address << 18);

	/* Wait until IDLE bit in Network Status register is cleared */
	while (!(pEmac->EMAC_NSR & AT91C_EMAC_IDLE));
	*dwValue = (pEmac->EMAC_MAN & AT91C_EMAC_DATA);	
}
/*
 * Write value stored in a PHY register.
 * Note: MDI interface is assumed to already have been enabled.
 */
void write_phy(AT91PS_EMAC pEmac, unsigned char phy_addr, unsigned char address, DWORD dwValue)
{
	pEmac->EMAC_MAN = AT91C_EMAC_PHY_BASE_WORD | AT91C_EMAC_WRITE_PHY | ((phy_addr & 0x1f) << 23) | (address << 18) | (dwValue & 0xFFFF);

	/* Wait until IDLE bit in Network Status register is cleared */
	while (!(pEmac->EMAC_NSR & AT91C_EMAC_IDLE));	
}

void AT91F_Enable_Mdi(AT91PS_EMAC pEmac)
{
	pEmac->EMAC_NCR |= AT91C_EMAC_MPE;	/* enable management port */
}

/*
 * Disable the MDIO bit in the MAC control register
 */
void AT91F_Disable_Mdi(AT91PS_EMAC pEmac)
{
	pEmac->EMAC_NCR &= ~AT91C_EMAC_MPE;	/* disable management port */
}

//------------------------------------------------------------------------------
// Iplementation for EMAC NIC functions

void EmacSetMAcAddress(UCHAR * pMacAddress)
{
	AT91PS_PMC ppmc = (AT91PS_PMC) OALPAtoVA((DWORD)AT91C_BASE_PMC, FALSE);

	AT91PS_EMAC pEmac = (AT91PS_EMAC)OALPAtoVA((DWORD)AT91C_BASE_MACB, FALSE);
	// Enable Peripheral clock in PMC for  EMAC		
	ppmc->PMC_PCER = ((unsigned int) 1 << AT91C_ID_EMAC);
		
	memcpy(OurEmacAddr,pMacAddress,sizeof(OurEmacAddr));
	// the sequence write EMAC_SA1L and write EMAC_SA1H must be respected
	pEmac->EMAC_SA1L = ((int)OurEmacAddr[3] << 24) | ((int)OurEmacAddr[2] << 16) | ((int)OurEmacAddr[1] << 8) | OurEmacAddr[0];
	pEmac->EMAC_SA1H = ((int)OurEmacAddr[5] << 8) | OurEmacAddr[4];

	RETAILMSG(1,(TEXT("pEmac->EMAC_SA1L=  %x\n\r"), pEmac->EMAC_SA1L));
	RETAILMSG(1,(TEXT("pEmac->EMAC_SA1H= %x \n\r"), pEmac->EMAC_SA1H));

}



extern T_PHY_INTERFACE DM9161A_PhyInterface;

//*----------------------------------------------------------------------------
//* \fn    AT91F_EMACInit
//* \brief This function initialise the ethernet
//*----------------------------------------------------------------------------
int AT91F_EMACInit( // \return Status ( Success = 0)
		AT91PS_EMAC pEmac,     // \arg Pointer to AT91PS_EMAC service
		unsigned int pRxTdList,
		unsigned int pTxTdList)
{

	DWORD mac_cfg;
	T_MAC_INFO			macInfo;
	T_PHY_CONFIGURATION PhyCfg;
	T_PHY_INTERFACE		*pPhyInterface;
	UCHAR ucPhyAddr;	
	T_PHY_INTERFACE *PhyList[] = 
	{
		&DM9161A_PhyInterface,
	};

	//AT91PS_MATRIX pMatrix = (AT91PS_MATRIX) OALPAtoVA((DWORD)AT91C_BASE_MATRIX, FALSE);
	AT91PS_PMC ppmc = (AT91PS_PMC) OALPAtoVA((DWORD)AT91C_BASE_PMC, FALSE);
	AT91PS_PIO pPIOC = (AT91PS_PIO) OALPAtoVA((DWORD)AT91C_BASE_PIOC, FALSE);
	AT91PS_PIO pPIOE = (AT91PS_PIO) OALPAtoVA((DWORD)AT91C_BASE_PIOE, FALSE);


	
	/*
	pMatrix->MATRIX_SCFG0 = 0x01000008;
	pMatrix->MATRIX_PRAS0 |= 0x30000000;
	pMatrix->MATRIX_PRBS0 = 0x00000000;
*/

	macInfo.read_phy = read_phy;
	macInfo.write_phy = write_phy;
	macInfo.pDeviceLocation = pEmac;


	RETAILMSG(1,(TEXT("->Enter in AT91F_EMACInit \n\r")));

	
	// Enable Peripheral clock in PMC for  EMAC		
	ppmc->PMC_PCER = ((unsigned int) 1 << AT91C_ID_EMAC);

	// Configure PIO E to periph A mode
	pPIOE->PIO_ASR =	AT91C_PE28_E_TXEN | AT91C_PE26_E_RX1 | AT91C_PE31_E_F100 | AT91C_PE24_E_TX1 |
						AT91C_PE29_E_MDC | AT91C_PE27_E_RXER | AT91C_PE23_E_TX0 | AT91C_PE25_E_RX0 |
						AT91C_PE22_E_CRS | AT91C_PE21_E_TXCK | AT91C_PE30_E_MDIO;
	// Disable used PIO from PIO E
	pPIOE->PIO_PDR = 	AT91C_PE28_E_TXEN | AT91C_PE26_E_RX1 | AT91C_PE31_E_F100 | AT91C_PE24_E_TX1 |
						AT91C_PE29_E_MDC | AT91C_PE27_E_RXER | AT91C_PE23_E_TX0 | AT91C_PE25_E_RX0 |
						AT91C_PE22_E_CRS | AT91C_PE21_E_TXCK | AT91C_PE30_E_MDIO;


	// Configure PIO C to periph B mode
	pPIOC->PIO_BSR = AT91C_PC25_E_RXDV;
	// Disable used PIO from PIO A
	pPIOC->PIO_PDR = AT91C_PC25_E_RXDV;


	pEmac->EMAC_IDR = 0xFFFFFFFF;

	pEmac->EMAC_NCFGR  |= (AT91C_EMAC_CLK); //Set the lowest speed for the MDIO communication

	/* Read the PHY ID registers */
	AT91F_Enable_Mdi(pEmac);
	
/*
	if (AT91F_Ether_Probe(pEmac))
		return -1;
*/
	pPhyInterface = FindPhy(&macInfo,PhyList,sizeof(PhyList)/sizeof(PhyList[0]),&ucPhyAddr);
	if (pPhyInterface == NULL)
	{
		RETAILMSG(1,(TEXT("No Phy Found\r\n")));
		return -1;
	}
	RETAILMSG(1,(TEXT("Found Phy (%s) at address %d\r\n"),pPhyInterface->wzName,ucPhyAddr));

	//pPhyInterface->PHY_Reset(&macInfo,ucPhyAddr);
#define GET_LINK_SPEED_TIMEOUT 10000
	
#ifdef IS_MISTRAL
	PhyCfg.bFullDuplex = FALSE;
	PhyCfg.bAutoNegociation = FALSE;
	PhyCfg.dwSpeed = SPEED_10;
	pPhyInterface->PHY_SetConfiguration(&macInfo,ucPhyAddr,&PhyCfg);
#else
	PhyCfg.bAutoNegociation = FALSE;
	if(pPhyInterface->PHY_GetConfiguration(&macInfo,ucPhyAddr,&PhyCfg) == FALSE)
	{
		if (PhyCfg.bAutoNegociation == TRUE) 
		{
			// Autonegociation is started but not complete yet
		}
		else
		{	 // Autonegocitaion is not selected
			RETAILMSG(1,(TEXT("EMAC: Starting Autonegociation\r\n")));
			pPhyInterface->PHY_StartAutoNegociation(&macInfo,ucPhyAddr);
		}
		if (pPhyInterface->PHY_WaitForAutonegociationComplete(&macInfo,ucPhyAddr,GET_LINK_SPEED_TIMEOUT) == FALSE)
		{
			RETAILMSG(1,(TEXT("Autonegociation failed\r\n")));
			return -1;
		}
	}
	
#endif

	if (pPhyInterface->PHY_WaitForLink(&macInfo,ucPhyAddr,GET_LINK_SPEED_TIMEOUT) == FALSE)
	{
		RETAILMSG(1,(TEXT("No Link\r\n")));
		return -1;
	}
	
	if(pPhyInterface->PHY_GetConfiguration(&macInfo,ucPhyAddr,&PhyCfg) == FALSE)
	{
		RETAILMSG(1,(TEXT("Unable to get the network configuration from the PHY\r\n")));
		return -1;
	
	}




	
	RETAILMSG(1,(TEXT("\n\r EMAC Init : %d Mbit/s %s DUPLEX (%s)\r\n"), PhyCfg.dwSpeed,PhyCfg.bFullDuplex ? L"FULL" : L"HALF", PhyCfg.bRMII ? L"RMII" : L"MII"));


	/* Read the PHY ID registers */
	AT91F_Disable_Mdi(pEmac);
	
	
	// The descriptor list address is assigned to the Rx buffer
	pEmac->EMAC_RBQP = pRxTdList;
	// The descriptor list address is assigned to the Tx buffer
	pEmac->EMAC_TBQP = pTxTdList;


	pEmac->EMAC_NCR  = 0;
	/* Update the MAC with the new information */
	mac_cfg = pEmac->EMAC_NCFGR & ~(AT91C_EMAC_SPD | AT91C_EMAC_FD);
	
	if (PhyCfg.dwSpeed == SPEED_100) 
	{
		mac_cfg |= AT91C_EMAC_SPD;
	}
	else if (PhyCfg.dwSpeed == SPEED_10) 
	{
		//Nothing to do here
	}
	else
	{
		RETAILMSG(1,(TEXT("Invalid network speed\r\n")));
	}

	if (PhyCfg.bFullDuplex== TRUE)	
	{
		mac_cfg |= AT91C_EMAC_FD;
	}

	

	pEmac->EMAC_NCFGR = mac_cfg;
	pEmac->EMAC_RSR  = 0xFFFFFFFF;
	pEmac->EMAC_TSR  = 0xFFFFFFFF;
	pEmac->EMAC_NCR  |= AT91C_EMAC_CLRSTAT; // Clear the statistics
	pEmac->EMAC_USRIO  = (PhyCfg.bRMII ? AT91C_EMAC_RMII : 0) | AT91C_EMAC_CLKEN;
	pEmac->EMAC_NCR  |= (AT91C_EMAC_TE | AT91C_EMAC_RE);

	{ DWORD dummy = pEmac->EMAC_ISR;}
	pEmac->EMAC_IER = 0x0000080;
	{ DWORD dummy = pEmac->EMAC_ISR;}


 	return 0;
}

//*----------------------------------------------------------------------------
//* \fn    AT91F_EmacEntry
//* \brief Initialise Emac to receive packets
//*----------------------------------------------------------------------------
int AT91F_EmacEntry(AT91PS_EMAC p_mac)
{
	
	at91_macb_alloc_sdram(&g_MacPriv);
	at91_macb_init_dma(&g_MacPriv);
	
	return AT91F_EMACInit(p_mac, g_MacPriv.rx_ring_dma,g_MacPriv.tx_ring_dma);//(unsigned int) AT91C_EMAC_RX_TDLIST_BASE_PHYS, (unsigned int) AT91C_EMAC_TX_TDLIST_BASE_PHYS));
}



///////////////////////////////////////////////////////////////////////////
// 	EMACInit - Initialise Emac Ethernet controler
///////////////////////////////////////////////////////////////////////////
BOOL   EMACInit(UINT8 *pAddress, UINT32 offset, UINT16 mac[3])
{
	g_pEmac = (AT91PS_EMAC)OALPAtoVA((DWORD)AT91C_BASE_MACB, FALSE);
		
	RETAILMSG(1,(TEXT("Init Emac Ethernet controler \n\r")));

	RETAILMSG(1,(TEXT("Enter in AT91F_EmacEntry  base = 0x%x\n\r"),g_pEmac));
	RETAILMSG(1,(TEXT("EMACB revision 0x%x\n\r"),g_pEmac->EMAC_REV));
	if (AT91F_EmacEntry(g_pEmac) == 0)
	{

		if (NULL != mac) {
			mac[0] = g_pEmac->EMAC_SA1L & 0x0000FFFF;
			mac[1] = (g_pEmac->EMAC_SA1L & 0xFFFF0000) >> 16;
			mac[2] = g_pEmac->EMAC_SA1H & 0x0000FFFF;
			RETAILMSG(1,(TEXT("EDBG:AT91Init Reading MAC address 0x%X 0x%X 0x%X\r\n"),
				mac[0], mac[1], mac[2]));
		}
		return TRUE;

	}else
	{
		return FALSE;
	}

}


void ResetTxBuffers(macb_priv *priv)
{
	int index;
    dma_addr_t addr;

	g_pEmac->EMAC_NCR = g_pEmac->EMAC_NCR & ~(AT91C_EMAC_TE) | AT91C_EMAC_THALT;
	g_pEmac->EMAC_TSR = 0xFFFFFFFF;
	
	addr = priv->tx_buffers_dma;
	for (index = 0; index < TX_RING_SIZE; index++) {
	  priv->tx_ring[index].addr = addr;
	  priv->tx_ring[index].ctrl = TXBUF_USED;

	  addr += TX_BUFFER_SIZE;
	}

	priv->tx_ring[TX_RING_SIZE -1].ctrl |= TXBUF_WRAP;

	priv->tx_tail = priv->tx_head = 0;

	g_pEmac->EMAC_NCR = g_pEmac->EMAC_NCR | AT91C_EMAC_TE;

}



static int at91_macb_tx(macb_priv *priv, BOOL bForceTX,DWORD dwISRStatus)
{
        unsigned int head, tail;
        volatile DWORD status;


	status = g_pEmac->EMAC_TSR;

	/*
	dev_dbg(&priv->pdev->dev, "macb_tx status = %02lx\n",
		(unsigned long)status);
*/
	

	if (status & AT91C_EMAC_UND) 
	{
		EdbgOutputDebugString("TX underrun, resetting buffers, status = %x\r\n",status);
	  priv->tx_head = priv->tx_tail = 0;
	  g_pEmac->EMAC_TSR = AT91C_EMAC_UND;
	  ResetTxBuffers(priv);
	  return UNDERRUN;
	}

	if (!(status & AT91C_EMAC_COMP) && !bForceTX) {
		//EdbgOutputDebugString("No TX buffers complete, TSR = %x ISR = %x\r\n",status,dwISRStatus);		 	  
	  return 0;
	}
	
	g_pEmac->EMAC_TSR = AT91C_EMAC_COMP | 0xFFFFFFFF;

	head = priv->tx_head;
	for (tail = priv->tx_tail; tail != head; tail = NEXT_TX(tail)) {
	  
		DWORD ctrl;

	  ctrl = priv->tx_ring[tail].ctrl;

	  //EdbgOutputDebugString(" tx ! tail %d\r\n",tail);
	  // A buffer is not released by TX DMA, stop processing
	  if (!(ctrl & TXBUF_USED))
	  {
		  //EdbgOutputDebugString(" tx !(ctrl & TXBUF_USED)\r\n");
	    break;
	  }

	  
	/*
	dev_dbg(&priv->pdev->dev, "skb %u (data %p) TX complete\n",
		  tail, skb->data);
		  */

	  

	}

	priv->tx_tail = tail;
	//EdbgOutputDebugString("at91_macb_tx tail = %d\r\n",tail);
	return 0;
}

static void
DumpEtherFrame( BYTE *pFrame, WORD cwFrameLength )
{
    int i,j;

    EdbgOutputDebugString( "Frame Buffer Address: 0x%X\r\n", pFrame );
    EdbgOutputDebugString( "To: %B:%B:%B:%B:%B:%B  From: %B:%B:%B:%B:%B:%B  Type: 0x%H  Length: %u\r\n",
        pFrame[0], pFrame[1], pFrame[2], pFrame[3], pFrame[4], pFrame[5],
        pFrame[6], pFrame[7], pFrame[8], pFrame[9], pFrame[10], pFrame[11],
        ntohs(*((UINT16 *)(pFrame + 12))), cwFrameLength );

    for( i = 0; i < cwFrameLength / 16; i++ ) {
        for( j = 0; j < 16; j++ )
            EdbgOutputDebugString( " %B", pFrame[i*16 + j] );
        EdbgOutputDebugString( "\r\n" );
    }
    for( j = 0; j < cwFrameLength % 16; j++ )
        EdbgOutputDebugString( " %B", pFrame[i*16 + j] );
    EdbgOutputDebugString( "\r\n" );
}


#define AT91C_EMAC_TX_FLAGS  (AT91C_EMAC_TUNDR | AT91C_EMAC_TCOMP | AT91C_EMAC_TXERR | AT91C_EMAC_TXUBR)
#define AT91C_EMAC_RX_FLAGS  (AT91C_EMAC_RCOMP | AT91C_EMAC_ROVR | AT91C_EMAC_RXUBR)

UINT16 EMACSendFrame(UINT8 *pBuffer, UINT32 length) 
{
	DWORD dwTimeout;
	BOOL bLoop = FALSE;
	DWORD dwStatus;
	BOOL bError = FALSE;
	BOOL bForceTX = FALSE;
//	EdbgOutputDebugString( "s");
	//dumpEmacStatus(g_pEmac);
	
	do
	{
		if (bForceTX)
		{
			EdbgOutputDebugString( "bForceTX\r\n");
		}
		if (at91_macb_start_xmit(&g_MacPriv,pBuffer,length))
		{
			EdbgOutputDebugString( "at91_macb_start_xmit failed\r\n");
			return -1;
		}
		
		dwTimeout = 1000;
		dwStatus = g_pEmac->EMAC_ISR;
		while (((dwStatus & AT91C_EMAC_TX_FLAGS)==0) && (dwTimeout))
		{
			dwStatus = g_pEmac->EMAC_ISR;
			dwTimeout--;
		}
		
		if (dwTimeout == 0)
		{
			EdbgOutputDebugString( "tx timeout");
			return -1;
		}
		
		if (at91_macb_tx(&g_MacPriv,bForceTX,dwStatus) == UNDERRUN)
		{
			bForceTX = TRUE;
			bError = TRUE;
			bLoop = TRUE;
		}
		else
		{
			bLoop = FALSE;
		}

		g_pEmac->EMAC_TSR = 0xFFFFFFFF;//AT91C_EMAC_TX_FLAGS;
		dwStatus = g_pEmac->EMAC_ISR;

	} while (bLoop);
	
	
	
	if (bError)
	{
		EdbgOutputDebugString( "Sent Frame error\r\n");
	}
	{
#ifdef DUMP
		Edb gOutputDebugString( "Sent Frame\r\n");
		DumpEtherFrame(pBuffer,length);
#endif
		//dumpEmacStatus(g_pEmac,0xFF);
	}
	return 0;	
}


UINT16 EMACGetFrame(UINT8 *pBuffer, UINT16 *pLength) 
{
	DWORD dwStatus;
	BOOL bForceRX = FALSE;

//	EdbgOutputDebugString( "g");
	/*
	EdbgOutputDebugString( ".");
	*/
	//dumpEmacStatus(g_pEmac,DUMP_RSR | DUMP_ISR);
	
	//EdbgOutputDebugString( "\r\n!0x%x!\r\n",*((DWORD*)0xA0000000));
	

	dwStatus = g_pEmac->EMAC_ISR;
	if (dwStatus)
	{
		//EdbgOutputDebugString( "isr 0x%x\r\n",dwStatus);
		if (dwStatus & 0x2)
		{
			bForceRX = TRUE;
		}
	}
	

	if (at91_macb_rx(&g_MacPriv, 1, pBuffer, pLength,bForceRX))
	{
#ifdef DUMP
		EdbgOutputDebugString( "Received Frame\r\n");
		DumpEtherFrame(pBuffer,*pLength);
#endif
		//g_pEmac->EMAC_RSR = 0xFFFFFFFF;
		return *pLength;
	}
	else
	{
//		EdbgOutputDebugString( "Received Frame error\r\n");
		g_pEmac->EMAC_RSR = 0xFFFFFFFF;
		return 0;
	}
}


VOID   EMACEnableInts() 
{
	//DWORD dwIrq = AT91C_ID_EMAC;
	EdbgOutputDebugString( "Emac enable int\r\n");
	g_pEmac->EMAC_IER = AT91C_EMAC_RCOMP  | AT91C_EMAC_RXUBR  | AT91C_EMAC_TXUBR  | AT91C_EMAC_TUNDR  | AT91C_EMAC_RLEX   | AT91C_EMAC_TXERR  | AT91C_EMAC_TCOMP  | AT91C_EMAC_ROVR   | AT91C_EMAC_HRESP;
	//OALIntrEnableIrqs(1, &dwIrq);

}
VOID   EMACDisableInts() 
{	
	//DWORD dwIrq = AT91C_ID_EMAC;
	g_pEmac->EMAC_IDR = 0xFFFFFFFF;
	//OALIntrDisableIrqs(1, &dwIrq);
	EdbgOutputDebugString( "Emac disable int\r\n");
	
}

VOID   EMACCurrentPacketFilter(UINT32 filter) {}
BOOL   EMACMulticastList(UINT8 *pAddresses, UINT32 count) {return TRUE;}






//! @}
//! @}

//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/Emacb/Emac.c $
//-----------------------------------------------------------------------------
//