//-----------------------------------------------------------------------------
//! \addtogroup	MISC
//! @{
//
//  All rights reserved ADENEO SAS 2005
//! \file		at91sam9261_gpio.c
//!
//! \brief		Header description
//!
//-----------------------------------------------------------------------------
//!
//! \if subversion
///   @URL: $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9261/MISC/GPIO/at91sam9261_gpio.c $
//!   @author $Author: edaniel $
//!   @version $Revision: 750 $
//!   @date $Date: 2007-04-18 17:10:56 +0200 (mer., 18 avr. 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	GPIO
//! @{

//------------------------------------------------------------------------------
//                                                                      Includes
//------------------------------------------------------------------------------
// Standard includes
#include <windows.h>

// Project includes
#include "at91sam9261.h"
#include "at91sam9261_gpio.h"

DWORD g_dwOalPioBankNumber= NB_PIO_BANK; 

T_PIO_BANK_DESCRIPTION g_PioBankDescTab[NB_PIO_BANK]={
	{AT91C_BASE_PIOA,32,0,0,0,AT91C_ID_PIOA,0,0},
	{AT91C_BASE_PIOB,32,0,0,0,AT91C_ID_PIOB,0,0},		
	{AT91C_BASE_PIOC,32,0,0,0,AT91C_ID_PIOC,0,0}, 		
};

extern BOOL InitPioTable(void);
extern void DeinitPioTable(void);

//-----------------------------------------------------------------------------
//! \fn			BOOL WINAPI DllMain(HANDLE hInstance, ULONG dwReason, LPVOID lpReserved)
//!
//! \brief		This function is the entry point of the Dll driver
//!
//! \param		hInstance			handle Instance
//! \param		dwReason			Reason of the call
//! \param		lpReserved		Not used
//!
//! \return		\e TRUE indicates success
//! \return		\e FALSE indicates failure
//!
//-----------------------------------------------------------------------------
BOOL WINAPI DllMain(HANDLE hInstance, ULONG dwReason, LPVOID lpReserved)
{
    BOOL bRet = TRUE;
	switch (dwReason)
    {
        case DLL_PROCESS_ATTACH:
          DisableThreadLibraryCalls ((HMODULE)hInstance);
		  if(InitPioTable() == FALSE)
		  {
			  DeinitPioTable();
			  bRet = FALSE;
			  
		  }
          break;

        case DLL_PROCESS_DETACH:
			DeinitPioTable();
        default:
            break;
    }

    return bRet;  
}



//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9261/MISC/GPIO/at91sam9261_gpio.c $
//------------------------------------------------------------------------------

//
//! @}
//
//! @}
