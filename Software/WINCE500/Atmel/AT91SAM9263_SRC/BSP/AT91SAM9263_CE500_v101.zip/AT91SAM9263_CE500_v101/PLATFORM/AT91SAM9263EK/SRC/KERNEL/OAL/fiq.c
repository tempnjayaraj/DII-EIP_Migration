//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		fiq.c
//!
//! \brief		This file implements the fast interrupt handler for the AT91SAM9263EK.
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/KERNEL/OAL/fiq.c $
//!   $Author: jjhiblot $
//!   $Revision: 68 $
//!   $Date: 2006-01-24 15:59:48 +0100 (mar., 24 janv. 2006) $
//! \endif
//-----------------------------------------------------------------------------


//! \addtogroup	INTR
//! @{

#include <windows.h>
#include <ceddk.h>
#include <nkintr.h>
#include "at91sam9263EK.h"
#include "oal_args.h"
#include "oal_kitl.h"
#include "drv_glob.h"
#include "AT91SAM926x.h"
#include "AT91SAM926x_interface.h"
#include "AT91SAM926x_oal_intr.h"
#include "AT91SAM926x_oal_watchdog.h"
#include "lib_AT91SAM926x.h"



//-----------------------------------------------------------------------------
//! \fn			  void OEMInterruptHandlerFIQ()
//!
//! \brief		This function is implemented by the OEM to provide fast interrupt 
//!       request (FIQ) support for the ARM microprocessor. 
//!
//!
//!
//!
//-----------------------------------------------------------------------------
void OEMInterruptHandlerFIQ()
{
	
}

//! @} end of subgroup INTR

//! @} end of group OAL

//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/KERNEL/OAL/fiq.c $
//-----------------------------------------------------------------------------
//