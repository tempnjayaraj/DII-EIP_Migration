//-----------------------------------------------------------------------------
//! \addtogroup   SDMMC
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				AT91RM9200_sdmmc.h
//!
//! \brief				This module contains the function prototypes and constant, type,
//!					global data and structure definitions for the Windows CE RAM disk driver
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/DRIVERS/Sdcard/AT91RM9200_sdmmc.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//! Based on ramdisk.h for Windows CE RAM disk driver from Microsoft
//! 
//-----------------------------------------------------------------------------

#include <CEDDK.h>

#include "AT91RM9200_MCI_Device.h"


#ifdef __cplusplus
extern "C" {
#endif


//globals
extern AT91PS_PIO g_pPioA;
extern AT91PS_PIO g_pPioB;
extern AT91PS_MCI g_pMCI;
extern AT91PS_PDC g_pPDC;
extern AT91PS_PMC g_pPMC;


//PDC

#define SIZE_OF_PDC_TX_BUFFER (2048)
#define SIZE_OF_PDC_RX_BUFFER (2048)

PVOID 				vDMACommonTxBuffer;
PHYSICAL_ADDRESS 	pDMACommonTxBuffer;
PVOID 				vDMACommonRxBuffer;
PHYSICAL_ADDRESS 	pDMACommonRxBuffer;
DMA_ADAPTER_OBJECT  dmaAdapterObject;

#define AT91C_MCI_TIMEOUT			1000000   /* For AT91F_MCIDeviceWaitReady */

#define	AT91C_MCI_SR_ERROR		(AT91C_MCI_UNRE |\
									 AT91C_MCI_OVRE |\
									 AT91C_MCI_DTOE |\
									 AT91C_MCI_DCRCE |\
									 AT91C_MCI_RTOE |\
									 AT91C_MCI_RENDE |\
									 AT91C_MCI_RCRCE |\
									 AT91C_MCI_RDIRE |\
									 AT91C_MCI_RINDE)
//
// Device states - To guard against races during trasitions to and from
// standby mode, a disk starts in the STATE_INITING state.  Upon entering
// standby mode, a disk goes into the STATE_DEAD state and can no longer
// be used.  Coming out of standby mode, the pcmcia system will force a card
// removal and this driver will get unloaded.  Between the time the device has
// left standby mode and the card removal notice gets generated, the disk 
// should not be used at all, since as the driver is unloading it unmaps the
// memory windows to pcmcia common memory space.
//
#define STATE_INITING 1
#define STATE_CLOSED  2
#define STATE_OPENED  3
#define STATE_DEAD    4    // Power down
#define STATE_REMOVED 5

#define DISK_DEAD_ERROR     ERROR_NOT_READY
#define DISK_REMOVED_ERROR  ERROR_BAD_UNIT

#define SDMAGICNUMBER		0xDD001133

typedef struct _DISK {
    struct _DISK * d_next;
    CRITICAL_SECTION d_DiskCardCrit;// guard access to global state and card
    DWORD d_DiskCardState;
    DISK_INFO d_DiskInfo;    // for DISK_IOCTL_GET/SETINFO
    DWORD d_OpenCount;    // open ref count
    LPWSTR d_ActivePath;    // registry path to active key for this device
    DWORD dwMagicNumber;
    AT91PS_MciDevice MciDevice;	//structure from ATMEL samples
    DWORD dwSysIntr;
    HANDLE hInterruptEvent;
} DISK, * PDISK; 


#define SD_BYTES_PER_SECTOR 512

//
// Global functions
//
BOOL InitDisk(PDISK pDisk);
DWORD DoDiskIO(PDISK pDisk, DWORD Opcode, PSG_REQ pSG);
DWORD GetDiskInfo(PDISK pDisk, PDISK_INFO pInfo);
DWORD SetDiskInfo(PDISK pDisk, PDISK_INFO pInfo);
DWORD GetDiskStateError(DWORD DiskState);
VOID DeinitDisk(PDISK pDisk);
BOOL GetFolderName(PDISK pDisk, LPWSTR pOutBuf, DWORD nOutBufSize, DWORD * pBytesReturned);
BOOL GetDeviceInfo(PDISK pDisk, PSTORAGEDEVICEINFO pInfo);
DWORD FormatDisk(PDISK pDisk, PDISK_INFO pInfo);
unsigned long ReadData(PDISK pDisk,PSG_REQ pSgr);
unsigned long WriteData(PDISK pDisk,PSG_REQ pSgr);
AT91S_MCIDeviceStatus AT91F_MCI_SDCard_Init (AT91PS_MciDevice pMCI_Device,PDISK pDisk);
AT91S_MCIDeviceStatus AT91F_MCI_MMC_Init (AT91PS_MciDevice pMCI_Device,	PDISK pDisk);
AT91S_MCIDeviceStatus AT91F_MCI_ReadBlock(AT91PS_MciDevice pMCI_Device, int src, unsigned int *dataBuffer, unsigned int sizeToRead,PDISK p);
AT91S_MCIDeviceStatus AT91F_MCI_WriteBlock(AT91PS_MciDevice pMCI_Device, int dest, unsigned int *dataBuffer, unsigned int sizeToWrite,PDISK p);
void AT91F_MCIDeviceWaitReady(AT91PS_MciDevice pMCI_Device,unsigned int timeout,PDISK pDisk);
void endianExchangeMemcpy(char * charDestBuffer, char* charSrcBuffer,  unsigned int length);
void AT91F_MCI_ConfigureController (
        AT91PS_MCI pMCI,  			 // \arg pointer to a MCI controller
        unsigned int DTOR_register,  // \arg Data Timeout Register to be programmed
        unsigned int MR_register,  	 // \arg Mode Register to be programmed
        unsigned int SDCR_register);  // \arg SDCard Register to be programmed

#ifdef DEBUG
//
// Debug zones
//
#define ZONE_ERROR      DEBUGZONE(0)
#define ZONE_WARNING    DEBUGZONE(1)
#define ZONE_FUNCTION   DEBUGZONE(2)
#define ZONE_INIT       DEBUGZONE(3)
#define ZONE_PCMCIA		DEBUGZONE(4)
#define ZONE_IO         DEBUGZONE(5)
#define ZONE_MISC       DEBUGZONE(6)

#endif  // DEBUG


#ifdef __cplusplus
}
#endif

//! @}
