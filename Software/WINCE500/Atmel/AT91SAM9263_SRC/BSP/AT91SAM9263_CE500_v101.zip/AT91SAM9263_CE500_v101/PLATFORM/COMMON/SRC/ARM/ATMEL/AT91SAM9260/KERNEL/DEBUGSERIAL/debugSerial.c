//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9260\KERNEL\DEBUGSERIAL\debugSerial.c
//!
//! \brief		AT91SAM9260 debug serial feature
//!
//-----------------------------------------------------------------------------

#include <windows.h>
#include <oal.h>
#include "AT91SAM926x.h"
#include "AT91SAM926x_interface.h"
#include "lib_AT91SAM926x.h"


#define DBGU_BAUDRATE	(115200)
//------------------------------------------------------------------------------
/// This function initializes the debug serial port of the AT91SAM9261
/// \return TRUE indicates success
/// \return FALSE indicates failure
BOOL OEMInitDebugSerial ()
{
	DWORD			dwMasterClock;
	AT91PS_PIO		pPIOB = OALPAtoVA((DWORD) AT91C_BASE_PIOB,FALSE);	

    if (g_pDBGU == NULL)
    {
        g_pDBGU = OALPAtoVA((DWORD) AT91C_BASE_DBGU,FALSE);
    }

	dwMasterClock = AT91SAM926x_GetMasterClock(FALSE);

   	// Open PIO for DBGU
	pPIOB->PIO_PDR = (AT91C_PB15_DTXD | AT91C_PB14_DRXD);
	pPIOB->PIO_ASR = (AT91C_PB15_DTXD | AT91C_PB14_DRXD);
	

	// Configure DBGU
	AT91F_US_Configure (
		(AT91PS_USART) g_pDBGU,          // DBGU base address
		dwMasterClock,             //
		AT91C_US_ASYNC_MODE,  // mode Register to be programmed
		DBGU_BAUDRATE,              // baudrate to be programmed
		0);                   // timeguard to be programmed

	// Enable Transmitter
	AT91F_US_EnableTx((AT91PS_USART) g_pDBGU);    
	// Enable Receiver
	AT91F_US_EnableRx((AT91PS_USART) g_pDBGU);	

	return TRUE;
}

//------------------------------------------------------------------------------

//! @}

