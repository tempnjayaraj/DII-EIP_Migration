//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!  
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		sdmmc.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/SDMEMORY/sdmmc.h $
//!   $Author: pblanchard $
//!   $Revision: 980 $
//!   $Date: 2007-06-11 07:26:34 -0700 (Mon, 11 Jun 2007) $
//! \endif
//!
//! Header for SD Memory Card driver. Based on ramdisk.h for Windows CE RAM disk driver from Microsoft
//-----------------------------------------------------------------------------
//! \addtogroup	SDMEMORY
//! @{
//!  


#ifndef __SDMMC_H__
#define __SDMMC_H__


#include "AT91C_MCI_Device.h"
#include <CEDDK.h>


#ifdef __cplusplus
extern "C" {
#endif


// Globals
/*
extern AT91PS_MCI g_pMCI_VirtualBase;
extern AT91PS_PDC g_pPDC_VirtualBase;
extern AT91PS_PMC g_pPMC_VirtualBase;
*/





#define SLOT_A	0
#define SLOT_B	1

#define SIZE_OF_PDC_TX_BUFFER (2048)
#define SIZE_OF_PDC_RX_BUFFER (2048)

#define MIN(X, Y)  ((X) < (Y) ? (X) : (Y))

#define AT91C_MCI_TIMEOUT			1000   /* For AT91F_MCIDeviceWaitReady */

#define	AT91C_MCI_SR_ERROR		(AT91C_MCI_UNRE |\
									 AT91C_MCI_OVRE |\
									 AT91C_MCI_DTOE |\
									 AT91C_MCI_DCRCE |\
									 AT91C_MCI_RTOE |\
									 AT91C_MCI_RENDE |\
									 AT91C_MCI_RCRCE |\
									 AT91C_MCI_RDIRE |\
									 AT91C_MCI_RINDE)
//
// Device states - To guard against races during trasitions to and from
// standby mode, a disk starts in the STATE_INITING state.  Upon entering
// standby mode, a disk goes into the STATE_DEAD state and can no longer
// be used.  Coming out of standby mode, the pcmcia system will force a card
// removal and this driver will get unloaded.  Between the time the device has
// left standby mode and the card removal notice gets generated, the disk 
// should not be used at all, since as the driver is unloading it unmaps the
// memory windows to pcmcia common memory space.
//
#define STATE_INITING 1
#define STATE_CLOSED  2
#define STATE_OPENED  3
#define STATE_DEAD    4    // Power down
#define STATE_REMOVED 5

#define DISK_DEAD_ERROR     ERROR_NOT_READY
#define DISK_REMOVED_ERROR  ERROR_BAD_UNIT

#define SDMAGICNUMBER		0xDD001133

/*! \struct DISK
	\brief Disk informations
*/
typedef struct _DISK {
    struct _DISK * d_next;
    CRITICAL_SECTION d_DiskCardCrit;//!<Guard access to global state and card
    DWORD d_DiskCardState;			//!<State of the SD Memory Card
    DISK_INFO d_DiskInfo;			//!<For DISK_IOCTL_GET/SETINFO
    DWORD d_OpenCount;				//!<Open ref count
    LPWSTR d_ActivePath;			//!<Registry path to active key for this device
    DWORD dwMagicNumber;			//!<Magic Number
    DWORD dwSysIntr;				//!<Sysintr of MCI device
    HANDLE hInterruptEvent;			//!<MCI interrupt event
	DWORD dwSlotNumber;				//!<MCI Slot ID
	CEDEVICE_POWER_STATE CurrentDx;	//!< Driver current power state

	AT91S_MciDevice MciDevice;		//!<Structure from ATMEL samples
    AT91S_MciDeviceFeatures	DeviceFeatures;
	AT91S_MciDeviceDesc		DeviceDesc;


	AT91PS_MCI	pMCI_VirtualBase; //!< Virtual base address of the MCI controller
	AT91PS_PDC	pPDC_VirtualBase; //!< Virtual base address of the MCI's PDC

	/// Virtual address of the transmit buffer
	///
	/// \note this buffer is allocated through HalAllocateCommBuffer because the PDC requires a physical address and the rest of the driver needs a virtual address
	PVOID 				vDMACommonTxBuffer;
	/// Physical address of the transmit buffer
	///
	/// \note this buffer is allocated through HalAllocateCommBuffer because the PDC requires a physical address and the rest of the driver needs a virtual address
	PHYSICAL_ADDRESS 	pDMACommonTxBuffer;
	/// Virtual address of the receive buffer
	///
	/// \note this buffer is allocated through HalAllocateCommBuffer because the PDC requires a physical address and the rest of the driver needs a virtual address
	PVOID 				vDMACommonRxBuffer;
	/// Physical address of the receive buffer
	///
	/// \note this buffer is allocated through HalAllocateCommBuffer because the PDC requires a physical address and the rest of the driver needs a virtual address
	PHYSICAL_ADDRESS 	pDMACommonRxBuffer;
	/// dummy object required by HalAllocateBuffer
	///
	/// \note this object is useless in this architecture because we don't handle bus address translation (no PCI on this board)
	DMA_ADAPTER_OBJECT  dmaAdapterObject;

} DISK, * PDISK; 


#define SD_BYTES_PER_SECTOR 512			// Octets

//
// Global functions
//
BOOL ConfigClockFromRegistry(LPCTSTR ActiveKey,AT91PS_MCI pMCI);
PDISK CreateDiskObject(void);
BOOL IsValidDisk(PDISK pDisk);
BOOL DSK_Close(DWORD Handle);
BOOL InitDisk(PDISK pDisk);
void DeinitDisk(PDISK pDisk);
DWORD DoDiskIO(PDISK pDisk, DWORD dwOpcode, PSG_REQ pSgr);
DWORD GetDiskInfo(PDISK pDisk, PDISK_INFO pInfo);
DWORD SetDiskInfo(PDISK pDisk, PDISK_INFO pInfo);
void ConfigPMC (PDISK pDisk,BOOL bState);
DWORD GetDiskStateError(DWORD DiskState);
BOOL GetFolderName(PDISK pDisk, LPWSTR FolderName, DWORD cBytes, DWORD * pcBytes);
BOOL GetDeviceInfo(PDISK pDisk, PSTORAGEDEVICEINFO pInfo);
DWORD FormatDisk(PDISK pDisk, PDISK_INFO pInfo);
unsigned long ReadData(PDISK pDisk,PSG_REQ pSG);
unsigned long WriteData(PDISK pDisk,PSG_REQ pSG);
AT91S_MCIDeviceStatus AT91F_MCI_SDCard_Init (AT91PS_MciDevice pMCI_Device,PDISK pDisk);
AT91S_MCIDeviceStatus AT91F_MCI_MMC_Init (AT91PS_MciDevice pMCI_Device,	PDISK pDisk);
AT91S_MCIDeviceStatus AT91F_MCI_ReadBlock(AT91PS_MciDevice pMCI_Device, int src, unsigned int *dataBuffer, unsigned int sizeToRead,PDISK pDisk);
AT91S_MCIDeviceStatus AT91F_MCI_WriteBlock(AT91PS_MciDevice pMCI_Device, int dest, unsigned int *dataBuffer, unsigned int sizeToWrite,PDISK pDisk);
void AT91F_MCIDeviceWaitReady(AT91PS_MciDevice pMCI_Device,unsigned int timeout,PDISK pDisk);
void AT91F_MCI_ConfigureController (
        AT91PS_MCI pMCI,  			 // Pointer to a MCI controller
        unsigned int DTOR_register,  // Data Timeout Register to be programmed
        unsigned int MR_register,  	 // Mode Register to be programmed
        unsigned int SDCR_register); // SDCard Register to be programmed


extern DWORD SDMemoryBoardSpecificGetSlotID(DWORD dwSlotNumber);
extern BOOL SDMemoryBoardSpecificIsWriteProtected(DWORD dwSlotNumber);
extern BOOL SDMemoryBoardSpecificPIOConfiguration(DWORD dwSlotNumber);
extern DWORD SDMemoryBoardSpecificGetMCIBase(DWORD dwSlotNumber);
extern DWORD SDMemoryBoardSpecificGetMCIID(DWORD dwSlotNumber);

extern BOOL SDMemoryBoardSpecificInit(DWORD dwSlotNumber);
extern BOOL SDMemoryBoardSpecificGetBus(DWORD dwSlotNumber);
extern void SDMemoryBoardSpecificDeInit(DWORD dwSlotNumber);
extern BOOL SDMemoryBoardSpecificReleaseBus(DWORD dwSlotNumber);

#ifdef DEBUG
//
// Debug zones
//
#define ZONE_ERROR      DEBUGZONE(0)
#define ZONE_WARNING    DEBUGZONE(1)
#define ZONE_FUNCTION   DEBUGZONE(2)
#define ZONE_INIT       DEBUGZONE(3)
#define ZONE_PCMCIA		DEBUGZONE(4)
#define ZONE_IO         DEBUGZONE(5)
#define ZONE_MISC       DEBUGZONE(6)

#endif  // DEBUG


#ifdef __cplusplus
}
#endif

#endif //__SDMMC_H__


//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/SDMEMORY/sdmmc.h $
//-----------------------------------------------------------------------------
//! @}
