//-----------------------------------------------------------------------------
//! \addtogroup	SDMemory
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		mci_device.c
//!
//! \brief		Common part of the SD Memory Card driver
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/SDMEMORY/mci_device.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//!
//! This driver initializes the MCI peripheral and allows read/write on an SD Card
//-----------------------------------------------------------------------------

// System include
#include <windows.h>
#include <diskio.h>
#include <storemgr.h>
#include <AT91C_MCI_Device.h>

// Local include
#include "sdmmc.h"


//-----------------------------------------------------------------------------
//! \fn			DWORD WaitForStatus(AT91PS_MciDevice pMCI_Device, DWORD dwTargetStatusMask, DWORD dwTimeout, PDISK pDisk)
//!
//! \brief		Wait that a given event occures (Wait on an interrupt event, not a busy wait)
//!
//! \param		pMCI_Device			pointer to the device. (Not used)
//! \param		dwTargetStatusMask	bitfield of the status we're waiting for
//! \param		dwTimeout			Timeout after which the request fails
//! \param		pDisk				pointer to the disk structure describing the device
//!
//! \return		Returns a Microsoft Error Code
//!
//! The OS invokes this function to suspend power to a device.
//-----------------------------------------------------------------------------
void WaitForStatus(AT91PS_MciDevice pMCI_Device, DWORD dwTargetStatusMask, DWORD dwTimeout, PDISK pDisk)
{
	volatile DWORD dwCurrentStatus;
	DWORD dwStartTime = GetTickCount();

	pDisk->pMCI_VirtualBase->MCI_IDR = 0xFFFFFFFF;

	while ((((dwCurrentStatus = pDisk->pMCI_VirtualBase->MCI_SR) & dwTargetStatusMask) != dwTargetStatusMask) 
				&& ((GetTickCount() - dwStartTime) < dwTimeout))
	{
		// Enable only the interrupts we're interrested in
		pDisk->pMCI_VirtualBase->MCI_IER = dwTargetStatusMask;

		if (WaitForSingleObject(pDisk->hInterruptEvent, dwTimeout) == WAIT_TIMEOUT)
		{
			RETAILMSG(1, (TEXT("WaitForSingleObject == WAIT_TIMEOUT (%d)\r\nStatusMask = 0x%X\r\nstatus 0x%x\r\n"), dwTimeout, dwTargetStatusMask, dwCurrentStatus));
		}
		else
		{
			InterruptDone(pDisk->dwSysIntr);
		}
	}

	// To be sure interrupt is acquitted
	InterruptDone(pDisk->dwSysIntr);
	pDisk->pMCI_VirtualBase->MCI_IDR = 0xFFFFFFFF;
}

 
//-----------------------------------------------------------------------------
//! \fn			AT91S_MCIDeviceStatus AT91F_MCI_SendCommand(AT91PS_MciDevice pMCI_Device, unsigned int Cmd, unsigned int Arg, PDISK pDisk)
//!
//! \brief		This function sends a command to the SD Memory Card
//!
//! \param		pMCI_Device	Pointer to a AT91S_MciDevice structure
//! \param		Cmd			Command code
//! \param		Arg			Argument
//! \param		pDisk		Pointer to a DISK structure
//!
//! \return		Returns a status
//-----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_SendCommand(AT91PS_MciDevice pMCI_Device, unsigned int Cmd, unsigned int Arg, PDISK pDisk)
{
	unsigned int	error;

    // Send the command
    pDisk->pMCI_VirtualBase->MCI_ARGR = Arg;
    pDisk->pMCI_VirtualBase->MCI_CMDR = Cmd;

	// wait for CMDRDY Status flag to read the response
	WaitForStatus(pMCI_Device, AT91C_MCI_CMDRDY, 150, pDisk);

    // Test error  ==> if crc error and response R3 ==> don't check error
    error = (pDisk->pMCI_VirtualBase->MCI_SR & AT91C_MCI_SR_CMD_ERROR);
	if (error != 0)
	{
		// if the command is SEND_OP_COND the CRC error flag is always present (cf : R3 response)
		if ( (Cmd != AT91C_SDCARD_APP_OP_COND_CMD) && (Cmd != AT91C_MMC_SEND_OP_COND_CMD) )
		{
			return ((pDisk->pMCI_VirtualBase->MCI_SR) & AT91C_MCI_SR_ERROR);
		}
		else
		{
			if (error != AT91C_MCI_RCRCE)
			{
				return ((pDisk->pMCI_VirtualBase->MCI_SR) & AT91C_MCI_SR_ERROR);
			}
		}
	}

    return AT91C_CMD_SEND_OK;
}


//-----------------------------------------------------------------------------
//! \fn			AT91S_MCIDeviceStatus AT91F_MCI_SDCard_SendAppCommand(AT91PS_MciDevice pMCI_Device, unsigned int Cmd_App, unsigned int Arg,	PDISK pDisk)
//!
//! \brief		This function sends an application specific command to the SD Memory Card
//!
//! \param		pMCI_Device	Pointer to a AT91S_MciDevice structure
//! \param		Cmd_App		Specific command to send
//! \param		Arg			Argument
//! \param		pDisk		Pointer to a DISK structure
//!
//! \return		Returns the device status
//-----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_SDCard_SendAppCommand(AT91PS_MciDevice pMCI_Device, unsigned int Cmd_App, unsigned int Arg,	PDISK pDisk)
{
	unsigned int error;

	// Send the CMD55 for application specific command
    pDisk->pMCI_VirtualBase->MCI_ARGR = (pMCI_Device->pMCI_DeviceFeatures->Relative_Card_Address << 16 );
    pDisk->pMCI_VirtualBase->MCI_CMDR = AT91C_APP_CMD;

	// wait for CMDRDY Status flag to read the response
	WaitForStatus(pMCI_Device, AT91C_MCI_CMDRDY, 150, pDisk);

    // check if it is a specific command and then send the command
	if ((Cmd_App && AT91C_SDCARD_APP_ALL_CMD) == 0)
	{
		return AT91C_CMD_SEND_ERROR;
	}
	
	error = AT91F_MCI_SendCommand(pMCI_Device, Cmd_App, Arg, pDisk);

	return error;
}


//-----------------------------------------------------------------------------
//! \fn			AT91S_MCIDeviceStatus AT91F_MCI_GetCardStatus(AT91PS_MciDevice pMCI_Device, unsigned int relative_card_address, PDISK pDisk)
//!
//! \brief		This function returns the status register of the addressed card
//!
//! \param		pMCI_Device					Pointer to a AT91S_MciDevice structure
//! \param		relative_card_address		Card's address
//! \param		pDisk						Pointer to a DISK structure
//!
//! \return		Returns the device status
//-----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_GetCardStatus(AT91PS_MciDevice pMCI_Device, unsigned int relative_card_address, PDISK pDisk)
{
	if (AT91F_MCI_SendCommand(pMCI_Device,
								AT91C_SEND_STATUS_CMD,
								relative_card_address <<16,pDisk) == AT91C_CMD_SEND_OK)
	{
		return (pDisk->pMCI_VirtualBase->MCI_RSPR[0]);
	}
	return AT91C_CMD_SEND_ERROR;
}


//-----------------------------------------------------------------------------
//! \fn	AT91S_MCIDeviceStatus AT91F_MCI_ReadBlock(AT91PS_MciDevice pMCI_Device, int src, unsigned int *dataBuffer, unsigned int sizeToRead, PDISK pDisk)
//!
//! \brief		This function read a block from the SD Memory Card
//!
//! \param		pMCI_Device	Pointer to a AT91S_MciDevice structure
//! \param		src			Address to read in the card
//! \param		dataBuffer	Buffer which will receive the block read
//! \param		sizeToRead	Size to read in bytes
//! \param		pDisk		Pointer to a DISK structure
//!
//! \return		Returns the device status
//-----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_ReadBlock(AT91PS_MciDevice pMCI_Device, int src, unsigned int *dataBuffer, unsigned int sizeToRead, PDISK pDisk)
{
    unsigned int status;
	unsigned char loop;

    if (pMCI_Device->pMCI_DeviceDesc->state != AT91C_MCI_IDLE)
  	{
		RETAILMSG(1, (TEXT("AT91F_MCI_ReadBlock-ERROR-test1\n\r")));
		return AT91C_READ_ERROR;
    }
  	

    if ((unsigned)(src + sizeToRead) > pMCI_Device->pMCI_DeviceFeatures->Memory_Capacity)
  	{
		RETAILMSG(1, (TEXT("AT91F_MCI_ReadBlock-ERROR-test3\n\r")));
		return AT91C_READ_ERROR;
    }

    // If source does not fit a begin of a block
	if ((src % pMCI_Device->pMCI_DeviceFeatures->Max_Read_DataBlock_Length) != 0)
  	{
		RETAILMSG(1, (TEXT("AT91F_MCI_ReadBlock-ERROR-test4\n\r")));
		return AT91C_READ_ERROR;
    }
   
     // Test if the MMC supports Partial Read Block
     // ALWAYS SUPPORTED IN SD Memory Card
    if ((sizeToRead < pMCI_Device->pMCI_DeviceFeatures->Max_Read_DataBlock_Length) 
    	&& (pMCI_Device->pMCI_DeviceFeatures->Read_Partial == 0x00))
  	{
		RETAILMSG(1, (TEXT("AT91F_MCI_ReadBlock-ERROR-test5\n\r")));
		return AT91C_READ_ERROR;
    }
   	
    if (sizeToRead > pMCI_Device->pMCI_DeviceFeatures->Max_Read_DataBlock_Length)
  	{
		RETAILMSG(1, (TEXT("AT91F_MCI_ReadBlock-ERROR-test6\n\r")));
		return AT91C_READ_ERROR;
    }
      
    // Init Mode Register
	pDisk->pMCI_VirtualBase->MCI_MR |= ((pMCI_Device->pMCI_DeviceFeatures->Max_Read_DataBlock_Length << 16) | AT91C_MCI_PDCMODE);
	 
    if (sizeToRead %4)
	{
		sizeToRead = (sizeToRead /4)+1;
	}
	else
	{
		sizeToRead = sizeToRead/4;
	}

	loop = 0;
	do
	{

		// wait for AT91C_MCI_NOTBUSY flag to be set.
		WaitForStatus(pMCI_Device, AT91C_MCI_NOTBUSY, 1000, pDisk);
		
		pDisk->pPDC_VirtualBase->PDC_PTCR = (AT91C_PDC_TXTDIS | AT91C_PDC_RXTDIS);
		pDisk->pPDC_VirtualBase->PDC_RPR  = (unsigned int) dataBuffer;
		pDisk->pPDC_VirtualBase->PDC_RCR  = sizeToRead;
		pMCI_Device->pMCI_DeviceDesc->state = AT91C_MCI_RX_SINGLE_BLOCK;
	
		// (PDC) Receiver Transfer Enable
		pDisk->pPDC_VirtualBase->PDC_PTCR = AT91C_PDC_RXTEN;

		// Send the Read single block command & test errors
		AT91F_MCI_SendCommand(pMCI_Device, AT91C_READ_SINGLE_BLOCK_CMD, src, pDisk);

	 	// wait for ENDRX flag to be set.
		WaitForStatus(pMCI_Device,AT91C_MCI_ENDRX, 100, pDisk);

		status = (pDisk->pMCI_VirtualBase->MCI_SR & AT91C_MCI_SR_DATA_TRANSFER_ERROR);
		//DEBUGMSG(ZONE_IO, (TEXT("Read_block_CMD_status ->0x%x\r\n"), status));
		//DEBUGMSG(ZONE_IO, (TEXT("RD_loop -> %d\n\r"),loop));
	}
	while ((status != AT91C_CMD_SEND_OK) && (loop++ < 10));

	if (status != AT91C_CMD_SEND_OK)
	{
		RETAILMSG(1, (TEXT("AT91F_MCI_ReadBlock-ERROR-%d\n\r"), loop));
		return AT91C_READ_ERROR;
	}
	else
	{
		//RETAILMSG(1, (TEXT("AT91F_MCI_ReadBlock-OK-%d\n\r"), count));
		return AT91C_READ_OK;
	}
}


//-----------------------------------------------------------------------------
//! \fn			AT91S_MCIDeviceStatus AT91F_MCI_WriteBlock(AT91PS_MciDevice pMCI_Device, int dest, unsigned int *dataBuffer, unsigned int sizeToWrite, PDISK pDisk)
//!
//! \brief		This function write a block in the SD Memory Card
//!
//! \param		pMCI_Device	Pointer to a AT91S_MciDevice structure
//! \param		dest		Address where to write the data
//! \param		dataBuffer	Buffer which will receive the block read
//! \param		sizeToWrite	Size to write in bytes
//! \param		pDisk		Pointer to a DISK structure
//!
//! \return		Returns the device status
//-----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_WriteBlock(AT91PS_MciDevice pMCI_Device, int dest, unsigned int *dataBuffer, unsigned int sizeToWrite, PDISK pDisk)
{
    unsigned int status;
	unsigned char loop;

	if(pMCI_Device->pMCI_DeviceDesc->state != AT91C_MCI_IDLE)
	{
		RETAILMSG(1, (TEXT("AT91F_MCI_WriteBlock-ERROR-test1\n\r")));
		return AT91C_WRITE_ERROR;
    }

    if ((unsigned)(dest + sizeToWrite) > pMCI_Device->pMCI_DeviceFeatures->Memory_Capacity)
	{
		RETAILMSG(1, (TEXT("AT91F_MCI_WriteBlock-ERROR-test3\n\r")));
		return AT91C_WRITE_ERROR;
    }

    // If source does not fit a begin of a block
	if ((dest % pMCI_Device->pMCI_DeviceFeatures->Max_Read_DataBlock_Length) != 0)
	{
		RETAILMSG(1, (TEXT("AT91F_MCI_WriteBlock-ERROR-test4\n\r")));
		return AT91C_WRITE_ERROR;
    }
   
    // Test if the MMC supports Partial Write Block 
    if ((sizeToWrite < pMCI_Device->pMCI_DeviceFeatures->Max_Write_DataBlock_Length) 
    	&& (pMCI_Device->pMCI_DeviceFeatures->Write_Partial == 0x00))
	{
		RETAILMSG(1, (TEXT("AT91F_MCI_WriteBlock-ERROR-test5\n\r")));
		return AT91C_WRITE_ERROR;
    }
   		
   	if (sizeToWrite > pMCI_Device->pMCI_DeviceFeatures->Max_Write_DataBlock_Length)
	{
		RETAILMSG(1, (TEXT("AT91F_MCI_WriteBlock-ERROR-test6\n\r")));
		return AT91C_WRITE_ERROR;
    }

    // Init Mode Register
	pDisk->pMCI_VirtualBase->MCI_MR |= ((pMCI_Device->pMCI_DeviceFeatures->Max_Write_DataBlock_Length << 16) | AT91C_MCI_PDCMODE);
	
	if (sizeToWrite %4)
	{
		sizeToWrite = (sizeToWrite /4)+1;
	}
	else
	{
		sizeToWrite = sizeToWrite/4;
	}

	// Init PDC for write sequence
	loop = 0;
	do
	{
		// Wait for AT91C_MCI_NOTBUSY flag to be set.
		WaitForStatus(pMCI_Device, AT91C_MCI_NOTBUSY, 1000, pDisk);

		pDisk->pPDC_VirtualBase->PDC_PTCR = (AT91C_PDC_TXTDIS | AT91C_PDC_RXTDIS);
		pDisk->pPDC_VirtualBase->PDC_TPR = (unsigned int)dataBuffer;
		pDisk->pPDC_VirtualBase->PDC_TCR = sizeToWrite;
		pMCI_Device->pMCI_DeviceDesc->state = AT91C_MCI_TX_SINGLE_BLOCK;

		 // Send the write single block command & test errors
		AT91F_MCI_SendCommand(pMCI_Device, AT91C_WRITE_BLOCK_CMD/* AT91C_WRITE_MULTIPLE_BLOCK_CMD*/, dest,pDisk);

		// Enables TX for PDC transfert requests
		pDisk->pPDC_VirtualBase->PDC_PTCR = AT91C_PDC_TXTEN;

	 	// Wait for ENDTX flag to be set.
		WaitForStatus(pMCI_Device, AT91C_MCI_ENDTX, 100, pDisk);
		
		status = (pDisk->pMCI_VirtualBase->MCI_SR & AT91C_MCI_SR_DATA_TRANSFER_ERROR);
		DEBUGMSG(ZONE_IO, (TEXT("write_block_CMD_status ->0x%x\r\n"), status));
		DEBUGMSG(ZONE_IO, (TEXT("WR_loop -> %d\n\r"), loop));

	}
	while((status != AT91C_CMD_SEND_OK) && (loop++ < 10));

	if (status != AT91C_CMD_SEND_OK)
	{
		RETAILMSG(1, (TEXT("AT91F_MCI_WriteBlock-ERROR-loop %d\n\r"),loop));
		return AT91C_WRITE_ERROR;
	}

	else
	{
		// RETAILMSG(1, (TEXT("AT91F_MCI_WriteBlock-OK-%d\n\r"), count));
		return AT91C_WRITE_OK;
	}
}


//-----------------------------------------------------------------------------
//! \fn			AT91S_MCIDeviceStatus AT91F_MCI_MMC_SelectCard(AT91PS_MciDevice pMCI_Device, unsigned int relative_card_address, PDISK pDisk)
//!
//! \brief		This function toggles a card between the Stand_by and Transfer states or between Programming and Disconnect states
//!
//! \param		pMCI_Device				Pointer to a AT91S_MciDevice structure
//! \param		relative_card_address	Card's address
//! \param		pDisk					Pointer to a DISK structure
//!
//! \return		Returns the device status
//-----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_MMC_SelectCard(AT91PS_MciDevice pMCI_Device, unsigned int relative_card_address, PDISK pDisk)
{
    int status;
	
	// Check if the MMC card chosen is already the selected one
	status = AT91F_MCI_GetCardStatus(pMCI_Device, relative_card_address, pDisk);

	if (status < 0)
	{
		return AT91C_CARD_SELECTED_ERROR;
	}

	if ((status & AT91C_SR_CARD_SELECTED) == AT91C_SR_CARD_SELECTED)
	{
		return AT91C_CARD_SELECTED_OK;
	}

	// Search for the MMC Card to be selected, status = the Corresponding Device Number
	status = 0;
	while ((pMCI_Device->pMCI_DeviceFeatures[status].Relative_Card_Address != relative_card_address)
		   && (status < AT91C_MAX_MCI_CARDS))
	{
		status++;
	}

	if (status > AT91C_MAX_MCI_CARDS)
    {
		return AT91C_CARD_SELECTED_ERROR;
	}

    if (AT91F_MCI_SendCommand( pMCI_Device,
    								   AT91C_SEL_DESEL_CARD_CMD,
    								   pMCI_Device->pMCI_DeviceFeatures[status].Relative_Card_Address << 16,pDisk) == AT91C_CMD_SEND_OK)
    {
		return AT91C_CARD_SELECTED_OK;
	}
    return AT91C_CARD_SELECTED_ERROR;
}


//-----------------------------------------------------------------------------
//! \fn			AT91S_MCIDeviceStatus AT91F_MCI_GetCSD (AT91PS_MciDevice pMCI_Device, unsigned int relative_card_address , unsigned int * response, PDISK pDisk)
//!
//! \brief		This function asks to the specified card to send its CSD
//!
//! \param		pMCI_Device				Pointer to a AT91S_MciDevice structure
//! \param		relative_card_address	Card's address
//! \param		response				Pointer to a buffer where the response will be stored
//! \param		pDisk					Pointer to a DISK structure
//!
//! \return		Returns the device status
//-----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_GetCSD (AT91PS_MciDevice pMCI_Device, unsigned int relative_card_address , unsigned int * response, PDISK pDisk)
{
 	
 	if (AT91F_MCI_SendCommand(pMCI_Device,
								  AT91C_SEND_CSD_CMD,
								  (relative_card_address << 16),pDisk) != AT91C_CMD_SEND_OK)
	{
		return AT91C_CMD_SEND_ERROR;
	}
	
    response[0] = pDisk->pMCI_VirtualBase->MCI_RSPR[0];
   	response[1] = pDisk->pMCI_VirtualBase->MCI_RSPR[1];
    response[2] = pDisk->pMCI_VirtualBase->MCI_RSPR[2];
    response[3] = pDisk->pMCI_VirtualBase->MCI_RSPR[3];
    
    return AT91C_CMD_SEND_OK;
}


//-----------------------------------------------------------------------------
//! \fn			AT91S_MCIDeviceStatus AT91F_MCI_SetBlocklength(AT91PS_MciDevice pMCI_Device, unsigned int length, PDISK pDisk)
//!
//! \brief		This function sets the block length for all following block commands (R/W)
//!
//! \param		pMCI_Device		Pointer to a AT91S_MciDevice structure
//! \param		length			Length of the block to R/W
//! \param		pDisk			Pointer to a DISK structure
//!
//! \return		Returns the device status
//-----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_SetBlocklength(AT91PS_MciDevice pMCI_Device, unsigned int length, PDISK pDisk)
{
    return (AT91F_MCI_SendCommand(pMCI_Device, AT91C_SET_BLOCKLEN_CMD, length, pDisk));
}


//-----------------------------------------------------------------------------
//! \fn			AT91S_MCIDeviceStatus AT91F_MCI_MMC_GetAllOCR(AT91PS_MciDevice pMCI_Device, PDISK pDisk)
//!
//! \brief		This function asks to all cards to send their operations conditions
//!
//! \param		pMCI_Device		Pointer to a AT91S_MciDevice structure
//! \param		pDisk			Pointer to a DISK structure
//!
//! \return		Returns the device status
//-----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_MMC_GetAllOCR(AT91PS_MciDevice pMCI_Device, PDISK pDisk)
{
	unsigned int	response =0x0;
 	
 	while(1)
    {
    	response = AT91F_MCI_SendCommand(pMCI_Device,
  										AT91C_MMC_SEND_OP_COND_CMD,
  										AT91C_MMC_HOST_VOLTAGE_RANGE,pDisk);
		if (response != AT91C_CMD_SEND_OK)
		{
			return AT91C_INIT_ERROR;
		}
		
		response = pDisk->pMCI_VirtualBase->MCI_RSPR[0];
		
		if ((response & AT91C_CARD_POWER_UP_BUSY) == AT91C_CARD_POWER_UP_BUSY)
		{
			return(response);	
		}
	}
}


//-----------------------------------------------------------------------------
//! \fn			AT91S_MCIDeviceStatus AT91F_MCI_MMC_GetAllCID(AT91PS_MciDevice pMCI_Device, unsigned int *response, PDISK pDisk)
//!
//! \brief		This function asks to the MMC on the chosen slot to send its CID
//!
//! \param		pMCI_Device		Pointer to a AT91S_MciDevice structure
//! \param		response		Pointer to a buffer which will received the response
//! \param		pDisk			Pointer to a DISK structure
//!
//! \return		Returns the device status
//-----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_MMC_GetAllCID(AT91PS_MciDevice pMCI_Device, unsigned int *response, PDISK pDisk)
{
	int Nb_Cards_Found=-1;
  
	while(1)
	{
	 	if(AT91F_MCI_SendCommand(pMCI_Device,
								AT91C_MMC_ALL_SEND_CID_CMD,
								AT91C_NO_ARGUMENT,pDisk) != AT91C_CMD_SEND_OK)
		{
			return Nb_Cards_Found;
		}
		else
		{		
			Nb_Cards_Found = 0;
			// Assignation of the relative address to the MMC CARD
			pMCI_Device->pMCI_DeviceFeatures[Nb_Cards_Found].Relative_Card_Address = Nb_Cards_Found + AT91C_FIRST_RCA;
			// Set the insert flag
			pMCI_Device->pMCI_DeviceFeatures[Nb_Cards_Found].Card_Inserted = AT91C_MMC_CARD_INSERTED;
	
			if (AT91F_MCI_SendCommand(pMCI_Device,
									 AT91C_MMC_SET_RELATIVE_ADDR_CMD,
									 (Nb_Cards_Found + AT91C_FIRST_RCA) << 16,pDisk) != AT91C_CMD_SEND_OK)
				return AT91C_CMD_SEND_ERROR;
				 
			// If no error during assignation address ==> Increment Nb_cards_Found
			Nb_Cards_Found++ ;
		}
	}
}


//-----------------------------------------------------------------------------
//! \fn			AT91S_MCIDeviceStatus AT91F_MCI_MMC_Init (AT91PS_MciDevice pMCI_Device, PDISK pDisk)
//!
//! \brief		This function returns the MMC initialisation status
//!
//! \param		pMCI_Device		Pointer to a AT91S_MciDevice structure
//! \param		pDisk			Pointer to a DISK structure
//!
//! \return		Returns the device status
//-----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_MMC_Init (AT91PS_MciDevice pMCI_Device, PDISK pDisk)
{
    unsigned int	tab_response[4];
	unsigned int	mult,blocknr;
	unsigned int 	i,Nb_Cards_Found=0;

	// Resets all MMC Cards in Idle state
	AT91F_MCI_SendCommand(pMCI_Device, AT91C_MMC_GO_IDLE_STATE_CMD, AT91C_NO_ARGUMENT, pDisk);

    if(AT91F_MCI_MMC_GetAllOCR(pMCI_Device,pDisk) == AT91C_INIT_ERROR)
	{
    	return AT91C_INIT_ERROR;
	}

	Nb_Cards_Found = AT91F_MCI_MMC_GetAllCID(pMCI_Device,tab_response,pDisk);
	if (Nb_Cards_Found != AT91C_CMD_SEND_ERROR)
	{
		for(i = 0; i < Nb_Cards_Found; i++)
		{
			if (AT91F_MCI_GetCSD(pMCI_Device,
									  pMCI_Device->pMCI_DeviceFeatures[i].Relative_Card_Address,
									  tab_response,pDisk) != AT91C_CMD_SEND_OK)
			{
				pMCI_Device->pMCI_DeviceFeatures[i].Relative_Card_Address = 0;					  
			}
			else
			{
				pMCI_Device->pMCI_DeviceFeatures[i].Max_Read_DataBlock_Length = 1 << ((tab_response[1] >> AT91C_CSD_RD_B_LEN_S) & AT91C_CSD_RD_B_LEN_M );
	 			pMCI_Device->pMCI_DeviceFeatures[i].Max_Write_DataBlock_Length =	1 << ((tab_response[3] >> AT91C_CSD_WBLEN_S) & AT91C_CSD_WBLEN_M );
				pMCI_Device->pMCI_DeviceFeatures[i].Sector_Size = 1 + ((tab_response[2] >> AT91C_CSD_v22_SECT_SIZE_S) & AT91C_CSD_v22_SECT_SIZE_M );
		  		pMCI_Device->pMCI_DeviceFeatures[i].Read_Partial = (tab_response[1] >> AT91C_CSD_RD_B_PAR_S) & AT91C_CSD_RD_B_PAR_M;
				pMCI_Device->pMCI_DeviceFeatures[i].Write_Partial = (tab_response[3] >> AT91C_CSD_WBLOCK_P_S) & AT91C_CSD_WBLOCK_P_M;
				
				// None in MMC specification version 2.2
				pMCI_Device->pMCI_DeviceFeatures[i].Erase_Block_Enable = 0;
				
				pMCI_Device->pMCI_DeviceFeatures[i].Read_Block_Misalignment = (tab_response[1] >> AT91C_CSD_RD_B_MIS_S) & AT91C_CSD_RD_B_MIS_M;
				pMCI_Device->pMCI_DeviceFeatures[i].Write_Block_Misalignment = (tab_response[1] >> AT91C_CSD_WR_B_MIS_S) & AT91C_CSD_WR_B_MIS_M;

				// Compute Memory Capacity
				// Compute MULT
				mult = 1 << ( ((tab_response[2] >> AT91C_CSD_C_SIZE_M_S) & AT91C_CSD_C_SIZE_M_M) + 2 );
				// compute MSB of C_SIZE
				blocknr = ((tab_response[1] >> AT91C_CSD_CSIZE_H_S) & AT91C_CSD_CSIZE_H_M) << 2;
				// compute MULT * (LSB of C-SIZE + MSB already computed + 1) = BLOCKNR
				blocknr = mult * ( ( blocknr + ( (tab_response[2] >> AT91C_CSD_CSIZE_L_S) & AT91C_CSD_CSIZE_L_M) ) + 1 );

				pMCI_Device->pMCI_DeviceFeatures[i].Memory_Capacity =  pMCI_Device->pMCI_DeviceFeatures[i].Max_Read_DataBlock_Length * blocknr;
		  		// End of Compute Memory Capacity

				// From now on, ignore the MAX Block length given by the SDCARD, we'll always use a 512 bytes sector size
				pMCI_Device->pMCI_DeviceFeatures[i].Max_Read_DataBlock_Length = SD_BYTES_PER_SECTOR;
				pMCI_Device->pMCI_DeviceFeatures[i].Max_Write_DataBlock_Length = SD_BYTES_PER_SECTOR;

			}			  
		}
		return AT91C_INIT_OK;
	}
    return AT91C_INIT_ERROR;
}


//-----------------------------------------------------------------------------
//! \fn			AT91S_MCIDeviceStatus AT91F_MCI_SDCard_GetOCR (AT91PS_MciDevice pMCI_Device, PDISK pDisk)
//!
//! \brief		This function asks to all cards to send their operations conditions
//!
//! \param		pMCI_Device		Pointer to a AT91S_MciDevice structure
//! \param		pDisk			Pointer to a DISK structure
//!
//! \return		Returns the device status
//-----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_SDCard_GetOCR (AT91PS_MciDevice pMCI_Device, PDISK pDisk)
{
	unsigned int	response =0x0;

	// The RCA to be used for CMD55 in Idle state shall be the card's default RCA=0x0000.
	pMCI_Device->pMCI_DeviceFeatures->Relative_Card_Address = 0x0;
 	
 	while ((response & AT91C_CARD_POWER_UP_BUSY) != AT91C_CARD_POWER_UP_BUSY)
    {
    	response = AT91F_MCI_SDCard_SendAppCommand(pMCI_Device,
  										AT91C_SDCARD_APP_OP_COND_CMD,
  										AT91C_MMC_HOST_VOLTAGE_RANGE,pDisk);
		// if (response != AT91C_CMD_SEND_OK)
		// return AT91C_INIT_ERROR;
		
		response = (pDisk->pMCI_VirtualBase->MCI_RSPR[0]);
	}
	return(pDisk->pMCI_VirtualBase->MCI_RSPR[0]);
}


//-----------------------------------------------------------------------------
//! \fn			AT91S_MCIDeviceStatus AT91F_MCI_SDCard_GetCID (AT91PS_MciDevice pMCI_Device, unsigned int *response, PDISK pDisk)
//!
//! \brief		This function asks to the SD Memory Card on the chosen slot to send its CID
//!
//! \param		pMCI_Device		Pointer to a AT91S_MciDevice structure
//! \param		response		Pointer to a buffer which will received the response
//! \param		pDisk			Pointer to a DISK structure
//!
//! \return		Returns the device status
//-----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_SDCard_GetCID (AT91PS_MciDevice pMCI_Device, unsigned int *response, PDISK pDisk)
{
 	if(AT91F_MCI_SendCommand(pMCI_Device,
							AT91C_ALL_SEND_CID_CMD,
							AT91C_NO_ARGUMENT,pDisk) != AT91C_CMD_SEND_OK)
	{
		return AT91C_CMD_SEND_ERROR;
	}
	
    response[0] = pDisk->pMCI_VirtualBase->MCI_RSPR[0];
   	response[1] = pDisk->pMCI_VirtualBase->MCI_RSPR[1];
    response[2] = pDisk->pMCI_VirtualBase->MCI_RSPR[2];
    response[3] = pDisk->pMCI_VirtualBase->MCI_RSPR[3];
    
    return AT91C_CMD_SEND_OK;
}


//-----------------------------------------------------------------------------
//! \fn			AT91S_MCIDeviceStatus AT91F_MCI_SDCard_SetBusWidth(AT91PS_MciDevice pMCI_Device, PDISK pDisk)
//!
//! \brief		This function sets bus width for SD Memory Card
//!
//! \param		pMCI_Device		Pointer to a AT91S_MciDevice structure
//! \param		pDisk			Pointer to a DISK structure
//!
//! \return		Returns the device status
//-----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_SDCard_SetBusWidth(AT91PS_MciDevice pMCI_Device, PDISK pDisk)
{
	volatile int	ret_value;
	char			bus_width;

	do
	{
		ret_value = AT91F_MCI_GetCardStatus(pMCI_Device, pMCI_Device->pMCI_DeviceFeatures->Relative_Card_Address, pDisk);
	}
	while ((ret_value > 0) && ((ret_value & AT91C_SR_READY_FOR_DATA) == 0));

	// Select Card
    AT91F_MCI_SendCommand(pMCI_Device,
    						AT91C_SEL_DESEL_CARD_CMD,
    						(pMCI_Device->pMCI_DeviceFeatures->Relative_Card_Address)<<16,pDisk);

	// Set bus width for Sdcard
	if(pMCI_Device->pMCI_DeviceDesc->SDCard_bus_width == 4)
	{
		 bus_width = AT91C_BUS_WIDTH_4BITS;
		 pDisk->pMCI_VirtualBase->MCI_SDCR |= AT91C_MCI_SCDBUS;
	}
	else
	{
		bus_width = AT91C_BUS_WIDTH_1BIT;
		pDisk->pMCI_VirtualBase->MCI_SDCR &= ~AT91C_MCI_SCDBUS;
	}

	if (AT91F_MCI_SDCard_SendAppCommand(pMCI_Device, AT91C_SDCARD_SET_BUS_WIDTH_CMD, bus_width, pDisk) != AT91C_CMD_SEND_OK)
	{
		return AT91C_CMD_SEND_ERROR;
	}
	// Set bus width for Sdcard
	if(pMCI_Device->pMCI_DeviceDesc->SDCard_bus_width == 4)
	{
		 bus_width = AT91C_BUS_WIDTH_4BITS;
		 pDisk->pMCI_VirtualBase->MCI_SDCR |= AT91C_MCI_SCDBUS;
	}
	else
	{
		bus_width = AT91C_BUS_WIDTH_1BIT;
		pDisk->pMCI_VirtualBase->MCI_SDCR &= ~AT91C_MCI_SCDBUS;
	}


	return AT91C_CMD_SEND_OK;
}


//-----------------------------------------------------------------------------
//! \fn			AT91S_MCIDeviceStatus AT91F_MCI_SDCard_Init(AT91PS_MciDevice pMCI_Device, PDISK pDisk)
//!
//! \brief		This function the SD Memory Card
//!
//! \param		pMCI_Device		Pointer to a AT91S_MciDevice structure
//! \param		pDisk			Pointer to a DISK structure
//!
//! \return		Returns the initialization status
//-----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_SDCard_Init(AT91PS_MciDevice pMCI_Device, PDISK pDisk)
{
    unsigned int	tab_response[4];
	unsigned int	mult,blocknr;

	AT91F_MCI_SendCommand(pMCI_Device, AT91C_GO_IDLE_STATE_CMD, AT91C_NO_ARGUMENT, pDisk);

	if(AT91F_MCI_SDCard_GetOCR(pMCI_Device,pDisk) == AT91C_INIT_ERROR)
	{
		return AT91C_INIT_ERROR;
	}
    
/*	if */AT91F_MCI_SDCard_GetCID(pMCI_Device, tab_response, pDisk);// == AT91C_CMD_SEND_OK)
	{
	    pMCI_Device->pMCI_DeviceFeatures->Card_Inserted = AT91C_SD_CARD_INSERTED;

	    /*if (*/AT91F_MCI_SendCommand(pMCI_Device, AT91C_SET_RELATIVE_ADDR_CMD, 0, pDisk); //== AT91C_CMD_SEND_OK)
		{
			pMCI_Device->pMCI_DeviceFeatures->Relative_Card_Address = (pDisk->pMCI_VirtualBase->MCI_RSPR[0] >> 16);
		/*	if (*/AT91F_MCI_GetCSD(pMCI_Device, pMCI_Device->pMCI_DeviceFeatures->Relative_Card_Address, tab_response, pDisk); //== AT91C_CMD_SEND_OK)
			{
		  		pMCI_Device->pMCI_DeviceFeatures->Max_Read_DataBlock_Length = 1 << ((tab_response[1] >> AT91C_CSD_RD_B_LEN_S) & AT91C_CSD_RD_B_LEN_M );
	 			pMCI_Device->pMCI_DeviceFeatures->Max_Write_DataBlock_Length =	1 << ((tab_response[3] >> AT91C_CSD_WBLEN_S) & AT91C_CSD_WBLEN_M );
				pMCI_Device->pMCI_DeviceFeatures->Sector_Size = 1 + ((tab_response[2] >> AT91C_CSD_v21_SECT_SIZE_S) & AT91C_CSD_v21_SECT_SIZE_M );
		  		pMCI_Device->pMCI_DeviceFeatures->Read_Partial = (tab_response[1] >> AT91C_CSD_RD_B_PAR_S) & AT91C_CSD_RD_B_PAR_M;
				pMCI_Device->pMCI_DeviceFeatures->Write_Partial = (tab_response[3] >> AT91C_CSD_WBLOCK_P_S) & AT91C_CSD_WBLOCK_P_M;
				pMCI_Device->pMCI_DeviceFeatures->Erase_Block_Enable = (tab_response[3] >> AT91C_CSD_v21_ER_BLEN_EN_S) & AT91C_CSD_v21_ER_BLEN_EN_M;
				pMCI_Device->pMCI_DeviceFeatures->Read_Block_Misalignment = (tab_response[1] >> AT91C_CSD_RD_B_MIS_S) & AT91C_CSD_RD_B_MIS_M;
				pMCI_Device->pMCI_DeviceFeatures->Write_Block_Misalignment = (tab_response[1] >> AT91C_CSD_WR_B_MIS_S) & AT91C_CSD_WR_B_MIS_M;

				// Compute Memory Capacity
				// Compute MULT
				mult = 1 << ( ((tab_response[2] >> AT91C_CSD_C_SIZE_M_S) & AT91C_CSD_C_SIZE_M_M) + 2 );
				// compute MSB of C_SIZE
				blocknr = ((tab_response[1] >> AT91C_CSD_CSIZE_H_S) & AT91C_CSD_CSIZE_H_M) << 2;
				// compute MULT * (LSB of C-SIZE + MSB already computed + 1) = BLOCKNR
				blocknr = mult * ( ( blocknr + ( (tab_response[2] >> AT91C_CSD_CSIZE_L_S) & AT91C_CSD_CSIZE_L_M) ) + 1 );

				pMCI_Device->pMCI_DeviceFeatures->Memory_Capacity = pMCI_Device->pMCI_DeviceFeatures->Max_Read_DataBlock_Length * blocknr;
			  	// End of Compute Memory Capacity
				
				// From now on, ignore the MAX Block length given by the SDCARD, we'll always use a 512 bytes sector size
				pMCI_Device->pMCI_DeviceFeatures->Max_Read_DataBlock_Length = SD_BYTES_PER_SECTOR;
				pMCI_Device->pMCI_DeviceFeatures->Max_Write_DataBlock_Length = SD_BYTES_PER_SECTOR;


		  		if( AT91F_MCI_SDCard_SetBusWidth(pMCI_Device,pDisk) == AT91C_CMD_SEND_OK )
				{	
					 if (AT91F_MCI_SetBlocklength(pMCI_Device,SD_BYTES_PER_SECTOR,pDisk) == AT91C_CMD_SEND_OK)
					return AT91C_INIT_OK;
				}
			}
		}
	}
    return AT91C_INIT_ERROR;
}


//-----------------------------------------------------------------------------
//! \fn			void AT91F_MCIDeviceWaitReady(AT91PS_MciDevice pMCI_Device, unsigned int timeout, PDISK pDisk)
//!
//! \brief		This function waits until the MCI device is ready. Tests the NOTBUSY flag
//!
//! \param		pMCI_Device	Pointer to a AT91S_MciDevice
//! \param		timeout		If the waiting exceeds the timeout, the function is stopped
//! \param		pDisk		Pointer to a DISK structure
//-----------------------------------------------------------------------------
void AT91F_MCIDeviceWaitReady(AT91PS_MciDevice pMCI_Device, unsigned int timeout, PDISK pDisk)
{
	WaitForStatus(pMCI_Device, AT91C_MCI_NOTBUSY, timeout, pDisk);
}


//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/SDMEMORY/mci_device.c $
//-----------------------------------------------------------------------------
//
