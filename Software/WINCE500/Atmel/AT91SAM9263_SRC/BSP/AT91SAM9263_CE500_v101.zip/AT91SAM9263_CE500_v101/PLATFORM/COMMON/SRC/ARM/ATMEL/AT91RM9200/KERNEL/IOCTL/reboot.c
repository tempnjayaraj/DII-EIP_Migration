//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		reboot.c
//!
//! \brief		AT91RM9200's reboot feature
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/KERNEL/IOCTL/reboot.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

#include <windows.h>
#include <oal.h>

#include "AT91RM9200.h"
#include "at91rm9200_oal_ioctl.h"



//-----------------------------------------------------------------------------
//! \fn		BOOL OALIoCtlHalGetProcessorClock(	UINT32 code, VOID *pInpBuffer, 
//!								UINT32 inpSize, VOID *pOutBuffer, 
//!								UINT32 outSize, UINT32 *pOutSize)
//!
//! \brief		This function implements the IOCTL_HAL_REBOOT IOControl
//!				Reboot is not implemented yet
//!
//!	\param		code		not used
//!	\param		pInpBuffer	Reboot type
//!	\param		inpSize		sizeof(DWORD)
//!	\param		pOutBuffer	not used
//!	\param		outSize		not used
//!	\param		pOutSize	not used
//!
//! \return		TRUE indicates success
//! \return		FALSE indicates failure (bad parameters)
//!
//! 
//-----------------------------------------------------------------------------
BOOL OALIoCtlHalReboot(UINT32 code, VOID *pInpBuffer, 
                       UINT32 inpSize, VOID *pOutBuffer, 
                       UINT32 outSize, UINT32 *pOutSize)
{	
	BOOL bResult = FALSE;
	AT91PS_SYS pSys = (AT91PS_SYS) OALPAtoVA((DWORD)AT91C_BASE_SYS, FALSE);

	DEBUGMSG(1, (TEXT("+OALIoCtlHalReboot\r\n")));
	
	pSys->ST_WDMR = 1 | AT91C_ST_RSTEN;  //reset by watchdog in MMCE_SYS_CLK/128 
	
	bResult = TRUE;

	DEBUGMSG(1, (TEXT("-OALIoCtlHalReboot (result = %s)\r\n"),bResult ? L"TRUE" : L"FALSE"));
    
	return bResult;
}


//! @}
