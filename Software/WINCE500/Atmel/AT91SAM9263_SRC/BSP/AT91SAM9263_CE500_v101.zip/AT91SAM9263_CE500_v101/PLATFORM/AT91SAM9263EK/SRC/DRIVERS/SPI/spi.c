//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file spi.c 
//!
//! $RCSfile: spi.c,v $
//! 
//! \brief This file implements the platform dependent part of the SPI driver
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/SPI/SPI.c $
//!   $Author: jjhiblot $
//!   $Revision: 958 $
//!   $Date: 2007-06-07 14:02:07 +0200 (jeu., 07 juin 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	SPI
//! @{
//!
///////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <ceddk.h>
#include "AT91SAM926x.h"
#include "AT91SAM9263EK.h"
#include "lib_at91sam926x.h"
#include <AT91SAM926x_spi.h>
#include "AT91SAM926x_spi_ioctl.h"
#include "at91sam9263ek_ioctl.h"
#include "at91sam9263_gpio.h"
#include "SPIDriver.h"

#define DEBUGSPI9263EK 0

// SPIO 0
#define SPI0_MISO	AT91C_PIN_PA(0)
#define SPI0_MOSI	AT91C_PIN_PA(1)
#define SPI0_SPCK	AT91C_PIN_PA(2)
#define SPI0_NPCS3B	AT91C_PIN_PB(11)
// SPIO 1
#define SPI1_MISO	AT91C_PIN_PB(12)
#define SPI1_MOSI	AT91C_PIN_PB(13)
#define SPI1_SPCK	AT91C_PIN_PB(14)
#define SPI1_NPCS2B	AT91C_PIN_PB(17)

#define BUSY		AT91C_PIN_PA(31)

static HANDLE g_hMutex;
//-----------------------------------------------------------------------------
//! \fn			BOOL HWSPIControllerBoardSpecificInit()
//!
//! \brief		Initialize the specific platform 
//!			Create a mutex for sharing the SPI/MCI pins
//!
//! \return		\e TRUE When all is good
//!	\return		\e FALSE When there is an error during initialization
//-----------------------------------------------------------------------------
BOOL HWSPIControllerBoardSpecificInit()
{
	BOOL bRet = TRUE;
	
	// creation of the mutex for sharing the SPI/MCI pins
	g_hMutex = CreateMutex(NULL, FALSE, SPI_MCI_BUS_MUTEX);
	if (g_hMutex == NULL)
	{
		bRet = FALSE;
	}
	return bRet;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL HWSPIControllerBoardSpecificDeInit()
//!
//! \brief		DeInitialize the specific platform
//!			
//!
//-----------------------------------------------------------------------------
void HWSPIControllerBoardSpecificDeInit()
{
	HANDLE hTemp = g_hMutex;
	g_hMutex = NULL;
	CloseHandle(hTemp);
}

//-----------------------------------------------------------------------------
//! \fn			BOOL HWSPIControllerBoardSpecificGetBus()
//!
//! \brief		Get the SPI bus during a transfer
//!
//! \return		\e TRUE When all is good
//!	\return		\e FALSE When there is an error 
//-----------------------------------------------------------------------------
BOOL HWSPIControllerBoardSpecificGetBus()
{
	BOOL bRet = FALSE;
	DWORD dwWaitRet;
	if(g_hMutex != NULL)
	{
		dwWaitRet = WaitForSingleObject(g_hMutex, INFINITE );
		if ( dwWaitRet != WAIT_TIMEOUT )
		{
			bRet = TRUE;
		}
	}
	else
	{
		RETAILMSG(1, (L"HWSPIControllerBoardSpecificGetBus : Invalid Handle"));
	}
	return bRet;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL HWSPIControllerBoardSpecificReleaseBus()
//!
//! \brief		Release the Mutex afeter a transfer
//!
//! \return		\e TRUE When all is good
//!	\return		\e FALSE When there is an error 
//-----------------------------------------------------------------------------
BOOL HWSPIControllerBoardSpecificReleaseBus()
{
	BOOL bRet = FALSE;
	if (g_hMutex != NULL)
	{
		ReleaseMutex(g_hMutex);
		bRet = TRUE;
	}
	else
	{
		RETAILMSG(1, (L"HWSPIControllerBoardSpecificReleaseBus : Invalid Handle"));
	}
	return bRet;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL HWSPIControllerBoardSpecificPIODeinitialization(DWORD dwDevID)
//!
//! \brief		This function is called to deinitialize the PIOs used by the SPI controller.
//!
//! \param 		dwDevID The ID of the SPI controller
//!
//!	\return		TRUE
//-----------------------------------------------------------------------------
BOOL HWSPIControllerBoardSpecificPIODeinitialization(DWORD dwDevID)
{
	return TRUE;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL HWSPIControllerBoardSpecificPIOInitialization(DWORD dwDevID, WORD wCS)
//!
//! \brief		This function is called to initialize the PIOs used by the SPI controller.
//!
//! \param 		dwDevID 		The ID of the SPI controller
//! \param 		wCS		 	indicates which ChipSelect is really used
//!
//!	\return		True if valid ID, FALSE else
//-----------------------------------------------------------------------------
BOOL HWSPIControllerBoardSpecificPIOInitialization(DWORD dwDevID, WORD wCS)
{
	BOOL bResult = TRUE;
	//	This PIO initialization is only available for chipSelects used in the nadia2ek board
	//	The wCS indicates which ChipSelect is really used. Developpers must modify the PIO 
	//	initialization if needed.
	
	switch (dwDevID)
	{
		case 0: //SPI0 controller..... not connected
			{
				const struct pio_desc hw_pioSPI0[] = 
					{
									{"MISO0",	SPI0_MISO  , 0, PIO_DEFAULT, PIO_PERIPH_A},
									{"MOSI0",	SPI0_MOSI  , 0, PIO_DEFAULT, PIO_PERIPH_A},
									{"SPCK0",	SPI0_SPCK  , 0, PIO_DEFAULT, PIO_PERIPH_A},
									{"NPCS00",	SPI0_NPCS3B, 0, PIO_DEFAULT, PIO_PERIPH_B},
								};
				pio_setup(hw_pioSPI0, sizeof(hw_pioSPI0)/sizeof(struct pio_desc));
			}
			break;
		case 1: //SPI1 controller..... used by TSC2200
			{
				const struct pio_desc hw_pioSPI1[] = 
				{
									{"MISO1",	SPI1_MISO  , 0, PIO_DEFAULT, PIO_PERIPH_A},
									{"MOSI1",	SPI1_MOSI  , 0, PIO_DEFAULT, PIO_PERIPH_A},
									{"SPCK1",	SPI1_SPCK  , 0, PIO_DEFAULT, PIO_PERIPH_A},
									{"NPCS21",	SPI1_NPCS2B, 0, PIO_DEFAULT, PIO_PERIPH_A},
								};
				pio_setup(hw_pioSPI1, sizeof(hw_pioSPI1)/sizeof(struct pio_desc));
			}
			break;
		default:
			return FALSE;
	}

	return bResult;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL HWSPICSBoardSpecificPIODeinitialization(AT91PS_PIO pPioBank,DWORD dwPioMask)
//!
//! \brief		This function is called to deinitialize a PIO used by the SPI driver as a ChipSelect.
//!
//! \param 		pPioBank 		pointer to the PIO's bank controller
//! \param 		dwPioMask 	Mask for the pio
//!
//!	\return		True
//-----------------------------------------------------------------------------
BOOL HWSPICSBoardSpecificPIODeinitialization(AT91PS_PIO pPioBank,DWORD dwPioMask)
{
	return TRUE;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL HWSPICSBoardSpecificPIOInitialization(DWORD dwPinNumber)
//!
//! \brief		This function is called to initialize a PIO used by the SPI driver as a ChipSelect.
//!
//! \param 		dwPinNumber 		pin number of the pio
//!
//!	\return		TRUE 	indicates success
//!	\return		FALSE	indicates failure
//-----------------------------------------------------------------------------
BOOL HWSPICSBoardSpecificPIOInitialization(/*DWORD dwPIOBankNumber,*/DWORD dwPinNumber/*,AT91PS_PIO* ppPioBank,DWORD* pPioMask*/)
{
	BOOL bRet = FALSE;

	if (dwPinNumber >=0 && dwPinNumber <= PIO_NB_IO * NB_PIO_BANK)
	{
		struct pio_desc hw_pio[] = 
	{
			{"CS",	dwPinNumber, 1, PIO_DEFAULT, PIO_OUTPUT},
		};
		pio_setup(hw_pio, sizeof(hw_pio)/sizeof(struct pio_desc));
		bRet = TRUE;
	}
	return bRet;
}

//numbers of boucle FOR to do in tempo()
#define TEMPO 300

//#pragma needed to avoid compilo optimization
#pragma optimize("",off)

//-----------------------------------------------------------------------------
//! \fn			void tempo ()
//!
//! \brief		brief This function allows to wait few microseconds
//!
//-----------------------------------------------------------------------------
void tempo ()
{
	volatile unsigned int waitingLoop;
	for(waitingLoop=0;waitingLoop<TEMPO;waitingLoop++)
	{
	}
}

#pragma optimize("",on)

//-----------------------------------------------------------------------------
//!
//! \fn			void SPIWriteCharADS7843 (T_SPI_OPEN_STRUCTURE* pOpenContext,UCHAR ucCmd, WORD *pBufOut)
//!
//! \brief		This function Writes a Command on SPI for ADS7843
//!
//! \param		pOpenContext		SPI Device	
//! \param		ucCmd		Command to send to ADS7843
//! \param		pBufOut 		Pointer to the buffer used to transfer the output data from
//!				the device. 			 	
//-----------------------------------------------------------------------------
void SPIWriteCharADS7843 (T_SPI_OPEN_STRUCTURE* pOpenContext,UCHAR ucCmd, WORD *pBufOut)
{
	DWORD dwBitIndex = 0;
	UCHAR dwBit = 0;
	int i = 0;

	// Chip select CS#
	pio_set_value(SPI0_NPCS3B, 0);

	// Send command
	for (i = 0; i <= 7; i ++)
	{
		// Data MSB first
		dwBit = (ucCmd & (1 << (7-i))) >> (7-i);

		if (dwBit)
		{
			// "1"
			pio_set_value(SPI0_MOSI, 1);
		}
		else
		{
			// "0"
			pio_set_value(SPI0_MOSI, 0);
		}
		
		// Clock 
		// Data acquisition on rising edge
		tempo();
		pio_set_value(SPI0_SPCK, 1);
		tempo();
		pio_set_value(SPI0_SPCK, 0);
	}

	// After sending the command the MOSI signal must stay to low
	pio_set_value(SPI0_MOSI, 0);

	tempo ();

	// Read conversion data
	(*pBufOut) = 0;
	for (i = 0; i <= 11;)
	{
		//Sleep(2);
		tempo();
		pio_set_value(SPI0_SPCK, 1);

		// Read data when busy done
		if (!(pio_get_value(BUSY)))
		{
			(*pBufOut) = ((*pBufOut) << 1) | (pio_get_value(SPI0_MISO) ? 1 : 0);
			i++;
		}

		tempo();
		pio_set_value(SPI0_SPCK, 0);
	}

	tempo();

	// Chip unselect
	pio_set_value(SPI0_NPCS3B, 1);

	DEBUGMSG(DEBUGSPI9263EK, (TEXT("SPIDriver: -ADS7843_Transaction Data(recu=%d) \r\n"), *pBufOut));


}

//-----------------------------------------------------------------------------
//!
//! \fn			BOOL DoSPITransactionADS7843(T_SPI_OPEN_STRUCTURE* pOpenContext,UCHAR ucCmd, WORD* pBufOut, DWORD dwLenOut)
//!
//! \brief		This function performs the SPI transaction for ADS7843
//!
//! \param		pOpenContext		SPI Device	
//! \param		ucCmd	: Command to send to ADS7843			
//! \param		pBufOut : Pointer to the buffer used to transfer the output data from 
//!				the device. 
//! \param		dwLenOut : Maximum number of bytes in the buffer specified by pBufOut. 	
//! \return		TRUE, or FALSE in case of error
//-----------------------------------------------------------------------------
BOOL DoSPITransactionADS7843(T_SPI_OPEN_STRUCTURE* pOpenContext,UCHAR ucCmd, WORD* pBufOut, DWORD dwLenOut)
{
	const struct pio_desc hw_pio[] = {
		{"SPI0_MOSI",	SPI0_MOSI,	0, PIO_DEFAULT, PIO_OUTPUT},
		{"SPI0_SPCK",	SPI0_SPCK,	0, PIO_DEFAULT, PIO_OUTPUT},
		{"SPI0_NPCS3B",	SPI0_NPCS3B,0, PIO_DEFAULT, PIO_OUTPUT},
		{"SPI0_MISO",	SPI0_MISO,	0, PIO_DEFAULT, PIO_INPUT},
		{"BUSY",		BUSY,		0, PIO_DEFAULT, PIO_INPUT},
	};
	
	const struct pio_desc hw_pio_periph[] = {
		{"SPI0_MOSI",	SPI0_MISO,	0, PIO_DEFAULT, PIO_PERIPH_A},
		{"SPI0_SPCK",	SPI0_SPCK,	0, PIO_DEFAULT, PIO_PERIPH_A},
		{"SPI0_NPCS3B",	SPI0_MISO,	0, PIO_DEFAULT, PIO_PERIPH_A},
		{"SPI0_MISO",	SPI0_NPCS3B,0, PIO_DEFAULT, PIO_PERIPH_B},
	};
	
	T_SPI_CONTROLLER_STRUCTURE* pSPIControllerInfo = pOpenContext->pSPIInfo->pSPIControllerInfo;
	

	// The Transaction is protected by a critical section
	// we must get the SPI controller for ourselves.
	EnterCriticalSection(&pSPIControllerInfo->csSPIAccess);
	
	DEBUGMSG(DEBUGSPI9263EK, (TEXT("SPIDriver: +ADS7843_Transaction")));
	
	// Manual transaction

	pio_setup(hw_pio, sizeof(hw_pio)/sizeof(struct pio_desc));

	pio_set_value(SPI0_MOSI, 0);
	tempo();
	pio_set_value(SPI0_SPCK, 0);
	tempo();
	pio_set_value(SPI0_NPCS3B, 1);
	tempo();	

	// Write Command
	SPIWriteCharADS7843(pOpenContext,ucCmd,pBufOut);

	// Re enable MOSI (PIO_PA1) as peripheral output
	pio_setup(hw_pio_periph, sizeof(hw_pio_periph)/sizeof(struct pio_desc));

	DEBUGMSG(DEBUGSPI9263EK, (TEXT("SPIDriver: -ADS7843_Transaction")));

	//We can now release the access to the SPI controller
	LeaveCriticalSection(&pSPIControllerInfo->csSPIAccess);

	return TRUE;
}

//-----------------------------------------------------------------------------
//!
//! \fn			BOOL SPI_Board_Specific_IOControl(DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut )
//!
//! \brief		This function sends a command to a device. It uses SPI_IOControl 
//!				for AT91SAM926X except for IOCTL_SPI_ADS7843 code
//!
//! \param		hOpenContext : Handle to the open context of the device. The XXX_Open
//!				function creates and returns this identifier. 
//!
//! \param		dwCode : I/O control operation to perform. These codes are 
//!				device-specific and are usually exposed to developers through a 
//!				header file. 
//!
//! \param		pBufIn : Pointer to the buffer containing data to transfer to the device. 
//!
//! \param		dwLenIn : Number of bytes of data in the buffer specified for pBufIn. 
//!
//! \param		pBufOut : Pointer to the buffer used to transfer the output data from 
//!				the device. 
//!
//! \param		dwLenOut : Maximum number of bytes in the buffer specified by pBufOut. 
//!
//! \param		pdwActualOut : Pointer to the DWORD buffer that this function uses to 
//!				return the actual number of bytes received from the device. 
//!
//! \return		\e TRUE indicates success.
//!	\return		\e FALSE indicates failure.
//-----------------------------------------------------------------------------
extern BOOL SPI_IOControl(DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut );

BOOL SPI_Board_Specific_IOControl(DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut )
{
	BOOL bResult=TRUE;
	T_SPI_OPEN_STRUCTURE* pSPIOpen;
	T_SPI_INIT_STRUCTURE* pSPIInfo;

	pSPIOpen= (T_SPI_OPEN_STRUCTURE*) hOpenContext;
	pSPIInfo = (T_SPI_INIT_STRUCTURE*)pSPIOpen->pSPIInfo;

	HWSPIControllerBoardSpecificGetBus();
	HWSPIControllerBoardSpecificPIOInitialization(pSPIInfo->dwDevIndex, pSPIInfo->wCS);

	if( dwCode == IOCTL_SPI_ADS7843)
	{
			DEBUGMSG(DEBUGSPI9263EK, (TEXT("SPI_IOControl - IOCTL_ADS7843\r\n")));
			if (pBufIn != NULL && pBufOut != NULL && dwLenOut >= sizeof(WORD))
			{
				T_SPI_TRANSACTION_ELEMENT_PARAM* pTransactionArray = (T_SPI_TRANSACTION_ELEMENT_PARAM*) pBufIn;
				bResult = DoSPITransactionADS7843((T_SPI_OPEN_STRUCTURE *)hOpenContext,*((UCHAR *)pBufIn), (WORD*)pBufOut,dwLenOut);
				if (bResult)
					*pdwActualOut = dwLenOut;
				
			}
			else
			{
				DEBUGMSG(DEBUGSPI9263EK, (TEXT("SPI_IOControl - Bad parameters\r\n")));			}

	}
	else
	{
		bResult = SPI_IOControl(hOpenContext, dwCode, pBufIn, dwLenIn, pBufOut, dwLenOut, pdwActualOut );
	}
	HWSPIControllerBoardSpecificReleaseBus();

	return bResult;
}








//! @}

////////////////////////////////////////////////////////////////////////////////
// End of $RCSfile: spi.c,v $
////////////////////////////////////////////////////////////////////////////////
//


//! @}
