//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		ATMEL\AT91SAM926x\KERNEL\POWER\power.c
//!
//! \brief		AT91SAM926x's power-related (suspend-related) features
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/POWER/power.c $
//!   $Author: pblanchard $
//!   $Revision: 1068 $
//!   $Date: 2007-07-09 08:55:44 -0700 (Mon, 09 Jul 2007) $
//! \endif
//-----------------------------------------------------------------------------

//! \addtogroup	POWER
//! @{

#include <windows.h>
#include <nkintr.h>
#include <oal.h>
#include "AT91SAM926x_oal_intr.h"
#include "at91sam926x_interface.h"
#include "at91sam926x_timebomb.h"

extern DWORD PowerProcSpecificGetPMCBaseAddress(void);
extern DWORD PowerProcSpecificGetCKGRBaseAddress(void);
extern void OEMRefreshWatchDog(void);

//-----------------------------------------------------------------------------
//! \fn			DWORD OEMPowerManagerInit(void)
//!
//! \brief		This function handles the initialization routines used by the kernel's suspend code
//!
//!
//!
//! \return		Always False
//-----------------------------------------------------------------------------
DWORD OEMPowerManagerInit(void)
{
    DWORD sysIntr;

	TIMEBOMB_INIT_ONCE(DEFAULT_TIME_BOMB);

    RETAILMSG(1,(TEXT("+OEMPowerManagerInit\r\n")));
    //Clear the wakeup sources' list
    for (sysIntr = SYSINTR_FIRMWARE; sysIntr < SYSINTR_MAXIMUM; sysIntr++) 
    {		
        OALIoCtlHalDisableWake(0,&sysIntr,sizeof(sysIntr),0,0,0);
    }	
	RETAILMSG(1,(TEXT("-OEMPowerManagerInit\r\n")));
	return 0;
}


extern UINT64 GetAndUpdateRTCValue(BOOL);

//-----------------------------------------------------------------------------
//! \fn			void OEMPowerOff()
//!
//! \brief		Called when the system is in transition to its lowest power mode (off)
//!				TODO : Specific functions is not implemented and not called yet
//! 
//!
//!
//!
//-----------------------------------------------------------------------------
void OEMPowerOff()
{     
	DWORD sysIntr;
	DWORD dwSavePCConfig, dwSaveSCConfig;
	
	TIMEBOMB_CHECK(L"Power Off");

#ifdef RTC_IS_BASED_ON_RTT
	//Refresh the RTC so that the counter is reset
	GetAndUpdateRTCValue(TRUE);
#endif	

	INTERRUPTS_OFF();
    
    // First do platform specific actions
    BSPPowerOff(&dwSavePCConfig,&dwSaveSCConfig);
    
    //This takes care of saving the AIC and PIOs interrupt mask and disable every interrupt
    SOCSaveAndDisableAllIntrBeforeSuspend();


    //Enable wake-up sources interrupts
    for (sysIntr = SYSINTR_FIRMWARE; sysIntr < SYSINTR_MAXIMUM; sysIntr++) {
        // Skip if sysIntr isn't allowed as wake source
        if (OALPowerWakeSource(sysIntr))
        {
            // Enable it as interrupt
            OEMInterruptEnable(sysIntr, NULL, 0);
			RETAILMSG(1, (L"OALPowerWakeSource enable %x\r\n",sysIntr));

        }        
    }
    
    // Go to power off mode
    OALCPUPowerOff();

    //This takes care of restoring the AIC and PIOs interrupt mask
    SOCRestoreAllIntrAfterSuspend();
  
    // Complete platform specific actions
    BSPPowerOn(dwSavePCConfig,dwSaveSCConfig);    
    
    INTERRUPTS_ON();
}


//-----------------------------------------------------------------------------
//! \fn			void OALCPUPowerOff()
//!
//! \brief		This function is called to stop the processor execution
//! 
//!
//!
//!
//-----------------------------------------------------------------------------
void OALCPUPowerOff()
{
    extern volatile UINT32 g_oalLastSysIntr;
#ifndef FAKE_IDLE
	DWORD plla,pllb,mck;
//	DWORD pc,sc;
	DWORD DELAY=1000;//no idea of possible value
	AT91PS_PMC pPMC = OALPAtoVA((DWORD)AT91C_BASE_PMC,FALSE);
	AT91PS_CKGR pCKGR = OALPAtoVA((DWORD) AT91C_BASE_CKGR, FALSE);
#endif
	
//	RETAILMSG(1,(TEXT("OALCPUPowerOff\r\n")));

	g_oalLastSysIntr = SYSINTR_NOP;
	
#ifndef FAKE_IDLE

// save settings	
	pllb = pCKGR->CKGR_PLLBR;
	plla = pCKGR->CKGR_PLLAR;
   mck = pPMC->PMC_MCKR;
//	pc=pPMC->PMC_PCSR;
//	sc=pPMC->PMC_SCSR;

//	RETAILMSG(1,(TEXT("pc = 0x%X, sc = 0x%X\r\n"),pc,sc));

  // The stopping of the unecessary clock is done in the board specific code (function BSPPowerOff)
  // because it depends of the behavior of the specific board.
//	pPMC->PMC_PCDR= 0x1FF8;
//	pPMC->PMC_SCDR= 0xFFFE;
   
	 pPMC->PMC_MCKR = AT91C_PMC_MDIV_2  | AT91C_PMC_CSS_SLOW_CLK|AT91C_PMC_PRES_CLK;

	// Waiting that MasterClock is stable
   	while ((pPMC->PMC_SR & AT91C_PMC_MCKRDY) == 0);
 
 
   // Desactivate PLLA et B
	pCKGR->CKGR_PLLAR = 0x3f00;
	pCKGR->CKGR_PLLBR = 0x3f00;
	//turn off oscillator

	pCKGR->CKGR_MOR &= ~AT91C_CKGR_MOSCEN;
#endif

	
    
	INTERRUPTS_ON();
    
	do
    {
        
#ifdef FAKE_IDLE
        // Wait until interrupt handler set interrupt flag
        while (g_oalLastSysIntr == SYSINTR_NOP)
		{
#ifndef OAL_NO_WATCHDOG
			OEMRefreshWatchDog();
#endif
		}
#else
      
		AT91SAM926x_SuspendWaitForInterrupt(&(pPMC->PMC_SCDR));
		  
#endif  
       OEMInterruptDone(g_oalLastSysIntr);

	} while (OALPowerWakeSource(g_oalLastSysIntr) == FALSE); 

#ifndef FAKE_IDLE

	//turn on oscillator
	pCKGR->CKGR_MOR |=AT91C_CKGR_MOSCEN;

	//restart 
	 pCKGR->CKGR_PLLBR = pllb;  
	 pCKGR->CKGR_PLLAR = plla;
   // Wait for PLL stabilization LOCK bit in PMC_SR 
	while( !(pPMC->PMC_SR & AT91C_PMC_LOCKB) );
	while( !(pPMC->PMC_SR & AT91C_PMC_LOCKA) );
	// Selection of Master Clock MCK (so Processor Clock PCK)

   pPMC->PMC_MCKR = mck;
   while( !(pPMC->PMC_SR & AT91C_PMC_MCKRDY));

//	pPMC->PMC_PCER=pc;
//	pPMC->PMC_SCER=sc;

#endif
 
    INTERRUPTS_OFF();    
}

    
//-----------------------------------------------------------------------------
//! \fn		BOOL OALIoCtlHalPresuspend(	UINT32 code, VOID *pInpBuffer, UINT32 inpSize, VOID *pOutBuffer,UINT32 outSize, UINT32 *pOutSize)
//!
//! \brief		This function implements the IOCTL_HAL_SUSPEND IOControl
//!				Suspend is not implemented yet
//!
//!	\param		code		not used
//!	\param		pInpBuffer	not used
//!	\param		inpSize		not used
//!	\param		pOutBuffer	not used
//!	\param		outSize		not used
//!	\param		pOutSize	not used
//!
//! \return		TRUE indicates success
//! \return		FALSE indicates failure (bad parameters)
//!
//-----------------------------------------------------------------------------
BOOL OALIoCtlHalPresuspend(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer, 
    UINT32 outSize, UINT32 *pOutSize
) {
    return TRUE;
}


//! @} end of subgroup POWER

//! @} end of group OAL

////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/POWER/power.c $
////////////////////////////////////////////////////////////////////////////////
//
