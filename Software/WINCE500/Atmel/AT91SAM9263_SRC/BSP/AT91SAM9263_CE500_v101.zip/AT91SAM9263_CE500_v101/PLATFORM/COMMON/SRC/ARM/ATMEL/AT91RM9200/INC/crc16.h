//-----------------------------------------------------------------------------
//! \addtogroup	MISC
//! @{
//!  
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		crc16.h
//!
//!
//! Header for crc16 lib
//-----------------------------------------------------------------------------


#ifndef _CRC16_H_
#define _CRC16_H_

unsigned short crc16_ccitt(unsigned char *buf, int len);

#endif
 /* _CRC16_H_ */

// End of Doxygen group crc16
//! @}
                  