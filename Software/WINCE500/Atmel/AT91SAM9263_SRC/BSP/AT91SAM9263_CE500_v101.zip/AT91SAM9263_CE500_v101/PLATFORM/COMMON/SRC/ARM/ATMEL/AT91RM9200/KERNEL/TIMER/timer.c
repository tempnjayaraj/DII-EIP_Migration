//-----------------------------------------------------------------------------
//! \addtogroup   OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				timer.c
//!
//! \brief				The system timer management
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/KERNEL/TIMER/timer.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

#include <windows.h>
#include <nkintr.h>
#include <oal.h>

#include "AT91RM9200_interface.h"
#include "AT91RM9200.h"
#include "AT91RM9200_oal_timer.h"
#include "AT91RM9200_oal_intr.h"

//Table contains number of counts per second in TIMER_CLOCKx entry of timer counter
UINT32 g_tabMCKdivPerMSec[5];

//Pointer to Timer Counter controller
AT91PS_TC g_pTC = NULL;

//Selection clock entering in TC
#define AT91C_TC_MCLK_DIV2		0
#define AT91C_TC_MCLK_DIV8		1
#define AT91C_TC_MCLK_DIV32		2
#define AT91C_TC_MCLK_DIV128	3
#define AT91C_TC_SLOWCLK		4

//Select which Timer Counter is used is used
#define AT91C_BASE_TC AT91C_BASE_TC0

//-----------------------------------------------------------------------------
//! \fn BOOL OALTimerInit (UINT32 msecPerSysTick, UINT32 countsPerMSec, UINT32 countsMargin)
//!
//!	\brief Initialize timer counter to generate IT every msecPerSysTick millisecond and start it
//!
//!	\param msecPerSysTick	Number of milliseconds between 2 IT
//!	\param countsPerMSec	Number of counts (sharpness) by milliseconds
//!	\param countsMargin		not used
//!
//!	\return TRUE
//! 
//-----------------------------------------------------------------------------
BOOL OALTimerInit (UINT32 msecPerSysTick, UINT32 countsPerMSec, UINT32 countsMargin)
{

    AT91PS_SYS pSYS = NULL;
	
	DEBUGMSG(1,(TEXT("+OALTimerInit\r\n")));	
	g_tabMCKdivPerMSec[AT91C_TC_MCLK_DIV2] = (AT91RM9200_GetMasterClock(FALSE/* do not use Shadow*/)/2 );
	g_tabMCKdivPerMSec[AT91C_TC_MCLK_DIV8] = (AT91RM9200_GetMasterClock(FALSE/* do not use Shadow*/)/8 );
	g_tabMCKdivPerMSec[AT91C_TC_MCLK_DIV32] = (AT91RM9200_GetMasterClock(FALSE/* do not use Shadow*/)/32 );
	g_tabMCKdivPerMSec[AT91C_TC_MCLK_DIV128] = (AT91RM9200_GetMasterClock(FALSE/* do not use Shadow*/)/128 );
	g_tabMCKdivPerMSec[AT91C_TC_SLOWCLK] = ( SLOW_CLOCK_FREQUENCY );

    //Sanity check
    if (!(msecPerSysTick > 0))
    {
        msecPerSysTick = 1;                       
    }
    	
    // Initialize timer state global variable.
    g_oalTimer.countsPerMSec          = g_tabMCKdivPerMSec[AT91C_TC_MCLK_DIV2] / 1000;
	g_oalTimer.maxPeriodMSec          = (((1<<16)-1) * 1000 / g_tabMCKdivPerMSec[AT91C_TC_SLOWCLK] );

    
    if (msecPerSysTick < g_oalTimer.maxPeriodMSec) //Clip the period to its maximum value if needed
    {        
        g_oalTimer.msecPerSysTick         = msecPerSysTick;                      
    } else {
        g_oalTimer.msecPerSysTick         = g_oalTimer.maxPeriodMSec;                      
    }
    
    g_oalTimer.countsPerSysTick       = (g_oalTimer.countsPerMSec * g_oalTimer.msecPerSysTick);
    
	// Actual parameters are equal to default parameters
	g_oalTimer.actualMSecPerSysTick   = g_oalTimer.msecPerSysTick;
    g_oalTimer.actualCountsPerSysTick = g_oalTimer.countsPerSysTick;
    
    g_oalTimer.countsMargin           = countsMargin;
    g_oalTimer.curCounts              = 0;
    
    // Initialize kernel-exported values.
    idleconv     = 1;
    curridlehigh = 0;
	curridlelow = 0;

    // Initialize high resolution timer function pointers
    pQueryPerformanceFrequency = OALTimerQueryPerformanceFrequency;
    pQueryPerformanceCounter   = OALTimerQueryPerformanceCounter;   
	//pOEMUpdateRescheduleTime   = OALTimerUpdateRescheduleTime;

	RETAILMSG(1,(TEXT("g_oalTimer.msecPerSysTick : 0x%x\r\n"),g_oalTimer.msecPerSysTick));
	RETAILMSG(1,(TEXT("g_oalTimer.countsPerMSec : 0x%x\r\n"),g_oalTimer.countsPerMSec));
	RETAILMSG(1,(TEXT("g_oalTimer.countsMargin : 0x%x\r\n"),g_oalTimer.countsMargin));
	RETAILMSG(1,(TEXT("g_oalTimer.maxPeriodMSec : 0x%x\r\n"),g_oalTimer.maxPeriodMSec));
	RETAILMSG(1,(TEXT("g_oalTimer.countsPerSysTick : 0x%x\r\n"),g_oalTimer.countsPerSysTick));
	RETAILMSG(1,(TEXT("g_oalTimer.actualMSecPerSysTick : 0x%x\r\n"),g_oalTimer.actualMSecPerSysTick));
	RETAILMSG(1,(TEXT("g_oalTimer.actualCountsPerSysTick : 0x%x\r\n"),g_oalTimer.actualCountsPerSysTick));
	RETAILMSG(1,(TEXT("g_oalTimer.curCounts : 0x%x\r\n"),g_oalTimer.curCounts));
	
	if (g_pTC == NULL)
    {
        g_pTC = OALPAtoVA((DWORD) AT91C_BASE_TC,FALSE);
    }

	if (pSYS == NULL)
    {
        pSYS = (AT91PS_SYS) OALPAtoVA((DWORD) AT91C_BASE_SYS,FALSE);
	}

	g_pTC->TC_IDR = AT91C_TC_CPCS ;  // Interrupt disable Register
	

	pSYS->PMC_PCER = ((unsigned int) 1 << AT91C_ID_TC0);

	//First of all, disable the TC.
	g_pTC->TC_CCR = AT91C_TC_CLKDIS;

	g_pTC->TC_CMR = AT91C_TC_MCLK_DIV2 | AT91C_TC_WAVE | AT91C_TC_WAVESEL_UP_AUTO;

/*! \note Rc is loaded with newly converted interval.
*/		
	g_pTC->TC_RC = g_oalTimer.countsPerSysTick;


/*! \note An interrupt is fired when RC compare occurs
*/
	g_pTC->TC_IER = AT91C_TC_CPCS;

	// Enable the timer and reset it
	g_pTC->TC_CCR = AT91C_TC_CLKEN | AT91C_TC_SWTRG;

	SOCEnableIrq(AT91C_ID_TC0);

	
	DEBUGMSG(1,(TEXT("-OALTimerInit\r\n")));
	
    return(TRUE);
}

//-----------------------------------------------------------------------------
//! \fn INT32 OALTimerCountsSinceSysTick()
//!
//!	\brief return number of counts since last IT occured
//!
//!	\return Number of counts since last IT occured
//! 
//-----------------------------------------------------------------------------
INT32 OALTimerCountsSinceSysTick()
{
	return g_pTC->TC_CV;
}

//-----------------------------------------------------------------------------
//! \fn void UpdateCounters(INT32 countSinceSysTick)
//!
//!	\brief Update 2 counters required by oal. One for current count, 1 for current millisecond.
//!
//!	\param countSinceSysTick Number of counts since last IT occured
//! 
//-----------------------------------------------------------------------------
void UpdateCounters(INT32 countSinceSysTick)
{
	CurMSec += ((countSinceSysTick*g_oalTimer.actualMSecPerSysTick)/g_oalTimer.actualCountsPerSysTick);
	g_oalTimer.curCounts += ( ((UINT64)countSinceSysTick * g_oalTimer.actualCountsPerSysTick)/g_oalTimer.countsPerSysTick);
}

//-----------------------------------------------------------------------------
//! \fn UINT32 OALTimerEnterIdle(UINT32 period, UINT32 margin)
//!
//!	\brief this function is called from OEMIdle when period of sysTick can be enlarged
//!
//!	\param	period	New period (in millisecond) between 2 sysTick, between 2 IT
//!
//!	\return 0
//! 
//-----------------------------------------------------------------------------
UINT32 OALTimerEnterIdle(UINT32 period)
{
	UINT8 clock;
	BOOL bIntrEnabled = INTERRUPTS_ENABLE(FALSE);

	//First of all, disable the TC.
	g_pTC->TC_CCR = AT91C_TC_CLKDIS;

	//Update counter before tick changed
	UpdateCounters(OALTimerCountsSinceSysTick());

	//compute which clock divider is necessary
	if(period< (((1<<16)-1) * 1000 / g_tabMCKdivPerMSec[AT91C_TC_MCLK_DIV2] ) )
	{
			clock = AT91C_TC_MCLK_DIV2;
	}
	else if(period<(((1<<16)-1) * 1000 / g_tabMCKdivPerMSec[AT91C_TC_MCLK_DIV8] ))
	{
		clock = AT91C_TC_MCLK_DIV8;
	}
	else if(period<(((1<<16)-1) * 1000 / g_tabMCKdivPerMSec[AT91C_TC_MCLK_DIV32] ))
	{
		clock = AT91C_TC_MCLK_DIV32;
	}
	else if(period<(((1<<16)-1) * 1000 / g_tabMCKdivPerMSec[AT91C_TC_MCLK_DIV128] ))
	{
		clock = AT91C_TC_MCLK_DIV128;
	}
	else
	{
		if(period>=(((1<<16)-1) * 1000 / g_tabMCKdivPerMSec[AT91C_TC_SLOWCLK] ))
		{
			period = (((1<<16)-1) * 1000 / g_tabMCKdivPerMSec[AT91C_TC_SLOWCLK] ) - 1;
		}
		clock = AT91C_TC_SLOWCLK;
	}
	
    // Actual parameters update
	g_oalTimer.actualMSecPerSysTick   = period;
    g_oalTimer.actualCountsPerSysTick = (g_tabMCKdivPerMSec[clock] * g_oalTimer.actualMSecPerSysTick / 1000);
   
	//EdbgOutputDebugString("OALTimerEnterIdle: P:%d, RC:%d, CL:%d\r\n",period,g_oalTimer.actualCountsPerSysTick,clock);
    

	g_pTC->TC_CMR =  clock | AT91C_TC_WAVE | AT91C_TC_WAVESEL_UP_AUTO;

	/*! \note Rc is loaded with newly converted interval.
	*/		
	g_pTC->TC_RC = g_oalTimer.actualCountsPerSysTick;

	/*! \note An interrupt is fired when RC compare occurs
	*/
	g_pTC->TC_IER = AT91C_TC_CPCS;

	// Enable the timer and reset it
	g_pTC->TC_CCR = AT91C_TC_CLKEN | AT91C_TC_SWTRG;

	INTERRUPTS_ENABLE(bIntrEnabled);
	
	return 0;
}

//-----------------------------------------------------------------------------
//! \fn UINT32 OALTimerExitFromIdle(UINT32 period, UINT32 margin)
//!
//!	\brief this function is called from OEMIdle when period of sysTick has been enlarged and must return to normal
//!
//!	\return 0
//! 
//-----------------------------------------------------------------------------
UINT32 OALTimerExitFromIdle()
{
	BOOL bIntrEnabled = INTERRUPTS_ENABLE(FALSE);
	//RETAILMSG(1,(TEXT("OALTimerExitFromIdle")));
	
	//First of all, disable the TC.
	g_pTC->TC_CCR = AT91C_TC_CLKDIS;

	//Update counter before tick changed
	UpdateCounters(OALTimerCountsSinceSysTick());

    // Restore original values
    g_oalTimer.actualMSecPerSysTick = g_oalTimer.msecPerSysTick;
    g_oalTimer.actualCountsPerSysTick = g_oalTimer.countsPerSysTick; 

	g_pTC->TC_CMR = AT91C_TC_MCLK_DIV2 | AT91C_TC_WAVE | AT91C_TC_WAVESEL_UP_AUTO;

	/*! \note Rc is loaded with newly converted interval.
	*/		
	g_pTC->TC_RC = g_oalTimer.countsPerSysTick;

	/*! \note An interrupt is fired when RC compare occurs
	*/
	g_pTC->TC_IER = AT91C_TC_CPCS;

	// Enable the timer and reset it
	g_pTC->TC_CCR = AT91C_TC_CLKEN | AT91C_TC_SWTRG;

	INTERRUPTS_ENABLE(bIntrEnabled);

	return 0;	
}

//-----------------------------------------------------------------------------
//! \fn UINT32 OALTimerIntrHandlerWithILTSupport(DWORD dwCountSinceSysTick)
//!
//!	\brief This function implement timer interrupt handler. It is called from common
//!			ARM interrupt handler.
//!
//!	\param	dwCountSinceSysTick Number of count since SysTick occured. Used for compute IT latence in ILT SUpport.
//!
//!	\return last Sysintr occured
//! 
//-----------------------------------------------------------------------------

UINT32 OALTimerIntrHandlerWithILTSupport(DWORD dwCountSinceSysTick)
{
	DWORD sysIntr = SYSINTR_UNDEFINED;
	//Just in case the BSP handles the nested interrupts, make sure that we'rent going to be interrupted while playing with the timer
	
	//Acknoledge interrupt
	if(!(g_pTC->TC_SR & AT91C_TC_CPCS))
	{
		//RETAILMSG(1,(TEXT("OALTimer Error")));		
	}	
	else
	{
		CurMSec += g_oalTimer.actualMSecPerSysTick;
		g_oalTimer.curCounts += g_oalTimer.countsPerSysTick;		

#ifdef OAL_ILTIMING
		if (g_oalILT.active) {
			if (--g_oalILT.counter == 0) {
				sysIntr = SYSINTR_TIMING;
				g_oalILT.counter = g_oalILT.counterSet;
				g_oalILT.isrTime1 = dwCountSinceSysTick;
				g_oalILT.isrTime2 = OALTimerCountsSinceSysTick();			
			}
		}
#endif
	}

	if (sysIntr == SYSINTR_UNDEFINED)
	{
		if ((int) (CurMSec - dwReschedTime) >= 0)
		{
			sysIntr = SYSINTR_RESCHED;
		}
	}
	return sysIntr;
}


//! @}
