//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9263/KERNEL/TIMER/timer.c
//!
//! \brief		AT91SAM9263 processor's timer
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/KERNEL/TIMER/timer.c $
//!   $Author: ltourlonias $
//!   $Revision: 684 $
//!   $Date: 2007-04-13 14:35:48 +0200 (ven., 13 avr. 2007) $
//! \endif
//-----------------------------------------------------------------------------


#include <windows.h>

#include "at91sam926x.h"

DWORD TimerProcSpecificGetPMCBaseAddress(void)
{
	return (DWORD) AT91C_BASE_PMC;
}

DWORD TimerProcSpecificGetPITCBaseAddress(void)
{
	return (DWORD) AT91C_BASE_PITC;
}

DWORD TimerProcSpecificGetSYSId(void)
{
	return (DWORD) AT91C_ID_SYS;
}

//------------------------------------------------------------------------------

//! @}


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/KERNEL/TIMER/timer.c $
////////////////////////////////////////////////////////////////////////////////
//
