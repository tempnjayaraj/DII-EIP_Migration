//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
// All rights reserved ADENEO SAS 2005
//!
//! \file 	custom_keypad.cpp
//!
//! \brief		Stream driver for the Keypad embedded on the AT91SAM9263EK EvalBoard
//! 
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/KeyPad/custom_keypad.cpp $
//!   $Author: pblanchard $
//!   $Revision: 959 $
//!   $Date: 2007-06-07 16:26:37 +0200 (jeu., 07 juin 2007) $
//! \endif
//
// The keypad driver is a DLL loaded by DeviceManager, named KPD.
// It is a stream driver (KPD1), with some dummy functions (Open, Close, Read, Write, Seek, IOControl).
// It is not loaded by GWES, using the Layout Manager.
// It is written in C++. (class KeyPad)
// It works from an IST, sending keyboard events with PostKeybdMessage().
// It can be unloaded using "s unmountdrv KPD1:" and reloaded using "s activateDevice BuiltIn\KEYPAD"
//
//-----------------------------------------------------------------------------

//! \addtogroup	Keypad
//! @{
//
// System include
#include <windows.h>
#include <nkintr.h>
#include <ceddk.h>
#include <devload.h>
#include "AT91SAM9263_oal_intr.h"


// Local include
#include "custom_keypad.hpp"
#include "at91sam9263_gpio.h"

//------------------------------------------------------------------------------
// Defines
//
#define KEYPAD_POLLING_TIMEOUT_NAME		(TEXT("PollingTimeout"))
#define KEYPAD_KEY_NAME_FORMAT			(TEXT("KEY%d"))
#define KEYPAD_PIO_NAME_FORMAT			(TEXT("KEY%d_PIO"))



#define POLLING_TIME_OUT_DEFAULT		15 // in milliseconds
#define KEYPRESSURE_TIME				 2
//------------------------------------------------------------------------------
// Externs
//
extern "C" PVOID VirtualAllocCopyPhysical(unsigned size,char *str,PVOID pPhysicalAddress);

//------------------------------------------------------------------------------
// Global Variables
//
static DWORD g_dwSysIntr_WakeUp ;//wake up sysintr
static HANDLE g_hEvent_WakeUp;	
//------------------------------------------------------------------------------
// Local Variables
//

//------------------------------------------------------------------------------
// Local Functions
//
KeyPad* CustomKeyPadInit ()
{
	return new CustomKeyPad();
}

CustomKeyPad::CustomKeyPad()
{
	m_dwKeysStates = NULL;

	// Clear
	memset(m_dwKeysGPio, 0x00, sizeof(m_dwKeysGPio));

}

BOOL CustomKeyPad::RegQueryDword (HKEY hKey, LPWSTR lpKeyName, DWORD *pdwValue)
{
	BOOL bRet = FALSE;
	LONG lResult = 0;
	DWORD dwSize = sizeof(DWORD);

	lResult = RegQueryValueEx(hKey, lpKeyName, NULL, NULL, (LPBYTE)pdwValue, &dwSize);

	if (lResult == ERROR_SUCCESS)
	{
		bRet = TRUE;
	}

	return bRet;
}


// Get Keypad keys assignement from registry
void CustomKeyPad::GetKeysAssignement(HKEY hKey)
{
	WCHAR pStr[255];
	DWORD dwKeyIndex = 0;
	DWORD dwVKeyValue = 0;
	BOOL bNoError = FALSE;

	// Clear buffer
	memset(pStr, 0x00, sizeof(pStr));

	// Detect the numbers of keys, and get the associated VKEY for each key
	do
	{
		// Generate key
		swprintf((wchar_t *)pStr, KEYPAD_KEY_NAME_FORMAT, dwKeyIndex);
		
		// Get the Key VKEY
		bNoError = RegQueryDword (hKey, (wchar_t *)pStr, &dwVKeyValue);

		// Store the key values
		if (bNoError)
		{
			m_KeypadKeyToVKey[dwKeyIndex] = (UCHAR)dwVKeyValue;
			m_dwNbKeypadKeys = dwKeyIndex + 1;

			DEBUGMSG(1,(TEXT("CustomKeyPad::GetKeysAssignement : Key : %d, VKey : 0x%X\r\n"), dwKeyIndex, dwVKeyValue));
			
			dwKeyIndex++;
		}
		else
		{
			DEBUGMSG(1,(TEXT("CustomKeyPad::GetKeysAssignement : No more Key descriptions available in registry : %d\r\n"), dwKeyIndex));
		}


	} while ((bNoError) && (dwKeyIndex <= KEYPAD_MAX_KEY_NUMBER));

}

// Get Keypad keys GPIO assignement from registry
BOOL CustomKeyPad::GetGPIOAssignement(HKEY hKey)
{
	WCHAR pStr[255] = TEXT("\0");
	DWORD dwKeyIndex = 0;
	DWORD dwGPIOValue = 0;
	BOOL bNoError = TRUE;

	// Clear buffer
	memset(pStr, 0x00, sizeof(pStr));


	// Get the GPIO assigned to each key
	for (dwKeyIndex = 0 ; (dwKeyIndex < m_dwNbKeypadKeys) && bNoError ; dwKeyIndex++)
	{
		// Generate key
		swprintf((wchar_t *)pStr, KEYPAD_PIO_NAME_FORMAT, dwKeyIndex);
		
		// Get the Key VKEY
		bNoError = RegQueryDword (hKey, (wchar_t *)pStr, &dwGPIOValue);

		if (bNoError)
		{
			m_dwKeysGPio[dwKeyIndex] = dwGPIOValue;

			DEBUGMSG(1,(TEXT("CustomKeyPad::GetGPIOAssignement : Key : %d, GPIO : %d\r\n"), dwKeyIndex, dwGPIOValue));
		}
		else
		{
			ERRORMSG(1,(TEXT("CustomKeyPad::GetGPIOAssignement : No GPIO assigned to Key : %d\r\n"), dwKeyIndex));
		}
	}


	return bNoError;
}

// Set pios as input
void CustomKeyPad::GPiosInit()
{
	DWORD dwIndex;
	struct pio_desc hw_pio;

	for (dwIndex = 0; dwIndex < m_dwNbKeypadKeys; dwIndex++)
	{
		hw_pio.pin_num = m_dwKeysGPio[dwIndex];
		hw_pio.attribute = PIO_PULLUP;
		hw_pio.type = PIO_INPUT;

		pio_setup(&hw_pio, sizeof(hw_pio)/sizeof(struct pio_desc));
		
	}
}


//
// /note This function perform the following steps
//       1) Get registry entry if needed
//		 2) Assign the m_dwSysintr value (optional) for key pressure detection
//			 - if not used m_dwSysintr must be SYSINTR_UNDIFINED
//		 3) Assign the m_dwPollingTimeOut (optional) to
//			 - if not used m_dwPollingTimeOut must be INFINITE
//		 4) Allocate and fill the m_KeypadKeyToVKey variable with the VKEY assignement
//		 5) Do not mised to set m_dwNbKeypadKeys to the value of m_KeypadKeyToVKey elements
//
BOOL CustomKeyPad::CustomInitialize(LPCTSTR pContext)
{
	BOOL bRet = TRUE;
	HKEY hKey;
	DWORD dwValue;
	BOOL bStatus;

	// code to set BP3 as the wake up source	
	DWORD dwLogIntr_WakeUp    = (LOGINTR_BASE_PIOC + 5)    ;
	DWORD dwResult;
	
	g_hEvent_WakeUp = CreateEvent(NULL,FALSE,FALSE,NULL);
	if (g_hEvent_WakeUp == NULL)
		
	{
		DEBUGMSG(1 ,(TEXT(" Cannot create interrupt Event, we're going to use polling ! \r\n")));                         
	}
	
	if(!KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &dwLogIntr_WakeUp   , sizeof(dwLogIntr_WakeUp   ), &g_dwSysIntr_WakeUp   , sizeof(g_dwSysIntr_WakeUp   ), 0))
	{
		DEBUGMSG(1, (TEXT("IOCTL_HAL_REQUEST_SYSINTR failed\n\r")));
	}
	
	if(!KernelIoControl(IOCTL_HAL_ENABLE_WAKE, &g_dwSysIntr_WakeUp   , sizeof(g_dwSysIntr_WakeUp   ), &dwResult   , sizeof(dwResult   ), 0))
	{
		DEBUGMSG(1, (TEXT("IOCTL_HAL_ENABLE_WAKE failed\n\r")));
	}
	
	if (InterruptInitialize(g_dwSysIntr_WakeUp, g_hEvent_WakeUp, 0, 0) == FALSE)
		
	{
		DEBUGMSG(1 ,(TEXT(" Cannot initialize the interrupt ! \r\n")));                                                  
	}


	// Load KeypadKeys assignement
	hKey = OpenDeviceKey (pContext);

	if (hKey == NULL )
	{
		ERRORMSG(1,(TEXT("CustomKeyPad::Initialize Unable to open device registry entry\r\n")));
		bRet = FALSE;
	}

	// Get Key assignement from registry
	if (bRet)
	{
		GetKeysAssignement(hKey);
		
		// Clear the keys states table
		m_dwKeysStates = new DWORD[m_dwNbKeypadKeys];
		memset(m_dwKeysStates, 0x00, m_dwNbKeypadKeys * sizeof(DWORD));

		bRet = GetGPIOAssignement(hKey);
	}

	
  
	if (bRet)
	{
		// No Sysintr need
		m_dwSysintr = SYSINTR_UNDEFINED;
		
		//
		bStatus = RegQueryDword (hKey, KEYPAD_POLLING_TIMEOUT_NAME, &dwValue);
		if (bStatus)
		{
			m_dwPollingTimeOut = dwValue;
		}
		else
		{
			m_dwPollingTimeOut = POLLING_TIME_OUT_DEFAULT;
		}

	}

	// Set PIO as intput
	GPiosInit();
	

	// Close registry key
	if ((hKey != NULL) && (RegCloseKey(hKey) != ERROR_SUCCESS))
	{
		bRet = FALSE;
	}


	return bRet;
}


BOOL CustomKeyPad::CustomDeinitialize() 
{
	if (m_dwKeysStates != NULL)
	{
		delete m_dwKeysStates;
	}

	return TRUE;
}


BOOL CustomKeyPad::KeyPadPowerOff(void)
{
	RETAILMSG(1,(TEXT("KeyPadPowerOff customclass\r\n")));
	InterruptDone(g_dwSysIntr_WakeUp);
	return TRUE;
}
BOOL CustomKeyPad::KeyPadPowerOn(void)
{
	RETAILMSG(1,(TEXT("KeyPadPowerOn customclass\r\n")));
	InterruptDone(g_dwSysIntr_WakeUp);
	return TRUE;
}


// Get the keypad keys state (1 bit for each key)
// To avoid mecanical rebounds, the Key must be seen X time pressed before indicating as pressed to the driver
DWORD CustomKeyPad::GetKeypadState(void)
{
	DWORD dwIndex;
	DWORD dwKeyPadKeysState;
	DWORD dwGPIOState;


  	dwKeyPadKeysState = 0;

	for (dwIndex = 0 ; dwIndex < m_dwNbKeypadKeys ; dwIndex++)
	{
		// Get the Pio Status
		// 1 the key is released, 0 the key is pressed
		dwGPIOState = pio_get_value(m_dwKeysGPio[dwIndex]);
		if (dwGPIOState == 0)
		{
			// The key is pressed, so increase the keystate conter
			m_dwKeysStates[dwIndex] += 1;

			if (m_dwKeysStates[dwIndex] >= KEYPRESSURE_TIME)
			{
				dwKeyPadKeysState |= (1 << dwIndex);
			}
		}
		else
		{
			m_dwKeysStates[dwIndex] = 0;
		}
	}


	return dwKeyPadKeysState;
}

//! @}

//! @}
