//-----------------------------------------------------------------------------
//! \addtogroup   Serial
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				AT91RM9200_SerialDriver.c
//!
//! \brief				Interface for MDD serial driver
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/DRIVERS/Serial/AT91RM9200_SerialDriver.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

// System include
#include <windows.h>
#include <memory.h>
#include <nkintr.h>
#include <CEDDK.h>
#include <devload.h>
#include <Serhw.h>

// Local include
#include <AT91RM9200.h>
#include <lib_AT91RM9200.h>
#include "AT91RM9200_Serial_DbgZones.h"
#include "AT91RM9200_SerialDriver.h"
#include "AT91RM9200_oal_ioctl.h"


extern DWORD g_dwMaxSerialDevices;
const HW_VTBL SerIoVTbl;
DWORD g_dwMasterClock;


//-----------------------------------------------------------------------------
VOID AT91SERIAL_SetBreak(T_SERIALINIT_STRUCTURE *pInitContext);
VOID AT91SERIAL_ClearBreak(T_SERIALINIT_STRUCTURE *pInitContext);
VOID AT91SERIAL_SetDTR(T_SERIALINIT_STRUCTURE *pInitContext);
VOID AT91SERIAL_ClearDTR(T_SERIALINIT_STRUCTURE *pInitContext);
VOID AT91SERIAL_SetRTS(T_SERIALINIT_STRUCTURE *pInitContext);
VOID AT91SERIAL_ClearRTS(T_SERIALINIT_STRUCTURE *pInitContext);
BOOL AT91SERIAL_SetParity(T_SERIALINIT_STRUCTURE *pInitContext, DWORD dwParity);
BOOL AT91SERIAL_SetStopBits(T_SERIALINIT_STRUCTURE *pInitContext, DWORD dwStopBits);
BOOL AT91SERIAL_SetByteSize(T_SERIALINIT_STRUCTURE *pInitContext, DWORD dwByteSize);
VOID AT91SERIAL_SetCommTimeouts(T_SERIALINIT_STRUCTURE *pInitContext, LPCOMMTIMEOUTS lpCommTimeouts);
BOOL AT91SERIAL_SetBaudRate (T_SERIALINIT_STRUCTURE *pInitContext, DWORD dwBaudRate);
BOOL AT91SERIAL_SetMode(T_SERIALINIT_STRUCTURE *pInitContext, DWORD dwfRtsControl, DWORD dwfDtrControl);
DWORD AT91SERIAL_ReadCSR(T_SERIALINIT_STRUCTURE *pInitContext);
VOID AT91SERIAL_ClearCSR(T_SERIALINIT_STRUCTURE *pInitContext);
//-----------------------------------------------------------------------------

extern void EnableInt(void);
extern void DisableInt(void);
//-----------------------------------------------------------------------------
//! \brief	Implements custom IOControls that are not intercepted by the MDD
//!
//! \param	pInitContext	Instance's Context
//! \param	dwCode			Command code
//! \param	pBufIn			pointer to a buffer where is stored the input data
//! \param	dwLenIn			size of the input data
//! \param	pBufOut			pointer to a buffer where the output data is going to be stored
//! \param	dwLenOut		maximum size of the output data
//! \param	pdwActualOut	pointer to a DWORD where's going to be stored the final size of the output data
//!
//!
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//!
//! 
//-----------------------------------------------------------------------------
BOOL AT91_HWIoctl(T_SERIALINIT_STRUCTURE *pInitContext, DWORD dwCode,PBYTE pBufIn,DWORD dwLenIn, PBYTE pBufOut,DWORD dwLenOut,PDWORD pdwActualOut)
{
	BOOL bRet = FALSE;


	return bRet;
}



//-----------------------------------------------------------------------------
//! \fn		BOOL AT91_HWSetCommTimeouts(T_SERIALINIT_STRUCTURE *pInitContext, LPCOMMTIMEOUTS lpCommTO)
//!
//! \brief		Sets the DCB Line
//!
//! \param		pInitContext	Initialization context (gives access to the controller)
//! \param		lpCommTO		Timeouts' structure	
//!
//!
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//!
//! 
//-----------------------------------------------------------------------------
BOOL AT91_HWSetCommTimeouts(T_SERIALINIT_STRUCTURE *pInitContext, LPCOMMTIMEOUTS lpCommTO)
{	
	BOOL bRet = FALSE;
	DWORD dwTO = 0;
#define MAX_TIMEOUT_REG_VALUE 0xFFFF

	if (pInitContext == NULL || lpCommTO == NULL)
	{
		DEBUGMSG(DBG_FUNCTION|DBG_ERROR, (TEXT("+AT91_HWSetCommTimeouts : Bad parameters.\r\n")));
		return FALSE;
	}

	// Compute TimeOut register value
	dwTO = (lpCommTO->ReadIntervalTimeout * pInitContext->dcb.BaudRate) / 1000;

	// Check boundcing value
	if (lpCommTO->ReadIntervalTimeout != 0 && dwTO == 0)
	{
		dwTO = 0x01;
	}
	else if (dwTO > MAX_TIMEOUT_REG_VALUE)
	{
		dwTO = MAX_TIMEOUT_REG_VALUE;
	}
	
	//
	EnterCriticalSection (&pInitContext->csUsartReg);

	pInitContext->pUSARTReg->US_RTOR = dwTO;

	//
	LeaveCriticalSection (&pInitContext->csUsartReg);
	bRet = TRUE;

	return bRet;
}




//-----------------------------------------------------------------------------
//! \fn		BOOL AT91_HWSetDCB(T_SERIALINIT_STRUCTURE *pInitContext, LPDCB pDCB)
//!
//! \brief		Set the DCB (structure describing the settings of the serial port)
//!
//! \param		pInitContext	Initialization context (gives access to the controller)
//! \param		pDCB			DCB structure	
//!
//!
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//!
//! 
//-----------------------------------------------------------------------------
BOOL AT91_HWSetDCB(T_SERIALINIT_STRUCTURE *pInitContext, LPDCB pDCB)
{
	
	BOOL bRet = TRUE;
	BOOL bDCBOK = TRUE;
	
	//	DEBUGMSG(1, (L"entree AT91_HWSetDCB"));
	
	if (pInitContext == NULL || pDCB == NULL)
	{
		DEBUGMSG(DBG_FUNCTION|DBG_ERROR, (TEXT("+AT91_HWSetDCB : Bad parameters.\r\n")));
		return FALSE;
	}
	
	
	DEBUGMSG(DBG_FUNCTION, (TEXT("+AT91_HWSetDCB.\r\n")));
	
	DEBUGMSG(DBG_FUNCTION,(TEXT("AT91_HWSetDCB : ------------ old ------------\r\n")));
	DEBUGMSG(DBG_FUNCTION,(TEXT("AT91_HWSetDCB : BaudRate		: %d\r\n"), pInitContext->dcb.BaudRate));
	DEBUGMSG(DBG_FUNCTION,(TEXT("AT91_HWSetDCB : ByteSize		: %d\r\n"), pInitContext->dcb.ByteSize));
	DEBUGMSG(DBG_FUNCTION,(TEXT("AT91_HWSetDCB : Parity			: %d\r\n"), pInitContext->dcb.Parity));
	DEBUGMSG(DBG_FUNCTION,(TEXT("AT91_HWSetDCB : StopBits		: %d\r\n"), pInitContext->dcb.StopBits));
	DEBUGMSG(DBG_FUNCTION,(TEXT("AT91_HWSetDCB : ------------- new ------------\r\n")));
	DEBUGMSG(DBG_FUNCTION,(TEXT("AT91_HWSetDCB : BaudRate		: %d\r\n"), pDCB->BaudRate));
	DEBUGMSG(DBG_FUNCTION,(TEXT("AT91_HWSetDCB : ByteSize		: %d\r\n"), pDCB->ByteSize));
	DEBUGMSG(DBG_FUNCTION,(TEXT("AT91_HWSetDCB : Parity			: %d\r\n"), pDCB->Parity));
	DEBUGMSG(DBG_FUNCTION,(TEXT("AT91_HWSetDCB : StopBits		: %d\r\n"), pDCB->StopBits));
	DEBUGMSG(DBG_FUNCTION,(TEXT("AT91_HWSetDCB : ------------------------------\r\n")));
	
	
	// Test if the DCB is available
	if( (pDCB->BaudRate == 75) | (pDCB->BaudRate == 110) | (pDCB->BaudRate == 300) | (pDCB->BaudRate == 600) | (pDCB->BaudRate == 1200)
		| (pDCB->BaudRate == 2400) | (pDCB->BaudRate == 4800) | (pDCB->BaudRate == 7200) | (pDCB->BaudRate == 9600) | (pDCB->BaudRate == 14400)
		| (pDCB->BaudRate == 19200) | (pDCB->BaudRate == 38400) | (pDCB->BaudRate == 56000) | (pDCB->BaudRate == 128000) | (pDCB->BaudRate == 115200)
		| (pDCB->BaudRate == 57600) )
	{
	}
	else
	{
		bDCBOK = FALSE;
	}
	
	if ( (pDCB->ByteSize < 5) | (pDCB->ByteSize >8) )
	{
		bDCBOK = FALSE;
	}
	
	if ( (pDCB->Parity != EVENPARITY) & (pDCB->Parity != MARKPARITY) & (pDCB->Parity != NOPARITY) 
		& (pDCB->Parity != ODDPARITY) & (pDCB->Parity != SPACEPARITY) ) 
	{
		bDCBOK = FALSE;
	}
	
	if ( (pDCB->StopBits != ONESTOPBIT) & (pDCB->StopBits != ONE5STOPBITS) & (pDCB->StopBits != TWOSTOPBITS) )
	{
		bDCBOK = FALSE;
	}
	
	
	if (bDCBOK == TRUE)
	{
		// If the device is open, scan for changes and do whatever
		// is needed for the changed fields.  if the device isn't
		// open yet, just save the DCB for later use by the open.
		if (pInitContext->dwOpenCount > 0)
		{
			// Update only modified parameters
			
			if (pInitContext->dcb.BaudRate != pDCB->BaudRate)
			{
				bRet = AT91SERIAL_SetBaudRate(pInitContext, pDCB->BaudRate);
				DEBUGMSG(DBG_FUNCTION, (TEXT(" AT91_HWSetDCB : New Baud Rate = %d.\r\n"), pDCB->BaudRate));
			}
			
			if (bRet && pInitContext->dcb.ByteSize != pDCB->ByteSize)
			{
				bRet = AT91SERIAL_SetByteSize(pInitContext, pDCB->ByteSize);
				DEBUGMSG(DBG_FUNCTION, (TEXT(" AT91_HWSetDCB : New Byte Size = %d.\r\n"), pDCB->ByteSize));
			}
			
			if (bRet && pInitContext->dcb.StopBits != pDCB->StopBits)
			{
				bRet = AT91SERIAL_SetStopBits(pInitContext, pDCB->StopBits);
				DEBUGMSG(DBG_FUNCTION, (TEXT(" AT91_HWSetDCB : New Stop Bits = %d.\r\n"), pDCB->StopBits));
			}
			
			if (bRet && pInitContext->dcb.Parity != pDCB->Parity)
			{
				bRet = AT91SERIAL_SetParity(pInitContext, pDCB->Parity);
				DEBUGMSG(DBG_FUNCTION, (TEXT(" AT91_HWSetDCB : New Parity = %d.\r\n"), pDCB->Parity));
			}
			
			// Change the UART mode
			if (bRet && 
				((pInitContext->dcb.fRtsControl != pDCB->fRtsControl) || 
				 (pInitContext->dcb.fDtrControl != pDCB->fDtrControl) ))
			{
				AT91SERIAL_SetMode(pInitContext, pDCB->fRtsControl, pDCB->fDtrControl);
				DEBUGMSG(DBG_FUNCTION, (TEXT(" AT91_HWSetDCB : New Mode = %X.\r\n"), (pInitContext->pUSARTReg->US_MR & AT91C_US_USMODE)));

			}		
		}
		
		// Save DCB
		if (bRet)
		{
			pInitContext->dcb = *pDCB;
		}
	}
	else
	{
		bRet=FALSE;
	}
	DEBUGMSG(DBG_FUNCTION, (TEXT("-AT91_HWSetDCB.\r\n")));
	
	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn		VOID AT91_HWPurgeComm(T_SERIALINIT_STRUCTURE *pInitContext, DWORD fdwAction)
//!
//! \brief		clear/abort the FIFOs according to the parameter
//!
//! \param		pInitContext	Initialization context (gives access to the controller)
//! \param		fdwAction		Action to perform (clear/abort read or write fifo)
//!
//! 
//-----------------------------------------------------------------------------
VOID AT91_HWPurgeComm(T_SERIALINIT_STRUCTURE *pInitContext, DWORD fdwAction)
{
	DWORD dwPDCEnabled = 0;

	if (pInitContext == NULL)
	{
		DEBUGMSG(DBG_FUNCTION|DBG_ERROR, (TEXT("+AT91_HWPurgeComm : Bad parameters.\r\n")));
	}

	//
	EnterCriticalSection (&pInitContext->csUsartReg);


	// RX Purge and abort
	if (fdwAction & (PURGE_RXABORT | PURGE_RXCLEAR))
	{
		// Store PDC 
		dwPDCEnabled = pInitContext->pUSARTReg->US_PTSR & AT91C_PDC_RXTEN;

		// Stop Rx
		pInitContext->pUSARTReg->US_PTCR = AT91C_PDC_RXTDIS;

		// Reset PDC counter and pointers
		pInitContext->pUSARTReg->US_RPR = pInitContext->pDMACommonRxBuffer[pInitContext->dwCurrentRxBuffer].LowPart;
		pInitContext->pUSARTReg->US_RCR = GET_RCR_SIZE;

		pInitContext->pUSARTReg->US_RNPR = pInitContext->pDMACommonRxBuffer[pInitContext->dwCurrentRxBuffer].LowPart + GET_RCR_SIZE;
		pInitContext->pUSARTReg->US_RNCR = GET_RNCR_SIZE;

		// Enable PDC
		if (dwPDCEnabled)
		{
			pInitContext->pUSARTReg->US_PTCR = AT91C_PDC_RXTEN;
		}
	}

	// TX Purge and abort
	if (fdwAction & (PURGE_TXABORT | PURGE_TXCLEAR))
	{
		// Store PDC 
		dwPDCEnabled = pInitContext->pUSARTReg->US_PTSR & AT91C_PDC_TXTEN;

		// Stop Rx
		pInitContext->pUSARTReg->US_PTCR = AT91C_PDC_TXTDIS;

		// Reset PDC counter and pointers
		pInitContext->pUSARTReg->US_TPR = 0;
		pInitContext->pUSARTReg->US_TCR = 0;

		pInitContext->pUSARTReg->US_TNPR = 0;
		pInitContext->pUSARTReg->US_TNCR = 0;

		// Enable PDC
		if (dwPDCEnabled)
		{
			pInitContext->pUSARTReg->US_PTCR = AT91C_PDC_TXTEN;
		}
	}
	
	//
	LeaveCriticalSection (&pInitContext->csUsartReg);

}


//-----------------------------------------------------------------------------
//! \fn		VOID AT91_HWGetCommProperties(T_SERIALINIT_STRUCTURE *pInitContext, LPCOMMPROP pCommProp)
//!
//! \brief		Set the COMM properties
//!
//! \param		pInitContext	Initialization context (gives access to the controller)
//! \param		pCommProp		Comm Properties
//!
//! 
//-----------------------------------------------------------------------------
VOID AT91_HWGetCommProperties(T_SERIALINIT_STRUCTURE *pInitContext, LPCOMMPROP pCommProp)
{

	if (pInitContext == NULL)
	{
		DEBUGMSG(DBG_FUNCTION|DBG_ERROR, (TEXT("+AT91_HWGetCommProperties : Bad parameters.\r\n")));
	}

	DEBUGMSG(DBG_FUNCTION, (TEXT("+AT91_HWGetCommProperties\r\n")));
	
	*pCommProp = pInitContext->commProp;

}


//-----------------------------------------------------------------------------
//! \fn		VOID AT91_HWGetModemStatus(T_SERIALINIT_STRUCTURE *pInitContext, PULONG pModemStatus)
//!
//! \brief		Retrieve the modem's status
//!
//! \param		pInitContext	Initialization context (gives access to the controller)
//! \param		pModemStatus	pointer to a DWORD where the status is going to be written
//!
//! 
//-----------------------------------------------------------------------------
VOID AT91_HWGetModemStatus(T_SERIALINIT_STRUCTURE *pInitContext, PULONG pModemStatus)
{
	DWORD dwModemStatus = 0;

	if (pInitContext == NULL || pModemStatus == NULL)
	{
		DEBUGMSG(DBG_FUNCTION|DBG_ERROR, (TEXT("+AT91_HWGetModemStatus : Bad parameters.\r\n")));
	}

	//
	EnterCriticalSection (&pInitContext->csUsartReg);

	
	//dwModemStatus = pInitContext->dwIntRemModemStatus;

	dwModemStatus = AT91SERIAL_ReadCSR(pInitContext);

	DEBUGMSG(1, (L"CSR= 0x%06X", dwModemStatus));

	if (dwModemStatus & AT91C_US_CTS)
	{
		*pModemStatus &= ~MS_CTS_ON; 
	}
	else
	{
		*pModemStatus |= MS_CTS_ON; 
	}

	if (dwModemStatus & AT91C_US_DSR)
	{
		*pModemStatus &= ~MS_DSR_ON; 
	}
	else
	{
		*pModemStatus |= MS_DSR_ON; 
	}

	if (dwModemStatus & AT91C_US_RI)
	{
		*pModemStatus &= ~MS_RING_ON; 
	}
	else
	{
		*pModemStatus |= MS_RING_ON; 
	}

	if (dwModemStatus & AT91C_US_DCD)
	{
		*pModemStatus &= ~MS_RLSD_ON; 
	}
	else
	{
		*pModemStatus |= MS_RLSD_ON; 
	}
	//
	LeaveCriticalSection (&pInitContext->csUsartReg);

}

//-----------------------------------------------------------------------------
//! \fn		VOID AT91_HWReset(T_SERIALINIT_STRUCTURE *pInitContext)
//!
//! \brief		reset the controller
//!
//! \param		pInitContext	Initialization context (gives access to the controller)
//!
//! 
//-----------------------------------------------------------------------------
VOID AT91_HWReset(T_SERIALINIT_STRUCTURE *pInitContext)
{

	if (pInitContext == NULL)
	{
		DEBUGMSG(DBG_FUNCTION|DBG_ERROR, (TEXT("+AT91_HWReset : Bad parameters.\r\n")));
	}

	DEBUGMSG(DBG_FUNCTION, (TEXT("+AT91_HWReset.\r\n")));

	//
	EnterCriticalSection (&pInitContext->csUsartReg);

	// Resets the status bits PARE, FRAME, OVRE and RXBRK in the US_CSR.
	pInitContext->pUSARTReg->US_CSR = AT91C_US_RSTSTA;

	//
	LeaveCriticalSection (&pInitContext->csUsartReg);

	DEBUGMSG(DBG_FUNCTION, (TEXT("-AT91_HWReset.\r\n")));

}



//-----------------------------------------------------------------------------
//! \fn		ULONG AT91_HWGetStatus(T_SERIALINIT_STRUCTURE *pInitContext, LPCOMSTAT lpStat)
//!
//! \brief		Get the status of device (not implemented)
//!
//! 
//-----------------------------------------------------------------------------
DWORD AT91_HWGetStatus(T_SERIALINIT_STRUCTURE *pInitContext, LPCOMSTAT lpStat)
{
	ULONG ulReturn = (ULONG)-1;
	DWORD dwCSRReg;
    if (pInitContext && lpStat) 
	{
		dwCSRReg = AT91SERIAL_ReadCSR(pInitContext);
        lpStat->fCtsHold = pInitContext->dcb.fOutxCtsFlow && (dwCSRReg & AT91C_US_CTS)?0:1;
        lpStat->fDsrHold = pInitContext->dcb.fOutxDsrFlow && (dwCSRReg & AT91C_US_DSR)?0:1;
        // NOTE - I think what they really want to know here is
        // the amount of data in the MDD buffer, not the amount
        // in the UART itself.  Just set to 0 for now since the
        // MDD doesn't take care of this.
        lpStat->cbInQue = 0;
        lpStat->cbOutQue = 0;
        ulReturn = 0;
    }        
    return ulReturn;
}


//-----------------------------------------------------------------------------
//! \fn		BOOL AT91_HWXmitComChar(T_SERIALINIT_STRUCTURE *pInitContext, UCHAR ComChar)
//!
//! \brief		Immediate transmit of a character
//!
//! \param		pInitContext	Initialization context (gives access to the controller)
//! \param		ComChar			character to transmit
//!
//!
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//!
//! 
//-----------------------------------------------------------------------------
BOOL AT91_HWXmitComChar(T_SERIALINIT_STRUCTURE *pInitContext, UCHAR ComChar)
{
	BOOL bRet = FALSE;
	DWORD dwPDCTxEnabled = 0;

#define TX_TIMEOUT	2	// 2 ms
	DWORD dwStartTime = 0;

	if (pInitContext == NULL)
	{
		DEBUGMSG(DBG_FLOW|DBG_ERROR, (TEXT("+AT91_HWXmitComChar : Bad parameters.\r\n")));
		return FALSE;
	}

	DEBUGMSG(DBG_FLOW, (TEXT("+AT91_HWXmitComChar\r\n")));
	
	//
	EnterCriticalSection (&pInitContext->csUsartReg);


	// Store PDC status
	dwPDCTxEnabled = pInitContext->pUSARTReg->US_PTSR & AT91C_PDC_TXTEN;

	// Desable PDC Tx
	pInitContext->pUSARTReg->US_PTCR = AT91C_PDC_TXTDIS;


	// Wait end of the current Tx
	dwStartTime = GetTickCount ();
	do {

		// Tx Data register ready ?
		if (pInitContext->pUSARTReg->US_CSR & AT91C_US_TXRDY)
		{
			// Put the char in the Tx register
			pInitContext->pUSARTReg->US_THR = ComChar;
			bRet = TRUE;
			break;

		}
	} while ((GetTickCount() - dwStartTime) < TX_TIMEOUT);


	// Enable PDC Tx
	if (dwPDCTxEnabled)
	{
		pInitContext->pUSARTReg->US_PTCR = AT91C_PDC_TXTEN;
	}


	// 
	LeaveCriticalSection (&pInitContext->csUsartReg);


	DEBUGMSG(DBG_FLOW, (TEXT("-AT91_HWXmitComChar.\r\n")));

	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn		VOID AT91_HWSetBreak(T_SERIALINIT_STRUCTURE *pInitContext)
//!
//! \brief	Set the break condition
//!
//! \param		pInitContext	Initialization context (gives access to the controller)
//!
//!
//! 
//-----------------------------------------------------------------------------
VOID AT91_HWSetBreak(T_SERIALINIT_STRUCTURE *pInitContext)
{
	if (pInitContext == NULL)
	{
		return;
	}

	if (pInitContext->pfnSetBreak != NULL)
		pInitContext->pfnSetBreak(pInitContext->pHardwareContext);
	else
		AT91SERIAL_SetBreak(pInitContext);


}


//-----------------------------------------------------------------------------
//! \fn		VOID AT91_HWClearBreak(T_SERIALINIT_STRUCTURE *pInitContext)
//!
//! \brief		Clear the break condition
//!
//! \param		pInitContext	Initialization context (gives access to the controller)
//!
//!
//! 
//-----------------------------------------------------------------------------
VOID AT91_HWClearBreak(T_SERIALINIT_STRUCTURE *pInitContext)
{
	if (pInitContext == NULL)
	{
		return;
	}

	if (pInitContext->pfnClearBreak != NULL)
		pInitContext->pfnClearBreak(pInitContext->pHardwareContext);
	else
		AT91SERIAL_ClearBreak(pInitContext);


}

//-----------------------------------------------------------------------------
//! \fn		BOOL AT91_HWDisableIR(T_SERIALINIT_STRUCTURE *pInitContext)
//!
//! \brief		Disable the IR mode (Not supported)
//! \param		pInitContext	Initialization context (gives access to the controller)
//!
//!	\return		\e FALSE indicates failure
//!
//! 
//-----------------------------------------------------------------------------
BOOL AT91_HWDisableIR(T_SERIALINIT_STRUCTURE *pInitContext)
{
	DEBUGMSG(DBG_IR, (TEXT("+AT91_HWDisableIR : IRMode Not supported.\r\n")));
	return FALSE;
}


//-----------------------------------------------------------------------------
//! \fn		BOOL AT91_HWEnableIR(T_SERIALINIT_STRUCTURE *pInitContext, ULONG BaudRate)
//!
//! \brief		Enable  the IR mode (Not supported)
//!
//! \param		pInitContext	Initialization context (gives access to the controller)
//! \param		BaudRate		Baudrate of the IR communication
//!
//!
//!	\return		\e FALSE indicates failure
//! 
//-----------------------------------------------------------------------------
BOOL AT91_HWEnableIR(T_SERIALINIT_STRUCTURE *pInitContext, ULONG BaudRate)
{
	DEBUGMSG(DBG_IR, (TEXT("+AT91_HWEnableIR : IRMode Not supported.\r\n")));
	return FALSE;
}


//-----------------------------------------------------------------------------
//! \fn		VOID AT91_HWSetRTS(T_SERIALINIT_STRUCTURE *pInitContext)
//!
//! \brief		Set the RTS Line
//!
//! \param		pInitContext	Initialization context (gives access to the controller)
//!
//!
//-----------------------------------------------------------------------------
VOID AT91_HWSetRTS(T_SERIALINIT_STRUCTURE *pInitContext)
{
	if (pInitContext == NULL)
	{
		return;
	}

	if (pInitContext->pfnSetRTS != NULL)
		pInitContext->pfnSetRTS(pInitContext->pHardwareContext);
	else
		AT91SERIAL_SetRTS(pInitContext);


}


//-----------------------------------------------------------------------------
//! \fn		VOID AT91_HWClearRTS(T_SERIALINIT_STRUCTURE *pInitContext)
//!
//! \brief		Clear the RTS Line
//!
//! \param		pInitContext	Initialization context (gives access to the controller)
//!
//! 
//-----------------------------------------------------------------------------
VOID AT91_HWClearRTS(T_SERIALINIT_STRUCTURE *pInitContext)
{
	if (pInitContext == NULL)
	{
		return;
	}

	if (pInitContext->pfnClearRTS != NULL)
		pInitContext->pfnClearRTS(pInitContext->pHardwareContext);
	else
		AT91SERIAL_ClearRTS(pInitContext);
}


//-----------------------------------------------------------------------------
//! \fn		VOID AT91_HWSetDTR(T_SERIALINIT_STRUCTURE *pInitContext)
//!
//! \brief		Set the DTR Line
//!
//! \param		pInitContext	Initialization context (gives access to the controller)
//!
//! 
//-----------------------------------------------------------------------------
VOID AT91_HWSetDTR(T_SERIALINIT_STRUCTURE *pInitContext)
{
	if (pInitContext == NULL)
	{
		return;
	}

	if (pInitContext->pfnSetDTR != NULL)
		pInitContext->pfnSetDTR(pInitContext->pHardwareContext);
	else
		AT91SERIAL_SetDTR(pInitContext);
}


//-----------------------------------------------------------------------------
//! \fn		VOID AT91_HWClearDTR(T_SERIALINIT_STRUCTURE *pInitContext)
//!
//! \brief		Clear the DTR Line
//!
//! \param		pInitContext	Initialization context (gives access to the controller)
//! 
//-----------------------------------------------------------------------------
VOID AT91_HWClearDTR(T_SERIALINIT_STRUCTURE *pInitContext)
{
	if (pInitContext == NULL)
	{
		return;
	}

	if (pInitContext->pfnClearDTR != NULL)
		pInitContext->pfnClearDTR(pInitContext->pHardwareContext);
	else
		AT91SERIAL_ClearDTR(pInitContext);
}


//-----------------------------------------------------------------------------
//! \fn		BOOL AT91_HWPowerOn(T_SERIALINIT_STRUCTURE *pInitContext)
//!
//! \brief		Turn the controller ON
//!
//! \param		pInitContext	Initialization context (gives access to the controller)
//!
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//! 
//-----------------------------------------------------------------------------
BOOL AT91_HWPowerOn(T_SERIALINIT_STRUCTURE *pInitContext)
{
	BOOL bRet = TRUE;

	// Note: No debug messages in power handlers !!!

	if (pInitContext == NULL)
	{
		return FALSE;
	}

	// Enable periph clock
	AT91F_PMC_EnablePeriphClock(pInitContext->pPMCReg, 1 << pInitContext->dwDeviceId);


	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn		BOOL AT91_HWPowerOff(T_SERIALINIT_STRUCTURE *pInitContext)
//!
//! \brief		Turn the controller OFF
//!
//! \param		pInitContext	Initialization context (gives access to the controller)
//!
//!
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//!
//! 
//-----------------------------------------------------------------------------
BOOL AT91_HWPowerOff(T_SERIALINIT_STRUCTURE *pInitContext)
{
	BOOL bRet = TRUE;

	// Note: No debug messages in power handlers !!!

	if (pInitContext == NULL)
	{
		return FALSE;
	}

	// Disable periph clock
	AT91F_PMC_DisablePeriphClock(pInitContext->pPMCReg, 1 << pInitContext->dwDeviceId);


	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn		ULONG AT91_HWGetRxBufferSize(T_SERIALINIT_STRUCTURE *pInitContext)	
//!
//! 
//-----------------------------------------------------------------------------
ULONG AT91_HWGetRxBufferSize(T_SERIALINIT_STRUCTURE *pInitContext)
{
	DEBUGMSG(DBG_EVENTS, (TEXT("+AT91_HWGetRxBufferSize.\r\n")));
	return 0;
}


//-----------------------------------------------------------------------------
//! \fn		VOID AT91_HWLineIntrHandler(T_SERIALINIT_STRUCTURE *pInitContext)
//!
//! 
//-----------------------------------------------------------------------------
VOID AT91_HWLineIntrHandler(T_SERIALINIT_STRUCTURE *pInitContext)
{

	//DEBUGMSG(DBG_EVENTS, (TEXT("+AT91_HWLineIntrHandler : Not implemented yet.\r\n")));

	if (pInitContext->dwIntRemModemStatus & AT91C_US_TIMEOUT)
	{
		DEBUGMSG(1, (L"Timeout received"));
	}
}


//-----------------------------------------------------------------------------
//! \fn		VOID AT91_HWModemIntrHandler(T_SERIALINIT_STRUCTURE *pInitContext)
//!
//!
//! 
//-----------------------------------------------------------------------------
VOID AT91_HWModemIntrHandler(T_SERIALINIT_STRUCTURE *pInitContext)
{
	ULONG fdwEventMask = 0;

	// Which signals are asserted ?
	if (pInitContext->dwIntRemModemStatus & AT91C_US_CTSIC)
	{
		// It is CTS signal
		fdwEventMask |= EV_CTS;
	}
	if (pInitContext->dwIntRemModemStatus & AT91C_US_DSRIC)
	{
		// It is DSR signal
		fdwEventMask |= EV_DSR;
	}
	if (pInitContext->dwIntRemModemStatus & AT91C_US_RIIC)
	{
		// It is RING signal
		fdwEventMask |= EV_RING;
	}

	if (pInitContext->dwIntRemModemStatus & AT91C_US_DCDIC)
	{
		// It is DCD signal
		fdwEventMask |= EV_RLSD;
	}

	if (pInitContext->dwIntRemModemStatus & AT91C_US_RXBRK)
	{
		// It is BREAK signal
		pInitContext->dwErrors |= CE_BREAK;
		fdwEventMask |= EV_BREAK;
		pInitContext->pUSARTReg->US_CR = AT91C_US_RSTSTA;
	}

	if (fdwEventMask != 0)
	{
		EvaluateEventFlag(pInitContext->pMDDContext, fdwEventMask);
	}
}


//-----------------------------------------------------------------------------
//! \fn		VOID  AT91_HWTxIntrHandler(T_SERIALINIT_STRUCTURE *pInitContext, PUCHAR pSrc, PULONG pBytes)
//!
//! 
//-----------------------------------------------------------------------------
VOID  AT91_HWTxIntrHandler(T_SERIALINIT_STRUCTURE *pInitContext, PUCHAR pSrc, PULONG pBytes)
{
	DWORD dwDataLength = 0;

	if ((pInitContext == NULL) || (pBytes == NULL))
	{
		DEBUGMSG(DBG_EVENTS|DBG_ERROR, (TEXT("+AT91_HWTIntrHandler : Bad function parameters.\r\n")));
		return;
	}


	// We  may be done sending. If so, we just desable the TX interrupts and return
	if (*pBytes == 0)
	{
		EnterCriticalSection (&pInitContext->csUsartReg);

		pInitContext->pUSARTReg->US_IDR =	AT91C_US_TXRDY | 
											AT91C_US_TXEMPTY | 
											AT91C_US_TXBUFE | 
											AT91C_US_ENDTX;			

		LeaveCriticalSection (&pInitContext->csUsartReg);

	}
	else
	{
	// Data to send
	
		// TODO : NBS :  Maybe we have to flushdone like at91_serial_hw.c ln 1155 of AT91RM9200 BSP ?
	
		// Check data to send size, the size could not exceed the DMA buffer size
		dwDataLength = (*pBytes) > SIZE_OF_PDC_TX_BUFFER ? SIZE_OF_PDC_TX_BUFFER : *pBytes;

		// Copy data to the DMA buffer
		memcpy(pInitContext->vDMACommonTxBuffer, pSrc, dwDataLength);

		
		EnterCriticalSection (&pInitContext->csUsartReg);
		
		// TODO : NBS : can increase device flow by adding a secondary tx pdc buffer, that should be used when 
		//				the device is busy

		// No transfert in progress yet
		if (pInitContext->pUSARTReg->US_TCR == 0)
		{
			pInitContext->pUSARTReg->US_TPR  = pInitContext->pDMACommonTxBuffer.LowPart;
			pInitContext->pUSARTReg->US_TCR  = dwDataLength;
			pInitContext->pUSARTReg->US_IER  = AT91C_US_ENDTX;
			pInitContext->pUSARTReg->US_CR   = AT91C_US_TXEN;
			*pBytes = dwDataLength;

		}
		else
		{
		// Device busy no data sent 
			*pBytes = 0;
		}


		LeaveCriticalSection (&pInitContext->csUsartReg);
	}
	return;
}


//-----------------------------------------------------------------------------
//! \fn		ULONG AT91_HWRxIntrHandler(T_SERIALINIT_STRUCTURE *pInitContext, PUCHAR pTarget, PULONG pBytes)
//!		
//!
//! 
//-----------------------------------------------------------------------------
ULONG AT91_HWRxIntrHandler(T_SERIALINIT_STRUCTURE *pInitContext, PUCHAR pTarget, PULONG pBytes)
{
	DWORD dwDiscarded = 0;
	DWORD dwNotYetDiscarded = 0;
	DWORD dwFreeSpace = 0;
	DWORD dwFirstRxCounter = 0; 
	DWORD dwNextRxCounter = 0;
	DWORD dwDataLength = 0;

	DWORD dwOldRxBuffer = 0;


	if (pInitContext == NULL || pTarget == NULL || pBytes == NULL)
	{
		DEBUGMSG(DBG_EVENTS|DBG_ERROR, (TEXT("+AT91_HWRxIntrHandler : Bad function parameters.\r\n")));
		return 0;
	}

	// Rx Buffer not initialized yet
	if (pInitContext->vDMACommonRxBuffer[pInitContext->dwCurrentRxBuffer] == 0x00)
	{
		DEBUGMSG(DBG_EVENTS|DBG_ERROR, (TEXT("+AT91_HWRxIntrHandler : Rx Buffer not initialized yet.\r\n")));
		return 0;
	}

	dwFreeSpace	= *pBytes;


	EnterCriticalSection (&pInitContext->csUsartReg);


	DisableInt();
	// Disable PDC rx
	pInitContext->pUSARTReg->US_PTCR = AT91C_PDC_RXTDIS;

	// Get receive data bytes quantity
	dwFirstRxCounter = pInitContext->pUSARTReg->US_RCR;
	dwNextRxCounter = pInitContext->pUSARTReg->US_RNCR;

	dwDataLength = (GET_RCR_SIZE + GET_RNCR_SIZE) - (dwFirstRxCounter + dwNextRxCounter);

	// No data to transmit to the mdd
	if (dwDataLength == 0)
	{
		// Re enable PDC rx
		pInitContext->pUSARTReg->US_PTCR = AT91C_PDC_RXTEN;

		EnableInt();

		LeaveCriticalSection (&pInitContext->csUsartReg);

		// No data
		*pBytes = 0;
		return 0;
	}

	// More data received than queries, left over data is copied to the beggining of the new pdc buffer
	// and a delta is applied to the beggining of this buffer to avoid over writing data.
	if (dwDataLength > dwFreeSpace)
	{
		
		dwNotYetDiscarded = dwDataLength - dwFreeSpace;
		dwDataLength = dwFreeSpace;		
		if (dwNotYetDiscarded > (SIZE_OF_PDC_FIFO - FIFO_THRESOLD))
		{
			dwDiscarded = dwNotYetDiscarded - (SIZE_OF_PDC_FIFO - FIFO_THRESOLD);
			//RETAILMSG(1,(TEXT("Serial : !!!!! Discarding %d bytes\r\n"),dwDiscarded));
			dwNotYetDiscarded = (SIZE_OF_PDC_FIFO - FIFO_THRESOLD);
		}
	}
	else
	{
		dwNotYetDiscarded = 0;
	}


	// Set next buffer index
	dwOldRxBuffer = pInitContext->dwCurrentRxBuffer;
	pInitContext->dwCurrentRxBuffer = (++pInitContext->dwCurrentRxBuffer) % RX_BUFFERS;


	// Set pdc buffers,  apply offset at beggining if necessary
	pInitContext->pUSARTReg->US_RPR = pInitContext->pDMACommonRxBuffer[pInitContext->dwCurrentRxBuffer].LowPart + dwNotYetDiscarded;
	pInitContext->pUSARTReg->US_RCR = GET_RCR_SIZE;

	pInitContext->pUSARTReg->US_RNPR = pInitContext->pUSARTReg->US_RPR + pInitContext->pUSARTReg->US_RCR;
	pInitContext->pUSARTReg->US_RNCR = FIFO_THRESOLD - GET_RCR_SIZE - dwNotYetDiscarded;


	// Re enable PDC rx
	pInitContext->pUSARTReg->US_PTCR = AT91C_PDC_RXTEN;

	EnableInt();

	// Copy the not yet dicarded data to the begginning of the pdc buffer (backup copy for next call from thr mdd to this function)
	if (dwNotYetDiscarded != 0)
	{
		DEBUGMSG(DBG_EVENTS|DBG_ERROR,(TEXT("dwNotYetDiscarded %d \r\n"),dwNotYetDiscarded));
		memcpy((LPBYTE)pInitContext->vDMACommonRxBuffer[pInitContext->dwCurrentRxBuffer], (LPBYTE)pInitContext->vDMACommonRxBuffer[dwOldRxBuffer] + dwDataLength, dwNotYetDiscarded);
	}


	// Store received data to the mdd buffer
	memcpy(pTarget, (LPBYTE)pInitContext->vDMACommonRxBuffer[dwOldRxBuffer], dwDataLength);

	*pBytes = dwDataLength;
	
	LeaveCriticalSection (&pInitContext->csUsartReg);

	return dwDiscarded;
}



//-----------------------------------------------------------------------------
//! \fn			BOOL AT91_HWGetIntrType (T_SERIALINIT_STRUCTURE *pInitContext)
//!
//! 
//-----------------------------------------------------------------------------
INTERRUPT_TYPE AT91_HWGetIntrType(T_SERIALINIT_STRUCTURE *pInitContext)
{
	INTERRUPT_TYPE itType = INTR_NONE;
	DWORD dwChannelStatus;
	DWORD CSRReg;
	DWORD IMRReg;

	if (pInitContext == NULL)
	{
		DEBUGMSG(DBG_EVENTS|DBG_ERROR, (TEXT("+AT91_HWGetIntrType : Bad pInitContext.\r\n")));
		return INTR_NONE;
	}

	EnterCriticalSection (&pInitContext->csUsartReg);

	CSRReg = AT91SERIAL_ReadCSR(pInitContext);
	AT91SERIAL_ClearCSR(pInitContext);
	IMRReg = pInitContext->pUSARTReg->US_IMR;
	dwChannelStatus = CSRReg & IMRReg;
	/*
	DEBUGMSG(DBG_EVENTS, (TEXT("+AT91_HWGetIntrType: CSR=0x%x, IMR=0x%x, status=0x%x\r\n"), CSRReg, IMRReg,
		dwChannelStatus));
*/
	LeaveCriticalSection (&pInitContext->csUsartReg);

	//
	if( dwChannelStatus & (AT91C_US_PARE | AT91C_US_FRAME | AT91C_US_OVRE  
							| AT91C_US_TIMEOUT	| AT91C_US_ITERATION))
	{
		if (dwChannelStatus & AT91C_US_OVRE)
		{
			DEBUGMSG (DBG_EVENTS, (TEXT(" AT91_HWGetIntrType : ERROR Overrun\r\n")));
		}
		if (dwChannelStatus & AT91C_US_PARE)
		{
			DEBUGMSG (DBG_EVENTS, (TEXT(" AT91_HWGetIntrType : ERROR Parity\r\n")));
		}
		if (dwChannelStatus & AT91C_US_FRAME)
		{
			DEBUGMSG (DBG_EVENTS, (TEXT(" AT91_HWGetIntrType : ERROR Framing\r\n")));
		}
		
		if (dwChannelStatus & AT91C_US_TIMEOUT)
		{
			DEBUGMSG (DBG_EVENTS, (TEXT(" AT91_HWGetIntrType : ERROR Timeout\r\n")));
		}
		if (dwChannelStatus & AT91C_US_ITERATION)
		{
			DEBUGMSG (DBG_EVENTS, (TEXT(" AT91_HWGetIntrType : ERROR Iteration\r\n")));
		}
		

		pInitContext->pUSARTReg->US_CR = AT91C_US_RSTSTA;
		itType |= INTR_LINE;  // Error status
	}

	if( dwChannelStatus & (AT91C_US_CTSIC | AT91C_US_DSRIC | AT91C_US_RIIC | AT91C_US_DCDIC | AT91C_US_RXBRK))  
	{
		DEBUGMSG (DBG_EVENTS, (TEXT(" AT91_HWGetIntrType : INTR_MODEM\r\n")));

		pInitContext->dwIntRemModemStatus = dwChannelStatus; // remember status, IC flags are needed in ModemIntHandle.
             // flags are cleared after read !
		itType |= INTR_MODEM;
	}

	if (dwChannelStatus & AT91C_US_RXBUFF)
	{
		//DEBUGMSG (DBG_EVENTS, (TEXT(" AT91_HWGetIntrType : AT91C_US_RXBUFF\r\n")));
	}

	if ((dwChannelStatus & (AT91C_US_ENDRX | AT91C_US_TIMEOUT)) && pInitContext->dwOpenCount ) {      
		if (dwChannelStatus & AT91C_US_TIMEOUT)
		{
			pInitContext->pUSARTReg->US_CR = AT91C_US_STTTO;
		}
		//DEBUGMSG (DBG_EVENTS, (TEXT(" AT91_HWGetIntrType : INTR_RX\r\n")));

		itType |= INTR_RX;    // Received valid data.
	}	
	if (dwChannelStatus & AT91C_US_ENDTX)  {
		//DEBUGMSG (DBG_EVENTS, (TEXT(" AT91_HWGetIntrType : INTR_TX\r\n")));

		itType |= INTR_TX;
	}	

/*	DEBUGMSG(DBG_EVENTS, (TEXT("+AT91_HWGetIntrType : interrupt type. INTR_NONE : %d, INTR_LINE : %d, INTR_RX %d, INTR_TX %d, INTR_MODEM %d\r\n"),
					       itType == INTR_NONE, (itType & INTR_LINE)?1:0, (itType & INTR_RX)?1:0,  (itType & INTR_TX)?1:0 , (itType & INTR_MODEM)?1:0));
*/
	return itType;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL AT91_HWClose (T_SERIALINIT_STRUCTURE *pInitContext)
//!
//! 
//-----------------------------------------------------------------------------
ULONG AT91_HWClose (T_SERIALINIT_STRUCTURE *pInitContext)
{
	ULONG ulRet = -1;
	int i = 0;

 	if (pInitContext == NULL)
	{
		DEBUGMSG(DBG_OPEN|DBG_ERROR, (TEXT("+AT91_HWClose : Bad pInitContext.\r\n")));
		return -1;
	}

	// Disallow multiple simultaneous opens
	if (pInitContext->dwOpenCount == 0)
	{
		DEBUGMSG(DBG_OPEN|DBG_ERROR, (TEXT("+AT91_HWClose : Device not opened. Open it first.\r\n")));
		return -1;
	}

	DEBUGMSG(DBG_OPEN, (TEXT("+AT91_HWClose : Close device.\r\n")));

	pInitContext->dwOpenCount --;

	if (pInitContext->vDMACommonTxBuffer != NULL)
	{
		HalFreeCommonBuffer (&pInitContext->dmaAdapter,
							 SIZE_OF_PDC_TX_BUFFER,
							 pInitContext->pDMACommonTxBuffer,
							 pInitContext->vDMACommonTxBuffer,
							 FALSE);
	}

	if (pInitContext->vDMACommonRxBuffer[0] != NULL)
	{
		HalFreeCommonBuffer (&pInitContext->dmaAdapter,
							 SIZE_OF_PDC_FIFO,
							 pInitContext->pDMACommonRxBuffer[0],
							 pInitContext->vDMACommonRxBuffer[0],
							 FALSE);
		
		for (i=1  ;  i < RX_BUFFERS  ;  i++)
		{
			pInitContext->vDMACommonRxBuffer[i] = NULL;
			pInitContext->pDMACommonRxBuffer[i].QuadPart = 0;
		}

	}

	EnterCriticalSection (&pInitContext->csUsartReg);

	
	// Desable IT and flow
	pInitContext->pUSARTReg->US_IDR = 0xFFFFFFFF;
	pInitContext->pUSARTReg->US_CR = AT91C_US_TXDIS | AT91C_US_RXDIS;
	pInitContext->pUSARTReg->US_CR = AT91C_US_RSTSTA | AT91C_US_STTTO | AT91C_US_RSTRX | AT91C_US_RSTTX;
	
	// Clear RTS
	if (pInitContext->pfnClearRTS != NULL)
	{
		pInitContext->pfnClearRTS(pInitContext->pHardwareContext);
	}
	else
		AT91SERIAL_ClearRTS(pInitContext);


	// Desable RX, TX
	pInitContext->pUSARTReg->US_CR = AT91C_US_RXDIS;
	pInitContext->pUSARTReg->US_CR = AT91C_US_TXDIS;


// TODO : NBS : disable PDC ????

	// Disable periph clock
	AT91F_PMC_DisablePeriphClock(pInitContext->pPMCReg, 1<< pInitContext->dwDeviceId);

	LeaveCriticalSection (&pInitContext->csUsartReg);

	DEBUGMSG(DBG_OPEN, (TEXT("+AT91_HWClose : Device closed.\r\n")));

	return ulRet;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL AT91_HWOpen (T_SERIALINIT_STRUCTURE *pInitContext)
//!
//! 
//-----------------------------------------------------------------------------
BOOL AT91_HWOpen (T_SERIALINIT_STRUCTURE *pInitContext)
{
	BOOL bRet = TRUE;
	DWORD dwDMAindex = 0;
	
	DWORD dwTempData = 0x00;

	if (pInitContext == NULL)
	{
		DEBUGMSG(DBG_OPEN|DBG_ERROR,(TEXT("+AT91_HWOpen : Bad pInitContext\r\n")));
		return FALSE;
	}

	// Disallow multiple simultaneous opens
	if (pInitContext->dwOpenCount > 0)
	{
		DEBUGMSG(DBG_OPEN|DBG_ERROR, (TEXT("+AT91_HWOpen : Device already opend; Close it first.\r\n")));
		return FALSE;
	}


	DEBUGMSG(DBG_OPEN,(TEXT("+AT91_HWOpen : Open device\r\n")));


	pInitContext->vDMACommonTxBuffer = NULL;
	pInitContext->vDMACommonRxBuffer[0] = NULL;

	// TX Buffers
	pInitContext->vDMACommonTxBuffer = HalAllocateCommonBuffer (&pInitContext->dmaAdapter,
																SIZE_OF_PDC_TX_BUFFER,
																&(pInitContext->pDMACommonTxBuffer),
																FALSE);

	// RX Buffers
	pInitContext->vDMACommonRxBuffer[0] = HalAllocateCommonBuffer (&pInitContext->dmaAdapter,
																   SIZE_OF_PDC_FIFO,
																   &(pInitContext->pDMACommonRxBuffer[0]),
																   FALSE);

	for (dwDMAindex=1  ;  dwDMAindex < RX_BUFFERS  ;  dwDMAindex++)
	{
		pInitContext->vDMACommonRxBuffer[dwDMAindex] = (((PCHAR)pInitContext->vDMACommonRxBuffer[0]) + (dwDMAindex * FIFO_THRESOLD));
		pInitContext->pDMACommonRxBuffer[dwDMAindex].QuadPart = (pInitContext->pDMACommonRxBuffer[0].QuadPart) + (dwDMAindex * FIFO_THRESOLD);
	}


	// Enable periph clock
	AT91F_PMC_EnablePeriphClock(pInitContext->pPMCReg, 1 << pInitContext->dwDeviceId);

	EnterCriticalSection (&pInitContext->csUsartReg);

	// Desable IT and flow
	pInitContext->pUSARTReg->US_IDR = 0xFFFFFFFF;
	pInitContext->pUSARTReg->US_CR = AT91C_US_TXDIS | AT91C_US_RXDIS;
	pInitContext->pUSARTReg->US_CR = AT91C_US_RSTSTA | AT91C_US_STTTO | AT91C_US_RSTRX | AT91C_US_RSTTX;

	// Set up the controller for a normal mode uart, using the parameters given in the DCB structure
	pInitContext->pUSARTReg->US_MR = AT91C_US_USMODE_NORMAL;
	
	// Set peripheral internal Clock to master clock
	pInitContext->pUSARTReg->US_MR |= AT91C_US_CLKS_CLOCK;


	// Get defaults from the DCB structure
	AT91SERIAL_SetBaudRate( pInitContext, pInitContext->dcb.BaudRate );
	AT91SERIAL_SetByteSize( pInitContext, pInitContext->dcb.ByteSize );
	AT91SERIAL_SetStopBits( pInitContext, pInitContext->dcb.StopBits );
	AT91SERIAL_SetParity  ( pInitContext, pInitContext->dcb.Parity );		


	dwTempData = pInitContext->pUSARTReg->US_RHR;
	pInitContext->pUSARTReg->US_CR = AT91C_US_RSTSTA | AT91C_US_STTTO;
	
	// Configure PDC
	pInitContext->pUSARTReg->US_PTCR = AT91C_PDC_TXTEN;
	pInitContext->pUSARTReg->US_PTCR = AT91C_PDC_RXTEN;
	
	pInitContext->pUSARTReg->US_CR = AT91C_US_RXEN;
	pInitContext->pUSARTReg->US_CR = AT91C_US_TXDIS;

	// PDC buffers initialisation
	pInitContext->dwCurrentRxBuffer = 0;

	pInitContext->pUSARTReg->US_RPR = pInitContext->pDMACommonRxBuffer[pInitContext->dwCurrentRxBuffer].LowPart;
	pInitContext->pUSARTReg->US_RCR = GET_RCR_SIZE;

	pInitContext->pUSARTReg->US_RNPR = pInitContext->pDMACommonRxBuffer[pInitContext->dwCurrentRxBuffer].LowPart + GET_RCR_SIZE;
	pInitContext->pUSARTReg->US_RNCR = GET_RNCR_SIZE;
	

	// Enable IT
	AT91F_US_EnableIt (pInitContext->pUSARTReg, pInitContext->dwIntMask);

	LeaveCriticalSection (&pInitContext->csUsartReg);

	pInitContext->dwOpenCount ++;

	DEBUGMSG(DBG_OPEN,(TEXT("-AT91_HWOpen : device opened\r\n")));
	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL AT91_HWDeinit(T_SERIALINIT_STRUCTURE *pInitContext)
//!
//! 
//-----------------------------------------------------------------------------
BOOL AT91_HWDeinit(T_SERIALINIT_STRUCTURE *pInitContext)
{
	BOOL bRet = TRUE;

	if (pInitContext == NULL)
		return FALSE;

	// Make sure device is closed before doing DeInit
	if ( pInitContext->dwOpenCount )
		AT91_HWClose( pInitContext );

	
	if (pInitContext->dwDeviceIndex != -1 && pInitContext->pHardwareContext != NULL)
	{
		HWSerialDeInit (pInitContext->pHardwareContext);
	}

	if (pInitContext->pPMCReg != NULL)
		MmUnmapIoSpace(pInitContext->pPMCReg, sizeof(AT91S_PMC));

	if (pInitContext->pUSARTReg != NULL)
		MmUnmapIoSpace(pInitContext->pUSARTReg, sizeof(AT91S_USART));

	if (pInitContext->pPDCReg != NULL)
		MmUnmapIoSpace(pInitContext->pPDCReg, sizeof(AT91S_PDC));

	DeleteCriticalSection (&pInitContext->csUsartReg);

	LocalFree (pInitContext->pHWObj);

	LocalFree (pInitContext);
	
	DEBUGMSG(ZONE_INIT,(TEXT("-AT91_HWDeinit : Deinit complete\r\n")));

	return bRet;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL AT91_HWPostInit(T_SERIALINIT_STRUCTURE *pInitContext)
//!
//! 
//-----------------------------------------------------------------------------
BOOL AT91_HWPostInit(T_SERIALINIT_STRUCTURE *pInitContext)
{
	BOOL bRet = TRUE;

	DEBUGMSG(ZONE_INIT,(TEXT("-AT91_HWPostInit.\r\n")));

	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL GetRegistryData (T_SERIALINIT_STRUCTURE *pInitContext, LPCTSTR regKeyPath)	
//!
//! 
//-----------------------------------------------------------------------------
BOOL GetRegistryData (T_SERIALINIT_STRUCTURE *pInitContext, LPCTSTR regKeyPath)
{
	BOOL bRet = TRUE;

#define REGISTRY_BUFFER_SIZE	256
	HKEY hKey;
	DWORD dwDataSize = REGISTRY_BUFFER_SIZE;
	LONG regError = ERROR_SUCCESS;

	// Parameters check
	if (pInitContext == NULL || regKeyPath == NULL)
		return FALSE;

	DEBUGMSG(DBG_INIT, (TEXT("Try to open %s\r\n"), regKeyPath));

	//
	hKey = OpenDeviceKey(regKeyPath);
	if ( hKey == NULL ) {
		DEBUGMSG(ZONE_INIT | ZONE_ERROR,(TEXT("Failed to open device key\r\n")));
		return FALSE;        
	}

	// Get the UART index associated to this driver
	dwDataSize = REG_SERIALPORTINDEX_VAL_LEN;
	regError = RegQueryValueEx(
					hKey, 
					REG_SERIALPORTINDEX_VAL_NAME, 
					NULL, 
					NULL,
					(LPBYTE) &(pInitContext->dwDeviceIndex), 
					&dwDataSize);

	if (regError != ERROR_SUCCESS)
		bRet = FALSE;

	DEBUGMSG (DBG_INIT,(TEXT("GetRegistryData - Device Index %d (UART %d)\r\n"),
		pInitContext->dwDeviceIndex, pInitContext->dwDeviceIndex));

	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn			PVOID AT91_HWInit (ULONG Identifier, PVOID pMDDContext, PHWOBJ pHWObj)
//!
//! 
//-----------------------------------------------------------------------------
PVOID AT91_HWInit (ULONG Identifier, PVOID pMDDContext, PHWOBJ pHWObj)
{
	T_SERIALINIT_STRUCTURE *pInitContext = NULL;
	T_SERIAL_HW serialHW;

	PHYSICAL_ADDRESS PA_PMCReg, PA_USARTReg, PA_PDCReg;

	pInitContext = (T_SERIALINIT_STRUCTURE*) LocalAlloc(LPTR, sizeof(T_SERIALINIT_STRUCTURE));
	if (pInitContext == NULL)
		return NULL;

	pInitContext->pMDDContext = pMDDContext;
	pInitContext->pHWObj = pHWObj;
	pInitContext->dwDeviceIndex = -1;
	pInitContext->pHardwareContext = NULL;
	pInitContext->dwOpenCount = 0;
	pInitContext->pPMCReg = NULL;
	pInitContext->pUSARTReg = NULL;
	pInitContext->pPDCReg = NULL;
	pInitContext->dwBufferedCSR = 0;
	
	pInitContext->vDMACommonTxBuffer = NULL;
	pInitContext->vDMACommonRxBuffer[0] = NULL;

	pInitContext->pfnClearRTS = NULL;
	pInitContext->pfnSetRTS = NULL;

	pInitContext->pfnClearDTR = NULL;
	pInitContext->pfnSetDTR = NULL;
	

	// Load registry entries
	if (!GetRegistryData (pInitContext, (LPCWSTR)Identifier))
		goto InitFailed;

	//
	InitializeCriticalSection (&pInitContext->csUsartReg);


	// Specific HW Init
	serialHW.dwSysIntr = SYSINTR_UNDEFINED;
	serialHW.pfnClearRTS = NULL;
	serialHW.pfnSetRTS = NULL;
	serialHW.pfnClearDTR = NULL;
	serialHW.pfnSetDTR = NULL;
	serialHW.pfnClearBreak = NULL;
	serialHW.pfnSetBreak = NULL;
	pInitContext->pHardwareContext = (PVOID)HWSerialInit (pInitContext->dwDeviceIndex, (LPCTSTR)Identifier, &serialHW);

	// No hardware context available means error
	if (pInitContext->pHardwareContext == NULL)
		goto InitFailed;
	
	pInitContext->dwDeviceId = serialHW.dwDeviceID;
	pInitContext->dwIntMask = serialHW.dwIntMask;
	// Set and clear custom management
	if (serialHW.pfnClearRTS != NULL)
		pInitContext->pfnClearRTS = serialHW.pfnClearRTS;

	if (serialHW.pfnSetRTS != NULL)
		pInitContext->pfnSetRTS = serialHW.pfnSetRTS;

	if (serialHW.pfnClearDTR != NULL)
		pInitContext->pfnClearDTR = serialHW.pfnClearDTR;

	if (serialHW.pfnSetDTR != NULL)
		pInitContext->pfnSetDTR = serialHW.pfnSetDTR;
	
	if (serialHW.pfnClearBreak != NULL)
		pInitContext->pfnClearBreak = serialHW.pfnClearBreak;

	if (serialHW.pfnSetBreak != NULL)
		pInitContext->pfnSetBreak = serialHW.pfnSetBreak;



	// Commmon hardware init
	PA_PMCReg.QuadPart	= (LONGLONG) AT91C_BASE_PMC;
	pInitContext->pPMCReg = (AT91PS_PMC) MmMapIoSpace(PA_PMCReg, sizeof(AT91S_PMC), FALSE);

	PA_USARTReg.QuadPart	= (LONGLONG) serialHW.dwBaseAddress;
	pInitContext->pUSARTReg = (AT91PS_USART) MmMapIoSpace(PA_USARTReg, sizeof(AT91S_USART), FALSE);

	PA_PDCReg.QuadPart	= (LONGLONG) serialHW.dwPDCBaseAddress ;
	pInitContext->pPDCReg = (AT91PS_PDC) MmMapIoSpace(PA_PDCReg, sizeof(AT91S_PDC), FALSE);

	if (pInitContext->pPMCReg == NULL || 
		pInitContext->pUSARTReg == NULL ||
		pInitContext->pPDCReg == NULL )
		goto InitFailed;

	// Init status and errors variables.
	memset ((char *) &(pInitContext->lpStat), 0, sizeof(COMSTAT));
	pInitContext->dwErrors = 0;

	// Hardware PIOs initialisation
	HWSerialInitPIO(pInitContext->pHardwareContext);



	// Disable RX TX
	EnterCriticalSection (&pInitContext->csUsartReg);
	
	pInitContext->pUSARTReg->US_CR = AT91C_US_TXDIS | AT91C_US_RXDIS;
	pInitContext->pUSARTReg->US_RTOR = 20;
	
	LeaveCriticalSection (&pInitContext->csUsartReg);

	
	//
	pHWObj->BindFlags = THREAD_AT_INIT;
    pHWObj->dwIntID = serialHW.dwSysIntr;      
    pHWObj->pFuncTbl = (HW_VTBL *) &SerIoVTbl;
	


	// DMA Adapter object
	pInitContext->dmaAdapter.ObjectSize = sizeof(DMA_ADAPTER_OBJECT);
	pInitContext->dmaAdapter.InterfaceType = PCIBus;
	pInitContext->dmaAdapter.BusNumber = 0;
	


	// Set up our Comm Properties data    
	pInitContext->commProp.wPacketLength		= 0xffff;
	pInitContext->commProp.wPacketVersion		= 0xffff;
	pInitContext->commProp.dwServiceMask		= SP_SERIALCOMM;
	pInitContext->commProp.dwReserved1			= 0;
	pInitContext->commProp.dwMaxTxQueue			= 16;
	pInitContext->commProp.dwMaxRxQueue			= 16;
	pInitContext->commProp.dwMaxBaud			= BAUD_115200;
	pInitContext->commProp.dwProvSubType		= PST_RS232;
	pInitContext->commProp.dwProvCapabilities	=
									PCF_DTRDSR | PCF_RLSD | PCF_RTSCTS |
									PCF_SETXCHAR |
									PCF_INTTIMEOUTS |
									PCF_PARITY_CHECK |
									PCF_SPECIALCHARS |
									PCF_TOTALTIMEOUTS |
									PCF_XONXOFF;
	pInitContext->commProp.dwSettableBaud      =
		BAUD_075 | BAUD_110 | BAUD_150 | BAUD_300 | BAUD_600 |
		BAUD_1200 | BAUD_1800 | BAUD_2400 | BAUD_4800 |
		BAUD_7200 | BAUD_9600 | BAUD_14400 |
		BAUD_19200 | BAUD_38400 | BAUD_56K | BAUD_128K |
		BAUD_115200 | BAUD_57600 | BAUD_USER;
	pInitContext->commProp.dwSettableParams    =
		SP_BAUD | SP_DATABITS | SP_HANDSHAKING | SP_PARITY |
		SP_PARITY_CHECK | SP_RLSD | SP_STOPBITS;
	pInitContext->commProp.wSettableData       =
		DATABITS_5 | DATABITS_6 | DATABITS_7 | DATABITS_8;
	pInitContext->commProp.wSettableStopParity =
		STOPBITS_10 | STOPBITS_20 |
		PARITY_NONE | PARITY_ODD | PARITY_EVEN | PARITY_SPACE |
		PARITY_MARK;


	// Set up our commTimeouts properties data
	pInitContext->commTimeouts.ReadIntervalTimeout = DEFAULT_READINTERVALTIMEOUT; 
	pInitContext->commTimeouts.ReadTotalTimeoutMultiplier = DEFAULT_READTOTALTIMEOUTMULTIPLIER; 
	pInitContext->commTimeouts.ReadTotalTimeoutConstant = DEFAULT_READTOTALTIMEOUTCONSTANT; 
	pInitContext->commTimeouts.WriteTotalTimeoutMultiplier = DEFAULT_WRITETOTALTIMEOUTMULTIPLIER; 
	pInitContext->commTimeouts.WriteTotalTimeoutConstant = DEFAULT_WRITETOTALTIMEOUTCONSTANT; 

	// Init master clock reference value;
	if (!KernelIoControl(IOCTL_HAL_MASTERCLOCK, NULL, 0, &g_dwMasterClock, sizeof(g_dwMasterClock), 0))
	{
		goto InitFailed;
	}

	return (PVOID) pInitContext;


InitFailed:
	if (pInitContext)
	{
		if (pInitContext->dwDeviceIndex != -1 && pInitContext->pHardwareContext != NULL)
		{
			HWSerialDeInit (pInitContext->pHardwareContext);
		}

		if (pInitContext->pPMCReg != NULL)
			MmUnmapIoSpace(pInitContext->pPMCReg, sizeof(AT91S_PMC));

		if (pInitContext->pUSARTReg != NULL)
			MmUnmapIoSpace(pInitContext->pUSARTReg, sizeof(AT91S_USART));

		if (pInitContext->pPDCReg != NULL)
			MmUnmapIoSpace(pInitContext->pPDCReg, sizeof(AT91S_PDC));


		LocalFree (pInitContext);
	}
	return NULL;

}

//-----------------------------------------------------------------------------
//! \fn			PHWOBJ GetSerialObject(DWORD dwDeviceArrayIndex)
//!
//! \brief		This function supports the implementation of the lower layers of serial port drivers.
//!
//! \param		dwDeviceArrayIndex	Index into an array of serial devices, corresponding 
//!									to the different lower-layer implementations that might 
//!									be shared by a single upper-layer implementation.
//!
//!
//! \return		A pointer to a <i>HWOBJ</i> structure, which contains the correct function 
//!				pointers and parameters for the hardware interface functions of the 
//!				relevant lower layer.
//!
//! This function returns a pointer to a HWOBJ structure. The structure contains the function 
//!	pointers and parameters for the hardware interface functions of the relevant lower layer.
//-----------------------------------------------------------------------------
PHWOBJ GetSerialObject(DWORD dwDeviceArrayIndex)
{
	PHWOBJ pSerObj = NULL;

	if ( dwDeviceArrayIndex > g_dwMaxSerialDevices)
	{
		return NULL;
	}

	// Allocate space for the HWOBJ
	pSerObj = (PHWOBJ) LocalAlloc(LPTR, sizeof(HWOBJ));
	if (pSerObj == NULL)
	{
		return NULL;
	}

    // Fill in the HWObj structure that we just allocated.

    //pSerObj->BindFlags = THREAD_IN_PDD;      // Actually, no thread.
    pSerObj->dwIntID = 0;                    // SysIntr is filled in at init time
    pSerObj->pFuncTbl = (HW_VTBL *) &SerIoVTbl; // Return pointer to appropriate functions

    // Now return this structure to the MDD.
    return (pSerObj);
}

const
HW_VTBL SerIoVTbl = {
	AT91_HWInit, // PVOID (*HWInit)(ULONG Identifier, PVOID pMDDContext, PHWOBJ pHWObj);
	AT91_HWPostInit, // BOOL (*HWPostInit)(PVOID pHead);
	AT91_HWDeinit, // ULONG (*HWDeinit)(PVOID pHead);
	AT91_HWOpen, // BOOL (*HWOpen)(PVOID pHead);
	AT91_HWClose, // ULONG (*HWClose)(PVOID pHead);
	AT91_HWGetIntrType, // INTERRUPT_TYPE (*HWGetIntrType)(PVOID pHead);
	AT91_HWRxIntrHandler, // ULONG (*HWRxIntrHandler)(PVOID pHead, PUCHAR pTarget, PULONG pBytes);
	AT91_HWTxIntrHandler, // VOID (*HWTxIntrHandler)(PVOID pHead, PUCHAR pSrc, PULONG pBytes);
	AT91_HWModemIntrHandler, // VOID (*HWModemIntrHandler)(PVOID pHead);
	AT91_HWLineIntrHandler, // VOID (*HWLineIntrHandler)(PVOID pHead);
	AT91_HWGetRxBufferSize, // ULONG (*HWGetRxBufferSize)(PVOID pHead);
	AT91_HWPowerOff, // BOOL (*HWPowerOff)(PVOID pHead);
	AT91_HWPowerOn, // BOOL (*HWPowerOn)(PVOID pHead);
	AT91_HWClearDTR, // VOID (*HWClearDTR)(PVOID pHead);
	AT91_HWSetDTR, // VOID (*HWSetDTR)(PVOID pHead);
	AT91_HWClearRTS, // VOID (*HWClearRTS)(PVOID pHead);
	AT91_HWSetRTS, // VOID (*HWSetRTS)(PVOID pHead);
	AT91_HWEnableIR, // BOOL (*HWEnableIR)(PVOID pHead, ULONG BaudRate);
	AT91_HWDisableIR, // BOOL (*HWDisableIR)(PVOID pHead);
	AT91_HWClearBreak, // VOID (*HWClearBreak)(PVOID pHead);
	AT91_HWSetBreak, // VOID (*HWSetBreak)(PVOID pHead);
	AT91_HWXmitComChar, // BOOL (*HWXmitComChar)(PVOID pHead, UCHAR ComChar);
	AT91_HWGetStatus, // ULONG (*HWGetStatus)(PVOID pHead, LPCOMSTAT lpStat);
	AT91_HWReset, // VOID (*HWReset)(PVOID pHead);
	AT91_HWGetModemStatus, // VOID (*HWGetModemStatus)(PVOID pHead, PULONG pModemStatus);
	AT91_HWGetCommProperties, // VOID (*HWGetCommProperties)(PVOID pHead, LPCOMMPROP pCommProp);
	AT91_HWPurgeComm, // VOID (*HWPurgeComm)(PVOID pHead, DWORD fdwAction);
	AT91_HWSetDCB, // BOOL (*HWSetDCB)(PVOID pHead, LPDCB pDCB);
	AT91_HWSetCommTimeouts, // BOOL (*HWSetCommTimeouts)(PVOID pHead, LPCOMMTIMEOUTS lpCommTO);
	AT91_HWIoctl, // BOOL (*HWIoctl)(PVOID pHead, DWORD dwCode,PBYTE pBufIn,DWORD dwLenIn, PBYTE pBufOut,DWORD dwLenOut,PDWORD pdwActualOut);
};

//! @}

