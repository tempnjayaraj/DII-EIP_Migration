//-----------------------------------------------------------------------------
//! \addtogroup AT91SAM9263
//! @{
//
//  All rights reserved ADENEO SAS 2005
//
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM9263/MISC/GLOBAL/procinfo.c
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/MISC/GLOBAL/procinfo.c $
//!   $Author: edaniel $
//!   $Revision: 749 $
//!   $Date: 2007-04-18 17:02:22 +0200 (mer., 18 avr. 2007) $
//! \endif
//		TODO
//
//-----------------------------------------------------------------------------

#include <windows.h>
#include <oal.h>

#include "AT91SAM926x_interface.h"
#include "at91sam926x.h"

static WCHAR *g_Cores[] = {
	L"Unknown",
	L"ARM946ES",
	L"ARM7TDMI",
	L"Unknown",
	L"ARM920T",
	L"ARM926EJ-S",
	L"Unknown",
	L"ARM926 (old)",	// not sure this is mandatory, for old compatibility only.
};

//-----------------------------------------------------------------------------
//! \fn			const T_PROC_INFO *MiscSpecificGetProcInfo()
//!
//! \brief		This function gets back processor info
//!
//! \return		adress of a structure T_PROC_INFO
//!
//-----------------------------------------------------------------------------
const T_PROC_INFO *MiscSpecificGetProcInfo()
{
	static T_PROC_INFO sProcInfo = {
		L"ATMEL",
		L"",
		L"AT91SAM9263",
		0,
		0,
		L"0",
		0,
		0
	};

	if (sProcInfo.dwClockSpeed == 0)
	{
		AT91PS_DBGU pDbguReg = (AT91PS_DBGU) OALPAtoVA((DWORD) AT91C_BASE_DBGU, FALSE);
		UINT index, length;

		sProcInfo.dwClockSpeed = AT91SAM926x_GetMasterClock(FALSE);

		index = (pDbguReg->DBGU_CIDR >> 5) & 0x7;
		length = (NKwcslen(g_Cores[index]) + 1) * sizeof(WCHAR);
		memcpy(sProcInfo.cCore, g_Cores[index], length);
	}

	return &sProcInfo;
}

//! @}
