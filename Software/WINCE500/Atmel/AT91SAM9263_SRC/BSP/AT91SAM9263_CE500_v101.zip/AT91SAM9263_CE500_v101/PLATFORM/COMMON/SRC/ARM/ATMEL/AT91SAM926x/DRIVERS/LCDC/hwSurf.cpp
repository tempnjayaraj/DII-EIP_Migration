//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x/DRIVERS/LCDC/hwSurf.cpp 
//!
//! \brief		Implementation of hwSurf class, heritating from DDGPESurf abstract class
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/LCDC/hwSurf.cpp $
//!   $Author: pblanchard $
//!   $Revision: 984 $
//!   $Date: 2007-06-11 09:19:22 -0700 (Mon, 11 Jun 2007) $
//! \endif
//-----------------------------------------------------------------------------	
//! \addtogroup	LCDC
//! @{
//

// Local include
#include "LCDC\precomp.h"

//-----------------------------------------------------------------------------
// hwSurf constructor
// Author     : DMA
//
// This constrcutor is called every time you want to create a DDGPESurf in video
// memory, !! and just for this use !! You'd to give a valid videomem pointer
// in pBits and a VideoMem offset (for HW acceleration) in offset. Stride represent
// the width of the video memory ( should be different of the width of the surface )
//
hwSurf::hwSurf(int width, int height, unsigned long offset, void* pBits, int stride, EGPEFormat format, Node2D *pNode2D)
:DDGPESurf(width, height, pBits, stride, format)
{
	DEBUGMSG(0, (TEXT("-> hwSurf")));
	
	m_pNode2D = pNode2D;
	m_fInVideoMemory = true;
	m_nOffsetInVideoMemory = offset;

	DEBUGMSG(0, (TEXT("<- hwSurf")));
}

//-----------------------------------------------------------------------------
// hwSurf constructor
// Author     : DMA
//
// This constructor is called every time you want to create a DDGPESurf
// read comment for the upper constructor
//
hwSurf::hwSurf(int width, int height, unsigned long offset, void* pBits, int stride, EGPEFormat format, EDDGPEPixelFormat pixelFormat, Node2D *pNode2D)
:DDGPESurf(width, height, pBits, stride, format, pixelFormat)
{
	DEBUGMSG(0, (TEXT("-> hwSurf")));

	m_pNode2D = pNode2D;
	m_fInVideoMemory = true;
	m_nOffsetInVideoMemory = offset;

	DEBUGMSG(0, (TEXT("<- hwSurf")));
}

//-----------------------------------------------------------------------------
// hwSurf Destructor
// Author     : DMA
hwSurf::~hwSurf()
{
	DEBUGMSG(0, (TEXT("-> ~Surface")));

	DEBUGMSG(0, (TEXT("~Surface::Node2D unallocator is called")));
	m_pNode2D->Free();

	DEBUGMSG(0, (TEXT("<- ~Surface")));
}

//! @}

////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/LCDC/hwSurf.cpp $
////////////////////////////////////////////////////////////////////////////////
//
//! @}