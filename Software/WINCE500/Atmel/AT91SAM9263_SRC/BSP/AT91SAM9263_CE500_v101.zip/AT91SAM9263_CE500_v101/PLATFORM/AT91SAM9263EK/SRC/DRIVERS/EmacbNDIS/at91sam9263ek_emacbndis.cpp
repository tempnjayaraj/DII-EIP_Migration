//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//! \addtogroup	EMAC
//! @{
//
//! \addtogroup EMACBNDIS
//! @{
//
//  All rights reserved ADENEO SAS 2005
//
//! \file		at91sam9263ek_emacbndis.cpp
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/EmacbNDIS/at91sam9263ek_emacbndis.cpp $
//!   $Author: pgal $
//!   $Revision: 932 $
//!   $Date: 2007-06-04 14:28:50 +0200 (lun., 04 juin 2007) $
//! \endif
//
//-----------------------------------------------------------------------------

// Controller includes
#include "at91sam926x.h"

// Driver includes
#include "at91sam9263ek_emacbndis.h"
#include "at91sam9263_gpio.h"

//------------------------------------------------------------------------------
//! \fn void C_SAM9263EK_EMACBNDIS::PIOConfiguration(void)
//! \brief Configuring PIO for EMACB controller
//!
//! A special operation consiting to reset controller with a special configuration
//! and then configure PIO correctly.
//------------------------------------------------------------------------------
void C_SAM9263EK_EMACBNDIS::PIOConfiguration(void)
{
//	RETAILMSG(1, (L"C_SAM9260EK_EMACBNDIS::PIOConfiguration\r\n"));
	const struct pio_desc hw_pio[] = {
		{"ETXCK",	AT91C_PIN_PE(21), 0, PIO_DEFAULT, PIO_PERIPH_A},
		{"ECRS",	AT91C_PIN_PE(22), 0, PIO_DEFAULT, PIO_PERIPH_A},
		{"ETX0",	AT91C_PIN_PE(23), 0, PIO_DEFAULT, PIO_PERIPH_A},
		{"ETX1",	AT91C_PIN_PE(24), 0, PIO_DEFAULT, PIO_PERIPH_A},
		{"ERX0",	AT91C_PIN_PE(25), 0, PIO_DEFAULT, PIO_PERIPH_A},
		{"ERX1",	AT91C_PIN_PE(26), 0, PIO_DEFAULT, PIO_PERIPH_A},
		{"ERXER",	AT91C_PIN_PE(27), 0, PIO_DEFAULT, PIO_PERIPH_A},
		{"ETXEN",	AT91C_PIN_PE(28), 0, PIO_DEFAULT, PIO_PERIPH_A},
		{"EMDC",	AT91C_PIN_PE(29), 0, PIO_DEFAULT, PIO_PERIPH_A},
		{"EMDIO",	AT91C_PIN_PE(30), 0, PIO_DEFAULT, PIO_PERIPH_A},
		{"EF100",	AT91C_PIN_PE(31), 0, PIO_DEFAULT, PIO_PERIPH_A},
		{"ERXDV",	AT91C_PIN_PC(25), 0, PIO_DEFAULT, PIO_PERIPH_B},
	};

	const struct pio_desc hw_pio2[] = {
		{"ERX0",	AT91C_PIN_PE(25), 0, PIO_DEFAULT, PIO_OUTPUT},
		{"ERX1",	AT91C_PIN_PE(26), 0, PIO_DEFAULT, PIO_OUTPUT},
		{"ERXDV",	AT91C_PIN_PC(25), 0, PIO_DEFAULT, PIO_OUTPUT},
		{"ECRS",	AT91C_PIN_PE(22), 0, PIO_DEFAULT, PIO_OUTPUT}
	};

	AT91PS_PMC	pPMC;
	AT91PS_RSTC pRSTC;

	PHYSICAL_ADDRESS pa;
	PHYSICAL_ADDRESS pRST;

	pRST.LowPart = (DWORD)AT91C_BASE_RSTC;
	pa.LowPart = (DWORD)AT91C_BASE_PMC;

	pPMC = (AT91PS_PMC)MmMapIoSpace(pa, sizeof(AT91S_PMC), FALSE);	
	pRSTC= (AT91PS_RSTC)MmMapIoSpace(pRST,sizeof(AT91S_RSTC), FALSE);
		
	// Enable Peripheral clock in PMC for  EMAC		
	pPMC->PMC_PCER = ((unsigned int) 1 << AT91C_ID_EMAC);

	// The reset of the external chips is done in the beginning
	// of the OEMInit() in the OAL.	
	//pio_setup(hw_pio2, sizeof(hw_pio2)/sizeof(struct pio_desc));
	//pRSTC->RSTC_RCR = (0xA5 << 24 ) | AT91C_RSTC_EXTRST;

	Sleep(200);

	pio_setup(hw_pio, sizeof(hw_pio)/sizeof(struct pio_desc));



	MmUnmapIoSpace(pPMC, sizeof(AT91S_PMC));
	MmUnmapIoSpace(pRSTC, sizeof(AT91S_RSTC));	
}
//! @}
//! @}
//! @}
