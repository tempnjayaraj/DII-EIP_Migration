//-----------------------------------------------------------------------------
//! \addtogroup	I2C
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91RM9200_i2c_ioctl.h
//!
//! \brief		I2C driver iocontrol definitions
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/INC/IOCTL/AT91RM9200_i2c_ioctl.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//!
//! IOControl used by application for interaction and transaction with the I2C driver
//-----------------------------------------------------------------------------

#ifndef __AT91RM9200_I2C_IOCTL_H__
#define __AT91RM9200_I2C_IOCTL_H__

#ifdef __cplusplus
extern "C" {
#endif

// Functions
#define I2C_FUNCTION_READ			2048
#define I2C_FUNCTION_WRITE			2049
#define I2C_FUNCTION_TRANSFERT_RATE	2050
#define I2C_FUNCTION_LOCK			2051
#define I2C_FUNCTION_UNLOCK			2052


// IOControl codes
/*! \def IOCTL_I2C_READ 
	\brief Command code for performing a read on the I2C bus
*/
#define IOCTL_I2C_READ				CTL_CODE(FILE_DEVICE_DATALINK, I2C_FUNCTION_READ, METHOD_BUFFERED, FILE_READ_ACCESS)

/*! \def IOCTL_I2C_WRITE 
	\brief Command code for performing a write on the I2C bus
*/
#define IOCTL_I2C_WRITE				CTL_CODE(FILE_DEVICE_DATALINK, I2C_FUNCTION_WRITE, METHOD_BUFFERED, FILE_WRITE_ACCESS)

/*! \def IOCTL_I2C_TRANSFERT_RATE 
	\brief Command code to set the transfert rate
*/
#define IOCTL_I2C_TRANSFERT_RATE	CTL_CODE(FILE_DEVICE_DATALINK, I2C_FUNCTION_TRANSFERT_RATE, METHOD_BUFFERED, FILE_WRITE_ACCESS)

#define IOCTL_I2C_LOCK				CTL_CODE(FILE_DEVICE_DATALINK, I2C_FUNCTION_LOCK, METHOD_BUFFERED, FILE_WRITE_ACCESS)

#define IOCTL_I2C_UNLOCK			CTL_CODE(FILE_DEVICE_DATALINK, I2C_FUNCTION_UNLOCK, METHOD_BUFFERED, FILE_WRITE_ACCESS)



typedef enum {
	NO_IADR			= 0x0, //!< No internal device address (Byte command protocol)
	ONE_BYTE_IADR	= 0x1,	//!< One-byte internal device address
	TWO_BYTE_IADR	= 0x2,	//!< Two-byte internal device address
	THREE_BYTE_IADR	= 0x3	//!< Three-byte internal device address
} IADDR_SIZE ;

// Structs
/*! \struct T_I2CIOCTL_READ
	\brief Parameter for the IOCTL_I2C_READ command
*/
typedef struct {
	DWORD dwDeviceAddr;			//!< I2C device address
	DWORD dwRegAddress;			//!< I2C internatl device address to read
	IADDR_SIZE eAddressSize;	//!< I2C internal device address size
	BOOL bDisableInterrupt;	//!< Force interrupt to be disabled during the transfer
} T_I2CIOCTL_READ;



/*! \struct T_I2CIOCTL_WRITE
	\brief Parameter for the IOCTL_I2C_WRITE command
*/
typedef struct {
	DWORD dwDeviceAddr;		//!< I2C device address
	DWORD dwRegAddress;		//!< I2C register address to write
	IADDR_SIZE eAddressSize;	//!< I2C internal device address size
	DWORD dwBufferSize;		//!< Quantity of data to send to device
	LPBYTE pBuffer;			//!< Buffer of data to send
	BOOL bDisableInterrupt;	//!< Force interrupt to be disabled during the transfer
} T_I2CIOCTL_WRITE;

#ifdef __cplusplus
}
#endif

#endif // #ifndef __AT91RM9200_I2C_IOCTL_H__

//! @}
