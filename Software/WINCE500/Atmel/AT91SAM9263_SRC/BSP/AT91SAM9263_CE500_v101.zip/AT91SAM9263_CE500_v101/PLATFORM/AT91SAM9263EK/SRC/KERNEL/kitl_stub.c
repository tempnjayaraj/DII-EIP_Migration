//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		kitl_stub.c
//!
//! \brief		Support routines for KITL (stubs only). Based on Microsoft's code (see header below)
//!
//! \if subversion
//!   $URL: http://centaure/svn/thales_navigation-bsp_nadia2ek/TRUNK/WINCE500/PLATFORM/nadia2EK/SRC/KERNEL/kitl_stub.c $
//!   $Author: jjhiblot $
//!   $Revision: 18 $
//!   $Date: 2005-12-19 15:16:58 +0100 (lun., 19 déc. 2005) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	KITL_STUB
//! @{

//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//

#include <windows.h>
#include "oal_kitl.h"


///  This function is called from OEMInit to start KITL. It's empty here since KITL is disabled
BOOL OALKitlStart()
{
	DEBUGMSG(1, (_T("OALKitlStart-------------------\r\n")));
    return TRUE;
}

//------------------------------------------------------------------------------
///  This function is called as part of IOCTL_HAL_INITREGISTRY to update
///  registry with information about KITL device. This must be done to avoid
///  loading Windows CE driver for KITL devices in case that it is part of image. On system
///  without KITL is this function replaced with empty stub.
///
VOID OALKitlInitRegistry()
{
		DEBUGMSG(1, (_T("OALKitlInitRegistry-------------------\r\n")));
}


//! @}

//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/thales_navigation-bsp_nadia2ek/TRUNK/WINCE500/PLATFORM/nadia2EK/SRC/KERNEL/kitl_stub.c $
//-----------------------------------------------------------------------------
//