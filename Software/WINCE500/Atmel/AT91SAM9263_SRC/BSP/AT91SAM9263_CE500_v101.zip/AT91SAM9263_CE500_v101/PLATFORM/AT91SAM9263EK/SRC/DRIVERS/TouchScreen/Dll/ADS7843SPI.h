//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//! \addtogroup	TOUCHSCREEN
//! @{
//!  
//  All rights reserved ADENEO SAS 2006
//!
//-----------------------------------------------------------------------------
//! \file		ADS7843SPI.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/TouchScreen/Dll/ADS7843SPI.h $
//!   $Author: ltourlonias $
//!   $Revision: 684 $
//!   $Date: 2007-04-13 14:35:48 +0200 (ven., 13 avr. 2007) $
//! \endif
//!
//! \brief Header for interface between SPI driver and TouchScreen driver
//-----------------------------------------------------------------------------

#ifndef __ADS7843SPI_H__
#define __ADS7843SPI_H__


BOOL InitializeSPIDriver(LPCTSTR strDriverName);

void DeinitializeSPIDriver();


BOOL ADS7843_ReadXY(INT *pUnCalX, INT *pUnCalY);

BOOL ADS7843_ReadY(INT *pUnCalY);

BOOL ADS7843_ReadX(INT *pUnCalX);


void CustomizeCoordinates (INT *pUnCalX, INT *pUnCalY);

#endif //#ifndef __ADS7843SPI_H__

//! @}
//! @}

////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/TouchScreen/Dll/ADS7843SPI.h $
////////////////////////////////////////////////////////////////////////////////
//
