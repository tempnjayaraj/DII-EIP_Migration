//-----------------------------------------------------------------------------
//! \addtogroup	DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/NandFlash/GenericFMD.c
//!
//! \brief		A generic modular FMD for NAND Flash memory
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/NandFlash/GenericFMD.c $
//!   $Author: cchary $
//!   $Revision: 811 $
//!   $Date: 2007-05-10 15:33:51 +0200 (jeu., 10 mai 2007) $
//! \endif
//!
//! Implements a sector mapping and a sector locking system witch interface
//! with WinCE Std block driver and also with BootPart. cf the graph below.
//! 
//-----------------------------------------------------------------------------
//! \addtogroup	NandFlash
//! @{
//!

// -------------------------
// |      Application      |
// -------------------------
//       |             |
//       V             |
// --------------      |        ---------------
// | FileSystem |      |        |  Bootloader |
// --------------      |        ---------------
//       |             |               |
//       V             V               V
// --------------------------   ---------------
// | WinCE Std Block Driver |   |   BootPart  |
// --------------------------   ---------------
//             |                       |
// ---- L o g i c a l -- A d d r e s s e s ----
//             |                       |
//             V                       V
// --------------------------------------------
// |                  F M D                   |
// --------------------------------------------
// |                    |                     |
// |                    V                     |
// | ---------------------------------------- |
// | |    BTL : Block Translation Layer     | |
// | ---------------------------------------- |
// |                    |                     |
// | - P h y s i c a l  | A d d r e s s e s - |
// |                    V                     |
// | ---------------------------------------- |
// | |   WPS : Write protection system      | |
// | ---------------------------------------- |
// |                    |                     |
// |                    V                     |
// | ---------------------------------------- |
// | |   LLD : Low Level Driver             | |
// | ---------------------------------------- |
// |--------------------|---------------------|
//                      V
// --------------------------------------------
// |             Hardware device              |
// --------------------------------------------

// System specific include
#include <windows.h>
#include <nkintr.h>
#include <oal.h>
#include <fmd.h>

#include "GenericFMD.h"
#include "NandFlash.h"

//#define USE_ECC
#ifdef USE_ECC
#include <ecc.h>
#include "GenericECC.h"
#endif


// Make a Doxygen group
//! \addtogroup GenericFMD
//! @{

//! \brief	Called by init to select a specific HW device
static void ConfigChip	();

//! \brief	BlocksInfo should be hardcoded, or extracted from flash
static BOOL	LoadBlocksInfo	();

static NandChip *pChip;
static MapSectionList *pMapPlan;

//! \brief	Sector buffer for read & write transaction
static BYTE* g_pSectorBuffer = NULL;

//! \brief	Array for block informations
static FMDBlocksInfo* g_pBlocksInfo = NULL;

static BOOL Sparses2Info(PBYTE pSpares, PSectorInfo pSectorInfoBuff);
static BOOL Info2Sparses(PSectorInfo pSectorInfoBuff, PBYTE pSpares);

static struct _FlashSize
{
	DWORD dwDataNbBytes		;	//!< Nb of bytes in data section
	DWORD dwSpareNbBytes	;	//!< Nb of bytes in spare section
	DWORD dwSectorNbBytes	;	//!< Total nb of bytes in a sector

	DWORD dwBlockNbSectors	;	//!< Nb of sector in a block
	DWORD dwBlockNbData		;	//!< Nb of DataBytes in a block
	DWORD dwBlockNbSpares	;	//!< Nb of SpareBytes in a block
	DWORD dwBlockNbBytes	;	//!< Total nb of bytes in a block

	DWORD dwNbBlocks		;	//!< Nb of blocks in device
	DWORD dwNbSectors		;	//!< Total nb of sectors in device
	DWORD dwNbData			;	//!< Nb of DataBytes in device
	DWORD dwNbSpares		;	//!< Nb of SpareBytes in device
	DWORD dwNbBytes			;	//!< Total nb of bytes in device

	DWORD dwReserveArea		;	//!< Nb of block reserved for image storage

} g_FlashSize;


//-----------------------------------------------------------------------------
//! \fn			PVOID FMD_Init(LPCTSTR lpActiveReg, PPCI_REG_INFO pRegIn, PPCI_REG_INFO pRegOut)
//!
//! \brief		This function initializes the flash memory of a device.
//!
//! \param		lpActiveReg	Registry key given by Windows
//! \param		pRegIn		Registry key given by Windows
//! \param		pRegOut		Registry key given by Windows
//!
//! \return		Handle to the specific device on success, you must pass this value to FMD_Deinit
//!	\return		-1 on error
//!
//! This function call LLD_Init, choose a configuration from DevID's and load
//! per block informations.
//-----------------------------------------------------------------------------
PVOID FMD_Init(LPCTSTR lpActiveReg, PPCI_REG_INFO pRegIn, PPCI_REG_INFO pRegOut)
{
	DWORD	dwRet	= 0;
	int		i		= 0;
	DWORD	MemBase	= 0x40000000;

	// In
	DEBUGMSG(1, (TEXT("->FMD_Init\n\r")));

	// Retreive registry settings - If the call come from bootloader, lpActiveReg is null
	if (lpActiveReg)
	{
		HKEY	hKey	= 0;
		DWORD	Size	;
		DWORD	Type	;

		hKey = OpenDeviceKey(lpActiveReg);
		RegQueryValueEx(hKey, L"membase", 0, &Type, (BYTE*)&MemBase, &Size);
		RegCloseKey(hKey);
	}

	pChip = NandFlash_Alloc();
	if(!pChip)
	{
		dwRet = -1;
		goto exit;
	}

	pChip->dwPhyNandBaseAddr = MemBase;
	if(!NandFlash_LowLevelInit(pChip))
	{
		dwRet = -1;
		goto exit;
	}
	DEBUGMSG(1, (TEXT("FMD_Init::FMD Low Level Init ok\n\r")             ));
	
	ConfigChip();
	
	// Allocate sufficient memory space to save blocks informations
	g_pBlocksInfo = (FMDBlocksInfo*)malloc(g_FlashSize.dwNbBlocks*sizeof(FMDBlocksInfo));

	// Allocate one-sector buffer
	g_pSectorBuffer = (BYTE*)malloc(g_FlashSize.dwSectorNbBytes);

	// Load Nand locking and mapping informations
	if (!LoadBlocksInfo())
	{
		dwRet = -1;
		DEBUGMSG(1, (TEXT("FMD_Init::Error loading block informations\n\r")));
		goto exit;
	}

exit:

	// Free dynamic memory
	if (dwRet && g_pBlocksInfo)
	{
		free(g_pBlocksInfo);
	}

	if (dwRet && g_pSectorBuffer)
	{
		free(g_pSectorBuffer);
	}

	if (dwRet && pChip)
	{
		NandFlash_Release(pChip);
	}

	// Init successfull
	if (!dwRet)
	{
		dwRet = 1;
	}

	// Out
	DEBUGMSG(1, (TEXT("<-FMD_Init\n\r")));

	return (PVOID)dwRet;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL FMD_Deinit(PVOID hFMD)
//!
//! \brief		This function de-initializes the flash chip.
//!
//! \param		hFMD Handle to an FMD, given by FMD_Init
//!
//! \return		\e TRUE when all is good
//!	\return		\e FALSE when all is bad
//-----------------------------------------------------------------------------
BOOL FMD_Deinit(PVOID hFMD)
{
	// In
	DEBUGMSG(1, (TEXT("->FMD_Deinit\n\r")));

	NandFlash_Release(pChip);

	// Release memory allocated
	if (g_pBlocksInfo)
		free(g_pBlocksInfo);

	if (g_pSectorBuffer)
		free(g_pSectorBuffer);

	// Out
	DEBUGMSG(1, (TEXT("<-FMD_Deinit\n\r")));

	return TRUE;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL FMD_GetInfo(PFlashInfo pFlashInfo)
//!
//! \brief		This function return size characteristics for the flash memory device.
//!
//! \param		pFlashInfo Pointer to a FlashInfo struct
//!
//! \return		\e TRUE when all is good
//!	\return		\e FALSE when all is bad
//-----------------------------------------------------------------------------
BOOL FMD_GetInfo(PFlashInfo pFlashInfo)
{
	BOOL bRet = TRUE;

	// In
	DEBUGMSG(1, (TEXT("->FMD_GetInfo\n\r")));

	pFlashInfo->flashType			= NAND;
	pFlashInfo->dwNumBlocks			= g_FlashSize.dwNbBlocks;
	pFlashInfo->dwBytesPerBlock		= g_FlashSize.dwBlockNbBytes;
	pFlashInfo->wSectorsPerBlock	= (WORD)g_FlashSize.dwBlockNbSectors;
	pFlashInfo->wDataBytesPerSector	= (WORD)g_FlashSize.dwDataNbBytes;

	// Out
	DEBUGMSG(1, (TEXT("<-FMD_GetInfo\n\r")));

	return bRet;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL FMD_EraseBlock(BLOCK_ID blockID)
//!
//! \brief		This function erases the specified block
//!
//! \param		blockID Address of the block that will be erased
//!
//! \return		\e TRUE when all is good
//!	\return		\e FALSE when there is an error during erase
//!
//! An erase command should abort when the block is bad, when the WPS is enable
//! or when the chip timed-out. The FMD return an error message using DEBUGMSG.
//-----------------------------------------------------------------------------
BOOL FMD_EraseBlock(BLOCK_ID blockID)
{
	BOOL bRet = TRUE;
	DWORD dwPhyBlck;

	// In
	//DEBUGMSG(1, (TEXT("->FMD_EraseBlock\n\r")));
	//DEBUGMSG(1, (TEXT("FMD_eraseblock : %x\n\r"),blockID));
	// Test if the WriteProtection is activated on this block
	if (g_pBlocksInfo[blockID].wStatus & BLOCK_WP_ACTIVATED)
	{
		bRet = FALSE;
		DEBUGMSG(1, (TEXT("FMD_EraseBlock::WriteProtectionSystem reject an EraseCmd on logical block 0x%X (physical 0x%X)\n\r"), blockID, g_pBlocksInfo[blockID].wPhysicalNumber));
		goto exit;
	}

	// Compute the physical number of the block you want to delete
	dwPhyBlck = g_pBlocksInfo[blockID].wPhysicalNumber;

//	RETAILMSG(1, (TEXT("FMD_EraseBlock::Erase on block 0x%X (physical 0x%X)"), blockID, dwPhyBlck));	

	// Call the LLD for erasing
	if (!LLD_ERASEBLOCK(pChip, dwPhyBlck))
	{
		bRet = FALSE;
		DEBUGMSG(1, (TEXT("FMD_EraseBlock::Erase has failed on block 0x%X (physical 0x%X)\n\r"), blockID, dwPhyBlck));
		goto exit;
	}

exit:

	// Out
	//DEBUGMSG(1, (TEXT("<-FMD_EraseBlock\n\r")));

	return bRet;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL FMD_ReadSector(SECTOR_ADDR startSectorAddr, LPBYTE pSectorBuff, PSectorInfo pSectorInfoBuff, DWORD dwNumSectors)
//!
//! \brief		This function reads the requested sector data and/or info
//!
//! \param		startSectorAddr Logical address of the first sector to read
//! \param		pSectorBuff Pointer to a buffer large enought to store all data bytes
//! \param		pSectorInfoBuff Pointer to a buffer large enought to store all info bytes
//! \param		dwNumSectors Number of sector that should be read
//!
//! \return		\e TRUE When all is good
//!	\return		\e FALSE When there is an error during read
//!
//! An read command should abort when parameters are bad, or when LowLevelRead fail
//! The FMD return an error message using DEBUGMSG.
//-----------------------------------------------------------------------------
BOOL FMD_ReadSector(SECTOR_ADDR startSectorAddr, LPBYTE pSectorBuff, PSectorInfo pSectorInfoBuff, DWORD dwNumSectors)
{
	BOOL bRet = TRUE;
	DWORD dwZone;
	DWORD dwLogSecNb, dwLogBlckNb, dwPhyBlckNb, dwPhySecNb;
	DWORD endSectorAddr = startSectorAddr + dwNumSectors;
	
#ifdef USE_ECC	
	DWORD i;
	DWORD dwErroBlockNb;
#endif


	// In
	//DEBUGMSG(1, (TEXT("->FMD_ReadSector\n\r")));
	

	// If two bufferpointers are null
	if (!pSectorBuff && !pSectorInfoBuff)
	{
		bRet = FALSE;
		DEBUGMSG(1, (TEXT("FMD_ReadSector::Error, two null parameters\n\r")));
		goto exit;
	}
	
	// If we just want to read the info (ie : databuffer is null)
	if (!pSectorBuff)
	{
		dwZone = ZONE_INFO;
	}
	// Else if we just want to read the data (ie : infobuffer is null)
	else if (!pSectorInfoBuff)
	{
		dwZone = ZONE_DATA;
	}
	// Else we want to read data and info in the sector
	else
	{
		dwZone = ZONE_DATA|ZONE_INFO;
	}
	
	// Iterating through sectors
	for (dwLogSecNb=startSectorAddr; dwLogSecNb<endSectorAddr; dwLogSecNb++)
	{
		// Convert logical address to physical
		dwLogBlckNb = dwLogSecNb / g_FlashSize.dwBlockNbSectors;
		dwPhyBlckNb = g_pBlocksInfo[dwLogBlckNb].wPhysicalNumber;
		dwPhySecNb  = dwPhyBlckNb*g_FlashSize.dwBlockNbSectors + dwLogSecNb%g_FlashSize.dwBlockNbSectors;
		
		//DEBUGMSG(1, (TEXT("FMD_ReadSector : %x\n\r"),dwPhySecNb));	
	


		// Test if the WriteProtection is activated on the current LogicalBlock
		if (g_pBlocksInfo[dwLogBlckNb].wStatus & BLOCK_WP_ACTIVATED)
		{
			bRet = FALSE;
			DEBUGMSG(1, (TEXT("FMD_ReadSector::WriteProtectionSystem reject an ReadCmd on logical block 0x%X (physical 0x%X)\n\r"), dwLogBlckNb, dwPhyBlckNb));
			continue;
		}
		
		// Effective read
		if (!LLD_READSECTOR(pChip, dwZone, dwPhySecNb, g_pSectorBuffer))
		{
			bRet = FALSE;
			DEBUGMSG(1, (TEXT("FMD_ReadSector::Error:Low level read failed on sector 0x%X (physical 0x%X)\n\r"), dwLogSecNb, dwPhySecNb));
			DEBUGMSG(1, (TEXT("FMD_ReadSector::Current block was 0x%X (physical 0x%X)\n\r"), dwLogBlckNb, dwPhyBlckNb));
			continue;
		}
		
		
		// If we want informations, then we had to parse spares
		if (dwZone&ZONE_INFO)
		{
			Sparses2Info(&g_pSectorBuffer[g_FlashSize.dwDataNbBytes], pSectorInfoBuff);
			pSectorInfoBuff++;
		}
		// If we want the data only, just copy them
		if (dwZone&ZONE_DATA)
		{
#ifdef USE_ECC
			BOOL bSectorIsErased = TRUE;
			// if block has been erased, ecc is written FF and should be 00
			for(i=0;i<g_FlashSize.dwSpareNbBytes-sizeof(SectorInfo);i++)
			{
				//DEBUGMSG(1, (TEXT("FMD_ReadSector : ECC Data 0x%X\n\r"), g_pSectorBuffer[g_FlashSize.dwDataNbBytes+sizeof(SectorInfo)+i]));
				if	(g_pSectorBuffer[g_FlashSize.dwDataNbBytes+sizeof(SectorInfo)+i] != 0xFF)
				{
					bSectorIsErased = FALSE;
					break;
				}
			}

			if (bSectorIsErased)
			{
				for(i=0;i<g_FlashSize.dwSpareNbBytes-sizeof(SectorInfo);i++)
				{
					g_pSectorBuffer[g_FlashSize.dwDataNbBytes+sizeof(SectorInfo)+i] = 0x00;
				}
			}

			
			// Check if the data is valid according to ECC
			if (IsECCDataValid(g_pSectorBuffer,g_FlashSize.dwDataNbBytes,&g_pSectorBuffer[g_FlashSize.dwDataNbBytes+sizeof(SectorInfo)]) == FALSE)
			{
				DEBUGMSG(1, (TEXT("FMD_ReadSector : ECC Data Invalid Current block was 0x%X (physical 0x%X)\n\r"), dwLogBlckNb, dwPhyBlckNb));
				// Try to correct it if the data is invalid
				if (CorrectData(g_pSectorBuffer, g_FlashSize.dwDataNbBytes, &g_pSectorBuffer[g_FlashSize.dwDataNbBytes+sizeof(SectorInfo)]) == TRUE)
				{				
					{
						
						BYTE* g_pBlockBuffer = NULL;
						g_pBlockBuffer = (BYTE*)malloc(g_FlashSize.dwBlockNbBytes);
						dwErroBlockNb = dwLogSecNb; 
						//if correction succeeded, read the whole sector, correct the erronous block
						// then erase sector and write it back
						
						//read sector
						
						for (i=0; i<g_FlashSize.dwBlockNbSectors; i++)
						{
							dwPhySecNb  = dwPhyBlckNb*g_FlashSize.dwBlockNbSectors + i % g_FlashSize.dwBlockNbSectors;
							
							// Convert logical address to physical
							if (!LLD_READSECTOR(pChip, ZONE_DATA|ZONE_INFO, dwPhySecNb, &g_pBlockBuffer[i*g_FlashSize.dwSectorNbBytes]))
							{
								bRet = FALSE;
								DEBUGMSG(1, (TEXT("FMD_ReadSector::Error:Low level read failed on sector 0x%X (physical 0x%X)\n\r"), dwLogSecNb, dwPhySecNb));
								DEBUGMSG(1, (TEXT("FMD_ReadSector::Current block was 0x%X (physical 0x%X)\n\r"), dwLogBlckNb, dwPhyBlckNb));
								continue;
							}
						}
						// correct erronous block
						memcpy(&g_pBlockBuffer[(dwErroBlockNb%g_FlashSize.dwBlockNbSectors)*g_FlashSize.dwSectorNbBytes], &g_pSectorBuffer[0], g_FlashSize.dwSectorNbBytes);
						
						//erase block
						if (!LLD_ERASEBLOCK(pChip, dwPhyBlckNb))
						{
							bRet = FALSE;
							DEBUGMSG(1, (TEXT("FMD_EraseBlock::Erase has failed on block  (physical 0x%X)\n\r"), dwPhyBlckNb));
							goto exit;
						}
						
						//write correct block back
						
						for (i=0; i<g_FlashSize.dwBlockNbSectors; i++)
						{
							dwPhySecNb  = dwPhyBlckNb*g_FlashSize.dwBlockNbSectors + i % g_FlashSize.dwBlockNbSectors;
							
							if (!LLD_WRITESECTOR(pChip, ZONE_DATA|ZONE_INFO, dwPhySecNb, &g_pBlockBuffer[i*g_FlashSize.dwSectorNbBytes]))
							{
								bRet = FALSE;
								DEBUGMSG(1, (TEXT("FMD_WriteSector::Error:Low level write failed on sector 0x%X (physical 0x%X)\n\r"), dwLogSecNb, dwPhySecNb));
								DEBUGMSG(1, (TEXT("FMD_WriteSector::Current block was 0x%X (physical 0x%X)\n\r"), dwLogBlckNb, dwPhyBlckNb));
								continue;
							}
						}
						free(g_pBlockBuffer);				
						DEBUGMSG(1, (TEXT("FMD_WriteSector::CorrectData succes Current block was 0x%X (physical 0x%X)\n\r"), dwLogBlckNb, dwPhyBlckNb));
					}
				}
				else
				{
					// Correction failed .... continue the loop but signal an error
					DEBUGMSG(1, (TEXT("FMD_WriteSector:: CorrectData failed Current block was 0x%X (physical 0x%X)\n\r"), dwLogBlckNb, dwPhyBlckNb));
					bRet = FALSE;
					continue;
				}
			}
#endif
		

			memcpy(pSectorBuff, &g_pSectorBuffer[0], g_FlashSize.dwDataNbBytes);
			pSectorBuff+=g_FlashSize.dwDataNbBytes;
		}
	}
	
exit:

	


	// Out
	//DEBUGMSG(1, (TEXT("<-FMD_ReadSector\n\r")));
	
	return bRet;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL FMD_WriteSector(SECTOR_ADDR startSectorAddr, LPBYTE pSectorBuff, PSectorInfo pSectorInfoBuff, DWORD dwNumSectors)
//!
//! \brief		This function write the given sector data and/or info
//!
//! \param		startSectorAddr Logical address of the first sector to read
//! \param		pSectorBuff Pointer to a buffer large enought to store all data bytes
//! \param		pSectorInfoBuff Pointer to a buffer large enought to store all info bytes
//! \param		dwNumSectors Number of sector that should be read
//!
//! \return		\e TRUE When all is good
//!	\return		\e FALSE When there is an error during write
//!
//! An write command should abort when parameters are bad, when WPS is enable,
//! or when LowLevelWrite fail. The FMD return an error message using DEBUGMSG.
//-----------------------------------------------------------------------------
BOOL FMD_WriteSector(SECTOR_ADDR startSectorAddr, LPBYTE pSectorBuff, PSectorInfo pSectorInfoBuff, DWORD dwNumSectors)
{
	BOOL bRet = TRUE;
	DWORD dwZone;
	DWORD dwLogSecNb, dwLogBlckNb, dwPhyBlckNb, dwPhySecNb;
	DWORD endSectorAddr = startSectorAddr + dwNumSectors;

	 
	// In
	//DEBUGMSG(1, (TEXT("->FMD_WriteSector\n\r")));

	// If two bufferpointers are null
	if (!pSectorBuff && !pSectorInfoBuff)
	{
		bRet = FALSE;
		DEBUGMSG(1, (TEXT("FMD_WriteSector::Error, two null parameters\n\r")));
		goto exit;
	}



	// Iterating through sectors
	for (dwLogSecNb=startSectorAddr; dwLogSecNb<endSectorAddr; dwLogSecNb++)
	{
		dwZone =0;
		// If we just want to write the info (ie : databuffer is null)
		if (!pSectorBuff)
		{
			dwZone = ZONE_INFO;
		}
		// Else if we just want to write the data (ie : infobuffer is null)
		else if (!pSectorInfoBuff)
		{
			dwZone = ZONE_DATA;
		}
		// Else we want to write data and info in the sector
		else
		{
			dwZone = ZONE_DATA|ZONE_INFO;
		}

		// Convert logical address to physical
		dwLogBlckNb = dwLogSecNb / g_FlashSize.dwBlockNbSectors;
		dwPhyBlckNb = g_pBlocksInfo[dwLogBlckNb].wPhysicalNumber;
		dwPhySecNb  = dwPhyBlckNb*g_FlashSize.dwBlockNbSectors + dwLogSecNb%g_FlashSize.dwBlockNbSectors;



		// Test if the WriteProtection is activated on the current LogicalBlock
		if (g_pBlocksInfo[dwLogBlckNb].wStatus & BLOCK_WP_ACTIVATED)
		{
			bRet = FALSE;
			DEBUGMSG(1, (TEXT("FMD_WriteSector::WriteProtectionSystem reject an WriteCmd on logical block 0x%X (physical 0x%X)\n\r"), dwLogBlckNb, dwPhyBlckNb));
			continue;
		}


		// If we want to write informations, then we had to create spares
		if (dwZone&ZONE_INFO)
		{			
			Info2Sparses(pSectorInfoBuff, &g_pSectorBuffer[g_FlashSize.dwDataNbBytes]);
			pSectorInfoBuff++;
		}
		
		// If we want to write data, just copy them
		if (dwZone&ZONE_DATA)
		{	
			memcpy(&g_pSectorBuffer[0], pSectorBuff, g_FlashSize.dwDataNbBytes);
			pSectorBuff+=g_FlashSize.dwDataNbBytes;
		}
		
#ifdef USE_ECC
		// ECC management
		// Do we want ot write new data ....
		if (dwZone&ZONE_DATA)
		{
			//Read the spare if we don't write a new spare....
			if ((dwZone&ZONE_INFO) == 0)
			{				
				if (!LLD_READSECTOR(pChip, ZONE_INFO, dwPhySecNb, &g_pSectorBuffer[g_FlashSize.dwDataNbBytes]))
				{
					bRet = FALSE;
					DEBUGMSG(1, (TEXT("FMD_ReadSector::Error:Low level read (read/modify/write spare) failed on sector 0x%X (physical 0x%X)\n\r"), dwLogSecNb, dwPhySecNb));
					DEBUGMSG(1, (TEXT("FMD_ReadSector::Current block was 0x%X (physical 0x%X)\n\r"), dwLogBlckNb, dwPhyBlckNb));
					continue;
				}
			}
			//Compute the ECC and write it in the spare part
			ComputeECC(g_pSectorBuffer,g_FlashSize.dwDataNbBytes,g_pSectorBuffer+g_FlashSize.dwDataNbBytes+sizeof(SectorInfo),g_FlashSize.dwSpareNbBytes-sizeof(SectorInfo));

			//tell the LLD to write the spare as well
			dwZone |= ZONE_INFO;
		}
#endif		
			
		// Effective write
		if (!LLD_WRITESECTOR(pChip, dwZone, dwPhySecNb, g_pSectorBuffer))
		{
			bRet = FALSE;
			DEBUGMSG(1, (TEXT("FMD_WriteSector::Error:Low level write failed on sector 0x%X (physical 0x%X)\n\r"), dwLogSecNb, dwPhySecNb));
			DEBUGMSG(1, (TEXT("FMD_WriteSector::Current block was 0x%X (physical 0x%X)\n\r"), dwLogBlckNb, dwPhyBlckNb));
			continue;
		}
	}

exit:

	// Out
	//DEBUGMSG(1, (TEXT("<-FMD_WriteSector\n\r")));

	return bRet;
}

//-----------------------------------------------------------------------------
//! \fn			DWORD FMD_GetBlockStatus(BLOCK_ID blockID)
//!
//! \brief		This function returns the status of a block.
//!
//! \param		blockID Address of a block
//!
//! \result		There is six different status for a block :
//!				-# \e 0 The block is OK
//!				-# \e BLOCK_STATUS_UNKNOWN The status could not be determined due to a read error
//!				-# \e BLOCK_STATUS_BAD The block is bad
//!				-# \e BLOCK_STATUS_READONLY The block is read-only
//!				-# \e BLOCK_STATUS_RESERVED The block is reserved
//!				-# \e BLOCK_STATUS_XIP The block is reserved for XIP
//-----------------------------------------------------------------------------
DWORD FMD_GetBlockStatus(BLOCK_ID blockID)
{
	DWORD BlkStatus = 0;
	SectorInfo SecInfo;

	if (g_pBlocksInfo[blockID].wStatus & BLOCK_RESERVED)
	{
		return BLOCK_STATUS_RESERVED;
	}

	// Read SectorInfo field for the first sector of the block
	if (!FMD_ReadSector(blockID*g_FlashSize.dwBlockNbSectors, NULL, &SecInfo, 1))
	{
		DEBUGMSG(1, (TEXT("FMD_GetBlockStatus::Can't read SectorInfo for the first sector of logical block 0x%X\n\r"), blockID));
		BlkStatus = BLOCK_STATUS_UNKNOWN;
		goto exit;
	}

	// If the sixth byte isn't equal to 0xFF, the block is bad
	if ( ((UCHAR)(SecInfo.bBadBlock)) != ((UCHAR)0xFF) )
	{
		RETAILMSG(1, (TEXT("FMD_GetBlockStatus::Logical block 0x%X is marked as bad\n\r"), blockID));
		BlkStatus |= BLOCK_STATUS_BAD;
		goto exit;
	}

	// If the fifth byte contain the ReadOnly flag
	
	if (!(SecInfo.bOEMReserved & OEM_BLOCK_READONLY))
	{
		BlkStatus |= BLOCK_STATUS_READONLY;
	}

	if (!(SecInfo.bOEMReserved & OEM_BLOCK_RESERVED))
	{
		BlkStatus |= BLOCK_STATUS_RESERVED;
	}
	
exit:

	// Out
//	DEBUGMSG(1, (TEXT("<-FMD_GetBlockStatus\n\r")));

	return BlkStatus;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL FMD_SetBlockStatus (BLOCK_ID blockID, DWORD dwStatus)
//!
//! \brief		This function set the the status for a block
//!
//! \param		blockID Address of a block
//! \param		dwStatus Combination of flags representing the status
//!
//! \return		\e TRUE When all is good
//!	\return		\e FALSE When there is an error during SetStatus
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
BOOL FMD_SetBlockStatus (BLOCK_ID blockID, DWORD dwStatus)
{

	SectorInfo SecInfo;

	// Read SectorInfo field for the first sector of the block
	if (!FMD_ReadSector(blockID*g_FlashSize.dwBlockNbSectors, NULL, &SecInfo, 1))
	{
		return FALSE;		
	}


	// In
	RETAILMSG(1, (TEXT("->FMD_SetBlockStatus\n\r")));

	if (dwStatus & BLOCK_STATUS_BAD)
	{
		SecInfo.bBadBlock = 0;
	}
	if (dwStatus & BLOCK_STATUS_READONLY)
	{
		SecInfo.bOEMReserved &= ~OEM_BLOCK_READONLY;
	}

	if (SecInfo.bOEMReserved & BLOCK_STATUS_RESERVED)
	{
		SecInfo.bOEMReserved &= ~OEM_BLOCK_RESERVED;
	}

		
	if (Info2Sparses(&SecInfo, &g_pSectorBuffer[g_FlashSize.dwDataNbBytes]))
	{
		if (!FMD_WriteSector(blockID*g_FlashSize.dwBlockNbSectors, NULL, &SecInfo, 1))
		{
			RETAILMSG(1, (L"FMD_SetBlockStatus : Error Writing Spares\r\n"));
		}
	}
	// Out
	RETAILMSG(1, (TEXT("<-FMD_SetBlockStatus\n\r")));

	return FALSE;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL FMD_OEMIoControl(DWORD dwIoControlCode, PBYTE pInBuf, DWORD nInBufSize, PBYTE pOutBuf, DWORD nOutBufSize, PDWORD pBytesReturned)
//!
//! \brief		This function implements user-defined commands for the flash memory device
//!
//! \param		dwIoControlCode Specific IOControl :
//!				-# IOCTL_FMD_GET_INTERFACE
//!				-# ...
//! \param		pInBuf Pointer to a data input buffer
//! \param		nInBufSize Size in byte of the input buffer
//! \param		pOutBuf Pointer to a data output buffer
//! \param		nOutBufSize Size in byte of the output buffer
//! \param		pBytesReturned	Number of effective bytes returned
//!
//! \return		\e TRUE When all is good
//!	\return		\e FALSE When there is an error during IOCtl
//!
//! IOCtl send his error message through the DEBUGMSG function
//-----------------------------------------------------------------------------
BOOL FMD_OEMIoControl(DWORD dwIoControlCode, PBYTE pInBuf, DWORD nInBufSize, PBYTE pOutBuf, DWORD nOutBufSize, PDWORD pBytesReturned)
{
	BOOL hRet = FALSE;
	DEBUGMSG(1, (TEXT("->FMD_OEMIoControl\n\r")));
	switch(dwIoControlCode)
	{
		case IOCTL_DISK_USER_WRITE:
			{
				int		i;
				SG_REQ	*pSgReq		= (SG_REQ*)pInBuf;
				int		Start		= pSgReq->sr_start;
				int		NbSector	= pSgReq->sr_num_sec;
				BYTE	*pData		= MapCallerPtr(pSgReq->sr_sglist[0].sb_buf, NbSector * g_FlashSize.dwDataNbBytes);
				/*------------------------------------
				Be carful ! This is the correct use of mapper in CE 6.0, but don't work correctly
				CeOpenCallerBuffer (
									(void**)&pData, 
									pSgReq->sr_sglist[0].sb_buf, 
									NbSector * g_FlashSize.dwDataNbBytes, 
									ARG_O_PTR,
									FALSE
									);
				------------------------------------*/

				if (pSgReq->sr_sglist[0].sb_len == NbSector * g_FlashSize.dwDataNbBytes)
				{
					for (i=0; i<NbSector; i++)
					{
						FMD_WriteSector(Start, pData, 0, 1);
						pData += g_FlashSize.dwDataNbBytes;
						Start++;
					}
				} else {
					DEBUGMSG(1, (TEXT("FMD_OEMIoControl::Error in IOCTL_DISK_USER_WRITE parameters, could you please check if len(buffer) is a multiple of flash sector size")));
					hRet = FALSE;
				}

				/*------------------------------------
				Be carful ! This is the correct use of mapper in CE 6.0, but don't work correctly
				CeCloseCallerBuffer (
									pData, 
									pSgReq->sr_sglist[0].sb_buf, 
									NbSector * g_FlashSize.dwDataNbBytes, 
									ARG_O_PTR
									);
				------------------------------------*/
				UnMapPtr(pData);

				break;
			}

		case IOCTL_DISK_USER_READ:
			{
				int		i;
				SG_REQ	*pSgReq		= (SG_REQ*)pInBuf;
				int		Start		= pSgReq->sr_start;
				int		NbSector	= pSgReq->sr_num_sec;
				BYTE	*pData		= MapCallerPtr(pSgReq->sr_sglist[0].sb_buf, NbSector * g_FlashSize.dwDataNbBytes);
				/*------------------------------------
				Be carful ! This is the correct use of mapper in CE 6.0, but don't work correctly
				CeOpenCallerBuffer (
									(void**)&pData, 
									pSgReq->sr_sglist[0].sb_buf, 
									NbSector * g_FlashSize.dwDataNbBytes, 
									ARG_I_PTR,
									FALSE
									);
				------------------------------------*/
				if (pSgReq->sr_sglist[0].sb_len == NbSector * g_FlashSize.dwDataNbBytes)
				{
					for (i=0; i<NbSector; i++)
					{
						FMD_ReadSector(Start, pData, 0, 1);
						pData += g_FlashSize.dwDataNbBytes;
						Start++;
					}
				} else {
					DEBUGMSG(1, (TEXT("FMD_OEMIoControl::Error in IOCTL_DISK_USER_READ parameters, could you please check if len(buffer) is a multiple of flash sector size")));
					hRet = FALSE;
				}

				/*------------------------------------
				Be carful ! This is the correct use of mapper in CE 6.0, but don't work correctly
				CeCloseCallerBuffer (
									pData, 
									pSgReq->sr_sglist[0].sb_buf, 
									NbSector * g_FlashSize.dwDataNbBytes, 
									ARG_I_PTR
									);
				------------------------------------*/
				UnMapPtr(pData);
			}
			break;

		case IOCTL_DISK_USER_DELETE:
			{
				int					i;
				DELETE_SECTOR_INFO	*pDsInfo	= (DELETE_SECTOR_INFO*)pInBuf;
				int					Start		= pDsInfo->startsector;
				int					NbSector	= pDsInfo->numsectors;
				int					NbBlock		= NbSector / g_FlashSize.dwBlockNbSectors;
				int					BlockStart	= Start / g_FlashSize.dwBlockNbSectors;

				if (!((Start%g_FlashSize.dwBlockNbSectors) || (NbSector%g_FlashSize.dwBlockNbSectors)))
				{
					for (i=0; i<NbBlock; i++)
					{
						FMD_EraseBlock(BlockStart);
						BlockStart++;
					}
				} else {
					DEBUGMSG(1, (TEXT("FMD_OEMIoControl::Error in IOCTL_DISK_USER_DELETE parameters")));
					hRet = FALSE;
				}
			}
			break;
		default:
			DEBUGMSG(1, (TEXT("FMD_OEMIoControl::Not supported IOCtl : 0x%X\n\r"), dwIoControlCode));
	}
	DEBUGMSG(1, (TEXT("<-FMD_OEMIoControl\n\r")));
	return hRet;
}

//-----------------------------------------------------------------------------
//! \fn			VOID FMD_PowerDown(VOID)
//!
//! \brief		This function suspends power to the flash memory device, if applicable
//!
//! \return		\e TRUE When all is good
//!	\return		\e FALSE When there is an error during PowerDown
//-----------------------------------------------------------------------------
VOID FMD_PowerDown(VOID)
{
	// Stub
}

//-----------------------------------------------------------------------------
//! \fn			VOID FMD_PowerUp(VOID)
//!
//! \brief		This function restores power to the flash memory device, if applicable
//!
//! \return		\e TRUE When all is good
//!	\return		\e FALSE When there is an error during PowerUp
//-----------------------------------------------------------------------------
VOID FMD_PowerUp(VOID)
{
	// Stub
}
//-----------------------------------------------------------------------------
//! \fn			static void ConfigChip()
//!
//! \brief		Called by init to select a specific HW device
//!
//-----------------------------------------------------------------------------
static void ConfigChip()
{
	// In
	DEBUGMSG(1, (TEXT("->ConfigChip\n\r")));

	// Compute all number. (Blocks, Sectors,...)
	g_FlashSize.dwDataNbBytes	= pChip->pFlashDev->dwDataNbBytes;
	g_FlashSize.dwSpareNbBytes	= pChip->pFlashDev->dwSpareNbBytes;
	g_FlashSize.dwBlockNbSectors= pChip->pFlashDev->dwBlockNbSectors;
	g_FlashSize.dwNbBlocks		= pChip->pFlashDev->dwNbBlocks;

	g_FlashSize.dwSectorNbBytes	= g_FlashSize.dwDataNbBytes + g_FlashSize.dwSpareNbBytes;

	g_FlashSize.dwBlockNbData	= g_FlashSize.dwBlockNbSectors * g_FlashSize.dwDataNbBytes;
	g_FlashSize.dwBlockNbSpares	= g_FlashSize.dwBlockNbSectors * g_FlashSize.dwSpareNbBytes;
	g_FlashSize.dwBlockNbBytes	= g_FlashSize.dwBlockNbSectors * g_FlashSize.dwSectorNbBytes;

	g_FlashSize.dwNbSectors		= g_FlashSize.dwNbBlocks * g_FlashSize.dwBlockNbSectors;
	g_FlashSize.dwNbData		= g_FlashSize.dwNbBlocks * g_FlashSize.dwBlockNbData;
	g_FlashSize.dwNbSpares		= g_FlashSize.dwNbBlocks * g_FlashSize.dwBlockNbSpares;
	g_FlashSize.dwNbBytes		= g_FlashSize.dwNbBlocks * g_FlashSize.dwBlockNbBytes;

	pMapPlan = pChip->pFlashDev->pMapping;

	DEBUGMSG(1, (TEXT("ConfigChip::FMD will use these parameters :\n\r")             ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwDataNbBytes    : %d\n\r"), g_FlashSize.dwDataNbBytes    ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwSpareNbBytes   : %d\n\r"), g_FlashSize.dwSpareNbBytes   ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwBlockNbSectors : %d\n\r"), g_FlashSize.dwBlockNbSectors ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwNbBlocks       : %d\n\r"), g_FlashSize.dwNbBlocks       ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwSectorNbBytes  : %d\n\r"), g_FlashSize.dwSectorNbBytes  ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwBlockNbData    : %d\n\r"), g_FlashSize.dwBlockNbData    ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwBlockNbSpares  : %d\n\r"), g_FlashSize.dwBlockNbSpares  ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwBlockNbBytes   : %d\n\r"), g_FlashSize.dwBlockNbBytes   ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwNbSectors      : %d\n\r"), g_FlashSize.dwNbSectors      ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwNbData         : %d\n\r"), g_FlashSize.dwNbData         ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwNbSpares       : %d\n\r"), g_FlashSize.dwNbSpares       ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwNbBytes        : %d\n\r"), g_FlashSize.dwNbBytes        ));

	// Out
	DEBUGMSG(1, (TEXT("<-ConfigChip\n\r")));
}

//-----------------------------------------------------------------------------
//! \fn			BOOL LoadBlocksInfo()
//!
//! \brief		This function load per-block informations (mapping & lock) for the device
//!
//! \return		\e TRUE When all is good
//!	\return		\e FALSE When there is an error during LoadBlocksInfo
//-----------------------------------------------------------------------------
BOOL LoadBlocksInfo()
{	// To do : Save Blocks information in flash :)
	
	BOOL bRet = TRUE;
	DWORD i,j;

	// In
	DEBUGMSG(1, (TEXT("->LoadBlocksInfo\n\r")));

	// Debug only
	DEBUGMSG(1, (TEXT("LoadBlocksInfo::g_pBlocksInfo : 0x%X\n\r"), g_pBlocksInfo));

	// Create an array for each block (valid or not) and fill it with
	// static block info. Currently all blocks are accessible, and there
	// is no mapping

	// Parsing map plan
	for (i=0; i<pMapPlan->dwNbElements; i++)
	{
		// Set all blocks for this map section
		for (j=0; j<pMapPlan->MapSectionArray[i].dwSizeInBlock; j++)
		{
			g_pBlocksInfo[pMapPlan->MapSectionArray[i].dwLogBlock + j].wPhysicalNumber	= (WORD)(pMapPlan->MapSectionArray[i].dwPhyBlock + j); // Only 16bits are revelant
			g_pBlocksInfo[pMapPlan->MapSectionArray[i].dwLogBlock + j].wStatus			= (WORD)(pMapPlan->MapSectionArray[i].dwStatus); // Only 16bits are revelant
		}
	}

	// Out
	DEBUGMSG(1, (TEXT("<-LoadBlocksInfo\n\r")));

	return bRet;
}

static BOOL Sparses2Info(PBYTE pSpares, PSectorInfo pSectorInfoBuff) {
	BOOL bRet = TRUE;

	// Test if we got enough spares to store SectorInfo
	if (g_FlashSize.dwSpareNbBytes < sizeof(SectorInfo))
	{
		bRet = FALSE;
		RETAILMSG(1, (TEXT("Spares2Info::Not enought spares byte to store SectorInfo\n\r")));
		goto exit;
	}

	// Translation is just a copy :)
	memcpy(pSectorInfoBuff, pSpares, sizeof(SectorInfo));

exit:

	return bRet;
}

static BOOL Info2Sparses(PSectorInfo pSectorInfoBuff, PBYTE pSpares) {
	BOOL bRet = TRUE;
	DWORD i;

	// Test if we got enough spares to store SectorInfo
	if (g_FlashSize.dwSpareNbBytes < sizeof(SectorInfo))
	{
		bRet = FALSE;
		RETAILMSG(1, (TEXT("Info2Spares::Not enought spares byte to store SectorInfo\n\r")));
		goto exit;
	}

	// Translation is just a copy :)
	memcpy(pSpares, pSectorInfoBuff, sizeof(SectorInfo));

	// We fill other spares bytes with 0xFF
	for (i=sizeof(SectorInfo); i<g_FlashSize.dwSpareNbBytes; i++)
	{
		pSpares[i] = 0xFF;
	}

exit:

	return bRet;
}

// End of Doxygen group GenericFMD
//! @}

//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/NandFlash/GenericFMD.c $
//-----------------------------------------------------------------------------
//

//! @}
