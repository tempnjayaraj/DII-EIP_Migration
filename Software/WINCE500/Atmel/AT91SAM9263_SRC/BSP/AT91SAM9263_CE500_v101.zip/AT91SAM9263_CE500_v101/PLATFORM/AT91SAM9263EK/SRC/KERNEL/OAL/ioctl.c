//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9263EK/SRC/KERNEL/OAL/ioctl.c
//!
//! \brief		Implements the ioctl table
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/KERNEL/OAL/ioctl.c $
//!   $Author: jjhiblot $
//!   $Revision: 18 $
//!   $Date: 2005-12-19 15:16:58 +0100 (lun., 19 déc. 2005) $
//! \endif
//-----------------------------------------------------------------------------


//! \addtogroup	IOCTL
//! @{

#include <windows.h>
#include <oal.h>

#include "AT91SAM926x_oal_ioctl.h"
#include "at91sam9263EK_ioctl.h"
#include "oal_bootloadersettings.h"

//------------------------------------------------------------------------------
//
//  Define:  IOCTL_PLATFORM_TYPE/OEM
//
//  Defines the platform type and OEM string.
//
#define IOCTL_PLATFORM_TYPE                 (L"AT91SAM9263EK")
#define IOCTL_PLATFORM_OEM                  (L"Adeneo")



//------------------------------------------------------------------------------
//
//  Global: g_oalIoctlPlatformType/OEM    
//
//  Platform Type/OEM
//
LPCWSTR g_oalIoCtlPlatformType = IOCTL_PLATFORM_TYPE;
LPCWSTR g_oalIoCtlPlatformOEM  = IOCTL_PLATFORM_OEM;

//------------------------------------------------------------------------------
//
//  Global: g_oalIoCtlTable[]    
//
//  IOCTL handler table. This table includes the IOCTL code/handler pairs  
//  defined in the IOCTL configuration file. This global array is exported 
//  via oal_ioctl.h and is used by the OAL IOCTL component.
//
//	NOTE: It's possible to override IOCTLs by re-defining them earlier in the following table.
//

const OAL_IOCTL_HANDLER g_oalIoCtlTable[] = {

	{IOCTL_READ_EBOOT_SETTINGS,		0,	OALIoCtlReadBootloaderSettings},
	{IOCTL_WRITE_EBOOT_SETTINGS,	0,	OALIoCtlWriteBootloaderSettings},


#include "AT91SAM926x_ioctl_tab.h"	//Include the IOCTLs supported by the processor
#include <oal_ioctl_tab.h>			// Then include the IOCTLs defined in the OAL.
};


//! @} end of subgroup IOCTL

//! @} end of group OAL

//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/KERNEL/OAL/ioctl.c $
//-----------------------------------------------------------------------------
//
