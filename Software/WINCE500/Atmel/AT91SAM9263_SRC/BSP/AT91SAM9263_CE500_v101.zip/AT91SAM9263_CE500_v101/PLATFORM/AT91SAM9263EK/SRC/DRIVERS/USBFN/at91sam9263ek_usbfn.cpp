//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//! \addtogroup	USBFN
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		at91sam9263ek_usbfn.cpp
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/USBFN/at91sam9263ek_usbfn.cpp $
//!   $Author: ltourlonias $
//!   $Revision: 684 $
//!   $Date: 2007-04-13 14:35:48 +0200 (ven., 13 avr. 2007) $
//! \endif
//!
//! Implementation of the at91sam9263ek USB Device object
//-----------------------------------------------------------------------------

#include <windows.h>


#include "AT91SAM926x_usbfn.h"
#include "AT91SAM926x.h"
#include "AT91SAM926x_oal_intr.h"
#include "at91sam9263ek.h"
#include "atmel_gpio.h"
#include "AT91SAM9263_gpio.h"

class at91sam9263ekUsbDevice: public AT91SAMUsbDevice {
public:
    at91sam9263ekUsbDevice(LPCTSTR lpActivePath)
    :  AT91SAMUsbDevice(lpActivePath)
    {
//		v_pGPIOAReg = NULL;   
    }
    virtual ~at91sam9263ekUsbDevice() 
    {
/*		if (v_pGPIOAReg)
        {
        	MmUnmapIoSpace(v_pGPIOAReg,sizeof(AT91S_PIO));
        }
 */   
    }
//-----------------------------------------------------------------------------
//! \brief		This function enable the pull-up
//!
//! This allows the host to 'see' the device and start enumeration
//-----------------------------------------------------------------------------	
	virtual void EnablePullUp()
	{
		m_pUDP->UDP_TXVC = AT91C_UDP_PUON;
	}
//-----------------------------------------------------------------------------
//! \brief		This function deactivate the pull-up
//!
//! This 'disconnects' the device from the USB bus
//-----------------------------------------------------------------------------	
	virtual void DisablePullUp()
	{	
//		m_pUDP->UDP_TXVC &= ~AT91C_UDP_PUON;
	}

//-----------------------------------------------------------------------------
//! \brief		This function inits the device
//!
//! \param		pvMddContext			pointer to a string containing registry key name
//! \param		pMddInterfaceInfo		pointer to the MDD interface
//! \param		pPddInterfaceInfo		pointer to the PDD interface
//!
//! \return		ERROR_SUCCESS
//!
//-----------------------------------------------------------------------------
    virtual DWORD Init(PVOID pvMddContext, PUFN_MDD_INTERFACE_INFO pMddInterfaceInfo, PUFN_PDD_INTERFACE_INFO pPddInterfaceInfo) 
    {
        DWORD dwReturn = ERROR_INVALID_DATA;
		AT91PS_PMC	pPMC;

		PHYSICAL_ADDRESS ioPhysicalBase;

		/*JJH*/
        ioPhysicalBase.LowPart = (DWORD)AT91C_BASE_PMC;
        ioPhysicalBase.HighPart = 0;  
        pPMC = (AT91PS_PMC)MmMapIoSpace(ioPhysicalBase, sizeof(AT91S_PMC), FALSE);		
		pPMC->PMC_SCER = AT91C_PMC_UDP;
	//	pPMC->PMC_PCER = 1 << AT91C_PMC_UDP;
        
		MmUnmapIoSpace(pPMC,sizeof(AT91S_PMC));
			
/*		if (v_pGPIOAReg == NULL)
        {			
            ioPhysicalBase.LowPart = (DWORD)AT91C_BASE_PIOA;
            ioPhysicalBase.HighPart = 0;  
        	v_pGPIOAReg = (AT91PS_PIO)MmMapIoSpace(ioPhysicalBase, sizeof(AT91S_PIO), FALSE);
        }
		if (!v_pGPIOAReg)
		{
			RETAILMSG(1,(_T("Memory allocation for PIOA failed!!!")));
		}
		else
        {
        }
*/		const struct pio_desc hw_pio[] = 
		{
			{"DET",		AT91C_PIN_PA(PIO_USBD_DETECT_PIN_NUMBER), 0, PIO_PULLUP, PIO_INPUT},
		};
		pio_setup(hw_pio, sizeof(hw_pio));

		dwReturn = AT91SAMUsbDevice::Init(pvMddContext, pMddInterfaceInfo, pPddInterfaceInfo);
		
        return dwReturn;
    }
//-----------------------------------------------------------------------------
//! \brief		This function starts the device
//!
//! \return		ERROR_SUCCESS
//!
//-----------------------------------------------------------------------------
    virtual DWORD Start() 
    {
        DWORD dwReturn = AT91SAMUsbDevice::Start();        
        return dwReturn;
    }
//-----------------------------------------------------------------------------
//! \brief		This function stops the device
//!
//! \return		ERROR_SUCCESS
//!
//-----------------------------------------------------------------------------
    virtual DWORD Stop() 
    {
        DWORD dwReturn = AT91SAMUsbDevice::Stop();
        return dwReturn;
    }
//-----------------------------------------------------------------------------
//! \brief		This function checks if the cable is attached to the device
//!
//! \return		TRUE = cable attached
//! \return		FALSE = cable not attached
//!
//-----------------------------------------------------------------------------
    
	virtual BOOL IsCableAttached() 
    { 		
        if (pio_get_value(AT91C_PIN_PA(PIO_USBD_DETECT_PIN_NUMBER)))
	//		v_pGPIOAReg->PIO_PDSR & PIO_USBD_DETECT_MASK
		{
			return TRUE;
		}
		else
		{			
			return FALSE;
		}
    };
	

//-----------------------------------------------------------------------------
//! \brief		This function initializes an interrupt on the detection pin
//!
//! \return		TRUE = success
//! \return		FALSE = failure
//!
//-----------------------------------------------------------------------------
	BOOL InitializeUSBDetectionInterrupt()
	{
		DWORD dwLogintr = LOGINTR_BASE_PIOA + PIO_USBD_DETECT_PIN_NUMBER;		
		BOOL bResult = TRUE;
		
		m_hDetectionEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
		if (m_hDetectionEvent == NULL)
		{
			bResult = FALSE;
			goto error;
		}
		bResult = KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &dwLogintr, sizeof(dwLogintr), &m_dwDetectionSysintr, sizeof(m_dwDetectionSysintr), 0);
		if (bResult == FALSE)
		{
			goto error;
		}

		InterruptInitialize(m_dwDetectionSysintr, m_hDetectionEvent, 0, 0);
		if (bResult == FALSE)
		{
			goto error;
		}


		return TRUE;
error:
		DeinitializeUSBDetectionInterrupt();
		return FALSE;

	};

/// \brief		This function deinitializes the interrupt on the detection pin
	void DeinitializeUSBDetectionInterrupt()
	{
		HANDLE hTemp;
		InterruptDisable(m_dwDetectionSysintr);
		KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, &m_dwDetectionSysintr, sizeof(m_dwDetectionSysintr), NULL,0,0);		
		m_dwDetectionSysintr = 0;
		hTemp = m_hDetectionEvent;
		CloseHandle(hTemp);		
	};

private:	
//	volatile AT91PS_PIO v_pGPIOAReg; 
};

//-----------------------------------------------------------------------------
//! \brief		This function Create the Device the run thread
//!
//! \param		lpActivePath	Registry path
//!
//! \return		the pointer to the device
//!
//-----------------------------------------------------------------------------
AT91SAMUsbDevice * CreateAT91SAMUsbDevice(LPCTSTR lpActivePath)
{
    return new at91sam9263ekUsbDevice(lpActivePath);
}
//! @}
//! @}