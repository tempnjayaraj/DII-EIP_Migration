//------------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!
//   All rights reserved ADENEO SAS 2005
//!
//------------------------------------------------------------------------------
//! \file		key_code.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/GenericEBOOT/key_code.h $
//!   $Author: ltourlonias $
//!   $Revision: 657 $
//!   $Date: 2007-04-10 16:52:09 +0200 (mar., 10 avr. 2007) $
//! \endif
//------------------------------------------------------------------------------
//! \addtogroup	EBOOT
//! @{

#ifndef KEY_CODE_H
#define KEY_CODE_H

//------------------------------------------------------------------------------
//                                                             Defines and types
//------------------------------------------------------------------------------
#define KEY_SPACE			0x20
#define KEY_ENTER			0x0D

#define KEY_0				0X30
#define KEY_1				0x31
#define KEY_2				0x32
#define KEY_3				0x33
#define KEY_4				0x34
#define KEY_5				0x35
#define KEY_6				0x36
#define KEY_7				0x37
#define KEY_8				0x38
#define KEY_9				0x39
#define KEY_A				0x61
#define KEY_B				0x62
#define KEY_C				0x63
#define KEY_D				0x64
#define KEY_E				0x65
#define KEY_F				0x66
#define KEY_G				0x67
#define KEY_H				0x68
#define KEY_I				0x69
#define KEY_J				0x6A
#define KEY_K				0x6B
#define KEY_L				0x6C
#define KEY_M				0x6D
#define KEY_N				0x6E
#define KEY_O				0x7F
#define KEY_P				0x70
#define KEY_Q				0x71
#define KEY_R				0x72
#define KEY_S				0x73
#define KEY_T				0x74
#define KEY_U				0x75
#define KEY_V				0x76
#define KEY_W				0x77
#define KEY_X				0x78
#define KEY_Y				0x79
#define KEY_Z				0x7A

#define NO_KEY				0x00


#endif  // KEY_CODE_H
//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/GenericEBOOT/key_code.h $
//------------------------------------------------------------------------------
//

//
//! @}
//

//
//! @}
//