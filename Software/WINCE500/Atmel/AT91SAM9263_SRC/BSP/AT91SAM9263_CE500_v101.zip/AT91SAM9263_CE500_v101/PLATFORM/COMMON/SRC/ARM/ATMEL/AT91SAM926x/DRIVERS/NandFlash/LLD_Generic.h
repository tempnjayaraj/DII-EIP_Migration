//-----------------------------------------------------------------------------
//! \addtogroup	DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/NandFlash/LLD_Generic.h
//!
//! \brief		Generic LLD part for NAND Flash memory
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/NandFlash/LLD_Generic.c $
//!   $Author: ltourlonias $
//!   $Revision: 657 $
//!   $Date: 2007-04-10 16:52:09 +0200 (mar., 10 avr. 2007) $
//! \endif
//!
//! 
//-----------------------------------------------------------------------------
//! \addtogroup	NandFlash
//! @{
//!

#ifndef __GENERIC_LLD__
#define __GENERIC_LLD__

#include "NandFlash.h"

BOOL LLDGeneric_EraseBlock(NandChip *, DWORD);
BOOL LLDGeneric_EraseBlock(NandChip *, DWORD);

BOOL LLDGeneric_WriteSectorSmall(NandChip *, DWORD, DWORD, PBYTE);
BOOL LLDGeneric_ReadSectorSmall(NandChip *, DWORD, DWORD, PBYTE);

BOOL LLDGeneric_WriteSectorLarge(NandChip *, DWORD, DWORD, PBYTE);
BOOL LLDGeneric_ReadSectorLarge(NandChip *, DWORD, DWORD, PBYTE);

#endif /*__GENERIC_LLD__*/

// End of Doxygen group NandFlash Driver
//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/NandFlash/LLD_Generic.c $
//-----------------------------------------------------------------------------
//
//! @}
