//-----------------------------------------------------------------------------
//! \addtogroup   OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file			pll.c
//!
//! \brief			PLL management for AT91RM9200
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/KERNEL/PLL/pll.c $
//!   $Author: glemercier $
//!   $Revision: 752 $
//!   $Date: 2007-04-19 02:33:50 -0700 (Thu, 19 Apr 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

#include <windows.h>
#include <nkintr.h>
#include <oal.h>
#include "AT91RM9200.h"
#include "AT91RM9200_interface.h"
#include "lib_AT91RM9200.h"

#define PLL_FREQUENCY_RANGE_LIMIT   155000000

//-----------------------------------------------------------------------------
//! \fn		DWORD GetMainClockFreq(AT91PS_CKGR pCKGR)
//!
//! \brief		Returns value of Main clock in Hz
//!
//!	\param		pointer to clock generator controller
//!
//! \return		value of Main clock in Hz
//!
//! 
//-----------------------------------------------------------------------------
DWORD GetMainClockFreq(AT91PS_CKGR pCKGR)
{
	if (pCKGR->CKGR_MCFR & AT91C_CKGR_MAINRDY)
	{		
		return ((pCKGR->CKGR_MCFR & AT91C_CKGR_MAINF) * (SLOW_CLOCK_FREQUENCY)) / 16;
	}
	else
	{
		return 0;
	}
}

//-----------------------------------------------------------------------------
//! \fn		DWORD GetPLLAFreq(AT91PS_CKGR pCKGR)
//!
//! \brief		Returns value of PLLA clock in Hz
//!
//!	\param		pointer to clock generator controller
//!
//! \return		value of PLLA clock in Hz
//!
//! 
//-----------------------------------------------------------------------------
DWORD GetPLLAFreq(AT91PS_CKGR pCKGR)
{
    DWORD dwMainClk;
    DWORD dwMUL,dwDIV;

	
	dwMainClk = GetMainClockFreq(pCKGR);
    dwMUL = (pCKGR->CKGR_PLLAR & AT91C_CKGR_MULA) >> 16;
    dwDIV = (pCKGR->CKGR_PLLAR & AT91C_CKGR_DIVA) >> 0;
    
    if (dwDIV == 0)
        return 0;

    return (dwMainClk / dwDIV) * (dwMUL+1);
}

//-----------------------------------------------------------------------------
//! \fn		DWORD GetPLLBFreq(AT91PS_CKGR pCKGR)
//!
//! \brief		Returns value of PLLB clock in Hz
//!
//!	\param		pointer to clock generator controller
//!
//! \return		value of PLLB clock in Hz
//!
//! 
//-----------------------------------------------------------------------------
DWORD GetPLLBFreq(AT91PS_CKGR pCKGR)
{

    DWORD dwMainClk;
    DWORD dwMUL,dwDIV;

	dwMainClk = GetMainClockFreq(pCKGR);

    dwMUL = (pCKGR->CKGR_PLLBR & AT91C_CKGR_MULB) >> 16;
    dwDIV = (pCKGR->CKGR_PLLBR & AT91C_CKGR_DIVB) >> 0;
    
    if (dwDIV == 0)
        return 0;

    return (dwMainClk  / dwDIV) * (dwMUL+1);
}


//-----------------------------------------------------------------------------
//! \fn		DWORD AT91RM9200_GetPLLAClock(BOOL bUseShadowedValue)
//!
//! \brief		This function is called by the kernel to retreive the value of the PLLA clock in Hz
//!
//!	\param		TRUE to use shadowed value
//!
//! \return		value of PLLA clock in Hz
//!
//! 
//-----------------------------------------------------------------------------
DWORD AT91RM9200_GetPLLAClock(BOOL bUseShadowedValue)
{
    static DWORD dwPLLAClock = 0xFFFFFFFF;

    if ((dwPLLAClock == 0xFFFFFFFF) || (!bUseShadowedValue))
    {        
        	    
		AT91PS_CKGR pCKGR;
		pCKGR = (AT91PS_CKGR) OALPAtoVA((DWORD) AT91C_BASE_CKGR,FALSE);
		dwPLLAClock = GetPLLAFreq(pCKGR);
    }           
	RETAILMSG(1,(TEXT("PLLA Clock is %d Hz\r\n"),dwPLLAClock));
    return dwPLLAClock; 
}

//-----------------------------------------------------------------------------
//! \fn		DWORD AT91RM9200_GetPLLBClock(BOOL bUseShadowedValue)
//!
//! \brief		This function is called by the kernel to retreive the value of the PLLB clock in Hz
//!
//!	\param		TRUE to use shadowed value
//!
//! \return		value of PLLB clock in Hz
//!
//! 
//-----------------------------------------------------------------------------
DWORD AT91RM9200_GetPLLBClock(BOOL bUseShadowedValue)
{
    static DWORD dwPLLBClock = 0xFFFFFFFF;

    if ((dwPLLBClock == 0xFFFFFFFF) || (!bUseShadowedValue))
    {        
        	    
		AT91PS_CKGR pCKGR;
		pCKGR = (AT91PS_CKGR) OALPAtoVA((DWORD) AT91C_BASE_CKGR,FALSE);
		dwPLLBClock = GetPLLBFreq(pCKGR);
    }           
	RETAILMSG(1,(TEXT("PLLB Clock is %d Hz\r\n"),dwPLLBClock));
    return dwPLLBClock;
}

//-----------------------------------------------------------------------------
//! \fn		DWORD AT91RM9200_GetProcessorClock(BOOL bUseShadowedValue)
//!
//! \brief		This function is called by the kernel to retreive the value of the Processor clock in Hz
//!
//!	\param		TRUE to use shadowed value
//!
//! \return		value of Processor clock in Hz
//!
//! 
//-----------------------------------------------------------------------------
DWORD AT91RM9200_GetProcessorClock(BOOL bUseShadowedValue)
{
	static DWORD dwProcessorClock = 0xFFFFFFFF;

    if ((dwProcessorClock == 0xFFFFFFFF) || (!bUseShadowedValue))
    {        
		DWORD dwInputFreq;	    
		AT91PS_PMC pPMC;		
		AT91PS_CKGR pCKGR;
		pPMC = (AT91PS_PMC) OALPAtoVA((DWORD) AT91C_BASE_PMC,FALSE);
		pCKGR = (AT91PS_CKGR) OALPAtoVA((DWORD) AT91C_BASE_CKGR,FALSE);
		switch (pPMC->PMC_MCKR & AT91C_PMC_CSS)
		{
			case AT91C_PMC_CSS_SLOW_CLK: dwInputFreq = SLOW_CLOCK_FREQUENCY; break;
			case AT91C_PMC_CSS_MAIN_CLK: dwInputFreq = GetMainClockFreq(pCKGR); break;
			case AT91C_PMC_CSS_PLLA_CLK: dwInputFreq = GetPLLAFreq(pCKGR); break;
			case AT91C_PMC_CSS_PLLB_CLK: dwInputFreq = GetPLLBFreq(pCKGR); break;
		}

        if (dwInputFreq != 0)
		{
			dwProcessorClock = dwInputFreq >> ((pPMC->PMC_MCKR & AT91C_PMC_PRES)>>2);
		}
    }           
	RETAILMSG(1,(TEXT("Processor Clock is %d Hz\r\n"),dwProcessorClock));
    return dwProcessorClock;
}

//-----------------------------------------------------------------------------
//! \fn		DWORD AT91RM9200_GetMasterClock(BOOL bUseShadowedValue)
//!
//! \brief		This function is called by the kernel to retreive the value of the Master clock in Hz
//!
//!	\param		TRUE to use shadowed value
//!
//! \return		value of Master clock in Hz
//!
//! 
//-----------------------------------------------------------------------------
DWORD AT91RM9200_GetMasterClock(BOOL bUseShadowedValue)
{        
    static DWORD dwMasterClock = 0xFFFFFFFF;

    if ((dwMasterClock == 0xFFFFFFFF) || (!bUseShadowedValue))
    {        
        
		DWORD temp;
		DWORD dwInputFreq;	    
		AT91PS_PMC pPMC;		
		AT91PS_CKGR pCKGR;
		pPMC = (AT91PS_PMC) OALPAtoVA((DWORD) AT91C_BASE_PMC,FALSE);
		pCKGR = (AT91PS_CKGR) OALPAtoVA((DWORD) AT91C_BASE_CKGR,FALSE);
		switch (pPMC->PMC_MCKR & AT91C_PMC_CSS)
		{
			case AT91C_PMC_CSS_SLOW_CLK: dwInputFreq = SLOW_CLOCK_FREQUENCY; break;
			case AT91C_PMC_CSS_MAIN_CLK: dwInputFreq = GetMainClockFreq(pCKGR); break;
			case AT91C_PMC_CSS_PLLA_CLK: dwInputFreq = GetPLLAFreq(pCKGR); break;
			case AT91C_PMC_CSS_PLLB_CLK: dwInputFreq = GetPLLBFreq(pCKGR); break;
		}

        if (dwInputFreq != 0)
		{
			temp = dwInputFreq >> ((pPMC->PMC_MCKR & AT91C_PMC_PRES)>>2);
			dwMasterClock = temp / (((pPMC->PMC_MCKR & AT91C_PMC_MDIV) >> 8)+1);
		}
		        
    }           
	RETAILMSG(1,(TEXT("Master Clock is %d Hz\r\n"),dwMasterClock));
    return dwMasterClock;  
}

//-----------------------------------------------------------------------------
//! \fn		void AT91RM9200_TurnProcessorClockOff()
//!
//! \brief		This function is called by the kernel to stop the processor clock and thus enter the idle/suspend mode.
//!
//!
//! 
//-----------------------------------------------------------------------------
void AT91RM9200_TurnProcessorClockOff()
{
	AT91PS_PMC pPMC;
	pPMC = (AT91PS_PMC) OALPAtoVA((DWORD) AT91C_BASE_PMC,FALSE);
	if (pPMC == NULL)
	{
		return;
	}
	pPMC->PMC_SCDR = AT91C_PMC_PCK;
}


static void ComputeMulAndDiv(DWORD dwSrcFreqInHz, DWORD dwDestFreqInHz, DWORD *pMul, DWORD *pDiv)
{
	DWORD dwMul,dwDiv;
	DWORD dwDestFreqInKHz = dwDestFreqInHz / 1000;
	DWORD dwSrcFreqInKHz = dwSrcFreqInHz / 1000;
	
	dwDiv = 255 * 2;	
	do
	{
		dwDiv /= 2;
		dwMul = (dwDestFreqInKHz * dwDiv) / dwSrcFreqInKHz;
		
	} while (dwMul > 2048);
	
	*pMul = dwMul;
	*pDiv = dwDiv;
}


//-----------------------------------------------------------------------------
//! \fn		DWORD AT91RM9200_SetPLLBFreq(AT91PS_CKGR pCKGR,AT91PS_PMC pPMC,DWORD dwFreqInMHz,DWORD dwUSBDivider)
//!
//! \brief		This function is called by the kernel to set the PLLB frequency
//!
//-----------------------------------------------------------------------------
DWORD AT91RM9200_SetPLLBFreq(	AT91PS_CKGR pCKGR	, 
								AT91PS_PMC pPMC		, 
								DWORD dwFreqInMHz	, 
								DWORD dwUSBDivider	)
{
    DWORD dwTemp = 0;
    DWORD dwFreq, dwMainClock;  	
	DWORD dwDiv;
	DWORD dwMul;
	
	dwMainClock = GetMainClockFreq(pCKGR);
	ComputeMulAndDiv(dwMainClock, dwFreqInMHz * 1000000, &dwMul, &dwDiv);
        
    dwTemp |= (dwMul << 16) | (dwDiv);    
    dwTemp |= dwUSBDivider;
        
        
    dwFreq = (dwMainClock / dwDiv) * (dwMul+1);    
    if (dwFreq < PLL_FREQUENCY_RANGE_LIMIT)
    {
        dwTemp |= AT91C_CKGR_OUTB_0;
    }
    else
    {
        dwTemp |= AT91C_CKGR_OUTB_2;
    }
    
    dwTemp |= (AT91C_CKGR_PLLBCOUNT & (0x3FF << 8)); //Maximum setup time (we don't really know the characteristics of the PLL filter implemented on the board).
    
    
    pCKGR->CKGR_PLLBR = dwTemp;
    
    while ((pPMC->PMC_SR & AT91C_PMC_LOCKB) == 0);    
    
    return 0;
}

#define DEFAULT_BUS_RATIO	4
#define MAX_PRESCALER		6

#define PLL_OUT_RANGE_MIN	80


BOOL AT91RM9200_SetProcessorAndMasterClocks(AT91PS_PMC pPMC,AT91PS_CKGR pCKGR,DWORD dwProcessorClockInMHz,DWORD dwBusClockRatio		)
{
#ifdef IS_MISTRAL
	return TRUE;
#else
	DWORD PLLA_CountBeforeStable;
	DWORD PLLA_Divider;
	DWORD PLLA_Multipler;
	DWORD PLLA_BusRatio;
	DWORD dwTemp;
	DWORD dwPrescaler = 0;
		
	DWORD dwTargetPLLFrequencyInMHz = dwProcessorClockInMHz;


	DEBUGMSG(1,(TEXT("Target processor Frequency is %d\r\nTarget Bus Frequency is %d\r\n"),dwProcessorClockInMHz,dwProcessorClockInMHz/dwBusClockRatio));

	/* Compute the prescaler if needed */
	while (dwTargetPLLFrequencyInMHz < PLL_OUT_RANGE_MIN)
	{
		dwPrescaler++;
		if (dwPrescaler > MAX_PRESCALER)
		{
			return FALSE;
		}
		dwTargetPLLFrequencyInMHz = dwProcessorClockInMHz * (1 << dwPrescaler);
	}

	// Clip the selected bus ratio
	if ((dwBusClockRatio != 1) && (dwBusClockRatio != 2) && (dwBusClockRatio != 4))
	{
		RETAILMSG(1,(TEXT("AT91RM9200_SetProcessorAndMasterClocks : Invalid bus ratio (%d). Setting default (%d)\r\n"),dwBusClockRatio,DEFAULT_BUS_RATIO));
		dwBusClockRatio = 4;
	}


	PLLA_CountBeforeStable	= 0x100;	
	PLLA_BusRatio			= 0;

	DEBUGMSG(1,(TEXT("2 Prescaler is %d\r\nTarget PLL A Frequency is %d MHz\r\n"),dwPrescaler,dwTargetPLLFrequencyInMHz));

	{
		// Small tempo to let the Chip a bit time to settle.
		// Someow it's no good to write characters on the serial before a bit.
		volatile DWORD dwTempo = 10000;
		while (dwTempo--);
	}

	ComputeMulAndDiv(GetMainClockFreq(pCKGR), dwTargetPLLFrequencyInMHz*1000000, &PLLA_Multipler, &PLLA_Divider);	
	//DEBUGMSG(1,(TEXT("PLLA_Divider %d PLLA_Multipler %d"),PLLA_Divider,PLLA_Multipler));


	// Switch MasterClock To SlowClock, with a prescaler of 1 and a bus divider of 2
    pPMC->PMC_MCKR = AT91C_PMC_MDIV_2 | AT91C_PMC_PRES_CLK | AT91C_PMC_CSS_SLOW_CLK;

	// Waiting that MasterClock is stable
 	while ((pPMC->PMC_SR & AT91C_PMC_MCKRDY) == 0);


	// PLLA Configuration
	dwTemp = AT91C_CKGR_SRCA | (PLLA_Multipler<<16) | (PLLA_CountBeforeStable<<8) | PLLA_Divider;

	if ((dwTargetPLLFrequencyInMHz*1000000) < PLL_FREQUENCY_RANGE_LIMIT)
    {
        dwTemp |= AT91C_CKGR_OUTA_0;
    }
    else
    {
        dwTemp |= AT91C_CKGR_OUTA_2;
    }

	pCKGR->CKGR_PLLAR = dwTemp;
	
	// Waiting for PLLA to be stable
	while ((pPMC->PMC_SR & AT91C_PMC_LOCKA) == 0); 

	// Selecting the right Bus Ratio
	switch (dwBusClockRatio)
	{
		case 1:
			PLLA_BusRatio = AT91C_PMC_MDIV_1;
			break;
		case 2:
			PLLA_BusRatio = AT91C_PMC_MDIV_2;
			break;
		case 4:
			PLLA_BusRatio = AT91C_PMC_MDIV_3;
			break;
		default:
			PLLA_BusRatio = AT91C_PMC_MDIV_3;
	}

	// Switch MasterClock to PLLA
	pPMC->PMC_MCKR = PLLA_BusRatio | AT91C_PMC_CSS_PLLA_CLK | (dwPrescaler << 2);

	// Waiting fo MasterClock to be locked
	while ((pPMC->PMC_SR & AT91C_PMC_MCKRDY) == 0);

	{
		// Small tempo to let the Chip a bit time to settle.
		// Someow it's no good to write characters on the serial before a bit.
		volatile DWORD dwTempo = 10000;
		while (dwTempo--);
	}

    return TRUE;
#endif
}
//! @}






