//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		kitl_cfg.h
//!
//! \brief		Supported Kitl Devices definitions
//!
//! \if subversion
//!   $URL: http://centaure/svn/thales_navigation-bsp_nadia2ek/TRUNK/WINCE500/PLATFORM/nadia2EK/SRC/INC/kitl_cfg.h $
//!   $Author: jjhiblot $
//!   $Revision: 18 $
//!   $Date: 2005-12-19 15:16:58 +0100 (lun., 19 déc. 2005) $
//! \endif
//-----------------------------------------------------------------------------

//
#ifndef __KITL_CFG_H
#define __KITL_CFG_H

#include "oal_ethdrv.h"
#include "oal_serialdrv.h"
//------------------------------------------------------------------------------

OAL_KITL_SERIAL_DRIVER g_kitlCspSerial	= OAL_SERIALDRV_DBGU; 
OAL_KITL_ETH_DRIVER g_kitlEthEMACB		= OAL_ETHDRV_EMACB;
#ifdef KITL_NE2000_PCMCIA_SUPPORT    
OAL_KITL_ETH_DRIVER g_kitlEthNE2000     = OAL_ETHDRV_NE2000;
#endif

OAL_KITL_DEVICE g_kitlDevices[] = {
#ifdef KITL_ON_SERIAL
    {
        L"CSPSERIAL", Internal, (DWORD) AT91C_BASE_DBGU, 0,
        OAL_KITL_TYPE_SERIAL, &g_kitlCspSerial
    },
#endif
    { 
        L"EMACB", Internal, (DWORD) AT91C_BASE_MACB, 0, OAL_KITL_TYPE_ETH, 
        &g_kitlEthEMACB
    },
#ifdef KITL_NE2000_PCMCIA_SUPPORT    
	{ 
        L"NE2000_PCCARD", Internal, (BULVERDE_BASE_REG_PA_PCMCIA_S0_IO + 0x300), 0, OAL_KITL_TYPE_ETH, 
        &g_kitlEthNE2000
    },
    { 
        L"NE2000_PCCARD", Internal, (BULVERDE_BASE_REG_PA_PCMCIA_S1_IO + 0x300), 0, OAL_KITL_TYPE_ETH, 
        &g_kitlEthNE2000
    },
#endif

    {
        NULL, 0, 0, 0, 0, NULL
    }
};    

//------------------------------------------------------------------------------

#endif

//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/thales_navigation-bsp_nadia2ek/TRUNK/WINCE500/PLATFORM/nadia2EK/SRC/INC/kitl_cfg.h $
//-----------------------------------------------------------------------------
//