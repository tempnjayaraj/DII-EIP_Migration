//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/WATCHDOG/watchdog.c
//!
//! \brief		support for the AT91SAM926x's watchdog
//!
//! Watchdog support can be disbled by adding OAL_NO_WATCHDOG in the environment variables
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/WATCHDOG/watchdog.c $
//!   $Author: pblanchard $
//!   $Revision: 1090 $
//!   $Date: 2007-07-13 07:07:28 -0700 (Fri, 13 Jul 2007) $
//! \endif
//-----------------------------------------------------------------------------

//! \addtogroup	WATCHDOG
//! @{

#include <windows.h>
#include <oal.h>
#include "at91sam926x.h"
#include "at91sam926x_timebomb.h"

extern DWORD WatchdogProcSpecificGetWDTCBaseAddress(void);
extern DWORD WatchdogProcSpecificGetClockFrequency(void);

#ifndef OAL_NO_WATCHDOG

/// Frequency of the watchdo counter as defined in the datasheet of the processor
#define WATCHDOG_COUNTER_FREQUENCY (WatchdogProcSpecificGetClockFrequency()/128)

//
// kernel exports
//
extern void (* pfnOEMRefreshWatchDog) (void);   ///< function pointer used by the kernel to call the function to refresh watchdog

/// virtual base address of the watchdog controller
static AT91PS_WDTC g_pWatchdog;

//-----------------------------------------------------------------------------
//! \fn       void AT91SAM926x_RefreshWatchDog(AT91PS_WDTC pWatchdog)
//!
//!	\brief 	  This function is used to refresh the watchdog
//!
//!	\param 	  pWatchdog pointer to a AT91PS_WDTC structure
//! 
//!
//-----------------------------------------------------------------------------
void AT91SAM926x_RefreshWatchDog(AT91PS_WDTC pWatchdog)
{
   //Restart the Watchdog
	DEBUGMSG(1,(TEXT("AT91SAM926x_RefreshWatchDog!\r\n")));
	pWatchdog->WDTC_WDCR = (0xA5 << 24) | AT91C_WDTC_WDRSTT;	
}

//-----------------------------------------------------------------------------
//! \fn       DWORD AT91SAM926x_SetWatchDogConfiguration(AT91PS_WDTC pWatchdog, DWORD flags, DWORD dwWatchdogPeriod)
//!
//!	\brief 	  This function sets the watchdog configuration
//!
//!	\param 	  pWatchdog	 pointer to a AT91PS_WDTC structure
//!	\param 	  flags Flags for watchdog configuration
//!	\param 	  dwWatchdogPeriod Watchdog period asked
//!
//!	\return	  Watchdog period configured after timer restriction apply
//! 
//-----------------------------------------------------------------------------
DWORD AT91SAM926x_SetWatchDogConfiguration(AT91PS_WDTC pWatchdog, DWORD flags, DWORD dwWatchdogPeriod)
{
	DWORD dwTemp;

	

	//dwWatchdogPeriod is in ms, convert it in 'watchdog ticks' and clip it
	dwTemp = (dwWatchdogPeriod * WATCHDOG_COUNTER_FREQUENCY) / 1000;		

	RETAILMSG(1,(TEXT("AT91SAM926x_SetWatchDogConfiguration %d => %d\r\n"),dwWatchdogPeriod,dwTemp));


	if (dwTemp > 0xFFF)
	{
		dwTemp = 0xFFF;
		RETAILMSG(1,(TEXT("Clipping The Watchdog period to the maximum : 0xFFF (%d ms)\r\n"),(dwTemp * 1000) / WATCHDOG_COUNTER_FREQUENCY));
	}	
	dwWatchdogPeriod   = (dwTemp * 1000) / WATCHDOG_COUNTER_FREQUENCY;
	
	
	//Change the period of the watchdog (and also its delta value) but keep the other settings ...
	pWatchdog->WDTC_WDMR = flags | ((dwTemp<<16) | (dwTemp<<0));

	return dwWatchdogPeriod;
}

//-----------------------------------------------------------------------------
//! \fn       void OEMRefreshWatchDog(void)
//!
//!	\brief    This function is the OAL interface for refreshing the watchdog
//! 
//!
//!
//!
//-----------------------------------------------------------------------------
void OEMRefreshWatchDog(void)
{	
	AT91SAM926x_RefreshWatchDog(g_pWatchdog);
	TIMEBOMB_CHECK(L"WATCHDOG");
}
#endif //#OAL_NO_WATCHDOG


//-----------------------------------------------------------------------------
//! \fn DWORD OEMInitWatchDogTimer (DWORD dwWatchdogPeriod)
//!
//!	\brief This function initializes the hardware and so the software, so that the Kernel is provided with a Hardware Watchdog.
//!
//!	\param	dwWatchdogPeriod	Initial period of watchdog asked
//!
//!	\return	Watchdog period configured after timer restriction apply
//-----------------------------------------------------------------------------
DWORD OEMInitWatchDogTimer (DWORD dwWatchdogPeriod)
{
#ifndef OAL_NO_WATCHDOG
	DWORD dwResult;
#endif

	TIMEBOMB_INIT_ONCE(DEFAULT_TIME_BOMB);

	RETAILMSG(1, (L"+OEMInitWatchDogTimer\r\n"));
	//At this point the watchdog is disabled ....
#ifdef OAL_NO_WATCHDOG
	OALMSG(OAL_FUNC, (L"+OEMInitWatchDogTimer (DISABLED)\r\n"));
	{
		AT91PS_WDTC pWatchdog = OALPAtoVA (WatchdogProcSpecificGetWDTCBaseAddress(), FALSE);		
		pWatchdog->WDTC_WDMR = AT91C_WDTC_WDDIS;
	}
	return 0;
#else
    OALMSG(OAL_FUNC, (L"+OEMInitWatchDogTimer\r\n"));
	g_pWatchdog = OALPAtoVA (WatchdogProcSpecificGetWDTCBaseAddress(), FALSE);
	RETAILMSG(1,(TEXT("AT91SAM926x_DispWatchDog %x!\r\n"),g_pWatchdog->WDTC_WDMR));

	//Set the watcdog period
	dwResult = AT91SAM926x_SetWatchDogConfiguration(g_pWatchdog,AT91C_WDTC_WDRSTEN | AT91C_WDTC_WDDBGHLT | AT91C_WDTC_WDIDLEHLT, dwWatchdogPeriod);

    pfnOEMRefreshWatchDog = OEMRefreshWatchDog;
    
	
    OALMSG(1, (L"-OEMInitWatchDogTimer (result = %d)\r\n",dwResult));

	return dwResult;
#endif

}
//! @} end of subgroup WATCHDOG

//! @} end of group OAL

////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/WATCHDOG/watchdog.c $
////////////////////////////////////////////////////////////////////////////////
//
