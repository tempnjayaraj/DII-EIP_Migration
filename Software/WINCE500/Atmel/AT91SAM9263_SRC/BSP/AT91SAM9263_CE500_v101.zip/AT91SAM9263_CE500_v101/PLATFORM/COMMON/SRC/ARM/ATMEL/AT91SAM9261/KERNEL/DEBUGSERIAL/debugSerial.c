//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9261/KERNEL/DEBUGSERIAL/debugSerial.c
//!
//! \brief		AT91SAM9261 debug serial feature
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9261/KERNEL/DEBUGSERIAL/debugSerial.c $
//!   $Author: pblanchard $
//!   $Revision: 984 $
//!   $Date: 2007-06-11 09:19:22 -0700 (Mon, 11 Jun 2007) $
//! \endif
//-----------------------------------------------------------------------------

//! \addtogroup	DEBUGSERIAL
//! @{

#include <windows.h>
#include <oal.h>
#include "AT91SAM926x.h"
#include "AT91SAM926x_interface.h"
#include "lib_AT91SAM926x.h"


#define DBGU_BAUDRATE	(115200)
//------------------------------------------------------------------------------
/// This function initializes the debug serial port of the AT91SAM9261
/// \return TRUE indicates success
/// \return FALSE indicates failure
BOOL OEMInitDebugSerial ()
{
	DWORD			dwMasterClock;
	AT91PS_PIO		pPIOA = OALPAtoVA((DWORD) AT91C_BASE_PIOA,FALSE);	

    if (g_pDBGU == NULL)
    {
        g_pDBGU = OALPAtoVA((DWORD) AT91C_BASE_DBGU,FALSE);
    }

	dwMasterClock = AT91SAM926x_GetMasterClock(FALSE);

   	// Open PIO for DBGU
	pPIOA->PIO_PDR = (AT91C_PA10_DTXD | AT91C_PA9_DRXD);
	pPIOA->PIO_ASR = (AT91C_PA10_DTXD | AT91C_PA9_DRXD);
	

	// Configure DBGU
	AT91F_US_Configure (
		(AT91PS_USART) g_pDBGU,          // DBGU base address
		dwMasterClock,             //
		AT91C_US_ASYNC_MODE,  // mode Register to be programmed
		DBGU_BAUDRATE,              // baudrate to be programmed
		0);                   // timeguard to be programmed

	// Enable Transmitter
	AT91F_US_EnableTx((AT91PS_USART) g_pDBGU);    
	// Enable Receiver
	AT91F_US_EnableRx((AT91PS_USART) g_pDBGU);	

	return TRUE;
}

//! @} end of subgroup DEBUGSERIAL

//! @} end of group OAL


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9261/KERNEL/DEBUGSERIAL/debugSerial.c $
////////////////////////////////////////////////////////////////////////////////
//
