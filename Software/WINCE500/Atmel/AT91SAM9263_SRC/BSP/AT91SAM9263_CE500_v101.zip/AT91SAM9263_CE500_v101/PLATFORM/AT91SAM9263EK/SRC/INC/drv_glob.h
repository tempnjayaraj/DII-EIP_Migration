//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		drv_glob.h
//!
//! \brief		Provides the C definitions for the driver globals area
//!
//! \if subversion
//!   $URL: http://centaure/svn/thales_navigation-bsp_nadia2ek/TRUNK/WINCE500/PLATFORM/nadia2EK/SRC/INC/drv_glob.h $
//!   $Author: jjhiblot $
//!   $Revision: 135 $
//!   $Date: 2006-03-06 09:29:00 +0100 (lun., 06 mars 2006) $
//! \endif
//-----------------------------------------------------------------------------

#ifndef AT91SAM9263EK_DRV_GLOB_H
#define AT91SAM9263K_DRV_GLOB_H

#include "args.h"

#define PAD(label,amt) UCHAR Pad##label[amt]

#pragma pack(1)

// Miscellaneous
typedef struct _MISC_GLOBALS {	
    PAD(0, 0x100);
} MISC_GLOBALS, *PMISC_GLOBALS;


//------------------------------------------------------------------------------
//
// Bootloader parameters passed to the image.
//
//------------------------------------------------------------------------------

typedef struct _DRIVER_GLOBALS
{
// offset 0x0000
	volatile DWORD	FiqCounter;
	MISC_GLOBALS	misc_glob;
	PAD(0,0x800 -sizeof(MISC_GLOBALS) -sizeof(DWORD));	
	
// Offset 0x0800
	DWORD FirstNonZeroVariable;
	// The following structs will not be zero initialized (see defs above)
	BOOL bEboot;// reset through eboot	
	BSP_ARGS BSPArgs; //BSP parameteres passed by the bootloader  
    BOOL bForceCleanBoot; // Force clean boot option (may be used in case
	PAD(1,0x800 -sizeof(BSP_ARGS) -sizeof(BOOL) -sizeof(DWORD) -sizeof(BOOL));   
// Offset 0x1000    
} DRIVER_GLOBALS, *PDRIVER_GLOBALS;


#pragma pack()

#endif // AT91SAM9263EK_DRV_GLOB_H

//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/thales_navigation-bsp_nadia2ek/TRUNK/WINCE500/PLATFORM/nadia2EK/SRC/INC/drv_glob.h $
//-----------------------------------------------------------------------------
//