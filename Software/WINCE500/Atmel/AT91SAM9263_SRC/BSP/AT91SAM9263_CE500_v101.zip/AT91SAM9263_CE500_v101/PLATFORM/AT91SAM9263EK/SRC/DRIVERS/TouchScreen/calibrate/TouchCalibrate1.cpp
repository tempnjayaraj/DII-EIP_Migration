//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//
//! \file		TouchCalibrate1.cpp
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/TouchScreen/calibrate/TouchCalibrate1.cpp $
//!   $Author: ltourlonias $
//!   $Revision: 684 $
//!   $Date: 2007-04-13 14:35:48 +0200 (ven., 13 avr. 2007) $
//! \endif
//		TODO
// AT91RM9200 Adaptation: ADESET SAS
//
//-----------------------------------------------------------------------------
//! \addtogroup TOUCHSCREEN
//! @{
//

#include "stdafx.h"

extern "C" BOOL WINAPI TouchCalibrate(void);


BOOL CalibrationOK()
{
    HKEY hKeybd;
    DWORD status;


    status = RegOpenKeyEx(
                HKEY_LOCAL_MACHINE,
                _T("HARDWARE\\DEVICEMAP\\TOUCH"),
                0,
                0,
                &hKeybd);
    if (status) {   	
        return FALSE;
    }


	
	status = RegQueryValueEx(hKeybd,_T("CalibrationData"),NULL,NULL,NULL,NULL);		//note that the data is not required, we only want to see wether the key exists

	RegCloseKey(hKeybd);

    if (status != ERROR_SUCCESS) {
		return FALSE;
    }

	return TRUE; 
}   




int WINAPI WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR     lpCmdLine,
                     int       nCmdShow)
{
	BOOL errcode;

	if (!CalibrationOK())	
	{
		errcode=TouchCalibrate();
	}

	return 0;
}

//! @}

//! @}
