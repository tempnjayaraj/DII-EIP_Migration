//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/EEPROM/eeprom.h
//
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/EEPROM/eeprom.h $
//!   $Author: ltourlonias $
//!   $Revision: 684 $
//!   $Date: 2007-04-13 14:35:48 +0200 (ven., 13 avr. 2007) $
//! \endif
//
// Header for EEPROM driver
//-----------------------------------------------------------------------------
//! \addtogroup EEPROM
//! @{
//  

#ifndef __EEPROM_H__
#define __EEPROM_H__



typedef struct {
	AT91PS_PIO pPioBaseAddress;
	DWORD dwOpenCount;
	CRITICAL_SECTION	cs;
	DWORD dwPageSize;
	DWORD dwTotalSize;
	HANDLE	hI2CDevice;
	DWORD dwI2CAddr;
	WCHAR I2CDeviceName[6];
	DWORD dwLastWriteTime;
} T_EEPROMINIT_STRUCTURE;

typedef struct {
	T_EEPROMINIT_STRUCTURE *pDeviceContext;
	DWORD dwAccessCode;
	DWORD dwShareMode;
	DWORD dwCurrentOffset;
} T_EEPROMOPEN_STRUCTURE;


BOOL	WINAPI	DllEntry(HANDLE hinstDLL, DWORD dwReason, LPVOID  lpvReserved); 
DWORD	EEP_Init	(LPCTSTR pContext, LPCVOID lpvBusContext);
BOOL	EEP_Deinit	(T_EEPROMINIT_STRUCTURE *pDeviceContext);
DWORD	EEP_Open	(T_EEPROMINIT_STRUCTURE *pDeviceContext, DWORD AccessCode, DWORD ShareMode);
BOOL	EEP_Close	(T_EEPROMOPEN_STRUCTURE *pOpenContext);
DWORD	EEP_Read	(T_EEPROMOPEN_STRUCTURE *pOpenContext, LPVOID pBuffer, DWORD dwCount);
DWORD	EEP_Write	(T_EEPROMOPEN_STRUCTURE *pOpenContext, LPCVOID pBuffer, DWORD dwCount);
DWORD	EEP_Seek	(T_EEPROMOPEN_STRUCTURE *pOpenContext, long Amount, WORD wType);
BOOL	EEP_IOControl (T_EEPROMOPEN_STRUCTURE *pOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut);
void	EEP_PowerDown (T_EEPROMINIT_STRUCTURE *pDeviceContext);
void	EEP_PowerUp	  (T_EEPROMINIT_STRUCTURE *pDeviceContext);


#endif // #define __EEPROM_H__

// End of Doxygen group EEPROM
//! @}
//! @}
//-----------------------------------------------------------------------------
// End of $RCSfile: $
//-----------------------------------------------------------------------------
