//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x_oal_intr.h
//!
//! \brief		common definitions of the interrupt constants for the AT91SAM926x processors
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/AT91SAM926x_oal_intr.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//-----------------------------------------------------------------------------

#ifndef AT91SAM926X_OALINTR_H
#define AT91SAM926X_OALINTR_H

#include <nkintr.h>

#define LOGINTR_UNDEFINED    ((DWORD)-1)
#define LOGINTR_MIN            0

#define LOGINTR_AIC_FIRST             		1 //First AIC's irq
#define LOGINTR_AIC_LAST                    31 //Last AIC's irq
                            
                         
BOOL SOCDisableIrq(DWORD irq, BOOL* pOldState);
BOOL SOCEnableIrq(DWORD irq);
void SOCSaveAndDisableAllIntrBeforeSuspend();
void SOCRestoreAllIntrAfterSuspend();

#if   defined   PROC_AT91SAM9260
#include "at91sam9260_oal_intr.h"
#elif   defined   PROC_AT91SAM9261
#include "at91sam9261_oal_intr.h"
#elif defined   PROC_AT91SAM9262
#include "at91sam9262_oal_intr.h"
#elif defined   PROC_AT91SAM9263
#include "at91sam9263_oal_intr.h"
#else
#error A Processor must be defined
#endif

#endif

//! @}


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/AT91SAM926x_oal_intr.h $
////////////////////////////////////////////////////////////////////////////////
//
