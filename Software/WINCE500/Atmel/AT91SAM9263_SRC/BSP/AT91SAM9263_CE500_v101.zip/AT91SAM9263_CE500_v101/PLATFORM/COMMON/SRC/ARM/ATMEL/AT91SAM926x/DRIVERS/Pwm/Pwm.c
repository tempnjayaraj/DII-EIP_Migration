//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		Pwm.c
//!
//! \brief		Common part of the stream driver allowing the management of PWM
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/Pwm/Pwm.c $
//!   $Author: pblanchard $
//!   $Revision: 984 $
//!   $Date: 2007-06-11 09:19:22 -0700 (Mon, 11 Jun 2007) $
//! \endif
//!
//! This driver manages 3 PWM channels and each channel can drive 2 PWM signals
//-----------------------------------------------------------------------------
//! \addtogroup	PWM
//! @{
//!

// System include
#include <windows.h>
#include <memory.h>
#include <nkintr.h>
#include <CEDDK.h>
#include <Devload.h>

// Local include
#include "AT91SAM926x.h"
#include "lib_AT91SAM926x.h"
#include "AT91SAM926x_oal_intr.h"
#include "Pwm_DbgZones.h"
#include "AT91SAM926x_oal_ioctl.h"
#include "AT91SAM926x_pwm_ioctl.h"
#include "Pwm.h"

// The dpCurSettings structure for debug zones
#ifdef DEBUG
DBGPARAM dpCurSettings =
{
    TEXT("PWM"),
    {
        TEXT("Init"),
        TEXT("DeInit"),
        TEXT("Open"),
        TEXT("Close"),
        TEXT("Read"),
        TEXT("Write"),
        TEXT("Seek"),
        TEXT("IOCtl"),
        TEXT("na"),
        TEXT("na"),
        TEXT("na"),
        TEXT("na"),
        TEXT("na"),
        TEXT("Info"),
        TEXT("Warning"),
        TEXT("Error")
    }
    , MASK_INIT | MASK_DEINIT | MASK_INFO | MASK_ERROR
};
#endif

//-----------------------------------------------------------------------------
//! \fn			BOOL WINAPI PWM_DllEntry(HANDLE hinstDLL, DWORD dwReason, LPVOID lpvReserved)
//!
//! \brief		This function is the entry point of the Dll driver
//!
//! \param		hinstDLL	DLL instance
//! \param		dwReason	Reason of the call
//! \param		lpvReserved	Not used
//!
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//!
//! This function intialize debug zone when called with the DLL_PROCESS_ATTACH reason
//-----------------------------------------------------------------------------
BOOL WINAPI PWM_DllEntry(HANDLE hinstDLL, DWORD dwReason, LPVOID lpvReserved)
{
    switch(dwReason)
    {
    case DLL_PROCESS_ATTACH:
        DEBUGREGISTER((HMODULE)hinstDLL);
        DEBUGMSG(ZONE_INFO,(TEXT("Pwm Driver: DLL_PROCESS_ATTACH\n")));
   	break;

    case DLL_THREAD_ATTACH:
        DEBUGMSG(ZONE_INFO,(TEXT("Pwm Driver: DLL_THREAD_ATTACH\n")));
	break;

    case DLL_THREAD_DETACH:
        DEBUGMSG(ZONE_INFO,(TEXT("Pwm Driver: DLL_THREAD_DETACH\n")));
	break;
    case DLL_PROCESS_DETACH:
        DEBUGMSG(ZONE_INFO,(TEXT("Pwm Driver: DLL_PROCESS_DETACH\n")));
	break;
#ifdef UNDER_CE
    case DLL_PROCESS_EXITING:
        DEBUGMSG(ZONE_INFO,(TEXT("Pwm Driver: DLL_PROCESS_EXITING\n")));
	break;
    case DLL_SYSTEM_STARTED:
        DEBUGMSG(ZONE_INFO,(TEXT("Pwm Driver: DLL_SYSTEM_STARTED\n")));
	break;
#endif
    }

    return TRUE;
}


//-----------------------------------------------------------------------------
//! \fn			static BOOL ConfigurePWM(T_IOCTLPWM_CONFIG * pPwmConfig, T_PWMINIT_STRUCTURE * pDeviceContext)
//!
//! \brief		This function configure the timer-counter controler for a frequency and duty cycles given by the user
//!
//! \param		pPwmConfig		Pointer to a PWM configuration which contains the frequency and the duty cycles
//! \param		pDeviceContext	Pointer to the Device Context
//!
//! \return		\e TRUE indicates success.
//! \return		\e FALSE indicates failure.
//!
//-----------------------------------------------------------------------------
static BOOL ConfigurePWM(T_IOCTLPWM_CONFIG * pPwmConfig, T_PWMINIT_STRUCTURE * pDeviceContext)
{
	DWORD dwSrcTimerClock = AT91C_TC_CLKS;
	DWORD dwDivTimerClock = 0;
	DWORD dwRCValue = 0;
	DWORD dwMasterClock = 0;

	DEBUGMSG(ZONE_INFO, (TEXT("->ConfigurePWM\r\n")));

	if (KernelIoControl(IOCTL_HAL_MASTERCLOCK, NULL, 0, &dwMasterClock, sizeof(dwMasterClock), 0) == FALSE)
	{
		DEBUGMSG(ZONE_INFO|ZONE_ERROR, (TEXT("<-ConfigurePWM : KernelIoControl IOCTL_HAL_MASTERCLOCK FAILED\r\n")));
		return FALSE;
	}

	if ((pPwmConfig->dwFrequency >= F5_MIN) && (pPwmConfig->dwFrequency <= F5_MAX))
	{
		dwSrcTimerClock = AT91C_TC_CLKS_TIMER_DIV5_CLOCK;
	}
	else
	{
		if ((pPwmConfig->dwFrequency >= F4_MIN(dwMasterClock)) && (pPwmConfig->dwFrequency <= F4_MAX(dwMasterClock)))
		{
			dwSrcTimerClock = AT91C_TC_CLKS_TIMER_DIV4_CLOCK;
			dwDivTimerClock = TIMER_CLOCK4_DIV;
		}
		else
		{
			if ((pPwmConfig->dwFrequency >= F3_MIN(dwMasterClock)) && (pPwmConfig->dwFrequency <= F3_MAX(dwMasterClock)))
			{
				dwSrcTimerClock = AT91C_TC_CLKS_TIMER_DIV3_CLOCK;
				dwDivTimerClock = TIMER_CLOCK3_DIV;
			}
			else
			{
				if ((pPwmConfig->dwFrequency >= F2_MIN(dwMasterClock)) && (pPwmConfig->dwFrequency <= F2_MAX(dwMasterClock)))
				{
					dwSrcTimerClock = AT91C_TC_CLKS_TIMER_DIV2_CLOCK;
					dwDivTimerClock = TIMER_CLOCK2_DIV;
				}
				else
				{
					if ((pPwmConfig->dwFrequency >= F1_MIN(dwMasterClock)) && (pPwmConfig->dwFrequency <= F1_MAX(dwMasterClock)))
					{
						dwSrcTimerClock = AT91C_TC_CLKS_TIMER_DIV1_CLOCK;
						dwDivTimerClock = TIMER_CLOCK1_DIV;
					}
					else
					{
						DEBUGMSG(ZONE_INFO|ZONE_ERROR, (TEXT("<-ConfigurePWM : Frequency out of range !\r\n")));
						return FALSE;
					}
				}
			}

		}
	}

	pDeviceContext->pTC_VirtualBase->TC_CMR |= dwSrcTimerClock;

	if (dwSrcTimerClock == AT91C_TC_CLKS_TIMER_DIV5_CLOCK)
	{
		dwRCValue = (TIMER_CLOCK5 / pPwmConfig->dwFrequency);
	}
	else
	{
		dwRCValue = (dwMasterClock / (pPwmConfig->dwFrequency * dwDivTimerClock));
	}
	
	pDeviceContext->pTC_VirtualBase->TC_RC = (WORD)dwRCValue;	

	pDeviceContext->pTC_VirtualBase->TC_RA = ((pPwmConfig->dwDutyCycleA * dwRCValue) / 100);
	pDeviceContext->pTC_VirtualBase->TC_RB = ((pPwmConfig->dwDutyCycleB * dwRCValue) / 100);

	DEBUGMSG(ZONE_INFO, (TEXT("<-ConfigurePWM : OK\r\n")));
	return TRUE;
}


//-----------------------------------------------------------------------------
//! \fn			static BOOL	GetDefaultParameters(T_IOCTLPWM_CONFIG * pPwmDefaultConfig, T_PWMINIT_STRUCTURE * pDeviceContext)
//!
//! \brief		This function retrieves default parameters (frequency and duty cycles) from registry
//!
//! \param		pPwmDefaultConfig	Pointer to a PWM configuration which will contain the default frequency and duty cycles
//! \param		pDeviceContext		Pointer to the Device Context
//!
//! \return		\e TRUE indicates success.
//! \return		\e FALSE indicates failure.
//!
//-----------------------------------------------------------------------------
static BOOL	GetDefaultParameters(T_IOCTLPWM_CONFIG * pPwmDefaultConfig, T_PWMINIT_STRUCTURE * pDeviceContext)
{
	BOOL bRet = TRUE;
	DWORD dwSize = 0;

	DEBUGMSG(ZONE_INFO, (TEXT("->GetDefaultParameters\r\n")));
	
	dwSize = sizeof(DWORD);
	if (RegQueryValueEx(pDeviceContext->hKey, TEXT("DefaultFrequency"), NULL, NULL, (LPBYTE)&(pPwmDefaultConfig->dwFrequency), &dwSize) != ERROR_SUCCESS)
	{
		DEBUGMSG(ZONE_INFO|ZONE_ERROR, (TEXT("GetDefaultParameters : RegQueryValueEx DefaultFrequency failed !\r\n")));
		bRet = FALSE;
	}

	dwSize = sizeof(DWORD);
	if (RegQueryValueEx(pDeviceContext->hKey, TEXT("DefaultDutyCycleA"), NULL, NULL, (LPBYTE)&(pPwmDefaultConfig->dwDutyCycleA), &dwSize) != ERROR_SUCCESS)
	{
		DEBUGMSG(ZONE_INFO|ZONE_ERROR, (TEXT("GetDefaultParameters : RegQueryValueEx DefaultDutyCycleA failed !\r\n")));
		bRet = FALSE;
	}

	dwSize = sizeof(DWORD);
	if (RegQueryValueEx(pDeviceContext->hKey, TEXT("DefaultDutyCycleB"), NULL, NULL, (LPBYTE)&(pPwmDefaultConfig->dwDutyCycleB), &dwSize) != ERROR_SUCCESS)
	{
		DEBUGMSG(ZONE_INFO|ZONE_ERROR, (TEXT("GetDefaultParameters : RegQueryValueEx DefaultDutyCycleB failed !\r\n")));
		bRet = FALSE;
	}

	DEBUGMSG(ZONE_INFO, (TEXT("<-GetDefaultParameters\r\n")));
	return bRet;
}

//-----------------------------------------------------------------------------
//! \fn			DWORD PWM_Init(LPCTSTR pContext, LPCVOID lpvBusContext)
//!
//! \brief		This function initializes the device.
//!
//! Device Manager calls this function as a result of a call to the ActivateDeviceEx 
//! function. When the user starts using a device, such as inserting a PC Card, 
//! Device Manager calls this function to initialize the device. Applications do not call this function. 
//!
//! \param		pContext		Pointer to a string containing the registry path to the active key for the stream interface driver.
//! \param		lpvBusContext	Potentially process-mapped pointer passed as the 
//!								fourth parameter to ActivateDeviceEx. If this driver 
//!								was loaded through legacy mechanisms, then lpvBusContext 
//!								is zero. This pointer, if used, has only been mapped 
//!								again as it passes through the protected server library (PSL).
//!								The <b>PWM_Init</b> function is responsible for performing all protection 
//!								checking. In addition, any pointers referenced through lpvBusContext 
//!								must be remapped with the <b>MapCallerPtr</b> function before they 
//!								can be dereferenced.
//!
//! \return		Returns a handle to the device context created if successful. 
//!	\return		\e zero if not successful.
//-----------------------------------------------------------------------------
DWORD PWM_Init(LPCTSTR pContext, LPCVOID lpvBusContext)
{
    PHYSICAL_ADDRESS    PMC_PhysicalBase;
    PHYSICAL_ADDRESS    PIOC_PhysicalBase;
	PHYSICAL_ADDRESS    TC_PhysicalBase;
	T_PWMINIT_STRUCTURE * pDeviceContext;
	DWORD				dwSize;
	
	DEBUGMSG(ZONE_INIT, (TEXT("->PWM_Init\r\n")));

	PMC_PhysicalBase.QuadPart = (LONGLONG)AT91C_BASE_PMC;
	PIOC_PhysicalBase.QuadPart = (LONGLONG)AT91C_BASE_PIOC;

	pDeviceContext = (T_PWMINIT_STRUCTURE *)LocalAlloc(LMEM_ZEROINIT|LMEM_FIXED, sizeof(T_PWMINIT_STRUCTURE));

	if (pDeviceContext == 0)
	{
		DEBUGMSG(ZONE_INIT|ZONE_ERROR, (TEXT("<-PWM_Init KO : pDeviceContext NULL pointer !\r\n")));
		goto InitFailed;
	}

	pDeviceContext->pPMC_VirtualBase = (AT91PS_PMC)MmMapIoSpace(PMC_PhysicalBase, sizeof(AT91S_PMC), FALSE);
	pDeviceContext->pPIOC_VirtualBase = (AT91PS_PIO)MmMapIoSpace(PIOC_PhysicalBase, sizeof(AT91S_PIO), FALSE);

	if ((pDeviceContext->pPMC_VirtualBase == NULL) || (pDeviceContext->pPIOC_VirtualBase == NULL))
	{
		DEBUGMSG(ZONE_INIT|ZONE_ERROR, (TEXT("<-PWM_Init KO : MmMapIoSpace failed !\r\n")));
		goto InitFailed;
	}

	pDeviceContext->hKey = OpenDeviceKey(pContext);

	dwSize = sizeof(DWORD);
	// Retrieve the index of the device from registry
	if (RegQueryValueEx(pDeviceContext->hKey, TEXT("Index"), NULL, NULL, (LPBYTE)&(pDeviceContext->dwIndex), &dwSize) != ERROR_SUCCESS)
	{
		DEBUGMSG(ZONE_INIT|ZONE_ERROR, (TEXT("<-PWM_Init KO : RegQueryValueEx Index failed !\r\n")));
		goto InitFailed;
	}

	switch (pDeviceContext->dwIndex)
	{
		case 1:
			TC_PhysicalBase.QuadPart = (LONGLONG)AT91C_BASE_TC0;
		break;

		case 2:
			TC_PhysicalBase.QuadPart = (LONGLONG)AT91C_BASE_TC1;
		break;

		case 3:
			TC_PhysicalBase.QuadPart = (LONGLONG)AT91C_BASE_TC2;
		break;

		default:
			DEBUGMSG(ZONE_INIT|ZONE_ERROR, (TEXT("PWM_Init : Driver Index Not supported (index = %d)\r\n"), pDeviceContext->dwIndex));
			goto InitFailed;
	}

	pDeviceContext->pTC_VirtualBase = (AT91PS_TC)MmMapIoSpace(TC_PhysicalBase, sizeof(AT91S_TC), FALSE);
	
	// Configure in Waveform mode 
	if (pDeviceContext->pTC_VirtualBase != NULL)
	{
		pDeviceContext->pTC_VirtualBase->TC_CMR = 
													AT91C_TC_WAVE |
													AT91C_TC_ACPA_CLEAR | 
													AT91C_TC_ACPC_SET | 
													AT91C_TC_BCPB_CLEAR | 
													AT91C_TC_BCPC_SET;

		DEBUGMSG(ZONE_INIT, (TEXT("<-PWM_Init OK !\r\n")));
		return (DWORD)pDeviceContext;
	}

InitFailed:
	
	DEBUGMSG(ZONE_INIT|ZONE_ERROR, (TEXT("PWM_Init : InitFailed\r\n")));

	if (pDeviceContext->pPMC_VirtualBase != NULL)
	{
		MmUnmapIoSpace(pDeviceContext->pPMC_VirtualBase, sizeof(AT91S_PMC));
	}

	if (pDeviceContext->pPIOC_VirtualBase != NULL)
	{
		MmUnmapIoSpace(pDeviceContext->pPIOC_VirtualBase, sizeof(AT91S_PIO));
	}

	if (pDeviceContext != 0)
	{
		LocalFree(pDeviceContext);
	}
	
	return 0;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL PWM_Deinit(T_PWMINIT_STRUCTURE *pDeviceContext)
//!
//! \brief		This function uninitializes the device.
//!
//! \param		pDeviceContext	Pointer to the the device init context. The PWM_Init (Device Manager)
//!								function creates and returns this pointer.
//!
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//!
//! When the user stops using a device, such as when a PC Card is removed from its socket, 
//! Device Manager calls this function. Applications do not call this function. Device Manager 
//! calls the PWM_Deinit driver function as a result of a call to the DeactivateDevice function. 
//! Your stream interface driver should free any resources it has allocated, and then terminate.
//-----------------------------------------------------------------------------
BOOL PWM_Deinit(T_PWMINIT_STRUCTURE * pDeviceContext)
{
	BOOL bRet = TRUE;

	DEBUGMSG(ZONE_DEINIT, (TEXT("->PWM_Deinit\r\n")));

	if (pDeviceContext != NULL)
	{
		if (pDeviceContext->pPMC_VirtualBase != NULL)
		{
			MmUnmapIoSpace(pDeviceContext->pPMC_VirtualBase, sizeof(AT91S_PMC));
		}

		if (pDeviceContext->pPIOC_VirtualBase != NULL)
		{
			MmUnmapIoSpace(pDeviceContext->pPIOC_VirtualBase, sizeof(AT91S_PIO));
		}

		if (pDeviceContext->pTC_VirtualBase != NULL)
		{
			MmUnmapIoSpace(pDeviceContext->pTC_VirtualBase, sizeof(AT91S_TC));
		}

		if (LocalFree(pDeviceContext) != NULL)
		{
			DEBUGMSG(ZONE_DEINIT|ZONE_ERROR, (TEXT("PWM_Deinit : LocalFree FAILED\r\n")));			
			bRet = FALSE;
		}

		RegCloseKey(pDeviceContext->hKey);
	}
	else
	{
		DEBUGMSG(ZONE_DEINIT|ZONE_ERROR, (TEXT("PWM_Deinit : pDeviceContext = NULL pointer\r\n")));
		bRet = FALSE;
	}

	DEBUGMSG(ZONE_DEINIT, (TEXT("<-PWM_Deinit\r\n")));
	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn			DWORD PWM_Open(T_PWMINIT_STRUCTURE *pDeviceContext, DWORD AccessCode, DWORD ShareMode)
//!
//! \brief		This function opens a device for reading, writing, or both.
//!
//! \param		pDeviceContext	Pointer to the the device open context. The <b>PWM_Init</b> (Device Manager)
//!								function creates and returns this identifier.
//! \param		AccessCode		Access code for the device. The access is a combination
//!								of read and write access from <b>CreateFile</b>. 
//! \param		ShareMode		File share mode of the device. The share mode is a combination 
//!								of read and write access sharing from <b>CreateFile</b>. 
//!
//! \return		This function returns a handle that identifies the open context of the device 
//!				to the calling application. If your device can be opened multiple times, use 
//!				this handle to identify each open context.
//!
//! When this function executes, your device should allocate the resources that it needs for 
//! each open context and prepare for operation. This might involve preparing the device for 
//! reading or writing and initializing data structures it uses for operation.
//-----------------------------------------------------------------------------
DWORD PWM_Open(T_PWMINIT_STRUCTURE *pDeviceContext , DWORD AccessCode, DWORD ShareMode)
{
	T_PWMOPEN_STRUCTURE * pOpenContext;

	DEBUGMSG(ZONE_OPEN, (TEXT("->PWM_Open\r\n")));
	pOpenContext = (T_PWMOPEN_STRUCTURE*)LocalAlloc(LMEM_ZEROINIT|LMEM_FIXED, sizeof(T_PWMOPEN_STRUCTURE));
	if (pOpenContext == 0)
	{
		DEBUGMSG(ZONE_OPEN|ZONE_ERROR, (TEXT("PWM_Open : pOpenContext NULL pointer\r\n")));
		goto OpenFailed;
	}
	
	// Store device settings for future use
	pOpenContext->pDeviceContext = pDeviceContext;

	// Configuration of PIO is specific to the board
	if (ConfigurePioForPWM(pDeviceContext->dwIndex, pDeviceContext->pPMC_VirtualBase, pDeviceContext->pPIOC_VirtualBase) == FALSE)
	{
		DEBUGMSG(ZONE_OPEN|ZONE_ERROR, (TEXT("PWM_Open : ConfigurePioForPWM failed\r\n")));
		goto OpenFailed;
	}
	
	pOpenContext->dwConfiguredAtLeastOneTime = 0;

	DEBUGMSG(ZONE_OPEN, (TEXT("<-PWM_Open OK\r\n")));
	return (DWORD)pOpenContext;

OpenFailed:

	DEBUGMSG(ZONE_OPEN|ZONE_ERROR, (TEXT("PWM_Open : OpenFailedr\r\n")));
	if (pOpenContext != 0)
	{
		LocalFree(pOpenContext);
	}
	
	DEBUGMSG(ZONE_OPEN|ZONE_ERROR, (TEXT("<-PWM_Open KO\r\n")));
	return 0;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL PWM_Close(T_PWMOPEN_STRUCTURE *pOpenContext)
//!
//! \brief		This function closes a device context created by the pOpenContext parameter.
//!
//! \param		pOpenContext	Pointer returned by the <b>PWM_Open</b> (Device Manager) function, 
//!								which is used to identify the open context of the device. 
//!
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//!
//! An application calls the CloseHandle function to stop using a stream interface driver. 
//! The hFile parameter specifies the handle associated with the device context. In response
//! to <b>CloseHandle</b>, the operating system invokes <b>PWM_Close</b>.
//-----------------------------------------------------------------------------
BOOL PWM_Close(T_PWMOPEN_STRUCTURE *pOpenContext)
{
	BOOL bRet = TRUE;
	DEBUGMSG(ZONE_CLOSE, (TEXT("->PWM_Close\r\n")));
	
	if (pOpenContext != NULL)
	{
		// Free memory
		if (LocalFree(pOpenContext) != NULL)
		{
			DEBUGMSG(ZONE_CLOSE|ZONE_ERROR, (TEXT("PWM_Close : LocalFree FAILED\r\n")));
			bRet = FALSE;
		}
	}

	DEBUGMSG(ZONE_CLOSE, (TEXT("<-PWM_Close\r\n")));
	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn			DWORD PWM_Read(T_PWMOPEN_STRUCTURE *pOpenContext, LPVOID pBuffer, DWORD dwCount)
//!
//! \brief		This function reads data from the device identified by the open context.
//!
//! \param		pOpenContext	Handle to the open context of the device. The <b>PWM_Open</b> 
//!								(Device Manager) function creates and returns this identifier.  
//! \param		pBuffer			Pointer to the buffer that stores the data read from 
//!								the device. This buffer should be at least <i>Count</i> bytes long. 
//! \param		dwCount			Number of bytes to read from the device into <i>pBuffer</i>.
//!
//! \return		\e zero to indicate <i>end-of-file</i>. 
//! \return		\e -1 to indicate an error. 
//! \return		The number of bytes read to indicate success.
//!
//! After an application calls the ReadFile function to read from the device, the operating system
//! invokes this function. The <i>hFile</i> parameter is a handle to the device. The <i>pBuffer</i> parameter 
//! points to the buffer that contains the data read from the device. The <i>dwCount</i> parameter indicates 
//! the number of bytes that the application requests to read from the device.
//-----------------------------------------------------------------------------
DWORD PWM_Read(T_PWMOPEN_STRUCTURE *pOpenContext, LPVOID pBuffer, DWORD dwCount)
{
	DEBUGMSG(ZONE_READ, (TEXT("->PWM_Read\r\n")));
	DEBUGMSG(ZONE_READ, (TEXT("<-PWM_Read\r\n")));
	return -1;
}


//-----------------------------------------------------------------------------
//! \fn			DWORD PWM_Write(T_PWMOPEN_STRUCTURE *pOpenContext, LPCVOID pBuffer, DWORD dwCount)
//!
//! \brief		This function writes data to the device.
//!
//! \param		pOpenContext	Handle to the open context of the device. The <b>PWM_Open</b> 
//!								(Device Manager) function creates and returns this identifier.  
//! \param		pBuffer			Pointer to the buffer that contains the data to write. 
//!								This buffer should be at least <i>Count</i> bytes long. 
//! \param		dwCount			Number of bytes to write from the <i>pBuffer</i> buffer into the device.
//!
//! \return		The number of bytes  written indicates success
//! \return		\e -1 to indicate an error. 
//!
//! After an application uses the WriteFile function to write to the device, the operating system, 
//! invokes this function. The <i>hFile</i> parameter is a handle to the device. The <i>pBuffer</i> parameter 
//! points to the buffer that contains the data read from the device. The <i>dwCount</i> parameter indicates 
//! the number of bytes that the application requests to write to the device.
//-----------------------------------------------------------------------------
DWORD PWM_Write(T_PWMOPEN_STRUCTURE *pOpenContext, LPCVOID pBuffer, DWORD dwCount)
{
	DEBUGMSG(ZONE_WRITE, (TEXT("->PWM_Write\r\n")));
	DEBUGMSG(ZONE_WRITE, (TEXT("<-PWM_Write\r\n")));
	return -1;
}


//-----------------------------------------------------------------------------
//! \fn			DWORD PWM_Seek(T_PWMOPEN_STRUCTURE *pOpenContext, long Amount, WORD wType)
//!
//! \brief		This function moves the data pointer in the device.
//!
//! \param		pOpenContext	Handle to the open context of the device. The <b>PWM_Open</b> 
//!								(Device Manager) function creates and returns this identifier.  
//! \param		Amount			Number of bytes to move the data pointer in the device. A positive value 
//!								moves the data pointer toward the end of the file and a negative value 
//!								moves it toward the beginning.
//! \param		wType			Starting point for the data pointer. The following table shows the available values for this parameter.
//!
//! \return		The new data pointer for the device indicates success.
//! \return		\e -1 to indicate an error. 
//!
//! After an application calls the SetFilePointer function to move the data pointer in the device, 
//! the operating system invokes this function. If your device is capable of opening more than once, 
//! this function modifies only the data pointer for the instance specified by <i>pOpenContext</i>.
//-----------------------------------------------------------------------------
DWORD PWM_Seek(T_PWMOPEN_STRUCTURE *pOpenContext, long Amount, WORD wType)
{
	DEBUGMSG(ZONE_SEEK, (TEXT("->PWM_Seek\r\n")));
	DEBUGMSG(ZONE_SEEK, (TEXT("<-PWM_Seek\r\n")));
	return -1;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL PWM_IOControl(T_PWMOPEN_STRUCTURE *pOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut)
//!
//! \brief		This function sends a command to a device.
//!
//! \param		pOpenContext	Handle to the open context of the device. The <b>PWM_Open</b> 
//!								(Device Manager) function creates and returns this identifier.  
//! \param		dwCode			I/O control operation to perform. These codes are device-specific and 
//!								are usually exposed to developers through a header file. 
//!								Use <b>CTL_CODE</b> macro to generate a driver unique identifier for your iocontrol.
//! \param		pBufIn			Pointer to the buffer containing data to transfer to the device. 
//! \param		dwLenIn			Number of bytes of data in the buffer specified for <i>pBufIn</i>.
//! \param		pBufOut			Pointer to the buffer used to transfer the output data from the device.
//! \param		dwLenOut		Maximum number of bytes in the buffer specified by <i>pBufOut</i>.
//! \param		pdwActualOut	Pointer to the <b>DWORD</b> buffer that this function uses to 
//!								return the actual number of bytes received from the device. 
//!
//! \return		\e TRUE indicates success.
//! \return		\e FALSE indicates failure.
//!
//! An application uses the DeviceIoControl function to specify an operation to perform. The operating system,
//! in turn, invokes the <b>PWM_IOControl</b> function. The <i>dwCode</i> parameter contains the input or output 
//! operation to perform; these codes are usually specific to each device driver and are exposed to application 
//! programmers through a header file that the device driver developer makes available.
//!
//! Available IOControls are :
//!
//!		- IOCTL_PWM_CONFIG	: Configure the Frequency, the Duty Cycle A & B of the PWM signal
//!			- \e pBufIn		: (T_IOCTLPWM_CONFIG *)
//!			- \e pBufOut	: NULL
//!
//!		- IOCTL_PWM_START	: Start the PWM
//!			- \e pBufIn		: NULL
//!			- \e pBufOut	: NULL
//!
//!		- IOCTL_PWM_STOP	: Stop the PWM
//!			- \e pBufIn		: NULL
//!			- \e pBufOut	: NULL
//!
//-----------------------------------------------------------------------------
BOOL PWM_IOControl(T_PWMOPEN_STRUCTURE * pOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut)
{
	BOOL bRet = TRUE;
	DWORD dwRCValue = 0;

	DEBUGMSG(ZONE_IOCTL, (TEXT("->PWM_IOControl\r\n")));

	if (pdwActualOut != NULL)
	{
		*pdwActualOut = 0;
	}

	if (pOpenContext == NULL)
	{
		DEBUGMSG(ZONE_IOCTL|ZONE_ERROR, (TEXT("PWM_IOControl : pOpenContext NULL pointer\r\n")));
		DEBUGMSG(ZONE_IOCTL, (TEXT("<-PWM_IOControl KO\r\n")));
		return FALSE;
	}

	switch (dwCode)
	{
		case IOCTL_PWM_CONFIG:
		{		
			T_IOCTLPWM_CONFIG * pPwmConfig;

			if ((pBufIn == NULL) || (dwLenIn != sizeof(T_IOCTLPWM_CONFIG)) || (pBufOut != NULL) || (dwLenOut != 0))
			{
				DEBUGMSG(ZONE_IOCTL|ZONE_ERROR, (TEXT("<-PWM_IOControl : Invalid parameters\r\n")));
				SetLastError(ERROR_INVALID_PARAMETER);
				return FALSE;
			}
			else
			{
				pPwmConfig = (T_IOCTLPWM_CONFIG *) pBufIn;
				if (pPwmConfig->dwFrequency == 0)
				{
					DEBUGMSG(ZONE_IOCTL|ZONE_ERROR, (TEXT("<-PWM_IOControl : Frequency = 0 Hz !!\r\n")));
					SetLastError(ERROR_INVALID_PARAMETER);
					return FALSE;
				}
			}
	
			if (ConfigurePWM(pPwmConfig, pOpenContext->pDeviceContext))
			{
				if (pdwActualOut != NULL)
				{
					*pdwActualOut = sizeof(T_IOCTLPWM_CONFIG);
				}
				// Now the PWM is configured with user parameters
				pOpenContext->dwConfiguredAtLeastOneTime = 1;
			}
		}
		break;

		case IOCTL_PWM_START:
		{
			if ((pBufIn != NULL) || (dwLenIn != 0) || (pBufOut != NULL) || (dwLenOut != 0))
			{
				DEBUGMSG(ZONE_IOCTL|ZONE_ERROR, (TEXT("<-PWM_IOControl : Invalid parameters\r\n")));
				SetLastError(ERROR_INVALID_PARAMETER);
				return FALSE;
			}

			// We can start PWM with default parameters from registry
			if (pOpenContext->dwConfiguredAtLeastOneTime == 0)
			{
				T_IOCTLPWM_CONFIG pwmDefaultConfig;
				if (GetDefaultParameters(&pwmDefaultConfig, pOpenContext->pDeviceContext))
				{
					if (ConfigurePWM(&pwmDefaultConfig, pOpenContext->pDeviceContext))
					{
						// Now the PWM is configured with default parameters
						pOpenContext->dwConfiguredAtLeastOneTime = 1;
					}
				}
			}
			// Enable the clock
			pOpenContext->pDeviceContext->pTC_VirtualBase->TC_CCR = AT91C_TC_CLKEN;
		}
		break;
		
		case IOCTL_PWM_STOP:
			{
				if ((pBufIn != NULL) || (dwLenIn != 0) || (pBufOut != NULL) || (dwLenOut != 0))
				{
					DEBUGMSG(ZONE_IOCTL|ZONE_ERROR, (TEXT("<-PWM_IOControl : Invalid parameters\r\n")));
					SetLastError(ERROR_INVALID_PARAMETER);
					return FALSE;
				}
				// Disable the clock
				pOpenContext->pDeviceContext->pTC_VirtualBase->TC_CCR = AT91C_TC_CLKDIS;
			}
			break;


			//---------------------------//
			//     Power management      //
			//							 //
			// States :					 //
			//   - D0 : On				 //
			//	 - D1 : UserIdle		 //
			//   - D2 : SystemIdle		 //
			//	 - D3 : Suspend			 //
			//   - D4 : Off				 //
			//							 //
			//---------------------------//


		case IOCTL_POWER_CAPABILITIES:
			if (pBufOut != NULL && dwLenOut == sizeof(POWER_CAPABILITIES))
			{
				PPOWER_CAPABILITIES ppc = (PPOWER_CAPABILITIES) pBufOut;
				memset(ppc, 0, sizeof(*ppc));
				ppc->DeviceDx = (1<<D0) | (1<<D1) | (1<<D2) | (1<<D3) | (1<<D4);	// support D0,D1,D2,D3 and D4
				*pdwActualOut = sizeof(POWER_CAPABILITIES);
				DEBUGMSG(ZONE_IOCTL, (TEXT("I2C Driver: IOCTL_POWER_CAPABILITIES\r\n")));
			}
			break;
			
		case IOCTL_POWER_QUERY:
			if(pBufOut != NULL && dwLenOut == sizeof(CEDEVICE_POWER_STATE))
			{
				// return a good status on any valid query, since we are always ready to
				// change power states.
				CEDEVICE_POWER_STATE NewDx = *(PCEDEVICE_POWER_STATE) pBufOut;
				if(!VALID_DX(NewDx))
				{
					// this is a valid Dx state so return a good status
					bRet = FALSE;
				}
				DEBUGMSG(ZONE_IOCTL, (TEXT("I2C Driver: IOCTL_POWER_QUERY\r\n")));
			}
			break;
			
		case IOCTL_POWER_SET:
			if(pBufOut != NULL && dwLenOut == sizeof(CEDEVICE_POWER_STATE))
			{
				
				CEDEVICE_POWER_STATE NewDx = *(PCEDEVICE_POWER_STATE) pBufOut;
				DEBUGMSG(ZONE_IOCTL, (TEXT("I2C Driver: IOCTL_POWER_SET to %x\r\n"),NewDx));
				if(VALID_DX(NewDx))
				{
					if (NewDx == D0) // D0
					{
						//when using PWM and 32data bus, there is a pin conflict
				//	AT91F_PMC_EnablePeriphClock(pOpenContext->pDeviceContext->pPMC_VirtualBase,	((unsigned int) 1 << pOpenContext->pDeviceContext->dwIndex));
					}
					if (NewDx == D3 || NewDx == D4)
					{
				//	AT91F_PMC_DisablePeriphClock(pOpenContext->pDeviceContext->pPMC_VirtualBase,	((unsigned int) 1 << pOpenContext->pDeviceContext->dwIndex));
					}
					else // D1, D2
					{
						// Nothing more when entering in this power state
					}
					
				pOpenContext->pDeviceContext->CurrentDx = NewDx;
				}			
			}
			break;
			
		case IOCTL_POWER_GET:
			if(pBufOut != NULL && dwLenOut == sizeof(CEDEVICE_POWER_STATE))
			{
				
				*(PCEDEVICE_POWER_STATE) pBufOut = 	pOpenContext->pDeviceContext->CurrentDx;			
				*pdwActualOut = sizeof(CEDEVICE_POWER_STATE);
				DEBUGMSG(ZONE_IOCTL, (TEXT("I2C Driver: IOCTL_POWER_GET to %x\r\n"),pOpenContext->pDeviceContext->CurrentDx));
			}
			break;
			
			
		default:
			bRet = FALSE;
			DEBUGMSG(ZONE_IOCTL|ZONE_ERROR, (TEXT("PWM_IOControl : IOCTL Unknown !\r\n")));
	}

	DEBUGMSG(ZONE_IOCTL, (TEXT("<-PWM_IOControl\r\n")));
	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn			void PWM_PowerDown(T_PWMINIT_STRUCTURE *pDeviceContext)
//!
//! \brief		This function suspends power to the device. It is useful only with devices that can 
//!				power down under software control. Such devices are typically, but not exclusively, PC Cards.
//!
//! \param		pDeviceContext	Pointer to the device context. The call to the <b>PWM_Init</b> 
//!								(Device Manager) function returns this identifier.  
//!
//!
//!
//! The OS invokes this function to suspend power to a device.
//-----------------------------------------------------------------------------
void PWM_PowerDown(T_PWMINIT_STRUCTURE *pDeviceContext)
{

}


//-----------------------------------------------------------------------------
//! \fn			void PWM_PowerUp(T_PWMINIT_STRUCTURE *pDeviceContext)
//!
//! \brief		This function restores power to a device.
//!
//! \param		pDeviceContext	Pointer to the device context. The call to the <b>PWM_Init</b> 
//!								(Device Manager) function returns this identifier.  
//!
//!
//!
//! The OS invokes this function to restore power to a device.
//-----------------------------------------------------------------------------
void PWM_PowerUp(T_PWMINIT_STRUCTURE *pDeviceContext)
{

}



//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/Pwm/Pwm.c $
//-----------------------------------------------------------------------------
//
//! @}
