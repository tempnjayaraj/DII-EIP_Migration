//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x\KERNEL\DEBUGSERIAL\debugSerial.c
//!
//! \brief		AT91SAM926x's debug serial feature
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/DEBUGSERIAL/debugSerial.c $
//!   $Author: pblanchard $
//!   $Revision: 1058 $
//!   $Date: 2007-07-05 01:34:39 -0700 (Thu, 05 Jul 2007) $
//! \endif
//-----------------------------------------------------------------------------

//! \addtogroup	DEBUGSERIAL
//! @{

#include <windows.h>
#include <oal.h>
#include <nkintr.h>

#include "at91SAM926x.h"
#include "AT91SAM926x_interface.h"

/// pointer to the Debug Serial controller
AT91PS_DBGU g_pDBGU = NULL;

//-----------------------------------------------------------------------------
//! \fn       void AT91SAM926x_SetDebugSerialInterface(AT91PS_DBGU pDBGU)
//!
//! \brief		This function sets the pointer to the Debug Serial controller.
//!
//! \param		pDBGU pointer to a DBGU structure
//!
//!
//-----------------------------------------------------------------------------
void AT91SAM926x_SetDebugSerialInterface(AT91PS_DBGU pDBGU)
{
	g_pDBGU = pDBGU;
}

//-----------------------------------------------------------------------------
//! \fn		     int OEMReadDebugByte(void)
//!
//! \brief		  This function retrieves a byte from the debug serial port
//!
//!
//!
//! \return		 OEM_DEBUG_COM_ERROR indicates failure
//!	\return		 OEM_DEBUG_READ_NODATA indicates no data has been received
//! \return		 Other value is byte received
//-----------------------------------------------------------------------------
int OEMReadDebugByte(void)
{
	if (g_pDBGU == NULL)
	{
		return OEM_DEBUG_COM_ERROR;
	}

	if (g_pDBGU->DBGU_CSR & AT91C_US_RXRDY) //Did we receive at least one byte ?
	{
		return 	g_pDBGU->DBGU_RHR; //If so return its value
	}
	return OEM_DEBUG_READ_NODATA; //If not so, return the no data flag
	
}


//-----------------------------------------------------------------------------
//! \fn        void OEMWriteDebugByte(BYTE ch)
//!
//! \brief    This function outputs a byte to the debug serial port.
//!
//! \param    ch	byte to send
//!
//!
//-----------------------------------------------------------------------------
void OEMWriteDebugByte(BYTE ch)
{
	if (g_pDBGU == NULL)
		return;

	while (!(g_pDBGU->DBGU_CSR & AT91C_US_TXRDY))
	{
		//do nothing. wait for the controller to be ready
	}
	g_pDBGU->DBGU_THR=ch;
	while (!(g_pDBGU->DBGU_CSR & AT91C_US_TXRDY))
	{
		//do nothing. wait for the controller to be ready
	}
}

//-----------------------------------------------------------------------------
//! \fn       void DisableDBGU()
//!
//! \brief		This function disables the transmision and reception.
//!
//!
//!
//!
//-----------------------------------------------------------------------------
void DisableDBGU()
{
	while (!(g_pDBGU->DBGU_CSR & AT91C_US_TXRDY))
	{
		//do nothing. wait for the controller to be ready
	}
	g_pDBGU->DBGU_CR = AT91C_US_RSTRX | AT91C_US_RSTTX;	
}

//-----------------------------------------------------------------------------
//! \fn       void EnableDBGU()
//!
//! \brief		This function enables the emission and reception.
//!
//!
//!
//!
//-----------------------------------------------------------------------------
void EnableDBGU()
{	
	// Enable Transmitter
    g_pDBGU->DBGU_CR = AT91C_US_TXEN; 
	// Enable Receiver
	g_pDBGU->DBGU_CR = AT91C_US_RXEN;	
}

//-----------------------------------------------------------------------------
//! \fn		unsigned int ConfigureBaudrate(const unsigned int main_clock, const unsigned int baud_rate)
//!
//! \brief		This function configures the dbgu Baudrate
//!
//! \param		main_clock main clock of the processor
//! \param		baud_rate baudrate wanted
//!
//! \return   baudrate value that must be stored in the DBGU controller 
//-----------------------------------------------------------------------------
unsigned int ConfigureBaudrate (
	const unsigned int main_clock, // \arg peripheral clock
	const unsigned int baud_rate)  // \arg UART baudrate
{
	unsigned int baud_value = ((main_clock*10)/(baud_rate * 16));
	if ((baud_value % 10) >= 5)
		baud_value = (baud_value / 10) + 1;
	else
		baud_value /= 10;
	return baud_value;
}

//-----------------------------------------------------------------------------
//! \fn		   void ConfigureDBGU(unsigned int mainClock, unsigned int mode, unsigned int baudRate, unsigned int timeguard)
//!
//! \brief		This function initializes the DBGU controller and enables emission and reception.
//!
//-----------------------------------------------------------------------------
void ConfigureDBGU (
	unsigned int mainClock,  // \arg peripheral clock
	unsigned int mode ,      // \arg mode Register to be programmed
	unsigned int baudRate ,  // \arg baudrate to be programmed
	unsigned int timeguard ) // \arg timeguard to be programmed
{
    AT91PS_PDC pPDC;

	//* Disable interrupts
    g_pDBGU->DBGU_IDR = (unsigned int) -1;

    //* Reset receiver and transmitter
    g_pDBGU->DBGU_CR = AT91C_US_RSTRX | AT91C_US_RSTTX | AT91C_US_RXDIS | AT91C_US_TXDIS ;

	//* Define the baud rate divisor register
	g_pDBGU->DBGU_BRGR = ConfigureBaudrate(mainClock, baudRate);

	//* Write the Timeguard Register
	((AT91PS_USART)g_pDBGU)->US_TTGR = timeguard ;
	

    //* Clear Transmit and Receive Counters
  //  AT91F_PDC_Open((AT91PS_PDC) &(g_pDBGU->DBGU_RPR));
	pPDC = (AT91PS_PDC) &(g_pDBGU->DBGU_RPR);
	
	// stop PDC
	pPDC->PDC_PTCR = AT91C_PDC_RXTDIS;
	pPDC->PDC_PTCR = AT91C_PDC_TXTDIS;

	// reset all pointer
	pPDC->PDC_RNPR = 0;
	pPDC->PDC_RNCR = 0;
	pPDC->PDC_TNPR = 0;
	pPDC->PDC_TNCR = 0;
	pPDC->PDC_RPR = 0;
	pPDC->PDC_RCR = 0;
	pPDC->PDC_TPR = 0;
	pPDC->PDC_TCR = 0;

	//restart PDC
	pPDC->PDC_PTCR = AT91C_PDC_TXTEN;
	pPDC->PDC_PTCR = AT91C_PDC_RXTEN;


    //* Define the USART mode
    g_pDBGU->DBGU_MR = mode  ;

}

//! @} end of subgroup DEBUGSERIAL

//! @} end of group OAL

////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/DEBUGSERIAL/debugSerial.c $
////////////////////////////////////////////////////////////////////////////////
//



