//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x/INC/LCDC/precomp.h
//!
//! \brief		precompiled Header for  LCDC
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/LCDC/precomp.h $
//!   $Author: pblanchard $
//!   $Revision: 993 $
//!   $Date: 2007-06-12 08:36:50 -0700 (Tue, 12 Jun 2007) $
//! \endif
//!
//-----------------------------------------------------------------------------
//! \addtogroup	LCDC
//! @{
//!

#define DDRAW_ENABLE


// System include
#include <windows.h>
#include <Winddi.h>
#include <ddgpe.h>
#include <CEDDK.h>
#include <ddrawi.h>
#include <ddpguids.h>
#include <ddhfuncs.h>



// Local include                                                                       
#include "AT91SAM926x.h"
#include "lib_AT91SAM926x.h"
#include "hwSurf.h"
#include "lcd_lut.h"                                                                    
#include "Core.h"
#include "ddgpeusr.h"
#include "lcd_def.h"

//! @}


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/LCDC/precomp.h $
////////////////////////////////////////////////////////////////////////////////
//
//! @}
