//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		Serial_SAM926X_HW.cpp
//!
//! \brief		Serial driver Hardware functions for AT91SAM926x chipset
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/Serial/Serial_SAM926X_HW.cpp $
//!   $Author: pblanchard $
//!   $Revision: 1097 $
//!   $Date: 2007-07-16 04:59:19 -0700 (Mon, 16 Jul 2007) $
//! \endif
//!
//! 
//-----------------------------------------------------------------------------
//! \addtogroup	Serial
//! @{
//!

//------------------------------------------------------------------------------
//                                                                      Includes
//------------------------------------------------------------------------------
// Standard includes
#include <windows.h>
#include <memory.h>
#include <nkintr.h>
#include <CEDDK.h>
#include <devload.h>

// Controller includes
#include "AT91SAM926x.h"
#include "lib_AT91SAM926x.h"

// Project include
#include "Serial_SAM926X_HW.h"
#include "Serial_SAM926X.h"
#include "Serial_SAM926X_DbgZones.h"

//------------------------------------------------------------------------------
//                                                               Defines & Types
//------------------------------------------------------------------------------

#define CSRINTS	0xFFFFF

//------------------------------------------------------------------------------
//                                                            Imported functions
//------------------------------------------------------------------------------

extern BOOL BSPSerialInit		(T_SERIAL_INIT_STRUCTURE * pInitContext);
extern BOOL BSPSerialDeinitPIO	(T_SERIAL_INIT_STRUCTURE * pContext);
extern BOOL BSPSerialSetRTS (T_SERIAL_INIT_STRUCTURE *pInitContext);
extern BOOL BSPSerialClearRTS (T_SERIAL_INIT_STRUCTURE *pInitContext);
extern BOOL	BSPGetSerialID (T_SERIAL_INIT_STRUCTURE *pInitContext);
extern BOOL	BSPGetSerialBaseAddress (T_SERIAL_INIT_STRUCTURE *pInitContext);
extern BOOL	BSPGetSerialPdcBaseAddress (T_SERIAL_INIT_STRUCTURE *pInitContext);
extern BOOL BSPGetSerialPmcBaseAddress (T_SERIAL_INIT_STRUCTURE *pInitContext);
extern "C" void DisableInt(void);
extern "C" void EnableInt(void);

//------------------------------------------------------------------------------
//                                                                     Variables
//------------------------------------------------------------------------------

DWORD g_dwMasterClock;

//------------------------------------------------------------------------------
//                                                            Exported functions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//!	\fn				BOOL HWInit(T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Hardware initialization of the device
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//!
//! \return			True if success;
//! \return	\e		False if error
//------------------------------------------------------------------------------
BOOL HWInit(T_SERIAL_INIT_STRUCTURE *pInitContext)
{
	PHYSICAL_ADDRESS PA_PMCReg, PA_USARTReg, PA_PDCReg;
		
	// Get the DeviceID of the USART
	if (!(BSPGetSerialID(pInitContext)))
	{
		goto error;
	}

	// Get the base address of the USART
	if(!(BSPGetSerialBaseAddress(pInitContext)))
	{
		goto error;
	}

	// Get the base address of the PDC
	if(!(BSPGetSerialPdcBaseAddress(pInitContext)))
	{
		goto error;
	}

	// Get the base address of the PMC
	if(!(BSPGetSerialPmcBaseAddress(pInitContext)))
	{
		goto error;
	}

	// Call specific BSP init for serial peripheric
	if(!(BSPSerialInit(pInitContext)))
	{
		goto error;
	}

	// Commmon hardware init
	PA_PMCReg.QuadPart	= (LONGLONG) pInitContext->dwPMCBaseAddress;
	pInitContext->pPMCReg = (AT91PS_PMC) MmMapIoSpace(PA_PMCReg, sizeof(AT91S_PMC), FALSE);

	PA_USARTReg.QuadPart	= (LONGLONG) pInitContext->dwBaseAddress;
	pInitContext->pUSARTReg = (AT91PS_USART) MmMapIoSpace(PA_USARTReg, sizeof(AT91S_USART), FALSE);

	PA_PDCReg.QuadPart	= (LONGLONG) pInitContext->dwPDCBaseAddress;
	pInitContext->pPDCReg = (AT91PS_PDC) MmMapIoSpace(PA_PDCReg, sizeof(AT91S_PDC), FALSE);

	// If there is any mapping error, unmapped all
	if (pInitContext->pPMCReg == NULL || 
		pInitContext->pUSARTReg == NULL ||
		pInitContext->pPDCReg == NULL )
	{
		goto error;
	}

	return TRUE;

error :

	HWDeinit(pInitContext);
	return FALSE;
}

//------------------------------------------------------------------------------
//!	\fn				BOOL HWDeinit(T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Hardware de-initialization of the device
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//!
//! \return			True if success;
//! \return	\e		False if error
//------------------------------------------------------------------------------
BOOL HWDeinit(T_SERIAL_INIT_STRUCTURE *pInitContext)
{
	if (pInitContext == NULL)
	{
		return FALSE;
	}

	if (pInitContext->pPMCReg != NULL)
	{
		MmUnmapIoSpace(pInitContext->pPMCReg, sizeof(AT91S_PMC));
	}

	if (pInitContext->pUSARTReg != NULL)
	{
		MmUnmapIoSpace(pInitContext->pUSARTReg, sizeof(AT91S_USART));
	}

	if (pInitContext->pPDCReg != NULL)
	{
		MmUnmapIoSpace(pInitContext->pPDCReg, sizeof(AT91S_PDC));
	}

	// Call specific PIO deinit for serial peripheric
	BSPSerialDeinitPIO(pInitContext);

	return TRUE;
}

//------------------------------------------------------------------------------
//!	\fn				BOOL HWOpen(T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Hardware open of the device
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//!
//! \return			True if success;
//! \return	\e		False if error
//------------------------------------------------------------------------------
BOOL HWOpen(T_SERIAL_INIT_STRUCTURE *pInitContext)
{
	DWORD dwTempData;

	DEBUGMSG (DBG_OPEN, (L"+HWOpen()"));

	if (pInitContext == NULL)
	{
		DEBUGMSG (DBG_OPEN | DBG_ERROR, (L" HWOpen() : Error, pInitContext parameters not valid"));
		return FALSE;
	}

	// The serial port is opened for the first time, we should enable the clock
	pInitContext->pPMCReg->PMC_PCER = 1 << pInitContext->dwDeviceID;

	EnterCriticalSection (&pInitContext->csUsartReg);

	// Disable all USART IT
	pInitContext->pUSARTReg->US_IDR = 0xFFFFFFFF;
	// Disable TX & RX
	pInitContext->pUSARTReg->US_CR = AT91C_US_TXDIS | AT91C_US_RXDIS;
	// Reset controller
	pInitContext->pUSARTReg->US_CR = AT91C_US_RSTSTA | AT91C_US_STTTO | AT91C_US_RSTRX | AT91C_US_RSTTX;
	// Set up the controller for a normal mode uart, using the parameters given in the DCB structure
	pInitContext->pUSARTReg->US_MR = AT91C_US_USMODE_NORMAL;
	// Set peripheral internal Clock to master clock
	pInitContext->pUSARTReg->US_MR |= AT91C_US_CLKS_CLOCK;

	LeaveCriticalSection (&pInitContext->csUsartReg);

	// Get defaults from the DCB structure
	HWSetBaudRate( pInitContext, pInitContext->dcb.BaudRate );
	HWSetByteSize( pInitContext, pInitContext->dcb.ByteSize );
	HWSetStopBits( pInitContext, pInitContext->dcb.StopBits );
	HWSetParity  ( pInitContext, pInitContext->dcb.Parity );

	EnterCriticalSection (&pInitContext->csUsartReg);

	// Get last char in controller buffer
	dwTempData = pInitContext->pUSARTReg->US_RHR;
	// Reset Status bit & timeout counter
	pInitContext->pUSARTReg->US_CR = AT91C_US_RSTSTA;
	
	// Enable PDC Receive & Transmit channel
	pInitContext->pUSARTReg->US_PTCR = AT91C_PDC_RXTEN;
	
	// Enable Receive & Transmit
	pInitContext->pUSARTReg->US_CR = AT91C_US_RXEN;

	// Init Rx DMA with entry of DMA
	// Default value are : RPR = BufferStart; RCR = BufferSize/2 | RNPR = BufferStart+(BufferSize/2);RNCR = BufferSize/2
	HWSetRxDmaRegisterValue(  pInitContext
							, pInitContext->dwPADmaRxBufferStart
							, pInitContext->dwRxBufferSize / 2
							, pInitContext->dwPADmaRxBufferStart + (pInitContext->dwRxBufferSize / 2)
							, pInitContext->dwRxBufferSize / 2
							);

	// Init TX DMA register with null value
	HWSetTxDmaRegisterValue(pInitContext, 0, 0, 0, 0);

	// Reset status flag
	pInitContext->pUSARTReg->US_CR = AT91C_US_RSTSTA;

	// Clear RTS at startup
	HWClearRTS(pInitContext);

	//HWEnableTimeOutInterrupt(pInitContext);
	HWEnableRxInterrupt(pInitContext);

	HWEnableReceive(pInitContext);

	LeaveCriticalSection (&pInitContext->csUsartReg);
	
	DEBUGMSG (DBG_OPEN, (L"-HWOpen()"));
	return TRUE;
}

//------------------------------------------------------------------------------
//!	\fn				VOID HWPurgeRxBuffers(T_SERIAL_OPEN_STRUCTURE *pOpenHead)
//!
//! \brief			Discards all RX characters.
//! 
//! \param	pOpenHead		Context pointer returned from COM_Open.
//!
//! \return			No return value
//------------------------------------------------------------------------------
VOID HWPurgeRxBuffers(T_SERIAL_OPEN_STRUCTURE *pOpenHead)
{
	T_SERIAL_INIT_STRUCTURE *pInitContext = pOpenHead->pSerialInit;

	// \warning Disable interrupt to minimize the section where PDC is disabled.
	// If the current thread have a low priority, the following code can't be interrupt.
	DisableInt();
	// Disable PDC received
	HWDisableReceive(pInitContext);

	// Protection are not used because this code is in a critical section (DisableInt()-EnableInt())
	pInitContext->dwPAControllerRxData		= pInitContext->dwPADmaRxBufferStart;
	pInitContext->dwPAUserRxData			= pInitContext->dwPADmaRxBufferStart;
	pInitContext->dwPADmaRxBufferTrueEnd	= pInitContext->dwPADmaRxBufferEnd;

	// Restore default value :  RPR = BufferStart; RCR = BufferSize/2
	//							RNPR = BufferStart+(BufferSize/2); RNCR = BufferSize/2
	HWSetRxDmaRegisterValue(  pInitContext
							, pInitContext->dwPADmaRxBufferStart
							, pInitContext->dwRxBufferSize / 2
							, pInitContext->dwPADmaRxBufferStart + (pInitContext->dwRxBufferSize / 2)
							, pInitContext->dwRxBufferSize / 2
							);

	// Clear RTS
	HWClearRTS(pInitContext);

	// Enable PDC received
	HWEnableReceive(pInitContext);
	// \warning Enable interrupt to end critical section.
	// The code below is the shortest as possible
	EnableInt();
}

//------------------------------------------------------------------------------
//!	\fn				VOID HWPurgeTxBuffers(T_SERIAL_OPEN_STRUCTURE *pOpenHead)
//!
//! \brief			Discards all TX characters.
//! 
//! \param	pOpenHead		Context pointer returned from COM_Open.
//!
//! \return			No return value
//------------------------------------------------------------------------------
VOID HWPurgeTxBuffers(T_SERIAL_OPEN_STRUCTURE *pOpenHead)
{
	T_SERIAL_INIT_STRUCTURE *pInitContext = pOpenHead->pSerialInit;

	EnterCriticalSection(&pInitContext->csUsartReg);

	// Disable PDC transmit channel.
	pInitContext->pUSARTReg->US_PTCR = AT91C_PDC_TXTDIS;

	pInitContext->bTxAbort = TRUE;

	HWSetTxDmaRegisterValue(pInitContext, 0, 0, 0, 0);

	// Reenable PDC transmit channel.
	pInitContext->pUSARTReg->US_PTCR = AT91C_PDC_TXTEN;
	HWEnableTxInterrupt(pInitContext);

	LeaveCriticalSection(&pInitContext->csUsartReg);
}


//------------------------------------------------------------------------------
//!	\fn				VOID HWSetRxDmaRegisterValue(T_SERIAL_INIT_STRUCTURE *pInitContext, DWORD dwRPR, DWORD dwRCR, DWORD dwPNPR, DWORD dwRNCR)
//!
//! \brief			Set the value in the PDC for the receive direction
//! 
//!	\param	pInitContext	Context pointer returned from COM_Init.
//!	\param	dwRPR			Receive Pointer Register.
//!	\param	dwRCR			Receive Counter Register.
//!	\param	dwRNPR			Receive Next Pointer Register.
//!	\param	dwRNCR			Receive Next Counter Register.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID HWSetRxDmaRegisterValue(T_SERIAL_INIT_STRUCTURE *pInitContext, DWORD dwRPR, DWORD dwRCR, DWORD dwRNPR, DWORD dwRNCR)
{
/*
	pInitContext->dwLastRNPRValue = dwRNPR;
	pInitContext->dwLastRNCRValue = dwRNCR;
	
	pInitContext->dwLastRPRValue = dwRPR;
	pInitContext->dwLastRCRValue = dwRCR;
*/
	pInitContext->pUSARTReg->US_RPR =  dwRPR;
	pInitContext->pUSARTReg->US_RCR =  dwRCR;

	pInitContext->pUSARTReg->US_RNPR = dwRNPR;
	pInitContext->pUSARTReg->US_RNCR = dwRNCR;
}

//------------------------------------------------------------------------------
//!	\fn				VOID HWSetTxDmaRegisterValue(T_SERIAL_INIT_STRUCTURE *pInitContext, DWORD dwTPR, DWORD dwTCR, DWORD dwTNPR, DWORD dwTNCR)
//!
//! \brief			Set the value in the PDC for the transmit direction
//! 
//!	\param	pInitContext	Context pointer returned from COM_Init.
//!	\param	dwTPR			Transmit Pointer Register.
//!	\param	dwTCR			Transmit Counter Register.
//!	\param	dwTNPR			Transmit Next Pointer Register.
//!	\param	dwTNCR			Transmit Next Counter Register.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID HWSetTxDmaRegisterValue(T_SERIAL_INIT_STRUCTURE *pInitContext, DWORD dwTPR, DWORD dwTCR, DWORD dwTNPR, DWORD dwTNCR)
{
	pInitContext->pUSARTReg->US_TPR  =  dwTPR;
	pInitContext->pUSARTReg->US_TCR  =  dwTCR;

	pInitContext->pUSARTReg->US_TNPR =  dwTNPR;
	pInitContext->pUSARTReg->US_TNCR =  dwTNCR;
}

//------------------------------------------------------------------------------
//!	\fn				BOOL HWClose(T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Hardware close of the device
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//!
//! \return			True if success;
//! \return	\e		False if error
//------------------------------------------------------------------------------
BOOL HWClose(T_SERIAL_INIT_STRUCTURE *pInitContext)
{
	DEBUGMSG (DBG_CLOSE, (L"+HWClose(()"));

	if (pInitContext == NULL)
	{
		DEBUGMSG (DBG_OPEN | DBG_ERROR, (L" HWClose() : Error, pInitContext parameters not valid"));
		return FALSE;
	}

	// Enter critical section to protect usart reg access
	EnterCriticalSection (&pInitContext->csUsartReg);

	// Disable all USART IT
	pInitContext->pUSARTReg->US_IDR = 0xFFFFFFFF;

	// Disable TX & RX
	pInitContext->pUSARTReg->US_CR = AT91C_US_TXDIS | AT91C_US_RXDIS;
	
	// Disable DMA
	pInitContext->pUSARTReg->US_PTCR = AT91C_PDC_RXTDIS | AT91C_PDC_TXTDIS;

	HWClearRTS(pInitContext);

	// Disable periph clock
	pInitContext->pPMCReg->PMC_PCDR = 1 << pInitContext->dwDeviceID;

	// Release usart reg access
	LeaveCriticalSection (&pInitContext->csUsartReg);

	DEBUGMSG (DBG_CLOSE, (L"-HWClose(()"));

	return TRUE;
}

//------------------------------------------------------------------------------
//!	\fn				VOID HWSetRxDmaRegisterNextValue(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure, DWORD dwRNPR, DWORD dwRNCR )
//!
//! \brief			Set the next buffer of the PDC in the receive direction
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//! \param dwRNPR			
//! \param dwRNCR			
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID HWSetRxDmaRegisterNextValue(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure, DWORD dwRNPR, DWORD dwRNCR )
{
/*
	// Translate regsiter value
	pSerialInitStructure->dwLastRCRValue = pSerialInitStructure->dwLastRNCRValue;
	pSerialInitStructure->dwLastRPRValue = pSerialInitStructure->dwLastRNPRValue;

	pSerialInitStructure->dwLastRNCRValue = dwRNCR;
	pSerialInitStructure->dwLastRNPRValue = dwRNPR;
*/

	// Set DMA Next  buffer to US PDC register
	pSerialInitStructure->pUSARTReg->US_RNPR = dwRNPR;
	pSerialInitStructure->pUSARTReg->US_RNCR = dwRNCR;
}

//------------------------------------------------------------------------------
//!	\fn				VOID HWSetTxDmaRegisterNextValue(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure, DWORD dwTNPR, DWORD dwTNCR)
//!
//! \brief			Set the next buffer of the PDC in the transmit direction
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//! \param dwTNPR			
//! \param dwTNCR			
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID HWSetTxDmaRegisterNextValue(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure, DWORD dwTNPR, DWORD dwTNCR)
{
	// Set DMA Next  buffer to US PDC register
	pSerialInitStructure->pUSARTReg->US_TNPR = dwTNPR;
	pSerialInitStructure->pUSARTReg->US_TNCR = dwTNCR;
}


//------------------------------------------------------------------------------
//!	\fn				DWORD HWGetInterruptStatus(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Get the status of the interrupt register
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			Status of the interruption
//------------------------------------------------------------------------------
DWORD HWGetInterruptStatus(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	DWORD  dwIMRValue, dwCSRValue, dwInterruptStatus;

	EnterCriticalSection (&pSerialInitStructure->csUsartReg);
	
	// Read interrupt status mask
	dwCSRValue = pSerialInitStructure->pUSARTReg->US_CSR;
	dwIMRValue = pSerialInitStructure->pUSARTReg->US_IMR;
	dwInterruptStatus = dwIMRValue & dwCSRValue;

	LeaveCriticalSection (&pSerialInitStructure->csUsartReg);

	return dwInterruptStatus;
}

//------------------------------------------------------------------------------
//!	\fn				VOID HWEnableTransmit(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Enable the transmission
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID HWEnableTransmit(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	// Enable DMA
	pSerialInitStructure->pUSARTReg->US_PTCR = AT91C_PDC_TXTEN;
	
	// Enable Car Transmit
	pSerialInitStructure->pUSARTReg->US_CR = AT91C_US_TXEN;
}

//------------------------------------------------------------------------------
//!	\fn				VOID HWDisableTransmit(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Disable the transmission
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID HWDisableTransmit(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	// Disable DMA
	pSerialInitStructure->pUSARTReg->US_PTCR = AT91C_PDC_TXTDIS;
}

//------------------------------------------------------------------------------
//!	\fn				VOID HWEnableReceive(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Enable the reception
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID HWEnableReceive(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	// Enable DMA
	pSerialInitStructure->pUSARTReg->US_PTCR = AT91C_PDC_RXTEN;
}

//------------------------------------------------------------------------------
//!	\fn				VOID HWDisableReceive(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Disable the reception
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID HWDisableReceive(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	// Disable DMA
	pSerialInitStructure->pUSARTReg->US_PTCR = AT91C_PDC_RXTDIS;
}

//------------------------------------------------------------------------------
//!	\fn				VOID HWEnableTimeOutInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Enable the TimeOut interrupt
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID HWEnableTimeOutInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	pSerialInitStructure->pUSARTReg->US_IER = AT91C_US_TIMEOUT;
}

//------------------------------------------------------------------------------
//!	\fn				VOID HWDisableTimeOutInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Disable the TimeOut interrupt
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID HWDisableTimeOutInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	pSerialInitStructure->pUSARTReg->US_IDR = AT91C_US_TIMEOUT;
}

//------------------------------------------------------------------------------
//!	\fn				VOID HWEnableTxInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Enable the Transmit interrupt
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID HWEnableTxInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	pSerialInitStructure->pUSARTReg->US_IER = AT91C_US_ENDTX | AT91C_US_TXEMPTY;
}

//------------------------------------------------------------------------------
//!	\fn				VOID HWDisableTxENDInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Disable the transmit end interrupt
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID HWDisableTxENDInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	pSerialInitStructure->pUSARTReg->US_IDR = AT91C_US_ENDTX;
}

//------------------------------------------------------------------------------
//!	\fn				VOID HWDisableTxEMPTYInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Disable the transmit empty interrupt
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID HWDisableTxEMPTYInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	pSerialInitStructure->pUSARTReg->US_IDR = AT91C_US_TXEMPTY;
}

//------------------------------------------------------------------------------
//!	\fn				VOID HWEnableRxInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Enable the reception interrupt
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID HWEnableRxInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	pSerialInitStructure->pUSARTReg->US_IER = AT91C_US_ENDRX | AT91C_US_RXBUFF | AT91C_US_OVRE;
}

//------------------------------------------------------------------------------
//!	\fn				VOID  HWEnableRxENDInterrupt	(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Enable the reception end interrupt
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID  HWEnableRxENDInterrupt	(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	pSerialInitStructure->pUSARTReg->US_IER = AT91C_US_ENDRX;
}

//------------------------------------------------------------------------------
//!	\fn				VOID HWDisableRxENDInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Disable the reception end interrupt
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID HWDisableRxENDInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	pSerialInitStructure->pUSARTReg->US_IDR = AT91C_US_ENDRX;
}

//------------------------------------------------------------------------------
//!	\fn				VOID  HWEnableRxBUFFInterrupt	(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Enable the reception buffer full interrupt
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID  HWEnableRxBUFFInterrupt	(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	pSerialInitStructure->pUSARTReg->US_IER = AT91C_US_RXBUFF;
}

//------------------------------------------------------------------------------
//!	\fn				VOID HWDisableRxBUFFInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Disable the reception buffer full interrupt
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID HWDisableRxBUFFInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	pSerialInitStructure->pUSARTReg->US_IDR = AT91C_US_RXBUFF;
}

//------------------------------------------------------------------------------
//!	\fn				VOID HWDisableRxInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Disable the reception interrupt
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID HWDisableRxInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	pSerialInitStructure->pUSARTReg->US_IDR = AT91C_US_ENDRX | AT91C_US_RXBUFF;
}


//------------------------------------------------------------------------------
//!	\fn				VOID  HWEnableRxBreakInterrupt	(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Enable the reception break interrupt
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID  HWEnableRxBreakInterrupt	(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	pSerialInitStructure->pUSARTReg->US_IER = AT91C_US_RXBRK;
}

//------------------------------------------------------------------------------
//!	\fn				VOID  HWDisableRxBreakInterrupt	(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Disable the reception break interrupt
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID HWDisableRxBreakInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	pSerialInitStructure->pUSARTReg->US_IDR = AT91C_US_RXBRK;
}

//------------------------------------------------------------------------------
//!	\fn				VOID  HWEnableFrameErrorInterrupt	(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Enable the frame error interrupt
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID  HWEnableFrameErrorInterrupt	(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	pSerialInitStructure->pUSARTReg->US_IER = AT91C_US_FRAME;
}

//------------------------------------------------------------------------------
//!	\fn				VOID  HWDisableFrameErrorInterrupt	(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Disable the frame error interrupt
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID HWDisableFrameErrorInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	pSerialInitStructure->pUSARTReg->US_IDR = AT91C_US_FRAME;
}

//------------------------------------------------------------------------------
//!	\fn				VOID  HWEnableParityErrorInterrupt	(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Enable the parity error interrupt
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID  HWEnableParityErrorInterrupt	(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	pSerialInitStructure->pUSARTReg->US_IER = AT91C_US_PARE;
}

//------------------------------------------------------------------------------
//!	\fn				VOID  HWDisableParityErrorInterrupt	(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Disable the parity error interrupt
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID HWDisableParityErrorInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	pSerialInitStructure->pUSARTReg->US_IDR = AT91C_US_PARE;
}

//------------------------------------------------------------------------------
//!	\fn				VOID  HWEnableDataCarrierDetectInterrupt	(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Enable the data carrier input change interrupt
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID  HWEnableDataCarrierDetectInterrupt	(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	pSerialInitStructure->pUSARTReg->US_IER = AT91C_US_DCDIC;
}

//------------------------------------------------------------------------------
//!	\fn				VOID  HWDisableDataCarrierDetectInterrupt	(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
//!
//! \brief			Disable the data carrier input change interrupt
//! 
//! \param pSerialInitStructure	Context pointer returned from COM_Init.
//!
//! \return			No return
//------------------------------------------------------------------------------
VOID HWDisableDataCarrierDetectInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure)
{
	pSerialInitStructure->pUSARTReg->US_IDR = AT91C_US_DCDIC;
}

//-----------------------------------------------------------------------------
//! \fn				VOID HWSetBreak(T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Set a break
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//! 
//! \return			No return
//-----------------------------------------------------------------------------
VOID HWSetBreak(T_SERIAL_INIT_STRUCTURE *pInitContext)
{
	if (pInitContext == NULL)
		return ;

	DEBUGMSG(DBG_FUNCTION, (TEXT("+HWSetBreak (STTBRK) 0x%X\r\n"), pInitContext));

	// Enable Break and tx clock
	pInitContext->pUSARTReg->US_CR = AT91C_US_STTBRK | AT91C_US_TXEN;

	DEBUGMSG(DBG_FUNCTION, (TEXT("-HWSetBreak (STTBRK) 0x%X\r\n"), pInitContext));
}

//-----------------------------------------------------------------------------
//! \fn				VOID HWClearBreak(T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Clear the break
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//! 
//! \return			No return
//-----------------------------------------------------------------------------
VOID HWClearBreak(T_SERIAL_INIT_STRUCTURE *pInitContext)
{

	if (pInitContext == NULL)
		return ;

	DEBUGMSG(DBG_FUNCTION, (TEXT("+HWClearBreak (STPBRK) 0x%X\r\n"), pInitContext));

	// Clear break and tx clock
	pInitContext->pUSARTReg->US_CR = AT91C_US_STPBRK | AT91C_US_TXDIS;

	DEBUGMSG(DBG_FUNCTION, (TEXT("-HWClearBreak (DTRDIS) 0x%X\r\n"), pInitContext));
	
}


//-----------------------------------------------------------------------------
//! \fn				VOID HWSetDTR(T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Set the DTR Signal
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//! 
//! \return			No return
//-----------------------------------------------------------------------------
VOID HWSetDTR(T_SERIAL_INIT_STRUCTURE *pInitContext)
{

	if (pInitContext == NULL)
		return ;

	DEBUGMSG(DBG_FUNCTION, (TEXT("+HWSetDTR (DTREN) 0x%X\r\n"), pInitContext));

	pInitContext->pUSARTReg->US_CR = AT91C_US_DTREN;

	DEBUGMSG(DBG_FUNCTION, (TEXT("-HWSetDTR (DTREN) 0x%X\r\n"), pInitContext));
	
}

//-----------------------------------------------------------------------------
//! \fn				VOID HWClearDTR(T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Clear the DTR Signal
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//! 
//! \return			No return
//-----------------------------------------------------------------------------
VOID HWClearDTR(T_SERIAL_INIT_STRUCTURE *pInitContext)
{

	if (pInitContext == NULL)
		return ;

	DEBUGMSG(DBG_FUNCTION, (TEXT("+HWClearDTR (DTRDIS) 0x%X\r\n"), pInitContext));

	pInitContext->pUSARTReg->US_CR = AT91C_US_DTRDIS;

	DEBUGMSG(DBG_FUNCTION, (TEXT("-HWClearDTR (DTRDIS) 0x%X\r\n"), pInitContext));
	
}

//-----------------------------------------------------------------------------
//! \fn				VOID HWSetRTS(T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Set the RTS Signal
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//! 
//! \return			No return
//-----------------------------------------------------------------------------
VOID HWSetRTS(T_SERIAL_INIT_STRUCTURE *pInitContext)
{
	if (pInitContext == NULL)
		return ;

	// Disactivate the RTS (set) to avoid an overrun 
	BSPSerialSetRTS (pInitContext);
	// Disable interrupt for let the PDC free som buffers
	pInitContext->pUSARTReg->US_IDR = AT91C_US_ENDRX | AT91C_US_RXBUFF;
}


//-----------------------------------------------------------------------------
//! \fn				VOID HWClearRTS(T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Clear the RTS Signal
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//! 
//! \return			No return
//-----------------------------------------------------------------------------
VOID HWClearRTS(T_SERIAL_INIT_STRUCTURE *pInitContext)
{
	if (pInitContext == NULL)
		return ;

	// Activate the RTS (clear) to (re)start the transfert
	BSPSerialClearRTS (pInitContext);
	// Enable interrupt for let PDC fill in the free buffer
	pInitContext->pUSARTReg->US_IER = AT91C_US_ENDRX | AT91C_US_RXBUFF;
}

//-----------------------------------------------------------------------------
//! \fn				BOOL HWSetParity(T_SERIAL_INIT_STRUCTURE *pInitContext, DWORD dwParity)
//!
//! \brief			Set the parity
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//! \param dwParity		Parity to set.
//! 
//! \return			True if success;
//! \return	\e		False if error
//-----------------------------------------------------------------------------
BOOL HWSetParity(T_SERIAL_INIT_STRUCTURE *pInitContext, DWORD dwParity)
{
	BOOL bRet = TRUE;
	DWORD dwUS_MR = 0x00000000;

	if (pInitContext == NULL)
		return FALSE;


	EnterCriticalSection(&pInitContext->csUsartReg);

	dwUS_MR = pInitContext->pUSARTReg->US_MR & ~AT91C_US_PAR;

	switch (dwParity)
	{
		case EVENPARITY:
			dwUS_MR |= AT91C_US_PAR_EVEN;
			break;

		case MARKPARITY:
			dwUS_MR |= AT91C_US_PAR_MARK;
			break;

		case NOPARITY:
			dwUS_MR |= AT91C_US_PAR_NONE;
			break;

		case ODDPARITY:
			dwUS_MR |= AT91C_US_PAR_ODD;
			break;

		case SPACEPARITY:
			dwUS_MR |= AT91C_US_PAR_SPACE;
			break;

		default:
			bRet = FALSE;
			break;
	}

	if (bRet)
	{
		pInitContext->pUSARTReg->US_MR = dwUS_MR;
	}

	LeaveCriticalSection(&pInitContext->csUsartReg);

	DEBUGMSG(DBG_FUNCTION, (TEXT("-HWSetParity 0x%X, PAR = 0x%08X\r\n"), pInitContext, dwUS_MR));

	return bRet;
}

//-----------------------------------------------------------------------------
//! \fn		BOOL HWSetStopBits(T_SERIAL_INIT_STRUCTURE *pInitContext, DWORD dwStopBits)
//!
//! \brief			Set the stop bit
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//! \param dwStopBits	Stop bit to set.
//! 
//! \return			True if success;
//! \return	\e		False if error
//-----------------------------------------------------------------------------
BOOL HWSetStopBits(T_SERIAL_INIT_STRUCTURE *pInitContext, DWORD dwStopBits)
{
	BOOL bRet = TRUE;
	DWORD dwUS_MR = 0x00000000;

	if (pInitContext == NULL)
		return FALSE;

	EnterCriticalSection(&pInitContext->csUsartReg);

	dwUS_MR = pInitContext->pUSARTReg->US_MR & ~AT91C_US_NBSTOP;

	switch (dwStopBits)
	{
		case ONESTOPBIT:
			dwUS_MR |= AT91C_US_NBSTOP_1_BIT;
			break;

		case ONE5STOPBITS:
			dwUS_MR |= AT91C_US_NBSTOP_15_BIT;
			break;

		case TWOSTOPBITS:
			dwUS_MR |= AT91C_US_NBSTOP_2_BIT;
			break;

		default:
			bRet = FALSE;
	}

	if (bRet)
	{
		pInitContext->pUSARTReg->US_MR = dwUS_MR;
	}

	LeaveCriticalSection(&pInitContext->csUsartReg);

	DEBUGMSG(DBG_FUNCTION, (TEXT("-HWSetByteSize 0x%X, NBSTOP = 0x%08X\r\n"), pInitContext, dwUS_MR));

	return bRet;
}



//-----------------------------------------------------------------------------
//! \fn				BOOL HWSetByteSize(T_SERIAL_INIT_STRUCTURE *pInitContext, DWORD dwByteSize)
//!
//! \brief			Set the byte size
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//! \param dwByteSize	Byte size to set.
//! 
//! \return			True if success;
//! \return	\e		False if error
//-----------------------------------------------------------------------------
BOOL HWSetByteSize(T_SERIAL_INIT_STRUCTURE *pInitContext, DWORD dwByteSize)
{
	BOOL bRet = TRUE;
	DWORD dwUS_MR = 0x00000000;

	if (pInitContext == NULL)
		return FALSE;

	EnterCriticalSection(&pInitContext->csUsartReg);

	dwUS_MR = pInitContext->pUSARTReg->US_MR & ~AT91C_US_CHRL;

	switch (dwByteSize)
	{
		case 5:
			dwUS_MR |= AT91C_US_CHRL_5_BITS;
			break;

		case 6:
			dwUS_MR |= AT91C_US_CHRL_6_BITS;
			break;

		case 7:
			dwUS_MR |= AT91C_US_CHRL_7_BITS;
			break;

		case 8:
			dwUS_MR |= AT91C_US_CHRL_8_BITS;
			break;

		default:
			bRet = FALSE;
	}

	if (bRet)
	{
		pInitContext->pUSARTReg->US_MR = dwUS_MR;
	}

	LeaveCriticalSection(&pInitContext->csUsartReg);

	DEBUGMSG(DBG_FUNCTION, (TEXT("-HWSetByteSize 0x%X, CHRL = 0x%08X\r\n"), pInitContext, dwUS_MR));

	return bRet;
}

//-----------------------------------------------------------------------------
//! \fn				BOOL HWSetMode(T_SERIAL_INIT_STRUCTURE *pInitContext, DWORD dwfRtsControl, DWORD dwfDtrControl)
//!
//! \brief			Set the mode
//! 
//! \param pInitContext		Context pointer returned from COM_Init.
//! \param dwfRtsControl	RTS flow control mode.
//! \param dwfDtrControl	DTR flow control mode.
//! 
//! \return			True if success;
//! \return	\e		False if error
//-----------------------------------------------------------------------------
BOOL HWSetMode(T_SERIAL_INIT_STRUCTURE *pInitContext, DWORD dwfRtsControl, DWORD dwfDtrControl)
{
	BOOL bRet = TRUE;
	DWORD dwUSMode = (pInitContext->pUSARTReg->US_MR & AT91C_US_USMODE);
	
	DEBUGMSG(DBG_FUNCTION, (TEXT("+HWSetMode 0x%X, Current mode = 0x%08X\r\n"), pInitContext, dwUSMode));

	// Normal mode : no CTS/RTS | DSR/DTR control
	if (dwfRtsControl != RTS_CONTROL_HANDSHAKE && dwfDtrControl != DTR_CONTROL_HANDSHAKE)
	{
		pInitContext->pUSARTReg->US_MR &= ~AT91C_US_USMODE;
		pInitContext->pUSARTReg->US_MR |= AT91C_US_USMODE_NORMAL;
		
		DEBUGMSG(DBG_FUNCTION, (TEXT(".HWSetMode 0x%X, Set new Usart mode NORMAL\r\n"), pInitContext));
	}
	// Hardware Handshaking mode : only CTS/RTS control
	else if (dwfRtsControl == RTS_CONTROL_HANDSHAKE && dwfDtrControl != DTR_CONTROL_HANDSHAKE)
	{
		pInitContext->pUSARTReg->US_MR &= ~AT91C_US_USMODE;
		pInitContext->pUSARTReg->US_MR |= AT91C_US_USMODE_HWHSH;
		
		DEBUGMSG(DBG_FUNCTION, (TEXT(".HWSetMode 0x%X, Set new Usart mode HARDWARE HANDSHAKING\r\n"), pInitContext));
	}
	// Modem mode : CTS/RTS and DSR/DTR control
	else if (dwfRtsControl == RTS_CONTROL_HANDSHAKE && dwfDtrControl == DTR_CONTROL_HANDSHAKE)
	{
		pInitContext->pUSARTReg->US_MR &= ~AT91C_US_USMODE;
		pInitContext->pUSARTReg->US_MR |= AT91C_US_USMODE_MODEM;

		DEBUGMSG(DBG_FUNCTION, (TEXT(".HWSetMode 0x%X, Set new Usart mode MODEM\r\n"), pInitContext));
	}
	// Unsupported configuration
	else if (dwfRtsControl != RTS_CONTROL_HANDSHAKE && dwfDtrControl == DTR_CONTROL_HANDSHAKE)
	{
		DEBUGMSG(DBG_FUNCTION, (TEXT(".HWSetMode 0x%X, Unsupported mode check the DCB flags\r\n"), pInitContext));
		bRet = FALSE;
	}

	DEBUGMSG(DBG_FUNCTION, (TEXT("-HWSetMode 0x%X\r\n"), pInitContext));

	return bRet;
}

//-----------------------------------------------------------------------------
//! \fn				DWORD HWReadCSR(T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Read the CSR signal
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//!
//!	\remarks		Not Implemented
//! 
//! \return			True if success;
//! \return	\e		False if error
//-----------------------------------------------------------------------------
DWORD HWReadCSR(T_SERIAL_INIT_STRUCTURE *pInitContext)
{
	//pInitContext->dwBufferedCSR = pInitContext->pUSARTReg->US_CSR | (pInitContext->dwBufferedCSR & CSRINTS);
	//return pInitContext->dwBufferedCSR;
	return 0;
}

//-----------------------------------------------------------------------------
//! \fn				VOID HWClearCSR(T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Clear the CSR signal
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//!
//!	\remarks		Not Implemented
//! 
//! \return			No return
//-----------------------------------------------------------------------------
VOID HWClearCSR(T_SERIAL_INIT_STRUCTURE *pInitContext)
{
	//pInitContext->dwBufferedCSR &= ~CSRINTS;
}

//-----------------------------------------------------------------------------
//! \fn				BOOL HWSetDCB(T_SERIAL_INIT_STRUCTURE *pInitContext, DCB *pDCB)
//!
//! \brief			Set the DCB
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//! \param pDCB			Pointer to the DCB structure to set.
//!
//! \return			True if success;
//! \return	\e		False if error
//-----------------------------------------------------------------------------
BOOL HWSetDCB(T_SERIAL_INIT_STRUCTURE *pInitContext, DCB *pDCB)
{
	BOOL bRet = TRUE;
	BOOL bDCBOK = TRUE;
	
	if (pInitContext == NULL || pDCB == NULL)
	{
		DEBUGMSG(DBG_FUNCTION|DBG_ERROR, (TEXT("+AT91_HWSetDCB : Bad parameters.\r\n")));
		return FALSE;
	}

	DEBUGMSG(DBG_FUNCTION,(TEXT("+AT91_HWSetDCB.\r\n")));
	DEBUGMSG(DBG_FUNCTION,(TEXT("AT91_HWSetDCB : ------------ old ------------\r\n")));
	DEBUGMSG(DBG_FUNCTION,(TEXT("AT91_HWSetDCB : BaudRate		: %d\r\n"), pInitContext->dcb.BaudRate));
	DEBUGMSG(DBG_FUNCTION,(TEXT("AT91_HWSetDCB : ByteSize		: %d\r\n"), pInitContext->dcb.ByteSize));
	DEBUGMSG(DBG_FUNCTION,(TEXT("AT91_HWSetDCB : Parity			: %d\r\n"), pInitContext->dcb.Parity));
	DEBUGMSG(DBG_FUNCTION,(TEXT("AT91_HWSetDCB : StopBits		: %d\r\n"), pInitContext->dcb.StopBits));
	DEBUGMSG(DBG_FUNCTION,(TEXT("AT91_HWSetDCB : ------------- new ------------\r\n")));
	DEBUGMSG(DBG_FUNCTION,(TEXT("AT91_HWSetDCB : BaudRate		: %d\r\n"), pDCB->BaudRate));
	DEBUGMSG(DBG_FUNCTION,(TEXT("AT91_HWSetDCB : ByteSize		: %d\r\n"), pDCB->ByteSize));
	DEBUGMSG(DBG_FUNCTION,(TEXT("AT91_HWSetDCB : Parity			: %d\r\n"), pDCB->Parity));
	DEBUGMSG(DBG_FUNCTION,(TEXT("AT91_HWSetDCB : StopBits		: %d\r\n"), pDCB->StopBits));
	DEBUGMSG(DBG_FUNCTION,(TEXT("AT91_HWSetDCB : ------------------------------\r\n")));

	// Test if the DCB is available
	if( (pDCB->BaudRate == 75) | (pDCB->BaudRate == 110) | (pDCB->BaudRate == 300) | (pDCB->BaudRate == 600) | (pDCB->BaudRate == 1200)
		| (pDCB->BaudRate == 2400) | (pDCB->BaudRate == 4800) | (pDCB->BaudRate == 7200) | (pDCB->BaudRate == 9600) | (pDCB->BaudRate == 14400)
		| (pDCB->BaudRate == 19200) | (pDCB->BaudRate == 38400) | (pDCB->BaudRate == 56000) | (pDCB->BaudRate == 128000) | (pDCB->BaudRate == 115200)
		| (pDCB->BaudRate == 57600) )
	{
	}
	else
	{
		bDCBOK = FALSE;
	}
	
	if ( (pDCB->ByteSize < 5) | (pDCB->ByteSize >8) )
	{
		bDCBOK = FALSE;
	}
	
	if ( (pDCB->Parity != EVENPARITY) & (pDCB->Parity != MARKPARITY) & (pDCB->Parity != NOPARITY) 
		& (pDCB->Parity != ODDPARITY) & (pDCB->Parity != SPACEPARITY) ) 
	{
		bDCBOK = FALSE;
	}
	
	if ( (pDCB->StopBits != ONESTOPBIT) & (pDCB->StopBits != ONE5STOPBITS) & (pDCB->StopBits != TWOSTOPBITS) )
	{
		bDCBOK = FALSE;
	}
	
	if ((((pDCB->fDtrControl & DTR_CONTROL_HANDSHAKE) == DTR_CONTROL_HANDSHAKE)) && !(pInitContext->fControlMask & DTR_CONTROL_MASK))
	{
		RETAILMSG(1, (L" DTR_CONTROL_HANDSHAKE not supported"));
		bDCBOK = FALSE;
	}
	
	if ((((pDCB->fRtsControl & RTS_CONTROL_HANDSHAKE) == RTS_CONTROL_HANDSHAKE)) && !(pInitContext->fControlMask & RTS_CONTROL_MASK))
	{
		RETAILMSG(1, (L" Warning !!!! RTS_CONTROL_HANDSHAKE not supported"));
	}

	// DCB set is valid, set wanted configuration to serial controller
	if (bDCBOK == TRUE)
	{
		// Baud rate
		if (pInitContext->dcb.BaudRate != pDCB->BaudRate)
		{
			bRet = HWSetBaudRate(pInitContext, pDCB->BaudRate);
			DEBUGMSG(DBG_FUNCTION, (TEXT(" AT91_HWSetDCB : Set new Baud Rate = %d.\r\n"), pDCB->BaudRate));
		}
		// Byte size
		if (bRet && pInitContext->dcb.ByteSize != pDCB->ByteSize)
		{
			bRet = HWSetByteSize(pInitContext, pDCB->ByteSize);
			DEBUGMSG(DBG_FUNCTION, (TEXT(" AT91_HWSetDCB : Set new Byte Size = %d.\r\n"), pDCB->ByteSize));
		}
		// Stop bits
		if (bRet && pInitContext->dcb.StopBits != pDCB->StopBits)
		{
			bRet = HWSetStopBits(pInitContext, pDCB->StopBits);
			DEBUGMSG(DBG_FUNCTION, (TEXT(" AT91_HWSetDCB : Set new Stop Bits = %d.\r\n"), pDCB->StopBits));
		}
		// Parity
		if (bRet && pInitContext->dcb.Parity != pDCB->Parity)
		{
			bRet = HWSetParity(pInitContext, pDCB->Parity);
			DEBUGMSG(DBG_FUNCTION, (TEXT(" AT91_HWSetDCB : Set new Parity = %d.\r\n"), pDCB->Parity));
		}

		// Change the UART mode
		if (bRet && (pInitContext->dcb.fRtsControl != pDCB->fRtsControl))
		{
			bRet = HWSetMode(pInitContext, pDCB->fRtsControl, pDCB->fDtrControl);
			DEBUGMSG(DBG_FUNCTION, (TEXT(" AT91_HWSetDCB : Set new Mode = %X.\r\n"), (pInitContext->pUSARTReg->US_MR & AT91C_US_USMODE)));
		}
	}
	else
	{
		bRet=FALSE;
	}
	DEBUGMSG(DBG_FUNCTION, (TEXT("-AT91_HWSetDCB.\r\n")));
	
	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn				VOID HWSetCommTimeouts(T_SERIAL_INIT_STRUCTURE *pInitContext, LPCOMMTIMEOUTS lpCommTimeouts)
//!
//! \brief			Set the Timeouts and enable the interrupt
//! 
//! \param pInitContext		Context pointer returned from COM_Init.
//! \param lpCommTimeouts	Pointer to the CommTimeouts structure to set.
//!
//! \return			No return
//-----------------------------------------------------------------------------
VOID HWSetCommTimeouts(T_SERIAL_INIT_STRUCTURE *pInitContext, LPCOMMTIMEOUTS lpCommTimeouts)
{
	DWORD dwBitsPeriod;

	if (pInitContext == NULL)
		return ;

	// If no ReadIntervalTimeout set, we set max value
	if (lpCommTimeouts->ReadIntervalTimeout == 0)
	{
		dwBitsPeriod = 0;
	}
	else
	{
		dwBitsPeriod = ((lpCommTimeouts->ReadIntervalTimeout * pInitContext->dcb.BaudRate ) / 1000);
	}
	
	// When nb_bit_period=0, we get an infinite timeout.
	// Due to the integer division, this value can be obtained, 
	// even if lpCommTimeouts->ReadIntervalTimeout is not 0.
	if (dwBitsPeriod > 0xFFFF)
	{
		dwBitsPeriod = 0xFFFF;		
	}
	
	EnterCriticalSection(&pInitContext->csUsartReg);
	pInitContext->pUSARTReg->US_CR = AT91C_US_STTTO;
	pInitContext->pUSARTReg->US_RTOR = dwBitsPeriod;
	LeaveCriticalSection(&pInitContext->csUsartReg);
	
	DEBUGMSG(DBG_FUNCTION,(TEXT("-HWSetCommTimeouts 0x%X, RTOR = 0x%08X\r\n"), pInitContext, dwBitsPeriod));
}


//-----------------------------------------------------------------------------
//! \fn				VOID HWClearCommTimeouts(T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Set the Timeouts
//! 
//! \param pInitContext		Context pointer returned from COM_Init.
//!
//! \return			No return
//-----------------------------------------------------------------------------
VOID HWClearCommTimeouts(T_SERIAL_INIT_STRUCTURE *pInitContext)
{
	EnterCriticalSection(&pInitContext->csUsartReg);
	pInitContext->pUSARTReg->US_IDR = AT91C_US_TIMEOUT;
	LeaveCriticalSection(&pInitContext->csUsartReg);
}




//-----------------------------------------------------------------------------
//! \fn				BOOL HWSetBaudRate (T_SERIAL_INIT_STRUCTURE *pInitContext, DWORD dwBaudRate)
//!
//! \brief			Set the Baudrate
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//! \param dwBaudRate	Baudrate to set.
//!
//! \return			True if success;
//! \return	\e		False if error
//-----------------------------------------------------------------------------
BOOL HWSetBaudRate (T_SERIAL_INIT_STRUCTURE *pInitContext, DWORD dwBaudRate)
{
	BOOL bRet = TRUE;

	if (pInitContext == NULL || dwBaudRate == 0)
		return FALSE;

	EnterCriticalSection(&pInitContext->csUsartReg);

	unsigned int baud_value = ((g_dwMasterClock * 10) / (dwBaudRate * 16));
	pInitContext->pUSARTReg->US_BRGR =
		(baud_value % 10) >= 5 ? (baud_value / 10) + 1 : baud_value / 10;

	LeaveCriticalSection(&pInitContext->csUsartReg);

	//The baudrate has changed, so the Interval Timeout clipping has changed as well, set the right timeout
	HWSetCommTimeouts(pInitContext, &pInitContext->commTimeouts);

	DEBUGMSG(DBG_FUNCTION,(TEXT("-HWSetBaudRate 0x%X, BaudRate = %d\r\n"), pInitContext, dwBaudRate));

	return bRet;
}

// End of Doxygen group Serial Driver
//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/Serial/Serial_SAM926X_HW.cpp $
//-----------------------------------------------------------------------------
//

//! @}
