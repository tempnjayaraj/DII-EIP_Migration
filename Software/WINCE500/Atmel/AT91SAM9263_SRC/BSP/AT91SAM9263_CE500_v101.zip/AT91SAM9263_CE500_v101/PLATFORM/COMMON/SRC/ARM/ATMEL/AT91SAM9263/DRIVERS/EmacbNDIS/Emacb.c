//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//! \addtogroup	EMAC
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		Emacb.c
//!
//! \brief		Emacb driver for AT91SAM9263's chipset
//!
//! \if cvs
//!   $Author: pgal $
//!   $Revision: 931 $
//!   $Date: 2007-06-04 14:28:02 +0200 (lun., 04 juin 2007) $
//! \endif
//!
//! Description of the driver on multi lines
//-----------------------------------------------------------------------------


// System include
#include <windows.h>
#include <oal.h>

// Local include
#include "at91sam926x.h"

//------------------------------------------------------------------------------
//! \fn void EMACBProcSpecificActivatePMC(void)
//! \brief Activate the PMC for EMABC controller
//------------------------------------------------------------------------------
void EMACBProcSpecificActivatePMC(void)
{
	AT91PS_PMC	pPMC;
	PHYSICAL_ADDRESS pa;

	pa.LowPart = (DWORD)AT91C_BASE_PMC;
	pPMC =  (AT91PS_PMC)MmMapIoSpace(pa, sizeof(AT91S_PMC), FALSE);		
		// Enable Peripheral clock in PMC for  EMAC		
	
	pPMC->PMC_PCER = ((unsigned int) 1 << AT91C_ID_EMAC);

	MmUnmapIoSpace(pPMC, sizeof(AT91S_PMC));		

}

//------------------------------------------------------------------------------
//! \fn void EMACBProcSpecificDeactivatePMC(void)
//! \brief Deactivate the PMC for EMABC controller
//------------------------------------------------------------------------------
void EMACBProcSpecificDeactivatePMC(void)
{
	AT91PS_PMC	pPMC;
	PHYSICAL_ADDRESS pa;

	pa.LowPart = (DWORD)AT91C_BASE_PMC;
	pPMC =  (AT91PS_PMC)MmMapIoSpace(pa, sizeof(AT91S_PMC), FALSE);		
		// Enable Peripheral clock in PMC for  EMAC		
	
	pPMC->PMC_PCDR = ((unsigned int) 1 << AT91C_ID_EMAC);

	MmUnmapIoSpace(pPMC, sizeof(AT91S_PMC));		

}

//------------------------------------------------------------------------------
//! \fn DWORD EMACBProcSpecificGetMacbBaseAddress(void)
//! \brief Getting emacb base address
//!
//! \return The EMACB base address
//------------------------------------------------------------------------------
DWORD EMACBProcSpecificGetMacbBaseAddress(void)
{
	return (DWORD)AT91C_BASE_MACB;
}

//! @}
//! @}
