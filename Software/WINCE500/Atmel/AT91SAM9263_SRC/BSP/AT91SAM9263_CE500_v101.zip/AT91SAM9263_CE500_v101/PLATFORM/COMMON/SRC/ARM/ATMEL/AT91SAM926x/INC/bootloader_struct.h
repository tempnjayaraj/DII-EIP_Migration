//------------------------------------------------------------------------------
//! \addtogroup	EBOOT
//! @{
//   All rights reserved ADENEO SAS 2005
//!
//------------------------------------------------------------------------------
//! \file		bootloader_struct.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/bootloader_struct.h $
//!   $Author: pgal $
//!   $Revision: 434 $
//!   $Date: 2007-02-28 16:33:13 +0100 (mer., 28 févr. 2007) $
//! \endif
//------------------------------------------------------------------------------

#ifndef BOOTLOADER_STRUCT_H
#define BOOTLOADER_STRUCT_H

//------------------------------------------------------------------------------
//                                                             Defines and types
//------------------------------------------------------------------------------

#pragma pack(1)
// The EBOOT_CFG structure holds a variety of configuration parameters.
// When adding new parameters, make sure that the size of the structure in bytes is 
// an integral number of DWORDS.  Pad the structure if necessary.

typedef struct
{
    DWORD dwPhysStart;
    DWORD dwPhysLen;
    DWORD dwLaunchAddr;    
    DWORD dwFlashLogicalAddress;
} IMGBOOT_DESC;

typedef struct
{
	DWORD ipAddress;
	DWORD subnetMask;
	DWORD dhcpEnable;
	DWORD delaySec;
  DWORD numBootMe;
	DWORD dwCoreFrequency;
	DWORD dwBusFreqDivider;
	BOOL  bImgToFlash;
	UCHAR macAddress[6];
	IMGBOOT_DESC imgBootDesc;
	DWORD autoDownloadImage;
	DWORD crc32; // must be at the end
} EBOOT_CFG, *PEBOOT_CFG;


typedef struct
{
	DWORD dwSize;
	DWORD dwEbootCodeFlashAddr;
	DWORD dwEbootSettingsFlashAddr;
	DWORD dwCrc32;

} T_BOOTLOADER_FLASH_CONFIG;
#pragma pack()

#endif  // BOOTLOADER_STRUCT_H

//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/bootloader_struct.h $
//------------------------------------------------------------------------------
//

//
//! @}
//
