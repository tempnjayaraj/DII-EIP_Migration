//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		shutdown.c
//!
//! \brief		AT91RM9200 shutdown feature
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/KERNEL/IOCTL/shutdown.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

#include <windows.h>
#include <oal.h>
#include <nkintr.h>

#include "at91rm9200.h"



//-----------------------------------------------------------------------------
//! \fn		BOOL OALIoCtlHalGetProcessorClock(	UINT32 code, VOID *pInpBuffer, 
//!								UINT32 inpSize, VOID *pOutBuffer, 
//!								UINT32 outSize, UINT32 *pOutSize)
//!
//! \brief		This function implements the IOCTL_HAL_SHUTDOWN IOControl
//!				Shutdown is not implemented yet
//!
//!	\param		code		not used
//!	\param		pInpBuffer	not used
//!	\param		inpSize		not used
//!	\param		pOutBuffer	not used
//!	\param		outSize		not used
//!	\param		pOutSize	not used
//!
//! \return		TRUE indicates success
//! \return		FALSE indicates failure (bad parameters)
//!
//! 
//-----------------------------------------------------------------------------
BOOL OALIoCtlHalShutdown(UINT32 code, VOID *pInpBuffer, 
                       UINT32 inpSize, VOID *pOutBuffer, 
                       UINT32 outSize, UINT32 *pOutSize)
{	

	RETAILMSG(1, (TEXT("OALIoCtlHalShutdown (TODO)\r\n")));
	
	return FALSE;
}


//! @}

