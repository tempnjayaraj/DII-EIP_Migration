//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Abstract:  

Holds definitions private to the implementation of the machine independent
driver interface.

--*/
//------------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//   All rights reserved ADENEO SAS 2005
//!
//------------------------------------------------------------------------------
//! \file		Serial_SAM926X.h
//!
//! \if subversion
//!   @URL: $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/Serial/Serial_SAM926X.h $
//!   @author $Author: pgal $
//!   @version $Revision: 916 $
//!   @date $Date: 2007-05-31 06:54:57 -0700 (Thu, 31 May 2007) $
//! \endif
//------------------------------------------------------------------------------
//! \addtogroup	Serial
//! @{


#ifndef __VSERIAL_H__
#define __VSERIAL_H__

//------------------------------------------------------------------------------
//                                                                      Includes
//------------------------------------------------------------------------------
// Only project includes
#include "AT91SAM926x.h"

//------------------------------------------------------------------------------
//                                                             Defines and types
//------------------------------------------------------------------------------

#define DEFAULT_RX_DMA_BUFFER_BYTE_SIZE		10240
#define RX_DMA_BUFFER_MIN_BYTE_SIZE			4096


#define DEFAULT_TX_DMA_BUFFER_BYTE_SIZE		1024
#define DEFAULT_TX_DMA_BUFFER_NUMBER		5
#define TX_DMA_BUFFER_MIN_NUMBER			2
//#define TX_DMA_TOTAL_BYTE_SIZE		(TX_DMA_BUFFER_BYTE_SIZE * TX_DMA_BUFFER_NUMBER)

#define	RX_INTERVAL_DEFAULT_TIMEOUT_VALUE 0xFFFF

//
// The serial event structure contains fields used to pass serial
// event information from the PDD to the MDD.  This information
// is passed via a callback, so the scope of this structure remains
// limited to the MDD.
//
typedef struct __COMM_EVENTS	{
	HANDLE				hCommEvent;						// @field Indicates serial events
	LONG				fEventMask;						// @field Event Mask requestd by application 
	LONG				fEventData;						// @field Event Mask Flag. 
    LONG				fAbort;							// @field TRUE after SetCommMask( 0 )
	CRITICAL_SECTION	EventCS;						//  CommEvent access and related sign atom	
} COMM_EVENTS, *PCOMM_EVENTS;


typedef struct
{
	PVOID					pReadAccessOwner;			// Pointer to whichever have accesses permission
    LIST_ENTRY				OpenList;					// Head of linked list of OPEN_INFOs 

	DCB						dcb;
	CRITICAL_SECTION		csSerialInitStructure;
	DWORD					dwOpenCnt;
	
	// Sum of event mask for all opens
	ULONG					fEventMask;	
	// Sum of event mask set for all opens
	ULONG					fEventMaskSet;
	
	// Supported control
	ULONG					fControlMask;

	// Timeout
	COMMTIMEOUTS			commTimeouts;
	HANDLE					hRxEvent;
	HANDLE					hTxEvent;

	// Transmit global init vars
	BOOL					bTxAbort;					//!< Purge Tx comm so, abort the com_write function
	DWORD					dwNbBytesToSend;			//!< Nb byte resting to send
	CRITICAL_SECTION		csNbBytesToSend;			//!< Protection for dwNbBytesToSend var access


	// USART Registers
	CRITICAL_SECTION		csUsartReg;
	volatile AT91PS_PMC		pPMCReg;					//!< Access to PMC registers
	volatile AT91PS_USART	pUSARTReg;					//!< Access to USART registers
	volatile AT91PS_PDC		pPDCReg;					//!< Access to PDC registers
	
	DWORD					dwDeviceID;					
	DWORD					dwDeviceIndex;					
	DWORD					dwBaseAddress;
	DWORD					dwPMCBaseAddress;
	DWORD					dwPDCBaseAddress;

	//// DMA
	// DMA buffer
	DMA_ADAPTER_OBJECT		dmaAdapter;					//!< DMA object for DMA buffers allocation

	// Receive DMA buffer
	PHYSICAL_ADDRESS	    * pDmaRxBufferPA;
	
	DWORD					dwPADmaRxBufferStart;
	DWORD					dwPADmaRxBufferEnd;
	DWORD					dwPADmaRxBufferTrueEnd;
	DWORD					dwPADmaRxBufferPRLimit;

	UCHAR					* pDmaRxBufferStart;

	DWORD					dwRxBufferSize;				//!< The read buffer total length
	DWORD					dwRxFCLLimit;				//!< Flow control's RX buffers low limit (4/5 * buffers count)
	DWORD					dwRxFCHLimit;				//!< Flow control's RX buffers high limit (3/5 * buffers count)
	DWORD					dwRxBufferDataAvailable;

	DWORD					dwPAControllerRxData;
	DWORD					dwPAUserRxData;

	// Transmit DMA buffer
	PVOID				    * pDmaTxBufferVA;
	PHYSICAL_ADDRESS	    * pDmaTxBufferPA;
	DWORD					dwTxBufferSize;
	DWORD					dwTxBufferCount;

	// Our buffer, all data received

	// Error Flags
	CRITICAL_SECTION		csErrorFlags;
	DWORD					dwErrorFlags;

	// Interrupt vars
	DWORD					dwSysIntr;
	BOOL					bSerialISTRun;
	HANDLE					hSerialEvent;
	HANDLE					hSerialIST;

	// Read & Write protection tools
	HANDLE					hReadMutex;
	HANDLE					hWriteMutex;

}	T_SERIAL_INIT_STRUCTURE;

typedef struct
{
	T_SERIAL_INIT_STRUCTURE* pSerialInit;
	COMM_EVENTS			CommEvents;						// @field Contains all info for serial event handling
	DWORD				AccessCode;						// @field What permissions was this opened with
    DWORD				ShareMode;						// @field What Share Mode was this opened with
    LIST_ENTRY			llist;							// @field Linked list of OPEN_INFOs
	BOOL				bTimeoutInterval;

}	T_SERIAL_OPEN_STRUCTURE;

#define E_OF_CHAR			0xd
#define ERROR_CHAR			0xd
#define BREAK_CHAR			0xd
#define EVENT_CHAR			0xd
#define X_ON_CHAR			0x11
#define X_OFF_CHAR			0x13

// Value of the flow control mask
#define	RTS_CONTROL_MASK	(1 << 0)
#define DTR_CONTROL_MASK	(1 << 1)



#define MIN(A,B) A<B?A:B
BOOL			SetThresHold(T_SERIAL_INIT_STRUCTURE * pSerialInitStructure, DWORD dwBufferLength);
BOOL			ComputeRR(T_SERIAL_INIT_STRUCTURE * pSerialInitStructure, DWORD dwWantedLen, DWORD * pdwRPR, DWORD * pdwRCR);
BOOL			ComputeRNR(T_SERIAL_INIT_STRUCTURE * pSerialInitStructure, DWORD dwRPR, DWORD dwRCR, DWORD * pdwRNPR, DWORD * pdwRNCR);
DWORD			ReadAvailableData(T_SERIAL_INIT_STRUCTURE * pSerialInitStructure, DWORD dwWantedByteNb, UCHAR ** pBufferDest);
inline DWORD	ComputeFreeSpace(T_SERIAL_INIT_STRUCTURE * pSerialInitStructure);
inline DWORD	ComputeAvailableChar(T_SERIAL_INIT_STRUCTURE * pSerialInitStructure);

#endif //	__VSERIAL_H__

//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/Serial/Serial_SAM926X.h $
//------------------------------------------------------------------------------
//

//
//! @}
//
//! @}
