//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//-----------------------------------------------------------------------------
//! \file		eboot_cfg.c 
//!
//! \brief		All eboot configuration manipulation
//!
//! \if subversion
///   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/GenericEBOOT/eboot_cfg.c $
//!   $Author: ltourlonias $
//!   $Revision: 985 $
//!   $Date: 2007-06-12 09:30:21 +0200 (mar., 12 juin 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	EBOOT
//! @{
//!


//------------------------------------------------------------------------------
//                                                                      Includes
//------------------------------------------------------------------------------
// Standard includes
#include <windows.h>
#include <nkintr.h>
#include <oal_memory.h>
#include <oal.h>

// Project include
#include "bootloader_struct.h"
#include "eboot_cfg.h"
#include "eboot_msg.h"

//------------------------------------------------------------------------------
//                                                               Defines & Types
//------------------------------------------------------------------------------



//------------------------------------------------------------------------------
//                                                            Imported variables
//------------------------------------------------------------------------------

// The default mac address (must be define in specfic part)
extern UCHAR						g_DefaultMacAddress[6];
extern T_BOOTLOADER_FLASH_CONFIG    g_bootFlashConfig;

//------------------------------------------------------------------------------
//                                                            Imported functions
//------------------------------------------------------------------------------

extern DWORD	EBOOT_GetCurrentSec(void);
extern UCHAR  * macAddr_toa(UCHAR* pMacAddress);
extern void		AsciiToMacAddr(UCHAR* pMacAddress,UCHAR* pSrc);

extern unsigned long ComputeCRC32(unsigned char *buf, int len);

extern DWORD	EBOOT_GetFlashImageLogicalAddress(void);

extern BOOL		EBOOT_InitFlash(DWORD dwAddress);
extern BOOL		EBOOT_ReadFlash(DWORD dwAddressDst, DWORD dwAddressSrc, DWORD dwLen);
extern BOOL		EBOOT_WriteFlash(DWORD dwAddressDst, DWORD dwAddressSrc, DWORD dwLen);
extern BOOL		EBOOT_EraseFlash(DWORD dwAddress, DWORD dwLen);
extern int		EBOOT_ReadDebugByte(void);

//------------------------------------------------------------------------------
//                                                            Exported functions
//------------------------------------------------------------------------------


//--------------------------------------------------------------------------------
//! \brief Load bootloader settings from flash
//!
//! \param pEbootCFG pointer to the structure of eboot settings
//--------------------------------------------------------------------------------
BOOL EBOOT_LoadConfigFromFlash(EBOOT_CFG *pEbootCFG)
{
	BOOL bResult = FALSE;

	// Read eboot config from flash
	if ( EBOOT_ReadFlash((DWORD)pEbootCFG, g_bootFlashConfig.dwEbootSettingsFlashAddr, sizeof(EBOOT_CFG)) == TRUE)
	{
		// Verify CRC
		if (pEbootCFG->crc32 != ComputeCRC32((UCHAR*)pEbootCFG,sizeof(EBOOT_CFG) - sizeof(DWORD)))
		{
			RETAILMSG(1,(EMSG_WARNING_NO_EBOOTCONFIG));
			RETAILMSG (1,(EMSG_CRLF));
			bResult = FALSE;
		}
		else
		{
			bResult = TRUE;
		}
	}
	else
	{
		RETAILMSG(1,(EMSG_ERROR_LOADEBOOTCONFIG));
		RETAILMSG (1,(EMSG_CRLF));
	}

	return(bResult);
}

//--------------------------------------------------------------------------------
//! \brief Save bootloader settings from flash
//!
//! \param pEbootCFG pointer to the structure of eboot settings
//--------------------------------------------------------------------------------
BOOL EBOOT_SaveConfigToFlash(EBOOT_CFG *pEbootCFG)
{
	BOOL bResult = FALSE;

	// Compute CRC32 to set it into the bootloader settings store
	pEbootCFG->crc32 = ComputeCRC32((UCHAR*)pEbootCFG,sizeof(EBOOT_CFG) - sizeof(DWORD));

	EBOOT_EraseFlash(g_bootFlashConfig.dwEbootSettingsFlashAddr, sizeof(EBOOT_CFG));

	//Write eboot config to flash
	if ( EBOOT_WriteFlash(g_bootFlashConfig.dwEbootSettingsFlashAddr, (DWORD)pEbootCFG, sizeof(EBOOT_CFG)) == TRUE)
	{
		//RETAILMSG(1,(EMSG_EBOOTCONFIG_SAVED));
		//RETAILMSG (1,(EMSG_CRLF));
		bResult = TRUE;
	}

	return bResult;
}


//--------------------------------------------------------------------------------
//! \brief Set the bootloader configuration. 
//!
//! \note This function is called when there's no valid flash settings found in flash
//!
//! \param pEbootCFG pointer to the structure that's to be filled
//!
//--------------------------------------------------------------------------------
void EBOOT_SetDefaultEBootCFG(EBOOT_CFG *pEbootCFG)
{
    pEbootCFG->delaySec			 = 5;
    pEbootCFG->autoDownloadImage = TRUE;
	memcpy(pEbootCFG->macAddress, g_DefaultMacAddress, sizeof(g_DefaultMacAddress));
    pEbootCFG->ipAddress         = inet_addr("192.168.111.115"); 
    pEbootCFG->subnetMask        = inet_addr("255.255.255.0"); 
    pEbootCFG->numBootMe         = 100;
    pEbootCFG->dhcpEnable        = TRUE;
	pEbootCFG->bImgToFlash		 = FALSE;

	pEbootCFG->dwCoreFrequency   = 200;
    pEbootCFG->dwBusFreqDivider  = 4;

    pEbootCFG->imgBootDesc.dwLaunchAddr				= 0x8005a000;
    pEbootCFG->imgBootDesc.dwPhysStart				= 0x80059000;
    pEbootCFG->imgBootDesc.dwPhysLen				= 0x0075144C;
	pEbootCFG->imgBootDesc.dwFlashLogicalAddress	= EBOOT_GetFlashImageLogicalAddress();

    pEbootCFG->crc32 = ComputeCRC32((UCHAR*)pEbootCFG,sizeof(EBOOT_CFG) - sizeof(DWORD));
}


//--------------------------------------------------------------------------------
//! \brief Get ip address from debug serial and set it into settings
//!
//! \param pEbootCFG pointer to the structure of eboot settings
//--------------------------------------------------------------------------------
void EBOOT_SetIP(EBOOT_CFG *pEbootCFG)
{
    char szDottedD[16]; // The string used to collect the dotted decimal IP address
    WORD cwNumChars = 0;
    UINT16 InChar = 0;

    EdbgOutputDebugString ( "\r\nEnter new IP address: ");

    while (!((InChar == 0x0d) || (InChar == 0x0a)))
    {
        InChar = EBOOT_ReadDebugByte();
        if (InChar != OEM_DEBUG_COM_ERROR && InChar != OEM_DEBUG_READ_NODATA)
        {
            // If it's a number or a period, add it to the string
            if (InChar == '.' || (InChar >= '0' && InChar <= '9'))
            {
                if (cwNumChars < 16)
                {
                    szDottedD[cwNumChars++] = (char)InChar;
                    OEMWriteDebugByte((BYTE)InChar);
                }
            }
            // If it's a backspace, back up
            else if (InChar == 8)
            {
                if (cwNumChars > 0)
                {
                    cwNumChars--;
                    OEMWriteDebugByte((BYTE)InChar);
                }
            }
        }
    }

    // If it's a carriage return with an empty string, don't change anything.
    if (cwNumChars)
    {
        szDottedD[cwNumChars] = '\0';
        pEbootCFG->ipAddress = inet_addr( szDottedD );
    }
}

//--------------------------------------------------------------------------------
//! \brief Get frequency from debug serial and set it to eboot settings
//!
//! \param pEbootCFG pointer to the structure of eboot settings
//--------------------------------------------------------------------------------
void EBOOT_SetFrequency(EBOOT_CFG *pEbootCFG)
{
    char szDottedD[3]; // The string used to collect the dotted masks
    WORD cwNumChars = 0;
    UINT16 InChar = 0;

    EdbgOutputDebugString ( "\r\nEnter new Core Frequency (old frequency is %d MHz) ",pEbootCFG->dwCoreFrequency);

    while (!((InChar == 0x0d) || (InChar == 0x0a)))
    {
        InChar = EBOOT_ReadDebugByte();
        if (InChar != OEM_DEBUG_COM_ERROR && InChar != OEM_DEBUG_READ_NODATA)
        {            
            if (InChar >= '0' && InChar <= '9')
            {
                if (cwNumChars < 3)
                {
                    szDottedD[cwNumChars++] = (char)InChar;
                    OEMWriteDebugByte((BYTE)InChar);
                }
            }
            // If it's a backspace, back up
            else if (InChar == 8)
            {
                if (cwNumChars > 0)
                {
                    cwNumChars--;
                    OEMWriteDebugByte((BYTE)InChar);
                }
            }
        }
    }

	szDottedD[cwNumChars] = '\0';

    // If it's a carriage return with an empty string, don't change anything.
    if (cwNumChars == 3)
    {        
        pEbootCFG->dwCoreFrequency = (100 * (szDottedD[0]-'0'))+ (10 * (szDottedD[1]-'0')) + (szDottedD[2]-'0');
    }
	else if (cwNumChars == 2)
    {        
        pEbootCFG->dwCoreFrequency = (10 * (szDottedD[0]-'0'))+ (szDottedD[1]-'0');
    }
	else if (cwNumChars == 1)
    {        
        pEbootCFG->dwCoreFrequency = (szDottedD[0]-'0');
    }



	cwNumChars = 0;
	InChar = 0;

    EdbgOutputDebugString ( "\r\nEnter new Bus divider (old divider is %d) ",pEbootCFG->dwBusFreqDivider);

    while (!((InChar == 0x0d) || (InChar == 0x0a)))
    {
        InChar = EBOOT_ReadDebugByte();
        if (InChar != OEM_DEBUG_COM_ERROR && InChar != OEM_DEBUG_READ_NODATA)
        {            
            if (InChar == '1' ||InChar == '2' ||InChar == '4')
            {
                if (cwNumChars < 1)
                {
                    szDottedD[cwNumChars++] = (char)InChar;
                    OEMWriteDebugByte((BYTE)InChar);
                }
            }
            // If it's a backspace, back up
            else if (InChar == 8)
            {
                if (cwNumChars > 0)
                {
                    cwNumChars--;
                    OEMWriteDebugByte((BYTE)InChar);
                }
            }
        }
    }

    // If it's a carriage return with an empty string, don't change anything.
    if (cwNumChars)
    {
        szDottedD[cwNumChars] = '\0';
        pEbootCFG->dwBusFreqDivider = szDottedD[0] - '0';
    }

}

//--------------------------------------------------------------------------------
//! \brief Get subnet mask address from debug serial and set it into eboot settings
//!
//! \param pEbootCFG pointer to the structure of eboot settings
//--------------------------------------------------------------------------------
void EBOOT_SetMask(EBOOT_CFG *pEbootCFG)
{
    char szDottedD[16]; // The string used to collect the dotted masks
    WORD cwNumChars = 0;
    UINT16 InChar = 0;

    EdbgOutputDebugString ( "\r\nEnter new subnet mask: ");

    while (!((InChar == 0x0d) || (InChar == 0x0a)))
    {
        InChar = EBOOT_ReadDebugByte();
        if (InChar != OEM_DEBUG_COM_ERROR && InChar != OEM_DEBUG_READ_NODATA)
        {
            // If it's a number or a period, add it to the string
            if (InChar == '.' || (InChar >= '0' && InChar <= '9'))
            {
                if (cwNumChars < 16)
                {
                    szDottedD[cwNumChars++] = (char)InChar;
                    OEMWriteDebugByte((BYTE)InChar);
                }
            }
            // If it's a backspace, back up
            else if (InChar == 8)
            {
                if (cwNumChars > 0)
                {
                    cwNumChars--;
                    OEMWriteDebugByte((BYTE)InChar);
                }
            }
        }
    }

    // If it's a carriage return with an empty string, don't change anything.
    if (cwNumChars)
    {
        szDottedD[cwNumChars] = '\0';
        pEbootCFG->subnetMask = inet_addr( szDottedD );
    }
}

//--------------------------------------------------------------------------------
//! \brief Get mac address from debug serial and set it into eboot settings
//!
//! \param pEbootCFG pointer to the structure of eboot settings
//--------------------------------------------------------------------------------
void EBOOT_SetMacAddress(EBOOT_CFG *pEbootCFG)
{
    char szDottedD[18]; // The string used to collect the dotted masks
    WORD cwNumChars = 0;
    UCHAR InChar = 0;
	DWORD dwNbNumber = 0;
	

    EdbgOutputDebugString ( "\r\nEnter new Mac Address: ");

    while (!((InChar == 0x0d) || (InChar == 0x0a)))
    {
        InChar = EBOOT_ReadDebugByte();
        if (InChar != OEM_DEBUG_COM_ERROR && InChar != OEM_DEBUG_READ_NODATA)
        {
			if (InChar >= 'a' && InChar <= 'f')
			{
				InChar += 'A' - 'a';
			}

            // If it's a number or a period, add it to the string
            if ((cwNumChars<sizeof(szDottedD)-1 ) && ((InChar >= 'A' && InChar <= 'F') || (InChar >= '0' && InChar <= '9')))
            {				
                if (cwNumChars < sizeof(szDottedD))
                {
                    szDottedD[cwNumChars++] = (char)InChar;
                    OEMWriteDebugByte((BYTE)InChar);
                }
				dwNbNumber++;
				if ((dwNbNumber == 2) && (cwNumChars<sizeof(szDottedD)-1))
				{
					dwNbNumber = 0;
					szDottedD[cwNumChars++] = (char)':';
					OEMWriteDebugByte((BYTE)':');
				}
            }
            // If it's a backspace, back up
            else if (InChar == 8)
            {
                if (cwNumChars > 0)
                {					
                    
					cwNumChars--;
					if (dwNbNumber == 0)
					{
						dwNbNumber = 1;
					}
					else
					{
						dwNbNumber--;
					}

					if (szDottedD[cwNumChars] == ':')
					{
						cwNumChars--;
						OEMWriteDebugByte((BYTE)InChar);
						OEMWriteDebugByte((BYTE)' ');
						OEMWriteDebugByte((BYTE)InChar);
					}
					OEMWriteDebugByte((BYTE)InChar);
					OEMWriteDebugByte((BYTE)' ');
					OEMWriteDebugByte((BYTE)InChar);
						
                }
            }
        }
    }

    // If it's a carriage return with an empty string, don't change anything.
    if (cwNumChars == sizeof(szDottedD)-1)
    {
        szDottedD[cwNumChars] = '\0';
		AsciiToMacAddr(pEbootCFG->macAddress,szDottedD);
    }
}

//--------------------------------------------------------------------------------
//! \brief Get number of bootme sent from the serial debug and set it into settings
//!
//! \param pEbootCFG pointer to the structure of eboot settings
//--------------------------------------------------------------------------------
void EBOOT_SetBootMe(EBOOT_CFG *pEbootCFG)
{
    char szCount[16];
    WORD cwNumChars = 0;
    UINT16 InChar = 0;

    EdbgOutputDebugString ( "\r\nUse 0 for continuous boot me packets. \r\n");
    EdbgOutputDebugString ( "Enter maximum number of boot me packets to send [0-255]: ");

    while (!((InChar == 0x0d) || (InChar == 0x0a)))
    {
        InChar = EBOOT_ReadDebugByte();
        if (InChar != OEM_DEBUG_COM_ERROR && InChar != OEM_DEBUG_READ_NODATA)
        {
            // If it's a number or a period, add it to the string
            if ((InChar >= '0' && InChar <= '9'))
            {
                if (cwNumChars < 16)
                {
                    szCount[cwNumChars++] = (char)InChar;
                    OEMWriteDebugByte((BYTE)InChar);
                }
            }
            // If it's a backspace, back up
            else if (InChar == 8)
            {
                if (cwNumChars > 0)
                {
                    cwNumChars--;
                    OEMWriteDebugByte((BYTE)InChar);
                }
            }
        }
    }

    // If it's a carriage return with an empty string, don't change anything.
    if (cwNumChars)
    {
        szCount[cwNumChars] = '\0';
        pEbootCFG->numBootMe = atoi(szCount);
        if (pEbootCFG->numBootMe > 255)
        {
            pEbootCFG->numBootMe = 255;
        }
        else if (pEbootCFG->numBootMe < 0)
        {
            pEbootCFG->numBootMe = 1;
        }
    }
}

//--------------------------------------------------------------------------------
//! \brief Get delay of premenu and set it into eboot settings
//!
//! \param pEbootCFG pointer to the structure of eboot settings
//--------------------------------------------------------------------------------
void EBOOT_SetDelay(EBOOT_CFG *pEbootCFG)
{
    char szCount[16];
    WORD cwNumChars = 0;
    UINT16 InChar = 0;

    EdbgOutputDebugString ( "\r\nEnter maximum number of seconds to delay [0-255]: ");

    while (!((InChar == 0x0d) || (InChar == 0x0a)))
    {
        InChar = EBOOT_ReadDebugByte();
        if (InChar != OEM_DEBUG_COM_ERROR && InChar != OEM_DEBUG_READ_NODATA)
        {
            // If it's a number or a period, add it to the string
            if ((InChar >= '0' && InChar <= '9'))
            {
                if (cwNumChars < 16)
                {
                    szCount[cwNumChars++] = (char)InChar;
                    OEMWriteDebugByte((BYTE)InChar);
                }
            }
            // If it's a backspace, back up
            else if (InChar == 8)
            {
                if (cwNumChars > 0)
                {
                    cwNumChars--;
                    OEMWriteDebugByte((BYTE)InChar);
                }
            }
        }
    }

    // If it's a carriage return with an empty string, don't change anything.
    if (cwNumChars)
    {
        szCount[cwNumChars] = '\0';
        pEbootCFG->delaySec = atoi(szCount);
        if (pEbootCFG->delaySec > 255)
        {
            pEbootCFG->delaySec = 255;
        }
        else if (pEbootCFG->delaySec <= 0)
        {
			RETAILMSG(1,(EMSG_CRLF));
			RETAILMSG(1,(EMSG_MUST_PRESS_SPACE));
			RETAILMSG(1,(EMSG_CRLF));
            pEbootCFG->delaySec = 0;
        }
    }
}

//--------------------------------------------------------------------------------
//! \brief Invert dhcp state
//!
//! \param pEbootCFG pointer to the structure of eboot settings
//--------------------------------------------------------------------------------
void EBOOT_InvertDhcpState(EBOOT_CFG *pEbootCFG)
{
	if (pEbootCFG->dhcpEnable == TRUE)
	{
		pEbootCFG->dhcpEnable = FALSE;
	}
	else
	{
		pEbootCFG->dhcpEnable = TRUE;
	}
}

//--------------------------------------------------------------------------------
//! \brief Invert autodownload state
//!
//! \param pEbootCFG pointer to the structure of eboot settings
//--------------------------------------------------------------------------------
void EBOOT_InvertAutoDownloadState(EBOOT_CFG *pEbootCFG)
{
	if (pEbootCFG->autoDownloadImage == TRUE)
	{
		pEbootCFG->autoDownloadImage = FALSE;
	}
	else
	{
		pEbootCFG->autoDownloadImage = TRUE;
	}
}

//--------------------------------------------------------------------------------
//! \brief Invert imageToFlash state
//!
//! \param pEbootCFG pointer to the structure of eboot settings
//--------------------------------------------------------------------------------
void EBOOT_InvertDownloadImgToFlash(EBOOT_CFG *pEbootCFG)
{
	if (pEbootCFG->bImgToFlash == TRUE)
	{
		pEbootCFG->bImgToFlash = FALSE;
	}
	else
	{
		pEbootCFG->bImgToFlash = TRUE;
	}
}

//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/GenericEBOOT/eboot_cfg.c $
//------------------------------------------------------------------------------

//
//! @}
//
//
//! @}
