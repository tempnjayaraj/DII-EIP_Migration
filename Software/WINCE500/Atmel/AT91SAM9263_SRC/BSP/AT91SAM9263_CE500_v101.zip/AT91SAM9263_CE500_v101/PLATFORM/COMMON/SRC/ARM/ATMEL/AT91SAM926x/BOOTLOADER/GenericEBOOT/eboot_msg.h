//------------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!
//   All rights reserved ADENEO SAS 2005
//!
//------------------------------------------------------------------------------
//! \file		eboot_msg.h
//!
//! Define list of all text writing in Eboot
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/GenericEBOOT/eboot_msg.h $
//!   $Author: ltourlonias $
//!   $Revision: 874 $
//!   $Date: 2007-05-24 09:03:04 +0200 (jeu., 24 mai 2007) $
//! \endif
//------------------------------------------------------------------------------
//! \addtogroup	EBOOT
//! @{

#ifndef EBOOT_MSG_H
#define EBOOT_MSG_H


#define	EMSG_CRLF					L"\r\n"
#define	EMSG_OK						L"OK"
#define	EMSG_FAILED					L"FAILED"
#define	EMSG_BOOTLOADER_START		L"Microsoft Windows CE 5.0 Ethernet Bootloader for the AT91SAM926xEK board \r\nAdaptation performed by ADENEO (c) 2007\r\n"
//#define EMSG_BAD_FIRSTBOOT_CONFIG   L"ERROR : Invalid firstboot settings, please review your firstboot version."
#define	EMSG_SPINFOREVER			L"\n\r\n\rSpinForever ..."

#define EMSG_SERIAL_INIT			L"\r\nDebug serial initialized ........OK \r\n"
#define EMSG_INIT_IMGFLASH			L"Initialize image flash ......."

#define EMSG_LOAD_DEFAULT_EBOOTCONFIG	L"INFO : Loading default bootloader settings"
//#define EMSG_SELECTION_ERROR			L"Invalid selection, please reboot device"
#define EMSG_ERROR_INIT_CRITICAL		L"ERROR : Critical error on initialization"
#define EMSG_WARNING_NO_EBOOTCONFIG		L"WARNING : LoadEBootCFG: No valid Eboot configuration found."
#define EMSG_ERROR_LOADEBOOTCONFIG		L"ERROR : Bootloader setting load failed"
#define EMSG_EBOOTCONFIG_SAVED			L"INFO : Bootloader setting successful saved"
#define EMSG_SAVE_IMGBOOTDESC			L"INFO : Saving new image flash boot description"

#define EMSG_ERROR_WAITFORHOST			L"ERROR : EbootWaitForHostConnect failed !"
#define EMSG_ERROR_NEVER_HERE			L"ERROR : Should never be here..."
#define EMSG_IMG_FLASH_ERASE			L"INFO : Erasing flash ..."
#define EMSG_IMG_FLASH_ERASE_SUCCESS	L"INFO : Flash successfully erased"
#define EMSG_IMG_FLASH_WRITE			L"INFO : writing image in flash"
#define EMSG_IMG_FLASH_WRITE_SUCCESS	L"INFO : Image successfully writed in flash"
#define EMSG_LAUNCHING_IMAGE_AT			L"Launching windows CE image by jumping at address 0x%8x"
#define	EMSG_DOWNLOAD_NOW_OR_CANCEL		L"Press [ENTER] to download now or [SPACE] to cancel."
#define	EMSG_LAUNCH_NOW_OR_CANCEL		L"Press [ENTER] to launch image stored in flash or [SPACE] to cancel."
#define EMSG_MUST_PRESS_SPACE			L"WARNING : You set 0 second of delay, so you must keep space bar pressed at startup to access to menu"
#define EMSG_NO_ETHER_LINK				L"WARNING : No Ethernet link detected... Check the connection !"
#define EMSG_RETRY_ETHER_LINK			L"INFO : Retrying in few seconds. (press <SPACE> or <ENTER> to cancel)"

#define EMSG_EBOOTCONFIG_HEADER			L"Ethernet Boot Loader Configuration :"

#endif  // EBOOT_MSG_H

//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/GenericEBOOT/eboot_msg.h $
//------------------------------------------------------------------------------
//

//
//! @}
//

//
//! @}
//