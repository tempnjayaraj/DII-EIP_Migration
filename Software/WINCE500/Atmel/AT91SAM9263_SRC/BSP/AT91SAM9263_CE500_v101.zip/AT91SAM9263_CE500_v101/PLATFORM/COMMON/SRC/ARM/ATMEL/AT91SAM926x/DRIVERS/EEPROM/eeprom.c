//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
// All rights reserved ADENEO SAS 2005
//!
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/EEPROM/eeprom.c
//!
//! \brief		Driver for a I2C EEPROM
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/EEPROM/eeprom.c $
//!   $Author: jjhiblot $
//!   $Revision: 860 $
//!   $Date: 2007-05-22 10:33:20 +0200 (mar., 22 mai 2007) $
//! \endif
//!
//-----------------------------------------------------------------------------
//! \addtogroup EEPROM
//! @{
//!

// System include
#include <windows.h>
#include <memory.h>
#include <nkintr.h>
#include <devload.h>
#include <ceddk.h>

// Local include
#include "AT91SAM926x_i2c_ioctl.h"
#include "AT91SAM926x.h"

#include "EEPROM_DbgZones.h"
#include "EEPROM.h"

#define EEPROM_WRITE_TIME	20

#define MIN(x,y) ((x)<(y) ? (x):(y))

// The dpCurSettings structure for debug zones
DBGPARAM dpCurSettings =
{
    TEXT("ZonesApp"),
    {
        TEXT("Init"),
        TEXT("DeInit"),
        TEXT("Open"),
        TEXT("Close"),
        TEXT("Read"),
        TEXT("Write"),
        TEXT("Seek"),
        TEXT("IOCtl"),
        TEXT("na"),
        TEXT("na"),
        TEXT("na"),
        TEXT("na"),
        TEXT("na"),
        TEXT("na"),
        TEXT("Warning"),
        TEXT("Error")
    }
    , MASK_INIT | MASK_DEINIT | MASK_INFO | MASK_ERROR
};

extern VOID EEPROM_Reset(VOID);

//-----------------------------------------------------------------------------
//! \fn			BOOL WINAPI DllEntry( HANDLE hinstDLL, DWORD dwReason, LPVOID lpvReserved)
//!
//! \brief		This function is the entry point of the Dll driver
//!
//! \param		hinstDLL	DLL instance
//! \param		dwReason	Reason of the call
//! \param		lpvReserved	Not used
//!
//! \return		\e TRUE when all is good
//!	\return		\e FALSE when all is bad
//!
//! This function intialize debug zone when called with the DLL_PROCESS_ATTACH reason
//-----------------------------------------------------------------------------
BOOL WINAPI DllEntry(HANDLE hinstDLL, DWORD dwReason, LPVOID lpvReserved)
{
    switch(dwReason)
    {
    case DLL_PROCESS_ATTACH:
        DEBUGREGISTER((HMODULE)hinstDLL);
        DEBUGMSG(ZONE_INFO,(TEXT("MYDRIVER: DLL_PROCESS_ATTACH\n")));
   	break;
    case DLL_THREAD_ATTACH:
        DEBUGMSG(ZONE_INFO,(TEXT("MYDRIVER: DLL_THREAD_ATTACH\n")));
        break;
    case DLL_THREAD_DETACH:
        DEBUGMSG(ZONE_INFO,(TEXT("MYDRIVER: DLL_THREAD_DETACH\n")));
        break;
    case DLL_PROCESS_DETACH:
        DEBUGMSG(ZONE_INFO,(TEXT("MYDRIVER: DLL_PROCESS_DETACH\n")));
        break;
#ifdef UNDER_CE
    case DLL_PROCESS_EXITING:
        DEBUGMSG(ZONE_INFO,(TEXT("MYDRIVER: DLL_PROCESS_EXITING\n")));
        break;
    case DLL_SYSTEM_STARTED:
        DEBUGMSG(ZONE_INFO,(TEXT("MYDRIVER: DLL_SYSTEM_STARTED\n")));
        break;
#endif
    }

    return TRUE;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL InitEEPROM(T_EEPROMINIT_STRUCTURE *pDeviceContext)
//!
//! \brief		This function initializes the EEPROM memory
//!
//! \param		pDeviceContext	Pointer to the device context.
//!
//! \return		True in success, False else
//!
//-----------------------------------------------------------------------------
BOOL InitEEPROM(T_EEPROMINIT_STRUCTURE *pDeviceContext)
{
	pDeviceContext->hI2CDevice = CreateFile (pDeviceContext->I2CDeviceName, // Pointer to the name of the port
				  GENERIC_READ | GENERIC_WRITE,
								// Access (read-write) mode
				  FILE_SHARE_READ | FILE_SHARE_WRITE,            // Share mode
				  NULL,         // Pointer to the security attribute
				  OPEN_EXISTING,// How to open the serial port
				  0,            // Port attributes
				  NULL);        

	if (pDeviceContext == INVALID_HANDLE_VALUE)
	{
		RETAILMSG(1,(TEXT("InitEEPROM : Unable to open I2C driver\r\n")));
		return FALSE;
	}

	return TRUE;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL DeinitEEPROM(T_EEPROMINIT_STRUCTURE *pDeviceContext)
//!
//! \brief		This function deinitializes the EEPROM memory
//!
//! \param		pDeviceContext	Pointer to the device context.
//!
//! \return		True in success, False else
//!
//-----------------------------------------------------------------------------
BOOL DeinitEEPROM(T_EEPROMINIT_STRUCTURE *pDeviceContext)
{
	CloseHandle(pDeviceContext->hI2CDevice);
	return TRUE;
}

//-----------------------------------------------------------------------------
//! \fn			void ResetEEPROM(T_EEPROMINIT_STRUCTURE *pDeviceContext)
//!
//! \brief		This function resets the EEPROM memory
//!
//! \param		pDeviceContext	Pointer to the device context.
//!
//-----------------------------------------------------------------------------
void ResetEEPROM(T_EEPROMINIT_STRUCTURE *pDeviceContext)
{
	RETAILMSG(1,(L"Reseting EEPROM"));
	if (!DeviceIoControl(pDeviceContext->hI2CDevice, IOCTL_I2C_LOCK,NULL, 0, NULL, 0, NULL, NULL))
	{
		RETAILMSG(1,(L"ResetEEPROM: IOCTL_I2C_LOCK failed"));
	}
	else
	{	
		EEPROM_Reset();

		if (!DeviceIoControl(pDeviceContext->hI2CDevice, IOCTL_I2C_UNLOCK,NULL, 0, NULL, 0, NULL, NULL))
		{
			RETAILMSG(1,(L"ResetEEPROM: IOCTL_I2C_UNLOCK failed"));
		}
	}
}

#define NB_RETRY_BEFORE_EEPROM_RESET		3
#define NB_RETRY_BEFORE_FAILURE			(NB_RETRY_BEFORE_EEPROM_RESET + 3)

//-----------------------------------------------------------------------------
//! \fn			BOOL ReadEEPROM(T_EEPROMINIT_STRUCTURE *pDeviceContext, DWORD dwOffset, UCHAR* pBuffer, DWORD dwCount)
//!
//! \brief		This function does a reading operation in EEPROM
//!
//! \param		pDeviceContext	Pointer to the device context.
//! \param		dwOffset		Offset
//! \param		pBuffer		Pointer to the buffer which receives data
//! \param		dwCount		Size of data
//!
//! \return		True in success, False else
//!
//-----------------------------------------------------------------------------
BOOL ReadEEPROM(T_EEPROMINIT_STRUCTURE *pDeviceContext, DWORD dwOffset, UCHAR* pBuffer, DWORD dwCount)
{
	BOOL bResult;
	DWORD dwRead;
	DWORD dwNbTry;
	T_I2CIOCTL_READ sRead;

	sRead.dwDeviceAddr = pDeviceContext->dwI2CAddr;
	sRead.dwRegAddress = dwOffset;
	sRead.eAddressSize = TWO_BYTE_IADR;
	sRead.bDisableInterrupt = TRUE;

	dwNbTry = 0;
		
	do
	{
		dwNbTry++;
		if (!DeviceIoControl(pDeviceContext->hI2CDevice, IOCTL_I2C_READ,&sRead, sizeof(sRead), pBuffer, dwCount, &dwRead, NULL))
		{
			RETAILMSG(1,(L"ReadEEPROM: IOCTL_I2C_READ failed"));
			bResult = FALSE;
			if (dwNbTry == NB_RETRY_BEFORE_EEPROM_RESET)
			{				
				ResetEEPROM(pDeviceContext);
			}
		}	
		else
		{
			bResult = TRUE;			
		}		
	} while ((bResult == FALSE) && (dwNbTry < NB_RETRY_BEFORE_FAILURE));

	return bResult;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL WriteEEPROM(T_EEPROMINIT_STRUCTURE *pDeviceContext, DWORD dwOffset,UCHAR* pBuffer, DWORD dwCount)
//!
//! \brief		This function does a writing operation in EEPROM
//!
//! \param		pDeviceContext	Pointer to the device context.
//! \param		dwOffset		Offset
//! \param		pBuffer		Pointer to the buffer which stores data
//! \param		dwCount		Size of buffer
//!
//! \return		True in success, False else
//!
//-----------------------------------------------------------------------------
BOOL WriteEEPROM(T_EEPROMINIT_STRUCTURE *pDeviceContext, DWORD dwOffset,UCHAR* pBuffer, DWORD dwCount)
{
	T_I2CIOCTL_WRITE sWrite;
	DWORD dwWritten;
	DWORD dwNbTry;
	BOOL bResult;
	
	sWrite.dwDeviceAddr = pDeviceContext->dwI2CAddr;
	sWrite.dwRegAddress = dwOffset;
	sWrite.eAddressSize = TWO_BYTE_IADR;
	sWrite.dwBufferSize = dwCount;
	sWrite.bDisableInterrupt = TRUE;
	sWrite.pBuffer = pBuffer;

	dwNbTry = 0;
		
	do
	{
		dwNbTry++;
		if (!DeviceIoControl(pDeviceContext->hI2CDevice, IOCTL_I2C_WRITE,&sWrite, sizeof(sWrite), NULL, 0, &dwWritten, NULL))
		{
			RETAILMSG(1,(L"WriteEEPROM: IOCTL_I2C_WRITE failed"));
			Sleep(20);
			bResult = FALSE;
			if (dwNbTry == NB_RETRY_BEFORE_EEPROM_RESET)
			{				
				ResetEEPROM(pDeviceContext);
			}
		}	
		else
		{
			bResult = TRUE;			
		}		
	} while ((bResult == FALSE) && (dwNbTry < NB_RETRY_BEFORE_FAILURE));

	return bResult;
	
}


//-----------------------------------------------------------------------------
//! \fn			DWORD EEP_Init(LPCTSTR pContext, LPCVOID lpvBusContext)
//!
//! \brief		This function initializes the device.
//!
//! \param		pContext		Pointer to a string containing the registry path to the active key for the stream interface driver.
//! \param		lpvBusContext	Potentially process-mapped pointer passed as the 
//!								fourth parameter to ActivateDeviceEx. If this driver 
//!								was loaded through legacy mechanisms, then lpvBusContext 
//!								is zero. This pointer, if used, has only been mapped 
//!								again as it passes through the protected server library (PSL).
//!								The <b>EEP_Init</b> function is responsible for performing all protection 
//!								checking. In addition, any pointers referenced through lpvBusContext 
//!								must be remapped with the <b>MapCallerPtr</b> function before they 
//!								can be dereferenced.
//!
//! \return		Returns a handle to the device context created if successful. 
//!	\return		\e zero if not successful.
//!
//! Device Manager calls this function as a result of a call to the ActivateDeviceEx 
//! function. When the user starts using a device, such as inserting a PC Card, 
//! Device Manager calls this function to initialize the device. Applications do not call this function. 
//-----------------------------------------------------------------------------
DWORD EEP_Init(LPCTSTR pContext, LPCVOID lpvBusContext)
{	
	DWORD dwType,dwSize;		
	HKEY hKey;

	T_EEPROMINIT_STRUCTURE *pDeviceContext = (T_EEPROMINIT_STRUCTURE *)LocalAlloc(LMEM_ZEROINIT|LMEM_FIXED, sizeof(T_EEPROMINIT_STRUCTURE));

	if (pDeviceContext == NULL)
	{
		return 0;
	}

	InitializeCriticalSection(&pDeviceContext->cs);


	pDeviceContext->dwOpenCount = 0;


	hKey = OpenDeviceKey(pContext);
	if (hKey == NULL)
	{
		goto InitError;
	}
	
	dwSize = sizeof(pDeviceContext->I2CDeviceName);
	if (ERROR_SUCCESS != RegQueryValueEx(hKey,L"I2CDevice",NULL,&dwType,(LPBYTE)pDeviceContext->I2CDeviceName,&dwSize))
	{
		goto InitError;
	}

	dwSize = sizeof(pDeviceContext->dwI2CAddr);
	if (ERROR_SUCCESS != RegQueryValueEx(hKey,L"I2CAddr",NULL,&dwType,(LPBYTE)&pDeviceContext->dwI2CAddr,&dwSize))
	{
		goto InitError;
	}

	dwSize = sizeof(pDeviceContext->dwPageSize);
	if (ERROR_SUCCESS != RegQueryValueEx(hKey,L"PageSize",NULL,&dwType,(LPBYTE)&pDeviceContext->dwPageSize,&dwSize))
	{
		goto InitError;
	}

	dwSize = sizeof(pDeviceContext->dwTotalSize);
	if (ERROR_SUCCESS != RegQueryValueEx(hKey,L"TotalSize",NULL,&dwType,(LPBYTE)&pDeviceContext->dwTotalSize,&dwSize))
	{
		goto InitError;
	}

	RegCloseKey(hKey);


	InitEEPROM(pDeviceContext);
	
	pDeviceContext->dwLastWriteTime = 0;

	return (DWORD)pDeviceContext;

InitError:

	
	if (hKey)
	{
		RegCloseKey(hKey);
	}
	if (pDeviceContext)
	{
		LocalFree(pDeviceContext);
		pDeviceContext = NULL;
	}
	
	return (DWORD)NULL;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL EEP_Deinit(T_EEPROMINIT_STRUCTURE *pDeviceContext)
//!
//! \brief		This function uninitializes the device.
//!
//! \param		pDeviceContext	Pointer to the the device init context. The EEP_Init (Device Manager)
//!								function creates and returns this pointer.
//!
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//!
//! When the user stops using a device, such as when a PC Card is removed from its socket, 
//! Device Manager calls this function. Applications do not call this function. Device Manager 
//! calls the EEP_Deinit driver function as a result of a call to the DeactivateDevice function. 
//! Your stream interface driver should free any resources it has allocated, and then terminate.
//-----------------------------------------------------------------------------
BOOL EEP_Deinit(T_EEPROMINIT_STRUCTURE *pDeviceContext)
{
	BOOL bRet = TRUE;

	
	if (pDeviceContext != NULL)
	{
		// All devices have to be unloaded before deinitialising the driver
		if (pDeviceContext->dwOpenCount != 0)
		{
			bRet = FALSE;
		}
		else
		{
			DeleteCriticalSection(&pDeviceContext->cs);
			
			DeinitEEPROM(pDeviceContext);

			// Free allocated memory
			if (LocalFree(pDeviceContext) != NULL)
			{
				bRet = FALSE;
			}
		}

	}

	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn			DWORD EEP_Open(T_EEPROMINIT_STRUCTURE *pDeviceContext, DWORD AccessCode, DWORD ShareMode)
//!
//! \brief		This function opens a device for reading, writing, or both.
//!
//! \param		pDeviceContext	Pointer to the the device open context. The <b>EEP_Init</b> (Device Manager)
//!								function creates and returns this identifier.
//! \param		AccessCode		Access code for the device. The access is a combination
//!								of read and write access from <b>CreateFile</b>. 
//! \param		ShareMode		File share mode of the device. The share mode is a combination 
//!								of read and write access sharing from <b>CreateFile</b>. 
//!
//! \return		This function returns a handle that identifies the open context of the device 
//!				to the calling application. If your device can be opened multiple times, use 
//!				this handle to identify each open context.
//!
//! When this function executes, your device should allocate the resources that it needs for 
//! each open context and prepare for operation. This might involve preparing the device for 
//! reading or writing and initializing data structures it uses for operation.
//-----------------------------------------------------------------------------
DWORD EEP_Open(T_EEPROMINIT_STRUCTURE *pDeviceContext, DWORD AccessCode, DWORD ShareMode)
{
	T_EEPROMOPEN_STRUCTURE *pOpenContext = (T_EEPROMOPEN_STRUCTURE*)LocalAlloc(LMEM_ZEROINIT|LMEM_FIXED, sizeof(T_EEPROMOPEN_STRUCTURE));
	
	// Store device settings for futur use
	pOpenContext->pDeviceContext = pDeviceContext;
	pOpenContext->dwAccessCode = AccessCode;
	pOpenContext->dwShareMode = ShareMode;
	
	
	// Increase opened device counter
	pOpenContext->pDeviceContext->dwOpenCount++;	

	return (DWORD)pOpenContext;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL EEP_Close(T_EEPROMOPEN_STRUCTURE *pOpenContext)
//!
//! \brief		This function closes a device context created by the pOpenContext parameter.
//!
//! \param		pOpenContext	Pointer returned by the <b>EEP_Open</b> (Device Manager) function, 
//!								which is used to identify the open context of the device. 
//!
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//!
//! An application calls the CloseHandle function to stop using a stream interface driver. 
//! The hFile parameter specifies the handle associated with the device context. In response
//! to <b>CloseHandle</b>, the operating system invokes <b>EEP_Close</b>.
//-----------------------------------------------------------------------------
BOOL EEP_Close(T_EEPROMOPEN_STRUCTURE *pOpenContext)
{
	BOOL bRet = TRUE;
	
	if (pOpenContext != NULL)
	{
		T_EEPROMINIT_STRUCTURE *pDeviceContext = pOpenContext->pDeviceContext;

		// Free memory
		if (LocalFree(pOpenContext) != NULL)
		{
			bRet = FALSE;
		}
		else
		{
			// Decrease opened device counter
			pDeviceContext->dwOpenCount --;
		}
	}

	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn			DWORD EEP_Read(T_EEPROMOPEN_STRUCTURE *pOpenContext, LPVOID pBuffer, DWORD dwCount)
//!
//! \brief		This function reads data from the device identified by the open context.
//!
//! \param		pOpenContext	Handle to the open context of the device. The <b>EEP_Open</b> 
//!								(Device Manager) function creates and returns this identifier.  
//! \param		pBuffer			Pointer to the buffer that stores the data read from 
//!								the device. This buffer should be at least <i>Count</i> bytes long. 
//! \param		dwCount			Number of bytes to read from the device into <i>pBuffer</i>.
//!
//! \return		\e zero to indicate <i>end-of-file</i>. 
//! \return		\e -1 to indicate an error. 
//! \return		The number of bytes read to indicate success.
//!
//! After an application calls the ReadFile function to read from the device, the operating system
//! invokes this function. The <i>hFile</i> parameter is a handle to the device. The <i>pBuffer</i> parameter 
//! points to the buffer that contains the data read from the device. The <i>dwCount</i> parameter indicates 
//! the number of bytes that the application requests to read from the device.
//-----------------------------------------------------------------------------
DWORD EEP_Read(T_EEPROMOPEN_STRUCTURE *pOpenContext, LPVOID pBuffer, DWORD dwCount)
{	
	UCHAR* pTemp;
	DWORD dwCurrentOffset,dwToRead,dwRemaining;
	BOOL bError = FALSE;
	// At least a device have to be opened
	if (pOpenContext == NULL || !pOpenContext->pDeviceContext->dwOpenCount)
		return -1;

	// The device have to be readable
	if (! (pOpenContext->dwAccessCode & GENERIC_READ))
		return -1;

	if (dwCount == 0)
	{
		return 0;
	}
	
	
	EnterCriticalSection(&pOpenContext->pDeviceContext->cs);
	
	// Clip the number of byte to read t  the content of the EEPROM
	if (dwCount +  pOpenContext->dwCurrentOffset >= pOpenContext->pDeviceContext->dwTotalSize)
	{
		dwCount = pOpenContext->pDeviceContext->dwTotalSize - pOpenContext->dwCurrentOffset - 1;
	}


	dwToRead = MIN(dwCount,pOpenContext->pDeviceContext->dwPageSize - (pOpenContext->dwCurrentOffset % pOpenContext->pDeviceContext->dwPageSize));
	dwRemaining = dwCount;
	dwCurrentOffset = pOpenContext->dwCurrentOffset;
	pTemp = pBuffer;
	while (dwRemaining)
	{
		DWORD dwElapsedSinceLastWrite = (INT32) (GetTickCount() - pOpenContext->pDeviceContext->dwLastWriteTime);
		if (dwElapsedSinceLastWrite < EEPROM_WRITE_TIME)
		{
			Sleep(MIN(EEPROM_WRITE_TIME,EEPROM_WRITE_TIME-dwElapsedSinceLastWrite));
		}
		//RETAILMSG(1,(TEXT("read (last %d / elapsed %d)\r\n"),pOpenContext->pDeviceContext->dwLastWriteTime,dwElapsedSinceLastWrite));
		if (ReadEEPROM(pOpenContext->pDeviceContext,dwCurrentOffset,pTemp,dwToRead) == FALSE)
		{
			bError = TRUE;
			break;
		}
		dwRemaining -= dwToRead;
		dwCurrentOffset += dwToRead;
		pTemp += dwToRead;
		dwToRead = MIN(dwRemaining,pOpenContext->pDeviceContext->dwPageSize);
	}
	
	if (bError == FALSE)
	{
		pOpenContext->dwCurrentOffset = dwCurrentOffset;
		LeaveCriticalSection(&pOpenContext->pDeviceContext->cs);
		return dwCount - dwRemaining;
	}
	else
	{		
		LeaveCriticalSection(&pOpenContext->pDeviceContext->cs);
		return -1;
	}
}


//-----------------------------------------------------------------------------
//! \fn			DWORD EEP_Write(T_EEPROMOPEN_STRUCTURE *pOpenContext, LPCVOID pBuffer, DWORD dwCount)
//!
//! \brief		This function writes data to the device.
//!
//! \param		pOpenContext	Handle to the open context of the device. The <b>EEP_Open</b> 
//!								(Device Manager) function creates and returns this identifier.  
//! \param		pBuffer			Pointer to the buffer that contains the data to write. 
//!								This buffer should be at least <i>Count</i> bytes long. 
//! \param		dwCount			Number of bytes to write from the <i>pBuffer</i> buffer into the device.
//!
//! \return		The number of bytes  written indicates success
//! \return		\e -1 to indicate an error. 
//!
//! After an application uses the WriteFile function to write to the device, the operating system, 
//! invokes this function. The <i>hFile</i> parameter is a handle to the device. The <i>pBuffer</i> parameter 
//! points to the buffer that contains the data read from the device. The <i>dwCount</i> parameter indicates 
//! the number of bytes that the application requests to write to the device.
//-----------------------------------------------------------------------------
DWORD EEP_Write(T_EEPROMOPEN_STRUCTURE *pOpenContext, LPCVOID pBuffer, DWORD dwCount)
{		
	UCHAR compBuffer[1024];

	UCHAR* pTemp;
	DWORD dwToWrite,dwCurrentOffset,dwRemaining;
	BOOL bError = FALSE;
	
	// At least a device have to be opened
	if (pOpenContext == NULL || !pOpenContext->pDeviceContext->dwOpenCount)
		return -1;

	// The device have to be readable
	if (! (pOpenContext->dwAccessCode & GENERIC_WRITE))
		return -1;


	if (dwCount == 0)
	{
		return 0;
	}
	
	
	EnterCriticalSection(&pOpenContext->pDeviceContext->cs);
	
	// Clip the number of byte to read t  the content of the EEPROM
	if (dwCount +  pOpenContext->dwCurrentOffset >= pOpenContext->pDeviceContext->dwTotalSize)
	{
		dwCount = pOpenContext->pDeviceContext->dwTotalSize - pOpenContext->dwCurrentOffset - 1;
	}


	dwToWrite = MIN(dwCount,pOpenContext->pDeviceContext->dwPageSize - (pOpenContext->dwCurrentOffset % pOpenContext->pDeviceContext->dwPageSize));
	dwRemaining = dwCount;
	
	dwCurrentOffset = pOpenContext->dwCurrentOffset;
	pTemp = (UCHAR*) pBuffer;
	while (dwRemaining)
	{
		
		DWORD dwElapsedSinceLastWrite = (INT32) (GetTickCount() - pOpenContext->pDeviceContext->dwLastWriteTime);
		if (dwElapsedSinceLastWrite < EEPROM_WRITE_TIME)
		{
			Sleep(MIN(EEPROM_WRITE_TIME,EEPROM_WRITE_TIME-dwElapsedSinceLastWrite));
		}
		//RETAILMSG(1,(TEXT("write (last %d / elapsed %d)\r\n"),pOpenContext->pDeviceContext->dwLastWriteTime,dwElapsedSinceLastWrite));
		
		if (WriteEEPROM(pOpenContext->pDeviceContext,dwCurrentOffset,pTemp,dwToWrite) == FALSE)
		{					
			bError = TRUE;
			pOpenContext->pDeviceContext->dwLastWriteTime = GetTickCount();
			break;
		}
		
		Sleep(EEPROM_WRITE_TIME);

		if (ReadEEPROM(pOpenContext->pDeviceContext,dwCurrentOffset,compBuffer,dwToWrite) == FALSE)
		{			
		}
		else
		{
			if (memcmp(compBuffer,pTemp,dwToWrite))
			{				
				bError = TRUE;			
				break;				
			}
		}
		

		pOpenContext->pDeviceContext->dwLastWriteTime = GetTickCount();		
		dwRemaining -= dwToWrite;
		dwCurrentOffset += dwToWrite;
		pTemp += dwToWrite;
		dwToWrite = MIN(dwRemaining,pOpenContext->pDeviceContext->dwPageSize);
	}
	

	if (bError == FALSE)
	{
		pOpenContext->dwCurrentOffset = dwCurrentOffset;
		LeaveCriticalSection(&pOpenContext->pDeviceContext->cs);
		return dwCount - dwRemaining;
	}
	else
	{		
		LeaveCriticalSection(&pOpenContext->pDeviceContext->cs);
		return -1;
	}
	

}


//-----------------------------------------------------------------------------
//! \fn			DWORD EEP_Seek(T_EEPROMOPEN_STRUCTURE *pOpenContext, long Amount, WORD wType)
//!
//! \brief		This function moves the data pointer in the device.
//!
//! \param		pOpenContext	Handle to the open context of the device. The <b>EEP_Open</b> 
//!								(Device Manager) function creates and returns this identifier.  
//! \param		Amount			Number of bytes to move the data pointer in the device. A positive value 
//!								moves the data pointer toward the end of the file and a negative value 
//!								moves it toward the beginning.
//! \param		wType			Starting point for the data pointer. The following table shows the available values for this parameter.
//!
//! \return		The new data pointer for the device indicates success.
//! \return		\e -1 to indicate an error. 
//!
//! After an application calls the SetFilePointer function to move the data pointer in the device, 
//! the operating system invokes this function. If your device is capable of opening more than once, 
//! this function modifies only the data pointer for the instance specified by <i>pOpenContext</i>.
//-----------------------------------------------------------------------------
DWORD EEP_Seek(T_EEPROMOPEN_STRUCTURE *pOpenContext, long Amount, WORD wType)
{
	DWORD dwDataSeek = -1;
	long  lNewPos;

	// At least a device have to be opened
	if (pOpenContext == NULL || !pOpenContext->pDeviceContext->dwOpenCount)
		return -1;

	EnterCriticalSection(&pOpenContext->pDeviceContext->cs);
	
	switch (wType)
	{
	case FILE_BEGIN:
		lNewPos = Amount;
		break;
	case FILE_CURRENT:
		lNewPos = pOpenContext->dwCurrentOffset + Amount;
		break;
	case FILE_END:
		lNewPos = pOpenContext->pDeviceContext->dwTotalSize + Amount;
		break;
	default:
		lNewPos = -1;
		break;
	}
	if ((lNewPos>=0) && (lNewPos<(long)pOpenContext->pDeviceContext->dwTotalSize))
	{
		pOpenContext->dwCurrentOffset = lNewPos;
		dwDataSeek = lNewPos;
	}

	LeaveCriticalSection(&pOpenContext->pDeviceContext->cs);
	return dwDataSeek;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL EEP_IOControl(T_EEPROMOPEN_STRUCTURE *pOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut)
//!
//! \brief		This function sends a command to a device.
//!
//! \param		pOpenContext	Handle to the open context of the device. The <b>EEP_Open</b> 
//!								(Device Manager) function creates and returns this identifier.  
//! \param		dwCode			I/O control operation to perform. These codes are device-specific and 
//!								are usually exposed to developers through a header file. 
//!								Use <b>CTL_CODE</b> macro to generate a driver unique identifier for your iocontrol.
//! \param		pBufIn			Pointer to the buffer containing data to transfer to the device. 
//! \param		dwLenIn			Number of bytes of data in the buffer specified for <i>pBufIn</i>.
//! \param		pBufOut			Pointer to the buffer used to transfer the output data from the device.
//! \param		dwLenOut		Maximum number of bytes in the buffer specified by <i>pBufOut</i>.
//! \param		pdwActualOut	Pointer to the <b>DWORD</b> buffer that this function uses to 
//!								return the actual number of bytes received from the device. 
//!
//! \return		\e TRUE indicates success.
//! \return		\e FALSE indicates failure.
//!
//! An application uses the DeviceIoControl function to specify an operation to perform. The operating system,
//! in turn, invokes the <b>EEP_IOControl</b> function. The <i>dwCode</i> parameter contains the input or output 
//! operation to perform; these codes are usually specific to each device driver and are exposed to application 
//! programmers through a header file that the device driver developer makes available.
//-----------------------------------------------------------------------------
BOOL EEP_IOControl(T_EEPROMOPEN_STRUCTURE *pOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut)
{
	BOOL bRet = TRUE;

	// At least a device have to be opened
	if (pOpenContext == NULL || !pOpenContext->pDeviceContext->dwOpenCount)
		return FALSE;

	switch (dwCode)
	{
		default:
			bRet = FALSE;
	}

	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn			void EEP_PowerDown(T_EEPROMINIT_STRUCTURE *pDeviceContext)
//!
//! \brief		This function suspends power to the device. It is useful only with devices that can 
//!				power down under software control. Such devices are typically, but not exclusively, PC Cards.
//!
//! \param		pDeviceContext	Pointer to the device context. The call to the <b>EEP_Init</b> 
//!								(Device Manager) function returns this identifier.  
//!
//!
//!
//! The OS invokes this function to suspend power to a device.
//-----------------------------------------------------------------------------
void EEP_PowerDown(T_EEPROMINIT_STRUCTURE *pDeviceContext)
{

}


//-----------------------------------------------------------------------------
//! \fn			void EEP_PowerUp(T_EEPROMINIT_STRUCTURE *pDeviceContext)
//!
//! \brief		This function restores power to a device.
//!
//! \param		pDeviceContext	Pointer to the device context. The call to the <b>EEP_Init</b> 
//!								(Device Manager) function returns this identifier.  
//!
//!
//!
//! The OS invokes this function to restore power to a device.
//-----------------------------------------------------------------------------
void EEP_PowerUp(T_EEPROMINIT_STRUCTURE *pDeviceContext)
{

}


// End of Doxygen group EEPROM
//! @}
//-----------------------------------------------------------------------------
// End of $RCSfile: $
//-----------------------------------------------------------------------------
//
// Historique : $Log: $
// Historique : 
//! @}
