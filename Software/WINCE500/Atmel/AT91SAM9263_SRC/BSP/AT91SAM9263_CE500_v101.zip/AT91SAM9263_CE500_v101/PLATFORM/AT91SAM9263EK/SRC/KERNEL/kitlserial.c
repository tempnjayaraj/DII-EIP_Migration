//-----------------------------------------------------------------------------
//! \addtogroup	KITL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		kitlserial.c
//!
//! \brief		This module provides the OAL functions for supporting a
//!          serial tranport for KITL.
//!
//! \remark		To make KITL use serial transport instead of ethernet transport, define
//!		  the environment variable "OAL_USE_KITL_SERIAL"
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK60/PLATFORM/AT91SAM9263EK/SRC/KITL/kitlserial.c $
//!   $Author: amlimonet $
//!   $Revision: 889 $
//!   $Date: 2007-05-28 10:42:57 +0200 (lun., 28 mai 2007) $
//! \endif
//-----------------------------------------------------------------------------

//! \addtogroup	KITLSERIAL
//! @{

//-----------------------------------------------------------------------------
// INCLUDE FILES
//-----------------------------------------------------------------------------
#include <windows.h>
#include <nkintr.h>
#include <oal.h>
#include "AT91SAM9263EK.h"
#include "AT91SAM9263.h"

//-----------------------------------------------------------------------------
// EXTERNAL FUNCTIONS
//-----------------------------------------------------------------------------
#include <windows.h>
#include <oal.h>
#include <nkintr.h>
//-----------------------------------------------------------------------------
// GLOBAL DEFINITIONS
//-----------------------------------------------------------------------------
#define DBGU_TXFIFO_DEPTH	1
#define DBGU_BAUDRATE	(115200)
//-----------------------------------------------------------------------------
// GLOBAL VARIABLES
//-----------------------------------------------------------------------------
static AT91PS_DBGU g_pDBGU;
//-----------------------------------------------------------------------------
// STATIC FUNCTIONS
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
//! \fn			  BOOL SerialInit(KITL_SERIAL_INFO *pSerInfo)
//!
//! \brief		This function initializes the interal UART with the specified communication settings.
//!
//! \param		pSerInfo : Pointer to KITL_SERIAL_INFO structure that contains
//!     information about how to initialize the serial KITL transport.
//!
//!	\return		TRUE indicates success
//!	\return		FALSE indicates success
//-----------------------------------------------------------------------------
BOOL SerialInit(KITL_SERIAL_INFO *pSerInfo)
{

    BOOL bRet = TRUE;

	// Get pointer to peripheral base
    g_pDBGU = (AT91PS_DBGU) OALPAtoVA((UINT32)AT91C_BASE_DBGU,FALSE);
    if (g_pDBGU == NULL) return FALSE;

    // Tell KITL upper layers that optimal tranfer size is TXFIFO size
    pSerInfo->bestSize = DBGU_TXFIFO_DEPTH;

    return bRet;
}


//-----------------------------------------------------------------------------
//! \fn			  VOID SerialDeinit(void)
//!
//! \brief		This function deinitializes the internal UART previously configured with SerialInit.
//!
//!
//!
//!
//-----------------------------------------------------------------------------
VOID SerialDeinit(void)
{
}

//-----------------------------------------------------------------------------
//! \fn			  UINT16 SerialRecv(UINT8 *pData, UINT16 size)
//!
//! \brief		This function pointer reads data from the KITL serial device.
//!
//! \param		pData Pointer to the packet data read from the KITL serial device.
//! \param		size Best size of the data to read from the serial device, in bytes.
//!
//!	\return		Returns the number of bytes read.
//-----------------------------------------------------------------------------
UINT16 SerialRecv(UINT8 *pData, UINT16 size)
{    
    UINT8 urxd;
    USHORT cbRead = 0;
	// read until buffer size is reached or an error occurs
    for(cbRead = 0; cbRead < size; cbRead++)
    {         
		if(g_pDBGU == NULL)
        {
			KITLOutputDebugString("KitlSerialRecvRaw:  receive error\n");
            cbRead= 0;
            break;
        }
        if (!(g_pDBGU->DBGU_CSR & AT91C_US_RXRDY)) //Did we receive at least one byte ?
		{
			cbRead = 0;
			break;
		}
        // read char from FIFO
        urxd = g_pDBGU->DBGU_RHR & 0xff;

        // If error detected in current character
        if (g_pDBGU->DBGU_CSR & AT91C_US_PARE)
        {
			KITLOutputDebugString("KitlSerialRecvRaw:  receive error\n");
            cbRead= 0;
            break;
        }
        
        // Place read char into buffer
        *(pData + cbRead) = urxd;
    }
    // If we ready any characters successfully, return TRUE
    if (cbRead > 0) return cbRead;

    return FALSE;
}

//-----------------------------------------------------------------------------
//! \fn			  UINT16 SerialSend(UINT8 *pData, UINT16 size)
//!
//! \brief		This function pointer sends data to the KITL serial device.
//!
//! \param		pData Pointer to the data to send to the serial device driver.
//! \param		size Size of the data specified in pData, in bytes.
//!
//!	\return		Returns 0 on success
//-----------------------------------------------------------------------------
UINT16 SerialSend(UINT8 *pData, UINT16 size)
{
	UINT16 cbWrite = 0;

	// Block until send is complete; no timeout
    for(cbWrite=0;cbWrite<size;cbWrite++)
    {
        // Wait until there is room in the FIFO
        while(!(g_pDBGU->DBGU_CSR & AT91C_US_TXRDY));
        // Write character to port
        g_pDBGU->DBGU_THR = *(pData + cbWrite);
    }
    return	cbWrite;
}

//-----------------------------------------------------------------------------
//! \fn			  VOID SerialSendComplete(UINT16 size)
//!
//! \brief		This function pointer is called when all packets have been sent to the serial device driver
//!
//! \param		size Total packet size of the data sent to the serial device driver.
//!
//!
//-----------------------------------------------------------------------------
VOID SerialSendComplete(UINT16 size)
{
}

//-----------------------------------------------------------------------------
//! \fn			  VOID SerialEnableInts(void)
//!
//! \brief		This function pointer enables the KITL transport interrupts if the transport is interrupt-based.
//!
//!
//!
//!
//-----------------------------------------------------------------------------
VOID SerialEnableInts(void)
{
}

//-----------------------------------------------------------------------------
//! \fn			  VOID SerialDisableInts(void)
//!
//! \brief		This function disables serial interrupts used for the KITL transport.
//!
//!
//!
//!
//-----------------------------------------------------------------------------
VOID SerialDisableInts(void)
{
}

//! @} end of subgroup KITLSERIAL

//! @} end of group KITL
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK60/PLATFORM/AT91SAM9263EK/SRC/KITL/kitlserial.c $
//-----------------------------------------------------------------------------
