//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x_usbfn_endpoint_in.h
//!
//! \brief		declaration for the IN endpoint
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/USBFN/AT91SAM926x_usbfn_endpoint_IN.h $
//!   $Author: pblanchard $
//!   $Revision: 984 $
//!   $Date: 2007-06-11 09:19:22 -0700 (Mon, 11 Jun 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	USBFN
//! @{
//!

#include <csync.h>
#include <cmthread.h>
//#include <CRegEdit.h>
#include <CRefCon.h>
#include <usbfn.h>

class AT91SAMEndpoint;

class AT91SAMEndpointIn : public AT91SAMEndpoint  
{
public:
	BOOL Init(PUSB_ENDPOINT_DESCRIPTOR pEndpointDesc,
            BYTE bConfigurationValue, BYTE bInterfaceNumber, BYTE bAlternateSetting);   
    AT91SAMEndpointIn(AT91SAMUsbDevice * const pUsbDevice,DWORD dwEndpointIndex)
        : AT91SAMEndpoint(pUsbDevice, dwEndpointIndex ) 
    {;
    }	
    DWORD   IST(DWORD dwIRBit) ;
};

//! @}
//! @}