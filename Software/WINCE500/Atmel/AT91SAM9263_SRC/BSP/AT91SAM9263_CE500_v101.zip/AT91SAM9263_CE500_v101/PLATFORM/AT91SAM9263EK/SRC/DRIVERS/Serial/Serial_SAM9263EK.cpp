//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//! \addtogroup	Serial
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		Serial_SAM9263EK.cpp
//!
//! \brief		Serial driver functions specific to the AT91SAM9261EK evaluation board
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/Serial/Serial_SAM9263EK.cpp $
//!   $Author: ltourlonias $
//!   $Revision: 684 $
//!   $Date: 2007-04-13 14:35:48 +0200 (ven., 13 avr. 2007) $
//! \endif
//!
//!
//-----------------------------------------------------------------------------

//------------------------------------------------------------------------------
//                                                                      Includes
//------------------------------------------------------------------------------
// Standard includes
#include <windows.h>
#include <memory.h>
#include <CEDDK.h>
#include <serdbg.h>

// Controller includes
#include "at91sam926x.h"
#include "at91sam9263_gpio.h"

// Project include
#include "Serial_SAM926X.h"
#include "atmel_gpio.h"

//------------------------------------------------------------------------------
//                                                                     Variables
//------------------------------------------------------------------------------

static const struct pio_desc hw_pio_us0[] = {
	{"TXD0", AT91C_PIN_PA(26), 0, PIO_DEFAULT, PIO_PERIPH_A},
	{"RXD0", AT91C_PIN_PA(27), 0, PIO_DEFAULT, PIO_PERIPH_A},
	{"RTS0", AT91C_PIN_PA(28), 0, PIO_DEFAULT, PIO_OUTPUT},
	{"CTS0", AT91C_PIN_PA(29), 0, PIO_DEFAULT, PIO_PERIPH_A},
};

static const struct pio_desc hw_pio_us1[] = {
	{"TXD1", AT91C_PIN_PD(0), 0, PIO_DEFAULT, PIO_PERIPH_A},
	{"RXD1", AT91C_PIN_PD(1), 0, PIO_DEFAULT, PIO_PERIPH_A},
	{"RTS1", AT91C_PIN_PD(7), 0, PIO_DEFAULT, PIO_OUTPUT},
	{"CTS1", AT91C_PIN_PD(8), 0, PIO_DEFAULT, PIO_PERIPH_B},
};

static const struct pio_desc hw_pio_us2[] = {
	{"TXD2", AT91C_PIN_PD(2), 0, PIO_DEFAULT, PIO_PERIPH_A},
	{"RXD2", AT91C_PIN_PD(3), 0, PIO_DEFAULT, PIO_PERIPH_A},
	{"RTS2", AT91C_PIN_PD(5), 0, PIO_DEFAULT, PIO_OUTPUT},
	{"CTS2", AT91C_PIN_PD(6), 0, PIO_DEFAULT, PIO_PERIPH_B},
};

//------------------------------------------------------------------------------
//                                                            Exported functions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//!	\fn				BOOL BSPSerialInit (T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Specific initialization of the evaluation board 
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//!
//! \return			True if success;
//! \return	\e		False if error
//------------------------------------------------------------------------------
BOOL BSPSerialInit (T_SERIAL_INIT_STRUCTURE *pInitContext)
{
	BOOL bRet = TRUE;

	// Configure PIO controllers
	switch (pInitContext->dwDeviceID)
	{
		case AT91C_ID_US0:
			DEBUGMSG(ZONE_INIT, (TEXT("BSPSerialInit: setting US0 up.\r\n")));
			pio_setup(hw_pio_us0, sizeof(hw_pio_us0) / sizeof(struct pio_desc));
			pInitContext->fControlMask = 0;
			pInitContext->fControlMask = RTS_CONTROL_MASK;
		break;
		
		case AT91C_ID_US1:
			DEBUGMSG(ZONE_INIT, (TEXT("BSPSerialInit: setting US1 up.\r\n")));
			pio_setup(hw_pio_us1, sizeof(hw_pio_us1) / sizeof(struct pio_desc));
			pInitContext->fControlMask = RTS_CONTROL_MASK;
		break;
		
		case AT91C_ID_US2:
			DEBUGMSG(ZONE_INIT, (TEXT("BSPSerialInit: setting US2 up.\r\n")));
			pio_setup(hw_pio_us2, sizeof(hw_pio_us2) / sizeof(struct pio_desc));
			pInitContext->fControlMask = RTS_CONTROL_MASK;

		break;

	default:
		bRet = FALSE;
		break;
	}
	return bRet;
}

//------------------------------------------------------------------------------
//!	\fn				BOOL BSPSerialDeinitPIO (T_SERIAL_INIT_STRUCTURE * pContext)
//!
//! \brief			Specific de-initialization of the evaluation board 
//! 
//! \param pContext	Context pointer returned from COM_Init.
//!
//! \return			True if success;
//! \return	\e		False if error
//------------------------------------------------------------------------------
BOOL BSPSerialDeinitPIO (T_SERIAL_INIT_STRUCTURE * pContext)
{
	return TRUE;
}

//------------------------------------------------------------------------------
//!	\fn				BOOL BSPSerialClearRTS (T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Clear the pin RTS
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//!
//! \return			True if success;
//! \return	\e		False if error
//------------------------------------------------------------------------------
BOOL BSPSerialClearRTS (T_SERIAL_INIT_STRUCTURE *pInitContext)
{
	BOOL RetVal = TRUE;

	switch (pInitContext->dwDeviceID)
	{
		case AT91C_ID_US0:
			pio_set_value(AT91C_PIN_PA(28), 0);
		break;
		case AT91C_ID_US1:
			pio_set_value(AT91C_PIN_PD(7), 0);
		break;
		case AT91C_ID_US2:
			pio_set_value(AT91C_PIN_PD(5), 0);
		break;
		default:
			RetVal = FALSE;
		break;
	}
	return RetVal;
}

//------------------------------------------------------------------------------
//!	\fn				BOOL BSPSerialSetRTS (T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Set the pin RTS
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//!
//! \return			True if success;
//! \return	\e		False if error
//------------------------------------------------------------------------------
BOOL BSPSerialSetRTS (T_SERIAL_INIT_STRUCTURE *pInitContext)
{
	BOOL RetVal = TRUE;

	switch (pInitContext->dwDeviceID)
	{
		case AT91C_ID_US0:
			pio_set_value(AT91C_PIN_PA(28), 1);
		break;
		case AT91C_ID_US1:
			pio_set_value(AT91C_PIN_PD(7), 1);
		break;
		case AT91C_ID_US2:
			pio_set_value(AT91C_PIN_PD(5), 1);
		break;
		default:
			RetVal = FALSE;
		break;
	}
	return RetVal;
}

//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/Serial/Serial_SAM9263EK.cpp $
//------------------------------------------------------------------------------

//
//! @}
//! @}
//