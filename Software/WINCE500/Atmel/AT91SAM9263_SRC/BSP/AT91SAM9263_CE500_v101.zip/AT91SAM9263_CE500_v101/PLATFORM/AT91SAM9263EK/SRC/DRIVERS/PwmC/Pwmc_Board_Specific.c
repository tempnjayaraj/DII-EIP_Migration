//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		Pwmc_Board_Specific.c
//!
//! \brief		Specific part of the stream driver allowing the management of PWM
//!
//! \if cvs
//!   $RCSfile: Pwm_Board_Specific.c,v $
//!   $Author: jjhiblot $
//!   $Revision: 101 $
//!   $Date: 2006-02-15 14:21:44 +0100 (mer., 15 févr. 2006) $
//! \endif
//!
//! This driver manages 3 PWM channels and each channel can drive 2 PWM signals
//-----------------------------------------------------------------------------
//! \addtogroup	PWMC
//! @{

// System include
#include <windows.h>
//#include <ceddk.h>

// Local include
#include "atmel_gpio.h"
#include "at91sam9263_gpio.h"
#include "..\drivers\pwm\Pwm_DbgZones.h"


//-----------------------------------------------------------------------------
//! \fn			BOOL ConfigurePioForPWM(DWORD dwIndex)
//!
//! \brief		This function configures the PIO for the PWM driver
//!
//! \param		dwIndex				Index (channel) of the peripheral to configure
//!							
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//!
//-----------------------------------------------------------------------------
BOOL ConfigurePioForPWM(DWORD dwIndex)
{
	DEBUGMSG(ZONE_INFO|ZONE_OPEN, (TEXT("->ConfigurePioForPWM\n\r")));
	switch (dwIndex)
	{
		case 0:						
			// The pin B7 is arbitrary chosen, the PWM0 is also available on PIN C28
			{
				const struct pio_desc hw_pio[] = {
					{"PWM0",	AT91C_PIN_PB(7), 0, PIO_DEFAULT, PIO_PERIPH_B},
				};
				pio_setup(hw_pio, (sizeof(hw_pio)/sizeof(struct pio_desc)));
			}
		break;

		case 1:						
			{
			// The pin B8 is arbitrary chosen, the PWM1 is also available on PIN C3
				const struct pio_desc hw_pio[] = {
					{"PWM1",	AT91C_PIN_PB(8), 0, PIO_DEFAULT, PIO_PERIPH_B},
				};
				pio_setup(hw_pio, (sizeof(hw_pio)/sizeof(struct pio_desc)));
			}
		break;

		case 2:			
			{
			// The pin B27 is arbitrary chosen, the PWM2 is also available on PIN C29
				const struct pio_desc hw_pio[] = {
					{"PWM2",	AT91C_PIN_PB(27), 0, PIO_DEFAULT, PIO_PERIPH_B},
				};
				pio_setup(hw_pio, (sizeof(hw_pio)/sizeof(struct pio_desc)));
			}
		break;

		case 3:
			{
			// The pin B29 is arbitrary chosen, the PWM3 is also available on PIN E10
				const struct pio_desc hw_pio[] = {
					{"PWM3",	AT91C_PIN_PB(29), 0, PIO_DEFAULT, PIO_PERIPH_B},
				};
				pio_setup(hw_pio, (sizeof(hw_pio)/sizeof(struct pio_desc)));
			}
		break;

		default:
			DEBUGMSG(ZONE_INFO|ZONE_ERROR, (TEXT("<-ConfigurePioForPWM : Driver Index Not supported (index = %d)\n\r"), dwIndex));
			return FALSE;
	}

	DEBUGMSG(ZONE_INFO, (TEXT("<-ConfigurePioForPWM OK\n\r")));
	return TRUE;
}

//! @}
//! @}
//-----------------------------------------------------------------------------
// End of $RCSfile: Pwm_Board_Specific.c,v $
//-----------------------------------------------------------------------------
//
// Historique : $Log: Pwm_Board_Specific.c,v $
// Historique : Revision 1.4  2005/11/24 13:56:56  sauray
// Historique : Bug corrected (but not tested) in register definition
// Historique :
// Historique : Revision 1.3  2005/11/18 15:16:47  jjhiblot
// Historique : Enhanced and fixed doxygen support
// Historique :
// Historique : Revision 1.2  2005/08/02 12:55:04  lvilquin
// Historique : nothing new
// Historique :
// Historique : Revision 1.1  2005/08/02 09:51:43  lvilquin
// Historique : Creation : PWM driver
// Historique :
