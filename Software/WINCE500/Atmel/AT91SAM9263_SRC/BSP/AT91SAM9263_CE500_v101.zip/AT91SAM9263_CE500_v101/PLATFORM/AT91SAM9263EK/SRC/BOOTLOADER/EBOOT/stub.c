//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//-----------------------------------------------------------------------------
//! \file		stub.c 
//!
//! \brief		This file contain all stub function (for link process)
//!
//! \if subversion
///  $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/BOOTLOADER/EBOOT/stub.c $
//!   $Author: jjhiblot $
//!   $Revision: 862 $
//!   $Date: 2007-05-22 10:55:05 +0200 (mar., 22 mai 2007) $
//! \endif
//-----------------------------------------------------------------------------
#include <windows.h>


//! \addtogroup	EBOOT
//! @{
//!

//----------------------------------------------------------------------------
// \fn    void SOCEnableIrq(DWORD irq)
// \brief need by timer
//----------------------------------------------------------------------------
BOOL SOCEnableIrq(DWORD irq)
{
	return TRUE;
}

//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/BOOTLOADER/EBOOT/stub.c $
//------------------------------------------------------------------------------

//
//! @}
//
//
//! @}
//
