//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//! \addtogroup	WAVEDEV
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		at91sam9263ek_wavedev.c
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/WAVEDEV/at91sam9263ek_wavedev.c $
//!   $Author: ltourlonias $
//!   $Revision: 684 $
//!   $Date: 2007-04-13 14:35:48 +0200 (ven., 13 avr. 2007) $
//! \endif
//!
//! Implementation of the board specific part of the WAVDEV driver.
//-----------------------------------------------------------------------------

#include <windows.h>
#include "ceddk.h"
#include "atmel_gpio.h"
#include "AT91SAM9263_gpio.h"

//static AT91PS_PIO g_pResetPIO = NULL;
//#define RESET_LINE_NUMBER	(13)
//#define RESET_LINE_BANK		(AT91C_BASE_PIOA)

#define AC97FS	AT91C_PIN_PB(0)
#define AC97CK	AT91C_PIN_PB(1)
#define AC97TX	AT91C_PIN_PB(2)
#define AC97RX	AT91C_PIN_PB(3)

//-----------------------------------------------------------------------------
//! \brief		This function clears the reset line
//-----------------------------------------------------------------------------
void AC97CBoardSpecificClearResetLine()
{
/*	PHYSICAL_ADDRESS PA;
	if (g_pResetPIO == NULL)
	{
		PA.QuadPart = (UINT64) RESET_LINE_BANK;
		g_pResetPIO  = (AT91PS_PIO) MmMapIoSpace(PA, sizeof(AT91S_PIO), FALSE);
	}
	
	g_pResetPIO->PIO_CODR = (1<<RESET_LINE_NUMBER);
	g_pResetPIO->PIO_PER = (1<<RESET_LINE_NUMBER);
	g_pResetPIO->PIO_OER = (1<<RESET_LINE_NUMBER);
	*/
}
//-----------------------------------------------------------------------------
//! \brief		This function sets the reset line
//-----------------------------------------------------------------------------
void AC97CBoardSpecificSetResetLine()
{
/*	PHYSICAL_ADDRESS PA;
	if (g_pResetPIO == NULL)
	{
		PA.QuadPart = (UINT64) AT91C_BASE_PIOA;
		g_pResetPIO  = (AT91PS_PIO) MmMapIoSpace(PA, sizeof(AT91S_PIO), FALSE);
	}
	
	g_pResetPIO->PIO_SODR = (1<<RESET_LINE_NUMBER);
	g_pResetPIO->PIO_PER = (1<<RESET_LINE_NUMBER);
	g_pResetPIO->PIO_OER = (1<<RESET_LINE_NUMBER);
*/
}
//-----------------------------------------------------------------------------
//! \brief		This function configure the PIOs for the AC97C controller
//! \return TRUE indicates success
//! \return FALSE indicates failure
//-----------------------------------------------------------------------------
BOOL ConfigureAudioPIOs(void)
{
 /*   PHYSICAL_ADDRESS PhysPIO;
	AT91PS_PIO pPIO;
	
    PhysPIO.QuadPart = (UINT64) PIO_BANK_FOR_AUDIO;
    pPIO = (AT91PS_PIO) MmMapIoSpace(PhysPIO, sizeof(AT91S_PIO), FALSE);
    if (pPIO == NULL)
	{
		return FALSE;
	}
	pPIO->PIO_ASR = PIO_MASK_FOR_AUDIO;
	pPIO->PIO_PDR = PIO_MASK_FOR_AUDIO;
	MmUnmapIoSpace(pPIO,sizeof(AT91S_PIO));

#define PIO_MASK_FOR_AUDIO	(AT91C_PB0_AC97FS | AT91C_PB1_AC97CK | AT91C_PB2_AC97TX | AT91C_PB3_AC97RX)
#define AC97FS	AT91C_PIN_PB(0)
#define AC97CK	AT91C_PIN_PB(1)
#define AC97TX	AT91C_PIN_PB(2)
#define AC97RX	AT91C_PIN_PB(3)
*/
	const struct pio_desc hw_pio[] = 
		{
			{"AC97FS",	AC97FS  , 0, PIO_PULLUP, PIO_PERIPH_A},
			{"AC97CK",	AC97CK  , 0, PIO_PULLUP, PIO_PERIPH_A},
			{"AC97TX",	AC97TX  , 0, PIO_PULLUP, PIO_PERIPH_A},
			{"AC97RX",	AC97RX	, 0, PIO_PULLUP, PIO_PERIPH_A},
		};
	pio_setup(hw_pio, sizeof(hw_pio)/sizeof(struct pio_desc));

	return TRUE;
}

//! @}
//! @}
