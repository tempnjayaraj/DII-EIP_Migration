//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		hmatrix.c
//!
//! \brief		AT91SAM926x's processor's Hmatrix configuation
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/KERNEL/HMATRIX/hmatrix.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//-----------------------------------------------------------------------------

#include <windows.h>
#include "at91sam926x.h"
#include "AT91SAM9263_oal_hmatrix.h"



#define AT91C_MATRIC_ARBITRATION_ROUNDROBIN			(0<<24)
#define AT91C_MATRIC_ARBITRATION_PRIORITY			(1<<24)

#define AT91C_MATRIC_ARBITRATION_NODEFAULTMASTER	(0<<16)
#define AT91C_MATRIC_ARBITRATION_LASTMASTER			(1<<16)
#define AT91C_MATRIC_ARBITRATION_FIXEDMASTER		(2<<16)

typedef struct {
	AT91_REG PRAS;
	AT91_REG PRBS;
} T_PRxS;


#define MIN(x,y) ((x)<(y) ? (x) : (y))

BOOL AT91SAM926x_ConfigureHMatrix(AT91PS_MATRIX pMatrix,T_SLAVE_CONFIG * pSlaveCfg, DWORD dwNbSlaves,DWORD * pMasterCfg, DWORD dwNbMaster)
{
	
	DWORD dwIndex;
	DWORD	dwMasterPriorityIndex;
	UINT64 u64MasterPriority;
	AT91_REG*	pMCFG;
	AT91_REG*	pSCFG;
	T_PRxS*	    pPRxS;
	
	pMCFG = &(pMatrix->MATRIX_MCFG0);
	for (dwIndex=0;dwIndex<dwNbMaster;dwIndex++)
	{
		RETAILMSG(1,(TEXT("Master %d cfg : 0x%x\r\n"),dwIndex,pMasterCfg[dwIndex]));
		pMCFG[dwIndex] = pMasterCfg[dwIndex];
	}

	pSCFG = &(pMatrix->MATRIX_SCFG0);
	pPRxS = (T_PRxS*) &(pMatrix->MATRIX_PRAS0);
	for (dwIndex=0;dwIndex<dwNbSlaves;dwIndex++)
	{
		WCHAR* szArbitration = NULL;
		WCHAR* szDefaultMasterType = NULL;

		DWORD dwTmp = 0;		
		BOOL bError = FALSE;
		
		RETAILMSG(1,(TEXT("Slave %d cfg\r\n"),dwIndex));

		dwTmp = MIN(pSlaveCfg[dwIndex].ucMaximumNumberOfAllowedCyclesForABurst,MAX_CYCLE_FOR_A_BURST);
		
		switch (pSlaveCfg[dwIndex].eArbitrationType)
		{
			case Priority: 
				szArbitration = L"Priority";
				dwTmp |= AT91C_MATRIC_ARBITRATION_PRIORITY;
			break;
			
			case RoundRobin:				
				szArbitration = L"RoundRobin";
				dwTmp |= AT91C_MATRIC_ARBITRATION_ROUNDROBIN;
			 break;
			 
			default:
				DEBUGMSG(1,(TEXT("Slave %d : Invalid arbitration\r\n"),dwIndex));
				bError = TRUE;
				break;
		}
		
		switch (pSlaveCfg[dwIndex].eDefaultMasterType)
		{
			case NoDefaultMaster: 
				szDefaultMasterType = L"No default Master";
				dwTmp |= AT91C_MATRIC_ARBITRATION_NODEFAULTMASTER;
			break;
			
			case LastMaster:			
				szDefaultMasterType = L"Last Accessing Default Master";
				dwTmp |= AT91C_MATRIC_ARBITRATION_LASTMASTER;
			 break;
			 
			case FixedMaster:
				szDefaultMasterType = L"Fixed Default Master";
				dwTmp |= AT91C_MATRIC_ARBITRATION_FIXEDMASTER;
			 break;
			 
			default:
				DEBUGMSG(1,(TEXT("Slave %d : Invalid fixed default Master type\r\n"),dwIndex));
				bError = TRUE;
				break;
		}
		
		if (pSlaveCfg[dwIndex].ucFixedDefaultMasterID >= dwNbMaster)
		{
			DEBUGMSG(1,(TEXT("Slave %d : Invalid fixed default Master ID\r\n"),dwIndex));
			bError = TRUE;
		}
		else
		{
			dwTmp |= ((pSlaveCfg[dwIndex].ucFixedDefaultMasterID) << 18);
		}
		
		u64MasterPriority = 0;
		for (dwMasterPriorityIndex=dwNbMaster;dwMasterPriorityIndex>0;dwMasterPriorityIndex--)
		{
			
			if (pSlaveCfg[dwIndex].ucMasterPriority[dwMasterPriorityIndex-1] <= MAX_MASTER_PRIORITY)
			{
				u64MasterPriority |= pSlaveCfg[dwIndex].ucMasterPriority[dwMasterPriorityIndex-1];
				u64MasterPriority <<= 4;
			}
			else
			{
				DEBUGMSG(1,(TEXT("Slave %d : Invalid priority for Master %d \r\n"),dwIndex,dwMasterPriorityIndex-1));
				bError = TRUE;
				break;
			}
			
		}
		
		
			if (bError == FALSE)
			{
				RETAILMSG(1,(TEXT("arbitration : %s\r\n"),szArbitration));
				if (pSlaveCfg[dwIndex].eDefaultMasterType == FixedMaster)
				{
					RETAILMSG(1,(TEXT("%s (ID %d)\r\n"),szDefaultMasterType,pSlaveCfg[dwIndex].ucFixedDefaultMasterID));
				}
				else
				{
					RETAILMSG(1,(TEXT("%s\r\n"),szDefaultMasterType));
				}

				for (dwMasterPriorityIndex=0;dwMasterPriorityIndex<dwNbMaster;dwMasterPriorityIndex++)
				{
					RETAILMSG(1,(TEXT("Master %d priority %d\r\n"),dwMasterPriorityIndex,pSlaveCfg[dwIndex].ucMasterPriority[dwMasterPriorityIndex]));
				}

				RETAILMSG(1,(TEXT("Slot cycle : %d\r\n"),dwTmp & 0xFF));

				RETAILMSG(1,(TEXT(" ==> SCFG 0x%x\r\n"),dwTmp));
				RETAILMSG(1,(TEXT(" ==> PRAS 0x%x\r\n"),u64MasterPriority & 0xFFFFFFFF));
				RETAILMSG(1,(TEXT(" ==> PRBS 0x%x\r\n"),u64MasterPriority >> 32));

				pSCFG[dwIndex] = dwTmp;
				pPRxS[dwIndex].PRAS = (DWORD) (u64MasterPriority & 0xFFFFFFFF);
				pPRxS[dwIndex].PRBS = (DWORD) (u64MasterPriority >> 32);
			}
			else
			{
				DEBUGMSG(1,(TEXT("Slave %d : Invalid configuration. Keeping reset values ...SCFG = 0x%x PRAS = 0x%x PRBS = 0x%x\r\n"),dwIndex,pSCFG[dwIndex],pPRxS[dwIndex].PRAS,pPRxS[dwIndex].PRBS));
			}
	}
	return TRUE;
}

//------------------------------------------------------------------------------

//! @}


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/KERNEL/HMATRIX/hmatrix.c $
////////////////////////////////////////////////////////////////////////////////
//
