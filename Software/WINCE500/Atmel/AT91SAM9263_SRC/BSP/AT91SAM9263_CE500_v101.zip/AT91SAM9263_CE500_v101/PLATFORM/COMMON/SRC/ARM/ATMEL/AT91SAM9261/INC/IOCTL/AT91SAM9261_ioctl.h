//-----------------------------------------------------------------------------
//! \addtogroup	
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9261_ioctl.h
//!
//! \brief		 iocontrol definitions
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9261/INC/IOCTL/AT91SAM9261_ioctl.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//!
//! IOControl used by application 
//-----------------------------------------------------------------------------

#ifndef __AT91SAM9261_IOCTL_H__
#define __AT91SAM9261_IOCTL_H__




