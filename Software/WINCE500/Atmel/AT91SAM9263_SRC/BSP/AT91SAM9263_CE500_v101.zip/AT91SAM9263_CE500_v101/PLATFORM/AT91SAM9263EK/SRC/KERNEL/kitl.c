//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		kitl.c
//!
//! \brief		Support routines for KITL
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/KERNEL/kitl.c $
//!   $Author: jjhiblot $
//!   $Revision: 127 $
//!   $Date: 2006-03-01 18:58:07 +0100 (mer., 01 mars 2006) $
//! \endif
//-----------------------------------------------------------------------------

//! \addtogroup	KITL
//! @{

#include <windows.h>
#include <oal.h>
#include <nkintr.h>
#include "AT91SAM9263EK.h"
#include "bsp_cfg.h"
#include "at91sam926x.h"
#include "kitl_cfg.h"


extern void EmacSetMAcAddress(UCHAR * pMacAddress);

//------------------------------------------------------------------------------
///  This function is called from OEMInit to start KITL. It sets KITL
///  configuration and it calls OALKitlInit
/// \return TRUE indicates success
/// \return FALSE indicates failure

//-----------------------------------------------------------------------------
//! \fn			  BOOL OALKitlStart()
//!
//! \brief		This function is called from OEMInit to start KITL. It sets KITL
//!     configuration and it calls OALKitlInit.
//!
//!
//!
//! \return TRUE indicates success
//! \return FALSE indicates failure
//-----------------------------------------------------------------------------
BOOL OALKitlStart()
{
    BOOL rc = FALSE;
    OAL_KITL_ARGS *pKITLArgs, KITLArgs;
    CHAR *pszDeviceId;

	// Let just ZONE_ERROR in kitl
//	dpCurSettings.ulZoneMask = 0x01;

	DEBUGMSG(1, (_T("OALKitlStart------kitl-------------\r\n")));

    OALMSG(OAL_KITL&&OAL_FUNC, (L"+OALKitlStart\r\n"));

#if KITL_ON_SERIAL
	// Don't go look for bootargs left by the bootloader, use the default setting.
    pKITLArgs = NULL;
#else
    // Look for bootargs left by the bootloader or left over from an earlier boot.
    pKITLArgs   = (OAL_KITL_ARGS*) OALArgsQuery(OAL_ARGS_QUERY_KITL);

	EmacSetMAcAddress((UCHAR*)pKITLArgs->mac);
#endif

    pszDeviceId = (CHAR*) OALArgsQuery(OAL_ARGS_QUERY_DEVID);
    
	
    // If no KITL arguments were found (typically provided by the bootloader), then select
    // some default settings.
    //
    if (pKITLArgs == NULL)
    {
        memset(&KITLArgs, 0, sizeof(OAL_KITL_ARGS));
        // By default, enable: KITL, DHCP, and VMINI...
        KITLArgs.flags = (OAL_KITL_FLAGS_ENABLED | OAL_KITL_FLAGS_DHCP | OAL_KITL_FLAGS_VMINI);
        // Use built-in EMACB controller for KITL.
        KITLArgs.devLoc.IfcType     = Internal;
        KITLArgs.devLoc.BusNumber   = 0;
#ifdef KITL_ON_SERIAL 
        KITLArgs.devLoc.PhysicalLoc = (PVOID)(AT91C_BASE_DBGU);
#else 	
        KITLArgs.devLoc.PhysicalLoc = (PVOID)(AT91C_BASE_MACB);
#endif
        KITLArgs.devLoc.LogicalLoc  = (DWORD)KITLArgs.devLoc.PhysicalLoc;

        pKITLArgs = &KITLArgs;
    }

    if (pszDeviceId == NULL)
    {
        OALMSG(OAL_ERROR, (L"ERROR: Unable to locate Device ID buffer\r\n"));
    }
    else if (pszDeviceId[0] == '\0')
    {
        // We don't yet have the Ethernet controller's MAC address (this is obtained
        // in the initialization function.  Store a base name for the device, and
        // signal that it should be extended with the MAC address later.
        //
        strncpy(pszDeviceId, BSP_DEVICE_PREFIX, OAL_KITL_ID_SIZE);
        pKITLArgs->flags |= OAL_KITL_FLAGS_EXTNAME;
    }

	// Finally call KITL library.

    //
    rc = OALKitlInit(pszDeviceId, pKITLArgs, g_kitlDevices);

    OALMSG(OAL_KITL&&OAL_FUNC, (L"-OALKitlStart(rc = %d)\r\n", rc));
    return(rc);
}

DWORD OEMEthGetSecs (void)
{
    SYSTEMTIME st;
    DWORD dwRet;
    static DWORD dwBias;
    static DWORD dwLastTime;

	DEBUGMSG(1, (_T("OEMEthGetSecs-------------------\r\n")));

    OEMGetRealTime( &st );
    dwRet = ((60UL * (60UL * (24UL * (31UL * st.wMonth + st.wDay) + st.wHour) + st.wMinute)) + st.wSecond);
    dwBias = dwRet;

    if (dwRet < dwLastTime) {
        KITLOutputDebugString("! Time went backwards (or wrapped): cur: %u, last %u\n",
                              dwRet,dwLastTime);
    }
    dwLastTime = dwRet;
    return (dwRet);
}
//-----------------------------------------------------------------------------
//! \fn			  VOID OALKitlInitRegistry()
//!
//! \brief		This function is called as part of IOCTL_HAL_INITREGISTRY to update
//!     registry with information about KITL device. This must be done to avoid
//!     loading Windows CE driver for KITL devices in case that it is part of image.
//!
//!
//!
//!
//-----------------------------------------------------------------------------

VOID OALKitlInitRegistry()
{
#ifdef KITL_NE2000_PCMCIA_SUPPORT
    OAL_KITL_ARGS *pKITLArgs;
    HKEY Key;
    DWORD Status;
    DWORD Disposition;

			DEBUGMSG(1, (_T("OALKitlInitRegistry-------------------\r\n")));

    // If we're using one of the PCCARD slots for the KITL connection, then we
    // should disable the PCCARD driver (via the "no load" option in the registry)
    // in order to avoid a conflict.
    //

    pKITLArgs   = (OAL_KITL_ARGS*) OALArgsQuery(OAL_ARGS_QUERY_KITL);


    if (pKITLArgs && 
       ((pKITLArgs->devLoc.PhysicalLoc == (PVOID)OALPAtoVA((BULVERDE_BASE_REG_PA_PCMCIA_S0_IO + 0x300), FALSE)) ||
        (pKITLArgs->devLoc.PhysicalLoc == (PVOID)OALPAtoVA((BULVERDE_BASE_REG_PA_PCMCIA_S1_IO + 0x300), FALSE))))
    {
        // We're using the PCCARD controller for the KITL connection...

        //
        // *** Disable PCCARD slot 0 instance ***
        //
        Status = NKRegCreateKeyEx(HKEY_LOCAL_MACHINE, L"Drivers\\BuiltIn\\PCC_MAINSTONEII0", 0, NULL, 0, 0, NULL, &Key, &Disposition);

        if (Status == ERROR_SUCCESS)
        {
            Disposition = DEVFLAGS_NOLOAD;
            // Set Flags value to indicate no loading of driver for this device
            Status = NKRegSetValueEx(Key, DEVLOAD_FLAGS_VALNAME, 0, DEVLOAD_FLAGS_VALTYPE, (PBYTE)&Disposition, sizeof(Disposition));
        }

        // Close the registry key.
        NKRegCloseKey(Key);

        if (Status != ERROR_SUCCESS)
        {
            OALMSGS(OAL_ERROR, (L"OALKitlInitRegistry: failed to set \"no load\" key for PCCARD slot 0.\r\n"));
            goto CleanUp;
        }

        //
        // *** Disable PCCARD slot 1 instance ***
        //
        Status = NKRegCreateKeyEx(HKEY_LOCAL_MACHINE, L"Drivers\\BuiltIn\\PCC_MAINSTONEII1", 0, NULL, 0, 0, NULL, &Key, &Disposition);

        if (Status == ERROR_SUCCESS)
        {
            Disposition = DEVFLAGS_NOLOAD;
            // Set Flags value to indicate no loading of driver for this device
            Status = NKRegSetValueEx(Key, DEVLOAD_FLAGS_VALNAME, 0, DEVLOAD_FLAGS_VALTYPE, (PBYTE)&Disposition, sizeof(Disposition));
        }

        // Close the registry key.
        NKRegCloseKey(Key);

        if (Status != ERROR_SUCCESS)
        {
            OALMSGS(OAL_ERROR, (L"OALKitlInitRegistry: failed to set \"no load\" key for PCCARD slot 1.\r\n"));
            goto CleanUp;
        }

        OALMSGS(TRUE, (L"INFO: PCCARD being used for KITL - disabling PCCARD driver...\r\n"));
    }

CleanUp:
#endif


    return;
}


//! @}

//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/KERNEL/kitl.c $
//-----------------------------------------------------------------------------
//