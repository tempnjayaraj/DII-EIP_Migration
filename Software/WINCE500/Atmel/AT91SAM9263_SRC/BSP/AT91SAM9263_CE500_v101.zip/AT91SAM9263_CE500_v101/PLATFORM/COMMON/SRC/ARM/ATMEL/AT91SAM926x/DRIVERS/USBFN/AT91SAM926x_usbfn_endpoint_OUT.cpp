//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x_usbfn_endpoint_out.cpp
//!
//! \brief		Implementation of the OUT endpoint
//!
//! 
//! 
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/USBFN/AT91SAM926x_usbfn_endpoint_OUT.cpp $
//!   $Author: pblanchard $
//!   $Revision: 984 $
//!   $Date: 2007-06-11 09:19:22 -0700 (Mon, 11 Jun 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	USBFN
//! @{
//!

#include <windows.h>
#include <ceddk.h>
#include <ddkreg.h>
#include "AT91SAM926x_usbfn.h"
#include "AT91SAM926x.h"
#include "AT91SAM926x_oal_intr.h"

#include "AT91SAM926x_USBFN_EndPoint.h"
#include "AT91SAM926x_USBFN_EndPoint_OUT.h"


//-----------------------------------------------------------------------------
//! \brief		This function handles interrupt on Out endpoint.
//!
//! \param		dwIRBit		Status of the interrupt
//!
//! \return		ERROR_SUCCESS	Always return this
//!
//! This function handles interrupt on endpoint. Calls ReceiveData, SendFakeFeature, CompleteTransfer
//-----------------------------------------------------------------------------
DWORD   AT91SAMEndpointOut::IST(DWORD dwIRBit)
{
	WCHAR strDump[2048] = TEXT("");
    Lock();
	BOOL bContinue = TRUE;
    SETFNAME();
    FUNCTION_ENTER_MSG();
    while (bContinue) {
        bContinue = FALSE;
        DEBUGMSG(ZONE_TRANSFER, (_T(" Out::IST(%d) CSR=0x%x"),m_dwEndpointIndex, m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex]));
      
        if (m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] & AT91C_UDP_ISOERROR) 
        {
            DEBUGMSG(ZONE_WARNING, (_T("Stall Sent on Out endpoint =0x%x"),m_dwEndpointIndex));
			m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] &= ~AT91C_UDP_ISOERROR;
            m_fStalled = TRUE;
            bContinue = TRUE;
        }

        if ((m_fStalled == FALSE) && (m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] & (AT91C_UDP_RX_DATA_BK0 | AT91C_UDP_RX_DATA_BK1)))
        { // Packet Complete.
            if ( m_pCurTransfer) 
            {
				int iFreeSpaceInBuffer = m_pCurTransfer->cbBuffer - m_pCurTransfer->cbTransferred;
				int iNbBytesReceived = (m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] & AT91C_UDP_RXBYTECNT) >> 16;		
				BOOL bEndOfTransfer = FALSE;				
				LPBYTE lpTemp = ((LPBYTE) m_pCurTransfer->pvBuffer) + m_pCurTransfer->cbTransferred;


				bContinue = TRUE;

                if (iNbBytesReceived <= iFreeSpaceInBuffer) 
                {					
					int iToTransfer;
					if (iNbBytesReceived < m_epDesc.wMaxPacketSize)
					{
						bEndOfTransfer = TRUE;
						iToTransfer = iNbBytesReceived;
					}
					else
					{
						iToTransfer = m_epDesc.wMaxPacketSize;
					}
					
					strDump[0]=0;
					while (iToTransfer--)
					{

						*(lpTemp) = m_pUsbDevice->m_pUDP->UDP_FDR[m_dwEndpointIndex];
#ifdef DEBUG
						if (ZONE_TRANSFER)
						{
							if (iToTransfer % 16 == 0)
							{
								swprintf(strDump, (TEXT("%s\r\n")), strDump);
							}
							swprintf(strDump, (TEXT("%s 0x%02X")), strDump, *(lpTemp));
						}					
#endif
						lpTemp++;
						m_pCurTransfer->cbTransferred++;
					}
					if (m_pCurTransfer->cbTransferred >=  m_pCurTransfer->cbBuffer)
					{
						bEndOfTransfer = TRUE;
					}

					
						DEBUGMSG(ZONE_TRANSFER, (_T("Endpoint %d IST (RECEIVE BK): Data received (%d bytes): %s \n"), m_dwEndpointIndex,iNbBytesReceived,strDump));


					if (bEndOfTransfer)
					{
						m_pUsbDevice->EnableEndpointInterrupt(m_dwEndpointIndex,FALSE);
						CompleteTransfer(UFN_NO_ERROR);                    
						bContinue = FALSE;
					}
                }
				else
				{
					// Not enough space to copy the whole fifo into the buffer .... 
					m_pUsbDevice->EnableEndpointInterrupt(m_dwEndpointIndex,FALSE);
					CompleteTransfer(UFN_CLIENT_BUFFER_ERROR);
					bContinue = FALSE;
				}

                
            }
			else
			{
					
					DWORD dwNbBytesReceived = (m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] & AT91C_UDP_RXBYTECNT) >> 16;		
					DWORD temp = dwNbBytesReceived;
#ifdef DEBUG					
					while (temp--)
					{
						if (temp % 16 == 0)
						{
							swprintf(strDump, (TEXT("%s\r\n")), strDump);
						}

						swprintf(strDump, (TEXT("%s 0x%02X")), strDump, m_pUsbDevice->m_pUDP->UDP_FDR[m_dwEndpointIndex]);						
					}
#endif
					
					DEBUGMSG(ZONE_TRANSFER, (_T("Endpoint %d DISCARDED RX BK): Data received (%d bytes): %s \n"),m_dwEndpointIndex,dwNbBytesReceived,strDump));

			}

			if (m_CurrentBank == BANK_0)
			{
				m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] &= ~AT91C_UDP_RX_DATA_BK0;
				m_CurrentBank = BANK_1;
			}
			else
			{
				m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] &= ~AT91C_UDP_RX_DATA_BK1;
				m_CurrentBank = BANK_0;
			}
        }
    }
    Unlock();
    FUNCTION_LEAVE_MSG();
    return ERROR_SUCCESS;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL AT91SAMEndpointOut:: Init( PUSB_ENDPOINT_DESCRIPTOR pEndpointDesc, BYTE bConfigurationValue, BYTE bInterfaceNumber, BYTE bAlternateSetting)
//! \brief		This function initializes the Bulk IN endpoint.
//!
//! \param		pEndpointDesc			Endpoint descriptor
//! \param		bConfigurationValue		Configuration value
//! \param		bInterfaceNumber		Interface number
//! \param		bAlternateSetting		Alternate setting
//!
//! \return		Does the init succeed ?
//!
//-----------------------------------------------------------------------------
BOOL AT91SAMEndpointOut:: Init( PUSB_ENDPOINT_DESCRIPTOR pEndpointDesc,
            BYTE bConfigurationValue, BYTE bInterfaceNumber, BYTE bAlternateSetting)
{
    Lock();
    BOOL bReturn = FALSE;
    SETFNAME();
    FUNCTION_ENTER_MSG();
    
	// Set in control mode		
    if ( pEndpointDesc && m_pUsbDevice!=NULL && m_dwEndpointIndex < MAX_ENDPOINT_NUMBER) 
	{
        if (AT91SAMEndpoint::Init(pEndpointDesc,bConfigurationValue,bInterfaceNumber,bAlternateSetting))
		{
			m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] = m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] & ~AT91C_UDP_EPTYPE | AT91C_UDP_EPTYPE_BULK_OUT;
			bReturn = TRUE;
		}
    }
    Unlock();
    FUNCTION_LEAVE_MSG();
    return bReturn;
}

//-----------------------------------------------------------------------------
//! \brief		This function issues a transfer on zero endpoint.
//!
//! \param		pTransfer		Transfer to be done
//!
//! \return		ERROR_INVALID_DATA	The data isn't mean to be sent
//! \return		ERROR_SUCCESS		Success
//!
//! This function enables the interrupt
//-----------------------------------------------------------------------------
DWORD AT91SAMEndpointOut::IssueTransfer(PSTransfer pTransfer)
{   
    Lock();
    SETFNAME();
    FUNCTION_ENTER_MSG();
    DWORD dwReturn = ERROR_SUCCESS;
    if (pTransfer!=NULL && pTransfer->pvBuffer != NULL)
	{
		if (PushTransfer(&InitiatedTransferFifo,pTransfer) == FALSE)
		{
			dwReturn = ERROR_NOT_READY;
		}
	}
    else 
    {
        dwReturn = ERROR_INVALID_DATA;
    }

	if (m_pCurTransfer == NULL) 
	{
		 // If it is valid.                
		m_pCurTransfer = PopTransfer(&InitiatedTransferFifo);
		if (m_pCurTransfer)
		{
			m_pCurTransfer->pvPddTransferInfo = 0;
			m_pCurTransfer->cbTransferred = 0;
			m_pCurTransfer->pvPddData = (PVOID) m_dwEndpointIndex;        

			m_pUsbDevice->EnableEndpointInterrupt(m_dwEndpointIndex,TRUE);
		}				
	}		

    FUNCTION_LEAVE_MSG();
    Unlock();
    return dwReturn;
}


//-----------------------------------------------------------------------------
//! \brief		This function completes the transfer.
//!
//! \param		dwError		
//!
//! \return		No return
//!
//! This function calls the MDD and completes the transfer
//-----------------------------------------------------------------------------
void AT91SAMEndpointOut::CompleteTransfer(DWORD dwError)
{
    PSTransfer  pCurTransfer;
	if (m_pCurTransfer) 
    {
        pCurTransfer = m_pCurTransfer;
        m_pCurTransfer->dwUsbError= dwError;
        m_pCurTransfer = NULL;
        m_pUsbDevice->MddTransferComplete(pCurTransfer);
    }    
	
	if (m_pCurTransfer == NULL) 
	{
		 // If it is valid.                
		pCurTransfer = PopTransfer(&InitiatedTransferFifo);
		if (pCurTransfer)
		{
			pCurTransfer->pvPddTransferInfo = 0;
			pCurTransfer->cbTransferred = 0;
			pCurTransfer->pvPddData = (PVOID) m_dwEndpointIndex;       
			m_pCurTransfer = pCurTransfer;
			m_pUsbDevice->EnableEndpointInterrupt(m_dwEndpointIndex,TRUE);
		}				
	}		

	
}

//! @}
//! @}
