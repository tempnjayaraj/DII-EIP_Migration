//-----------------------------------------------------------------------------
//! \addtogroup	AT91SAM9263EK
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9263EK_ioctl.h
//!
//! \brief		IOCTLs' defines for the AT91SAM9263EK
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/INC/IOCTL/at91sam9263ek_ioctl.h $
//!   $Author: jjhiblot $
//!   $Revision: 875 $
//!   $Date: 2007-05-24 12:21:32 +0200 (jeu., 24 mai 2007) $
//! \endif
//-----------------------------------------------------------------------------

#ifndef _AT91SAM9263EK_IOCTL_H_
#define _AT91SAM9263EK_IOCTL_H_

// HAL IOCTLs available through KernelIoControl

#define HAL_READ_EBOOT_SETTINGS		100	// !!! This constant must not overlap defined in the genric code for the AT91SAM926x familly
#define HAL_WRITE_EBOOT_SETTINGS	101

/*! \def IOCTL_READ_EBOOT_SETTINGS
	\brief Command code for reading the Bootloader settings
*/
#define IOCTL_READ_EBOOT_SETTINGS 	CTL_CODE(FILE_DEVICE_HAL, IOCTL_KLIB_USER + HAL_READ_EBOOT_SETTINGS, METHOD_BUFFERED, FILE_ANY_ACCESS)
/*! \def IOCTL_WRITE_EBOOT_SETTINGS
	\brief Command code for writing the Bootloader settings
*/
#define IOCTL_WRITE_EBOOT_SETTINGS 	CTL_CODE(FILE_DEVICE_HAL, IOCTL_KLIB_USER + HAL_WRITE_EBOOT_SETTINGS, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define IOCTL_CONTRAST_SET_LEVEL CTL_CODE(FILE_DEVICE_SCREEN, 2048, METHOD_BUFFERED, FILE_WRITE_ACCESS)


/*! \def IOCTL_SPI_ADS7843
	\brief Command code for the touchScreen. 
	The strength of the light is given in pBufIn
*/
#define SPI_TRANSACTION_ADS7843_CMD	(2048 + 0x100)
#define IOCTL_SPI_ADS7843		CTL_CODE(FILE_DEVICE_SERIAL_PORT, SPI_TRANSACTION_ADS7843_CMD, METHOD_BUFFERED, FILE_ANY_ACCESS)


#endif // _AT91SAM9263EK_IOCTL_H_

//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/INC/IOCTL/at91sam9263ek_ioctl.h $
//-----------------------------------------------------------------------------
//
