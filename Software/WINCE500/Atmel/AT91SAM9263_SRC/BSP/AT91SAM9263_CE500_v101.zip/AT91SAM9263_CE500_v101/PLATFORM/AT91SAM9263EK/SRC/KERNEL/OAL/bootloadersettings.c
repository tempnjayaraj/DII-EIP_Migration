//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		bootloadersettings.c
//!
//! \brief		Implements the access to the bootloader settings at the OAL level
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/KERNEL/OAL/bootloadersettings.c $
//!   $Author: jjhiblot $
//!   $Revision: 145 $
//!   $Date: 2006-03-08 17:22:18 +0100 (mer., 08 mars 2006) $
//! \endif
//-----------------------------------------------------------------------------

//! \addtogroup	BOOTLOADERSETTINGS
//! @{

#include <windows.h>
#include <oal.h>
#include "at91sam926x.h"
#include "at91sam9263EK.h"
#include "bsp_cfg.h"
#include "AT91SAM926x_interface.h"
#include "crc16.h"


//-----------------------------------------------------------------------------
//! \fn			BOOL OALIoCtlReadBootloaderSettings(DWORD code, VOID *pInBuffer, DWORD inSize, VOID *pOutBuffer, DWORD outSize,DWORD *pOutSize)
//!
//! \brief		This functions implements the READ access to the bootloadersettings
//!
//!	\param		code			not used
//!	\param		pInBuffer	Reboot type
//!	\param		inSize		sizeof(DWORD)
//!	\param		pOutBuffer	not used
//!	\param		outSize		not used
//!	\param		pOutSize		not used
//!
//! \return		TRUE indicates success
//! \return		FALSE indicates failure (bad parameters)
//-----------------------------------------------------------------------------
BOOL OALIoCtlReadBootloaderSettings(DWORD code, VOID *pInBuffer, DWORD inSize, VOID *pOutBuffer, DWORD outSize,DWORD *pOutSize)
{
	RETAILMSG(1, (TEXT("Kernel IOCTL Read bootloader settings not implemented\r\n")));
	return FALSE;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL OALIoCtlWriteBootloaderSettings(DWORD code, VOID *pInBuffer, DWORD inSize, VOID *pOutBuffer, DWORD outSize,DWORD *pOutSize)
//!
//! \brief		This functions implements the Write access to the bootloadersettings
//!
//!	\param		code			not used
//!	\param		pInBuffer	Reboot type
//!	\param		inSize		sizeof(DWORD)
//!	\param		pOutBuffer	not used
//!	\param		outSize		not used
//!	\param		pOutSize		not used
//!
//! \return		TRUE indicates success
//! \return		FALSE indicates failure (bad parameters)
//-----------------------------------------------------------------------------
BOOL OALIoCtlWriteBootloaderSettings(DWORD code, VOID *pInBuffer, DWORD inSize, VOID *pOutBuffer, DWORD outSize,DWORD *pOutSize)
{
	RETAILMSG(1, (TEXT("Kernel IOCTL Write bootloader settings not implemented\r\n")));
	return FALSE;
}

//! @} end of subgroup BOOTLOADERSETTINGS

//! @} end of group OAL

//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/KERNEL/OAL/bootloadersettings.c $
//-----------------------------------------------------------------------------
//