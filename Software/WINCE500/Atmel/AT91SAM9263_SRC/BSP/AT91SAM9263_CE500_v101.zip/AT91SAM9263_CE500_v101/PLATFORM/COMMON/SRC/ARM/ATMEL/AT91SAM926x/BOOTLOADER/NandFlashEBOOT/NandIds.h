//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/NandFlashEBOOT/NandIds.h
//!
//! \brief		NandFlash driver for AT91SAM926x chipset
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/NandFlashEBOOT/NandIds.h $
//!   $Author: ltourlonias $
//!   $Revision: 657 $
//!   $Date: 2007-04-10 16:52:09 +0200 (mar., 10 avr. 2007) $
//! \endif
//!
//! 
//-----------------------------------------------------------------------------
//! \addtogroup	NandFlash
//! @{
//!

#ifndef __NAND_IDS__
#define __NAND_IDS__

#include "Mapping.h"

/*
 * Chips Data
 */
typedef struct _NandFlashDev {
#pragma pack(1)
	union
	{
		struct
		{
			WORD wDevID;	// In memory, due to endianess ManID is before DevID
			WORD wManID;
		};
		DWORD dwCompleteID;	//!< ID of the device on 32b
	};
#pragma pack()
	DWORD dwDataNbBytes		;	//!< Nb of bytes in data section
	DWORD dwSpareNbBytes	;	//!< Nb of bytes in spare section
	DWORD dwBlockNbSectors	;	//!< Nb of sector in a block
	DWORD dwNbBlocks		;	//!< Nb of blocks in device
	DWORD dwFlags			;	//!< Flags
	void  (*Init)()			;	//!< Init function
	MapSectionList	*pMapping;		//!< Map plan. We can associate only one plan for a specific DevID
	WORD sFriendlyName[32];		//!< A user friendly name for the device (max 32 char)
} NandFlashDev;



// Manufacturer IDs
#define MANID_SAMSUNG				0xEC	//!< Samsung ManID
#define MANID_TOSHIBA				0x98	//!< Toshiba ManID
#define MANID_STMICRO				0x20	//!< STMicro ManID
#define MANID_MICRON				0x2C	//!< Micron  ManID

// Device IDs
#define DEVID_K9F1208U0A			0x76	//!< Samsung K9F1208U0A   ID
#define DEVID_MT29F2G16AAB			0xCA	//!< Micron  MT29F2G16AAB ID
#define DEVID_K9F2G08U0A			0xDA	//!< Samsung K9F2G08U0A   ID
#define DEVID_K9F1G08U0A			0xF1	//!< Samsung K9F1G08U0A   ID
#define DEVID_NAND512W3A			0x76	//!< ST Micro NAND512W3A   ID

// Flags
#define NAND_BUSWIDTH16		0x01
#define NAND_SMALLPAGES		0x02

NandFlashDev g_FlashDevIds[];


#endif

// End of Doxygen group NandFlash Driver
//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/NandFlashEBOOT/NandIds.h $
//-----------------------------------------------------------------------------
//
//! @}
