//-----------------------------------------------------------------------------
//! \addtogroup	DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/NandFlash/NandIds.c
//!
//! \brief		NandFlash driver for AT91SAM926x chipset
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/NandFlash/NandIds.c $
//!   $Author: ltourlonias $
//!   $Revision: 657 $
//!   $Date: 2007-04-10 16:52:09 +0200 (mar., 10 avr. 2007) $
//! \endif
//!
//! 
//-----------------------------------------------------------------------------
//! \addtogroup	NandFlash
//! @{
//!

#include "NandIds.h"
#include "Mapping.h"

// Data size in bytes
#define DATA_SIZE_8BYTES			0x0008
#define DATA_SIZE_16BYTES			0x0010
#define DATA_SIZE_32BYTES			0x0020
#define DATA_SIZE_64BYTES			0x0040
#define DATA_SIZE_128BYTES			0x0080
#define DATA_SIZE_256BYTES			0x0100	//!< 256 Bytes of data
#define DATA_SIZE_512BYTES			0x0200	//!< 512 Bytes of data
#define DATA_SIZE_1024BYTES			0x0400	//!< 1024 Bytes of data
#define DATA_SIZE_2048BYTES			0x0800
#define DATA_SIZE_4096BYTES			0x1000
#define DATA_SIZE_8192BYTES			0x2000

// Spare size in bytes
#define SPARE_SIZE_NOSPARES			0x00
#define SPARE_SIZE_1BYTES			0x01
#define SPARE_SIZE_2BYTES			0x02
#define SPARE_SIZE_4BYTES			0x04
#define SPARE_SIZE_8BYTES			0x08	//!< 8 Bytes of spares
#define SPARE_SIZE_16BYTES			0x10	//!< 16 Bytes of spares
#define SPARE_SIZE_32BYTES			0x20	//!< 32 Bytes of spares
#define SPARE_SIZE_64BYTES			0x40
#define SPARE_SIZE_128BYTES			0x80

// Sector per blocks
#define BLOCK_8SECTORS				0x08
#define BLOCK_16SECTORS				0x10	//!< 16 Sector per block
#define BLOCK_32SECTORS				0x20	//!< 32 Sector per block
#define BLOCK_64SECTORS				0x40	//!< 64 Sector per block
#define BLOCK_128SECTORS			0x80

// Number of blocks
#define BLOCK_512					0x0200
#define BLOCK_1024					0x0400
#define BLOCK_2048					0x0800	//!< 2048 Block
#define BLOCK_4096					0x1000	//!< 4096 Block
#define BLOCK_8192					0x2000	//!< 8192 Block
#define BLOCK_16384					0x4000
#define BLOCK_32768					0x8000

static MapSectionList K9F2G08U0A_Offset32MB = 
{
	2,											// Nb of section
	{
		{   0, 2048-256, 256, BLOCK_RESERVED},	// The first 256 blocks map to the end of flash ( 256 * 128KB = 32MB )
		{ 256, 0, 2048-256, BLOCK_WP_NOPROTECTION}	// The rest of the blocks map to the start of flash
	}
};

static MapSectionList K9F1G08U0A_Offset32MB = 
{
	2,											// Nb of section
	{
		{   0, 1024-256, 256, BLOCK_RESERVED},	// The first 256 blocks map to the end of flash ( 256 * 128KB = 32MB )
		{ 256, 0, 1024-256, BLOCK_WP_NOPROTECTION}	// The rest of the blocks map to the start of flash
	}
};


static MapSectionList K9F1208U0A_Offset32MB = 
{
	2,											// Nb of section
	{
		{   0, 4096-2048, 2048, BLOCK_RESERVED},	// The first 2k blocks map to the end of flash ( 2048 * 32 * 512 = 32MB )
		{2048,    0, 4096-2048, BLOCK_WP_NOPROTECTION}	// The 2k next and last blocks map to the start of flash
	}
};

static MapSectionList MT29F2G16AAB_Offset32MB = 
{
	2,											// Nb of section
	{
		{   0, 2048-256, 256, BLOCK_RESERVED},	// The first 256 blocks map to the end of flash ( 256 * 128KB = 32MB )
		{ 256, 0, 2048-256, BLOCK_WP_NOPROTECTION}	// The rest of the blocks map to the start of flash
	}
};

static MapSectionList NAND512W3A_Offset32MB = 
{
	2,											// Nb of section
	{
		{   0, 4096-2048, 2048, BLOCK_RESERVED},	// The first 2k blocks map to the end of flash ( 2048 * 32 * 512 = 32MB )
		{2048,    0, 4096-2048, BLOCK_WP_NOPROTECTION}	// The 2k next and last blocks map to the start of flash
	}
};
static MapSectionList TC58DVG02A_Offset16MB =
{
 	2,                                         // Nb of section
 	{
 	        {   0, 1024, 7168, BLOCK_RESERVED},     
 	        {7168,    0, 1024, BLOCK_WP_NOPROTECTION}
 	}
};
 	

NandFlashDev g_FlashDevIds[] =
{
	{	DEVID_NAND512W3A, MANID_STMICRO,
		DATA_SIZE_512BYTES, SPARE_SIZE_16BYTES, BLOCK_32SECTORS, BLOCK_4096,
		NAND_SMALLPAGES,	NULL,
		&NAND512W3A_Offset32MB,
		L"ST Micro - NAND512W3A"
	},
	{	DEVID_K9F2G08U0A, MANID_SAMSUNG,
		DATA_SIZE_2048BYTES, SPARE_SIZE_64BYTES, BLOCK_64SECTORS, BLOCK_2048,
		0x00,	NULL,
		&K9F2G08U0A_Offset32MB,
		L"Samsung - K9F2G08U0A"
	},
	{	DEVID_K9F1G08U0A, MANID_SAMSUNG,
		DATA_SIZE_2048BYTES, SPARE_SIZE_64BYTES, BLOCK_64SECTORS, BLOCK_1024,
		0x00,	NULL,
		&K9F1G08U0A_Offset32MB,
		L"Samsung - K9F1G08U0A"
	},
	{	DEVID_K9F1208U0A, MANID_SAMSUNG,
		DATA_SIZE_512BYTES, SPARE_SIZE_16BYTES, BLOCK_32SECTORS, BLOCK_4096,
		NAND_SMALLPAGES,	NULL,
		&K9F1208U0A_Offset32MB,
		L"Samsung - K9F1208U0A"
	},
	{	DEVID_MT29F2G16AAB, MANID_MICRON,
		DATA_SIZE_2048BYTES, SPARE_SIZE_64BYTES, BLOCK_64SECTORS, BLOCK_2048,
		NAND_BUSWIDTH16, NULL,
		&MT29F2G16AAB_Offset32MB,
		L"Micron - MT29F2G16AAB"
	},
	{	DEVID_TC58DVG02A, MANID_TOSHIBA,
		DATA_SIZE_512BYTES, SPARE_SIZE_16BYTES, BLOCK_32SECTORS, BLOCK_8192,
		NAND_SMALLPAGES, NULL,
		&TC58DVG02A_Offset16MB,
		L"Toshiba - TC58DVG02A"
	},
	{	0x00, 0x00,
		0x00, 0x00, 0x00, 0x00,
		0x00, NULL,
		NULL,
		L"",
	}
};

// End of Doxygen group NandFlash Driver
//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/NandFlash/NandIds.c $
//-----------------------------------------------------------------------------
//
//! @}
