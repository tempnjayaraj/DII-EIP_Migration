//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//! \addtogroup	WAVEDEV
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		aclink.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/WAVEDEV/aclink.h $
//!   $Author: amlimonet $
//!   $Revision: 889 $
//!   $Date: 2007-05-28 10:42:57 +0200 (lun., 28 mai 2007) $
//! \endif
//!
//! Header file declaring the communication functions (between the controller and the codec)
//-----------------------------------------------------------------------------

#ifndef __ACLINK_H__
#define __ACLINK_H__

#ifdef __cplusplus
extern "C"{
#endif 


#define ACLINK_MUTEX_NAME		TEXT("ACLINK")	
 
BOOL ReleaseAC97Lock(void);
BOOL GetAC97Lock(void);

BOOL WriteAC97(UINT8 Offset, UINT16 Data);
BOOL ReadAC97(UINT8 Offset, UINT16 *pData);

BOOL WriteAC97Raw(UINT8 Offset, UINT16 wData);
BOOL ReadAC97Raw(UINT8 Offset, UINT16 *pData);

BOOL InitializeACLink();
BOOL DeInitializeACLink();


#ifdef __cplusplus
}
#endif 

#endif
//! @} 
//! @}