//-----------------------------------------------------------------------------
//! \addtogroup	MISC
//! @{
//!  
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		crc16.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/crc16.h $
//!   $Author: pblanchard $
//!   $Revision: 1016 $
//!   $Date: 2007-06-18 09:40:37 -0700 (Mon, 18 Jun 2007) $
//! \endif
//!
//! Header for crc16 lib
//-----------------------------------------------------------------------------

// Make a Doxygen group
//! \addtogroup crc16
//! @{

#ifndef _CRC16_H_
#define _CRC16_H_

unsigned short crc16_ccitt(unsigned char *buf, int len);

#endif /* _CRC16_H_ */

// End of Doxygen group crc16
//! @}

//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/crc16.h $
//-----------------------------------------------------------------------------