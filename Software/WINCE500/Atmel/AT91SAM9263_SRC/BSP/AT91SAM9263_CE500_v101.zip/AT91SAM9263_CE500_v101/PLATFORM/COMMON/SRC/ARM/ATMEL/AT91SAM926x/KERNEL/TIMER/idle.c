//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/TIMER/idle.c 
//!
//! \brief		implements OEMIdle function
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/TIMER/idle.c $
//!   $Author: pblanchard $
//!   $Revision: 1090 $
//!   $Date: 2007-07-13 07:07:28 -0700 (Fri, 13 Jul 2007) $
//! \endif
//-----------------------------------------------------------------------------

//! \addtogroup	TIMER
//! @{

#include <windows.h>
#include <nkintr.h>
#include <oal.h>
#include "at91sam926x_interface.h"
#include "AT91SAM926x_oal_timer.h"


//
//  This file contains fake/busy loop implementation if OALCPUIdle function. 
//  It is assumed to be used in development only.

 
//------------------------------------------------------------------------------
//
//  Global:  g_oalLastSysIntr
//
//  This global variable is set by fake version of interrupt/timer handler
//  to last SYSINTR value.
//
volatile UINT32 g_oalLastSysIntr;

//-----------------------------------------------------------------------------
//! \fn VOID OALCPUIdle()
//!
//!	\brief This Idle function implements a busy idle. It is intend to be used only
//!			in development (when CPU doesn't support idle mode it is better to stub
//!			OEMIdle function instead use this busy loop). The busy wait is cleared by
//!			an interrupt from interrupt handler setting the g_oalLastSysIntr.
//!
//!
//!
//!
//-----------------------------------------------------------------------------
VOID OALCPUIdle()
{
	// Clear last SYSINTR global value
    g_oalLastSysIntr = SYSINTR_NOP;
    INTERRUPTS_ON();

#ifdef FAKE_IDLE    
    // Wait until interrupt handler set interrupt flag
    while (g_oalLastSysIntr == SYSINTR_NOP);
#else
	while (g_oalLastSysIntr == SYSINTR_NOP)
	{
		//AT91SAM926x_TurnProcessorClockOff();
		static AT91PS_PMC s_pPMC = NULL;
		
		if (s_pPMC == NULL)
		{
			s_pPMC = OALPAtoVA((DWORD)AT91C_BASE_PMC,FALSE); //cannot fail
		}

		AT91SAM926x_WaitForInterrupt(&(s_pPMC->PMC_SCDR));

	}
#endif    
    INTERRUPTS_OFF();
}

//-----------------------------------------------------------------------------
//! \fn       void OEMIdle(DWORD idleParam)
//!
//!	\brief	   This function is called by the kernel when there are no threads ready to 
//!			run. The CPU should be put into a reduced power mode if possible and halted. 
//!			It is important to be able to resume execution quickly upon receiving an 
//!			interrupt.
//!
//!			Interrupts are disabled when OEMIdle is called and when it returns.
//!
//!			Note that system timer must be running when CPU/SoC is moved to reduced
//!			power mode.
//!
//!	\param    idleParam not use
//! 
//!
//-----------------------------------------------------------------------------
void OEMIdle(DWORD idleParam)
{

    UINT32 baseMSec, idleMSec, idleSysTicks;
    INT32 idleCounts;
    ULARGE_INTEGER idle;
	UINT64 oldCounts,oldCurCounts,u64ReschedCounts;
	BOOL bNoTimerInterrupt;

    // Get current system timer counter
    baseMSec = CurMSec;

    // Compute the remaining idle time
    idleMSec = dwReschedTime - baseMSec;

	//Compute the reschedul time in counts and not in ms (this will give a much better precision)
	u64ReschedCounts = dwReschedTime * g_oalTimer.countsPerMSec;
	    
    // Idle time has expired - we need to return
    if ((INT32)idleMSec <= 0) return;

    // Limit the maximum idle time to what is supported.  
    // Counter size is the limiting parameter.  When kernel 
    // profiler or interrupt latency timing is active it is set
    // to one system tick.
    if (idleMSec > g_oalTimer.maxPeriodMSec) {	
        idleMSec = g_oalTimer.maxPeriodMSec;
		// In case we must clip the end-of-idle time,
		u64ReschedCounts = (baseMSec + idleMSec) * g_oalTimer.countsPerMSec;
    }
        
    idleSysTicks = idleMSec/g_oalTimer.msecPerSysTick;
    
	//Get the actual counts.
	oldCounts = g_oalTimer.curCounts + OALTimerCountsSinceSysTick();
    // This is idle time in hi-res ticks	
	idleCounts = (DWORD) (u64ReschedCounts - oldCounts);


	

    // Prolong beat period to idle time -- don't do it idle time isn't
    // longer than one system tick. Even if OALTimerExtendSysTick function
    // should accept this value it can cause problems if kernel profiler
    // or interrupt latency timing is active.
    if (idleSysTicks > 1) {
        // Extend timer period
       
	   OALTimerEnterIdle(idleCounts, g_oalTimer.countsMargin);
        // Update value for timer interrupt which wakeup from idle
        g_oalTimer.actualMSecPerSysTick = idleMSec;
        g_oalTimer.actualCountsPerSysTick = idleCounts;
		

    }

	

	oldCurCounts = g_oalTimer.curCounts;
    // Move SoC/CPU to idle mode
    OALCPUIdle();
	
	if (g_oalTimer.curCounts == oldCurCounts)
	{
		bNoTimerInterrupt = TRUE;
	}
	else
	{
		bNoTimerInterrupt = FALSE;
	}


	idleCounts = (DWORD) (g_oalTimer.curCounts + OALTimerCountsSinceSysTick() - oldCounts);
	

    // \return system tick period back to original. Don't call when idle
    // time was one system tick. See comment above.
    if ((idleSysTicks > 1) && bNoTimerInterrupt) {

        // We have to restore the normal timer interrupt period
        
        // \return system tick period back to original
        
		OALTimerExitFromIdle(
            g_oalTimer.countsPerSysTick, g_oalTimer.countsMargin
        );
		
        // Restore original values
        g_oalTimer.actualMSecPerSysTick = g_oalTimer.msecPerSysTick;
        g_oalTimer.actualCountsPerSysTick = g_oalTimer.countsPerSysTick;        		

    } 
    
    if (idleCounts < 0) idleCounts = 0;
    
    // Update idle counters
    idle.LowPart = curridlelow;
    idle.HighPart = curridlehigh;
    idle.QuadPart += idleCounts;
    curridlelow  = idle.LowPart;
    curridlehigh = idle.HighPart;
}

//! @} end of subgroup TIMER

//! @} end of group OAL

//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/TIMER/idle.c $
//-----------------------------------------------------------------------------
//
