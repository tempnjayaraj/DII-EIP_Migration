//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{	
//
//  All rights reserved ADENEO SAS 2005
//
//-----------------------------------------------------------------------------
//! \file		AM79C875.c
//
//! \brief		Implementaion of the Common PHY Interface for the AM98C875 Phy
//
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/Emacb/AM79c875.c $
//!   $Author: ltourlonias $
//!   $Revision: 684 $
//!   $Date: 2007-04-13 14:35:48 +0200 (ven., 13 avr. 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	EMAC
//! @{

//! \addtogroup	PHY
//! @{	

//! \addtogroup	AM98C875
//! @{	

#include <windows.h>
#include <oal.h>
#include "phyInterface.h"

#define AM79C875_CONTROL_REG	0
#define AM79C875_CONTROL_REG_RESET					(1<<15)
#define AM79C875_CONTROL_REG_AUTONEGOCIATION_ENABLE	(1<<12)
#define AM79C875_CONTROL_REG_RESTART_AUTONEGOCIATION	(1<<9)
#define AM79C875_CONTROL_REG_FULL_DUPLEX				(1<<8)
#define AM79C875_CONTROL_REG_SPEED_SELECT				(1<<13)

#define AM79C875_STATUS_REG	1
#define AM79C875_STATUS_REG_LINK						(1<<2)
#define AM79C875_STATUS_REG_AUTONEGOCIATION_COMPLETE	(1<<5)

#define AM79C875_ID1_REG	2
#define AM79C875_ID2_REG	3
#define MII_AM79C875_ID   0x00225540


#define AM79C875_LINK_PARTNER_REG	5
#define AM79C875_LINK_PARTNER_100FULL			(1<<8)
#define AM79C875_LINK_PARTNER_100HALF			(1<<7)
#define AM79C875_LINK_PARTNER_10FULL			(1<<6)
#define AM79C875_LINK_PARTNER_10HALF			(1<<5)


static BOOL PHY_Reset(T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr)
{
	pMacInfo->write_phy(pMacInfo->pDeviceLocation,ucPhyAddr,AM79C875_CONTROL_REG,AM79C875_CONTROL_REG_RESET);
	
	return TRUE;
}

static BOOL PHY_StartAutoNegociation(T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr)
{
	pMacInfo->write_phy(pMacInfo->pDeviceLocation,ucPhyAddr,AM79C875_CONTROL_REG,AM79C875_CONTROL_REG_AUTONEGOCIATION_ENABLE | AM79C875_CONTROL_REG_RESTART_AUTONEGOCIATION);	
	return TRUE;
}



static BOOL PHY_WaitForLink(T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr, DWORD dwTimeout)
{
	DWORD dwValue;
	DWORD dwEndOfWait = OALGetTickCount() + dwTimeout;	
	do
	{
		/* Link status is latched, so read twice to get current value */
		pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,AM79C875_STATUS_REG,&dwValue);
		pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,AM79C875_STATUS_REG,&dwValue);
		if (dwValue & AM79C875_STATUS_REG_LINK)
		{
			break;
		}
	}
	while (OALGetTickCount() < dwEndOfWait);

	if ((dwValue & AM79C875_STATUS_REG_LINK)==0)
	{
		RETAILMSG(1,(TEXT("No link \r\n")));
		return FALSE;			/* no link */
	}
	
	return TRUE;
}



static BOOL PHY_WaitForAutonegociationComplete(T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr, DWORD dwTimeout)
{
	DWORD dwValue;
	DWORD dwEndOfWait = OALGetTickCount() + dwTimeout;	
	do
	{
		/* Link status is latched, so read twice to get current value */
		pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,AM79C875_STATUS_REG,&dwValue);
		pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,AM79C875_STATUS_REG,&dwValue);
		if (dwValue & AM79C875_STATUS_REG_AUTONEGOCIATION_COMPLETE)
		{
			break;
		}
	}
	while (OALGetTickCount() < dwEndOfWait);

	if ((dwValue & AM79C875_STATUS_REG_AUTONEGOCIATION_COMPLETE)==0)
	{
		RETAILMSG(1,(TEXT("Autonegociation not complete \r\n")));
		return FALSE;
	}
	
	return TRUE;
}

static BOOL PHY_GetID(T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr,DWORD* pdwID)
{
	DWORD dwID,dwValue;
	pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,AM79C875_ID1_REG,&dwValue);
	dwID = dwValue << 16;

	dwValue = 0;
	pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,AM79C875_ID2_REG,&dwValue);
	dwID |= dwValue;	

	
	if (pdwID)
	{
		*pdwID = dwID;
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

static BOOL PHY_CheckID(T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr)
{
#define ID_MASK	0x00FFFFFE
	DWORD dwID;
	
	PHY_GetID(pMacInfo,ucPhyAddr,&dwID);
	if ((dwID & ID_MASK) != (MII_AM79C875_ID & ID_MASK))
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}


static BOOL PHY_SetConfiguration(T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr, T_PHY_CONFIGURATION* pPhyCfg)
{	
	DWORD dwControlReg;
	
	// Check parameters !
	if (pPhyCfg == NULL)
	{
		return FALSE;
	}
	
	if (pPhyCfg->bRMII == FALSE)
	{
		RETAILMSG(1,(TEXT("PHY_SetConfiguration : MII mode not available\r\n")));
		return FALSE;
	}

	
	if (pPhyCfg->bAutoNegociation)
	{
		return PHY_StartAutoNegociation(pMacInfo,ucPhyAddr);
	}
	
	
	// Check parameters
	if ((pPhyCfg->dwSpeed != SPEED_100) && (pPhyCfg->dwSpeed != SPEED_10))
	{
		return FALSE;
	}
	
	
	dwControlReg = 0;
	if (pPhyCfg->dwSpeed  == SPEED_100)
	{
		dwControlReg |= AM79C875_CONTROL_REG_SPEED_SELECT;
	}
	if (pPhyCfg->bFullDuplex)
	{
		dwControlReg |= AM79C875_CONTROL_REG_FULL_DUPLEX;
	}
	
	pMacInfo->write_phy(pMacInfo->pDeviceLocation,ucPhyAddr,AM79C875_CONTROL_REG,dwControlReg);	
	
	return FALSE;
}



static BOOL PHY_GetConfiguration(T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr, T_PHY_CONFIGURATION* pPhyCfg)
{
	DWORD dwCtrlReg;
	DWORD dwStatusReg;
	DWORD dwLinkPartnerReg;
	
	if (pPhyCfg == NULL)
	{
		return FALSE;
	}
	
	
	pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,AM79C875_CONTROL_REG,&dwCtrlReg);
	pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,AM79C875_STATUS_REG,&dwStatusReg);
	
	if (dwCtrlReg & AM79C875_CONTROL_REG_AUTONEGOCIATION_ENABLE) 
	{	
		pPhyCfg->bAutoNegociation = TRUE;	
		
				/* AutoNegotiation is enabled */
		if (!(dwStatusReg & AM79C875_STATUS_REG_AUTONEGOCIATION_COMPLETE)) 
		{
			return FALSE;		/* auto-negotitation in progress */
		}

		
		pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,AM79C875_LINK_PARTNER_REG,&dwLinkPartnerReg);
		if ((dwLinkPartnerReg & AM79C875_LINK_PARTNER_100FULL) || (dwLinkPartnerReg & AM79C875_LINK_PARTNER_100HALF)) 
		{
			pPhyCfg->dwSpeed  = SPEED_100;
		}
		else 
		{
			pPhyCfg->dwSpeed = SPEED_10;
		}
		
		if ((dwLinkPartnerReg & AM79C875_LINK_PARTNER_100FULL) || (dwLinkPartnerReg & AM79C875_LINK_PARTNER_10FULL)) 
		{
			pPhyCfg->bFullDuplex = TRUE;
		}		
		else
		{
			pPhyCfg->bFullDuplex = FALSE;
		}		
	} 
	else 
	{
		pPhyCfg->bAutoNegociation = FALSE;
		if (dwCtrlReg & AM79C875_CONTROL_REG_SPEED_SELECT)
		{
			pPhyCfg->dwSpeed = SPEED_100;
		}
		else
		{
			pPhyCfg->dwSpeed = SPEED_10;
		}
		if (dwCtrlReg & AM79C875_CONTROL_REG_FULL_DUPLEX)
		{
			pPhyCfg->bFullDuplex = TRUE;
		}
		else
		{
			pPhyCfg->bFullDuplex = FALSE;
		}
	}
	return TRUE;
}


static const WCHAR PhyName[] = L"AM79c875";



T_PHY_INTERFACE AM79C875_PhyInterface = {
	PHY_Reset,
	PHY_SetConfiguration,
	PHY_GetConfiguration,	
	PHY_StartAutoNegociation,
	PHY_WaitForLink,
	PHY_WaitForAutonegociationComplete,
	PHY_GetID,	
	PHY_CheckID,
	PhyName
};




//! @}
//! @}
//! @}
//! @}