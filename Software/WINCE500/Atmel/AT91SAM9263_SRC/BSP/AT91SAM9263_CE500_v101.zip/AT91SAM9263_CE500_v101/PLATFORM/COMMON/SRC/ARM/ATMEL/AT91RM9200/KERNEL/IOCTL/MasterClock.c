//-----------------------------------------------------------------------------
//! \addtogroup   OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file			MasterClock.c 
//!
//! \brief			Implements AT91RM9200 GetMasterClock feature
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/KERNEL/IOCTL/MasterClock.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

#include <windows.h>
#include <oal.h>

#include "at91rm9200.h"
#include "AT91RM9200_interface.h"


//-----------------------------------------------------------------------------
//! \fn		BOOL OALIoCtlHalGetMasterClock(	UINT32 code, VOID *pInpBuffer, 
//!								UINT32 inpSize, VOID *pOutBuffer, 
//!								UINT32 outSize, UINT32 *pOutSize)
//!
//! \brief		This function returns the Frequency of the Master Clock
//!
//!	\param		code		not used
//!	\param		pInpBuffer	not used
//!	\param		inpSize		not used
//!	\param		pOutBuffer	Frequency of the Master clock in Hz
//!	\param		outSize		Size of pOutBuffer
//!	\param		pOutSize	Size of pOutBuffer used
//!
//! \return		TRUE indictaes success
//! \return		FALSE indictaes failure (bad parameters)
//!
//! 
//-----------------------------------------------------------------------------
BOOL OALIoCtlHalGetMasterClock(	UINT32 code, VOID *pInpBuffer, 
								UINT32 inpSize, VOID *pOutBuffer, 
								UINT32 outSize, UINT32 *pOutSize)
{
	if ( pOutBuffer==NULL || outSize<sizeof(DWORD) )
	{
		return FALSE;
	}

	*(DWORD*)pOutBuffer = AT91RM9200_GetMasterClock(FALSE);

	if (pOutSize!=0)
	{
		*pOutSize = sizeof(DWORD);
	}

	return TRUE;
}

//! @}
