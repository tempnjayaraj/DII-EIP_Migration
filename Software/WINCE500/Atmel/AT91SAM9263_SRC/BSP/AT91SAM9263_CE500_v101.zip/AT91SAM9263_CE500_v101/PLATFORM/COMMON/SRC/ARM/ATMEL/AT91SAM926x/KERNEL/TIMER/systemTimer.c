//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/TIMER/systemTimer.c
//!
//! \brief		AT91SAM926x's System timer API
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/TIMER/systemTimer.c $
//!   $Author: pblanchard $
//!   $Revision: 1090 $
//!   $Date: 2007-07-13 07:07:28 -0700 (Fri, 13 Jul 2007) $
//! \endif
//-----------------------------------------------------------------------------

//! \addtogroup	TIMER
//! @{

#include <windows.h>
#include <oal.h>
#include <oal_memory.h>
#include <oal_timer.h>
#include <nkintr.h>

#include "AT91SAM926x.h"
#include "AT91SAM926x_interface.h"
#include "AT91SAM926x_oal_intr.h"
#include "AT91SAM926x_oal_timer.h"



AT91PS_PITC g_pPITC		= 0;

/*! \var g_dwMCKdiv16PerMSec 
	\brief This variable is the number of PIT count in one millisecond. (=MasterClock/16000)
*/
static DWORD g_dwMCKdiv16PerMSec= 0;



//-----------------------------------------------------------------------------
//! \fn       DWORD AT91SAM926x_Read_Interrupt_Counter()
//!
//!	\brief	   This function returns the value of 12 high bits witch inc on each 
//!     interrupt without reseting the 12 bits counter	
//!
//!
//! 
//! \return   12 bits value of the counter
//-----------------------------------------------------------------------------
DWORD AT91SAM926x_Read_Interrupt_Counter()
{
	return (g_pPITC->PITC_PIIR>>20);
}

//-----------------------------------------------------------------------------
//! \fn       DWORD AT91SAM926x_Read_MCKdiv16_Counter()
//!
//!	\brief	   This function returns the value of 20 low bits witch inc on MCK/16 without reseting any counter
//!
//!
//! 
//! \return   20 low bits value of MCK/16
//-----------------------------------------------------------------------------
DWORD AT91SAM926x_Read_MCKdiv16_Counter()
{    
    return (g_pPITC->PITC_PIIR & AT91C_PITC_CPIVMASK);
}


//-----------------------------------------------------------------------------
//! \fn       DWORD AT91SAM926x_Get_MSec_SinceLastSysTick()
//!
//!	\brief	   This function returns number of milliseconds elapsed since last SysTick
//!
//!
//! 
//! \return   number of milliseconds elapsed since last SysTick
//-----------------------------------------------------------------------------
DWORD AT91SAM926x_Get_MSec_SinceLastSysTick()
{    
    return AT91SAM926x_Read_MCKdiv16_Counter() / g_dwMCKdiv16PerMSec;
}




//-----------------------------------------------------------------------------
//! \fn       void AT91SAM926x_InitSystemTimer(DWORD period, BOOL periodIsMs, BOOL bUseInterrupt)
//!
//!	\brief	   This function is called every time you want to change SysTick period
//!       If periodIsMs is set to TRUE, period is in ms, else period is given in MCK/16
//!
//!	\param    period new system timer period
//!	\param    periodIsMs indicates if the period is in millisecond
//!	\param    bUseInterrupt indicates if interrupt must be used
//! 
//!
//-----------------------------------------------------------------------------
void AT91SAM926x_InitSystemTimer(DWORD period, BOOL periodIsMs, BOOL bUseInterrupt)
{         
    static AT91PS_SYS pSYS = NULL;

	DWORD nbMCLKdiv16PerSysTick, dwMaxMCKdiv16;

	DEBUGMSG(1,(TEXT("+AT91SAM926x_InitSystemTimer : period %d\r\n"), period));

	// Test period
	if (period == 0)
    {
        period = (periodIsMs ? 1 : g_dwMCKdiv16PerMSec);
    }
	
	// Virtual address of register
    if (pSYS == NULL)
    {
        pSYS = (AT91PS_SYS) OALPAtoVA((DWORD) AT91C_BASE_SYS,FALSE);

		// Get register address
		g_pPITC =  (AT91PS_PITC) &(pSYS->SYS_PITC_PIMR);

		
    }
    // MCK/16 per MSec
		g_dwMCKdiv16PerMSec = (AT91SAM926x_GetMasterClock(FALSE) / 1000) / 16;

		// Compute max MSec interval
		dwMaxMCKdiv16 = ((1<<20)-1) / g_dwMCKdiv16PerMSec;
    
	// If we get an ms period
	if (periodIsMs)
	{
		nbMCLKdiv16PerSysTick = g_dwMCKdiv16PerMSec * period ; 
		
	// Else we get a MCK/16 period
	} else {
		nbMCLKdiv16PerSysTick = period;
	}
    
	// If we ask a period that doesn't fit 20bit register we need to clip it
	// ie : 20 bit overflow @ dwMCKFrequency/16, approximatively 300ms
	if (nbMCLKdiv16PerSysTick > 0xFFFFF)
	{
		DEBUGMSG(1,(TEXT("AT91SAM926x_InitSystemTimer : Cliping PIV to 0xFFFFF (%d ms)\r\n"),(1000*0xFFFFF)/AT91SAM926x_GetMasterClock(FALSE)*16));
		nbMCLKdiv16PerSysTick = dwMaxMCKdiv16 * g_dwMCKdiv16PerMSec;
	}
	
	if (bUseInterrupt)
	{
		// Enable interrupt for the timer
		g_pPITC->PITC_PIMR = AT91C_PITC_PITEN | AT91C_PITC_PITIEN |  nbMCLKdiv16PerSysTick;	//enable interrupt and enable timer    
		
		// Enable the SYS IRQ
		SOCEnableIrq(AT91C_ID_SYS);
	}
	else
	{
		g_pPITC->PITC_PIMR = AT91C_PITC_PITEN | nbMCLKdiv16PerSysTick;	//disable interrupt and enable timer    	
	}

}

//! @} end of subgroup TIMER

//! @} end of group OAL


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/TIMER/systemTimer.c $
////////////////////////////////////////////////////////////////////////////////
//
