//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9263\KERNEL\DEBUGSERIAL\debugSerial.c
//!
//! \brief		Implements AT91SAM9263 debug serial feature
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/KERNEL/DEBUGSERIAL/debugSerial.c $
//!   $Author: pblanchard $
//!   $Revision: 1058 $
//!   $Date: 2007-07-05 01:34:39 -0700 (Thu, 05 Jul 2007) $
//! \endif
//-----------------------------------------------------------------------------

#include <windows.h>
#include <oal.h>
#include "AT91SAM926x.h"
#include "AT91SAM926x_interface.h"



//* Calculate the baudrate
//* Standard Asynchronous Mode : 8 bits , 1 stop , no parity
#define AT91C_US_ASYNC_MODE ( AT91C_US_USMODE_NORMAL + \
                        AT91C_US_NBSTOP_1_BIT + \
                        AT91C_US_PAR_NONE + \
                        AT91C_US_CHRL_8_BITS + \
                        AT91C_US_CLKS_CLOCK )

//* Standard External Asynchronous Mode : 8 bits , 1 stop , no parity
#define AT91C_US_ASYNC_SCK_MODE ( AT91C_US_USMODE_NORMAL + \
                            AT91C_US_NBSTOP_1_BIT + \
                            AT91C_US_PAR_NONE + \
                            AT91C_US_CHRL_8_BITS + \
                            AT91C_US_CLKS_EXT )

//* Standard Synchronous Mode : 8 bits , 1 stop , no parity
#define AT91C_US_SYNC_MODE ( AT91C_US_SYNC + \
                       AT91C_US_USMODE_NORMAL + \
                       AT91C_US_NBSTOP_1_BIT + \
                       AT91C_US_PAR_NONE + \
                       AT91C_US_CHRL_8_BITS + \
                       AT91C_US_CLKS_CLOCK )

//* SCK used Label
#define AT91C_US_SCK_USED (AT91C_US_CKLO | AT91C_US_CLKS_EXT)

//* Standard ISO T=0 Mode : 8 bits , 1 stop , parity
#define AT91C_US_ISO_READER_MODE ( AT91C_US_USMODE_ISO7816_0 + \
					   		 AT91C_US_CLKS_CLOCK +\
                       		 AT91C_US_NBSTOP_1_BIT + \
                       		 AT91C_US_PAR_EVEN + \
                       		 AT91C_US_CHRL_8_BITS + \
                       		 AT91C_US_CKLO +\
                       		 AT91C_US_OVER)

//* Standard IRDA mode
#define AT91C_US_ASYNC_IRDA_MODE (  AT91C_US_USMODE_IRDA + \
                            AT91C_US_NBSTOP_1_BIT + \
                            AT91C_US_PAR_NONE + \
                            AT91C_US_CHRL_8_BITS + \
                            AT91C_US_CLKS_CLOCK )

extern void ConfigureDBGU(
	unsigned int mainClock,  // \arg peripheral clock
	unsigned int mode ,      // \arg mode Register to be programmed
	unsigned int baudRate ,  // \arg baudrate to be programmed
	unsigned int timeguard ); // \arg timeguard to be programmed


#define DBGU_BAUDRATE	(115200)
//------------------------------------------------------------------------------
/// This function initializes the debug serial port of the AT91SAM9263
/// \return TRUE indicates success
/// \return FALSE indicates failure
BOOL OEMInitDebugSerial ()
{
	DWORD			dwMasterClock;
	AT91PS_PIO		pPIOA = OALPAtoVA((DWORD) AT91C_BASE_PIOA,FALSE);	

    if (g_pDBGU == NULL)
    {
        g_pDBGU = OALPAtoVA((DWORD) AT91C_BASE_DBGU,FALSE);
    }
 
	dwMasterClock = AT91SAM926x_GetMasterClock(FALSE);

   	// Open PIO for DBGU
	pPIOA->PIO_PDR = (AT91C_PC31_DTXD | AT91C_PC30_DRXD);
	pPIOA->PIO_ASR = (AT91C_PC31_DTXD | AT91C_PC30_DRXD);
	
	// Configure DBGU
	ConfigureDBGU (
		dwMasterClock,        // 
		AT91C_US_ASYNC_MODE,  // mode Register to be programmed
		DBGU_BAUDRATE,        // baudrate to be programmed
		0);                   // timeguard to be programmed

	//* Enable  transmitter
    g_pDBGU->DBGU_CR = AT91C_US_TXEN;   
	//* Enable receiver
    g_pDBGU->DBGU_CR = AT91C_US_RXEN;

	return TRUE;
}

//------------------------------------------------------------------------------


//! @}

////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/KERNEL/DEBUGSERIAL/debugSerial.c $
////////////////////////////////////////////////////////////////////////////////
//
