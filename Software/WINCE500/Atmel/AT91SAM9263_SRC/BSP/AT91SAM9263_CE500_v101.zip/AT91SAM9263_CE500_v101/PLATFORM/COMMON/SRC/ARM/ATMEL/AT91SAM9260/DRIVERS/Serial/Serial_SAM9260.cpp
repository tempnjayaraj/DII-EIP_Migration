//-----------------------------------------------------------------------------
//! \addtogroup	Serial
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		Serial_SAM9260.cpp
//!
//! \brief		Serial driver functions specific to the AT91SAM9260 chipset
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9260/DRIVERS/Serial/Serial_SAM9260.cpp $
//!   $Author: nlaunet $
//!   $Revision: 540 $
//!   $Date: 2007-03-09 05:24:21 -0800 (Fri, 09 Mar 2007) $
//! \endif
//!
//! 
//-----------------------------------------------------------------------------

//------------------------------------------------------------------------------
//                                                                      Includes
//------------------------------------------------------------------------------
// Standard includes
#include <windows.h>
#include <memory.h>
#include <CEDDK.h>

// Controller includes
#include "AT91SAM9260.h"
#include "lib_AT91SAM9260.h"

// Project include
#include "Serial_SAM926X.h"

//------------------------------------------------------------------------------
//                                                            Exported functions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//!	\fn				BOOL BSPGetSerialID (T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Get the device ID of the USART
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//!
//! \return			device ID if success;
//! \return	\e		False if error
//------------------------------------------------------------------------------
BOOL	BSPGetSerialID (T_SERIAL_INIT_STRUCTURE *pInitContext)
{
	BOOL RetVal = TRUE;

	switch (pInitContext->dwDeviceIndex)
	{
		case 0 :
			pInitContext->dwDeviceID = AT91C_ID_US0;
			break;
		case 1 :
			pInitContext->dwDeviceID = AT91C_ID_US1;
			break;
		case 2 :
			pInitContext->dwDeviceID = AT91C_ID_US2;
			break;
		case 3 :
			pInitContext->dwDeviceID = AT91C_ID_US3;
			break;
		case 4 :
			pInitContext->dwDeviceID = AT91C_ID_US4;
			break;
		case 5 :
			pInitContext->dwDeviceID = AT91C_ID_US5;
			break;
		default :
			RetVal = FALSE;
			break;
	}

	return RetVal;
}

//------------------------------------------------------------------------------
//!	\fn				BOOL BSPGetSerialBaseAddress (T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Get the Base address of the USART
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//!
//! \return			Base address if success;
//! \return	\e		False if error
//------------------------------------------------------------------------------
BOOL	BSPGetSerialBaseAddress (T_SERIAL_INIT_STRUCTURE *pInitContext)
{
	BOOL RetVal = TRUE;

	switch (pInitContext->dwDeviceID)
	{
		case AT91C_ID_US0 :
			pInitContext->dwBaseAddress = (DWORD)AT91C_BASE_US0;
			break;
		case AT91C_ID_US1 :
			pInitContext->dwBaseAddress = (DWORD)AT91C_BASE_US1;
			break;
		case AT91C_ID_US2 :
			pInitContext->dwBaseAddress = (DWORD)AT91C_BASE_US2;
			break;
		case AT91C_ID_US3 :
			pInitContext->dwBaseAddress = (DWORD)AT91C_BASE_US3;
			break;
		case AT91C_ID_US4 :
			pInitContext->dwBaseAddress = (DWORD)AT91C_BASE_US4;
			break;
		case AT91C_ID_US5 :
			pInitContext->dwBaseAddress = (DWORD)AT91C_BASE_US5;
			break;
		default :
			RetVal = FALSE;
			break;
	}

	return RetVal;
}

//------------------------------------------------------------------------------
//!	\fn				BOOL BSPGetSerialPdcBaseAddress (T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Get the PDC Base address of the USART
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//!
//! \return			PDC Base address if success;
//! \return	\e		False if error
//------------------------------------------------------------------------------
BOOL	BSPGetSerialPdcBaseAddress (T_SERIAL_INIT_STRUCTURE *pInitContext)
{
	BOOL RetVal = TRUE;

	switch (pInitContext->dwDeviceID)
	{
		case AT91C_ID_US0 :
			pInitContext->dwPDCBaseAddress = (DWORD)AT91C_BASE_PDC_US0;
			break;
		case AT91C_ID_US1 :
			pInitContext->dwPDCBaseAddress = (DWORD)AT91C_BASE_PDC_US1;
			break;
		case AT91C_ID_US2 :
			pInitContext->dwPDCBaseAddress = (DWORD)AT91C_BASE_PDC_US2;
			break;
		case AT91C_ID_US3 :
			pInitContext->dwPDCBaseAddress = (DWORD)AT91C_BASE_PDC_US3;
			break;
		case AT91C_ID_US4 :
			pInitContext->dwPDCBaseAddress = (DWORD)AT91C_BASE_PDC_US4;
			break;
		case AT91C_ID_US5 :
			pInitContext->dwPDCBaseAddress = (DWORD)AT91C_BASE_PDC_US5;
			break;
		default :
			RetVal = FALSE;
			break;
	}

	return RetVal;
}

//------------------------------------------------------------------------------
//!	\fn				BOOL BSPGetSerialPmcBaseAddress (T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Get the PMC Base address of the USART
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//!
//! \return			PMC Base address if success;
//! \return	\e		False if error
//------------------------------------------------------------------------------
BOOL	BSPGetSerialPmcBaseAddress (T_SERIAL_INIT_STRUCTURE *pInitContext)
{
	pInitContext->dwPMCBaseAddress = (DWORD)AT91C_BASE_PMC;
	return TRUE;
}

//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9260/DRIVERS/Serial/Serial_SAM9260.cpp $
//------------------------------------------------------------------------------

//
//! @}
//