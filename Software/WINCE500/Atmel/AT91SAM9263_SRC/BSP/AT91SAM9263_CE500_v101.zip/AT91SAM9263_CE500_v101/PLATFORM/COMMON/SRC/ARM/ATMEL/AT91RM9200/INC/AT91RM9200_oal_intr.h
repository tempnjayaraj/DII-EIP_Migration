//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91RM9200_oal_intr.h
//!
//! \brief		common definitions of the interrupt constants for AT91RM9200 processor
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/INC/AT91RM9200_oal_intr.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//!
//-----------------------------------------------------------------------------

#ifndef AT91RM9200_OALINTR_H
#define AT91RM9200_OALINTR_H

#include <nkintr.h>


#define LOGINTR_UNDEFINED    ((DWORD)-1)
#define LOGINTR_MIN            0

#define LOGINTR_AIC_FIRST             		1 //First AIC's irq
#define LOGINTR_AIC_LAST                    31 //Last AIC's irq
                            
// the following values are used to compute the LOGINTR associated with a PIO pin.
// For example LOGINTR for PIOA pin 4 is LOGINTR_BASE_PIOA + 4
#define LOGINTR_BASE_PIOA			64
#define LOGINTR_BASE_PIOB			96                           
#define LOGINTR_BASE_PIOC			128
#define LOGINTR_BASE_PIOD			160                       

//////////////////////////////////////////////////////////////////////
//                          
// SYSINTR values
//
#define SYSINTR_SYS			    (SYSINTR_FIRMWARE+0)
#define SYSINTR_ETHER			(SYSINTR_FIRMWARE+1)  
                       
BOOL SOCDisableIrq(DWORD irq, BOOL* pOldState);
BOOL SOCEnableIrq(DWORD irq);
void SOCSaveAndDisableAllIntrBeforeSuspend();
void SOCRestoreAllIntrAfterSuspend();



#endif

//! @}
