//-----------------------------------------------------------------------------
//! \addtogroup	DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9263EK/SRC/DRIVERS/NandFlash/NandFlash.c
//!
//! \brief		NandFlash driver for AT91SAM926x chipset
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/NandFlash/NandFlash.c $
//!   $Author: ltourlonias $
//!   $Revision: 657 $
//!   $Date: 2007-04-10 16:52:09 +0200 (mar., 10 avr. 2007) $
//! \endif
//!
//! 
//-----------------------------------------------------------------------------
//! \addtogroup	NandFlash
//! @{
//!

// System specific include
#include <windows.h>
#include <nkintr.h>
#include <oal.h>
#include <fmd.h>

// Platform specific include
#include "at91sam926x_oal_ioctl.h"

#include "at91sam9263_gpio.h"
#include "at91sam9263.h"
#include "at91sam926x_interface.h"

#include "at91sam9263ek.h"
#include "at91sam9263_oal_intr.h"

#include "NandFlash.h"


#define A91C_NAND_ENABLE_PIN	15
#define A91C_NAND_READY_PIN		22
#define A91C_NAND_ALE			(1<<21)
#define A91C_NAND_CLE			(1<<22)

static const struct pio_desc hw_pio[] = {
	{"NANDCS",	AT91C_PIN_PD(A91C_NAND_ENABLE_PIN), 0, PIO_PULLUP, PIO_OUTPUT},
	{"RDYBSY",	AT91C_PIN_PA(A91C_NAND_READY_PIN), 0, PIO_PULLUP , PIO_INPUT },
};
	
void NandFlashPlaftorm_PioSetup()
{
	pio_setup(hw_pio, sizeof(hw_pio)/sizeof(struct pio_desc));	
}

void NandFlashPlatform_Init(NandChip *pChip)
{
	/* pChip->dwPhyNandAleAddr is set by FMD, so we can use it */
	pChip->dwPhyNandAleAddr	= pChip->dwPhyNandBaseAddr + A91C_NAND_ALE;
	pChip->dwPhyNandCleAddr	= pChip->dwPhyNandBaseAddr + A91C_NAND_CLE;
	pChip->dwEnablePin = AT91C_PIN_PD(A91C_NAND_ENABLE_PIN);
	pChip->dwReadyPin = AT91C_PIN_PA(A91C_NAND_READY_PIN);
	pChip->dwLogintr = LOGINTR_BASE_PIOA + A91C_NAND_READY_PIN;
}


// End of Doxygen group NandFlash Driver
//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/NandFlash/NandFlash.c $
//-----------------------------------------------------------------------------
//
//! @}
