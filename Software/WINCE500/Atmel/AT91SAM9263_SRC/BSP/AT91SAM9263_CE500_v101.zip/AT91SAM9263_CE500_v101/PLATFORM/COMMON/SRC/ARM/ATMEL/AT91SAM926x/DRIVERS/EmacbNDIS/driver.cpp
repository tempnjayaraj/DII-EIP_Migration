//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//
//! \file		EmacbNDIS/driver.cpp
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/EmacbNDIS/driver.cpp $
//!   $Author: amlimonet $
//!   $Revision: 970 $
//!   $Date: 2007-06-08 11:52:45 +0200 (ven., 08 juin 2007) $
//! \endif
//
//-----------------------------------------------------------------------------
//! \addtogroup EMACNDIS
//! @{
//

// Common includes
#include	<windows.h>
#include	<oal_kitl.h>
#include	<oal_args.h> 

// Controllers includes

// APIs includes
#include	"at91sam926x_oal_ioctl.h"

// driver includes
#include	"common.h"
#include	"driver.h"
#include	"device.h"
#include	"at91sam9263ek.h"
#include	"at91sam9263ek_ioctl.h"
#include    "AT91SAM9263.h"


// Driver define configuration
#define IMPL_TX_QUEUE
#define IMPL_RESET
#define IMPL_SEND_INDICATION


#define	HANDLE_QUERY(event,ptr,len)	\
	case event: if(InfoBufferLength < (*BytesNeeded=len)) \
		{ status = NDIS_STATUS_INVALID_LENGTH; break; }	\
	panswer = (void*)(ptr); *BytesWritten = len; break;

#define	HANDLE_SET(event,len)	\
	case event: if(InfoBufferLength < (*BytesNeeded=len)) \
		{ status = NDIS_STATUS_INVALID_LENGTH; break; }	\
		*BytesRead = len; HANDLE_SET_##event(); break;

#define	HANDLE_SET_OID_GEN_CURRENT_PACKET_FILTER()	\
//	m_pLower->DeviceOnSetupFilter(*(U32*)InfoBuffer)

/****************************************************************************************
 *
 * Driver-wide global data declaration
 *
 ****************************************************************************************/

// All supported OID (features) our driver
NDIS_OID gszNICSupportedOid[] = {
		OID_GEN_SUPPORTED_LIST,
        OID_GEN_HARDWARE_STATUS,
        OID_GEN_MEDIA_SUPPORTED,
        OID_GEN_MEDIA_IN_USE,
        OID_GEN_MEDIA_CONNECT_STATUS,
        OID_GEN_MAXIMUM_SEND_PACKETS,
        OID_GEN_VENDOR_DRIVER_VERSION,
        OID_GEN_MAXIMUM_LOOKAHEAD,
        OID_GEN_MAXIMUM_FRAME_SIZE,
        OID_GEN_MAXIMUM_TOTAL_SIZE,
        OID_GEN_MAC_OPTIONS,
        OID_GEN_PROTOCOL_OPTIONS,
        OID_GEN_LINK_SPEED,
        OID_GEN_TRANSMIT_BUFFER_SPACE,
        OID_GEN_RECEIVE_BUFFER_SPACE,
        OID_GEN_TRANSMIT_BLOCK_SIZE,
        OID_GEN_RECEIVE_BLOCK_SIZE,
        OID_GEN_VENDOR_ID,
        OID_GEN_VENDOR_DESCRIPTION,
        OID_GEN_CURRENT_PACKET_FILTER,
        OID_GEN_CURRENT_LOOKAHEAD,
        OID_GEN_DRIVER_VERSION,
        OID_GEN_XMIT_OK,
        OID_GEN_RCV_OK,
        OID_GEN_XMIT_ERROR,
        OID_GEN_RCV_ERROR,
        OID_GEN_RCV_NO_BUFFER,
        OID_GEN_RCV_CRC_ERROR,
        OID_802_3_PERMANENT_ADDRESS,
        OID_802_3_CURRENT_ADDRESS,
        OID_802_3_MULTICAST_LIST,
        OID_802_3_MAXIMUM_LIST_SIZE,
        OID_802_3_RCV_ERROR_ALIGNMENT,
        OID_802_3_XMIT_ONE_COLLISION,
        OID_802_3_XMIT_MORE_COLLISIONS,
        OID_802_3_XMIT_DEFERRED,
        OID_802_3_XMIT_MAX_COLLISIONS,
        OID_802_3_XMIT_UNDERRUN,
        OID_802_3_XMIT_HEARTBEAT_FAILURE,
        OID_802_3_XMIT_TIMES_CRS_LOST,
        OID_802_3_XMIT_LATE_COLLISIONS,
    };

//------------------------------------------------------------------------------
//! \fn void NIC_DRIVER_OBJECT::DriverStart(void)
//! \brief Start the driver (calling DeviceStart on m_pLower variable)
//------------------------------------------------------------------------------
void NIC_DRIVER_OBJECT::DriverStart(void)
{
	m_pLower->DeviceStart();
}

//------------------------------------------------------------------------------
//! \fn void NIC_DRIVER_OBJECT::EDriverInitialize(OUT PNDIS_STATUS OpenErrorStatus,	OUT PUINT SelectedMediaIndex, IN PNDIS_MEDIUM MediaArray, IN UINT MediaArraySize)
//! \brief This function initialize the ethernet NDIS driver
//! 
//! \param OpenErrorStatus
//!
//! \param SelectedMediaIndex
//!
//! \param MediaArray
//!
//! \param MediaArraySize
//------------------------------------------------------------------------------
void NIC_DRIVER_OBJECT::EDriverInitialize(
		OUT PNDIS_STATUS OpenErrorStatus,
		OUT PUINT SelectedMediaIndex, 
		IN PNDIS_MEDIUM MediaArray, 
		IN UINT MediaArraySize)
{

//	RETAILMSG(1, (L"-->EDriverInitialize\r\n"));
	m_uRecentInterruptStatus = 0;
	
	if(!m_pLower)
		m_pLower = DeviceEntry(this,NULL);
		
	if(!m_pLower)
			THROW((ERR_STRING("Error in creating device")));
	
	UINT		i;
	NDIS_STATUS		status;
	NDIS_HANDLE		hconfig;

	// Determinate media type
	for(i=0; i<MediaArraySize; i++) 
		if(MediaArray[i] == NdisMedium802_3)	break;

    if (i == MediaArraySize) 
    	THROW((ERR_STRING("Unsupported media"),NDIS_STATUS_UNSUPPORTED_MEDIA));
		

	*SelectedMediaIndex = i;

	// Read registry configurations
	NdisOpenConfiguration(
			&status,
			&hconfig,
			m_NdisWrapper);

	EDriverConfigRegistry();
	

	if(status != NDIS_STATUS_SUCCESS) 
		THROW((ERR_STRING("Error in opening configuration"),status));

	C_Exception	*pexp;	
	TRY
	{
		m_pLower->DeviceSetDefaultSettings();
		m_pLower->DeviceRetriveConfigurations(hconfig);
		m_pLower->EDeviceValidateConfigurations();

		FI;
	}
	CATCH(pexp)
	{
		pexp->PrintErrorMessage();
		CLEAN(pexp);
		NdisCloseConfiguration(hconfig);
		THROW((ERR_STRING("*** Error in retriving configurations.\n")));
	}


	m_pLower->DeviceRegisterAdapter();
	
	U32		uNbBuffer,uaddr;
	uNbBuffer = m_pLower->m_szConfigures[CID_TXBUFFER_NUMBER];
	if(!(uaddr = (U32)malloc(sizeof(CQUEUE_GEN_HEADER)* uNbBuffer)))	
		THROW((ERR_STRING("Insufficient memory")));

	TRY
	{
		m_pLower->EDeviceLoadRegister(hconfig);
		EDriverAllocateBuffer();

		U32 i = 0;

		for(;uNbBuffer--;uaddr+=sizeof(CQUEUE_GEN_HEADER))
		{
			((PCQUEUE_GEN_HEADER)uaddr)->dwPhysAddrBuffer = m_PhysAddrTxBuffer + i *TX_BUFFER_SIZE;
			((PCQUEUE_GEN_HEADER)uaddr)->dwPhysAddrDesc = m_PhysAddrTxDesc + i * TX_DESC_SIZE;
			((PCQUEUE_GEN_HEADER)uaddr)->pvVirtAddrBuffer = (PVOID)(((DWORD)m_VirtAddrTxBuffer) + i * TX_BUFFER_SIZE);
			((PCQUEUE_GEN_HEADER)uaddr)->pvVirtAddrDesc = (PVOID)((DWORD)m_VirtAddrTxDesc + i * TX_DESC_SIZE);
			m_TQueue.Enqueue((PCQUEUE_GEN_HEADER)uaddr);
			i++;
		}


		m_pLower->EDeviceInitialize(m_pLower->m_nResetCounts=0);
		m_pLower->DeviceEnableInterrupt();
		
		m_pLower->EDeviceRegisterInterrupt();
		FI;
	}
	CATCH(pexp)
	{
		pexp->PrintErrorMessage();
		CLEAN(pexp);
		THROW((ERR_STRING("Device error")));
	}

	NdisCloseConfiguration(hconfig);
//	RETAILMSG(1, (L"<--EDriverInitialize\r\n"));


}

//------------------------------------------------------------------------------
//! \fn void NIC_DRIVER_OBJECT::EDriverConfigRegistry(void)
//! \brief Configure registry value with bootloader settings if bootsettings = 1 in registry
//------------------------------------------------------------------------------
void NIC_DRIVER_OBJECT::EDriverConfigRegistry(void)
{
	HKEY			hKey;
	LPCTSTR			hSubKey = _T("COMM\\EMACB1\\Parms\\TcpIp");
	WCHAR			strAddr[20];
	DWORD			dwBootSettings;
	DWORD			dwType = REG_DWORD;
	DWORD			dwBufLen = sizeof(DWORD);
	OAL_KITL_ARGS	kitl_cfg;
	DWORD			dwByteReturn;
	DWORD			dwValue;
	
	if(RegOpenKeyEx( HKEY_LOCAL_MACHINE, hSubKey, 0, 0, &hKey) == ERROR_SUCCESS)
	{
		if(RegQueryValueEx(hKey, _T("BootSettings"), NULL, &dwType, (LPBYTE)&dwBootSettings, &dwBufLen) == ERROR_SUCCESS)
		{
			if(dwBootSettings == 1)
			{
				RETAILMSG(1, (L"Using bootloader ethernet configuration\r\n"));
				KernelIoControl(IOCTL_HAL_GET_KITL_ARGS, NULL, 0, &kitl_cfg, sizeof(OAL_KITL_ARGS), &dwByteReturn);
				
				//Configure DHCP
				if(kitl_cfg.flags & OAL_KITL_FLAGS_DHCP)
				{
					dwValue = 1;
					RegSetValueEx(hKey, _T("EnableDHCP"), 0,
						dwType, (BYTE*)&dwValue, dwBufLen);
				}
				else
				{
					dwValue = 0;
					RegSetValueEx(hKey, _T("EnableDHCP"), 0,
						dwType, (BYTE*)&dwValue, dwBufLen);
				}
				
				// Configure IP address				
				swprintf(strAddr, L"%d.%d.%d.%d",
					(kitl_cfg.ipAddress & 0x000000FF),
					(kitl_cfg.ipAddress & 0x0000FF00)>>8, 
					(kitl_cfg.ipAddress & 0x00FF0000)>>16, 
					(kitl_cfg.ipAddress & 0xFF000000)>>24);
				dwType = REG_SZ;
				RegSetValueEx(hKey, _T("IpAddress"), 0, 
					dwType, (BYTE*)strAddr, wcslen(strAddr)*sizeof(TCHAR));
				
				// Configure SubNet Mask
				swprintf(strAddr, L"%d.%d.%d.%d",
					(kitl_cfg.ipMask & 0x000000FF),
					(kitl_cfg.ipMask & 0x0000FF00)>>8, 
					(kitl_cfg.ipMask & 0x00FF0000)>>16, 
					(kitl_cfg.ipMask & 0xFF000000)>>24);
				dwType = REG_SZ;
				RegSetValueEx(hKey, _T("Subnetmask"), 0, 
					dwType, (BYTE*)strAddr, wcslen(strAddr)*sizeof(TCHAR));
				
				
				RegCloseKey(hKey);
				LPCTSTR		hSubKey = _T("COMM\\EMACB1\\Parms");
				
				if(RegOpenKeyEx( HKEY_LOCAL_MACHINE, hSubKey, 0, 0, &hKey) == ERROR_SUCCESS)
				{
					swprintf(strAddr, L"%02x-%02x-%02x-%02x-%02x-%02x",
						(U8)(kitl_cfg.mac[0] & 0xFF),
						(U8)((kitl_cfg.mac[0] & 0xFF00) >> 8 ), 
						(U8)(kitl_cfg.mac[1] & 0xFF),
						(U8)((kitl_cfg.mac[1] & 0xFF00) >> 8 ), 
						(U8)(kitl_cfg.mac[2] & 0xFF),
						(U8)((kitl_cfg.mac[2] & 0xFF00) >> 8 ));
					dwType = REG_SZ;
					RegSetValueEx(hKey, _T("NetworkAddress"), 0, 
						dwType, (BYTE*)strAddr, wcslen(strAddr)*sizeof(TCHAR));


					RegCloseKey(hKey);
				}
			}
			else
			{
				RETAILMSG(1, (L"Using registry ethernet configuration\r\n"));
			}
			
		}
	}
}

//------------------------------------------------------------------------------
//! \fn void NIC_DRIVER_OBJECT::EDriverAllocateBuffer(void)
//! \brief Allocate all buffer use in driver (Rx and Tx) from configuration write in registry
//------------------------------------------------------------------------------
void NIC_DRIVER_OBJECT::EDriverAllocateBuffer(void)
{
	HKEY hKey;
	DWORD dwTransmitbuffer;
	DWORD dwReceivebuffer;
	DWORD dwBufLen = sizeof(DWORD);
	DWORD dwType = REG_DWORD;
	BOOL bUseDefault = TRUE;
	DMA_ADAPTER_OBJECT Adapter;
	PHYSICAL_ADDRESS PA,PA_txdesc, PA_txbuffer,PA_rxbuffer ;
	Adapter.ObjectSize    = sizeof(DMA_ADAPTER_OBJECT);
	Adapter.InterfaceType = Internal;
	Adapter.BusNumber     = 0;
	LPCTSTR		hSubKey = _T("COMM\\EMACB1\\Parms");

	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, hSubKey, 0, 0, &hKey) == ERROR_SUCCESS)
	{
		if ( (RegQueryValueEx(hKey, L"VramXmitBuffer" , 0, &dwType, (LPBYTE)&dwTransmitbuffer , &dwBufLen) == ERROR_SUCCESS))
		{
			// allocate TX buffer and DMA descriptor
			PA_txdesc.LowPart =dwTransmitbuffer;
			PA_txdesc.HighPart=0x00000000;
			m_VirtAddrTxDesc=MmMapIoSpace(PA_txdesc, m_pLower->m_szConfigures[CID_TXBUFFER_NUMBER]*TX_DESC_SIZE, FALSE);
			m_PhysAddrTxDesc = PA_txdesc.LowPart;
			PA_txbuffer.LowPart =(dwTransmitbuffer + m_pLower->m_szConfigures[CID_TXBUFFER_NUMBER] * TX_DESC_SIZE);
			PA_txbuffer.HighPart=0x00000000;
			m_VirtAddrTxBuffer=MmMapIoSpace(PA_txbuffer, (m_pLower->m_szConfigures[CID_TXBUFFER_NUMBER]*TX_BUFFER_SIZE), FALSE);
			m_PhysAddrTxBuffer = PA_txbuffer.LowPart;
			if((m_VirtAddrTxDesc  == NULL) || (m_VirtAddrTxBuffer  == NULL))
			{	
				RETAILMSG(1, (L"Error in TX buffer and DMA descriptor\r\n"));
			}
		}		
		else
		{
			// allocate TX buffer and DMA descriptor
			m_VirtAddrTxDesc = (BYTE *) HalAllocateCommonBuffer(&Adapter, (m_pLower->m_szConfigures[CID_TXBUFFER_NUMBER]*TX_DESC_SIZE), &PA, FALSE);
			m_PhysAddrTxDesc = PA.LowPart;
			m_VirtAddrTxBuffer = (BYTE *) HalAllocateCommonBuffer(&Adapter, (m_pLower->m_szConfigures[CID_TXBUFFER_NUMBER]*TX_BUFFER_SIZE),	&PA, FALSE);
			m_PhysAddrTxBuffer = PA.LowPart;
		}
		if ((RegQueryValueEx(hKey, L"VramRecvBuffer" , 0, &dwType, (LPBYTE)&dwReceivebuffer , &dwBufLen) == ERROR_SUCCESS))
		{
			// allocate RX buffer and DMA descriptor
			PA_rxbuffer.LowPart =dwReceivebuffer;
			PA_rxbuffer.HighPart=0x00000000;
			m_VirtAddrRxBuffer=MmMapIoSpace(PA_rxbuffer, (m_pLower->m_szConfigures[CID_RXBUFFER_NUMBER] * (RX_DESC_SIZE + RX_BUFFER_SIZE)), FALSE);
			m_PhysAddrRxBuffer = PA_rxbuffer.LowPart;
			if(m_VirtAddrRxBuffer == NULL)
			{
				RETAILMSG(1, (L"Error in TX buffer and DMA descriptor\r\n"));
			}
		}
		else
		{
			// allocate RX buffer and DMA descriptor
			m_VirtAddrRxBuffer = (PVOID)HalAllocateCommonBuffer(&Adapter, 
			(m_pLower->m_szConfigures[CID_RXBUFFER_NUMBER] * (RX_DESC_SIZE + RX_BUFFER_SIZE)),	&PA, FALSE);
			m_PhysAddrRxBuffer = PA.LowPart;
		}
	}
}

//------------------------------------------------------------------------------
//! \fn PVOID NIC_DRIVER_OBJECT::DriverBindAddress(U32 uPhysicalAddress,U32 uLength)
//! \brief  Bind a physical address (paramters) with a virtual address (use virtualAlloc and virtualCopy)
//! 
//! \param uPhysicalAddress	Physical address to bind
//!
//! \param uLength			length tof memory to bind
//!
//! \return					The virtual address bind.
//------------------------------------------------------------------------------
PVOID NIC_DRIVER_OBJECT::DriverBindAddress(
	U32		uPhysicalAddress,
	U32		uLength)
{
	void	*pvoid;
	
	// allocate memory for the work space
    if(!(pvoid = VirtualAlloc(
		NULL, 
		uLength,
		MEM_RESERVE, 
		PAGE_NOACCESS))) return NULL;

	// binding this virtual addr to physical location
	VirtualCopy(
		pvoid,
		(PVOID)uPhysicalAddress,
		uLength,
		PAGE_READWRITE | PAGE_NOCACHE);

	return pvoid;
}

//------------------------------------------------------------------------------
//! \fn void NIC_DRIVER_OBJECT::DriverIndication(U32 uIndication)
//! \brief Permit to indicate a parameter
//! 
//! \param uIndication	ID of parameter to indicate
//------------------------------------------------------------------------------
void	NIC_DRIVER_OBJECT::DriverIndication(
	U32		uIndication)
{
	switch (uIndication)
	{
		case NIC_IND_TX_IDLE:
			if(m_bOutofResources)
			{
				m_bOutofResources = 0;
				NdisMSendResourcesAvailable(m_NdisHandle);
			}
			break;
		case AID_ERROR:
		case AID_LARGE_INCOME_PACKET:
			m_bSystemHang = 1;
		default:
			break;
	}	
}

//------------------------------------------------------------------------------
//! \fn void NIC_DRIVER_OBJECT::DriverIsr(OUT PBOOLEAN InterruptRecognized, OUT PBOOLEAN QueueInterrupt)
//! \brief The driver ISR. Return via parameters if Interrupts have fired.
//! 
//! \param InterruptRecognized	As interrupt recognized (TRUE if yes)
//!
//! \param QueueInterrupt		Equals to InterruptRecognized
//------------------------------------------------------------------------------
void NIC_DRIVER_OBJECT::DriverIsr(
		OUT PBOOLEAN InterruptRecognized, 
		OUT PBOOLEAN QueueInterrupt)		
{
	U32	intstat = m_pLower->DeviceGetInterruptStatus();
	//m_pLower->DeviceDisableInterrupt();
	if(!intstat)
	{
		*InterruptRecognized =
		*QueueInterrupt = FALSE;
		//m_pLower->DeviceEnableInterrupt();
		return;
	}

	/* clear it immediately */
	m_uRecentInterruptStatus = intstat;
//	m_pLower->DeviceSetInterruptStatus(
//		m_uRecentInterruptStatus = intstat);
		
	*InterruptRecognized = TRUE;
	*QueueInterrupt = TRUE;

#ifdef	IMPL_DEVICE_ISR
	mpLower->DeviceIsr(intstat);
#endif

}

//------------------------------------------------------------------------------
//! \fn void NIC_DRIVER_OBJECT::DriverInterruptHandler(void)
//! \brief  The driver interrupt Handler (call lower layer interrupt handler function)
//------------------------------------------------------------------------------
void	NIC_DRIVER_OBJECT::DriverInterruptHandler(void)
{
	m_pLower->DeviceInterruptEventHandler(m_uRecentInterruptStatus);
	//m_pLower->DeviceEnableInterrupt();
}

//------------------------------------------------------------------------------
//! \fn NDIS_STATUS NIC_DRIVER_OBJECT::DriverQueryInformation(IN NDIS_OID Oid, IN PVOID InfoBuffer, IN ULONG InfoBufferLength, OUT PULONG BytesWritten,OUT PULONG BytesNeeded)
//! \brief This function permit to query information 
//! 
//! \param Oid				Information query id ask
//!
//! \param InfoBuffer		Buffer to write this information
//!
//! \param InfoBufferLength	Buffer length
//!
//! \param BytesWritten		Number of bytes write into the buffer
//!
//! \param BytesNeeded		Number of bytes need
//!
//! \return	The status of the opertation
//------------------------------------------------------------------------------
NDIS_STATUS NIC_DRIVER_OBJECT::DriverQueryInformation(
		IN NDIS_OID		Oid,
		IN PVOID		InfoBuffer, 
		IN ULONG		InfoBufferLength, 
		OUT PULONG		BytesWritten,
		OUT PULONG		BytesNeeded)
{
//	RETAILMSG(1, (L"-->DriverQueryInformation\r\n"));
	NDIS_STATUS	status = NDIS_STATUS_SUCCESS;
	
	PVOID	panswer;
	U8		szbuffer[32];
	U32		tmp32;
	
	// pass to lower object, to see if it can handle this query,
	// if it can, return TRUE and set status.
	if(m_pLower->DeviceQueryInformation(
		&status,
		Oid,
		InfoBuffer,
		InfoBufferLength,
		BytesWritten,
		BytesNeeded)) return status;
		
	switch (Oid) {
		HANDLE_QUERY( OID_GEN_SUPPORTED_LIST,
			&gszNICSupportedOid,sizeof(gszNICSupportedOid));
			
		HANDLE_QUERY( OID_GEN_HARDWARE_STATUS,
			&m_pLower->m_szCurrentSettings[SID_HW_STATUS],sizeof(U32));
			
		HANDLE_QUERY( OID_GEN_MEDIA_IN_USE,
			&m_pLower->m_szCurrentSettings[SID_MEDIA_IN_USE],sizeof(U32));

		HANDLE_QUERY( OID_GEN_MEDIA_SUPPORTED,
			&m_pLower->m_szCurrentSettings[SID_MEDIA_SUPPORTED],sizeof(U32));
			
		HANDLE_QUERY( OID_GEN_MEDIA_CONNECT_STATUS,
			&m_pLower->m_szCurrentSettings[SID_MEDIA_CONNECTION_STATUS],sizeof(U32));

		HANDLE_QUERY( OID_GEN_MAXIMUM_LOOKAHEAD,
			&m_pLower->m_szCurrentSettings[SID_MAXIMUM_LOOKAHEAD],sizeof(U32));

		HANDLE_QUERY( OID_GEN_MAXIMUM_FRAME_SIZE,
 			&m_pLower->m_szCurrentSettings[SID_MAXIMUM_FRAME_SIZE],sizeof(U32));
       
		HANDLE_QUERY( OID_GEN_MAXIMUM_TOTAL_SIZE,
 			&m_pLower->m_szCurrentSettings[SID_MAXIMUM_TOTAL_SIZE],sizeof(U32));
        
		HANDLE_QUERY( OID_GEN_MAXIMUM_SEND_PACKETS,
 			&m_pLower->m_szCurrentSettings[SID_MAXIMUM_SEND_PACKETS],sizeof(U32));
        
		HANDLE_QUERY( OID_GEN_LINK_SPEED,
 			&m_pLower->m_szCurrentSettings[SID_LINK_SPEED],sizeof(U32));

		HANDLE_QUERY( OID_GEN_XMIT_OK,
			&m_pLower->m_szStatistics[TID_GEN_XMIT_OK],sizeof(U32));
		HANDLE_QUERY( OID_GEN_RCV_OK,
			&m_pLower->m_szStatistics[TID_GEN_RCV_OK],sizeof(U32));
		HANDLE_QUERY( OID_GEN_XMIT_ERROR,
			&m_pLower->m_szStatistics[TID_GEN_XMIT_ERROR],sizeof(U32));
		HANDLE_QUERY( OID_GEN_RCV_ERROR,
			&m_pLower->m_szStatistics[TID_GEN_RCV_ERROR],sizeof(U32));
		HANDLE_QUERY( OID_GEN_RCV_NO_BUFFER,
			&m_pLower->m_szStatistics[TID_GEN_RCV_NO_BUFFER],sizeof(U32));
		HANDLE_QUERY( OID_GEN_RCV_CRC_ERROR,
			&m_pLower->m_szStatistics[TID_GEN_RCV_CRC_ERROR],sizeof(U32));

		HANDLE_QUERY( OID_802_3_RCV_ERROR_ALIGNMENT,
			&m_pLower->m_szStatistics[TID_802_3_RCV_ERROR_ALIGNMENT],sizeof(U32));			
        HANDLE_QUERY( OID_802_3_RCV_OVERRUN,
			&m_pLower->m_szStatistics[TID_802_3_RCV_OVERRUN],sizeof(U32));
		HANDLE_QUERY( OID_802_3_XMIT_ONE_COLLISION,
			&m_pLower->m_szStatistics[TID_802_3_XMIT_ONE_COLLISION],sizeof(U32));
		HANDLE_QUERY( OID_802_3_XMIT_MORE_COLLISIONS,
			&m_pLower->m_szStatistics[TID_802_3_XMIT_MORE_COLLISIONS],sizeof(U32));
		HANDLE_QUERY( OID_802_3_XMIT_DEFERRED,
			&m_pLower->m_szStatistics[TID_802_3_XMIT_DEFERRED],sizeof(U32));
		HANDLE_QUERY( OID_802_3_XMIT_MAX_COLLISIONS,
			&m_pLower->m_szStatistics[TID_802_3_XMIT_MAX_COLLISIONS],sizeof(U32));
		HANDLE_QUERY( OID_802_3_XMIT_UNDERRUN,
			&m_pLower->m_szStatistics[TID_802_3_XMIT_UNDERRUN],sizeof(U32));
		HANDLE_QUERY( OID_802_3_XMIT_HEARTBEAT_FAILURE,
			&m_pLower->m_szStatistics[TID_802_3_XMIT_HEARTBEAT_FAILURE],sizeof(U32));
		HANDLE_QUERY( OID_802_3_XMIT_TIMES_CRS_LOST,
			&m_pLower->m_szStatistics[TID_802_3_XMIT_TIMES_CRS_LOST],sizeof(U32));
		HANDLE_QUERY( OID_802_3_XMIT_LATE_COLLISIONS,
			&m_pLower->m_szStatistics[TID_802_3_XMIT_LATE_COLLISIONS],sizeof(U32));


		HANDLE_QUERY( OID_GEN_MAC_OPTIONS,
 			&m_pLower->m_szCurrentSettings[SID_GEN_MAC_OPTIONS],sizeof(U32));

		HANDLE_QUERY( OID_802_3_PERMANENT_ADDRESS,
			m_pLower->DeviceMacAddress(&szbuffer[0]),ETH_ADDRESS_LENGTH);
		HANDLE_QUERY( OID_802_3_CURRENT_ADDRESS,
			m_pLower->DeviceMacAddress(&szbuffer[0]),ETH_ADDRESS_LENGTH);

/*			case OID_802_3_CURRENT_ADDRESS:
			case OID_802_3_PERMANENT_ADDRESS:
				for(tmp32 = 0;tmp32<ETH_ADDRESS_LENGTH;tmp32++)
					szbuffer[tmp32] = 2;
			panswer = (void*)(&szbuffer[0]); *BytesWritten = ETH_ADDRESS_LENGTH; break;
*/
		HANDLE_QUERY( OID_802_3_MAXIMUM_LIST_SIZE,
 			&m_pLower->m_szCurrentSettings[SID_802_3_MAXIMUM_LIST_SIZE],sizeof(U32));
    
		HANDLE_QUERY( OID_802_3_MULTICAST_LIST,
 			&m_pLower->m_szMulticastList[0][0],
 			m_pLower->m_nMulticasts*ETH_ADDRESS_LENGTH);

		HANDLE_QUERY( OID_GEN_CURRENT_PACKET_FILTER,
 			&m_pLower->m_szCurrentSettings[SID_GEN_CURRENT_PACKET_FILTER],sizeof(U32));

		HANDLE_QUERY( OID_GEN_TRANSMIT_BUFFER_SPACE,
 			&m_pLower->m_szCurrentSettings[SID_GEN_TRANSMIT_BUFFER_SPACE],sizeof(U32));
		HANDLE_QUERY( OID_GEN_RECEIVE_BUFFER_SPACE,
 			&m_pLower->m_szCurrentSettings[SID_GEN_RECEIVE_BUFFER_SPACE],sizeof(U32));

		HANDLE_QUERY( OID_GEN_TRANSMIT_BLOCK_SIZE,
 			&m_pLower->m_szCurrentSettings[SID_GEN_TRANSMIT_BLOCK_SIZE],sizeof(U32));
		HANDLE_QUERY( OID_GEN_RECEIVE_BLOCK_SIZE,
 			&m_pLower->m_szCurrentSettings[SID_GEN_RECEIVE_BLOCK_SIZE],sizeof(U32));
		
		HANDLE_QUERY( OID_GEN_VENDOR_ID,
 			(tmp32=(U32)m_pLower->DeviceVendorID(),&tmp32),sizeof(U32));
		
		HANDLE_QUERY( OID_GEN_VENDOR_DESCRIPTION,
 			VENDOR_DESC,strlen(VENDOR_DESC));
		
		HANDLE_QUERY( OID_GEN_CURRENT_LOOKAHEAD,
 			&m_pLower->m_szCurrentSettings[SID_GEN_CURRENT_LOOKAHEAD],sizeof(U32));
		HANDLE_QUERY( OID_GEN_DRIVER_VERSION,
 			&m_pLower->m_szCurrentSettings[SID_GEN_DRIVER_VERSION],sizeof(U32));
		HANDLE_QUERY( OID_GEN_VENDOR_DRIVER_VERSION,
 			&m_pLower->m_szCurrentSettings[SID_GEN_VENDOR_DRIVER_VERSION],sizeof(U32));
		HANDLE_QUERY( OID_GEN_PROTOCOL_OPTIONS,
 			&m_pLower->m_szCurrentSettings[SID_GEN_PROTOCOL_OPTIONS],sizeof(U32));
			
		default:
			status = NDIS_STATUS_INVALID_OID;
			break;
	} // of switch

	if(status == NDIS_STATUS_SUCCESS)
	{
		NdisMoveMemory(InfoBuffer,panswer,*BytesWritten);
	}
//	RETAILMSG(1, (L"<--DriverQueryInformation\r\n"));
	return status;
}

	
//------------------------------------------------------------------------------
//! \fn NDIS_STATUS NIC_DRIVER_OBJECT::DriverSetInformation(IN NDIS_OID	Oid,IN PVOID InfoBuffer, IN ULONG InfoBufferLength, OUT PULONG BytesRead, OUT PULONG BytesNeeded)
//! \brief Permit to set a value for a specific parameter
//! 
//! \param Oid				Information id wanted to set
//!
//! \param InfoBuffer		Information wanted value
//!
//! \param InfoBufferLength Buffer in value
//!
//! \param BytesRead		Bytes read in buffer
//!
//! \param BytesNeeded		Nb bytes need
//!
//! \return	The operation status
//------------------------------------------------------------------------------
NDIS_STATUS NIC_DRIVER_OBJECT::DriverSetInformation(
	IN NDIS_OID		Oid,
	IN PVOID		InfoBuffer, 
	IN ULONG		InfoBufferLength, 
	OUT PULONG		BytesRead,
	OUT PULONG		BytesNeeded)
{
	
//	RETAILMSG(1, (L"-->DriverSetInformation\r\n"));
	NDIS_STATUS	status = NDIS_STATUS_SUCCESS;

	// pass to lower object, to see if it can handle this request,
	// if it can, return TRUE and set status.
	if(m_pLower->DeviceSetInformation(
		&status,
		Oid,
		InfoBuffer,
		InfoBufferLength,
		BytesRead,
		BytesNeeded)) return status;

	switch (Oid)
	{
		HANDLE_SET( OID_GEN_CURRENT_PACKET_FILTER,sizeof(U32));
		
		case OID_802_3_MULTICAST_LIST:
			NdisMoveMemory(
				&m_pLower->m_szMulticastList[0][0],
				InfoBuffer,
				InfoBufferLength);
			m_pLower->m_nMulticasts = 
				InfoBufferLength / ETH_ADDRESS_LENGTH;
			m_pLower->DeviceOnSetupFilter(
				m_pLower->m_szCurrentSettings[SID_GEN_CURRENT_PACKET_FILTER]
				| NDIS_PACKET_TYPE_MULTICAST);
			break;

		// don't care oids
		case OID_GEN_CURRENT_LOOKAHEAD:
			break;

		case OID_GEN_NETWORK_LAYER_ADDRESSES:
		default:
			status = NDIS_STATUS_INVALID_OID;
		
	}

//	RETAILMSG(1, (L"<--DriverSetInformation\r\n"));
	return status;
}

//------------------------------------------------------------------------------
//! \fn void NIC_DRIVER_OBJECT::DriverEnableInterrupt(void)
//! \brief  Enable interrupt (calling DeviceEnableInterrupt on m_pLower)
//------------------------------------------------------------------------------
void	NIC_DRIVER_OBJECT::DriverEnableInterrupt(void)
{
	m_pLower->DeviceEnableInterrupt();
}

//------------------------------------------------------------------------------
//! \fn void NIC_DRIVER_OBJECT::DriverDisableInterrupt(void)
//! \brief Disable interrupt (calling DriverDisableInterrupt on m_pLower)
//------------------------------------------------------------------------------
void	NIC_DRIVER_OBJECT::DriverDisableInterrupt(void)
{
	m_pLower->DeviceDisableInterrupt();
}

//------------------------------------------------------------------------------
//! \fn BOOL NIC_DRIVER_OBJECT::DriverCheckForHang(void)
//! \brief Reports the state of the network adapter 
//------------------------------------------------------------------------------
BOOL	NIC_DRIVER_OBJECT::DriverCheckForHang(void)
{
	BOOL	bRet = TRUE;
	
	if(m_pLower->CheckCable())
	{
		if(m_pLower->m_Cable == FALSE)
		{
			m_pLower->m_Cable = TRUE;
			RETAILMSG(1, (L"cable attached\r\n"));
			m_pLower->m_szCurrentSettings[SID_MEDIA_CONNECTION_STATUS] = NdisMediaStateConnected;
			NdisMIndicateStatus(m_NdisHandle,
				NDIS_STATUS_MEDIA_CONNECT, 
				(PVOID)0, 0);
			NdisMIndicateStatusComplete(m_NdisHandle);
			
		}
		bRet = FALSE;
	}
	else
	{
		if(m_pLower->m_Cable == TRUE)
		{
			m_pLower->m_Cable = FALSE;
			RETAILMSG(1, (L"cable detached\r\n"));
			m_pLower->m_szCurrentSettings[SID_MEDIA_CONNECTION_STATUS] = NdisMediaStateDisconnected;
			NdisMIndicateStatus(m_NdisHandle,
				NDIS_STATUS_MEDIA_DISCONNECT, 
				(PVOID)0, 0);
			NdisMIndicateStatusComplete(m_NdisHandle);
			
		}
	}
//	if(m_bSystemHang) return TRUE;
//	return m_pLower->DeviceCheckForHang();
	return bRet;
}

//------------------------------------------------------------------------------
//! \fn void NIC_DRIVER_OBJECT::DriverHalt(void)
//! \brief Use to halt driver (calling DeviceHalt on m_pLower)
//------------------------------------------------------------------------------
void NIC_DRIVER_OBJECT::DriverHalt(void)
{
	m_pLower->DeviceHalt();
}

//------------------------------------------------------------------------------
//! \fn NDIS_STATUS NIC_DRIVER_OBJECT::DriverReset(OUT PBOOLEAN	pbAddressingReset)
//! \brief This function reset the driver. Call DeviceReset and then DriverStart)
//! 
//! \param pbAddressingReset	Always true
//!
//! \return	Status of the operation (always NDIS_STATUS_SUCCESS)
//------------------------------------------------------------------------------
NDIS_STATUS NIC_DRIVER_OBJECT::DriverReset(
	OUT PBOOLEAN	pbAddressingReset)
{
	*pbAddressingReset = TRUE;
#ifndef	IMPL_RESET
	return	NDIS_STATUS_SUCCESS;
#endif

	m_pLower->DeviceReset();
	DriverStart();
	m_bSystemHang = 0;
	m_bOutofResources = 0;

	return NDIS_STATUS_SUCCESS;
}

//------------------------------------------------------------------------------
//! \fn NDIS_STATUS	NIC_DRIVER_OBJECT::DriverSend(IN PNDIS_PACKET	pPacket,IN UINT	uFlags)
//! \brief This function send the specified frame.
//! 
//! \param pPacket	Packet to send
//!
//! \param uFlags	Flags (the sent option)
//!
//! \return	Status of the operation
//------------------------------------------------------------------------------
NDIS_STATUS	NIC_DRIVER_OBJECT::DriverSend(
	IN PNDIS_PACKET	pPacket,
	IN UINT			uFlags)
{
//	RETAILMSG(1, (L"-->DriverSend\r\n"));
	if(m_pLower->m_Cable == TRUE)
	{
#if !defined(IMPL_TX_QUEUE)
	if(!m_pLower->DeviceQueryTxResources())
		return NDIS_STATUS_RESOURCES;
	
#endif

	PCQUEUE_GEN_HEADER	pobj;

	if(!(pobj = m_TQueue.Dequeue())) 
	{
		m_bOutofResources = 1;

		return NDIS_STATUS_RESOURCES;
	}
	
	PNDIS_BUFFER	pndisFirstBuffer;
	UINT			uPhysicalBufferCount;
	UINT			uBufferCount;
	UINT			uTotalPacketLength;

	PNDIS_BUFFER	pndisCurrBuffer;
	PU8		pcurr = (PU8)CQueueGetUserPointer(pobj);

	PVOID	ptrBuffer;
	UINT	nBuffer;
	U32		idx,check;

	NdisQueryPacket(
		pPacket, 
		&uPhysicalBufferCount, 
		&uBufferCount,
		&pndisFirstBuffer,
        &uTotalPacketLength);

    if (uTotalPacketLength > ETH_MAX_FRAME_SIZE) {
		DEBUGMSG(1,(L"<EMACB:NDIS_STATUS_FAILURE>\r\n"));
		return NDIS_STATUS_FAILURE;
    }
	
	uPhysicalBufferCount &= 0xFFFF;

	for(idx=0,check=0,pndisCurrBuffer=pndisFirstBuffer;
		idx < uBufferCount;
		idx++, pndisCurrBuffer = pndisCurrBuffer->Next)
	{
		NdisQueryBuffer(
			pndisCurrBuffer,
			&ptrBuffer,
			&nBuffer);

		if(!nBuffer) continue;
		
		NdisMoveMemory(pcurr, ptrBuffer, nBuffer);
		pcurr += nBuffer;
		check += nBuffer;
        
	} // of for gathering buffer

		if(uTotalPacketLength != check) {
			return NDIS_STATUS_FAILURE;
		}

	pobj->pPacket = (PVOID)pPacket;
	pobj->uFlags = uFlags;
	pobj->nLength = uTotalPacketLength;	
	m_pLower->DeviceSend(pobj);
	
#ifdef	IMPL_SEND_INDICATION
	return NDIS_STATUS_PENDING;
#else
	return NDIS_STATUS_SUCCESS;
#endif
	}
	else
		return NDIS_STATUS_FAILURE;
}

//------------------------------------------------------------------------------
//! \fn void NIC_DRIVER_OBJECT::DriverReceiveIndication(int nCurr,PVOID pVoid,int nLength)
//! \brief Reports states for a packket
//! 
//! \param nCurr Context handle supplied by the caller
//!
//! \param pVoid Specifies the base virtual address of the buffered packet header
//!
//! \param nLength Specifies the size, in bytes, of the received packet data.
//------------------------------------------------------------------------------
void	NIC_DRIVER_OBJECT::DriverReceiveIndication(
	int		nCurr,
	PVOID	pVoid,
	int		nLength)
{
	NdisMEthIndicateReceive(
		m_NdisHandle,
		(PNDIS_HANDLE)nCurr,
		(char*)pVoid,
		ETH_HEADER_SIZE,
		((char*)pVoid + ETH_HEADER_SIZE),
		nLength - ETH_HEADER_SIZE,
		nLength - ETH_HEADER_SIZE);
	
	NdisMEthIndicateReceiveComplete(m_NdisHandle);
	return;
}
	
//------------------------------------------------------------------------------
//! \fn void	NIC_DRIVER_OBJECT::DriverSendCompleted(PCQUEUE_GEN_HEADER pObject, NDIS_STATUS Status)
//! \brief Signal the packet specified in parameter as send completed (calling NdisMSendResourcesAvailable and NdisMSendComplete)
//! 
//! \param pObject	Packet descriptor object
//!
//! \param Status	Status of the packet
//------------------------------------------------------------------------------
void	NIC_DRIVER_OBJECT::DriverSendCompleted(
	PCQUEUE_GEN_HEADER	pObject,
	NDIS_STATUS			Status)
{
#ifdef	IMPL_SEND_INDICATION
	NdisMSendResourcesAvailable(m_NdisHandle);
	NdisMSendComplete(
				m_NdisHandle,
				(PNDIS_PACKET)(pObject->pPacket),
				Status);
#endif
	m_TQueue.Enqueue(pObject);
}
	

/********************************************************************************************
 *
 * Trunk Functions
 *
 ********************************************************************************************/

#ifdef	__cplusplus
extern "C" {	// miniport driver trunk functions
#endif

//------------------------------------------------------------------------------
//! \fn NDIS_STATUS MiniportInitialize(...)
//! \brief This function initialize miniport adapter for NDIS layer
//! 
//! \param OpenErrorStatus Points to a variable that MiniportInitialize sets to an NDIS_STATUS_XXX code specifying additional information about the error if MiniportInitialize will return NDIS_STATUS_OPEN_ERROR.
//!
//! \param SelectedMediaIndex Points to a variable in which MiniportInitialize sets the index of the MediumArray element that specifies the medium type the driver or its network adapter uses.
//!
//! \param MediaArray Specifies an array of NdisMediumXXX values from which MiniportInitialize selects one that its network adapter supports or that the driver supports as an interface to higher-level drivers.
//!
//! \param MediaArraySize Specifies the number of elements at MediumArray.
//!
//! \param MiniportHandle Specifies a handle identifying the miniport's network adapter
//!
//! \param WrapperConfigHandle Specifies a handle used only during initialization for calls to NdisXXX configuration and initialization functions.
//!
//! \return	Operation NDIS status
//------------------------------------------------------------------------------
NDIS_STATUS MiniportInitialize(
	OUT PNDIS_STATUS OpenErrorStatus,
	OUT PUINT SelectedMediaIndex, 
	IN PNDIS_MEDIUM MediaArray, 
	IN UINT MediaArraySize,
    IN NDIS_HANDLE MiniportHandle, 
	IN NDIS_HANDLE WrapperConfigHandle)
{
	DEBUGMSG(1,(L"<EMACB: +MiniportIntialize>\r\n"));

	static BOOL bInitDone = FALSE;
	if (bInitDone == FALSE)
	{
		NIC_DRIVER_OBJECT	*pnic;
	
		if(!(pnic = new NIC_DRIVER_OBJECT(
			MiniportHandle,WrapperConfigHandle)))	
			return	NDIS_STATUS_FAILURE;
		
		C_Exception	*pexp;
		TRY
		{
			pnic->EDriverInitialize(
				OpenErrorStatus,
				SelectedMediaIndex, 
				MediaArray, 
				MediaArraySize);
			
			pnic->DriverStart();	
			
			FI;
		}
		CATCH(pexp)
		{
			pexp->PrintErrorMessage();
			CLEAN(pexp);
			delete pnic;
			RETAILMSG(1, (L"-->MiniportInitialize FAILURE"));
			return NDIS_STATUS_FAILURE;
		}
		bInitDone = TRUE;
	}
	else
	{
		return NDIS_STATUS_FAILURE;
	}

	DEBUGMSG(1,(L"<EMACB:--MiniportInitialize>\r\n"));
	return NDIS_STATUS_SUCCESS;
}

//------------------------------------------------------------------------------
//! \fn void MiniportISRHandler(OUT PBOOLEAN InterruptRecognized, OUT PBOOLEAN QueueInterrupt, IN  NDIS_HANDLE MiniportContext)
//! \brief This function is a required function if the driver's network adapter generates interrupts
//! 
//! \param InterruptRecognized Points to a variable in which MiniportISR returns whether the network adapter actually generated the interrupt.
//! 
//! \param QueueInterrupt Points to a variable that MiniportISR sets to TRUE if the MiniportHandleInterrupt function should be called to complete the interrupt-driven I/O operation.
//!
//! \param MiniportContext Specifies the handle to a miniport-allocated context area in which the driver maintains per-network adapter state, set up by MiniportInitialize.
//------------------------------------------------------------------------------
void MiniportISRHandler(
		OUT PBOOLEAN InterruptRecognized, 
		OUT PBOOLEAN QueueInterrupt,
		IN  NDIS_HANDLE MiniportContext)
{
	((NIC_DRIVER_OBJECT*)MiniportContext)->DriverIsr(
		InterruptRecognized,
		QueueInterrupt);
}

//------------------------------------------------------------------------------
//! \fn VOID MiniportInterruptHandler(IN NDIS_HANDLE MiniportContext)
//! \brief This function is a required function if a driver's network adapter generates interrupts.
//! 
//! \param MiniportContext Specifies the handle to a miniport-allocated context area in which the driver maintains per-network adapter state, set up by MiniportInitialize.
//!
//! MiniportInterruptHandler does the deferred processing of all outstanding interrupt operations.
//------------------------------------------------------------------------------
VOID	MiniportInterruptHandler(
	IN NDIS_HANDLE  MiniportContext)
{
	((NIC_DRIVER_OBJECT*)MiniportContext)->DriverInterruptHandler();
}

//------------------------------------------------------------------------------
//! \fn NDIS_STATUS MiniportQueryInformation(...)
//! \brief This function is a required function that returns information about the capabilities and status of the driver and/or its network adapter.
//! 
//! \param MiniportContext Specifies the handle to a miniport-allocated context area in which the driver maintains per-network adapter state, set up by MiniportInitialize.
//! 
//! \param Oid Specifies the system-defined OID_XXX code designating the global query operation the driver should carry out.
//! 
//! \param InfoBuffer Points to a buffer in which MiniportQueryInformation should return the OID-specific information.
//! 
//! \param InfoBufferLength Specifies the number of bytes at InformationBuffer.
//!
//! \param BytesWritten Points to a variable that MiniportQueryInformation sets to the number of bytes it is returning at InformationBuffer.
//!
//! \param BytesNeeded Points to a variable that MiniportQueryInformation sets to the number of additional bytes it needs to satisfy the request if InformationBufferLength is less than Oid requires.
//!
//! \return	Operation NDIS status
//------------------------------------------------------------------------------
NDIS_STATUS MiniportQueryInformation(
	IN NDIS_HANDLE	MiniportContext,
	IN NDIS_OID		Oid,
	IN PVOID		InfoBuffer, 
	IN ULONG		InfoBufferLength, 
	OUT PULONG		BytesWritten,
	OUT PULONG		BytesNeeded)
{
	return ((NIC_DRIVER_OBJECT*)MiniportContext)->DriverQueryInformation(
			Oid,
			InfoBuffer, 
			InfoBufferLength, 
			BytesWritten,
			BytesNeeded);
}

//------------------------------------------------------------------------------
//! \fn NDIS_STATUS MiniportSetInformation(...)
//! \brief This function permit to set configuration to Miniport context
//!
//! \param MiniportContext Specifies the handle to a miniport-allocated context area in which the driver maintains per-network adapter state, set up by MiniportInitialize.
//! 
//! \param Oid Specifies the system-defined OID_XXX code designating the global query operation the driver should carry out.
//! 
//! \param InfoBuffer Points to a buffer in which MiniportSetInformation should return the OID-specific information.
//! 
//! \param InfoBufferLength Specifies the number of bytes at InformationBuffer.
//!
//! \param BytesRead Points to a variable that MiniportSetInformation sets to the number of bytes it read from the buffer at InformationBuffer.
//!
//! \param BytesNeeded Points to a variable that MiniportSetInformation sets to the number of additional bytes it needs to satisfy the request if InformationBufferLength is less than Oid requires.
//!
//! \return	Operation NDIS status
//!
//! This function is a required function that allows bound protocol drivers, 
//! or NDIS, to request changes in the state information that the miniport maintains
//! for particular object identifiers, such as changes in multicast addresses.
//------------------------------------------------------------------------------
NDIS_STATUS MiniportSetInformation(
	IN NDIS_HANDLE	MiniportContext, 
	IN NDIS_OID		Oid,
	IN PVOID		InfoBuffer, 
	IN ULONG		InfoBufferLength, 
	OUT PULONG		BytesRead,
	OUT PULONG		BytesNeeded)
{
	return ((NIC_DRIVER_OBJECT*)MiniportContext)->DriverSetInformation(
			Oid,
			InfoBuffer, 
			InfoBufferLength, 
			BytesRead,
			BytesNeeded);
}

//------------------------------------------------------------------------------
//! \fn VOID MiniportEnableInterrupt(IN NDIS_HANDLE  MiniportContext)
//! \brief MiniportEnableInterrupt is an optional function, supplied by some drivers of network adapters that support dynamic enabling and disabling of interrupts but do not share an IRQ.
//! 
//! \param MiniportContext Specifies the handle to a miniport-allocated context area in which the driver maintains per-network adapter state, set up by MiniportInitialize.
//------------------------------------------------------------------------------
VOID	MiniportEnableInterrupt(
	IN NDIS_HANDLE  MiniportContext)
{
	((NIC_DRIVER_OBJECT*)MiniportContext)->DriverEnableInterrupt();
}

//------------------------------------------------------------------------------
//! \fn VOID	MiniportDisableInterrupt(IN NDIS_HANDLE  MiniportContext)
//! \brief This functionis an optional function, supplied by drivers of network adapters that support dynamic enabling and disabling of interrupts but do not share an IRQ.
//! 
//! \param MiniportContext Specifies the handle to a miniport-allocated context area in which the driver maintains per-network adapter state, set up by MiniportInitialize.
//------------------------------------------------------------------------------
VOID	MiniportDisableInterrupt(
	IN NDIS_HANDLE  MiniportContext)
{
	((NIC_DRIVER_OBJECT*)MiniportContext)->DriverDisableInterrupt();
}

//------------------------------------------------------------------------------
//! \fn BOOLEAN	MiniportCheckForHang(IN NDIS_HANDLE MiniportContext)
//! \brief This function is an optional function that reports the state of the network adapter or monitors the responsiveness of an underlying device driver.
//! 
//! \param MiniportContext Specifies the handle to a miniport-allocated context area in which the driver maintains per-network adapter state, set up by MiniportInitialize.
//!
//! \return	MiniportCheckForHang returns TRUE if the driver determines that its network adapter is not operating or if an intermediate driver determines that the underlying device driver is unresponsive.
//!
//! This function call DriverCheckForHang() function
//------------------------------------------------------------------------------
BOOLEAN	MiniportCheckForHang(
	IN NDIS_HANDLE  MiniportContext)
{
	return ((NIC_DRIVER_OBJECT*)MiniportContext)->DriverCheckForHang();
}
 
//------------------------------------------------------------------------------
//! \fn VOID MiniportHalt(IN NDIS_HANDLE  MiniportContext)
//! \brief MiniportHalt is a required function that de-allocates resources when the network adapter is removed and halts the network adapter.
//! 
//! \param MiniportContext Specifies the handle to a miniport-allocated context area in which the driver maintains per-network adapter state, set up by MiniportInitialize.
//!
//! This function call DriverHalt() function
//------------------------------------------------------------------------------
VOID	MiniportHalt(
	IN NDIS_HANDLE  MiniportContext)
{
	((NIC_DRIVER_OBJECT*)MiniportContext)->DriverHalt();
}
 
//------------------------------------------------------------------------------
//! \fn NDIS_STATUS MiniportReset(OUT PBOOLEAN  AddressingReset, IN NDIS_HANDLE  MiniportContext)
//! \brief This function is a required function that issues a hardware reset to the network adapter and/or resets the driver's software state.
//!
//! \param AddressingReset Points to a variable that MiniportReset sets to TRUE if the NDIS library should call MiniportSetInformation to restore addressing information to the current values.
//! 
//! \param MiniportContext Specifies the handle to a miniport-allocated context area in which the driver maintains per-network adapter state, set up by MiniportInitialize.
//!
//! \return	The NDIS operation status
//------------------------------------------------------------------------------
NDIS_STATUS MiniportReset(
    OUT PBOOLEAN  AddressingReset,
    IN NDIS_HANDLE  MiniportContext)
{
	return ((NIC_DRIVER_OBJECT*)MiniportContext)->DriverReset(AddressingReset);
}

//------------------------------------------------------------------------------
//! \fn NDIS_STATUS	MiniportSend(IN NDIS_HANDLE	MiniportContext,IN PNDIS_PACKET	Packet,IN UINT Flags)
//! \brief This function transfers a protocol-supplied packet over the network.
//! 
//! \param MiniportContext Specifies the handle to a miniport-allocated context area in which the driver maintains per-network adapter state, set up by MiniportInitialize.
//!
//! \param Packet Points to a packet descriptor specifying the data to be transmitted.
//!
//! \param Flags Specifies the packet flags, if any, set by the protocol.
//!
//! \return	The NDIS operation status
//!
//! Calls DriverSend() function
//------------------------------------------------------------------------------
NDIS_STATUS	MiniportSend(
	IN NDIS_HANDLE	MiniportContext,
	IN PNDIS_PACKET	Packet,
	IN UINT			Flags)
{
	return ((NIC_DRIVER_OBJECT*)MiniportContext)->DriverSend(Packet,Flags);
}


#ifdef	__cplusplus   
}	// of miniport trunk functions
#endif


/********************************************************************************************
 *
 * DriverEntry
 *
 ********************************************************************************************/


//------------------------------------------------------------------------------
//! \fn DriverEntry(IN PDRIVER_OBJECT	pDriverObject, IN PUNICODE_STRING	pRegistryPath)
//! \brief DriverEntry is a required function that the system calls first in any NDIS driver.
//! 
//! \param pDriverObject Points to a system-supplied parameter.
//!
//! \param pRegistryPath Points to a second system-supplied parameter.
//!
//! \return	The NDIS operation status
//!
//! This function registring all Miniport callback supported by emacb driver
//------------------------------------------------------------------------------
extern "C" NTSTATUS DriverEntry(
	IN PDRIVER_OBJECT	pDriverObject, 
	IN PUNICODE_STRING	pRegistryPath)
{
	NDIS_STATUS		status;
	NDIS_HANDLE		hwrapper;
	NDIS40_MINIPORT_CHARACTERISTICS	ndischar;

	RETAILMSG(1,(L"Loading WinCE driver for ATMEL EMACB controller\r\n"));

	NdisMInitializeWrapper(
		&hwrapper, 
		pDriverObject,
		pRegistryPath,
		NULL);

	memset((void*)&ndischar,0,sizeof(ndischar));
    
    ndischar.Ndis30Chars.MajorNdisVersion = PRJ_NDIS_MAJOR_VERSION;
	ndischar.Ndis30Chars.MinorNdisVersion = PRJ_NDIS_MINOR_VERSION;
    
	ndischar.Ndis30Chars.InitializeHandler = MiniportInitialize;
    ndischar.Ndis30Chars.ResetHandler      = MiniportReset;
    ndischar.Ndis30Chars.CheckForHangHandler = MiniportCheckForHang;
    ndischar.Ndis30Chars.HaltHandler         = MiniportHalt;
    ndischar.Ndis30Chars.HandleInterruptHandler   = MiniportInterruptHandler;
    ndischar.Ndis30Chars.ISRHandler               = MiniportISRHandler;
    ndischar.Ndis30Chars.QueryInformationHandler  = MiniportQueryInformation;
    ndischar.Ndis30Chars.SetInformationHandler	  = MiniportSetInformation;
    ndischar.Ndis30Chars.SendHandler              = MiniportSend;


	if((status = NdisMRegisterMiniport(
		hwrapper,
		(PNDIS_MINIPORT_CHARACTERISTICS)&ndischar,
		sizeof(ndischar)) != NDIS_STATUS_SUCCESS))
	{
		NdisTerminateWrapper(hwrapper,NULL);
		return status;
	}


#ifndef	IMPL_DLL_ENTRY	
	INIT_EXCEPTION();
#endif

    return NDIS_STATUS_SUCCESS;
}
//! @}
//! @}
