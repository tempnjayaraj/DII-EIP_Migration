//-----------------------------------------------------------------------------
//! \addtogroup	USBFN
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x_usbfn.h
//!
//! \brief		declaration for the USB device (Host controller class)
//! 
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/AT91SAM926x_usbfn.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

#ifndef __AT91SAM926X_USBFN_H__
#define  __AT91SAM926X_USBFN_H__

//#define USE_RAS

#include "at91sam926x.h"
#include <csync.h>
#include <cmthread.h>

#ifndef _PREFAST_
#include <CRegEdit.h>
#else /// \bug Somehow Prefast doesn't like CRegEdit.h. So we mustn't include it when doing the PREFAST check.
class CRegistryEdit //Dummy CRegistryEdit Class for making prefast happy !
{
public:
	CRegistryEdit( LPCTSTR RegPath )
    {
       
    }
 
    BOOL    GetRegValue( LPCWSTR lpcName, LPBYTE lpData, DWORD dwDataLen )
    {
        return FALSE;
    }


    BOOL    RegQueryValueEx( LPCWSTR lpcName,
                             PDWORD pdwType,
                             LPBYTE lpData,
                             PDWORD pdwDataLen )
    {
      
        return (ERROR_SUCCESS );
    };
	BOOL IsKeyOpened()
    {
        return FALSE;
    }

private:
    HKEY    m_hDevKey;
};



#endif

#include <CRefCon.h>
#include <usbfn.h>
// For RAS entry management
#ifdef USE_RAS
#include <notify.h>
#include <ras.h>
#include <Unimodem.h>
#include <Netui.h>
#endif



#ifndef SHIP_BUILD
#define STR_MODULE _T("AT91SAM926x_usbfn!")
#define SETFNAME() LPCTSTR pszFname = STR_MODULE _T(__FUNCTION__) _T(":")
#else
#define SETFNAME()
#endif

#define MAX_ENDPOINT_NUMBER 0x05
static const WORD g_EndpointMaxSize[MAX_ENDPOINT_NUMBER] = {8,64,64,64,64};


// Registry Value.
#define AT91SAM_USBFUNCTION_PRIORITY_VALNAME    TEXT("Priority256")
#define AT91SAM_USBFUNCTION_PRIORITY_VALTYPE    REG_DWORD


//
#define AT91SAM_USBFUNCTION_DRIVER_VALNAME			TEXT("Drivers\\USB\\FunctionDrivers")
#define AT91SAM_USBFUNCTION_DRIVER_VALTYPE			REG_SZ

#define AT91SAM_USBFUNCTION_DRIVERCLIENT_VALNAME		TEXT("DefaultClientDriver")
#define AT91SAM_USBFUNCTION_DRIVERCLIENT_VALTYPE		REG_SZ

#define AT91SAM_USBFUNCTION_DRIVERNAME_VALNAME		TEXT("FriendlyName")
#define AT91SAM_USBFUNCTION_DRIVERNAME_VALTYPE		REG_SZ

//
#define AT91SAM_USBFUNCTION_DEFAULT_CONNECTION_NAME 			TEXT("USB Cable")
#define AT91SAM_USBFUNCTION_DEFAULT_DIRECT_CONNECT_TIMEOUT_SECONDS		5

//
// used only for debug messages
#define AT91SAM_USBFUNCTION_DRIVER_NAME		TEXT("USBFunction")



//
#define AT91SAM_USBFUNCTION_DEFAULT_PRIORITY    100

class AT91SAMEndpoint;

class CEndpointContainer : public CStaticContainer <AT91SAMEndpoint, MAX_ENDPOINT_NUMBER>
{
};
class AT91SAMUsbDevice :public CEndpointContainer, public CRegistryEdit, public CMiniThread {
public:
    AT91SAMUsbDevice(LPCTSTR lpActivePath);
    virtual ~AT91SAMUsbDevice();
    virtual DWORD Init(PVOID pvMddContext, PUFN_MDD_INTERFACE_INFO pMddInterfaceInfo, PUFN_PDD_INTERFACE_INFO pPddInterfaceInfo);
//  PDD interface.
    virtual BOOL DeleteAllEndpoint();
// Endpoint Function.
    virtual DWORD IsEndpointSupportable (DWORD dwEndpoint,UFN_BUS_SPEED Speed,PUSB_ENDPOINT_DESCRIPTOR pEndpointDesc,
            BYTE bConfigurationValue=1, BYTE bInterfaceNumber=0, BYTE bAlternateSetting=0 );
    virtual DWORD InitEndpoint(DWORD dwEndpoint,UFN_BUS_SPEED Speed,PUSB_ENDPOINT_DESCRIPTOR pEndpointDesc,
            BYTE bConfigurationValue=1, BYTE bInterfaceNumber=0, BYTE bAlternateSetting=0 );
    virtual DWORD DeinitEndpoint(DWORD dwEndpoint );
    virtual DWORD StallEndpoint(DWORD dwEndpoint );
    virtual DWORD ClearEndpointStall( DWORD dwEndpoint );
    virtual DWORD ResetEndpoint(DWORD dwEndpoint );
    virtual DWORD IsEndpointHalted( DWORD dwEndpoint, PBOOL pfHalted );
    virtual DWORD IssueTransfer(DWORD  dwEndpoint,PSTransfer pTransfer );
    virtual DWORD AbortTransfer(DWORD dwEndpoint, PSTransfer pTransfer);
    
//  Endpoint Ctrl Special
    virtual DWORD SendControlStatusHandshake(DWORD dwEndpoint);
//  Device Function.
    virtual DWORD Start();
    virtual DWORD Stop();
    virtual BOOL IsCableAttached();
    virtual DWORD  SetAddress( BYTE  bAddress );
    virtual void PowerDown();
    virtual void PowerUp() ;
    virtual void  SetPowerState( CEDEVICE_POWER_STATE cpsNew ) ;
    virtual DWORD IOControl( IOCTL_SOURCE source, DWORD dwCode, PBYTE  pbInBuf, DWORD cbInBuf, PBYTE pbOutBuf, DWORD cbOutBuf,PDWORD  pcbActualOutBuf );

#ifdef USE_RAS	
// For Ras enumeration and configuration
	static DWORD RasInitThread(LPVOID pThreadParam);
	DWORD RasInit();
	DWORD FindTSPDevice(HLINEAPP hLineApp, DWORD dwNumLines, DWORD dwAPIVersion, DWORD dwExtVersion, LPWSTR lpszTSPName, LPWSTR lpszTSPLineName);
	void WaitForReply (HLINEAPP hLineApp);
	LONG ModifyDevConfig (HLINEAPP hLineApp, HLINE hLine, PUNIMDM_CHG_DEVCFG pUCD);
	LPVARSTRING GetDevConfig (DWORD dwDeviceID, LPWSTR pszDeviceClassName);
	DWORD SetUsbFunctionAsDefaultConn (LPTSTR lpStrFriendlyName);
	void ModifyDefaultRasEntry (LPTSTR lpStrFriendlyName, RASENTRY *RasEntry);
	BOOL ModifyRetryTimeout(LPTSTR lpStrFriendlyName, LPVARSTRING  *pDevCfg);
	void CreateRegDefaultConnection();
#endif

    // Interrupt
    BOOL    EnableEndpointInterrupt(DWORD dwEndpointIndex,BOOL bEnable);


    // 
    void MddTransferComplete(PSTransfer pTransfer) {
        SETFNAME();
        if (m_pvMddContext) {
            DEBUGMSG(ZONE_FUNCTION, (_T("%s MddTransferComplete pTransfer:0x%x"),pszFname,pTransfer));
            m_pfnNotify(m_pvMddContext, UFN_MSG_TRANSFER_COMPLETE, (DWORD) pTransfer);
        }
        else 
            DebugBreak();
    }
    BOOL DeviceNotification( DWORD dwMsg, DWORD dwParam ) {
        SETFNAME();
        if (m_pvMddContext) {
            DEBUGMSG(ZONE_FUNCTION, (_T("%s DeviceNotification dwMsg:0x%x,dwParam:0x%x"),pszFname,dwMsg,dwParam));
            return m_pfnNotify(m_pvMddContext, dwMsg, dwParam);
        }
        else {
            DebugBreak();
            return FALSE;
        }
    }

	DWORD USBDetectionThread();

	AT91PS_UDP m_pUDP;
	
protected:
	virtual void EnablePullUp() = 0;
	virtual void DisablePullUp() = 0;
	virtual BOOL InitializeUSBDetectionInterrupt() = 0;
	virtual void DeinitializeUSBDetectionInterrupt() = 0;
    	virtual void PowerMgr(BOOL bOff);
    
	BOOL    m_fIsCableAttached;

    // IST
    DWORD       m_dwPriority;


    // Peripheral
    DWORD       m_dwPeriphSysIntr;
    HANDLE      m_hPeriphEvent;


    PVOID       m_pvMddContext;

    // Protected Fucntion
    BOOL        HardwareInit();
    BOOL        ReInit(); // For Cable Detach & Attach , We have to re-init the Device Controller.

    PFN_UFN_MDD_NOTIFY      m_pfnNotify;
    CEDEVICE_POWER_STATE    m_CurPowerState;
    HANDLE                  m_hParent;
	HANDLE m_hDetectionEvent;
	DWORD m_dwDetectionSysintr;

private:
	HANDLE m_USBDetectionThread;
	BOOL m_bTerminateDetectionThread;
    DWORD ThreadRun();
	DWORD m_dwLastFrameNumberDate;
	DWORD m_dwLastFrameNumber;
	AT91PS_PMC m_pPMC;
};


AT91SAMUsbDevice * CreateAT91SAMUsbDevice(LPCTSTR lpActivePath);

#endif
//! @}