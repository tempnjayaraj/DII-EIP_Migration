//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		I2CDriver.c
//!
//! \brief		I2C driver for AT91SAM926x chipset
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/I2C/I2CDriver.c $
//!   $Author: pblanchard $
//!   $Revision: 1090 $
//!   $Date: 2007-07-13 07:07:28 -0700 (Fri, 13 Jul 2007) $
//! \endif
//!
//! 
//-----------------------------------------------------------------------------
//! \addtogroup	I2C
//! @{
//!


// System include
#include <windows.h>
#include <memory.h>
#include <nkintr.h>
#include <CEDDK.h>
#include <devload.h>

// Local include
#include "AT91SAM926x.h"
#include "lib_AT91SAM926x.h"
#include "AT91SAM926x_oal_intr.h"
#include "AT91SAM926x_oal_ioctl.h"
#include "AT91SAM926x_i2c_ioctl.h"
#include "I2C_DbgZones.h"
#include "I2CDriver.h"

extern int DisableInt();
extern int EnableInt();
#define DISABLE_INTERRUPT(x) {if (x) DisableInt(); }
#define ENABLE_INTERRUPT(x) {if (x) EnableInt(); }


// Default values
#define AT91C_TWI_TIMEOUT 1000
#define AT91C_TWI_DEFAULT_CLOCK_RATE 200000


// Registry entries
#define I2C_PORT_KEYPATH_VAL_NAME				TEXT("Key")

#define I2C_TRANSFERT_RATE_VAL_NAME				TEXT("TransfertRate")
#define I2C_TRANSFERT_RATE_VAL_LEN				sizeof( DWORD )

#define TWI_READ_TIMEOUT	100
#define TWI_WRITE_TIMEOUT	100
// Global variable

// The dpCurSettings structure for debug zones
DBGPARAM dpCurSettings =
{
    TEXT("I2C"),
    {
        TEXT("Init"),
        TEXT("DeInit"),
        TEXT("Open"),
        TEXT("Close"),
        TEXT("Read"),
        TEXT("Write"),
        TEXT("Seek"),
        TEXT("IOCtl"),
        TEXT("na"),
        TEXT("na"),
        TEXT("na"),
        TEXT("na"),
        TEXT("na"),
        TEXT("na"),
        TEXT("Warning"),
        TEXT("Error")
    }
    , MASK_INIT | MASK_DEINIT | MASK_INFO | MASK_ERROR
};


static void setTwiClock(AT91PS_TWI pTwi, DWORD dwClockDiv);
static int twiReset(T_I2CINIT_STRUCTURE *pDeviceContext,DWORD dwTWIClkCfg);
static DWORD computeTwiClock(DWORD dwTransfertRate);

extern BOOL InitI2CVirtualAddresses(T_I2CINIT_STRUCTURE * pDeviceContext);
extern void DeinitI2CVirtualAddresses(T_I2CINIT_STRUCTURE * pDeviceContext);
extern DWORD I2CProcSpecificGetBaseAddress(void);

//-----------------------------------------------------------------------------
//! \fn			BOOL WINAPI I2C_DllEntry( HANDLE hinstDLL, DWORD dwReason, LPVOID lpvReserved)
//!
//! \brief		This function is the entry point of the Dll driver
//!
//! \param		hinstDll	DLL instance
//! \param		dwReason	Reason of the call
//! \param		lpvReserved	Not used
//!
//! \return		\e TRUE when all is good
//!	\return		\e FALSE when all is bad
//!
//! This function intialize debug zone when called with the DLL_PROCESS_ATTACH reason
//-----------------------------------------------------------------------------
BOOL WINAPI I2C_DllEntry(HANDLE hinstDLL, DWORD dwReason, LPVOID lpvReserved)
{
    switch(dwReason)
    {
    case DLL_PROCESS_ATTACH:
        DEBUGREGISTER((HMODULE)hinstDLL);
        DEBUGMSG(ZONE_INFO,(TEXT("I2C Driver: DLL_PROCESS_ATTACH\r\n")));
   	break;
    case DLL_THREAD_ATTACH:
        DEBUGMSG(ZONE_INFO,(TEXT("I2C Driver: DLL_THREAD_ATTACH\r\n")));
        break;
    case DLL_THREAD_DETACH:
        DEBUGMSG(ZONE_INFO,(TEXT("I2C Driver: DLL_THREAD_DETACH\r\n")));
        break;
    case DLL_PROCESS_DETACH:
        DEBUGMSG(ZONE_INFO,(TEXT("I2C Driver: DLL_PROCESS_DETACH\r\n")));
        break;
#ifdef UNDER_CE
    case DLL_PROCESS_EXITING:
        DEBUGMSG(ZONE_INFO,(TEXT("I2C Driver: DLL_PROCESS_EXITING\r\n")));
        break;
    case DLL_SYSTEM_STARTED:
        DEBUGMSG(ZONE_INFO,(TEXT("I2C Driver: DLL_SYSTEM_STARTED\r\n")));
        break;
#endif
    }

    return TRUE;
}


//-----------------------------------------------------------------------------
//! \fn			DWORD I2C_Init(LPCTSTR pContext, LPCVOID lpvBusContext)
//!
//! \brief		This function initializes the device.
//!
//! \param		pContext		Pointer to a string containing the registry path to the active key for the stream interface driver.
//! \param		lpvBusContext	Potentially process-mapped pointer passed as the 
//!								fourth parameter to ActivateDeviceEx. If this driver 
//!								was loaded through legacy mechanisms, then lpvBusContext 
//!								is zero. This pointer, if used, has only been mapped 
//!								again as it passes through the protected server library (PSL).
//!								The <b>I2C_Init</b> function is responsible for performing all protection 
//!								checking. In addition, any pointers referenced through lpvBusContext 
//!								must be remapped with the <b>MapCallerPtr</b> function before they 
//!								can be dereferenced.
//!
//! \return		Returns a handle to the device context created if successful. 
//!	\return		\e zero if not successful.
//!
//! Device Manager calls this function as a result of a call to the ActivateDeviceEx 
//! function. When the user starts using a device, such as inserting a PC Card, 
//! Device Manager calls this function to initialize the device. Applications do not call this function. 
//-----------------------------------------------------------------------------
DWORD I2C_Init(LPCTSTR pContext, LPCVOID lpvBusContext)
{
	BOOL bRet = TRUE;
	T_I2CINIT_STRUCTURE *pDeviceContext = (T_I2CINIT_STRUCTURE *)LocalAlloc(LMEM_ZEROINIT|LMEM_FIXED, sizeof(T_I2CINIT_STRUCTURE));

	if (pDeviceContext == NULL)
	{
		return 0;
	}

	// Critical section to avoid simultaneous I2C registers access
	InitializeCriticalSection(& pDeviceContext->scI2CAccess);

	if( InitI2CVirtualAddresses(pDeviceContext) != FALSE)
	{
		// Enable Peripheral clock in PMC for  TWI		
		pDeviceContext->pPMCReg->PMC_PCER = I2CProcSpecificGetBaseAddress();

	// Hardware chipset initalisation
		if (!I2C_InitHW(pDeviceContext->pPMCReg))
		{
			DEBUGMSG(ZONE_ERROR,(TEXT(" I2C_Init : I2C_InitHW() failed")));
			bRet = FALSE;
		}
		else
		{
	//
	// Configure TWI in master mode
	//

	EnterCriticalSection (& pDeviceContext->scI2CAccess);

   	// Reset peripheral
	pDeviceContext->pTWIReg->TWI_CR = AT91C_TWI_SWRST;

	// Disable all interrupts
	pDeviceContext->pTWIReg->TWI_IDR = AT91C_TWI_TXCOMP | AT91C_TWI_RXRDY | AT91C_TWI_TXRDY | AT91C_TWI_OVRE | AT91C_TWI_UNRE | AT91C_TWI_NACK;



	LeaveCriticalSection(& pDeviceContext->scI2CAccess);

	// No device opened
	pDeviceContext->dwOpenCount = 0;
	pDeviceContext->dwShareMode = FILE_SHARE_READ | FILE_SHARE_WRITE;

	// Load defaults from registry;
	LoadRegistry(pContext, pDeviceContext);

	EnterCriticalSection (& pDeviceContext->scI2CAccess);			
			setTwiClock(pDeviceContext->pTWIReg, pDeviceContext->dwDefaultTWIClkDiv);
	Sleep(2);
	LeaveCriticalSection (& pDeviceContext->scI2CAccess);
		}
	}
	else
	{
		DEBUGMSG(ZONE_ERROR,(TEXT(" I2C_Init : InitI2CVirtualAddresses() failed")));
		bRet = FALSE;
	}

	if (bRet == FALSE)
	{
		DeinitI2CVirtualAddresses(pDeviceContext);
	DEBUGMSG(ZONE_ERROR,(TEXT("I2C Driver: Intialisation failed\r\n")));

	return (DWORD)NULL;
	}
	else
	{
		return (DWORD)pDeviceContext;
	}
}


//-----------------------------------------------------------------------------
//! \fn			BOOL I2C_Deinit(T_I2CINIT_STRUCTURE *pDeviceContext)
//!
//! \brief		This function uninitializes the device.
//!
//! \param		pDeviceContext	Pointer to the the device init context. The I2C_Init (Device Manager)
//!								function creates and returns this pointer.
//!
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//!
//! When the user stops using a device, such as when a PC Card is removed from its socket, 
//! Device Manager calls this function. Applications do not call this function. Device Manager 
//! calls the I2C_Deinit driver function as a result of a call to the DeactivateDevice function. 
//! Your stream interface driver should free any resources it has allocated, and then terminate.
//-----------------------------------------------------------------------------
BOOL I2C_Deinit(T_I2CINIT_STRUCTURE *pDeviceContext)
{
	BOOL bRet = TRUE;



	if (pDeviceContext != NULL)
	{
		// All devices have to be unloaded before deinitialising the driver
		if (pDeviceContext->dwOpenCount != 0)
		{
			bRet = FALSE;
		}
		else
		{
			DeinitI2CVirtualAddresses(pDeviceContext);
			DeleteCriticalSection(&pDeviceContext->scI2CAccess);

			if (LocalFree(pDeviceContext) != NULL)
			{
				bRet = FALSE;
			}
		}

	}

	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn			DWORD I2C_Open(T_I2CINIT_STRUCTURE *pDeviceContext, DWORD AccessCode, DWORD ShareMode)
//!
//! \brief		This function opens a device for reading, writing, or both.
//!
//! \param		pDeviceContext	Pointer to the the device open context. The <b>I2C_Init</b> (Device Manager)
//!								function creates and returns this identifier.
//! \param		AccessCode		Access code for the device. The access is a combination
//!								of read and write access from <b>CreateFile</b>. 
//! \param		ShareMode		File share mode of the device. The share mode is a combination 
//!								of read and write access sharing from <b>CreateFile</b>. 
//!
//! \return		This function returns a handle that identifies the open context of the device 
//!				to the calling application. If your device can be opened multiple times, use 
//!				this handle to identify each open context.
//!
//! When this function executes, your device should allocate the resources that it needs for 
//! each open context and prepare for operation. This might involve preparing the device for 
//! reading or writing and initializing data structures it uses for operation.
//-----------------------------------------------------------------------------
DWORD I2C_Open(T_I2CINIT_STRUCTURE *pDeviceContext, DWORD AccessCode, DWORD ShareMode)
{
	T_I2COPEN_STRUCTURE *pOpenContext =  NULL;

	// Parameter check
	if (pDeviceContext == NULL)
	{
		ERRORMSG(ZONE_ERROR, (TEXT("I2C Driver: pDeviceContext is NULL\r\n")));
		return (DWORD) NULL;
	}

	// Share access right check
	if (pDeviceContext->dwOpenCount != 0 && pDeviceContext->dwShareMode == 0)
	{
		DEBUGMSG(ZONE_OPEN, (TEXT("I2C Driver: No share access for this device\r\n")));
		SetLastError(ERROR_SHARING_VIOLATION);
		return (DWORD) NULL;
	}

	if (pDeviceContext->dwOpenCount != 0 && ShareMode == 0)
	{
		DEBUGMSG(ZONE_OPEN, (TEXT("I2C Driver: this device is already open \r\n")));
		SetLastError(ERROR_SHARING_VIOLATION);
		return (DWORD) NULL;
	}

	pOpenContext = (PT_I2COPEN_STRUCTURE)LocalAlloc(LMEM_ZEROINIT|LMEM_FIXED, sizeof(T_I2COPEN_STRUCTURE));
	if (pOpenContext == NULL)
	{
		DEBUGMSG(ZONE_OPEN | ZONE_ERROR,(TEXT("I2C Driver: LocalAlloc for T_I2COPEN_STRUCTURE failed\r\n")));
		return (DWORD) NULL;
	}

	// Store device settings for futur use
	pOpenContext->pDeviceContext = pDeviceContext;
	pOpenContext->dwAccessCode = AccessCode;
	pOpenContext->pDeviceContext->dwShareMode = ShareMode;
	

	// Reset and enable TWI
	twiReset(pDeviceContext,pOpenContext->pDeviceContext->dwDefaultTWIClkDiv);

	//
	pOpenContext->dwTWIClkDiv = pOpenContext->pDeviceContext->dwDefaultTWIClkDiv;

	// Increase opened device counter 
		pOpenContext->pDeviceContext->dwOpenCount++;	

	return (DWORD)pOpenContext;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL I2C_Close(T_I2COPEN_STRUCTURE *pOpenContext)
//!
//! \brief		This function closes a device context created by the pOpenContext parameter.
//!
//! \param		pOpenContext	Pointer returned by the <b>I2C_Open</b> (Device Manager) function, 
//!								which is used to identify the open context of the device. 
//!
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//!
//! An application calls the CloseHandle function to stop using a stream interface driver. 
//! The hFile parameter specifies the handle associated with the device context. In response
//! to <b>CloseHandle</b>, the operating system invokes <b>I2C_Close</b>.
//-----------------------------------------------------------------------------
BOOL I2C_Close(T_I2COPEN_STRUCTURE *pOpenContext)
{
	BOOL	bRet = TRUE;
	
	if (pOpenContext != NULL)
	{
		T_I2CINIT_STRUCTURE *pDeviceContext = pOpenContext->pDeviceContext;

		// Free memory
		if (LocalFree(pOpenContext) != NULL)
		{
			bRet = FALSE;
		}
		else
		{
			// Decrease opened device counter
				pDeviceContext->dwOpenCount --;
			}
		}

	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn			DWORD I2C_Read(T_I2COPEN_STRUCTURE *pOpenContext, LPVOID pBuffer, DWORD dwCount)
//!
//! \brief		This function reads data from the device identified by the open context.
//!
//! \param		pOpenContext	Handle to the open context of the device. The <b>I2C_Open</b> 
//!								(Device Manager) function creates and returns this identifier.  
//! \param		pBuffer			Pointer to the buffer that stores the data read from 
//!								the device. This buffer should be at least <i>Count</i> bytes long. 
//! \param		dwCount			Number of bytes to read from the device into <i>pBuffer</i>.
//!
//! \return		\e zero to indicate <i>end-of-file</i>. 
//! \return		\e -1 to indicate an error. 
//! \return		The number of bytes read to indicate success.
//!
//! After an application calls the ReadFile function to read from the device, the operating system
//! invokes this function. The <i>hFile</i> parameter is a handle to the device. The <i>pBuffer</i> parameter 
//! points to the buffer that contains the data read from the device. The <i>dwCount</i> parameter indicates 
//! the number of bytes that the application requests to read from the device.
//-----------------------------------------------------------------------------
DWORD I2C_Read(T_I2COPEN_STRUCTURE *pOpenContext, LPVOID pBuffer, DWORD dwCount)
{
	DWORD dwDataSize = -1;
	
	RETAILMSG(1, (TEXT("REEADDDDD\r\n")));

	// At least a device have to be opened
	if (pOpenContext == NULL || !pOpenContext->pDeviceContext->dwOpenCount)
	{
		DEBUGMSG(ZONE_READ, (TEXT("I2C Driver: No device opened\r\n")));
		return -1;
	}

	// Access right check
	if (! (pOpenContext->dwAccessCode & GENERIC_READ))
	{
		DEBUGMSG(ZONE_READ, (TEXT("I2C Driver: No read access right\r\n")));
		return -1;
	}


	// Nothing to do here. Job done in the IOControl


	return dwDataSize;
}


//-----------------------------------------------------------------------------
//! \fn			DWORD I2C_Write(T_I2COPEN_STRUCTURE *pOpenContext, LPCVOID pBuffer, DWORD dwCount)
//!
//! \brief		This function writes data to the device.
//!
//! \param		pOpenContext	Handle to the open context of the device. The <b>I2C_Open</b> 
//!								(Device Manager) function creates and returns this identifier.  
//! \param		pBuffer			Pointer to the buffer that contains the data to write. 
//!								This buffer should be at least <i>Count</i> bytes long. 
//! \param		dwCount			Number of bytes to write from the <i>pBuffer</i> buffer into the device.
//!
//! \return		The number of bytes  written indicates success
//! \return		\e -1 to indicate an error. 
//!
//! After an application uses the WriteFile function to write to the device, the operating system, 
//! invokes this function. The <i>hFile</i> parameter is a handle to the device. The <i>pBuffer</i> parameter 
//! points to the buffer that contains the data read from the device. The <i>dwCount</i> parameter indicates 
//! the number of bytes that the application requests to write to the device.
//-----------------------------------------------------------------------------
DWORD I2C_Write(T_I2COPEN_STRUCTURE *pOpenContext, LPCVOID pBuffer, DWORD dwCount)
{
	DWORD dwDataSize = -1;


	// At least a device have to be opened
	if (pOpenContext == NULL || !pOpenContext->pDeviceContext->dwOpenCount)
	{
		DEBUGMSG(ZONE_READ, (TEXT("I2C Driver: No device opened\r\n")));
		return -1;
	}

	// The device have to be readable
	if (! (pOpenContext->dwAccessCode & GENERIC_WRITE))
	{
		DEBUGMSG(ZONE_READ, (TEXT("I2C Driver: No write access right\r\n")));
		return -1;
	}

	// Nothing to do here. Job done in the IOControl

	return dwDataSize;

}


//-----------------------------------------------------------------------------
//! \fn			DWORD I2C_Seek(T_I2COPEN_STRUCTURE *pOpenContext, long Amount, WORD wType)
//!
//! \brief		This function moves the data pointer in the device.
//!
//! \param		pOpenContext	Handle to the open context of the device. The <b>I2C_Open</b> 
//!								(Device Manager) function creates and returns this identifier.  
//! \param		Amount			Number of bytes to move the data pointer in the device. A positive value 
//!								moves the data pointer toward the end of the file and a negative value 
//!								moves it toward the beginning.
//! \param		wType			Starting point for the data pointer. The following table shows the available values for this parameter.
//!
//! \return		The new data pointer for the device indicates success.
//! \return		\e -1 to indicate an error. 
//!
//! After an application calls the SetFilePointer function to move the data pointer in the device, 
//! the operating system invokes this function. If your device is capable of opening more than once, 
//! this function modifies only the data pointer for the instance specified by <i>pOpenContext</i>.
//-----------------------------------------------------------------------------
DWORD I2C_Seek(T_I2COPEN_STRUCTURE *pOpenContext, long Amount, WORD wType)
{
	DWORD dwDataSeek = -1;

	// At least a device have to be opened
	if (pOpenContext == NULL || !pOpenContext->pDeviceContext->dwOpenCount)
	{
		DEBUGMSG(ZONE_SEEK, (TEXT("I2C Driver: No device opened\r\n")));
		return -1;
	}

	// Nothing to do here.

	return dwDataSeek;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL I2C_IOControl(T_I2COPEN_STRUCTURE *pOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut)
//!
//! \brief		This function moves the data pointer in the device.
//!
//! \param		pOpenContext	Handle to the open context of the device. The <b>I2C_Open</b> 
//!								(Device Manager) function creates and returns this identifier.  
//! \param		dwCode			I/O control operation to perform. These codes are device-specific and 
//!								are usually exposed to developers through a header file. 
//!								Use <b>CTL_CODE</b> macro to generate a driver unique identifier for your iocontrol.
//! \param		pBufIn			Pointer to the buffer containing data to transfer to the device. 
//! \param		dwLenIn			Number of bytes of data in the buffer specified for <i>pBufIn</i>.
//! \param		pBufOut			Pointer to the buffer used to transfer the output data from the device.
//! \param		dwLenOut		Maximum number of bytes in the buffer specified by <i>pBufOut</i>.
//! \param		pdwActualOut	Pointer to the <b>DWORD</b> buffer that this function uses to 
//!								return the actual number of bytes received from the device. 
//!
//! \return		\e TRUE indicates success.
//! \return		\e FALSE indicates failure.
//!
//! An application uses the DeviceIoControl function to specify an operation to perform. The operating system,
//! in turn, invokes the <b>I2C_IOControl</b> function. The <i>dwCode</i> parameter contains the input or output 
//! operation to perform; these codes are usually specific to each device driver and are exposed to application 
//! programmers through a header file that the device driver developer makes available.
//!
//-----------------------------------------------------------------------------
BOOL I2C_IOControl(T_I2COPEN_STRUCTURE *pOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut)
{
	BOOL bRet = TRUE;

	// At least a device have to be opened
	if (pOpenContext == NULL || !pOpenContext->pDeviceContext->dwOpenCount)
	{
		DEBUGMSG(ZONE_IOCTL, (TEXT("I2C Driver: No device opened\r\n")));
		return -1;
	}

	switch (dwCode)
	{
		case IOCTL_I2C_LOCK:
		{
			EnterCriticalSection (& pOpenContext->pDeviceContext->scI2CAccess);
		} break;

		case IOCTL_I2C_UNLOCK:
		{
			LeaveCriticalSection (& pOpenContext->pDeviceContext->scI2CAccess);
		} break;

		case IOCTL_I2C_READ:
		{
			T_I2CIOCTL_READ *ptIoctlRead;
			DWORD dwBufferSize;

			// Access right check
			if (! (pOpenContext->dwAccessCode & GENERIC_READ))
			{
				DEBUGMSG(ZONE_IOCTL, (TEXT("I2C Driver: No read access right for IOCTL_I2C_READ\r\n")));
				return -1;
			}

			// Check parameters
			if ( pBufIn  == NULL || dwLenIn  != sizeof(T_I2CIOCTL_READ) ||
				 pBufOut == NULL || dwLenOut < 1)
			{
				DEBUGMSG(ZONE_IOCTL, (TEXT("I2C Driver: Bad parameters for IOCTL_I2C_READ\r\n")));
				return FALSE;
			}

			ptIoctlRead = (T_I2CIOCTL_READ*)pBufIn;
			dwBufferSize = dwLenOut;
			
			// Read Data
			if (!I2C_ReadData (pOpenContext, ptIoctlRead->dwDeviceAddr, ptIoctlRead->dwRegAddress, ptIoctlRead->eAddressSize, ptIoctlRead->bDisableInterrupt, (LPBYTE)pBufOut, &(dwBufferSize)))
			{
				DEBUGMSG(ZONE_IOCTL, (TEXT("I2C Driver: I2C read for device 0x%x failed in IOCTL_I2C_READ\r\n"), ptIoctlRead->dwDeviceAddr));
				bRet = FALSE;
			}

			*pdwActualOut = dwBufferSize;
		}
		break;

		case IOCTL_I2C_WRITE:
		{
			T_I2CIOCTL_WRITE *ptIoctlWrite;
			LPBYTE lpBuff = NULL;

			// Access right check
			if (! (pOpenContext->dwAccessCode & GENERIC_WRITE))
			{
				DEBUGMSG(ZONE_IOCTL, (TEXT("I2C Driver: No write access right for IOCTL_I2C_WRITE\r\n")));
				return FALSE;
			}
			
			// Check parameters
			if ( pBufIn == NULL || dwLenIn != sizeof(T_I2CIOCTL_WRITE))
			{
				DEBUGMSG(ZONE_IOCTL, (TEXT("I2C Driver: Bad parameters for IOCTL_I2C_WRITE\r\n")));
				return FALSE;
			}

			ptIoctlWrite = (T_I2CIOCTL_WRITE*)pBufIn;

			// Caller process remap
			lpBuff = (LPBYTE) MapCallerPtr(ptIoctlWrite->pBuffer, ptIoctlWrite->dwBufferSize);

			if (lpBuff == NULL)
			{
				DEBUGMSG(ZONE_IOCTL, (TEXT("I2C Driver: MapCallerPtr failed in IOCTL_I2C_READ\r\n")));
				return FALSE;
			}

			// Write data
			if (! I2C_WriteData (pOpenContext, ptIoctlWrite->dwDeviceAddr, ptIoctlWrite->dwRegAddress, ptIoctlWrite->eAddressSize, ptIoctlWrite->bDisableInterrupt, lpBuff, &(ptIoctlWrite->dwBufferSize)))
			{
				DEBUGMSG(ZONE_IOCTL, (TEXT("I2C Driver: I2C read for device 0x%x failed in IOCTL_I2C_READ\r\n"), ptIoctlWrite->dwDeviceAddr));
				bRet= FALSE;
			}
			
			UnMapPtr(lpBuff);

		}
		break;


		case IOCTL_I2C_TRANSFERT_RATE:
			// Check parameters
			if ( pBufIn == NULL || dwLenIn != sizeof(DWORD))
			{
				DEBUGMSG(ZONE_IOCTL, (TEXT("I2C Driver: Bad parameters for IOCTL_I2C_TRANSFERT_RATE\r\n")));
				return -1;
			}
			
			// Compute clock divider from the transfert rate
			pOpenContext->dwTWIClkDiv = computeTwiClock(*((LPDWORD)pBufIn));


			// Set TWI clock
			EnterCriticalSection (& pOpenContext->pDeviceContext->scI2CAccess);		
			setTwiClock(pOpenContext->pDeviceContext->pTWIReg, pOpenContext->dwTWIClkDiv);
			Sleep(2);
			LeaveCriticalSection (& pOpenContext->pDeviceContext->scI2CAccess);


			DEBUGMSG(ZONE_IOCTL, (TEXT("I2C Driver: New transfert rate set to %d (ClkDiv = 0x%02x)\r\n"), *((LPDWORD)pBufIn), pOpenContext->dwTWIClkDiv));

			bRet = TRUE;
			break;
		

		//---------------------------//
		//     Power management      //
		//							 //
		// States :					 //
		//   - D0 : On				 //
		//	 - D1 : UserIdle		 //
		//   - D2 : SystemIdle		 //
		//	 - D3 : Suspend			 //
		//   - D4 : Off				 //
		//							 //
		//---------------------------//
		case IOCTL_POWER_CAPABILITIES:
			if (pBufOut != NULL && dwLenOut == sizeof(POWER_CAPABILITIES))
			{
				PPOWER_CAPABILITIES ppc = (PPOWER_CAPABILITIES) pBufOut;
				memset(ppc, 0, sizeof(*ppc));
				ppc->DeviceDx = (1<<D0) | (1<<D1) | (1<<D2) | (1<<D3) | (1<<D4);	// support D0,D1,D2,D3 and D4
				*pdwActualOut = sizeof(POWER_CAPABILITIES);
				DEBUGMSG(1, (TEXT("I2C Driver: IOCTL_POWER_CAPABILITIES\r\n")));
			}
			break;

		case IOCTL_POWER_QUERY:
			if(pBufOut != NULL && dwLenOut == sizeof(CEDEVICE_POWER_STATE))
			{
				// return a good status on any valid query, since we are always ready to
				// change power states.
				CEDEVICE_POWER_STATE NewDx = *(PCEDEVICE_POWER_STATE) pBufOut;
				if(!VALID_DX(NewDx))
				{
					// this is a valid Dx state so return a good status
					bRet = FALSE;
				}
				DEBUGMSG(1, (TEXT("I2C Driver: IOCTL_POWER_QUERY\r\n")));
			}
			break;

		case IOCTL_POWER_SET:
			if(pBufOut != NULL && dwLenOut == sizeof(CEDEVICE_POWER_STATE))
			{
			
				CEDEVICE_POWER_STATE NewDx = *(PCEDEVICE_POWER_STATE) pBufOut;
				DEBUGMSG(1, (TEXT("I2C Driver: IOCTL_POWER_SET to %x\r\n"),NewDx));
				if(VALID_DX(NewDx))
				{
					if (NewDx == D0) // D0
					{
						// Enable TWI Periph clock
						pOpenContext->pDeviceContext->pPMCReg->PMC_PCER = I2CProcSpecificGetBaseAddress();
					}
					if (NewDx == D3 || NewDx == D4)
					{
					// Enable TWI Periph clock
						pOpenContext->pDeviceContext->pPMCReg->PMC_PCDR = I2CProcSpecificGetBaseAddress();
					}
					else // D1, D2
					{
						// Nothing more when entering in this power state
					}

					pOpenContext->pDeviceContext->CurrentDx = NewDx;
				}			
			}
			break;

		case IOCTL_POWER_GET:
			if(pBufOut != NULL && dwLenOut == sizeof(CEDEVICE_POWER_STATE))
			{
				
				*(PCEDEVICE_POWER_STATE) pBufOut = 	pOpenContext->pDeviceContext->CurrentDx;			
				*pdwActualOut = sizeof(CEDEVICE_POWER_STATE);
				DEBUGMSG(1, (TEXT("I2C Driver: IOCTL_POWER_GET to %x\r\n"),pOpenContext->pDeviceContext->CurrentDx));
			}
			break;


		default:
			bRet = FALSE;
	}

	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn			void I2C_PowerDown(T_I2CINIT_STRUCTURE *pDeviceContext)
//!
//! \brief		This function suspends power to the device. It is useful only with devices that can 
//!				power down under software control. Such devices are typically, but not exclusively, PC Cards.
//!
//! \param		pDeviceContext	Pointer to the device context. The call to the <b>I2C_Init</b> 
//!								(Device Manager) function returns this identifier.  
//!
//!
//!
//! The OS invokes this function to suspend power to a device.
//-----------------------------------------------------------------------------
void I2C_PowerDown(T_I2CINIT_STRUCTURE *pDeviceContext)
{

}


//-----------------------------------------------------------------------------
//! \fn			void I2C_PowerUp(T_I2CINIT_STRUCTURE *pDeviceContext)
//!
//! \brief		This function restores power to a device.
//!
//! \param		pDeviceContext	Pointer to the device context. The call to the <b>I2C_Init</b> 
//!								(Device Manager) function returns this identifier.  
//!
//!
//!
//! The OS invokes this function to restore power to a device.
//-----------------------------------------------------------------------------
void I2C_PowerUp(T_I2CINIT_STRUCTURE *pDeviceContext)
{

}

#define TIMELIMIT 1000000


//-----------------------------------------------------------------------------
//! \fn			int AT91F_TWI_WriteByte(const AT91PS_TWI pTwi ,int mode, int int_address, char *data2send, int nb, BOOL bDisableInt)
//!
//! \brief		Send a byte to a slave device
//!
//! \param		pTwi			Pointer to the peripheral registers.
//! \param		mode			Wrting mode
//! \param		int_address	Writing Adress
//! \param		data2send		data to send
//! \param		nb			Number of char to send
//! \param		bDisableInt	Boolean to enable interrupt
//!
//!
//! \return		0 in success, -1 in failure
//!
//-----------------------------------------------------------------------------
int AT91F_TWI_WriteByte(const AT91PS_TWI pTwi ,int mode, int int_address, char *data2send, int nb, BOOL bDisableInt)
{
	
	int status,i=0;
	volatile long counter = 0;

	status = pTwi->TWI_SR;
	DISABLE_INTERRUPT(bDisableInt);

	// Set TWI Internal Address Register
	if ((mode & AT91C_TWI_IADRSZ) != 0) pTwi->TWI_IADR = int_address;

	if(nb <2){
	// Set the TWI Master Mode Register
	pTwi->TWI_MMR = mode & ~AT91C_TWI_MREAD;	
		pTwi->TWI_CR = AT91C_TWI_START | AT91C_TWI_MSEN | AT91C_TWI_STOP;
		pTwi->TWI_THR = *data2send;
	}
	else{
	// Set the TWI Master Mode Register
	  pTwi->TWI_MMR = mode & ~AT91C_TWI_MREAD;	
	  for(i=0;i<nb;i++){
		pTwi->TWI_CR = AT91C_TWI_START | AT91C_TWI_MSEN;
		if (i == (nb - 1)) pTwi->TWI_CR = AT91C_TWI_STOP;
		status = pTwi->TWI_SR;		 
		counter = TIMELIMIT;
		while (!(status & AT91C_TWI_TXRDY)){
    		status = pTwi->TWI_SR;		   
			counter --;
			//if ((INT32) (dwEndDate - GetTickCount()) < 0)
			if(counter < 0 || (status & (AT91C_TWI_OVRE | AT91C_TWI_UNRE | AT91C_TWI_NACK)))
			{
				ENABLE_INTERRUPT(bDisableInt);
				if(status&AT91C_TWI_OVRE)
					RETAILMSG(1,(TEXT("I2C Error: AT91C_TWI_OVRE\r\n")));
				if(status&AT91C_TWI_UNRE)
					RETAILMSG(1,(TEXT("I2C Error: AT91C_TWI_UNRE\r\n")));
				if(status&AT91C_TWI_NACK)
					RETAILMSG(1,(TEXT("I2C Error: AT91C_TWI_NACK\r\n")));
				if(counter<0)
					RETAILMSG(1,(TEXT("I2C Error: Timeout\r\n")));
				return -1;
			}
			else
			{
				//RETAILMSG(1,(TEXT("Wait...4\r\n")));
			}
    	}
		pTwi->TWI_THR = *(data2send+i);
	  }	
	}	
	status = pTwi->TWI_SR;
	counter = TIMELIMIT;
	while (!(status & AT91C_TWI_TXCOMP)){
    	status = pTwi->TWI_SR;
		counter--;

		if(counter < 0 || (status & (AT91C_TWI_OVRE | AT91C_TWI_UNRE | AT91C_TWI_NACK)))
		{
			ENABLE_INTERRUPT(bDisableInt);
			if(status&AT91C_TWI_OVRE)
				RETAILMSG(1,(TEXT("I2C Error: AT91C_TWI_OVRE\r\n")));
			if(status&AT91C_TWI_UNRE)
				RETAILMSG(1,(TEXT("I2C Error: AT91C_TWI_UNRE\r\n")));
			if(status&AT91C_TWI_NACK)
				RETAILMSG(1,(TEXT("I2C Error: AT91C_TWI_NACK\r\n")));
			if(counter<0)
				RETAILMSG(1,(TEXT("I2C Error: Timeout\r\n")));
			return -1;
		}
			else
			{
			//	RETAILMSG(1,(TEXT("Wait...3\r\n")));
			}
    }

	ENABLE_INTERRUPT(bDisableInt);

	return 0;
}

//-----------------------------------------------------------------------------
//! \fn			int AT91F_TWI_ReadByte(const AT91PS_TWI pTwi ,int mode, int int_address, char *data, int nb, BOOL bDisableInt)
//!
//! \brief		Read a byte from a slave device
//!
//! \param		pTwi			Pointer to the peripheral registers.
//! \param		mode			Reading mode
//! \param		int_address	Reading Adress
//! \param		data			pointer on a char to store datas
//! \param		nb			Number of char to read
//! \param		bDisableInt	Boolean to enable interrupt
//!
//!
//! \return		0 in success, -1 in failure
//!
//-----------------------------------------------------------------------------
int AT91F_TWI_ReadByte(const AT91PS_TWI pTwi ,int mode, int int_address, char *data, int nb, BOOL bDisableInt)
{	
	unsigned int status,i=0;
	volatile long counter = 0;

	status = pTwi->TWI_SR;
	DISABLE_INTERRUPT(bDisableInt);

	// Set the TWI Master Mode Register
	pTwi->TWI_MMR = mode | AT91C_TWI_MREAD;	
	
	// Set TWI Internal Address Register
	if ((mode & AT91C_TWI_IADRSZ) != 0) pTwi->TWI_IADR = int_address;
	
	// Start transfer
	if (nb == 1){
		pTwi->TWI_CR = AT91C_TWI_START;
		status = pTwi->TWI_SR;	
		pTwi->TWI_CR = AT91C_TWI_STOP;
		status = pTwi->TWI_SR;	
		counter = TIMELIMIT;
		while (!(status & AT91C_TWI_TXCOMP)){
			status = pTwi->TWI_SR;		   
			counter--;
			//if ((INT32) (dwEndDate - GetTickCount()) < 0)
			if(counter < 0 || (status & (AT91C_TWI_OVRE | AT91C_TWI_UNRE | AT91C_TWI_NACK)))
			{
				ENABLE_INTERRUPT(bDisableInt);
				if(status&AT91C_TWI_OVRE)
					RETAILMSG(1,(TEXT("I2C Error: AT91C_TWI_OVRE\r\n")));
				if(status&AT91C_TWI_UNRE)
					RETAILMSG(1,(TEXT("I2C Error: AT91C_TWI_UNRE\r\n")));
				if(status&AT91C_TWI_NACK)
					RETAILMSG(1,(TEXT("I2C Error: AT91C_TWI_NACK\r\n")));
				if(counter<0)
					RETAILMSG(1,(TEXT("I2C Error: Timeout\r\n")));
				return -1;
			}
			else
			{
				//RETAILMSG(1,(TEXT("Wait...2\r\n")));
			}    	
    	}
		//if(status & AT91C_TWI_RXRDY){
		*(data+i) = pTwi->TWI_RHR;
		//}	
	}
 	else{
 		pTwi->TWI_CR = AT91C_TWI_START | AT91C_TWI_MSEN;
		status = pTwi->TWI_SR;	
		counter = TIMELIMIT;
		// Wait transfer is finished
		while (!(status & AT91C_TWI_TXCOMP)){//for(i=0;i<nb;i++){
   			status = pTwi->TWI_SR;		   
    		if(status & AT91C_TWI_RXRDY){
				*(data+i++) = pTwi->TWI_RHR;
				if (i == (nb - 1)) pTwi->TWI_CR = AT91C_TWI_STOP;
			}	

			counter--;
			//if ((INT32) (dwEndDate - GetTickCount()) < 0)
			if(counter < 0 || (status & (AT91C_TWI_OVRE | AT91C_TWI_UNRE | AT91C_TWI_NACK)))
			{
				ENABLE_INTERRUPT(bDisableInt);
				if(status&AT91C_TWI_OVRE)
					RETAILMSG(1,(TEXT("I2C Error: AT91C_TWI_OVRE\r\n")));
				if(status&AT91C_TWI_UNRE)
					RETAILMSG(1,(TEXT("I2C Error: AT91C_TWI_UNRE\r\n")));
				if(status&AT91C_TWI_NACK)
					RETAILMSG(1,(TEXT("I2C Error: AT91C_TWI_NACK\r\n")));
				if(counter<0)
					RETAILMSG(1,(TEXT("I2C Error: Timeout\r\n")));
				return -1;
			}
			else
			{
				//RETAILMSG(1,(TEXT("Wait...1\r\n")));
			}
		}	
	}
	
	ENABLE_INTERRUPT(bDisableInt);

	return 0;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL I2C_ReadData (T_I2COPEN_STRUCTURE *pOpenContext, DWORD dwDeviceAddr, DWORD dwRegAddress, IADDR_SIZE eAddressSize, BOOL bDisableInt, LPBYTE pBuffer, LPDWORD lpdwBufferSize )
//!
//! \brief		Read a buffer of data on the I2C bus from the dwDeviceAddr at register dwRegAddress
//!
//! \param		pOpenContext	open context
//! \param		dwDeviceAddr	I2C device address
//! \param		dwRegAddress	the internal device address. The value can be 0 if <b>eAddressSize</b> is <i>NO_IADR</i>
//! \param		eAddressSize	size of the internal device address	
//! \param		bDisableInt	TODO
//! \param		pBuffer			pointer to a buffer of data
//! \param		lpdwBufferSize	pointer to a DWORD, specifing the buffer size, the number of bytes read
//!
//! \return		\e TRUE indicates success.
//! \return		\e FALSE indicates failure.
//!
//!	Read a buffer of data on the I2C bus from the dwDeviceAddr at register dwRegAddress
//-----------------------------------------------------------------------------
BOOL I2C_ReadData (T_I2COPEN_STRUCTURE *pOpenContext, DWORD dwDeviceAddr, DWORD dwRegAddress, IADDR_SIZE eAddressSize, BOOL bDisableInt, LPBYTE pBuffer, LPDWORD lpdwBufferSize )
{
	BOOL bRet = TRUE;
	AT91PS_TWI pTwi = pOpenContext->pDeviceContext->pTWIReg;
	DWORD dwAddressSize = (eAddressSize << 8 ) & AT91C_TWI_IADRSZ;

	LPBYTE pBufferRead = (LPBYTE)pBuffer;	//!< Buffer to store readden data
	DWORD dwCount = *lpdwBufferSize;		//!< Quantity of bytes to read


	DWORD dwStatus = 0;						//!<
	DWORD dwStatusMask = 0;					//!<
	DWORD dwTick = 0;						//!<
	

	// Check parameters
	if (pBuffer == NULL || *lpdwBufferSize < 1)
		return FALSE;


	EnterCriticalSection (& pOpenContext->pDeviceContext->scI2CAccess);

	if (pTwi->TWI_CWGR != pOpenContext->dwTWIClkDiv)
	{
		setTwiClock(pTwi, pOpenContext->dwTWIClkDiv);
		Sleep(4);
	}

	if (AT91F_TWI_ReadByte(pTwi,(dwDeviceAddr << 16) | dwAddressSize,dwRegAddress,pBuffer,*lpdwBufferSize,bDisableInt))
	{
		// Reset and enable TWI
		twiReset(pOpenContext->pDeviceContext,pOpenContext->dwTWIClkDiv);
		bRet = FALSE;
	}
	
	LeaveCriticalSection (& pOpenContext->pDeviceContext->scI2CAccess);


	return bRet;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL I2C_WriteData (T_I2COPEN_STRUCTURE *pOpenContext, DWORD dwDeviceAddr, DWORD dwRegAddress, IADDR_SIZE eAddressSize, BOOL bDisableInt, LPBYTE pBuffer, LPDWORD lpdwBufferSize)
//!
//! \brief		Write a buffer of data on the I2C bus for the dwDeviceAddr at register dwRegAddress
//!
//! \param		pOpenContext	open context
//! \param		dwDeviceAddr	I2C device address
//! \param		dwRegAddress	the internal device address. The value can be 0 if <b>eAddressSize</b> is <i>NO_IADR</i>
//! \param		eAddressSize	size of the internal device address	
//! \param		bDisableInt	TODO
//! \param		pBuffer			pointer to a buffer of data
//! \param		lpdwBufferSize	pointer to a DWORD, specifing the buffer size, the number of bytes read
//!
//! \return		\e TRUE indicates success.
//! \return		\e FALSE indicates failure.
//!
//! Write a buffer of data on the I2C bus for the dwDeviceAddr at register dwRegAddress.
//-----------------------------------------------------------------------------
BOOL I2C_WriteData (T_I2COPEN_STRUCTURE *pOpenContext, DWORD dwDeviceAddr, DWORD dwRegAddress, IADDR_SIZE eAddressSize, BOOL bDisableInt, LPBYTE pBuffer, LPDWORD lpdwBufferSize)
{
	BOOL bRet = TRUE;
	AT91PS_TWI pTwi = pOpenContext->pDeviceContext->pTWIReg;
	DWORD dwAddressSize = (eAddressSize << 8 ) & AT91C_TWI_IADRSZ;
	
	LPBYTE pBufferWrite = (LPBYTE)pBuffer;	//!< Buffer to store readden data
	DWORD dwCount = *lpdwBufferSize;		//!< Quantity of bytes to read
	
	DWORD dwStatus = 0;						//!<	
	DWORD dwTick = 0;						//!<


	// Check parameters
	if (pBuffer == NULL || *lpdwBufferSize < 1)
		return FALSE;


	EnterCriticalSection (& pOpenContext->pDeviceContext->scI2CAccess);

	if (pTwi->TWI_CWGR != pOpenContext->dwTWIClkDiv)
	{
		setTwiClock(pTwi, pOpenContext->dwTWIClkDiv);
		Sleep(4);
	}

	if (AT91F_TWI_WriteByte(pTwi,(dwDeviceAddr << 16) | dwAddressSize,dwRegAddress,pBuffer,*lpdwBufferSize,bDisableInt))
	{
		// Reset and enable TWI
		twiReset(pOpenContext->pDeviceContext,pOpenContext->dwTWIClkDiv);
		bRet = FALSE;
	}

	LeaveCriticalSection (& pOpenContext->pDeviceContext->scI2CAccess);


	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL LoadRegistry(LPCTSTR pContext, T_I2CINIT_STRUCTURE *pDeviceContext)
//!
//! \brief		This function loads driver registry configuration
//!
//! \param		pContext		Pointer to a string containing the registry path to the active key for the stream interface driver.
//! \param		pDeviceContext	current device context
//!
//! \return		\e TRUE indicates success.
//! \return		\e FALSE indicates failure.
//!
//! This function loads driver registry configuration
//-----------------------------------------------------------------------------
BOOL LoadRegistry(LPCTSTR pContext, T_I2CINIT_STRUCTURE *pDeviceContext)
{
#define CTRL_BUFFER_SIZE 256   
	LONG    regError;
    HKEY    hKey;
    DWORD   dwDataSize;
	DWORD	dwTransfertRate = AT91C_TWI_DEFAULT_CLOCK_RATE;


    DEBUGMSG(ZONE_INIT, (TEXT("I2C Driver:LoadRegistry Try to open %s\r\n"), pContext));

    // We've been handed the name of a key in the registry that was generated
    // on the fly by device.exe.  We're going to open that key.  

	hKey = OpenDeviceKey(pContext);

    if ( hKey == NULL ) {
        DEBUGMSG(ZONE_INIT,
                 (TEXT("I2C Driver:LoadRegistry Failed to open device key %s, Error 0x%X\r\n"), pContext, GetLastError()));
        return ( FALSE );                
    }
	
	dwDataSize = I2C_TRANSFERT_RATE_VAL_LEN;
    regError = RegQueryValueEx(
                                  hKey, 
                                  I2C_TRANSFERT_RATE_VAL_NAME, 
                                  NULL, 
                                  NULL,
                                  (LPBYTE)(&dwTransfertRate), 
                                  &dwDataSize);
    
	if (regError == ERROR_SUCCESS && dwTransfertRate != 0)
	{
		pDeviceContext->dwDefaultTWIClkDiv = computeTwiClock(dwTransfertRate);
	}
	else
	{
		pDeviceContext->dwDefaultTWIClkDiv = computeTwiClock(AT91C_TWI_DEFAULT_CLOCK_RATE);
	}


	return regError == ERROR_SUCCESS;
}


//-----------------------------------------------------------------------------
//! \fn			DWORD computeTwiClock(DWORD dwTransfertRate)
//!
//! \brief		This function compute clock divider for the Twi interface
//!
//! \param		dwTransfertRate	disired tranfert rate (in bits per second)
//!
//! \return		Clock divider
//!
//! This function compute clock divider from the chip master clock and the disired transfert rate
//! for a 50% duty cycle
//-----------------------------------------------------------------------------
static DWORD computeTwiClock(DWORD dwTransfertRate)
{
#define CLDIV_MAX 0xFF
#define CKDIV_MAX 0x7
	int iClockDiv;
	DWORD dwCLDIV;// CLDIV == CKDIV
	DWORD dwCKDIV;
		
	DWORD dwMasterClock;

	KernelIoControl(IOCTL_HAL_MASTERCLOCK, NULL, 0, &dwMasterClock, sizeof(dwMasterClock), 0);
		
	// (dwTransfert * 2) because we configure a whole periode (high periode and low periode)
	iClockDiv = (dwMasterClock / (dwTransfertRate * 2));	

	iClockDiv -= 6;

	// at this point the computation is iClockDiv = dwCLDIV * (1<<dwCKDIV);
	dwCLDIV = iClockDiv;
	dwCKDIV = 0;
	while (dwCLDIV>CLDIV_MAX)
	{
		dwCLDIV >>= 1;
		dwCKDIV++;
	}

	if (dwCKDIV>CKDIV_MAX)
	{
		RETAILMSG(1,(TEXT("I2C : Invalid Frequency\r\n")));
		dwCKDIV = CKDIV_MAX;
		dwCLDIV = CLDIV_MAX;
	}

	return (DWORD) (dwCKDIV<<16) | (dwCLDIV << 8) | (dwCLDIV);
}


//-----------------------------------------------------------------------------
//! \fn			void setTwiClock(AT91PS_TWI pTwi, DWORD dwClockDiv)
//!
//! \brief		Set the TWI peripheral transfert rate
//!
//! \param		pTwi		Pointer to the peripheral registers.
//! \param		dwClockDiv	Clock divider
//!
//!
//!
//! The driver call this function to set the transfert rate before any communication
//-----------------------------------------------------------------------------
static void setTwiClock(AT91PS_TWI pTwi, DWORD dwClockDiv)
{	
	pTwi->TWI_CWGR	= dwClockDiv;
}


static int twiReset(T_I2CINIT_STRUCTURE *pDeviceContext,DWORD dwTWIClkCfg)
{
	EnterCriticalSection (& pDeviceContext->scI2CAccess);			

	//// Configure TWI
	// Disable interrupts
	pDeviceContext->pTWIReg->TWI_IDR = (unsigned int) -1;
    // Reset peripheral
	pDeviceContext->pTWIReg->TWI_CR = AT91C_TWI_SWRST;
	// Set Master mode
	pDeviceContext->pTWIReg->TWI_CR = AT91C_TWI_MSEN;

	setTwiClock(pDeviceContext->pTWIReg, dwTWIClkCfg);
	Sleep(4);
	LeaveCriticalSection (& pDeviceContext->scI2CAccess);

	return 0;
}



// End of Doxygen group I2C Driver
//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/I2C/I2CDriver.c $
//-----------------------------------------------------------------------------
//
//! @}
