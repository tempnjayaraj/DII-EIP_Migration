//-----------------------------------------------------------------------------
//! \addtogroup	I2C
//! @{
//!  
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91RM9200_I2CDriver.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/DRIVERS/I2C/AT91RM9200_I2CDriver.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//!
//! Header for I2C driver
//-----------------------------------------------------------------------------

#ifndef __AT91RM9200_I2CDRIVER_H__
#define __AT91RM9200_I2CDRIVER_H__

// Structures
// Init context structure
typedef struct {
	AT91PS_TWI pTWIReg;				//!< virtual base address of I2C controller
	AT91PS_PDC pPDCReg;				//!< virtual base address of I2C controller's PDC (not used)
	CRITICAL_SECTION scI2CAccess;	//!< Critical section used to protect access to the I2C data and registers
	DWORD dwOpenCount;				//!< To keep track of how many time the instance has been opened
	DWORD dwShareMode;				//!< To keep track of the share mode of the instance. 
	DWORD dwDefaultTWIClkDiv;		//!< I2C Default Clock divider
} T_I2CINIT_STRUCTURE, *PT_I2CINIT_STRUCTURE;

// Open context structure
typedef struct {
	T_I2CINIT_STRUCTURE *pDeviceContext;	
	DWORD dwAccessCode;			//!< To keep track of the access mode (READ, WRITE or READ/WRITE)
	DWORD dwTWIClkDiv;				//!< Auctual I2C Clock divider
} T_I2COPEN_STRUCTURE, *PT_I2COPEN_STRUCTURE;


// Public interfaces
BOOL	WINAPI	I2C_DllEntry(HANDLE hInstDll, DWORD dwReason, LPVOID  lpvReserved); 
DWORD	I2C_Init	(LPCTSTR pContext, LPCVOID lpvBusContext);
BOOL	I2C_Deinit	(T_I2CINIT_STRUCTURE *pDeviceContext);
DWORD	I2C_Open	(T_I2CINIT_STRUCTURE *pDeviceContext, DWORD AccessCode, DWORD ShareMode);
BOOL	I2C_Close	(T_I2COPEN_STRUCTURE *pOpenContext);
DWORD	I2C_Read	(T_I2COPEN_STRUCTURE *pOpenContext, LPVOID pBuffer, DWORD dwCount);
DWORD	I2C_Write	(T_I2COPEN_STRUCTURE *pOpenContext, LPCVOID pBuffer, DWORD dwCount);
DWORD	I2C_Seek	(T_I2COPEN_STRUCTURE *pOpenContext, long Amount, WORD wType);
BOOL	I2C_IOControl (T_I2COPEN_STRUCTURE *pOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut);
void	I2C_PowerDown (T_I2CINIT_STRUCTURE *pDeviceContext);
void	I2C_PowerUp	  (T_I2CINIT_STRUCTURE *pDeviceContext);

// Internal usage
BOOL LoadRegistry(LPCTSTR pContext, T_I2CINIT_STRUCTURE *pDeviceContext);
BOOL I2C_ReadData (T_I2COPEN_STRUCTURE *pOpenContext, DWORD dwDeviceAddr, DWORD dwRegAddress, IADDR_SIZE eAddressSize, BOOL bDisableInt, LPBYTE pBuffer, LPDWORD lpdwBufferSize);
BOOL I2C_WriteData (T_I2COPEN_STRUCTURE *pOpenContext, DWORD dwDeviceAddr, DWORD dwRegAddress, IADDR_SIZE eAddressSize, BOOL bDisableInt, LPBYTE pBuffer, LPDWORD lpdwBufferSize);
DWORD AT91F_ComputeTwiClock(DWORD dwTranfertRate);
void AT91F_SetTwiClock(AT91PS_TWI pTwi, DWORD dwClockDiv);

// Hardware Specific intialisation
extern BOOL I2C_InitHW ();


#endif // #define __AT91RM9200_I2CDRIVER_H__

//! @}
