//-----------------------------------------------------------------------------
//!
//! \addtogroup DRIVERS
//! @{
//
//! \addtogroup	TOUCHSCREEN
//! @{
//
// All rights reserved ADENEO SAS 2006
//-----------------------------------------------------------------------------
//!
//! \file		ADS7843Touch.cpp
//!
//! \brief		Driver for touchScreen ADS7843.
//!				Use specific SPI Driver functions
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/TouchScreen/Dll/ADS7843Touch.cpp $
//!   $Author: amlimonet $
//!   $Revision: 889 $
//!   $Date: 2007-05-28 10:42:57 +0200 (lun., 28 mai 2007) $
//! \endif
//-----------------------------------------------------------------------------

//--------------------------------------------------------------
// Include Files
//--------------------------------------------------------------
#include    <windows.h>
#include	<types.h>
#include    <memory.h>
#include    <nkintr.h>
#include    <tchddsi.h>
#include	<CEDDK.h>

#include    "ADS7843Touch.h"
#include    "ADS7843SPI.h"

#include "AT91SAM926x.h"
#include "lib_at91sam926x.h"
#include <AT91SAM926x_spi.h>
#include "AT91SAM926x_spi_ioctl.h"
#include <AT91SAM9263_oal_intr.h>
#include "at91sam9263_gpio.h"

//--------------------------------------------------------------
// Defines
//--------------------------------------------------------------
// Sample rate
#define TOUCHPANEL_SELECT_SAMPLE_RATE_LOW	0
#define TOUCHPANEL_SELECT_SAMPLE_RATE_HIGH	1
#define ADS7843_SAMPLE_DELAY				3
// Sample filters
#define ADS7843_MAX_SKIPPED_SAMPLES			2
#define ADS7843_MAX_DIFFERENCE_CHANGE		40
#define ADS7843_HYSTERESIS_WAIT				6

//--------------------------------------------------------------
// Global Variables
//--------------------------------------------------------------
// MDD requiered
DWORD gIntrTouch        = SYSINTR_UNDEFINED;
DWORD gIntrTouchChanged = SYSINTR_NOP;

// This allows you to force new gIntrTouch interrupt after this time.
// Note that the extern "C"
// is required so that the variable name doesn't get decorated, and
// since we have an initializer the 'extern' is actually ignored and
// space is allocated.
extern "C" DWORD gdwTouchIstTimeout;

// The MDD requires a minimum of MIN_CAL_COUNT consecutive samples before
// it will return a calibration coordinate to GWE.  This value is defined
// in the PDD so that each OEM can control the behaviour of the touch
// panel and still use the Microsoft supplied MDD.  
extern "C" const int MIN_CAL_COUNT = 6;

// Timer counter settings
DWORD gdwCurrentSampleRate = TOUCHPANEL_SAMPLE_RATE_LOW;


//-----------------------------------------------------------------------------
//! \fn			BOOL TouchDriverCalibrationPointGet(TPDC_CALIBRATION_POINT *pTCP)
//!
//! \brief		This function calculate the position of each calibration points
//!
//!	\param		pTCP : pointer to a TPDC_CALIBRATION_POINT structure
//!
//! \return		\e TRUE when all is good
//!	\return		\e FALSE when all is bad
//!
//!
//-----------------------------------------------------------------------------
BOOL TouchDriverCalibrationPointGet(TPDC_CALIBRATION_POINT *pTCP)
{
	INT32	cDisplayWidth = pTCP->cDisplayWidth;
	INT32	cDisplayHeight = pTCP->cDisplayHeight;

	int	CalibrationRadiusX = cDisplayWidth / 10;
	int	CalibrationRadiusY = cDisplayHeight / 10;

	switch (pTCP->PointNumber) {
		case	0:	// Middle
			pTCP->CalibrationX = cDisplayWidth / 2;
			pTCP->CalibrationY = cDisplayHeight / 2;
			break;

		case	1:	// Upper Left
			pTCP->CalibrationX = (CalibrationRadiusX * 2);
			pTCP->CalibrationY = (CalibrationRadiusY * 2);
			break;

		case	2:  // Lower Left
			pTCP->CalibrationX = CalibrationRadiusX * 2;
			pTCP->CalibrationY = cDisplayHeight - (CalibrationRadiusY * 2);
			break;

		case	3:  // Lower Right
			pTCP->CalibrationX = cDisplayWidth - (CalibrationRadiusX * 2);
			pTCP->CalibrationY = cDisplayHeight - (CalibrationRadiusY * 2);
			break;

		case	4:	// Upper Right
			pTCP->CalibrationX = cDisplayWidth - (CalibrationRadiusX * 2);
			pTCP->CalibrationY = (CalibrationRadiusY * 2);
			break;

		default:
			pTCP->CalibrationX = cDisplayWidth / 2;
			pTCP->CalibrationY = cDisplayHeight / 2;
			SetLastError(ERROR_INVALID_PARAMETER);
			return FALSE;
		}
	return TRUE;
}


//--------------------------------------------------------------
// PDD Entry points
//--------------------------------------------------------------

//-----------------------------------------------------------------------------
//! \fn			LONG DdsiTouchPanelAttach(void)
//!
//! \brief		This function executes when the MDD's DLL entry point 
//!				gets a DLL_PROCESS_ATTACH message.
//!
//!
//! \return		zero (0)
//!
//!
//-----------------------------------------------------------------------------
LONG DdsiTouchPanelAttach(void)
{
	return 0;
}


//-----------------------------------------------------------------------------
//! \fn			LONG DdsiTouchPanelDetach(void)
//!
//! \brief		This function executes when the MDD's DLL entry point 
//!				gets a DLL_PROCESS_DETTACH message.
//!
//!
//! \return		zero (0)
//!
//!
//-----------------------------------------------------------------------------
LONG DdsiTouchPanelDetach(void)
{
	return 0;	
}

//-----------------------------------------------------------------------------
//! \fn			VOID DdsiTouchPanelDisable(void)
//!
//! \brief		This function disables the touch screen device.
//!
//!
//! \return		zero (0)
//!
//! This function disables the touch screen device. Disabling a touch screen 
//! prevents generation of any subsequent touch samples, and removes power from 
//! the screen's hardware. The exact steps necessary depend on the specific 
//! characteristics of the touch screen hardware.
//-----------------------------------------------------------------------------
VOID DdsiTouchPanelDisable(void)
{

	// Unload SPI Driver
	DeinitializeSPIDriver();
		
	// Release all Sysintr
	if (gIntrTouch != SYSINTR_UNDEFINED)
	{
		if (!KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, &gIntrTouch, sizeof(DWORD), NULL, 0, NULL))
    	{
        	ERRORMSG(1, (TEXT("ERROR: Failed to release the gIntrTouch sysintr (PIO_ADS7843_PENIRQ)\r\n")));
	   	} 	
	   	gIntrTouch = SYSINTR_UNDEFINED;
	}
}

//-----------------------------------------------------------------------------
//! \fn			BOOL DdsiTouchPanelEnable(void)
//!
//! \brief		This function applies power to the touch screen device.
//!
//!
//! \return		\e TRUE when all is good
//!	\return		\e FALSE when all is bad
//!
//! This function applies power to the touch screen device and initializes it 
//! for operation.
//-----------------------------------------------------------------------------
BOOL DdsiTouchPanelEnable(void)
{
	DWORD dwLogIntr;
	DWORD dwBytesReturned;
	DEBUGMSG( ADS7843_DEBUG, (TEXT("+Touch screen Init\r\n")));
	
	// Request SysIntr for PENIRQ
	dwLogIntr = (LOGINTR_BASE_PIOA + 15);
	SetLastError(ERROR_SUCCESS);
    if (!KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &dwLogIntr, sizeof(DWORD), &gIntrTouch, sizeof(DWORD), &dwBytesReturned))
    {
        RETAILMSG(1, (TEXT("ERROR: Failed to request the gIntrTouch sysintr, errorcode = %d \r\n"),GetLastError()));
        gIntrTouch = SYSINTR_UNDEFINED;
        return FALSE;
    }       

	// SPI initialization
	if (!InitializeSPIDriver(SPI_DRIVER_NAME))
	{
		return FALSE;	
	}
	
	return TRUE;		
}


//-----------------------------------------------------------------------------
//! \fn			BOOL DdsiTouchPanelGetDeviceCaps(INT iIndex, LPVOID lpOutput)
//!
//! \brief		This function obtain capabilities of the touchscreen.
//!
//! \param		iIndex : Capability to query.
//! \param		lpOutput : Pointer to one or more memory locations to 
//!						   place the queried information
//!
//! \return		\e TRUE when all is good
//!	\return		\e FALSE when all is bad
//!
//-----------------------------------------------------------------------------
BOOL DdsiTouchPanelGetDeviceCaps(INT iIndex, LPVOID lpOutput)
{
	BOOL bRet = FALSE;
	
	if (lpOutput == NULL) {
		ERRORMSG(1,(TEXT("TouchPanelGetDeviceCaps: invalid parameter.\r\n")));
		SetLastError(ERROR_INVALID_PARAMETER);
		return FALSE;
	}
	
	switch	(iIndex) {
		case TPDC_SAMPLE_RATE_ID:
			{
			TPDC_SAMPLE_RATE	*pTSR = (TPDC_SAMPLE_RATE*)lpOutput;
			pTSR->SamplesPerSecondLow = TOUCHPANEL_SAMPLE_RATE_LOW;
			pTSR->SamplesPerSecondHigh = TOUCHPANEL_SAMPLE_RATE_HIGH;
			pTSR->CurrentSampleRateSetting = (gdwCurrentSampleRate == TOUCHPANEL_SAMPLE_RATE_LOW)?TOUCHPANEL_SELECT_SAMPLE_RATE_LOW:TOUCHPANEL_SELECT_SAMPLE_RATE_HIGH;
			bRet = TRUE;
			}
			break;
			
		case TPDC_CALIBRATION_POINT_COUNT_ID:
			{
			TPDC_CALIBRATION_POINT_COUNT *pTCPC = (TPDC_CALIBRATION_POINT_COUNT*)lpOutput;
			pTCPC->flags = 0;
			pTCPC->cCalibrationPoints = 5;
			bRet = TRUE;
			}
			break;
			
		case TPDC_CALIBRATION_POINT_ID:
			bRet = TouchDriverCalibrationPointGet((TPDC_CALIBRATION_POINT*)lpOutput);
			break;
			
		default:
			ERRORMSG(1,(TEXT("TouchPanelGetDeviceCaps: invalid parameter.\r\n")));
			SetLastError(ERROR_INVALID_PARAMETER);
			return FALSE;
	}

	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn			void DdsiTouchPanelGetPoint(TOUCH_PANEL_SAMPLE_FLAGS *pTipState, INT *pUnCalX, INT *pUnCalY)
//!
//! \brief		This function returns the most recently acquired point.
//!
//! \param		pTipState : Pointer to where to return the tip state information
//! \param		pUnCalX : Pointer to where to return the x-coordinate
//! \param		pUnCalY : Pointer to where to return the y-coordinate
//!
//!
//! This function returns the most recently acquired point and its associated tip state information.
//-----------------------------------------------------------------------------
void DdsiTouchPanelGetPoint(TOUCH_PANEL_SAMPLE_FLAGS *pTipState, INT *pUnCalX, INT *pUnCalY)
{
	// Sampled
	static INT iPrevSampleX	= 0;
	static INT iPrevSampleY	= 0;
	// Last valid sample value
	static INT iPrevValidSampleX	= 0;
	static INT iPrevValidSampleY	= 0;
	// Skipped samples
	static DWORD dwSkippedSamples = 0;

	BOOL bIsPenDown = FALSE;

	Sleep(ADS7843_HYSTERESIS_WAIT);

	// Read PENIRQ level 
	// When the stylus touch the screen, the PENIRQ# goes low
	if (pio_get_value(AT91C_PIN_PA(15)))//(AT91F_PIO_IsInputSet(gpPIO_PENIRQ, AT91C_PA15_IRQ1))
	{
		bIsPenDown = FALSE;
	}
	else
	{
		bIsPenDown = TRUE;
	}
	
	// Pen Up
	if (!bIsPenDown)
	{
		// Set flags
		*pTipState = TouchSampleValidFlag;
		DEBUGMSG(ADS7843_DEBUG,(TEXT("DdsiTouchPanelGetPoint : PenUp detected.\r\n")));
		
		// \return the last valid sample
		*pUnCalX = iPrevValidSampleX;
		*pUnCalY = iPrevValidSampleY;

		// Reset values
		iPrevSampleX = 0;
		iPrevSampleY = 0;
		dwSkippedSamples = 0;

		gdwTouchIstTimeout = INFINITE;
	} 	
	// Pen Down 
	else
	{
		DEBUGMSG(ADS7843_DEBUG,(TEXT("DdsiTouchPanelGetPoint : PenDown detected.\r\n")));
		
		// Read XY
		if (!ADS7843_ReadXY(pUnCalX, pUnCalY))
		{
			*pTipState =  TouchSampleIgnore;
			DEBUGMSG(ADS7843_DEBUG,(TEXT("DdsiTouchPanelGetPoint : TouchSampleIgnored \r\n")));
			
		}
		else
		{
			CustomizeCoordinates (pUnCalX, pUnCalY);

			if(dwSkippedSamples < ADS7843_MAX_SKIPPED_SAMPLES)
			{
				dwSkippedSamples ++;
				*pTipState =  TouchSampleIgnore;
				DEBUGMSG(ADS7843_DEBUG,(TEXT("DdsiTouchPanelGetPoint : TouchSample Skipped (x=%d , y= %d\r\n"), *pUnCalX, *pUnCalY));
			}
			else
			{

				// Skip erroneous samples 
				if ((iPrevSampleX != 0 && iPrevSampleY != 0) &&
					((abs(iPrevSampleX - *pUnCalX) > ADS7843_MAX_DIFFERENCE_CHANGE) ||
					(abs(iPrevSampleY - *pUnCalY) > ADS7843_MAX_DIFFERENCE_CHANGE)) )
				{
					*pTipState =  TouchSampleIgnore;
					DEBUGMSG(ADS7843_DEBUG,(TEXT("DdsiTouchPanelGetPoint : TouchSample Invalid (x=%d , y= %d\r\n"), *pUnCalX, *pUnCalY));

				}
				else
				{
					*pTipState =  TouchSampleValidFlag | TouchSampleDownFlag;
					DEBUGMSG(ADS7843_DEBUG,(TEXT("DdsiTouchPanelGetPoint : TouchSample Valid (x=%d , y= %d\r\n"), *pUnCalX, *pUnCalY));
					// Store the sample for futur use
					iPrevValidSampleX = *pUnCalX;
					iPrevValidSampleY = *pUnCalY;
				}
				// Store the sample even if it as been skipped
				iPrevSampleX = *pUnCalX;
				iPrevSampleY = *pUnCalY;

			}
		}
		
		//Change timeout between 2 samplings
		gdwTouchIstTimeout = ADS7843_SAMPLE_DELAY;
	}
	
	InterruptDone(gIntrTouch);
	
}


//-----------------------------------------------------------------------------
//! \fn			VOID DdsiTouchPanelPowerHandler(BOOL bOff)
//!
//! \brief		This function returns the most recently acquired point.
//!
//! \param		bOff : <b>TRUE</b> indicates that the system is turning off. <b>FALSE</b> indicates that the system is turning on.
//!
//!
//! This function indicates to the driver that the system is entering or leaving the suspend state.
//-----------------------------------------------------------------------------
VOID DdsiTouchPanelPowerHandler(BOOL bOff)
{
	DEBUGMSG(ADS7843_DEBUG,(TEXT("DdsiTouchPanelPowerHandler.\r\n")));
	
}


//-----------------------------------------------------------------------------
//! \fn			BOOL DdsiTouchPanelSetMode(INT iIndex, LPVOID lpInput)
//!
//! \brief		This function sets information about the touch screen device.
//!
//! \param		iIndex : Mode to set.
//! \param		lpInput : Pointer to one or more memory locations where the update 
//!						  information resides. Points to one or more memory locations 
//!						  to place the queried information.
//!
//!
//! \return		\e TRUE when all is good
//!	\return		\e FALSE when all is bad
//-----------------------------------------------------------------------------
BOOL DdsiTouchPanelSetMode(INT iIndex, LPVOID lpInput)
{
	BOOL bRet = FALSE;
	
	switch (iIndex)
	{
		case TPSM_SAMPLERATE_HIGH_ID:
			gdwCurrentSampleRate = TOUCHPANEL_SAMPLE_RATE_HIGH;
			DEBUGMSG(ADS7843_DEBUG,(TEXT("DdsiTouchPanelSetMode : Set SampleRate to High.\r\n")));
			bRet = TRUE;
		break;
		
		case TPSM_SAMPLERATE_LOW_ID:
			gdwCurrentSampleRate = TOUCHPANEL_SAMPLE_RATE_LOW;
			DEBUGMSG(ADS7843_DEBUG,(TEXT("DdsiTouchPanelSetMode : Set SampleRate to Low.\r\n")));
			bRet = TRUE;
		break;
		
		default:
			bRet = FALSE;
			ERRORMSG(ADS7843_DEBUG,(TEXT("DdsiTouchPanelSetMode : Unsupported Mode.\r\n")));
		break;
	}
	
	return bRet;	
}

//! @}

////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/TouchScreen/Dll/ADS7843Touch.cpp $
////////////////////////////////////////////////////////////////////////////////
//

//! @}
