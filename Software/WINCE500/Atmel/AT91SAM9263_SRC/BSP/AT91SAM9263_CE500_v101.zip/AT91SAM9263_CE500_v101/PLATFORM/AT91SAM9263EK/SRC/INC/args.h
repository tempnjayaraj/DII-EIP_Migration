//-----------------------------------------------------------------------------
//! \addtogroup EBOOT
//! @{
//!
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		args.h
//!
//! \brief		Defines the argument structure shared by the bootloader and the OS image
//!
//! \if subversion
//!   $URL: http://centaure/svn/thales_navigation-bsp_nadia2ek/TRUNK/WINCE500/PLATFORM/nadia2EK/SRC/INC/args.h $
//!   $Author: jjhiblot $
//!   $Revision: 18 $
//!   $Date: 2005-12-19 15:16:58 +0100 (lun., 19 déc. 2005) $
//! \endif
//-----------------------------------------------------------------------------

#ifndef _ARGS_H_
#define _ARGS_H_

#include <oal_perreg.h>
#include <oal_args.h>
#include <oal_kitl.h>

//------------------------------------------------------------------------------

#define BSP_ARGS_VERSION				1
/*! \brief this structure is used to export data from the bootoader to the OAL
*/
typedef struct {
    OAL_ARGS_HEADER header;
    UINT8 deviceId[16];         /*! < \brief Device identification*/
    OAL_KITL_ARGS kitl;			/*! < \brief KITL information*/
    DWORD	dwCoreFrequency;	/*! < \brief Frequency for the core*/	
    DWORD	dwBusFreqDivider;	/*! < \brief Divider used to create the bus frequency with the core frequency*/
	BOOTLOADER_TYPE	bootType;			/*! < \brief Type of bootloader (nand flash or data flash)*/
} BSP_ARGS, *PBSP_ARGS;

#endif // _ARGS_H_.

//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/thales_navigation-bsp_nadia2ek/TRUNK/WINCE500/PLATFORM/nadia2EK/SRC/INC/args.h $
//-----------------------------------------------------------------------------
//