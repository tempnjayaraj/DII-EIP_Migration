//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		oal_bootloadersettings.h
//!
//! \brief		Header file defining the interface to access the bootloader's settings
//!
//! \if subversion
//!   $URL: http://centaure/svn/thales_navigation-bsp_nadia2ek/TRUNK/WINCE500/PLATFORM/nadia2EK/SRC/INC/oal_bootloadersettings.h $
//!   $Author: jjhiblot $
//!   $Revision: 18 $
//!   $Date: 2005-12-19 15:16:58 +0100 (lun., 19 déc. 2005) $
//! \endif
//-----------------------------------------------------------------------------

#ifndef __OAL_BOOTLOADERSETTINGS_H__
#define __OAL_BOOTLOADERSETTINGS_H__

BOOL OALIoCtlReadBootloaderSettings(UINT32 code, VOID *pInBuffer, UINT32 inSize, VOID *pOutBuffer, UINT32 outSize,UINT32 *pOutSize);
BOOL OALIoCtlWriteBootloaderSettings(UINT32 code, VOID *pInBuffer, UINT32 inSize, VOID *pOutBuffer, UINT32 outSize,UINT32 *pOutSize);

#endif //__OAL_BOOTLOADERSETTINGS_H__

//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/thales_navigation-bsp_nadia2ek/TRUNK/WINCE500/PLATFORM/nadia2EK/SRC/INC/oal_bootloadersettings.h $
//-----------------------------------------------------------------------------
//
