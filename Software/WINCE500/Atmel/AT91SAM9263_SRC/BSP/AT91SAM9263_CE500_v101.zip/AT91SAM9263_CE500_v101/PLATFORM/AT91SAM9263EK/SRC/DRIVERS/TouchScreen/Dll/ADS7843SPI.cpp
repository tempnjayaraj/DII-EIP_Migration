//-----------------------------------------------------------------------------
//!
//! \addtogroup DRIVERS
//! @{
//
//! \addtogroup	TOUCHSCREEN
//! @{
//
// All rights reserved ADENEO SAS 2006
//-----------------------------------------------------------------------------
//!
//! \file		ADS7843SPI.cpp
//!
//! \brief		Interface between SPI driver and TouchScreen driver
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/TouchScreen/Dll/ADS7843SPI.cpp $
//!   $Author: ltourlonias $
//!   $Revision: 684 $
//!   $Date: 2007-04-13 14:35:48 +0200 (ven., 13 avr. 2007) $
//! \endif
//-----------------------------------------------------------------------------

//--------------------------------------------------------------
// Include Files
//--------------------------------------------------------------
#include	<windows.h>

#include 	"ADS7843touch.h"
#include 	"ADS7843spi.h"
#include	"ADS7843Regs.h"
#include	"AT91SAM9263EK_ioctl.h"
#include	"AT91SAM926x_spi_ioctl.h"

//--------------------------------------------------------------
// Defines
//--------------------------------------------------------------
//#define USE_NORMAL_SPI_TRANSACTION

//--------------------------------------------------------------
// Global Variables
//--------------------------------------------------------------
// Handle to the SPI Driver
HANDLE ghTouchScreenSPIDriver = NULL;

//--------------------------------------------------------------
// TSC specific functions
//--------------------------------------------------------------
//-----------------------------------------------------------------------------
//! \fn			BOOL InitializeSPIDriver(LPCTSTR strDriverName)
//!
//! \brief		Load SPI Driver
//!
//!	\param		strDriverName : SPI Driver Name
//!
//! \return		\e TRUE when all is good
//!	\return		\e FALSE when all is bad
//!
//!
//-----------------------------------------------------------------------------
BOOL InitializeSPIDriver(LPCTSTR strDriverName)
{
	BOOL bRet = FALSE;
	
	if (ghTouchScreenSPIDriver != NULL)
	{
		CloseHandle (ghTouchScreenSPIDriver);
		ghTouchScreenSPIDriver = NULL;
	}		
	
	ghTouchScreenSPIDriver = CreateFile(
									strDriverName, 				//LPCTSTR lpFileName, 
									GENERIC_READ|GENERIC_WRITE, //DWORD dwDesiredAccess, 
									0,							//DWORD dwShareMode, 
									NULL, 						//LPSECURITY_ATTRIBUTES lpSecurityAttributes, 
									OPEN_EXISTING, 				//DWORD dwCreationDispostion, 
									FILE_ATTRIBUTE_NORMAL, 		//DWORD dwFlagsAndAttributes, 
									NULL 						//HANDLE hTemplateFile
									); 

	if (ghTouchScreenSPIDriver == INVALID_HANDLE_VALUE)
	{
		ERRORMSG(1, (TEXT("InitializeSPIDriver - Failed to load driver %s\r\n"), strDriverName));
		ghTouchScreenSPIDriver = NULL;
		return FALSE;
	}
	else
	{
		DEBUGMSG(1, (TEXT("InitializeSPIDriver - Driver %s loaded\r\n"), strDriverName));
		bRet = TRUE;
	}
	
	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn			void DeinitializeSPIDriver()
//!
//! \brief		Unload SPI Driver
//!
//!
//-----------------------------------------------------------------------------
void DeinitializeSPIDriver()
{

	
	
	// Unload Driver	
	if (ghTouchScreenSPIDriver != NULL)
	{
		CloseHandle (ghTouchScreenSPIDriver);
		ghTouchScreenSPIDriver = NULL;	
	}
	
}


//-----------------------------------------------------------------------------
//! \fn			BOOL ADS7843_Read16Bits (UCHAR ucCmd, INT *pDAVVal)
//!
//! \brief		Read 8 bits from the ADS7843 controler
//!
//! \param		ucCmd : command to send to the ADS7843 for the conversion
//! \param		pDAVVal : value readden
//!
//! \return		\e TRUE when all is good
//!	\return		\e FALSE when all is bad
//!
//!
//!	This function uses a dedicated IOControl because the normal SPI transaction
//! is too fast for this ADC. At 100 MHz the lowest SPCK is 400 kHz. The ADC will work 
//! but the conversion doesn't use the full range and the calibration is not very linear.
//-----------------------------------------------------------------------------
BOOL ADS7843_Read16Bits (UCHAR ucCmd, INT *pDAVVal)
{
	BOOL bRet = FALSE;
	DWORD dwNbBytes = 0;
	WORD wData = 0;
	
	if (ghTouchScreenSPIDriver == NULL)
		return FALSE;
#ifdef USE_NORMAL_SPI_TRANSACTION
	// implementation Normal SPI transaction

	{
		T_SPI_TRANSACTION_ELEMENT_PARAM SpiTransaction;
		UCHAR RxBuffer[3];
		UCHAR TxBuffer[3];

		// Init
		SpiTransaction.pTxBuffer = &TxBuffer;
		SpiTransaction.pRxBuffer = &RxBuffer;
		SpiTransaction.dwSize    = 3; // total transfer size, in words (SPI is configured in 8b)
		
		TxBuffer[0] = ucCmd;
		TxBuffer[1] = 0;
		TxBuffer[2] = 0;

		RxBuffer[0] = 0;
		RxBuffer[1] = 0;
		RxBuffer[2] = 0;
						
		bRet = DeviceIoControl(ghTouchScreenSPIDriver, IOCTL_SPI_TRANSACTION,
						&SpiTransaction, sizeof(SpiTransaction), NULL, 0, NULL, NULL);
		//RETAILMSG(1,(TEXT("RxBuffer[0] = 0x%x RxBuffer[1] = 0x%x RxBuffer[2] = 0x%x \r\n"),RxBuffer[0],RxBuffer[1],RxBuffer[2]));
	
		if (bRet)
		{
			*pDAVVal = (INT) (RxBuffer[1] << 4 | RxBuffer[2] >> 4);
		}
		
	}

	
#else //USE_NORMAL_SPI_TRANSACTION

	bRet = DeviceIoControl(
    					ghTouchScreenSPIDriver,		//HANDLE hDevice, 
    					IOCTL_SPI_ADS7843,			//DWORD dwIoControlCode, 
    					&ucCmd,                 	//LPVOID lpInBuffer, 
    					sizeof(ucCmd),          	//DWORD nInBufferSize, 
    					&wData,						//LPVOID lpOutBuffer, 
    					sizeof(wData),				//DWORD nOutBufferSize, 
    					&dwNbBytes,					//LPDWORD lpBytesReturned, 
    					NULL						//LPOVERLAPPED lpOverlapped
    					);	


	if (bRet && dwNbBytes == sizeof(wData))
		*pDAVVal = (INT)wData;
	else 
		bRet = FALSE;
		
#endif // USE_NORMAL_SPI_TRANSACTION

	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL ADS7843_ReadX(INT *pUnCalX)
//!
//! \brief		Read X coordiante
//!
//! \param		pUnCalX : X coordinate value
//!
//! \return		\e TRUE when all is good
//!	\return		\e FALSE when all is bad
//!
//-----------------------------------------------------------------------------
BOOL ADS7843_ReadX(INT *pUnCalX)
{
	return ADS7843_Read16Bits ((ADS7843_READ | ADS7843_X), pUnCalX);
}


//-----------------------------------------------------------------------------
//! \fn			BOOL ADS7843_ReadY(INT *pUnCalY)
//!
//! \brief		Read Y coordiante
//!
//! \param		pUnCalY : Y coordinate value
//!
//! \return		\e TRUE when all is good
//!	\return		\e FALSE when all is bad
//!
//-----------------------------------------------------------------------------
BOOL ADS7843_ReadY(INT *pUnCalY)
{
	return ADS7843_Read16Bits ((ADS7843_READ | ADS7843_Y), pUnCalY);
}


//-----------------------------------------------------------------------------
//! \fn			BOOL ADS7843_ReadXY(INT *pUnCalX, INT *pUnCalY)
//!
//! \brief		Read X and Y coordiantes
//!
//! \param		pUnCalX : X coordinate value
//! \param		pUnCalY : Y coordinate value
//!
//! \return		\e TRUE when all is good
//!	\return		\e FALSE when all is bad
//!
//-----------------------------------------------------------------------------
BOOL ADS7843_ReadXY(INT *pUnCalX, INT *pUnCalY)
{
	BOOL bRet = TRUE;
	// Read X
	bRet = ADS7843_ReadX(pUnCalX);
	// Read Y
	bRet = bRet && ADS7843_ReadY(pUnCalY);

//	RETAILMSG(1,(TEXT("x %d y %d\r\n"),*pUnCalX,*pUnCalY));
	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn			void CustomizeCoordinates (INT *pUnCalX, INT *pUnCalY)
//!
//! \brief		Customize X and Y coordiantes
//!
//! \param		pUnCalX : X coordinate value
//! \param		pUnCalY : Y coordinate value
//!
//!
//-----------------------------------------------------------------------------
void CustomizeCoordinates (INT *pUnCalX, INT *pUnCalY)
{
	// No cutomization needs
}


//! @}

////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/TouchScreen/Dll/ADS7843SPI.cpp $
////////////////////////////////////////////////////////////////////////////////
//

//! @}
