//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9263EK/SRC/BOOTLOADER/FirstBoot/SPIDataFlash.c
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/BOOTLOADER/FirstBoot/SPIDataFlash.c $
//!   $Author: ltourlonias $
//!   $Revision: 684 $
//!   $Date: 2007-04-13 14:35:48 +0200 (ven., 13 avr. 2007) $
//! \endif
//!
//! Low Level functions for SPI DataFlash
//-----------------------------------------------------------------------------
//! \addtogroup	FIRSTBOOT
//! @{
//!  
// System include
#include <windows.h>

#include "oal_memory.h"

// Local include
#include "firstboot_cfg.h"
#include "AT91SAM926x.h"
#include "lib_AT91SAM926x.h"
#include "SPIDataFlash.h"
#include "AT91SAM926x_interface.h"
#include "dbgu.h"


// Global variable
static AT91S_DataFlash DataFlashInst;
#define MAX_SECTOR_SIZE 1024
#define AT91C_MASTER_CLOCK              48000000

AT91PS_PIO g_VaBasePIOA;
AT91PS_PIO g_VaBasePIOC;
AT91PS_PMC g_VaBasePMC;
AT91PS_SPI g_VaBaseSPI0;
void OEMCacheRangeFlush(LPVOID pAddr, DWORD dwLength, DWORD dwFlags); /* Defined in kernel\buildexe\cfw.c */


//----------------------------------------------------------------------------
/// SPI Low level Initialization (PIOs, clock and reset)
//----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//! \fn			static void AT91F_SpiInit(void)
//!
//! \brief		This function performs SPI initialization
//-----------------------------------------------------------------------------
static void AT91F_SpiInit(void)
{
    unsigned int dwMasterClock;
    
	dwMasterClock = AT91C_MASTER_CLOCK;

	// Configure PIOs
	g_VaBasePIOA->PIO_BSR = AT91C_PA0_SPI0_MISO | AT91C_PA1_SPI0_MOSI | AT91C_PA2_SPI0_SPCK  | AT91C_PA5_SPI0_NPCS0;
	g_VaBasePIOA->PIO_PDR = AT91C_PA0_SPI0_MISO | AT91C_PA1_SPI0_MOSI | AT91C_PA2_SPI0_SPCK | AT91C_PA5_SPI0_NPCS0;

	// Enable CLock
	AT91C_BASE_PMC->PMC_PCER = 1 << AT91C_ID_SPI0;

	// Reset the SPI
	g_VaBaseSPI0->SPI_CR = AT91C_SPI_SWRST;

    // Configure SPI in Master Mode with No CS selected !!!
	g_VaBaseSPI0->SPI_MR = AT91C_SPI_MSTR | AT91C_SPI_MODFDIS | AT91C_SPI_PCS;
	
	// Configure correct chip select
	g_VaBaseSPI0->SPI_CSR[CHIP_SELECT_NUMBER] = AT91C_SPI_CPOL | (AT91C_SPI_DLYBS & 0x100000) | AT91C_SPI_DLYBCT & 0x10000000 | ((dwMasterClock / (AT91C_SPI_CLK)) << 8);
}


//----------------------------------------------------------------------------
//! \fn    static AT91F_SpiEnable
//!		      							  
//! \brief Enable SPI chip select 											  
//----------------------------------------------------------------------------
static void AT91F_SpiEnable(void)
{
	g_VaBaseSPI0->SPI_MR &= 0xFFF0FFFF;
	g_VaBaseSPI0->SPI_MR |= ((AT91C_SPI_PCS_GENERIC<<16) & AT91C_SPI_PCS);

	// SPI_Enable
	g_VaBaseSPI0->SPI_CR = AT91C_SPI_SPIEN;
}


//----------------------------------------------------------------------------
//! \fn    unsigned int AT91F_SpiWrite(AT91PS_DataflashDesc pDesc)
//!
//! \brief Set the PDC registers for a transfert											  
//----------------------------------------------------------------------------
unsigned int AT91F_SpiWrite(AT91PS_DataflashDesc pDesc)
{
	
	pDesc->state = BUSY;
   	g_VaBaseSPI0->SPI_PTCR = AT91C_PDC_TXTDIS + AT91C_PDC_RXTDIS;

	// Initialize the Transmit and Receive Pointer
	g_VaBaseSPI0->SPI_RPR = (unsigned int)pDesc->rx_cmd_pt;
	g_VaBaseSPI0->SPI_TPR = (unsigned int)pDesc->tx_cmd_pt;

	// Intialize the Transmit and Receive Counters
	g_VaBaseSPI0->SPI_RCR = pDesc->rx_cmd_size;
	g_VaBaseSPI0->SPI_TCR = pDesc->tx_cmd_size;

	if (pDesc->tx_data_size != 0)
	{
		// Initialize the Next Transmit and Next Receive Pointer
		g_VaBaseSPI0->SPI_RNPR = (unsigned int)pDesc->rx_data_pt;
		g_VaBaseSPI0->SPI_TNPR = (unsigned int)pDesc->tx_data_pt ;

		// Intialize the Next Transmit and Next Receive Counters
		g_VaBaseSPI0->SPI_RNCR = pDesc->rx_data_size ;
		g_VaBaseSPI0->SPI_TNCR = pDesc->tx_data_size ;
   	}


	g_VaBaseSPI0->SPI_PTCR = AT91C_PDC_TXTEN + AT91C_PDC_RXTEN;
	while(!(g_VaBaseSPI0->SPI_SR & AT91C_SPI_RXBUFF));

   	g_VaBaseSPI0->SPI_PTCR = AT91C_PDC_TXTDIS + AT91C_PDC_RXTDIS;
   	pDesc->state = IDLE;

	return AT91C_DATAFLASH_OK;
}


//----------------------------------------------------------------------
//! \fn    static AT91S_DataFlashStatus AT91F_DataFlashSendCommand(AT91PS_DataFlash pDataFlash, unsigned char OpCode, unsigned int CmdSize, unsigned int DataflashAddress)
//!			
//! \brief Generic function to send a command to the dataflash		
//----------------------------------------------------------------------
static AT91S_DataFlashStatus AT91F_DataFlashSendCommand(
	AT91PS_DataFlash pDataFlash,
	unsigned char OpCode,
	unsigned int CmdSize,
	unsigned int DataflashAddress)
{
    unsigned int adr;
	

	if ((pDataFlash->pDataFlashDesc->state) != IDLE)
	{
		return AT91C_DATAFLASH_BUSY;
	}

	// Process the address to obtain page address and byte address
	adr = ((DataflashAddress / (pDataFlash->pDevice->pages_size)) << pDataFlash->pDevice->page_offset) + (DataflashAddress % (pDataFlash->pDevice->pages_size));

	// Fill the  command  buffer
	pDataFlash->pDataFlashDesc->command[0] = OpCode;
	if (pDataFlash->pDevice->pages_number >= 16384)
	{
		pDataFlash->pDataFlashDesc->command[1] = (unsigned char)((adr & 0x0F000000) >> 24);
		pDataFlash->pDataFlashDesc->command[2] = (unsigned char)((adr & 0x00FF0000) >> 16);
		pDataFlash->pDataFlashDesc->command[3] = (unsigned char)((adr & 0x0000FF00) >> 8);
		pDataFlash->pDataFlashDesc->command[4] = (unsigned char)(adr & 0x000000FF);
	}
	else
	{	
		pDataFlash->pDataFlashDesc->command[1] = (unsigned char)((adr & 0x00FF0000) >> 16);
		pDataFlash->pDataFlashDesc->command[2] = (unsigned char)((adr & 0x0000FF00) >> 8);
		pDataFlash->pDataFlashDesc->command[3] = (unsigned char)(adr & 0x000000FF) ;
		pDataFlash->pDataFlashDesc->command[4] = 0;
	}

	pDataFlash->pDataFlashDesc->command[5] = 0;
	pDataFlash->pDataFlashDesc->command[6] = 0;
	pDataFlash->pDataFlashDesc->command[7] = 0;

	// Initialize the SpiData structure for the spi write fuction
	pDataFlash->pDataFlashDesc->tx_cmd_pt   =  pDataFlash->pDataFlashDesc->command ;
	pDataFlash->pDataFlashDesc->tx_cmd_size =  CmdSize ;
	pDataFlash->pDataFlashDesc->rx_cmd_pt   =  pDataFlash->pDataFlashDesc->command ;
	pDataFlash->pDataFlashDesc->rx_cmd_size =  CmdSize ;


	return AT91F_SpiWrite (pDataFlash->pDataFlashDesc);			
}


//----------------------------------------------------------------------
//! \fn    static AT91S_DataFlashStatus AT91F_DataFlashGetStatus(AT91PS_DataflashDesc pDesc)
//!			
//! \brief Read the status register of the dataflash			
//----------------------------------------------------------------------
static AT91S_DataFlashStatus AT91F_DataFlashGetStatus(AT91PS_DataflashDesc pDesc)
{
	AT91S_DataFlashStatus status;

	// If a transfert is in progress ==> return 0
	if ((pDesc->state) != IDLE)
	{
		return AT91C_DATAFLASH_BUSY;
	}
	
	// First send the read status command (D7H)
	pDesc->command[0] = DB_STATUS;
	pDesc->command[1] = 0;

	pDesc->DataFlash_state  = GET_STATUS;
    pDesc->tx_data_size 	= 0 ;	// Transmit the command and receive response
    pDesc->tx_cmd_pt 		= pDesc->command ;
    pDesc->rx_cmd_pt 		= pDesc->command ;
    pDesc->rx_cmd_size 		= 2 ;
    pDesc->tx_cmd_size 		= 2 ;

	
    status = AT91F_SpiWrite(pDesc);
	pDesc->DataFlash_state = *((unsigned char *) (pDesc->rx_cmd_pt) +1);
	
	return status;
}

//-----------------------------------------------------------------------------
//! \fn			static AT91S_DataFlashStatus AT91F_DataFlashWaitReady(AT91PS_DataflashDesc pDataFlashDesc, unsigned int timeoutMs)
//!
//! \brief		wait for dataflash ready (bit7 of the status register == 1)
//!
//! \param		pDataFlashDesc	Pointer on a DataFlash Descriptor Structure
//! \param		timeoutMs		Timeout in ms
//!
//! \return		DataFlash status "ready or not"
//-----------------------------------------------------------------------------
static AT91S_DataFlashStatus AT91F_DataFlashWaitReady(AT91PS_DataflashDesc pDataFlashDesc, unsigned int timeoutMs)
{	
	AT91PS_PITC		pPITC = AT91C_BASE_PITC;
	int count = pPITC->PITC_PIIR;
	unsigned int timeout = timeoutMs * (AT91C_MASTER_CLOCK/16000);

	
	if(pDataFlashDesc->state != IDLE)
	{
		return AT91C_DATAFLASH_ERROR;
	}

	pDataFlashDesc->DataFlash_state = 0;

	do
	{
		(unsigned int)AT91F_DataFlashGetStatus(pDataFlashDesc);
		if((pDataFlashDesc->DataFlash_state & 0x80) == 0x80)
		{
			return AT91C_DATAFLASH_OK;
		}
	}
	while((pPITC->PITC_PIIR -  count) < timeout);

	return AT91C_DATAFLASH_ERROR;
}


//-----------------------------------------------------------------------------
//! \fn			static AT91S_DataFlashStatus AT91F_DataFlashContinuousRead(	AT91PS_DataFlash pDataFlash, int src, unsigned char *dataBuffer, int sizeToRead)
//!
//! \brief		Continuous stream Read
//!
//! \param		pDataFlash		Pointer on a DataFlash Structure
//! \param		src				Dataflash address
//! \param		dataBuffer		Data buffer pointer
//! \param		sizeToRead		Data buffer size
//!
//! \return		DataFlash status
//-----------------------------------------------------------------------------
static AT91S_DataFlashStatus AT91F_DataFlashContinuousRead(AT91PS_DataFlash pDataFlash,
	int src,
	unsigned char *dataBuffer,
	int sizeToRead)
{
	AT91S_DataFlashStatus status;
	// Test the size to read in the device
	if ( (src + sizeToRead) > (pDataFlash->pDevice->pages_size * (pDataFlash->pDevice->pages_number)))
	{
		return AT91C_DATAFLASH_MEMORY_OVERFLOW;
	}

	pDataFlash->pDataFlashDesc->rx_data_pt = dataBuffer;
	pDataFlash->pDataFlashDesc->rx_data_size = sizeToRead;
	pDataFlash->pDataFlashDesc->tx_data_pt = dataBuffer;
	pDataFlash->pDataFlashDesc->tx_data_size = sizeToRead;
	
	status = AT91F_DataFlashSendCommand (pDataFlash, DB_CONTINUOUS_ARRAY_READ, 8, src);
	// Send the command to the dataflash
	return(status);
}


//-----------------------------------------------------------------------------
//! \fn			static AT91S_DataFlashStatus AT91F_MainMemoryToBufferTransfert(AT91PS_DataFlash pDataFlash, unsigned char BufferCommand, unsigned int page)
//!
//! \brief		Read a page in the SRAM Buffer 1 or 2
//!
//! \param		pDataFlash		Pointer on a DataFlash Structure
//! \param		BufferCommand	Command : DB_PAGE_2_BUF1_TRF or DB_PAGE_2_BUF2_TRF
//! \param		page			Page concerned
//!
//! \return		DataFlash status
//-----------------------------------------------------------------------------
static AT91S_DataFlashStatus AT91F_MainMemoryToBufferTransfert(
	AT91PS_DataFlash pDataFlash,
	unsigned char BufferCommand,
	unsigned int page)
{
	int cmdsize;
	// Test if the buffer command is legal
	if ((BufferCommand != DB_PAGE_2_BUF1_TRF) && (BufferCommand != DB_PAGE_2_BUF2_TRF))
	{
		return AT91C_DATAFLASH_BAD_COMMAND;
	}

	// No data to transmit or receive
    pDataFlash->pDataFlashDesc->tx_data_size = 0;
	cmdsize = 4;
	if (pDataFlash->pDevice->pages_number >= 16384)
	{
		cmdsize = 5;
	}
	return(AT91F_DataFlashSendCommand (pDataFlash, BufferCommand, cmdsize, page*pDataFlash->pDevice->pages_size));
}


//-----------------------------------------------------------------------------
//! \fn			static AT91S_DataFlashStatus AT91F_DataFlashWriteBuffer(AT91PS_DataFlash pDataFlash, unsigned char BufferCommand, unsigned char *dataBuffer, unsigned int bufferAddress, int SizeToWrite)
//! \brief		Write data to the internal sram buffer 1 or 2
//!
//! \param		pDataFlash		Pointer on a DataFlash Structure
//! \param		BufferCommand	Command : DB_BUF1_WRITE or DB_BUF2_WRITE
//! \param		dataBuffer		Data buffer to write
//! \param		bufferAddress	Address in the internal buffer
//! \param		SizeToWrite		Data buffer size	
//!
//! \return		DataFlash status
//-----------------------------------------------------------------------------
static AT91S_DataFlashStatus AT91F_DataFlashWriteBuffer(
	AT91PS_DataFlash pDataFlash,
	unsigned char BufferCommand,
	unsigned char *dataBuffer,
	unsigned int bufferAddress,
	int SizeToWrite)
{
	
	char temporaryBuffer[MAX_SECTOR_SIZE];
	int cmdsize;
	
	// Test if the size to write exceeds size of buffer
	if (SizeToWrite > MAX_SECTOR_SIZE)
	{
		return AT91C_DATAFLASH_BAD_COMMAND;
	}

	// Test if the buffer command is legal
	if ((BufferCommand != DB_BUF1_WRITE) && (BufferCommand != DB_BUF2_WRITE))
	{
		return AT91C_DATAFLASH_BAD_COMMAND;
	}

	// Buffer address must be lower than page size
	if (bufferAddress > (unsigned int)pDataFlash->pDevice->pages_size)
	{
		return AT91C_DATAFLASH_BAD_ADDRESS;
	}	

	if ((pDataFlash->pDataFlashDesc->state)  != IDLE)
	{
		return AT91C_DATAFLASH_BUSY;
	}

	
    // Send first Write Command
    pDataFlash->pDataFlashDesc->command[0] = BufferCommand;
	pDataFlash->pDataFlashDesc->command[1] = 0;
	if (pDataFlash->pDevice->pages_number >= 16384)
	{
	   	pDataFlash->pDataFlashDesc->command[2] = 0;
	   	pDataFlash->pDataFlashDesc->command[3] = (unsigned char)(((unsigned int)(bufferAddress &  pDataFlash->pDevice->byte_mask)) >> 8) ;
	   	pDataFlash->pDataFlashDesc->command[4] = (unsigned char)((unsigned int)bufferAddress  & 0x00FF) ;
		cmdsize = 5;
	}
	else
	{
		pDataFlash->pDataFlashDesc->command[2] = (unsigned char)(((unsigned int)(bufferAddress &  pDataFlash->pDevice->byte_mask)) >> 8) ;
	   	pDataFlash->pDataFlashDesc->command[3] = (unsigned char)((unsigned int)bufferAddress  & 0x00FF) ;
	   	pDataFlash->pDataFlashDesc->command[4] = 0;
		cmdsize = 4;
	}
	
	
	pDataFlash->pDataFlashDesc->tx_cmd_pt 	 = pDataFlash->pDataFlashDesc->command ;
    pDataFlash->pDataFlashDesc->tx_cmd_size  = cmdsize ;
    pDataFlash->pDataFlashDesc->rx_cmd_pt 	 = pDataFlash->pDataFlashDesc->command ;
    pDataFlash->pDataFlashDesc->rx_cmd_size  = cmdsize ;

	
	pDataFlash->pDataFlashDesc->rx_data_pt 	 = temporaryBuffer ;
    pDataFlash->pDataFlashDesc->tx_data_pt 	 = dataBuffer ;
    pDataFlash->pDataFlashDesc->rx_data_size = SizeToWrite ;
    pDataFlash->pDataFlashDesc->tx_data_size = SizeToWrite ;

	
	return AT91F_SpiWrite(pDataFlash->pDataFlashDesc);
}


//-----------------------------------------------------------------------------
//! \fn			AT91S_DataFlashStatus AT91F_PageErase(AT91PS_DataFlash pDataFlash, unsigned int page)
//!
//! \brief		Erase a page in the Data Flash
//!
//! \param		pDataFlash	Pointer on a DataFlash Structure
//! \param		page		Page concerned
//!
//! \return		DataFlash status
//-----------------------------------------------------------------------------
AT91S_DataFlashStatus AT91F_PageErase(AT91PS_DataFlash pDataFlash, unsigned int page)
{
	int cmdsize;
	// Test if the buffer command is legal	
	// No data to transmit or receive
    pDataFlash->pDataFlashDesc->tx_data_size = 0;
	
	cmdsize = 4;
	if (pDataFlash->pDevice->pages_number >= 16384)
	{
		cmdsize = 5;
	}
	return(AT91F_DataFlashSendCommand(pDataFlash, DB_PAGE_ERASE, cmdsize, page*pDataFlash->pDevice->pages_size));
}


//-----------------------------------------------------------------------------
//! \fn			static AT91S_DataFlashStatus AT91F_WriteBufferToMain(AT91PS_DataFlash pDataFlash, unsigned char BufferCommand, unsigned int dest)
//!
//! \brief		Write buffer to the main memory
//!
//! \param		pDataFlash		Pointer on a DataFlash Structure
//! \param		BufferCommand	Command : DB_BUF1_PAGE_PGM, DB_BUF1_PAGE_ERASE_PGM, DB_BUF2_PAGE_PGM or DB_BUF2_PAGE_ERASE_PGM
//! \param		dest			Main memory address
//!
//! \return		DataFlash status
//-----------------------------------------------------------------------------
static AT91S_DataFlashStatus AT91F_WriteBufferToMain(
											 AT91PS_DataFlash pDataFlash, 
											 unsigned char BufferCommand,	
											 unsigned int dest)
{
	int cmdsize;
	
	// Test if the buffer command is correct
	if ((BufferCommand != DB_BUF1_PAGE_PGM) &&
	    (BufferCommand != DB_BUF1_PAGE_ERASE_PGM) &&
	    (BufferCommand != DB_BUF2_PAGE_PGM) &&
	    (BufferCommand != DB_BUF2_PAGE_ERASE_PGM))
	{
		return AT91C_DATAFLASH_BAD_COMMAND;
	}

	// No data to transmit or receive
	pDataFlash->pDataFlashDesc->tx_data_size = 0;

	cmdsize = 4;
	if (pDataFlash->pDevice->pages_number >= 16384)
	{
		cmdsize = 5;
	}
	// Send the command to the dataflash
	return(AT91F_DataFlashSendCommand (pDataFlash, BufferCommand, cmdsize, dest));
}


//-----------------------------------------------------------------------------
//! \fn			static AT91S_DataFlashStatus AT91F_PartialPageWrite( AT91PS_DataFlash pDataFlash, unsigned char *src, unsigned int dest, unsigned int size)
//!
//!
//! \brief		Write partielly a page
//!
//! \param		pDataFlash	Pointer on a DataFlash Structure
//! \param		src			Buffer to write
//! \param		dest		Address to write in the data flash
//! \param		size		Size of the buffer to write
//!
//! \return		DataFlash status
//-----------------------------------------------------------------------------
static AT91S_DataFlashStatus AT91F_PartialPageWrite(
									AT91PS_DataFlash pDataFlash,
									unsigned char *src,
									unsigned int dest,
									unsigned int size)
{
	unsigned int page;
	unsigned int AdrInPage;

	page = dest / (pDataFlash->pDevice->pages_size);
	AdrInPage = dest % (pDataFlash->pDevice->pages_size);

	// Read the contents of the page in the Sram Buffer
	AT91F_MainMemoryToBufferTransfert(pDataFlash, DB_PAGE_2_BUF1_TRF, page);
	AT91F_DataFlashWaitReady(pDataFlash->pDataFlashDesc, AT91C_DATAFLASH_TIMEOUT);
	
	// Update the SRAM buffer
	AT91F_DataFlashWriteBuffer(pDataFlash, DB_BUF1_WRITE, src, AdrInPage, size);
	AT91F_DataFlashWaitReady(pDataFlash->pDataFlashDesc, AT91C_DATAFLASH_TIMEOUT);
	
	// Erase page if a 128 Mbits device
	if (pDataFlash->pDevice->pages_number >= 16384)
	{
		AT91F_PageErase(pDataFlash, page);
		AT91F_DataFlashWaitReady(pDataFlash->pDataFlashDesc, AT91C_DATAFLASH_TIMEOUT);
	}
	
	// Rewrite the modified Sram Buffer in the main memory
	return(AT91F_WriteBufferToMain(pDataFlash, DB_BUF1_PAGE_ERASE_PGM, (page*pDataFlash->pDevice->pages_size)));
}


//-----------------------------------------------------------------------------
//! \fn			static AT91S_DataFlashStatus AT91F_DataFlashWrite(AT91PS_DataFlash pDataFlash, unsigned char *src, int dest, int size )
//!
//! \brief		Function allowing writing to Data Flash
//!
//! \param		pDataFlash	Pointer on a DataFlash Structure
//! \param		src			Source Buffer to write
//! \param		dest		Address to write in the data flash
//! \param		size		Size of the buffer to write
//!
//! \return		DataFlash status
//-----------------------------------------------------------------------------
static AT91S_DataFlashStatus AT91F_DataFlashWrite(
										AT91PS_DataFlash pDataFlash,
										unsigned char *src,
										int dest,
										int size )
{
	unsigned int length;
	unsigned int page;
	unsigned int status;

	AT91F_SpiEnable();
			
    if (((unsigned int)dest + (unsigned int)size) > (unsigned int)(pDataFlash->pDevice->pages_size * (pDataFlash->pDevice->pages_number)))
	{
		return AT91C_DATAFLASH_MEMORY_OVERFLOW;
	}

    // If destination does not fit a page start address
    if ((dest % ((unsigned int)(pDataFlash->pDevice->pages_size)))  != 0 )
	{
		
		length = pDataFlash->pDevice->pages_size - (dest % ((unsigned int)(pDataFlash->pDevice->pages_size)));

		if ((unsigned int)size < length)
		{
			length = size;
		}

		if(!AT91F_PartialPageWrite(pDataFlash, src, dest, length))
		{
			return AT91C_DATAFLASH_ERROR;
		}

		AT91F_DataFlashWaitReady(pDataFlash->pDataFlashDesc, AT91C_DATAFLASH_TIMEOUT);

		// Update size, source and destination pointers
        size -= length;
        dest += length;
        src += length;
    }

    while (( size - pDataFlash->pDevice->pages_size ) >= 0 ) 
    {
		// Program dataflash page		
		page = (unsigned int)dest / (pDataFlash->pDevice->pages_size);

		status = AT91F_DataFlashWriteBuffer(pDataFlash, DB_BUF1_WRITE, src, 0, pDataFlash->pDevice->pages_size);
		AT91F_DataFlashWaitReady(pDataFlash->pDataFlashDesc, AT91C_DATAFLASH_TIMEOUT);
	
		status = AT91F_PageErase(pDataFlash, page);
		AT91F_DataFlashWaitReady(pDataFlash->pDataFlashDesc, AT91C_DATAFLASH_TIMEOUT);
		if (!status)
		{
			
			return AT91C_DATAFLASH_ERROR;
		}
		
		status = AT91F_WriteBufferToMain (pDataFlash, DB_BUF1_PAGE_PGM, dest);
		if(!status)
		{
			return AT91C_DATAFLASH_ERROR;
		}

		AT91F_DataFlashWaitReady(pDataFlash->pDataFlashDesc, AT91C_DATAFLASH_TIMEOUT);
	
		// Update size, source and destination pointers
	   	size -= pDataFlash->pDevice->pages_size ;
	   	dest += pDataFlash->pDevice->pages_size ;
	   	src  += pDataFlash->pDevice->pages_size ;
    }

    // If still some bytes to read
    if ( size > 0 )
	{
		
		// Program dataflash page
		if (!AT91F_PartialPageWrite(pDataFlash, src, dest, size))
		{
			return AT91C_DATAFLASH_ERROR;
		}
		AT91F_DataFlashWaitReady(pDataFlash->pDataFlashDesc, AT91C_DATAFLASH_TIMEOUT);
	}
	
    return AT91C_DATAFLASH_OK;
}


//-----------------------------------------------------------------------------
//!static int AT91F_DataFlashRead(AT91PS_DataFlash pDataFlash, unsigned long addr, unsigned long size, char *buffer)
//!
//! \brief		Function allowing reading from Data Flash
//!
//! \param		pDataFlash	Pointer on a DataFlash Structure
//! \param		addr		Address to read
//! \param		size		Size of to read
//! \param		buffer		Buffer which will receive data
//!
//! \return		DataFlash status
//-----------------------------------------------------------------------------
static int AT91F_DataFlashRead(
							AT91PS_DataFlash pDataFlash,
							unsigned long addr,
							unsigned long size,
							char *buffer)
{
	unsigned long SizeToRead;

	AT91F_SpiEnable();

	if (AT91F_DataFlashWaitReady(pDataFlash->pDataFlashDesc, AT91C_DATAFLASH_TIMEOUT) != AT91C_DATAFLASH_OK)
	{
		return -1;
	}

	while (size)
	{
		SizeToRead = (size < 0x8000)? size:0x8000;

		if (AT91F_DataFlashWaitReady(pDataFlash->pDataFlashDesc, AT91C_DATAFLASH_TIMEOUT) != AT91C_DATAFLASH_OK)
		{
			return -1;
		}

		if (AT91F_DataFlashContinuousRead (pDataFlash, addr, (unsigned char *)buffer, SizeToRead) != AT91C_DATAFLASH_OK)
		{
			return -1;
		}

		size -= SizeToRead;
		addr += SizeToRead;
		buffer += SizeToRead;
	}
   	return AT91C_DATAFLASH_OK;
}


//-----------------------------------------------------------------------------
//! \fn			static int AT91F_DataflashProbe(AT91PS_DataflashDesc pDesc)
//!
//! \brief		Check if DataFlash is available on the SPI bus
//!
//! \param		pDesc	Pointer on a DataFlash Descriptor Structure
//!
//! \return		Manufacturer and Device ID
//-----------------------------------------------------------------------------
static int AT91F_DataflashProbe(AT91PS_DataflashDesc pDesc)
{
	AT91F_SpiEnable();
   	AT91F_DataFlashGetStatus(pDesc);
	return ((pDesc->command[1] == 0xFF)? 0: (pDesc->command[1] & 0x3C));
}


//-----------------------------------------------------------------------------
//! \fn			int AT91F_DataflashInit(void)
//!
//! \brief		Check if DataFlash is available on the SPI bus
//!
//! \return		Number of DataFlash (0 or 1)
//-----------------------------------------------------------------------------
int AT91F_DataflashInit(void)
{
	int dfcode;
	int Nb_device = 0;

	g_VaBasePIOA = (AT91PS_PIO) AT91C_BASE_PIOA;
	g_VaBasePIOC = (AT91PS_PIO) AT91C_BASE_PIOC;
	g_VaBasePMC = (AT91PS_PMC) AT91C_BASE_PMC;
	g_VaBaseSPI0 = (AT91PS_SPI) AT91C_BASE_SPI0;


	AT91F_SpiInit();

	gDataflashInfo.Desc.state = IDLE;
	gDataflashInfo.id = 0;
	gDataflashInfo.Device.pages_number = 0;

	dfcode = AT91F_DataflashProbe(&gDataflashInfo.Desc);

	switch (dfcode)
	{
	case AT45DB161:
		gDataflashInfo.Device.pages_number = 4096;
		gDataflashInfo.Device.pages_size = 528;
		gDataflashInfo.Device.page_offset = 10;
		gDataflashInfo.Device.byte_mask = 0x300;
		gDataflashInfo.Desc.DataFlash_state = IDLE;
		gDataflashInfo.logical_address = CFG_DATAFLASH_LOGIC_ADDR_GENERIC;
		gDataflashInfo.id = dfcode;
		Nb_device++;
		break;

	case AT45DB321:
		gDataflashInfo.Device.pages_number = 8192;
		gDataflashInfo.Device.pages_size = 528;
		gDataflashInfo.Device.page_offset = 10;
		gDataflashInfo.Device.byte_mask = 0x300;
		gDataflashInfo.Desc.DataFlash_state = IDLE;
		gDataflashInfo.logical_address = CFG_DATAFLASH_LOGIC_ADDR_GENERIC;
		gDataflashInfo.id = dfcode;
		Nb_device++;
		break;

	case AT45DB642:
		gDataflashInfo.Device.pages_number = 8192;
		gDataflashInfo.Device.pages_size = 1056;
		gDataflashInfo.Device.page_offset = 11;
		gDataflashInfo.Device.byte_mask = 0x700;
		gDataflashInfo.Desc.DataFlash_state = IDLE;
		gDataflashInfo.logical_address = CFG_DATAFLASH_LOGIC_ADDR_GENERIC;
		gDataflashInfo.id = dfcode;
		Nb_device++;
		break;
	case AT45DB128:
		gDataflashInfo.Device.pages_number = 16384;
		gDataflashInfo.Device.pages_size = 1056;
		gDataflashInfo.Device.page_offset = 11;
		gDataflashInfo.Device.byte_mask = 0x700;
		gDataflashInfo.Desc.DataFlash_state = IDLE;
		gDataflashInfo.logical_address = CFG_DATAFLASH_LOGIC_ADDR_GENERIC;
		gDataflashInfo.id = dfcode;
		Nb_device++;
		break;
	default:
		break;
	}
	return (Nb_device);
}


//-----------------------------------------------------------------------------
//! \fn			static AT91PS_DataFlash AT91F_DataflashSelect(AT91PS_DataFlash pFlash, unsigned int *addr)
//!
//! \brief		Select the correct device in function of the address
//!
//! \param		pFlash	Pointer on a DataFlash Structure
//! \param		addr	Address of the DataFlash
//!
//! \return		Pointer on the DataFlash Structure
//-----------------------------------------------------------------------------
static AT91PS_DataFlash AT91F_DataflashSelect(AT91PS_DataFlash pFlash, unsigned int *addr)
{
	char addr_valid = 0;

	if ((*addr & 0xFF000000) == gDataflashInfo.logical_address) 
	{
		addr_valid = 1;		

	}

	if (!addr_valid)
	{
		pFlash = (AT91PS_DataFlash) 0;
		return pFlash;
	}
	
	pFlash->pDataFlashDesc = &(gDataflashInfo.Desc);
	pFlash->pDevice = &(gDataflashInfo.Device);
	*addr -= gDataflashInfo.logical_address;
	return pFlash;
}


//-----------------------------------------------------------------------------
//! \fn			int read_dataflash(unsigned long addr, unsigned long size, PVOID outBuffer)
//!
//! \brief		Dataflash memory read
//!
//! \param		addr	Address to read in the DataFlash
//! \param		size	Size to read
//! \param		outBuffer	Pointer on a buffer where the data is going to be stored
//!
//! \return		DataFlash status
//-----------------------------------------------------------------------------
int read_dataflash(unsigned long addr, unsigned long size, PVOID outBuffer)
{
	unsigned int AddrToRead = addr;
	AT91PS_DataFlash pFlash = &DataFlashInst;

	pFlash = AT91F_DataflashSelect(pFlash, &AddrToRead);
	if (pFlash == 0)
	{
		return -1;
	}
	return ( AT91F_DataFlashRead(pFlash, AddrToRead, size, outBuffer));
}


//-----------------------------------------------------------------------------
//! \fn			int write_dataflash(unsigned long addr_dest, PVOID addr_src, unsigned int size)
//!
//! \brief		Dataflash memory write
//!
//! \param		addr_dest	Address to write in the Data Flash
//! \param		addr_src	Address of the source buffer
//! \param		size		Size of the buffer to write
//!
//! \return		DataFlash status
//-----------------------------------------------------------------------------
int write_dataflash(unsigned long addr_dest, PVOID addr_src, unsigned int size)
{
	unsigned int AddrToWrite = addr_dest;
	AT91PS_DataFlash pFlash = &DataFlashInst;

	pFlash = AT91F_DataflashSelect(pFlash, &AddrToWrite);
	if (AddrToWrite == -1)
	{
		return -1;
	}
	return AT91F_DataFlashWrite(pFlash, (unsigned char *) addr_src, AddrToWrite, size);
}

//-----------------------------------------------------------------------------
//! \fn			void eraseAll_dataflash(void)
//!
//! \brief		Erase all dataflash
//-----------------------------------------------------------------------------
void eraseAll_dataflash(void)
{
	unsigned int i;

	if (gDataflashInfo.id != 0)
	{	
		AT91PS_DataFlash pFlash = &DataFlashInst;
	
		for(i=0;i<(unsigned int) gDataflashInfo.Device.pages_number;i++)
		{
			AT91F_PageErase(pFlash,i);
			
		}
		
	}
}

//! @}

//! @}
