//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9261_oal_ioctl_tab.h
//!
//! \brief		This file contains part of global IOCTL handler table for codes which must (or should) be implemented on AT91SAM9260-based platforms. 
//!
//!
//! This file is included by the platform's IOCTL table, g_oalIoCtlTable[].
//! Therefore, this file may ONLY define OAL_IOCTL_HANDLER entries. 
//-----------------------------------------------------------------------------


//------------------------------------------------------------------------------
// IOCTL CODE,                          Flags   Handler Function
//------------------------------------------------------------------------------

//! @}


