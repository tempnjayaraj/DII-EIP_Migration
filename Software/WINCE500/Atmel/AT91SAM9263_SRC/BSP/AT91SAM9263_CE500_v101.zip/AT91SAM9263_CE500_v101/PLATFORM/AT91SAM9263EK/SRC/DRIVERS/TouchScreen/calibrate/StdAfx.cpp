//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//
//! \file		StdAfx.cpp
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/TouchScreen/calibrate/StdAfx.cpp $
//!   $Author: ltourlonias $
//!   $Revision: 684 $
//!   $Date: 2007-04-13 14:35:48 +0200 (ven., 13 avr. 2007) $
//! \endif
//		TODO
//
//-----------------------------------------------------------------------------
// stdafx.cpp : source file that includes just the standard includes
//	TouchCalibrate1.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information
//! \addtogroup TOUCHSCREEN
//! @{
//

#include "stdafx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file
//! @}

//! @}
