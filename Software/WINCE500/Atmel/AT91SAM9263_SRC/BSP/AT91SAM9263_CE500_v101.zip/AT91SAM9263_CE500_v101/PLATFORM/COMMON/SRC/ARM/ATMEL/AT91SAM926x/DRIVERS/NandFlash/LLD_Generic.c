//-----------------------------------------------------------------------------
//! \addtogroup	DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/NandFlash/LLD_Generic.c
//!
//! \brief		Generic LLD part for NAND Flash memory
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/NandFlash/LLD_Generic.c $
//!   $Author: ltourlonias $
//!   $Revision: 657 $
//!   $Date: 2007-04-10 16:52:09 +0200 (mar., 10 avr. 2007) $
//! \endif
//!
//! 
//-----------------------------------------------------------------------------
//! \addtogroup	NandFlash
//! @{
//!

// System specific include
#include <windows.h>

#include "LLD_Generic.h"
#include "NandIds.h"

BOOL LLDGeneric_EraseBlock(NandChip * pChip, DWORD dwPhyBlckNb)
{
	BOOL bRet = TRUE;
	DWORD dwPhySecNb;
	DWORD dwStatus;
	//DEBUGMSG(1, (TEXT("->LLDGeneric_EraseBlock\n\r")));
	// Compute the number of first sector of the block
	dwPhySecNb = dwPhyBlckNb * pChip->pFlashDev->dwBlockNbSectors;

	NF_ENABLE(pChip);
	NF_WRITECMD(pChip, NAND_CMD_ERASE1);


	// Push the address of sector in three cycles
	NF_WRITEADDR(pChip, (UCHAR) (dwPhySecNb >>  0) & 0xFF);
	NF_WRITEADDR(pChip, (UCHAR) (dwPhySecNb >>  8) & 0xFF);
	if(pChip->pFlashDev->dwFlags & NAND_SMALLPAGES)
	{
		if(pChip->dwNbBytes > (32 << 20)) /* One more address cycle for devices > 32MiB */
		{
			NF_WRITEADDR(pChip, (UCHAR) (dwPhySecNb >> 16) & 0xFF);
		}
	}
	else
	{
		if(pChip->dwNbBytes > (128 << 20)) /* One more address cycle for devices > 128MiB */
		{ 
			NF_WRITEADDR(pChip, (UCHAR) (dwPhySecNb >> 16) & 0xFF);
		}
	}

	NF_WRITECMD(pChip, NAND_CMD_ERASE2);

	if (!NandFlash_WaitForReady(pChip, INTERRUPT_ON_READYBUSY,ERASE_TIMEOUT))
	{
		bRet = FALSE;
		RETAILMSG(1, (TEXT("LLD_ERASEBLOCK::Timed out waiting for Nand Ready signal\n\r")));
		goto exit;
	}
	
	NF_WRITECMD(pChip, NAND_CMD_STATUS);
	dwStatus = NF_READBYTE(pChip);
	if (dwStatus & NAND_STATUS_FAIL)
	{
		// Error during block erasing
		bRet = FALSE;
		RETAILMSG(1, (TEXT("LLD_ERASEBLOCK::Block erasing has failed on block physical 0x%X (status 0x%x)\n\r"), dwPhyBlckNb,dwStatus));
		goto exit;	
	}

exit:
	NF_DISABLE(pChip);
	//DEBUGMSG(1, (TEXT("<-LLDGeneric_EraseBlock\n\r")));
	return bRet;
}


BOOL LLDGeneric_WriteSectorSmall(NandChip *pChip, DWORD fZone, DWORD dwSectorAddr, PBYTE pInBuffer)
{
	BOOL	bRet = TRUE;
	DWORD	dwBytesToWrite;
	BYTE	Cmd;
	NandFlashDev *pFlashDev = pChip->pFlashDev;

	//DEBUGMSG(1, (TEXT("->LLDGeneric_WriteSectorSmall\n\r")));

	switch(fZone)
	{
		case ZONE_DATA:
			dwBytesToWrite = pFlashDev->dwDataNbBytes;
			Cmd = NAND_CMD_WRITE0;
			break;
		case ZONE_INFO:
			dwBytesToWrite = pFlashDev->dwSpareNbBytes;
			pInBuffer+=pFlashDev->dwDataNbBytes;
			Cmd = NAND_CMD_WRITEOOB;
			break;
		case ZONE_DATA|ZONE_INFO:
			dwBytesToWrite = pFlashDev->dwDataNbBytes + pFlashDev->dwSpareNbBytes;
			Cmd = NAND_CMD_WRITE0;
			break;
		default:
			RETAILMSG(1, (TEXT("LLDGeneric_WriteSectorSmall::Unknown zone\n\r")));
			bRet = FALSE;
			goto exit;
	}

	// Enable the chip
	NF_ENABLE(pChip);

	// Write from start or from Spares
	NF_WRITECMD(pChip, Cmd);

	// Write start
	NF_WRITECMD(pChip, NAND_CMD_SEQIN);

	// Push sector address, with no offset
	NF_WRITEADDR(pChip, 0x00);
	NF_WRITEADDR(pChip, (UCHAR) (dwSectorAddr >>  0) & 0xFF);
	NF_WRITEADDR(pChip, (UCHAR) (dwSectorAddr >>  8) & 0xFF);
	if(pChip->dwNbBytes > (32 << 20)) /* One more address cycle for devices > 32MiB */
	{
		NF_WRITEADDR(pChip, (UCHAR) (dwSectorAddr >> 16) & 0xFF);
	}

	//DEBUGMSG(1, (TEXT("LLDGeneric_WriteSectorSmall::BytesToWrite %d\n\r"), dwBytesToWrite));
	NF_WRITEBUF(pChip, pInBuffer, dwBytesToWrite);

	NF_WRITECMD(pChip, NAND_CMD_PAGEPROG);

	//  Wait for the Nand to be ready
	if (!NandFlash_WaitForReady(pChip, INTERRUPT_ON_READYBUSY,WRITE_TIMEOUT))
	{
		// Timed out waiting for Nand Ready signal
		bRet = FALSE;
		RETAILMSG(1, (TEXT("LLDGeneric_WriteSectorSmall::Timed out waiting for Nand Ready signal\n\r")));
		goto exit;
	}
	
exit:
	NF_DISABLE(pChip);
	//DEBUGMSG(1, (TEXT("<-LLDGeneric_WriteSectorSmall\n\r")));
	return bRet;
}

BOOL LLDGeneric_WriteSectorLarge(NandChip *pChip, DWORD fZone, DWORD dwSectorAddr, PBYTE pInBuffer) {
	BOOL	bRet = TRUE;
	DWORD	dwBytesToWrite;
	NandFlashDev *pFlashDev = pChip->pFlashDev;
	//DEBUGMSG(1, (TEXT("->LLDGeneric_WriteSectorLarge\n\r")));
	NF_ENABLE(pChip);
	NF_WRITECMD(pChip, NAND_CMD_SEQIN);

	// Push offset address
	switch(fZone)
	{
		case ZONE_DATA:
			dwBytesToWrite = pFlashDev->dwDataNbBytes;
			NF_WRITEADDR(pChip, 0x00);
			NF_WRITEADDR(pChip, 0x00);
			break;
		case ZONE_INFO:
			dwBytesToWrite = pFlashDev->dwSpareNbBytes;
			pInBuffer+=pFlashDev->dwDataNbBytes;
			if(pFlashDev->dwFlags & NAND_BUSWIDTH16)
			{
				// Div 2 is because we address in word and not in byte
				NF_WRITEADDR(pChip, (UCHAR) ((pFlashDev->dwDataNbBytes/2) >>  0) & 0xFF);
				NF_WRITEADDR(pChip, (UCHAR) ((pFlashDev->dwDataNbBytes/2) >>  8) & 0xFF);
			}
			else
			{
				NF_WRITEADDR(pChip, (UCHAR) ((pFlashDev->dwDataNbBytes) >>  0) & 0xFF);
				NF_WRITEADDR(pChip, (UCHAR) ((pFlashDev->dwDataNbBytes) >>  8) & 0xFF);
			}
			break;
		case ZONE_DATA|ZONE_INFO:
			dwBytesToWrite = pFlashDev->dwDataNbBytes + pFlashDev->dwSpareNbBytes;
			NF_WRITEADDR(pChip, 0x00);
			NF_WRITEADDR(pChip, 0x00);
			break;
		default:
			RETAILMSG(1, (TEXT("LLDGeneric_WriteSectorLarge::Unknown zone\n\r")));
			bRet = FALSE;
			goto exit;
	}

	// Push sector address
	NF_WRITEADDR(pChip, (UCHAR) (dwSectorAddr >>  0) & 0xFF);
	NF_WRITEADDR(pChip, (UCHAR) (dwSectorAddr >>  8) & 0xFF);
	//DEBUGMSG(1, (TEXT("LLDGeneric_WriteSectorLarge::%d %d\n\r"), pChip->dwNbBytes, (128 << 20)));
	if(pChip->dwNbBytes > (128 << 20)) /* One more address cycle for devices > 128MiB */
		NF_WRITEADDR(pChip, (UCHAR) (dwSectorAddr >> 16) & 0xFF);


	// Write data loop
	DEBUGMSG(1, (TEXT("LLDGeneric_WriteSectorLarge::BytesToWrite %d\n\r"), dwBytesToWrite));
	NF_WRITEBUF(pChip, pInBuffer, dwBytesToWrite);

	// Write end
	NF_WRITECMD(pChip, NAND_CMD_PAGEPROG);

	//  Wait for the Nand to be ready
	if (!NandFlash_WaitForReady(pChip, INTERRUPT_ON_READYBUSY,WRITE_TIMEOUT))
	{
		// Timed out waiting for Nand Ready signal
		bRet = FALSE;
		RETAILMSG(1, (TEXT("LLDGeneric_WriteSectorLarge::Timed out waiting for Nand Ready signal\n\r")));
		goto exit;
	}
	

exit:

	// Disable the chip
	NF_DISABLE(pChip);
	//DEBUGMSG(1, (TEXT("<-LLDGeneric_WriteSectorLarge\n\r")));
	return bRet;
}

BOOL LLDGeneric_ReadSectorSmall(NandChip *pChip, DWORD fZone, DWORD dwSectorAddr, PBYTE pOutBuffer) {
	BOOL	bRet = TRUE;
	DWORD	dwBytesToRead;
	BYTE	Cmd;
	NandFlashDev *pFlashDev = pChip->pFlashDev;
	//DEBUGMSG(1, (TEXT("->LLDGeneric_ReadSectorSmall\n\r")));
	switch(fZone)
	{
		case ZONE_DATA:
			dwBytesToRead = pFlashDev->dwDataNbBytes;
			Cmd = NAND_CMD_READ0;
			break;
		case ZONE_INFO:
			dwBytesToRead = pFlashDev->dwSpareNbBytes;
			pOutBuffer+=pFlashDev->dwDataNbBytes;
			Cmd = NAND_CMD_READOOB;
			break;
		case ZONE_DATA|ZONE_INFO:
			dwBytesToRead = pFlashDev->dwDataNbBytes + pFlashDev->dwSpareNbBytes;
			Cmd = NAND_CMD_READ0;
			break;
		default:
			RETAILMSG(1, (TEXT("LLDGeneric_ReadSectorSmall::Unknown zone\n\r")));
			bRet = FALSE;
			goto exit;
	}

	// WARNING : During a read procedure you can't call the ReadStatus flash cmd
	// The ReadStatus fill the read register with 0xC0 and then corrupt the read.

	NF_ENABLE(pChip);
	NF_WRITECMD(pChip, Cmd);

	// Push sector address, with no offset
	NF_WRITEADDR(pChip, 0x00);
	NF_WRITEADDR(pChip, (UCHAR) (dwSectorAddr >>  0) & 0xFF);
	NF_WRITEADDR(pChip, (UCHAR) (dwSectorAddr >>  8) & 0xFF);
	if(pChip->dwNbBytes > (32 << 20)) /* One more address cycle for devices > 32MiB */
		NF_WRITEADDR(pChip, (UCHAR) (dwSectorAddr >> 16) & 0xFF);

	// Wait for flash to be ready (can't pool on status, read upper WARNING)
	if (!NandFlash_WaitForReady(pChip, POOL_ON_READYBUSY,READ_TIMEOUT))
	{
		RETAILMSG(1, (TEXT("LLDGeneric_ReadSectorSmall: Timed out waiting for Nand Ready signal\n\r")));
	}

	// Read loop
	// DEBUGMSG(1, (TEXT("LLDGeneric_ReadSectorSmall::BytesToRead %d\n\r"), dwBytesToRead));

	NF_READBUF(pChip, pwOutBuffer, dwBytesToRead);
	
exit:

	// Disable the chip
	NF_DISABLE(pChip);
	//DEBUGMSG(1, (TEXT("<-LLDGeneric_ReadSectorSmall\n\r")));
	return bRet;
}

BOOL LLDGeneric_ReadSectorLarge(NandChip *pChip, DWORD fZone, DWORD dwSectorAddr, PBYTE pOutBuffer) {
	BOOL	bRet = TRUE;
	DWORD	dwBytesToRead;
	NandFlashDev *pFlashDev = pChip->pFlashDev;
	//DEBUGMSG(1, (TEXT("->LLDGeneric_ReadSectorLarge\n\r")));
	// WARNING : During a read procedure you can't call the ReadStatus flash cmd
	// The ReadStatus fill the read register with 0xC0 and then corrupt the read.

	NF_ENABLE(pChip);
	NF_WRITECMD(pChip, NAND_CMD_READ0);

	// Push offset address
	switch(fZone)
	{
		case ZONE_DATA:
			dwBytesToRead = pFlashDev->dwDataNbBytes;
			NF_WRITEADDR(pChip, 0x00);
			NF_WRITEADDR(pChip, 0x00);
			break;
		case ZONE_INFO:
			dwBytesToRead = pFlashDev->dwSpareNbBytes;
			pOutBuffer += pFlashDev->dwDataNbBytes;
			if(pFlashDev->dwFlags & NAND_BUSWIDTH16)
			{
				// Div 2 is because we address in word and not in byte
				NF_WRITEADDR(pChip, (UCHAR) ((pFlashDev->dwDataNbBytes/2) >>  0) & 0xFF);
				NF_WRITEADDR(pChip, (UCHAR) ((pFlashDev->dwDataNbBytes/2) >>  8) & 0xFF);
			}
			else
			{
				NF_WRITEADDR(pChip, (UCHAR) ((pFlashDev->dwDataNbBytes) >>  0) & 0xFF);
				NF_WRITEADDR(pChip, (UCHAR) ((pFlashDev->dwDataNbBytes) >>  8) & 0xFF);
			}
			break;
		case ZONE_DATA|ZONE_INFO:
			dwBytesToRead = pFlashDev->dwDataNbBytes + pFlashDev->dwSpareNbBytes;
			NF_WRITEADDR(pChip, 0x00);
			NF_WRITEADDR(pChip, 0x00);
			break;
		default:
			RETAILMSG(1, (TEXT("LLDGeneric_ReadSectorLarge::Unknown zone\n\r")));
			bRet = FALSE;
			goto exit;
	}

	// Push sector address
	NF_WRITEADDR(pChip, (UCHAR) (dwSectorAddr >>  0) & 0xFF);
	NF_WRITEADDR(pChip, (UCHAR) (dwSectorAddr >>  8) & 0xFF);
	//DEBUGMSG(1, (TEXT("LLDGeneric_ReadSectorLarge::%d %d\n\r"), pChip->dwNbBytes, (128 << 20)));
	if(pChip->dwNbBytes > (128 << 20)) /* One more address cycle for devices > 128MiB */
	{
		NF_WRITEADDR(pChip, (UCHAR) (dwSectorAddr >> 16) & 0xFF);
	}

	NF_WRITECMD(pChip, NAND_CMD_READSTART);

	// Wait for flash to be ready (can't pool on status, read upper WARNING)
	if (!NandFlash_WaitForReady(pChip, POOL_ON_READYBUSY,READ_TIMEOUT))
	{
		RETAILMSG(1, (TEXT("LLDGeneric_ReadSectorLarge: Timed out waiting for Nand Ready signal\n\r")));
	}

	//DEBUGMSG(1, (TEXT("LLDGeneric_ReadSectorLarge::BytesToRead %d\n\r"), dwBytesToRead));
	NF_READBUF(pChip, pwOutBuffer, dwBytesToRead);
	
exit:
	NF_DISABLE(pChip);
	//DEBUGMSG(1, (TEXT("<-LLDGeneric_ReadSectorLarge\n\r")));
	return bRet;
}

// End of Doxygen group NandFlash Driver
//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/NandFlash/LLD_Generic.c $
//-----------------------------------------------------------------------------
//
//! @}
