//-----------------------------------------------------------------------------
//! \addtogroup	DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//!
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/NandFlash/GenericECC.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/NandFlash/GenericECC.h $
//!   $Author: ltourlonias $
//!   $Revision: 657 $
//!   $Date: 2007-04-10 16:52:09 +0200 (mar., 10 avr. 2007) $
//! \endif
//! 
//! Header for the generic ECC functions
//-----------------------------------------------------------------------------

//! \addtogroup	NandFlash
//! @{
//!
#ifndef __GENERICECC_H__
#define __GENERICECC_H__

// Make a Doxygen group
//! \addtogroup GenericECC
//! @{

#define ECC_BLOCK_SIZE			512
#define ECC_RESULT_SIZE			6
#define MAX_DATA_SIZE_FOR_ECC	8192


BOOL ComputeECC(LPBYTE pData, DWORD dwDataBuffLen, LPBYTE pECC, DWORD dwECCBuffLen);
BOOL IsECCDataValid(LPBYTE pData, DWORD dwDataBuffLen, LPBYTE pExistingECC);
BOOL CorrectData(LPBYTE pData, DWORD dwDataBuffLen, LPBYTE pExistingECC);

#endif /*__GENERICECC_H__*/

// End of Doxygen group GenericECC
//! @}

//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/NandFlash/GenericECC.h $
//-----------------------------------------------------------------------------
//

//! @}
