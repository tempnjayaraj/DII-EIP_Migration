//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x/INC/LCDC/hwSurf.h 
//!
//! \brief		Declaration of hwSurf class, heritating from DDGPESurf abstract class
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/LCDC/hwSurf.h $
//!   $Author: pblanchard $
//!   $Revision: 993 $
//!   $Date: 2007-06-12 08:36:50 -0700 (Tue, 12 Jun 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	LCDC
//! @{
//!

#ifndef __hwSurf__
#define __hwSurf__

// Dependencies
//#include "Core.h"

class LCDC6xhw;

class hwSurf : public DDGPESurf
{
public:
	// Constructor - Destructor		
			hwSurf(			int width__l, 
							int height__l, 
							unsigned long offset, 
							void* pBits, 
							int stride, 
							EGPEFormat format, 
							Node2D *pNode2D);
		
			hwSurf(			int width__l, 
							int height__l, 
							unsigned long offset, 
							void *pBits, 
							int stride, 
							EGPEFormat format, 
							EDDGPEPixelFormat pixelFormat, 
							Node2D *pNode2D);

	virtual	~hwSurf			();

	DWORD	Top				() {return m_pNode2D->Top();};
	DWORD	Left			() {return m_pNode2D->Left();};

	Node2D			*m_pNode2D;
private:
			
};

#endif /*__hwSurf__*/

//! @}

//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/LCDC/hwSurf.h $
//-----------------------------------------------------------------------------
// 
//! @}
