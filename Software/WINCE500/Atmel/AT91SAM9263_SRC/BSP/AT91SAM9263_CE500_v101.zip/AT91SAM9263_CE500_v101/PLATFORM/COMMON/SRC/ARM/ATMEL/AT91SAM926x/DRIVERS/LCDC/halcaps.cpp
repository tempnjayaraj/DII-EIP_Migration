//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x/DRIVERS/LCDC/halcaps.cpp
//!
//! \brief		
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/LCDC/halcaps.cpp $
//!   $Author: pblanchard $
//!   $Revision: 1008 $
//!   $Date: 2007-06-15 04:24:36 -0700 (Fri, 15 Jun 2007) $
//! \endif
//!
//-----------------------------------------------------------------------------
//! \addtogroup	LCDC
//! @{
//

//-----------------------------------------------------------------------------
//
// This file is kept as is for the AT91SAM9261EK, no real modifications as been made.
// A problem while running D3D application could be noticed when using non RGB mask
// In fact DirectDraw & GDI support BGR mask, but Direct3D reference driver doesn't !
// If you want to use BGR mask ( With the 9261EK RevB you can't use a standard RGB mask )
// in a Direct3D application, you should recode your own D3D driver ! :( sorry
// .DMR
//
//-----------------------------------------------------------------------------

#include "LCDC\precomp.h"

#ifdef DDRAW_ENABLE

// Here are callbacks and capabilities description for your DDraw driver

//! \addtogroup	DirectDraw
//! @{

DDHAL_DDCALLBACKS cbDDCallbacks = {

    sizeof( DDHAL_DDCALLBACKS ),		// dwSize
	DDHAL_CB32_DESTROYDRIVER |			// dwFlags
	DDHAL_CB32_CREATESURFACE |
	DDHAL_CB32_SETCOLORKEY |
	DDHAL_CB32_SETMODE |
	DDHAL_CB32_WAITFORVERTICALBLANK |
	DDHAL_CB32_CANCREATESURFACE |
	DDHAL_CB32_CREATEPALETTE |
//	DDHAL_CB32_GETSCANLINE |
	DDHAL_CB32_SETEXCLUSIVEMODE |
	DDHAL_CB32_FLIPTOGDISURFACE |
	0,
    HalDestroyDriver,				// DestroyDriver
    DDGPECreateSurface,				// CreateSurface
    DDGPESetColorKeyDrv,			// SetColorKey
    DDGPESetMode,					// SetMode
    HalWaitForVerticalBlank,		// WaitForVerticalBlank
    HalCanCreateSurface, 			// CanCreateSurface
    DDGPECreatePalette, 			// CreatePalette
    0, 								// GetScanLine
    HalSetExclusiveMode,			// SetExclusiveMode
    DDGPEFlipToGDISurface			// FlipToGDISurface
};

// callbacks from the DIRECTDRAWCOLORCONTROL pseudo object

DDHAL_DDCOLORCONTROLCALLBACKS ColorControlCallbacks =
{
    sizeof(DDHAL_DDCOLORCONTROLCALLBACKS),
    0, // DDHAL_COLOR_COLORCONTROL,
    0  // &HalColorControl
};

// callbacks from the DIRECTDRAWEXEBUF psuedo object

DDHAL_DDEXEBUFCALLBACKS cbDDExeBufCallbacks = {

    sizeof( DDHAL_DDEXEBUFCALLBACKS ), // dwSize
    DDHAL_EXEBUFCB32_CANCREATEEXEBUF |
    DDHAL_EXEBUFCB32_CREATEEXEBUF    |
    DDHAL_EXEBUFCB32_DESTROYEXEBUF   |
    DDHAL_EXEBUFCB32_LOCKEXEBUF      |
    DDHAL_EXEBUFCB32_UNLOCKEXEBUF,		// dwFlags
    HalCanCreateSurface,			// CanCreateExecuteBuffer
    DDGPECreateExecuteBuffer,		// CreateExecuteBuffer
    DDGPEDestroyExecuteBuffer,		// DestroyExecuteBuffer
    DDGPELock,					// Lock
    DDGPEUnlock 				// Unlock
};

// callbacks from the DIRECTDRAWKERNEL pseudo object

DDHAL_DDKERNELCALLBACKS KernelCallbacks =
{
    sizeof(DDHAL_DDKERNELCALLBACKS),
	0,
	0
};

// callbacks from the DIRECTDRAWMISCELLANEOUS object

DDHAL_DDMISCELLANEOUSCALLBACKS MiscellaneousCallbacks = {

    sizeof(DDHAL_DDMISCELLANEOUSCALLBACKS),
	0,
    0, //HalGetAvailDriverMemory,
    0, //HalUpdateNonLocalHeap,
    0, //HalGetHeapAlignment,
    0  //HalGetSysmemBltStatus
};

// callbacks from the DIRECTDRAWPALETTE object

DDHAL_DDPALETTECALLBACKS cbDDPaletteCallbacks = {

    sizeof( DDHAL_DDPALETTECALLBACKS ), // dwSize
    DDHAL_PALCB32_DESTROYPALETTE |		// dwFlags
    DDHAL_PALCB32_SETENTRIES |
	0,
    DDGPEDestroyPalette,				// DestroyPalette
    DDGPESetEntries					// SetEntries
};


// callbacks from the DIRECTDRAWSURFACE object

DDHAL_DDSURFACECALLBACKS cbDDSurfaceCallbacks = {

    sizeof( DDHAL_DDSURFACECALLBACKS ), // dwSize
	DDHAL_SURFCB32_DESTROYSURFACE | 	// dwFlags
	DDHAL_SURFCB32_FLIP |
	DDHAL_SURFCB32_SETCLIPLIST |
	DDHAL_SURFCB32_LOCK |
	DDHAL_SURFCB32_UNLOCK |
	DDHAL_SURFCB32_BLT |
	DDHAL_SURFCB32_SETCOLORKEY |
	DDHAL_SURFCB32_GETBLTSTATUS |
	DDHAL_SURFCB32_GETFLIPSTATUS |
	DDHAL_SURFCB32_SETPALETTE |
	0,
    DDGPEDestroySurface,			// DestroySurface
    HalFlip,						// Flip
    HalSetClipList,					// SetClipList
    HalLock,						// Lock
    DDGPEUnlock,					// Unlock
    HalBlt,							// Blt
    HalSetColorKey,					// SetColorKey
    0,								// AddAttachedSurface
    HalGetBltStatus,				// GetBltStatus
    HalGetFlipStatus,				// GetFlipStatus
    0,								// UpdateOverlay
    0,								// SetOverlayPosition
	NULL,							// reserved4
    DDGPESetPalette,				// SetPalette
};

DDHAL_DDHALMEMORYCALLBACKS HalMemoryCallbacks = {

    sizeof(DDHAL_DDHALMEMORYCALLBACKS),
	0,
};


const DDKERNELCAPS KernelCaps =
{
    sizeof(DDKERNELCAPS),
    0,
    0
};


#define SCREEN_WIDTH	(g_pGPE->ScreenWidth())
#define SCREEN_HEIGHT	(g_pGPE->ScreenHeight())


// set up by HalInit
// This global pointer is to be recorded in the DirectDraw structure
DDGPE*			g_pGPE					= (DDGPE*)NULL;
DDGPESurf*		g_pDDrawPrimarySurface	= NULL;

// InitDDHALInfo must set up this information
unsigned long	g_nVideoMemorySize		= 0L;
unsigned char * g_pVideoMemory			= NULL; // virtual address of video memory from client's side


EXTERN_C void buildDDHALInfo( LPDDHALINFO lpddhi, DWORD modeidx ) {

	memset( lpddhi, 0, sizeof(DDHALINFO) ); 	// Clear the DDHALINFO structure

  LCDC6xhw * pLCDC62hw = (LCDC6xhw *)g_pGPE;
  DDHALMODEINFO * ModeTable = NULL;
  ModeTable = new DDHALMODEINFO();
  if (!ModeTable) {

    DEBUGMSG( GPE_ZONE_INIT,(TEXT("Unable to allocate mode table!\r\n")) );
    return;
  }

  ModeTable->dwWidth = pLCDC62hw->m_pMode->width;
  ModeTable->dwHeight = pLCDC62hw->m_pMode->height;
  ModeTable->lPitch = pLCDC62hw->m_VidMemStrideByte;
  ModeTable->dwBPP = pLCDC62hw->m_pMode->Bpp;
  if (ModeTable->dwBPP <= 8) {
    ModeTable->wFlags = DDMODEINFO_PALETTIZED;
  }
  else {
    ModeTable->wFlags = 0;
  }
  ModeTable->wRefreshRate = pLCDC62hw->m_pMode->frequency;
  switch(ModeTable->dwBPP)
  {
	  case	8:
		  ModeTable->dwRBitMask = 0;
		  ModeTable->dwGBitMask = 0;
		  ModeTable->dwBBitMask = 0;
		  ModeTable->dwAlphaBitMask = 0;
		  break;

	  case	16:


			////////////////////////////////////////////////////////////
			//
			// **********************   WARNING    ******************
			//
			// If you got a problem with D3D application, please reset
			// down values to : dwRBitMask = 0x7C00; dwGBitMask = 0x03E0; dwBBitMask = 0x001F;
			// These values are supported by D3D reference driver, but results
			// in a wrong color space. ie : red apears blue, and vice versa
			//	
			////////////////////////////////////////////////////////////
//#define DONT_USE_D3D
#ifdef DONT_USE_D3D
			// X1 R5 G5 B5		-> good!
			ModeTable->dwBBitMask = 0x7C00;
			ModeTable->dwGBitMask = 0x03E0;
			ModeTable->dwRBitMask = 0x001F;
			ModeTable->dwAlphaBitMask = 0;
#else
			ModeTable->dwRBitMask = 0x7C00;
			ModeTable->dwGBitMask = 0x03E0;
			ModeTable->dwBBitMask = 0x001F;
			ModeTable->dwAlphaBitMask = 0;

#endif

		  break;

	  case	24:
		  ModeTable->dwRBitMask = 0x00FF0000;
		  ModeTable->dwGBitMask = 0x0000FF00;
		  ModeTable->dwBBitMask = 0x000000FF;
		  ModeTable->dwAlphaBitMask = 0x00000000;
		  break;

	  case	32:
		  ModeTable->dwRBitMask = 0x00FF0000;
		  ModeTable->dwGBitMask = 0x0000FF00;
		  ModeTable->dwBBitMask = 0x000000FF;
		  ModeTable->dwAlphaBitMask = 0x00000000;
		  break;
  }

	if( !g_pVideoMemory )	// in case this is called more than once...
	{

		unsigned long videoMemoryStart;
		pLCDC62hw->GetVirtualVideoMemory( &videoMemoryStart, &g_nVideoMemorySize );
		DEBUGMSG( GPE_ZONE_INIT,(TEXT("GetVirtualVideoMemory returned addr=0x%08x size=%d\r\n"),
			videoMemoryStart, g_nVideoMemorySize));

		// Allocate some virtual memory space for video memory
		// this has already been done in ATI HAP so we don't need virtual alloc/copy
		g_pVideoMemory = (BYTE*)videoMemoryStart;

		DEBUGMSG( GPE_ZONE_INIT,(TEXT("gpVidMem=%08x\r\n"), g_pVideoMemory ));
	}

	// Populate the rest of the DDHALINFO structure:
    lpddhi->dwSize = sizeof(DDHALINFO);
    lpddhi->lpDDCallbacks = &cbDDCallbacks;
    lpddhi->lpDDSurfaceCallbacks = &cbDDSurfaceCallbacks;
    lpddhi->lpDDPaletteCallbacks = &cbDDPaletteCallbacks;
	lpddhi->lpDDExeBufCallbacks = &cbDDExeBufCallbacks;
	lpddhi->GetDriverInfo = HalGetDriverInfo;

    lpddhi->vmiData.fpPrimary = (unsigned long)(g_pVideoMemory) + g_pDDrawPrimarySurface->OffsetInVideoMemory();	// pointer to primary surface
    lpddhi->vmiData.dwFlags = 0;				// flags
    lpddhi->vmiData.dwDisplayWidth = SCREEN_WIDTH;
											// current display width
    lpddhi->vmiData.dwDisplayHeight = SCREEN_HEIGHT;
											// current display height
    lpddhi->vmiData.lDisplayPitch = g_pDDrawPrimarySurface->Stride(); //ScreenBpp * ScreenWidth / 8
	DEBUGMSG( GPE_ZONE_INIT,(TEXT("stride: %d\r\n"), lpddhi->vmiData.lDisplayPitch ));
											// current display pitch
    lpddhi->vmiData.ddpfDisplay.dwSize = sizeof(DDPIXELFORMAT);
											// ... = 8bit/pixel palettized
    lpddhi->vmiData.ddpfDisplay.dwFourCC = 0;	// (FOURCC code)

     if (ModeTable->wFlags & DDMODEINFO_PALETTIZED) {

       lpddhi->vmiData.ddpfDisplay.dwFlags = DDPF_RGB | DDPF_PALETTEINDEXED8;
     }
     else {

       lpddhi->vmiData.ddpfDisplay.dwFlags = DDPF_RGB;
     }

     lpddhi->vmiData.ddpfDisplay.dwRBitMask = ModeTable->dwRBitMask;
     lpddhi->vmiData.ddpfDisplay.dwGBitMask = ModeTable->dwGBitMask;
     lpddhi->vmiData.ddpfDisplay.dwBBitMask = ModeTable->dwBBitMask;
     lpddhi->vmiData.ddpfDisplay.dwRGBBitCount = ModeTable->dwBPP;

												// how many bits per pixel (BD_4,8,16,24,32)
    lpddhi->vmiData.dwOffscreenAlign = 2;		// byte alignment for offscreen surfaces
    lpddhi->vmiData.dwOverlayAlign = 0; 		// byte alignment for overlays
    lpddhi->vmiData.dwTextureAlign = 0; 		// byte alignment for textures
    lpddhi->vmiData.dwZBufferAlign = 0; 		// byte alignment for z buffers
    lpddhi->vmiData.dwAlphaAlign = 0;			// byte alignment for alpha
    lpddhi->vmiData.dwNumHeaps = 0;				// number of memory heaps in vmList
    lpddhi->vmiData.pvmList = (LPVIDMEM)NULL;	// array of heaps
	lpddhi->ddCaps.dwSize = sizeof(DDCAPS); 	// size of the DDDRIVERCAPS structure
	lpddhi->ddCaps.dwCaps = 					// driver specific capabilities
		DDCAPS_BLT |					// Display hardware is capable of blt operations
		DDCAPS_BLTQUEUE |				// Display hardware is capable of asynchronous blt operations
		DDCAPS_GDI |					// Display hardware is shared with GDI
		DDCAPS_COLORKEY |				// Supports color key
		DDCAPS_CANBLTSYSMEM |			// Display hardware is capable of bltting to or from system memory
		0;

    lpddhi->ddCaps.dwCaps2 =			// more driver specific capabilities
		DDCAPS2_NO2DDURING3DSCENE |		// Driver cannot interleave 2D & 3D operations
		0 ;

	lpddhi->ddCaps.dwCKeyCaps =			// color key capabilities of the surface
		0;
	lpddhi->ddCaps.dwFXCaps=			// driver specific stretching and effects capabilites
		0;
	lpddhi->ddCaps.dwPalCaps;			// palette capabilities
		DDPCAPS_8BIT |					// Simple 8-bit palette
		DDPCAPS_INITIALIZE |			// DDraw should initalize palette
										//   ..from lpDDColorArray
		DDPCAPS_PRIMARYSURFACE |		// Palette is attached to primary surface
		DDPCAPS_ALLOW256 |				// All 256 entries may be set
		0;
	lpddhi->ddCaps.dwSVCaps=0;			// Stereo vision capabilities (none)
	lpddhi->ddCaps.dwAlphaBltConstBitDepths = 0;// Alpha Blt's
	lpddhi->ddCaps.dwAlphaBltPixelBitDepths = 0;
	lpddhi->ddCaps.dwAlphaBltSurfaceBitDepths = 0;
    lpddhi->ddCaps.dwAlphaOverlayConstBitDepths=0;

	lpddhi->ddCaps.dwZBufferBitDepths=0;		// No z buffer
	lpddhi->ddCaps.dwVidMemTotal = g_nVideoMemorySize; // total amount of video memory
	lpddhi->ddCaps.dwVidMemFree = g_nVideoMemorySize;	// amount of free video memory

												// maximum number of visible overlays
	lpddhi->ddCaps.dwMaxVisibleOverlays = 0;
	lpddhi->ddCaps.dwCurrVisibleOverlays = 0;	// current number of visible overlays
	lpddhi->ddCaps.dwMinOverlayStretch=1000;
	lpddhi->ddCaps.dwMaxOverlayStretch=9999;
	lpddhi->ddCaps.dwNumFourCCCodes = 0;		// number of four cc codes
	lpddhi->ddCaps.dwAlignBoundarySrc = 4;		// source rectangle alignment
	lpddhi->ddCaps.dwAlignSizeSrc = 8;			// source rectangle byte size
	lpddhi->ddCaps.dwAlignStrideAlign = 8;		// stride alignment
	lpddhi->ddCaps.ddsCaps.dwCaps=				// DDSCAPS structure has all the general capabilities
		DDSCAPS_BACKBUFFER |					// Can create backbuffer surfaces
		DDSCAPS_COMPLEX |						// Can create complex surfaces
		DDSCAPS_FLIP |							// Can flip between surfaces
		DDSCAPS_FRONTBUFFER |					// Can create front-buffer surfaces
		DDSCAPS_OFFSCREENPLAIN |				// Can create off-screen bitmaps
		DDSCAPS_PALETTE |						// Has one palette ???
		DDSCAPS_PRIMARYSURFACE |				// Has a primary surface
		DDSCAPS_VIDEOMEMORY |					// Surfaces are in video memory
		DDSCAPS_VISIBLE |						// Changes are instant ???
		0;

	SETROPBIT(lpddhi->ddCaps.dwRops,SRCCOPY);	// Set bits for ROPS supported
	SETROPBIT(lpddhi->ddCaps.dwRops,PATCOPY);
	SETROPBIT(lpddhi->ddCaps.dwRops,BLACKNESS);
	SETROPBIT(lpddhi->ddCaps.dwRops,WHITENESS);
    lpddhi->dwMonitorFrequency = ModeTable->wRefreshRate;       // monitor frequency in current mode
    lpddhi->dwModeIndex = 0;					// current mode: index into array
    lpddhi->lpdwFourCC = 0;						// fourcc codes supported
    lpddhi->dwNumModes = 1;
												// number of modes supported
    lpddhi->lpModeInfo = ModeTable;                              // mode information

    lpddhi->dwFlags =
					DDHALINFO_MODEXILLEGAL |	// create flags
					DDHALINFO_GETDRIVERINFOSET |
					0;
    lpddhi->lpPDevice = (LPVOID)0;				// physical device ptr
    lpddhi->hInstance = (DWORD)0;				// instance handle of driver

}

#endif DDRAW_ENABLE

//! @}

//! @}

////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/LCDC/halcaps.cpp $
////////////////////////////////////////////////////////////////////////////////
//
//! @}