//-----------------------------------------------------------------------------
//! \addtogroup	SPI
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x_spi_ioctl.h
//!
//! \brief		Custom SPI IOCTLs declaration file
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/IOCTL/AT91SAM926x_spi_ioctl.h $
//!   $Author: pblanchard $
//!   $Revision: 1021 $
//!   $Date: 2007-06-20 08:50:46 -0700 (Wed, 20 Jun 2007) $
//! \endif
//!
//! IOControl used by application for interaction and transaction with the SPI driver
//-----------------------------------------------------------------------------


#ifndef __AT91SAM926X_SPI_IOCTL_H__
#define __AT91SAM926X_SPI_IOCTL_H__


//! \struct T_SPI_TRANSACTION_PARAM
//! \brief this strcuture is used to pass parameters to SPI_IOControl
typedef struct {
	PVOID pRxBuffer;	/*! < \brief location of the destination data */
	PVOID pTxBuffer;	/*! < \brief location of the source data */
	DWORD dwSize;		/*! < \brief size of the buffer*/	
} T_SPI_TRANSACTION_ELEMENT_PARAM;


// Functions
#define SPI_TRANSACTION_CMD			(2048 + 1)


/*! \def IOCTL_SPI_TRANSACTION	
	\brief Command code for performing a SPI transaction
*/

#define IOCTL_SPI_TRANSACTION	CTL_CODE(FILE_DEVICE_SERIAL_PORT, SPI_TRANSACTION_CMD, METHOD_BUFFERED, FILE_ANY_ACCESS)



#endif // #ifndef __AT91SAM926X_SPI_IOCTL_H__


// End of Doxygen group SPI
//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/IOCTL/AT91SAM926x_spi_ioctl.h $
//-----------------------------------------------------------------------------
//
