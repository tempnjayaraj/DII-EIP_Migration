//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91RM9200_interface.h
//!
//! \brief		AT91RM9200 API declaration
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/INC/AT91RM9200_interface.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//!
//-----------------------------------------------------------------------------

#include "at91rm9200.h"

///////////////////////////////////////////// PLL ////////////////////////////////////////////////////////


//-----------------------------------------------------------------------------
//! \fn		DWORD AT91RM9200_GetMasterClock(BOOL bUseShadowedValue)
//!
//! \brief		This function is called by the kernel to retreive the value of the Master clock in Hz
//!
//!	\param		TRUE to use shadowed value
//!
//! \return		value of Master clock in Hz
//!
//! 
//-----------------------------------------------------------------------------
DWORD AT91RM9200_GetMasterClock(BOOL bUseShadowedValue);

//-----------------------------------------------------------------------------
//! \fn		DWORD AT91RM9200_GetPLLAClock(BOOL bUseShadowedValue)
//!
//! \brief		This function is called by the kernel to retreive the value of the PLLA clock in Hz
//!
//!	\param		TRUE to use shadowed value
//!
//! \return		value of PLLA clock in Hz
//!
//! 
//-----------------------------------------------------------------------------
DWORD AT91RM9200_GetPLLAClock(BOOL bUseShadowedValue);

//-----------------------------------------------------------------------------
//! \fn		DWORD AT91RM9200_GetPLLBClock(BOOL bUseShadowedValue)
//!
//! \brief		This function is called by the kernel to retreive the value of the PLLB clock in Hz
//!
//!	\param		TRUE to use shadowed value
//!
//! \return		value of PLLB clock in Hz
//!
//! 
//-----------------------------------------------------------------------------
DWORD AT91RM9200_GetPLLBClock(BOOL bUseShadowedValue);

//-----------------------------------------------------------------------------
//! \fn		DWORD AT91RM9200_GetProcessorClock(BOOL bUseShadowedValue)
//!
//! \brief		This function is called by the kernel to retreive the value of the Processor clock in Hz
//!
//!	\param		TRUE to use shadowed value
//!
//! \return		value of Processor clock in Hz
//!
//! 
//-----------------------------------------------------------------------------
DWORD AT91RM9200_GetProcessorClock(BOOL bUseShadowedValue);

//-----------------------------------------------------------------------------
//! \fn		void AT91RM9200_TurnProcessorClockOff()
//!
//! \brief		This function is called by the kernel to stop the processor clock and thus enter the idle/suspend mode.
//!
//-----------------------------------------------------------------------------
void AT91RM9200_TurnProcessorClockOff();



//-----------------------------------------------------------------------------
//! \fn		DWORD AT91RM9200_SetPLLBFreq(AT91PS_CKGR pCKGR,AT91PS_PMC pPMC,DWORD dwFreqInMHz,DWORD dwUSBDivider)
//!
//! \brief		This function is called by the kernel to set the PLLB frequency
//!
//-----------------------------------------------------------------------------
DWORD AT91RM9200_SetPLLBFreq(	AT91PS_CKGR pCKGR	, 
								AT91PS_PMC pPMC		, 
								DWORD dwFreqInMHz	, 
								DWORD dwUSBDivider	);


BOOL AT91RM9200_SetProcessorAndMasterClocks(	AT91PS_PMC pPMC	,
												AT91PS_CKGR pCKGR,
												DWORD dwProcessorClockInMHz,
												DWORD dwBusClockRatio		);
												
												///////////////////////////////////////////// Serial //////////////////////////////////////////////////////
//------------------------------------------------------------------------------
//
//  Variable:     g_pDBGU
//
//  This variable is used by the AT91RM9200 API to know the base address of the DBGU controller.
// It must be initialized before the initialization code is used. otherwise the default value for the processor is used instead
//
extern AT91PS_DBGU g_pDBGU;
//------------------------------------------------------------------------------
//
//  Function:     AT91RM9200_SetDebugSerialInterface
//
//  This function is called to set the value of g_pDBGU in a proper way
//

void AT91RM9200_SetDebugSerialInterface(AT91PS_DBGU pDBGU);

//! @}
