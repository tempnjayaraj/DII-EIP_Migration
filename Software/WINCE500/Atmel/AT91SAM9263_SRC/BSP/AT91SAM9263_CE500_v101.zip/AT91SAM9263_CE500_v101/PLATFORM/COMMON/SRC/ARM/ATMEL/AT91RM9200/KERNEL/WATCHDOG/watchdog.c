//-----------------------------------------------------------------------------
//! \addtogroup   OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				watchdog.c
//!
//! \brief				support for the AT91RM9200's watchdog
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/KERNEL/WATCHDOG/watchdog.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//! Watchdog support can be disbled by adding OAL_NO_WATCHDOG in the environment variables
//! 
//-----------------------------------------------------------------------------

#include <windows.h>
#include <oal.h>
#include "at91rm9200.h"

#ifndef OAL_NO_WATCHDOG

/// Frequency of the watchdog counter as defined in the datasheet of the processor
#define WATCHDOG_COUNTER_FREQUENCY (SLOW_CLOCK_FREQUENCY/128)

//
// kernel exports
//
extern void (* pfnOEMRefreshWatchDog) (void);   ///< function pointer used by the kernel to call the function to refresh watchdog
extern DWORD   dwOEMWatchDogPeriod;             ///< watchdog period used by the kernel
extern DWORD   dwNKWatchDogThreadPriority;      ///<  watchdog thread priority used bythe kernel, default is 100, set by kernel. OEM can adjust as desired

/// virtual base address of the watchdog controller
static AT91PS_ST g_pSystemTimer;


//-----------------------------------------------------------------------------
//! \fn void AT91RM9200_RefreshWatchDog()
//!
//!	\brief This function is used to refresh the watchdog
//! 
//-----------------------------------------------------------------------------
void AT91RM9200_RefreshWatchDog()
{
   //Restart the Watchdog
	DEBUGMSG(1,(TEXT("AT91RM9200_RefreshWatchDog!\r\n")));
	g_pSystemTimer->ST_CR = (0xA5 << 24) | AT91C_ST_WDRST;	
}


//-----------------------------------------------------------------------------
//! \fn void AT91RM9200_RefreshWatchDog()
//!
//!	\brief This function is used to refresh the watchdog
//!
//!	\param flags Flags for watchdog configuration
//!	\param dwWatchdogPeriod Watchdog period asked
//!
//!	\return Watchdog period configured after timer restriction apply
//! 
//-----------------------------------------------------------------------------
DWORD AT91RM9200_SetWatchDogConfiguration(DWORD flags, DWORD dwWatchdogPeriod)
{
	DWORD dwTemp;

	

	//dwWatchdogPeriod is in ms, convert it in 'watchdog ticks' and clip it
	dwTemp = (dwWatchdogPeriod * WATCHDOG_COUNTER_FREQUENCY) / 1000;		

	RETAILMSG(1,(TEXT("AT91RM9200_SetWatchDogConfiguration %d => %d\r\n"),dwWatchdogPeriod,dwTemp));


	if (dwTemp > 0xFFF)
	{
		dwTemp = 0xFFF;
		RETAILMSG(1,(TEXT("Clipping The Watchdog period to the maximum : 0xFFF (%d ms)\r\n"),(dwTemp * 1000) / WATCHDOG_COUNTER_FREQUENCY));
	}	
	dwWatchdogPeriod   = (dwTemp * 1000) / WATCHDOG_COUNTER_FREQUENCY;
	
	
	//Change the period of the watchdog (and also its delta value) but keep the other settings ...
	g_pSystemTimer->ST_WDMR = flags | ((dwTemp<<16) | (dwTemp<<0));

	return dwWatchdogPeriod;
}

//-----------------------------------------------------------------------------
//! \fn void OEMRefreshWatchDog(void)
//!
//!	\brief This function is the OAL interface for refreshing the watchdog
//! 
//-----------------------------------------------------------------------------
void OEMRefreshWatchDog(void)
{	
	AT91RM9200_RefreshWatchDog();
}
#endif //#OAL_NO_WATCHDOG

//------------------------------------------------------------------------------
/// 
//-----------------------------------------------------------------------------
//! \fn DWORD OEMInitWatchDogTimer (DWORD dwWatchdogPeriod)
//!
//!	\brief This function initializes the hardware and so the software, so that the Kernel is provided with a Hardware Watchdog.
//!
//!	\param	dwWatchdogPeriod	Initial period of watchdog asked
//!
//!	\retrun	Watchdog period configured after timer restriction apply
//! 
//-----------------------------------------------------------------------------
DWORD OEMInitWatchDogTimer (DWORD dwWatchdogPeriod)
{
#ifndef OAL_NO_WATCHDOG
	DWORD dwResult;
#endif

	
	//At this point the watchdog is disabled ....
#ifdef OAL_NO_WATCHDOG	
	RETAILMSG(OAL_FUNC, (L"+OEMInitWatchDogTimer (DISABLED)\r\n"));
	{
		AT91PS_ST pSystemTimer = OALPAtoVA ((DWORD)AT91C_ST_CR, FALSE);		
		pSystemTimer->ST_WDMR = 0;
	}
	return 0;
#else    
	RETAILMSG(1, (L"+OEMInitWatchDogTimer\r\n"));
	g_pSystemTimer = OALPAtoVA ((DWORD)AT91C_ST_CR, FALSE);
	RETAILMSG(1,(TEXT("AT91RM9200_DispWatchDog %x!\r\n"),g_pSystemTimer->ST_WDMR));

	//Set the watcdog period 
	dwResult = AT91RM9200_SetWatchDogConfiguration(AT91C_ST_RSTEN, dwWatchdogPeriod);

    pfnOEMRefreshWatchDog = OEMRefreshWatchDog;
    
	
    RETAILMSG(1, (L"-OEMInitWatchDogTimer (result = %d)\r\n",dwResult));

	return dwResult;
#endif

}

//! @}

