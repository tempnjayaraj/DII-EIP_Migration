//-----------------------------------------------------------------------------
//! \addtogroup   KITL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				AT91RM9200_EMAC.h
//!
//! \brief				
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/INC/AT91RM9200_EMAC.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//!
//-----------------------------------------------------------------------------
#ifndef __AT91RM9200_EMAC_H__
#define __AT91RM9200_EMAC_H__
#include "AT91RM9200.h"


#define MAX_RX_BUFFS	10
#define ETH_ZLEN 60
#define AT91C_EMAC_RXBUFF_SZ	0x600  // 1518 rounded up
#define AT91C_EMAC_TXBUFF_SZ	0x600  // 1518 rounded up


// Interface to drive the physical layer
typedef struct _AT91S_PhyOps {
	unsigned char (*Init)(AT91S_EMAC* pmac);
	unsigned int  (*IsPhyConnected)(AT91S_EMAC* pmac);
	unsigned char (*GetLinkSpeed)(AT91S_EMAC* pmac);
	unsigned char (*AutoNegotiate)(AT91S_EMAC* pmac, int*);
} AT91S_PhyOps, * AT91PS_PhyOps;

extern AT91PS_PhyOps AT91_GetPhyInterface(void);
extern DWORD g_dlist_phys;
extern DWORD g_TransmitBuffer_Phys;



#endif // __AT91RM9200_EMAC_H__