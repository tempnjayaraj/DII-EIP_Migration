//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9263/DRIVERS/LCDC/LCDC2DGE.h
//!
//! \brief		Header for LCDC2DGE class
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/DRIVERS/LCDC/lcdc2dge.h $
//!   $Author: pblanchard $
//!   $Revision: 1021 $
//!   $Date: 2007-06-20 08:50:46 -0700 (Wed, 20 Jun 2007) $
//! \endif
//!
//-----------------------------------------------------------------------------
//! \addtogroup	LCDC
//! @{
//
//! \addtogroup LCDC63
//! @{
#ifndef __LCDC2DGE__
#define __LCDC2DGE__


#include "LCDC\precomp.h"
#include "at91sam9263.h"

//! \addtogroup	2DGE
//! @{


// Cursor
#define CURSOR_MASK_POSITION_IN_FRAME			384  //!< position (line number in pixels) of gCursorMask in the frame buffer (hidden area)
#define CURSOR_DATA_POSITION_IN_FRAME			416  //!< position (line number in pixels) of gCursorData in the frame buffer (hidden area)
#define CURSOR_BACKING_STORE_POSITION_IN_FRAME	448  //!< position (line number in pixels) of m_CursorBackingStore in the frame buffer (hidden area)

// Operation code
#define NOP				0x00
#define LINE_DRAWING	0xD0
#define BLOCK_TRANSFERT	0xB0
#define POLYGON_FILL	0xF0

// Options for line draw
#define PATTERN_2D		0x00
#define PATTERN_1D		0x01
#define NO_UPDATE_XY	0x00
#define UPDATE_XY		0x02
#define RELATIVE		0x00
#define ABSOLUTE		0x04

// Options for block transfert
#define NO_UPDATE_Y		0x00
#define UPDATE_Y		0x01
#define NO_UPDATE_X		0x00
#define UPDATE_X		0x02
#define RELATIVE		0x00
#define ABSOLUTE		0x04

// Logical operator
#define LOP_WRITE		0x00
#define LOP_OR			0x01
#define LOP_AND			0x02
#define LOP_XOR			0x03
#define LOP_NOT			0x04
#define LOP_NOR			0x05
#define LOP_NAND		0x06
#define LOP_XNOR		0x07

// Clip ON/OFF
#define CLIPPING_ON		0x01
#define CLIPPING_OFF	0x00


#define FD_POLYGON		0x1 // polygon fill done

#define AT91C_BASE_2DGE	0xFFFC8000

#define HW_FIFO_TIMEOUT	100

typedef struct _AT91S_2DGE
{
	// Inversion of X and Y registers for BTS, SB and TE              |Offset|
	volatile DWORD BTSYR;			// Block Transfer Size Y Register	 0
	volatile DWORD BTSXR;			// Block Transfer Size X Register	 4
	volatile DWORD SBYR;			// Source/Begin Y Register 			 8
	volatile DWORD SBXR;			// Source/Begin X Register 			 C
	volatile DWORD TEYR;			// Target/End Y Register 			10
	volatile DWORD TEXR;			// Target/End X Register 			14
	volatile DWORD LWR;				// Line Thickness Register 			18
	volatile DWORD LPR;				// Line Pattern Register 			1C
	volatile DWORD CSR;				// Colour Select Register 			20
	volatile DWORD LOR;				// Logic Operation Register 		
	volatile DWORD GOR;				// Graphics Operation Register 		
	volatile DWORD EBXR;			// Extended Begin X Register --- May it have to be inverted with EBYR
	volatile DWORD EBYR;			// Extended Begin Y Register 		 30 OK
	volatile DWORD EEXR;			// Extended End X Register 			 34
	volatile DWORD EEYR;			// Extended End Y Register 			 38 OK
	volatile DWORD ECSR;			// Extended Colour Select Register 	 3C OK
	volatile DWORD CCR;				// Clip Control Register 			 40 NOK
	volatile DWORD CYMINR;			// Clip Rectangle Y Minimum Register 44	NOK
	volatile DWORD CYMAXR;			// Clip Rectangle Y Maximum Register
	volatile DWORD CXMINR;			// Clip Rectangle X Minimum Register	
	volatile DWORD CXMAXR;			// Clip Rectangle X Maximum Register 50	
	volatile DWORD GSR;				// Graphics Status Register 		
	volatile DWORD VSR;				// VRAM Size Register 		 	
	volatile DWORD reserved1;		//  	
	volatile DWORD FCR;				// Fill Control Register 		 	
	volatile DWORD GIR;				// Graphics Interrupt Register 	 	
	volatile DWORD GIMR;			// Graphics Interrupt Mask Register	
	volatile DWORD reserved2;		// 
	volatile DWORD BPPR;			// Bits Per Pixel Register
	volatile DWORD reserved3;		//  	
	volatile DWORD CQCR;			// Command Queue Count Register 	
	volatile DWORD CQSR;			// Command Queue Status Register 	
	volatile DWORD CQR;				// Command Queue Register 		 
	volatile DWORD reserved4[3];	//  
	volatile DWORD VXR[16];			// Vertex X Register 		 		
	volatile DWORD reserved5[20];	// 
	volatile DWORD VYR[16];			// Vertex Y Register 		
	volatile DWORD reserved6[40];	//        
	volatile DWORD VOR;				// VRAM Offset Register 			
	volatile DWORD DFR;				// Data Format Register 			
} AT91S_2DGE,*AT91PS_2DGE;


#define QUEUE_EMPTY				(1<<0)
#define LITTLE_ENDIAN_2DGE_FMT	(1<<31)

// Struct for HW cmd, we support only Blt & Line, no painting is supported.
// Polygons drawing doesn't work currently

// A bltcmd pack all the data the 2D chip need to make a good blt :)
// This is all the register settings witch must be pushed on the HW FIFO
typedef struct
{
	WORD RegAddr1;
	WORD NbWord1;
	WORD SzY;		// in pixel units
	WORD SzX;
	WORD SrcY;
	WORD SrcX;
	WORD DstY;
	WORD DstX;

	WORD RegAddr2;
	WORD NbWord2;
	WORD LogOp;
	WORD Cmd;
} T_BLT_CMD; // 12 half-words

// A linecmd pack all the data we need to make a good line
// Like upper, this is all the register settings to push to the HW FIFO
typedef struct
{
	WORD RegAddr1;
	WORD NbWord1;
	WORD StartY;	// in pixel units
	WORD StartX;
	WORD EndY;
	WORD EndX;
	WORD Thick;
	WORD Pattern;
	WORD Color;
	WORD LogOp;
	WORD Cmd;
} T_LINE_CMD; // 11 half-words

typedef struct
{
	WORD RegAddr1;
	WORD NbWord1;
	WORD MinY;
	WORD MaxY;
	WORD MinX;	// Signed values
	WORD MaxX;
} T_CLIP_CMD; // 6 half-words

typedef struct
{
	WORD RegAddr1;
	WORD NbWord1;
	WORD ClipControl;
} T_CLIP_ACTIVATE; // 3 half-words


#define HW_FIFO_MAX_SIZE	64  // half-word (16bits)

typedef enum {
	BPP_1 = 0,
	BPP_2 = 1,
	BPP_4 = 2,
	BPP_8 = 3,
	BPP_16 = 4,
	BPP_24 = 5,
	BPP_32 = 6
} T_BPP_2DGE;

#define BLT_OP  (1<<1)
#define LINE_OP (1<<0)

#define DEFAULT_OPERATION_TIMEOUT	50



// FIFO for LCDC improvement
class LCDC2DGE
{

public:
	LCDC2DGE		(AT91PS_LCDC pLCDC, BOOL bUseInterrupt = TRUE);	// Constructor
	virtual ~LCDC2DGE();

	virtual void Configure(T_BPP_2DGE bpp,DWORD dwVideoMemWidthInPixels,DWORD dwVideoMemBusWidth, DWORD dwVisibleSurfaceOffset);

	BOOL LineDraw( WORD startx, WORD starty, WORD endx, WORD endy);
	BOOL ClipSet( WORD minclipx, WORD minclipy, WORD maxclipx, WORD maxclipy);
	BOOL ClipActivated( BOOL On);
	BOOL BlockTransfer( WORD startx, WORD starty, WORD endx, WORD endy, WORD sizex, WORD sizey, WORD LogicalOperation );

	BOOL Push(WORD* pData, DWORD NbWord, BOOL bUseInterrupt=TRUE);	// Push data to software fifo

	BOOL WaitForHWFifoEmpty(BOOL bUseInterrupt=TRUE);				// Wait for fifo empty
	BOOL WaitForOperationComplete(DWORD dwFlags = (BLT_OP | LINE_OP), DWORD dwTimeout = DEFAULT_OPERATION_TIMEOUT);										// Wait for all HW rendering to be done
	
private:
	DWORD       m_dwSysintr;
	AT91PS_LCDC m_pLCDC;
	AT91PS_2DGE m_p2DGE;
	AT91PS_PMC  m_pPMC;
	CRITICAL_SECTION	m_CriticalSection;	// Critical section for concurrent access
	DWORD m_EstimatedFifoFreeSpace;
	HANDLE m_hHWFifoEmptyEvent;
};

#endif //__LCDC2DGE__

// Doxygen End of group Core
//! @}
// Doxygen End of group LCDC63
//! @} 
// Doxygen End of group LCDC
//! @}
// Doxygen End of group Driver
//! @}


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/DRIVERS/LCDC/lcdc2dge.h $
////////////////////////////////////////////////////////////////////////////////
//
