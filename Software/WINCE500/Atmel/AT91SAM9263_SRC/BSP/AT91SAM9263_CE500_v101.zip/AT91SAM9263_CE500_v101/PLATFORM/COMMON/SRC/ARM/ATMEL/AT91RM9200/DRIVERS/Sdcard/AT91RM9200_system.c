//-----------------------------------------------------------------------------
//! \addtogroup   SDMMC
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				AT91RM9200_system.c
//!
//! \brief				Windows CE RAM disk driver
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/DRIVERS/Sdcard/AT91RM9200_system.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//!
//!	Based on system.c for Windows CE RAM disk driver from Microsoft
//!
//-----------------------------------------------------------------------------

#include <windows.h>
#include <diskio.h>
#include <storemgr.h>


#include "AT91RM9200_sdmmc.h"


#ifdef DEBUG
//
// These defines must match the ZONE_* defines
//
#define DBG_ERROR      1
#define DBG_WARNING    2
#define DBG_FUNCTION   4
#define DBG_INIT       8
#define DGB_PCMCIA	   16
#define DBG_IO         32

DBGPARAM dpCurSettings = {
    TEXT("RAM Disk"), {
    TEXT("Errors"),TEXT("Warnings"),TEXT("Functions"),TEXT("Initialization"),
    TEXT("Undefined"),TEXT("Disk I/O"),TEXT("Misc"),TEXT("Undefined"),
    TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined"),
    TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined") },
    0xFFFF
};
#endif  // DEBUG

//globals
DISK Disk;
AT91S_MciDeviceDesc DeviceDesc;
AT91S_MciDeviceFeatures DeviceFeatures;
AT91S_MciDevice MciDevice;


//------------------------------------------------------------------------------
//
// sdmmc.dll entry
//
//------------------------------------------------------------------------------
BOOL WINAPI DllMain(HINSTANCE DllInstance, DWORD Reason, LPVOID Reserved)
{
    switch(Reason) 
    {
        case DLL_PROCESS_ATTACH:
            DEBUGMSG(ZONE_INIT, (TEXT("SDMMC: DLL_PROCESS_ATTACH\r\n")));
            DEBUGREGISTER(DllInstance);
	    DisableThreadLibraryCalls((HMODULE) DllInstance);
            break;
    
        case DLL_PROCESS_DETACH:
            DEBUGMSG(ZONE_INIT, (TEXT("SDMMC: DLL_PROCESS_DETACH\r\n")));
            break;
    }
    return TRUE;
}   // DllMain


//------------------------------------------------------------------------------
//
// CreateDiskObject - create a DISK structure, init some fields
//
//------------------------------------------------------------------------------
PDISK CreateDiskObject(VOID)
{
    PDISK 						pDisk;
    AT91PS_MciDeviceDesc 		pDeviceDesc;	
	AT91PS_MciDeviceFeatures	pDeviceFeatures;
    AT91PS_MciDevice			pMciDevice;
    
    
    DEBUGMSG(ZONE_FUNCTION, (TEXT("+CreateDiskObject\r\n")));
    

    pDisk = &Disk;
	pDeviceDesc = &DeviceDesc;
	pDeviceFeatures = &DeviceFeatures;
	pMciDevice = &MciDevice;
	
    if ((pDisk != NULL)&&(pDeviceDesc != NULL)&&(pDeviceFeatures != NULL)&&(pMciDevice != NULL))
    {
        pDisk->d_OpenCount = 0;
        pDisk->d_ActivePath = NULL;
        InitializeCriticalSection(&(pDisk->d_DiskCardCrit));
        pDisk->d_DiskCardState = STATE_INITING;
        pDisk->dwMagicNumber = SDMAGICNUMBER;
        pDisk->MciDevice = pMciDevice;
         
        pDisk->MciDevice->pMCI_DeviceDesc = pDeviceDesc;
        pDisk->MciDevice->pMCI_DeviceFeatures = pDeviceFeatures;
         
		pDisk->MciDevice->pMCI_DeviceFeatures->Relative_Card_Address 		= 0;
		pDisk->MciDevice->pMCI_DeviceFeatures->Card_Inserted 				= AT91C_CARD_REMOVED;
		pDisk->MciDevice->pMCI_DeviceFeatures->Max_Read_DataBlock_Length	= 0;
		pDisk->MciDevice->pMCI_DeviceFeatures->Max_Write_DataBlock_Length 	= 0;
		pDisk->MciDevice->pMCI_DeviceFeatures->Read_Partial 				= 0;
		pDisk->MciDevice->pMCI_DeviceFeatures->Write_Partial 				= 0;
		pDisk->MciDevice->pMCI_DeviceFeatures->Erase_Block_Enable 			= 0;
		pDisk->MciDevice->pMCI_DeviceFeatures->Sector_Size 					= 0;
		pDisk->MciDevice->pMCI_DeviceFeatures->Memory_Capacity 				= 0;
		
		pDisk->MciDevice->pMCI_DeviceDesc->state							= AT91C_MCI_IDLE;
		pDisk->MciDevice->pMCI_DeviceDesc->SDCard_bus_width					= 0;       
        pDisk->dwSysIntr													= 0;
		pDisk->hInterruptEvent												= NULL;

    }
    
    DEBUGMSG(ZONE_FUNCTION, (TEXT("-CreateDiskObject\r\n")));
    return pDisk;
}   // CreateDiskObject


//------------------------------------------------------------------------------
//
// IsValidDisk - dummy function to know if the structure is v alid or not (according to a 'magic number').
//
// Return TRUE
//
//------------------------------------------------------------------------------
BOOL IsValidDisk(PDISK pDisk)
{
   if (pDisk)
   {
   		if (pDisk->dwMagicNumber == SDMAGICNUMBER)
   		{
   			return TRUE;
   		}
   	}
   	return FALSE;
  	
}   // IsValidDisk


//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
DWORD GetDiskStateError(DWORD DiskState)
{
    switch (DiskState)
    {
    case STATE_DEAD:
        return DISK_DEAD_ERROR;
        
    case STATE_REMOVED:
        return DISK_REMOVED_ERROR;
        
    }
    return ERROR_GEN_FAILURE;
}


//------------------------------------------------------------------------------
//
// Returns context data for this Init instance
//
// Arguments:
//      dwContext - registry path for this device's active key
//
//------------------------------------------------------------------------------
DWORD DSK_Init(DWORD dwContext)
{
    PDISK pDisk;
    LPWSTR ActivePath = (LPWSTR) dwContext;

    DEBUGMSG(ZONE_INIT, (TEXT("+SDMMC: DSK_Init entered\n\r")));
	
    pDisk = CreateDiskObject();
    if (pDisk == NULL) 
    {
        RETAILMSG(1,(TEXT("SDMMC: LocalAlloc(PDISK) failed %d\r\n"), GetLastError()));
        return 0;
    }

    if (ActivePath) 
    {
        DEBUGMSG(ZONE_INIT, (TEXT("SDMMC: ActiveKey = %s\r\n"), ActivePath));
        if (pDisk->d_ActivePath = LocalAlloc(LPTR, wcslen(ActivePath)*sizeof(WCHAR)+sizeof(WCHAR))) 
        {
            wcscpy(pDisk->d_ActivePath, ActivePath);
        }
        DEBUGMSG(ZONE_INIT, (TEXT("SDMMC : ActiveKey (copy) = %s (@ 0x%08X)\r\n"), pDisk->d_ActivePath, pDisk->d_ActivePath));
    }
    
	if(!InitDisk(pDisk))
	{
		DEBUGMSG(ZONE_INIT, (TEXT("-SDMMC: DSK_Init (failure)\r\n")));
		DeinitDisk(pDisk);
		return 0;
	}

    DEBUGMSG(ZONE_INIT, (TEXT("SDMMC: sectors = %d\r\n"), pDisk->d_DiskInfo.di_total_sectors));
    
    if (pDisk->d_DiskCardState == STATE_INITING) 
    {
        DEBUGMSG(ZONE_INIT,(TEXT("-SDMMC: DSK_Init returning 0x%x\r\n"), pDisk));
        return (DWORD) pDisk;
    }

    DEBUGMSG(ZONE_INIT, (TEXT("-SDMMC: DSK_Init (failure)\r\n")));
    DeinitDisk(pDisk);
    return 0;
}


//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
BOOL DSK_Close(DWORD Handle)
{
    PDISK pDisk = (PDISK)Handle;
    BOOL bClose = FALSE;

    DEBUGMSG(ZONE_IO, (TEXT("SDMMC: DSK_Close entered\r\n")));

    if (!IsValidDisk(pDisk)) 
    {
        return FALSE;
    }

    if (pDisk->d_DiskCardState == STATE_OPENED) 
    {
        EnterCriticalSection(&(pDisk->d_DiskCardCrit));
        pDisk->d_OpenCount--;
        if (pDisk->d_OpenCount == 0) 
        {
            pDisk->d_DiskCardState = STATE_CLOSED;
            bClose = TRUE;
        }
        LeaveCriticalSection(&(pDisk->d_DiskCardCrit));
    }
    DEBUGMSG(ZONE_IO, (TEXT("SDMMC: DSK_Close done\r\n")));
    return TRUE;
}   // DSK_Close


//------------------------------------------------------------------------------
//
// Device deinit - devices are expected to close down.
// The device manager does not check the return code.
//
//------------------------------------------------------------------------------
BOOL DSK_Deinit(DWORD dwContext)     // future: pointer to the per disk structure
{
    DEBUGMSG(ZONE_INIT, (TEXT("SDMMC: DSK_Deinit entered\r\n")));

    DSK_Close(dwContext);
    DeinitDisk((PDISK)dwContext);
    DEBUGMSG(ZONE_INIT, (TEXT("SDMMC: DSK_Deinit done\r\n")));
    return TRUE;
}   // DSK_Deinit


//------------------------------------------------------------------------------
//
// Returns handle value for the open instance.
//
//------------------------------------------------------------------------------
DWORD DSK_Open(DWORD dwData, DWORD dwAccess, DWORD dwShareMode)
{
    PDISK pDisk = (PDISK)dwData;
    DWORD ret = 0;

    DEBUGMSG(ZONE_IO, (TEXT("+SDMMC: DSK_Open(0x%x)\r\n"),dwData));

    if (IsValidDisk(pDisk) == FALSE) 
    {
        DEBUGMSG(ZONE_IO, (TEXT("SDMMC: DSK_Open - Passed invalid disk handle\r\n")));
        return ret;
    }

    if (pDisk->d_DiskCardState == STATE_INITING) 
    {
        if (pDisk->d_DiskInfo.di_total_sectors == 0) 
		{
            pDisk->d_DiskCardState = STATE_DEAD;
        }
        else
		{
			pDisk->d_DiskCardState = STATE_CLOSED;
        }
    }

    if ((pDisk->d_DiskCardState != STATE_OPENED) &&
        (pDisk->d_DiskCardState != STATE_CLOSED)) {
        SetLastError(GetDiskStateError(pDisk->d_DiskCardState));
        return 0;
    }

    EnterCriticalSection(&(pDisk->d_DiskCardCrit));
    if (pDisk->d_DiskCardState == STATE_CLOSED) 
    {
        pDisk->d_DiskCardState = STATE_OPENED;
    }
    
    ret = (DWORD)pDisk;
    pDisk->d_OpenCount++;
    LeaveCriticalSection(&(pDisk->d_DiskCardCrit));
    DEBUGMSG(ZONE_IO, (TEXT("-SDMMC: DSK_Open(0x%x) returning %d\r\n"),dwData, ret));
    return ret;
}   // DSK_Open


//------------------------------------------------------------------------------
//
// I/O Control function - responds to info, read and write control codes.
// The read and write take a scatter/gather list in pInBuf
//
//------------------------------------------------------------------------------
BOOL
DSK_IOControl(
    DWORD Handle,
    DWORD dwIoControlCode,
    PBYTE pInBuf,
    DWORD nInBufSize,
    PBYTE pOutBuf,
    DWORD nOutBufSize,
    PDWORD pBytesReturned
    )
{
    PSG_REQ pSG;
    PDISK pDisk = (PDISK) Handle;

    DEBUGMSG(ZONE_FUNCTION, (TEXT("+DSK_IOControl (%d) \r\n"), dwIoControlCode));
    
    if (IsValidDisk(pDisk) == FALSE) 
    {
        SetLastError(ERROR_INVALID_HANDLE);
        DEBUGMSG(ZONE_FUNCTION, (TEXT("-DSK_IOControl (invalid disk) \r\n")));
        return FALSE;
    }

    if (pDisk->d_DiskCardState != STATE_OPENED) 
    {
        SetLastError(GetDiskStateError(pDisk->d_DiskCardState));
        DEBUGMSG(ZONE_FUNCTION, (TEXT("-DSK_IOControl (disk card state) \r\n")));
        return FALSE;
    }

    //
    // Check parameters
    //
    switch (dwIoControlCode) 
    {
	case DISK_IOCTL_READ:
	case DISK_IOCTL_WRITE:
	case DISK_IOCTL_GETINFO:
	case DISK_IOCTL_SETINFO:
	case DISK_IOCTL_INITIALIZED:
       	if (pInBuf == NULL) 
		{
			SetLastError(ERROR_INVALID_PARAMETER);
			return FALSE;
		}
        break;

    case DISK_IOCTL_GETNAME:
		if (pOutBuf == NULL) 
		{
			SetLastError(ERROR_INVALID_PARAMETER);
			return FALSE;
		}
		break;

    case IOCTL_DISK_DEVICE_INFO:
		if(!pInBuf || nInBufSize != sizeof(STORAGEDEVICEINFO)) 
		{
			SetLastError(ERROR_INVALID_PARAMETER);   
			return FALSE;
		}
		break;
	
	case DISK_IOCTL_FORMAT_MEDIA:
		SetLastError(ERROR_SUCCESS);
		return TRUE;
	
	default:
		SetLastError(ERROR_INVALID_PARAMETER);
		return FALSE;
	}

    //
    // Execute dwIoControlCode
    //
    switch (dwIoControlCode) 
    {
	case DISK_IOCTL_FORMAT_MEDIA:
        DEBUGMSG(ZONE_FUNCTION, (TEXT("-DSK_IOControl (format) \r\n")));
		return FormatDisk(pDisk, (PDISK_INFO) pInBuf);

    case DISK_IOCTL_READ:
    case DISK_IOCTL_WRITE:
        pSG = (PSG_REQ) pInBuf;
/*
		{
            PSG_REQ pSgReq = pSG;
            if  (pSgReq && nInBufSize >= (sizeof(SG_REQ) + sizeof(SG_BUF) * (pSgReq->sr_num_sg - 1))) 
			{
			
			}
            else 
			{// Parameter Wrong.
                SetLastError(ERROR_INVALID_PARAMETER);
                return FALSE;
            };
        }
*/
        DoDiskIO(pDisk, dwIoControlCode, pSG);

		if (pSG->sr_status != ERROR_SUCCESS)
		{
			if (pBytesReturned)
				*pBytesReturned = 0;
			SetLastError(pSG->sr_status);
			return FALSE;
		}
		else
		{
			
			if (pBytesReturned)
				*pBytesReturned = (DWORD) pSG->sr_num_sec * SD_BYTES_PER_SECTOR;
		
		}	

        return TRUE;

    case DISK_IOCTL_GETINFO:
        SetLastError(GetDiskInfo(pDisk, (PDISK_INFO)pInBuf));
        return TRUE;

    case DISK_IOCTL_SETINFO:
        SetLastError(SetDiskInfo(pDisk, (PDISK_INFO)pInBuf));
        return TRUE;

    case DISK_IOCTL_INITIALIZED:
        return TRUE;

    case DISK_IOCTL_GETNAME:
        DEBUGMSG(ZONE_FUNCTION, (TEXT("-DSK_IOControl (name) \r\n")));
        return GetFolderName(pDisk, (LPWSTR)pOutBuf, nOutBufSize, pBytesReturned);

    case IOCTL_DISK_DEVICE_INFO: // new ioctl for disk info
        DEBUGMSG(ZONE_FUNCTION, (TEXT("-DSK_IOControl (device info) \r\n")));
        return GetDeviceInfo(pDisk, (PSTORAGEDEVICEINFO)pInBuf);

    default:
        DEBUGMSG(ZONE_FUNCTION, (TEXT("-DSK_IOControl (default) \r\n")));
        SetLastError(ERROR_INVALID_PARAMETER);
        return FALSE;
    }
}   // DSK_IOControl




//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
DWORD DSK_Read(DWORD Handle, LPVOID pBuffer, DWORD dwNumBytes){return 0;}
DWORD DSK_Write(DWORD Handle, LPCVOID pBuffer, DWORD dwNumBytes){return 0;}
DWORD DSK_Seek(DWORD Handle, long lDistance, DWORD dwMoveMethod){return 0;}
void DSK_PowerUp(void){}
void DSK_PowerDown(void){}

//! @}
