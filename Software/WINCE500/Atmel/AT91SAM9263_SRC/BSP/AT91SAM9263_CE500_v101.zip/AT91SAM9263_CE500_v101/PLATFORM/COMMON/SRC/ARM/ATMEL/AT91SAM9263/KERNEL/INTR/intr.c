//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9263/KERNEL/INTR/intr.c
//!
//! \brief		implements the PIO-related tables used by the interrupt engine
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/KERNEL/INTR/intr.c $
//!   $Author: pblanchard $
//!   $Revision: 1058 $
//!   $Date: 2007-07-05 01:34:39 -0700 (Thu, 05 Jul 2007) $
//! \endif
//-----------------------------------------------------------------------------

#include <windows.h>
#include <nkintr.h>
#include <AT91SAM926x.h>
#include "pio_intr.h"
#include "AT91SAM9263_oal_intr.h"


/// This defines the maximum number of physical interrupts handled by the BSP. 
///
/// \note : This value is much higher than the actual number of interrupt managed by the AIC (interrupt controller). It's because the PIOs interrupts go through an abstraction engine allowing to handle any PIO as a distinct interrupt line.
#define AT91SAM9263_OAL_INTR_IRQ_MAXIMUM    224

/// this variable contains the maximum number of physical interrupts handled by the BSP.
const DWORD oal_intr_irq_maximum = AT91SAM9263_OAL_INTR_IRQ_MAXIMUM;

///  This is the table used to do the translation from SYSINTR (system interrupt number) to LOGINTR (physical interrupt number)
///
///  \note SYSINTR_MAXIMUM is defined by the OS itself and cannot be changed.
UINT32 g_oalSysIntr2Irq[SYSINTR_MAXIMUM];
///  This is the table used to do the translation from LOGINTR (physical interrupt number) to SYSINTR (system interrupt number)
UINT32 g_oalIrq2SysIntr[AT91SAM9263_OAL_INTR_IRQ_MAXIMUM];

/// this variable contains the number of PIOs's bank
DWORD g_dwOalPioBankNumber= NB_PIO_BANK;

/// PIOs' banks description table. This is used by the generic PIO interrupt engine.
/// \note the following table is for AT91SAM9263 only
PIOBANKDESCRIPTION g_PioBankDescTab[NB_PIO_BANK]={
	{AT91C_BASE_PIOA,32,0,0,LOGINTR_BASE_PIOA,AT91C_ID_PIOA,0,0}, 
	{AT91C_BASE_PIOB,32,0,0,LOGINTR_BASE_PIOB,AT91C_ID_PIOB,0,0},
	{AT91C_BASE_PIOC,32,0,0,LOGINTR_BASE_PIOC,AT91C_ID_PIOCDE,0,0},
	{AT91C_BASE_PIOD,32,0,0,LOGINTR_BASE_PIOD,AT91C_ID_PIOCDE,0,0},
	{AT91C_BASE_PIOE,32,0,0,LOGINTR_BASE_PIOE,AT91C_ID_PIOCDE,0,0},
};

DWORD IntrProcSpecificGetPMCBaseAddress(void)
{
	return (DWORD) AT91C_BASE_PMC;
}

DWORD IntrProcSpecificGetPITCBaseAddress(void)
{
	return (DWORD) AT91C_BASE_PITC;
}

DWORD IntrProcSpecificGetAICBaseAddress(void)
{
	return (DWORD) AT91C_BASE_AIC;
}

DWORD IntrProcSpecificGetSYSId(void)
{
	return (DWORD) AT91C_ID_SYS;
}

//! @}
////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/KERNEL/INTR/intr.c $
////////////////////////////////////////////////////////////////////////////////
//
