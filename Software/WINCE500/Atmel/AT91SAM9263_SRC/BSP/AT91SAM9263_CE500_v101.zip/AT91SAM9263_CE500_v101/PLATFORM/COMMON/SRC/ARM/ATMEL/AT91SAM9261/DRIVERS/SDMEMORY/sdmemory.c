//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		SDMEMORY/sdmemory.c
//!
//! \brief		SD memory driver for AT91SAM9261's chipset
//!
//! \if cvs
//!   $Author: ltourlonias $
//!   $Revision: 563 $
//!   $Date: 2007-03-14 16:23:47 +0100 (mer., 14 mars 2007) $
//! \endif
//!
//! Description of the driver on multi lines
//-----------------------------------------------------------------------------
//! \addtogroup	SDMEMORY
//! @{
//!


// System include
#include <windows.h>
#include <oal.h>

// Controller includes
#include "AT91SAM9261.h"
#include "lib_AT91SAM9261.h"

extern DWORD SDMemoryBoardSpecificGetMCIID(DWORD dwSlotNumber);

//-----------------------------------------------------------------------------
//! \fn			void SDMemoryProcSpecificActivatePMC(DWORD dwSlotNumber)
//!
//! \brief		This function activates the clock for SDMemory controller in PMC
//!
//! \param		dwSlotNumber	Slot number
//!
//-----------------------------------------------------------------------------
void SDMemoryProcSpecificActivatePMC(DWORD dwSlotNumber)
{
	AT91PS_PMC pPMC;
	PHYSICAL_ADDRESS pa;

	pa.LowPart = (DWORD)AT91C_BASE_PMC;
	pPMC =  (AT91PS_PMC)MmMapIoSpace(pa, sizeof(AT91S_PMC), FALSE);

	pPMC->PMC_PCER = 1 << SDMemoryBoardSpecificGetMCIID(dwSlotNumber);

	MmUnmapIoSpace(pPMC, sizeof(AT91S_PMC));
}

//-----------------------------------------------------------------------------
//! \fn			void SDMemoryProcSpecificDeactivatePMC(DWORD dwSlotNumber)
//!
//! \brief		This function deactivates the clock for SDMemory controller in PMC
//!
//! \param		dwSlotNumber	Slot number
//!
//-----------------------------------------------------------------------------
void SDMemoryProcSpecificDeactivatePMC(DWORD dwSlotNumber)
{
	AT91PS_PMC pPMC;
	PHYSICAL_ADDRESS pa;

	pa.LowPart = (DWORD)AT91C_BASE_PMC;
	pPMC =  (AT91PS_PMC)MmMapIoSpace(pa, sizeof(AT91S_PMC), FALSE);

	pPMC->PMC_PCDR = 1 << SDMemoryBoardSpecificGetMCIID(dwSlotNumber);

	MmUnmapIoSpace(pPMC, sizeof(AT91S_PMC));
}

//! @}

//! @}
