//-----------------------------------------------------------------------------
//! \addtogroup	AT91SAM9263EK
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9263EK.h
//!
//! \brief		AT91SAM9263EK specific declarations
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/INC/at91sam9263EK.h $
//!   $Author: ltourlonias $
//!   $Revision: 846 $
//!   $Date: 2007-05-21 10:30:42 +0200 (lun., 21 mai 2007) $
//! \endif
//-----------------------------------------------------------------------------

#ifndef AT91SAM9263EK_H
#define AT91SAM9263EK_H

// mutex for sharing the SPI/MCI pins
#define SPI_MCI_BUS_MUTEX L"SPIMCIBusMutex"

// Default watchdog period
#define DEFAULT_WATCHDOG_PERIOD	20000 //20s

//
// AT91SAM9263 base of the SDRAM on CS1
//
// Make sure this match up with the def in config.bib
#define AT91SAM9263EK_BASE_SDRAM                AT91C_EBI0_SDRAM


//#define VIDEOMEM_DEFAULT_IN_SDRAM
// Make sure this match up with the def in config.bib (except that here, we're using the physical address)
#define DRIVER_GLOBALS_PHYSICAL_MEMORY_START    0x2006b000
#define DRIVER_GLOBALS_PHYSICAL_MEMORY_SIZE     0x1000  // 4K

#ifdef  VIDEOMEM_DEFAULT_IN_SDRAM
#define AT91SAM9263EK_BASE_VIDEO_MEM		   0x23E00000
#define AT91SAM9263EK_VIDEO_MEM_WIDTH		1024		   
#define AT91SAM9263EK_VIDEO_MEM_HEIGHT		1024
#define	AT91SAM9263EK_VIDEO_MEM_BUS_WIDTH	32
#else
#define AT91SAM9263EK_BASE_VIDEO_MEM		   0x70000000
#define AT91SAM9263EK_VIDEO_MEM_WIDTH		1024		   
#define AT91SAM9263EK_VIDEO_MEM_HEIGHT		1024
#define	AT91SAM9263EK_VIDEO_MEM_BUS_WIDTH	16
#endif

// Make sure this match up with the def in config.bib
#define AT91SAM9263EK_BASE_BLDRIMAGE            0x80000000
#define AT91SAM9263EK_BLDR_RESERVEDAREA_SIZE    0x00058000

#define AT91SAM9263EK_BASE_NAND				0x40000000

#define PIO_USBD_DETECT_PIN_NUMBER			(25)
#define PIO_USBD_DETECT_MASK				((unsigned int) (1<<PIO_USBD_DETECT_PIN_NUMBER))

/*
#define AT91SAM9263EK_BASE_NORFLASH          0x10000000

// NorFlash CS Config in ns (for eboot and OAL)
#define NOR_NWE_SETUP_NS		05	//ns
#define NOR_NWE_PULSE_NS		40	//ns							
#define NOR_NWE_CYCLE_NS		45	//ns
#define NOR_NCS_WR_SETUP_NS		0	//ns
#define NOR_NCS_WR_PULSE_NS		60	//ns
#define NOR_NRD_SETUP_NS		35	//ns
#define NOR_NRD_PULSE_NS		35	//ns
#define NOR_NRD_CYCLE_NS		70	//ns
#define NOR_NCS_RD_SETUP_NS		0	//ns
#define NOR_NCS_RD_PULSE_NS		70	//ns


// NorFlash CS Config in cycles (for firstboot)
#define NOR_NWE_SETUP_CY		1		//cycles
#define NOR_NWE_PULSE_CY		3		//cycles							
#define NOR_NWE_CYCLE_CY		4		//cycles
#define NOR_NCS_WR_SETUP_CY		0		//cycles
#define NOR_NCS_WR_PULSE_CY		4		//cycles
#define NOR_NRD_SETUP_CY		2		//cycles
#define NOR_NRD_PULSE_CY		2		//cycles
#define NOR_NRD_CYCLE_CY		4		//cycles
#define NOR_NCS_RD_SETUP_CY		0		//cycles
#define NOR_NCS_RD_PULSE_CY		4		//cycles
#define NOR_TDF_CYCLES	(1 << 16)		//cycles
*/


// PSRAM CS on EBI1 Config in ns
#define AT91C_PSRAM_EBI1_NWE_SETUP			10
#define AT91C_PSRAM_EBI1_NCS_WR_SETUP		10
#define AT91C_PSRAM_EBI1_NWE_PULSE			60
#define AT91C_PSRAM_EBI1_NCS_WR_PULSE		60	
#define AT91C_PSRAM_EBI1_NWE_CYCLE			90

#define AT91C_PSRAM_EBI1_NCS_RD_SETUP		10	
#define AT91C_PSRAM_EBI1_NRD_SETUP			10		
#define AT91C_PSRAM_EBI1_NCS_RD_PULSE		60
#define AT91C_PSRAM_EBI1_NRD_PULSE			60
#define AT91C_PSRAM_EBI1_NRD_CYCLE			90

#define AT91C_PSRAM_EBI1_TDF_CYCLES			(1<<16)
//-----------------------------------------------------------------------------
// Type definition
//

// Type used for know what kind of memory is used for 
// store eboot
typedef enum { NANDFLASH_BOOT_TYPE=0xC4C4C4C4
             , DATAFLASH_CS0_BOOT_TYPE=0xA9A9A9A9
             , DATAFLASH_CS1_BOOT_TYPE=0x17171717
             } BOOTLOADER_TYPE;


//------------------------------------------------------------------------------
// Structure definitions. 
//
#pragma pack(1)
// The EBOOT_CFG structure holds a variety of configuration parameters.
// When adding new parameters, make sure that the size of the structure in bytes is 
// an integral number of DWORDS.  Pad the structure if necessary.
/*typedef struct
{
    DWORD dwPhysStart;
    DWORD dwPhysLen;
    DWORD dwLaunchAddr;    
    DWORD dwFlashDevice;
    DWORD dwFlashOffset;
} IMGBOOT_DESC;

typedef struct
{
    DWORD autoDownloadImage;
    DWORD IP;
    DWORD subnetMask;
    DWORD numBootMe;
    DWORD delay;
    DWORD DHCPEnable;
    DWORD bootDeviceOrder;
    DWORD CheckSignatures;
	DWORD dwCoreFrequency;
	DWORD dwBusFreqDivider;
	BOOL  bImgToFlash;
	UCHAR MacAddress[6];
	IMGBOOT_DESC	imgBootDescArray[1];
    WORD crc16;    
} EBOOT_CFG, *PEBOOT_CFG;
*/
#pragma pack()

#endif // AT91SAM9263EK_H



//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/thales_navigation-bsp_nadia2ek/TRUNK/WINCE500/PLATFORM/nadia2EK/SRC/INC/nadia2EK.h $
//-----------------------------------------------------------------------------
//