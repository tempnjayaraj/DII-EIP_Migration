//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//! \addtogroup	WAVEDEV
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		aclink.c
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/WAVEDEV/aclink.c $
//!   $Author: ltourlonias $
//!   $Revision: 684 $
//!   $Date: 2007-04-13 14:35:48 +0200 (ven., 13 avr. 2007) $
//! \endif
//!
//! Implementation of the communication function (between the controller and the codec)
//-----------------------------------------------------------------------------

#include <windows.h>
#include <ceddk.h>
#include "at91sam926x.h"
#include "aclink.h"


#define READ_TIMEOUT 10
#define WRITE_TIMEOUT	10


extern AT91PS_AC97C   g_pAC97C;
static BOOL g_IsAC97Configured = FALSE;
static HANDLE g_hACLinkControlMutex = NULL;


//-----------------------------------------------------------------------------
//! \fn			BOOL InitializeACLink()
//!
//! \brief		This function intialiase AC97
//!
//! \return		TRUE when all is good
//!	\return		\e FALSE when all is bad
//-----------------------------------------------------------------------------
BOOL InitializeACLink()
{   
	if (g_hACLinkControlMutex == NULL)
    {
        g_hACLinkControlMutex = CreateMutex(NULL, FALSE, ACLINK_MUTEX_NAME);
    }

    return(TRUE);
}

//-----------------------------------------------------------------------------
//! \fn			BOOL DeInitializeACLink()
//!
//! \brief		This function deintialiase AC97
//!
//! \return		TRUE when all is good
//!	\return		\e FALSE when all is bad
//-----------------------------------------------------------------------------
BOOL DeInitializeACLink()
{
  
	if (g_hACLinkControlMutex)
    {
        CloseHandle(g_hACLinkControlMutex);
    }

    return(TRUE);
}


//-----------------------------------------------------------------------------
//! \fn			BOOL GetAC97Lock()
//!
//! \brief		This function lock the AC97
//!
//! \return		TRUE when all is good
//!	\return		\e FALSE when all is bad
//-----------------------------------------------------------------------------
static BOOL GetAC97Lock(void)
{   

    if (WaitForSingleObject(g_hACLinkControlMutex, 500) == WAIT_OBJECT_0)
    {
        return(TRUE);
    }
    else
    {
        return(FALSE);
    }
}

//-----------------------------------------------------------------------------
//! \fn			BOOL ReleaseAC97Lock()
//!
//! \brief		This function release the AC97
//!
//! \return		TRUE when all is good
//!	\return		\e FALSE when all is bad
//-----------------------------------------------------------------------------
static BOOL ReleaseAC97Lock(void)
{

    
    ReleaseMutex(g_hACLinkControlMutex);

    return(TRUE);
}


//-----------------------------------------------------------------------------
//! \fn			BOOL ReadAC97Raw(UINT8 Offset, UINT16 *pData)
//!
//! \brief		Read raw data on the AC97
//!
//! \param		Offset	Address where to read
//! \param		pData	Address where to write
//!
//! \return		TRUE when all is good
//!	\return		\e FALSE when all is bad
//-----------------------------------------------------------------------------
BOOL ReadAC97Raw(UINT8 Offset, UINT16 *pData)
{
	DWORD dwEndDate;
	DWORD dwDummy = g_pAC97C->AC97C_COSR; //Clear th RXRDY bit if set

	if ((pData == NULL) || (Offset > 0x7f))
	{
		return FALSE;
	}
	
	dwEndDate = GetTickCount() + READ_TIMEOUT;
	do
	{
		if (g_pAC97C->AC97C_COSR & AT91C_AC97C_TXRDY)
		{
			g_pAC97C->AC97C_COTHR = AT91C_AC97C_READ + (Offset << 16);
			break;
		}
	}
	while (dwEndDate > GetTickCount());
	
	
	dwEndDate = GetTickCount() + READ_TIMEOUT;
	do
	{
		if (g_pAC97C->AC97C_COSR & AT91C_AC97C_RXRDY)
		{
			*pData = g_pAC97C->AC97C_CORHR;
			return TRUE;
		}

	}
	while (dwEndDate > GetTickCount());
	
    return(FALSE);
}

//-----------------------------------------------------------------------------
//! \fn			BOOL ReadAC97(UINT8 Offset, UINT16 *pData)
//!
//! \brief		Read data on the AC97
//!
//! \param		Offset	Address where to read
//! \param		pData	Address where to write
//!
//! \return		TRUE when all is good
//!	\return		\e FALSE when all is bad
//-----------------------------------------------------------------------------
BOOL ReadAC97(UINT8 Offset, UINT16 *pData)
{
    BOOL retVal = FALSE;

    if (GetAC97Lock() == TRUE)
    {
        retVal = ReadAC97Raw(Offset, pData);
        ReleaseAC97Lock();
    }

    return(retVal);
}

//-----------------------------------------------------------------------------
//! \fn			BOOL WriteAC97Raw(UINT8 Offset, UINT16 wData)
//!
//! \brief		Write raw data on the AC97
//!
//! \param		Offset	Address where to write
//! \param		wData	Data to write
//!
//! \return		TRUE when all is good
//!	\return		\e FALSE when all is bad
//-----------------------------------------------------------------------------
BOOL WriteAC97Raw(UINT8 Offset, UINT16 wData)
{
	DWORD dwEndDate;
	
	if (Offset > 0x7f)
	{
		return FALSE;
	}		
	
	dwEndDate = GetTickCount() + WRITE_TIMEOUT;

	do
	{
		if (g_pAC97C->AC97C_COSR & AT91C_AC97C_TXRDY)
		{
			g_pAC97C->AC97C_COTHR = (Offset << 16) | wData;
			return TRUE;
		}
	}
	while (dwEndDate > GetTickCount());
	
    return(FALSE);
}

//-----------------------------------------------------------------------------
//! \fn			BOOL WriteAC97(UINT8 Offset, UINT16 Data)
//!
//! \brief		Write data on the AC97
//!
//! \param		Offset	Address where to write
//! \param		Data	Data to write
//!
//! \return		TRUE when all is good
//!	\return		\e FALSE when all is bad
//-----------------------------------------------------------------------------
BOOL WriteAC97(UINT8 Offset, UINT16 Data)
{
    BOOL retVal = FALSE;

    if (GetAC97Lock() == TRUE)
    {
        retVal = WriteAC97Raw(Offset, Data);
        ReleaseAC97Lock();
    }

    return(retVal);
}
//! @}
//! @}