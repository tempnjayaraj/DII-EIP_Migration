//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		procinfo.c
//!
//! \brief		This file implements the IOCTL_PROCESSOR_INFORMATION handler
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/KERNEL/IOCTL/procinfo.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------


#include <windows.h>
#include <oal.h>
#include "at91RM9200.h"
#include "at91rm9200_interface.h"



//------------------------------------------------------------------------------
//  Define:  IOCTL_PROCESSOR_VENDOR/CORE
//
//  Defines the processor information
//
#define IOCTL_PROCESSOR_VENDOR              (L"ATMEL")
#define IOCTL_PROCESSOR_CORE                (L"ARM920T")
#define IOCTL_PROCESSOR_NAME                (L"AT91RM9200")

//------------------------------------------------------------------------------
//
//  Define:  IOCTL_PROCESSOR_INSTRUCTION_SET
//
//  Defines the processor instruction set information
//
#define IOCTL_PROCESSOR_INSTRUCTION_SET     (0)

 
//-----------------------------------------------------------------------------
//! \fn		BOOL OALIoCtlHalGetProcessorClock(	UINT32 code, VOID *pInpBuffer, 
//!								UINT32 inpSize, VOID *pOutBuffer, 
//!								UINT32 outSize, UINT32 *pOutSize)
//!
//! \brief		Implements the IOCTL_PROCESSOR_INFORMATION handler.
//!				Returns information about the processor (vendor, Instruction set, frequency, etc ...)
//!
//!	\param		code		not used
//!	\param		pInpBuffer	not used
//!	\param		inpSize		not used
//!	\param		pOutBuffer	Information returned
//!	\param		outSize		Size of pOutBuffer
//!	\param		pOutSize	Size of pOutBuffer used
//!
//! \return		TRUE indicates success
//! \return		FALSE indicates failure (bad parameters)
//!
//! 
//-----------------------------------------------------------------------------
BOOL OALIoCtlProcessorInfo(
    UINT32 code, VOID *pInpBuffer, UINT32 inpSize, VOID *pOutBuffer, 
    UINT32 outSize, UINT32 *pOutSize
) {
    BOOL rc = TRUE;
    PROCESSOR_INFO *pInfo = (PROCESSOR_INFO*)pOutBuffer;
    UINT32 length1, length2, length3;

    OALMSG(OAL_FUNC, (L"+OALIoCtlAT91RM9200ProcessorInfo(...)\r\n"));

    // Set required/returned size if pointer isn't NULL
    if (pOutSize != NULL) *pOutSize = sizeof(PROCESSOR_INFO);
    
    // Validate inputs
    if (pOutBuffer == NULL || outSize < sizeof(PROCESSOR_INFO)) {
        NKSetLastError(ERROR_INSUFFICIENT_BUFFER);
        OALMSG(OAL_WARN, (
            L"WARN: OALIoCtlAT91RM9200ProcessorInfo: Buffer too small\r\n"
        ));
        rc = FALSE;
    }

    // Verify OAL lengths
    length1 = (NKwcslen(IOCTL_PROCESSOR_CORE) + 1) * sizeof(WCHAR);
    if (length1 > sizeof(pInfo->szProcessCore)) {
        OALMSG(OAL_ERROR, (
            L"ERROR:OALIoCtlAT91RM9200ProcessorInfo: Core value too big\r\n"
        ));
        rc = FALSE;
    }

    length2 = (NKwcslen(IOCTL_PROCESSOR_NAME) + 1) * sizeof(WCHAR);
    if (length2 > sizeof(pInfo->szProcessorName)) {
        OALMSG(OAL_ERROR, (
            L"ERROR:OALIoCtlAT91RM9200ProcessorInfo: Name value too big\r\n"
        ));
        rc = FALSE;
    }

    length3 = (NKwcslen(IOCTL_PROCESSOR_VENDOR) + 1) * sizeof(WCHAR);
    if (length3 > sizeof(pInfo->szVendor)) {
        OALMSG(OAL_ERROR, (
            L"ERROR:OALIoCtlAT91RM9200ProcessorInfo: Vendor value too big\r\n"
        ));
        rc = FALSE;
    }



	if(rc)
	{
		// Copy in processor information    
		pInfo->wVersion = 1;
		memset(pInfo, 0, sizeof(PROCESSOR_INFO));
		memcpy(pInfo->szProcessCore, IOCTL_PROCESSOR_CORE, length1);
		memcpy(pInfo->szProcessorName, IOCTL_PROCESSOR_NAME, length2);
		memcpy(pInfo->szVendor, IOCTL_PROCESSOR_VENDOR, length3);
		pInfo->dwInstructionSet = IOCTL_PROCESSOR_INSTRUCTION_SET;
		pInfo->dwClockSpeed  = AT91RM9200_GetMasterClock(FALSE);
	}
	else
	{
		OALMSG(OAL_FUNC, (L"-OALIoCtlAT91RM9200ProcessorInfo(rc = %d)\r\n", rc));
	}
    return rc;
}

//! @}


