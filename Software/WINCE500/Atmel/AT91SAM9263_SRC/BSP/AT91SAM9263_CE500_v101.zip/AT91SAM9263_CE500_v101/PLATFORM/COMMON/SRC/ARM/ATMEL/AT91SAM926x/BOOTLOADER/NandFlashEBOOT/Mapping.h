//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/NandFlashEBOOT/Mapping.h
//!
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/NandFlashEBOOT/Mapping.h $
//!   $Author: ltourlonias $
//!   $Revision: 657 $
//!   $Date: 2007-04-10 16:52:09 +0200 (mar., 10 avr. 2007) $
//! \endif
//!
//! 
//-----------------------------------------------------------------------------
//! \addtogroup	NandFlash
//! @{
//!

#ifndef __MAPPING__
#define __MAPPING__

#include <windows.h>

// Write Protection System codes
#define BLOCK_WP_NOPROTECTION		0x00	//!< No write protection
#define BLOCK_WP_ACTIVATED			0x01	//!< Write protection activated
#define BLOCK_RESERVED				0x02	//!< Block is reserved

// Sector zones
#define ZONE_DATA					0x01	//!< Sector data zone
#define ZONE_INFO					0x02	//!< Sector info zone

//! \brief A mapping section
typedef struct _MapSection
{
	DWORD dwPhyBlock;			//!< Physical block number
	DWORD dwLogBlock;			//!< Logical block number
	DWORD dwSizeInBlock;		//!< Size in block of the mapping section
	DWORD dwStatus;				//!< Status word for all blocks of the section (WriteProtection enable or disable)
} MapSection;

//! \brief A mapping plan
typedef struct _MapSectionList
{
	DWORD		dwNbElements;		//!< NbElements
	MapSection	MapSectionArray[];	//!< SectionList
} MapSectionList;

#endif 

// End of Doxygen group NandFlash Driver
//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/NandFlashEBOOT/Mapping.h $
//-----------------------------------------------------------------------------
//
//! @}
