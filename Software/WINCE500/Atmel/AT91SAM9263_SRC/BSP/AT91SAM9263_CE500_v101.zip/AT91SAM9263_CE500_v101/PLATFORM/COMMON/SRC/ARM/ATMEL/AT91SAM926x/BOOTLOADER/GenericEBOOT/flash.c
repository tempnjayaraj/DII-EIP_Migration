//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//-----------------------------------------------------------------------------
//! \file		flash.c 
//!
//! \brief		All common bootloader flash entry implementation
//!
//! \if subversion
///   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/GenericEBOOT/flash.c $
//!   $Author: nlaunet $
//!   $Revision: 668 $
//!   $Date: 2007-04-12 11:36:04 +0200 (jeu., 12 avr. 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	EBOOT
//! @{
//!

//------------------------------------------------------------------------------
//                                                                      Includes
//------------------------------------------------------------------------------
// Standard includes
#include <windows.h>
#include <blcommon.h>

// Local includes
#include "bootloader_struct.h"
#include "eboot_msg.h"


//------------------------------------------------------------------------------
//                                                             Imported variable
//------------------------------------------------------------------------------
// This varaible contain all eboot config
extern EBOOT_CFG		g_EbootCFG;

//------------------------------------------------------------------------------
//                                                             Imported function
//------------------------------------------------------------------------------
extern BOOL				EBOOT_InitFlash(DWORD dwAddress);
extern BOOL				EBOOT_ReadFlash(DWORD dwAddressDst, DWORD dwAddressSrc, DWORD dwLen);
extern BOOL				EBOOT_WriteFlash(DWORD dwAddressDst, DWORD dwAddressSrc, DWORD dwLen);
extern BOOL				EBOOT_EraseFlash(DWORD dwAddress, DWORD dwLen);



//------------------------------------------------------------------------------
//                                                            Exported functions
//------------------------------------------------------------------------------


//--------------------------------------------------------------------------------
//! \fn BOOL OEMStartEraseFlash (DWORD dwStartAddr, DWORD dwLength)
//! 
//! \brief This function is call by bl framework when erase flash is wanted
//!
//! \param dwStartAddr The start flash address
//!
//! \param dwLength The length of erase flash
//!
//! \return Always true
//--------------------------------------------------------------------------------
BOOL OEMStartEraseFlash (DWORD dwStartAddr, DWORD dwLength)
{
	return(TRUE);
}

//--------------------------------------------------------------------------------
//! \fn void OEMContinueEraseFlash (void)
//! 
//! \brief This function is call during flash erasing
//--------------------------------------------------------------------------------
void OEMContinueEraseFlash (void)
{
}

//--------------------------------------------------------------------------------
//! \fn BOOL OEMFinishEraseFlash (void)
//! 
//! \brief This function is call when erasing is finish
//--------------------------------------------------------------------------------
BOOL OEMFinishEraseFlash (void)
{
	return TRUE;
}

//--------------------------------------------------------------------------------
//! \fn BOOL OEMIsFlashAddr (DWORD dwAddr)
//! 
//! \brief This must return if parameters is within the flash memory space
//!
//! \param dwAddr The address you want to test
//! 
//! \return TRUE if is a flash address, FALSE else
//--------------------------------------------------------------------------------
BOOL OEMIsFlashAddr (DWORD dwAddr)
{
	if (g_EbootCFG.bImgToFlash == TRUE)
	{
		return(TRUE);
	}
	else
	{
		return(FALSE);
	}	
}

//--------------------------------------------------------------------------------
//! \fn BOOL OEMWriteFlash(DWORD dwStartAddr, DWORD dwLength)
//! 
//! \brief This function write data to flash memory section reserved for image saving
//!
//! \param dwStartAddr The source address where find data to copy
//!
//! \param dwLength Length in byte to write in flash
//! 
//! \return TRUE if correctly write, FALSE else
//--------------------------------------------------------------------------------
BOOL OEMWriteFlash(DWORD dwStartAddr, DWORD dwLength)
{	
	RETAILMSG(1, (EMSG_IMG_FLASH_ERASE));
	if (EBOOT_EraseFlash(g_EbootCFG.imgBootDesc.dwFlashLogicalAddress, dwLength) == TRUE)
	{
		RETAILMSG(1, (EMSG_IMG_FLASH_ERASE_SUCCESS));
	}
	else
	{
		RETAILMSG(1, (EMSG_FAILED));
		return FALSE;
	}
	RETAILMSG(1, (EMSG_CRLF));

	
	RETAILMSG(1, (EMSG_IMG_FLASH_WRITE));
	if (EBOOT_WriteFlash(g_EbootCFG.imgBootDesc.dwFlashLogicalAddress, dwStartAddr, dwLength) == TRUE)
	{
		RETAILMSG(1, (EMSG_IMG_FLASH_WRITE_SUCCESS));
	}
	else
	{
		RETAILMSG(1, (EMSG_FAILED));
		return FALSE;
	}
	RETAILMSG(1, (EMSG_CRLF));

	return(TRUE);
}

//--------------------------------------------------------------------------------
//! \fn LPBYTE OEMMapMemAddr (DWORD dwImageStart, DWORD dwAddr)
//! 
//! \brief This function permit to map a memory address
//!
//! \param dwImageStart The image address start
//!
//! \param dwAddr The image length
//! 
//! \return The mapped address
//--------------------------------------------------------------------------------
LPBYTE OEMMapMemAddr (DWORD dwImageStart, DWORD dwAddr)
{
	return((LPBYTE)dwAddr);
}

//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/GenericEBOOT/flash.c $
//------------------------------------------------------------------------------

//
//! @}
//
//
//! @}
