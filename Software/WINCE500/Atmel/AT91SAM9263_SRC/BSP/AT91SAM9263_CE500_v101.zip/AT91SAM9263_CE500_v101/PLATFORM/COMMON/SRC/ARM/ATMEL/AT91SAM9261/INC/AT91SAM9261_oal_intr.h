//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9261_oal_intr.h
//!
//! \brief		Definitions of the interrupt constants
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9261/INC/AT91SAM9261_oal_intr.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//-----------------------------------------------------------------------------

#ifndef AT91SAM9261_OALINTR_H
#define AT91SAM9261_OALINTR_H


// the following values are used to compute the LOGINTR associated with a PIO pin.
// For example LOGINTR for PIOA pin 4 is LOGINTR_BASE_PIOA + 4
#define LOGINTR_BASE_PIOA			64
#define LOGINTR_BASE_PIOB			96                           
#define LOGINTR_BASE_PIOC			128                          

//////////////////////////////////////////////////////////////////////
//                          
// SYSINTR values
//
#define SYSINTR_SYS			    (SYSINTR_FIRMWARE+0)
#define SYSINTR_ETHER			(SYSINTR_FIRMWARE+1)


#endif

//! @}


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9261/INC/AT91SAM9261_oal_intr.h $
////////////////////////////////////////////////////////////////////////////////
//
