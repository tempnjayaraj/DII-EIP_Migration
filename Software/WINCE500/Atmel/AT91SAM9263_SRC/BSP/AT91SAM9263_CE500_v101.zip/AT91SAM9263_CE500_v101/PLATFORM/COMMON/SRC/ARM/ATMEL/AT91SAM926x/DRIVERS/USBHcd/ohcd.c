//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		ohcd.c
//!
//! \brief		implements the OHCD platform dependent part (what's specific to the AT91SAM926x familly)
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/USBHcd/ohcd.c $
//!   $Author: pblanchard $
//!   $Revision: 984 $
//!   $Date: 2007-06-11 09:19:22 -0700 (Mon, 11 Jun 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	USBHost
//! @{
//!
#include <windows.h>
#include <ceddk.h>
#include <ohcdddsi.h>
#include <at91sam926x.h>
#include <at91sam926x_oal_intr.h>
#include <Devload.h>

// external function 
extern BOOL HWUSBBoardSpecificInit();


#define TOTAL_AVAILABLE_PHYS_MEM_VALUE_NAME     L"TotalAvailablePhysMem"
#define HIGH_PRIO_PHYS_MEM_VALUE_NAME           L"HighPrioPhysMem"

/// Default amount of memory to use for HCD buffer. Can be overriden by settings in the registry
static DWORD gcTotalAvailablePhysicalMemory = 65536; // 64K
/// Default amount of high priority memory to use for HCD buffer. Can be overriden by settings in the registry
static DWORD gcHighPriorityPhysicalMemory = 0x4000; // 16K

typedef struct _SOhcdPdd
{
    LPVOID lpvMemoryObject;
    LPVOID lpvOhcdMddObject;
	DWORD  dwSysIntr;
	AT91PS_UHP v_pUHPRegs;
} SOhcdPdd;

#define UnusedParameter(x)  x = x

#define DataSIZE 0x12
char pUHPData[DataSIZE];

//-----------------------------------------------------------------------------
//! \fn			HcdPdd_DllMain(HANDLE hinstDLL, DWORD dwReason, LPVOID lpvReserved)
//!
//! \brief		This function is the entry point of the Dll driver
//!
//! \param		hinstDLL	DLL instance
//! \param		dwReason	Reason of the call
//! \param		lpvReserved	Not used
//!
//! \return		TRUE
//!
//! This function intialize debug zone when called with the DLL_PROCESS_ATTACH reason
//-----------------------------------------------------------------------------
BOOL HcdPdd_DllMain(HANDLE hinstDLL, DWORD dwReason, LPVOID lpvReserved)
{
    UnusedParameter(hinstDLL);
    UnusedParameter(dwReason);
    UnusedParameter(lpvReserved);

    return TRUE;
}

static AT91PS_PMC v_PMCRegs;


#define AT91C_PRDSTRTVAL 0x2240
#define AT91C_FRINTERVAL 0x2710
#define AT91C_FSMAXPKTSZ (((AT91C_FRINTERVAL * 6) / 7) - 180)
#define AT91C_PRDSTRT    AT91C_PRDSTRTVAL
#define AT91C_FMINTERVAL ((AT91C_FSMAXPKTSZ << 16) | AT91C_FRINTERVAL)

//-----------------------------------------------------------------------------
//! \fn			static BOOL InitializeOHCI(SOhcdPdd * pPddObject, LPCWSTR szDriverRegKey)
//!
//! \brief		This function configures and initializes OHCI card
//!
//! \param		pPddObject	IN - Pointer to PDD structure
//! \param		szDriverRegKey	IN - Pointer to active registry key string
//!
//! \return		\e TRUE when the card could be located and configured
//!	\return		\e FALSE when all is bad
//!
//! This function configures and initializes OHCI card
//-----------------------------------------------------------------------------
static BOOL InitializeOHCI(SOhcdPdd * pPddObject, LPCWSTR szDriverRegKey)
{    
    LPVOID				pobMem			= NULL;
	LPVOID				pobOhcd			= NULL;
	DWORD				logintr			;
	PHYSICAL_ADDRESS	PhysicalAddress	;
	
	RETAILMSG(1, (TEXT("++InitializeOHCI\r\n")));
	
	// Mapping of physical register addresses in virtual address memory	
	PhysicalAddress.HighPart = 0;
	PhysicalAddress.LowPart = (DWORD) AT91C_BASE_PMC;
	v_PMCRegs = (AT91PS_PMC ) MmMapIoSpace(PhysicalAddress,sizeof(AT91S_PMC),FALSE);
	 

	//Power-up the USB Host Port			
	v_PMCRegs->PMC_SCER = AT91C_PMC_UHP_MASK;			// Start the clock here	
	v_PMCRegs->PMC_PCER = (1 << AT91C_ID_UHP);		
	
	HWUSBBoardSpecificInit();

	PhysicalAddress.HighPart = 0;
	PhysicalAddress.LowPart = (DWORD) AT91C_BASE_UHP ;
	pPddObject->v_pUHPRegs = MmMapIoSpace(PhysicalAddress,sizeof(AT91S_UHP),FALSE);
    if (pPddObject->v_pUHPRegs == NULL)
    {        
		goto error;
	}

	logintr = AT91C_ID_UHP;
	if (!KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &logintr, sizeof(logintr), &pPddObject->dwSysIntr, sizeof(pPddObject->dwSysIntr), NULL))
	{
		RETAILMSG(1, (TEXT("ERROR: Failed to request the serial sysintr for USB Device (logintr :%d).\r\n"),logintr));
		pPddObject->dwSysIntr = SYSINTR_UNDEFINED;
	}       
    // The PDD can supply a buffer of contiguous physical memory here, or can let the 
    // MDD try to allocate the memory from system RAM.  In our case, let the MDD do it.
    pobMem = HcdMdd_CreateMemoryObject(gcTotalAvailablePhysicalMemory,gcHighPriorityPhysicalMemory, NULL,NULL); 
    if(pobMem == NULL)
    {
		RETAILMSG(1,(TEXT("OHCD: Memory Object FAILED\r\n")));
		goto error;
	}
        

    pobOhcd = HcdMdd_CreateHcdObject(pPddObject, pobMem, szDriverRegKey, (PUCHAR)pPddObject->v_pUHPRegs, pPddObject->dwSysIntr);
	if (pobOhcd == NULL)
	{
		goto error;
	}
    
    pPddObject->lpvMemoryObject = pobMem;
    pPddObject->lpvOhcdMddObject = pobOhcd;

    RETAILMSG(1, (TEXT("--InitializeOHCI\r\n")));
    
    return TRUE;
error:
	if (pobOhcd)
        HcdMdd_DestroyHcdObject(pobOhcd);
    if (pobMem)
        HcdMdd_DestroyMemoryObject(pobMem);
	
	if (pPddObject->v_pUHPRegs)
	{
		MmUnmapIoSpace ((PVOID) pPddObject->v_pUHPRegs, sizeof(AT91S_UHP));
	}

	if (pPddObject->dwSysIntr!= SYSINTR_UNDEFINED)
	{
		DWORD dummy;
		KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, (PVOID)&pPddObject->dwSysIntr,sizeof(pPddObject->dwSysIntr), NULL, 0, &dummy);
	}

	if (v_PMCRegs != NULL)
	{
	   MmUnmapIoSpace(v_PMCRegs,sizeof(AT91S_PMC));
	}
	
    pobOhcd = NULL;
    pobMem = NULL;

	RETAILMSG(1, (TEXT("--InitializeOHCI FAILED!!!\r\n")));

	return FALSE;
}

//-----------------------------------------------------------------------------
//! \fn			DWORD HcdPdd_Init(DWORD dwContext)
//!
//! \brief		This function is the PDD Entry point - called at system init to detect and configure OHCI card.
//!
//! \param		dwContext	IN - Pointer to context value. For device.exe, this is a string indicating our active registry key.
//!
//! \return		adress of the SOhcdPdd object created and initialized
//!
//! This function is the PDD Entry point - called at system init to detect and configure OHCI card.
//-----------------------------------------------------------------------------
DWORD HcdPdd_Init(DWORD dwContext)  
                      
{
    SOhcdPdd *  pPddObject = malloc(sizeof(SOhcdPdd));
    BOOL        fRet = FALSE;
    HKEY hKey = NULL;

    RETAILMSG(1, (TEXT("USB:OhcdPdd_Init\r\n"))); 
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, (LPCTSTR )dwContext, 0, 0, &hKey) != ERROR_SUCCESS)

//	the function "OpenDeviceKey" always return hKey=NULL ???
//  hKey = OpenDeviceKey((LPCTSTR )dwContext);
//  if ( !hKey ) 
	{
        RETAILMSG(1,(TEXT("Failed to open device key, Using default buffer sizes\r\n")));                
    }
    else
    {
        DWORD dwType,dwValue,dwSize;
        
        dwSize = sizeof(DWORD);
        if ( RegQueryValueEx(hKey,TOTAL_AVAILABLE_PHYS_MEM_VALUE_NAME, NULL, &dwType,(LPBYTE)&dwValue, &dwSize) ) {
            RETAILMSG(1,(TEXT("Failed to get %s value, Using default 'Total Available Physical Memory' size\r\n")));         
        }
        else
        {
            gcTotalAvailablePhysicalMemory = dwValue;
        }
        
        dwSize = sizeof(DWORD);
        if ( RegQueryValueEx(hKey,HIGH_PRIO_PHYS_MEM_VALUE_NAME, NULL, &dwType,(LPBYTE)&dwValue, &dwSize) ) {
            RETAILMSG(1,(TEXT("Failed to get %s value, Using default 'High Priority Physical Memory' size\r\n")));         
        }
        else
        {
            gcHighPriorityPhysicalMemory = dwValue;
        }
        
        RegCloseKey(hKey);
    }
    
    

    fRet = InitializeOHCI(pPddObject, (LPCWSTR)dwContext);

    if(!fRet)
    {
        free(pPddObject);
        pPddObject = NULL;
    }
    
    return (DWORD)pPddObject;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL HcdPdd_CheckConfigPower(UCHAR bPort, DWORD dwCfgPower, DWORD dwTotalPower)
//!
//! \brief		This function checks power required by specific device configuration 
//! \brief 		and returns whether it can be supported on this platform.
//!
//! \note 		For the moment, this is trivial, just limit to
//! \note 		the 500mA requirement of USB.  But this could be 
//! \note 		more sophisticated, taking into account current battery status or other info.
//!
//! \param		bPort		IN - Port number
//! \param		dwCfgPower	IN - Power required by configuration
//! \param		dwTotalPower	IN - Total power currently in use on port
//!
//! \return		\e TRUE when the card could be located and configured
//!	\return		\e FALSE when all is bad
//!
//! This function checks power required by specific device configuration
//-----------------------------------------------------------------------------
BOOL HcdPdd_CheckConfigPower(UCHAR bPort, DWORD dwCfgPower, DWORD dwTotalPower)
{
    return ((dwCfgPower + dwTotalPower) > 500) ? FALSE : TRUE;
}

//-----------------------------------------------------------------------------
//! \fn			void HcdPdd_PowerUp(DWORD hDeviceContext)
//!
//! \brief		This function powers up the controller  
//!
//! \param		hDeviceContext	IN - Device driver context
//!
//! This function powers up the controller
//-----------------------------------------------------------------------------
void HcdPdd_PowerUp(DWORD hDeviceContext)
{
    SOhcdPdd * pPddObject = (SOhcdPdd *)hDeviceContext;
    
		//Power-up the USB Host Port			
	v_PMCRegs->PMC_PCER = (1 << AT91C_ID_UHP);		
	v_PMCRegs->PMC_SCER = AT91C_PMC_UHP_MASK;		

	HcdMdd_PowerUp(pPddObject->lpvOhcdMddObject);
	

    return;
}

//-----------------------------------------------------------------------------
//! \fn			void HcdPdd_PowerDown(DWORD hDeviceContext)
//!
//! \brief		This function powers down the controller  
//!
//! \note 		This does not stops the clocks however.
//!
//! \param		hDeviceContext	IN - Device driver context
//!
//! This function powers down the controller
//-----------------------------------------------------------------------------
void HcdPdd_PowerDown(DWORD hDeviceContext)
{
    SOhcdPdd * pPddObject = (SOhcdPdd *)hDeviceContext;

	HcdMdd_PowerDown(pPddObject->lpvOhcdMddObject);

	//Power-dwon the USB Host Port			
	v_PMCRegs->PMC_PCDR = (1 << AT91C_ID_UHP);		
	v_PMCRegs->PMC_SCDR = AT91C_PMC_UHP_MASK;			// Stop the 48 MHz clock here	
	
    return;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL HcdPdd_Deinit(DWORD hDeviceContext)
//!
//! \brief		This function deinitializes the driver and cleans up what's been
//! \brief     initalized in the HcdPdd_Init function and stops the clocks  
//!
//! \param		hDeviceContext	IN - Device driver context
//!
//! \return		\e TRUE when all is good
//!	\return		\e FALSE when all is bad
//!
//! This function deinitializes the driver
//-----------------------------------------------------------------------------
BOOL HcdPdd_Deinit(DWORD hDeviceContext)
{
    SOhcdPdd * pPddObject = (SOhcdPdd *)hDeviceContext;
	
    if(pPddObject->lpvOhcdMddObject)
        HcdMdd_DestroyHcdObject(pPddObject->lpvOhcdMddObject);
    if(pPddObject->lpvMemoryObject)
        HcdMdd_DestroyMemoryObject(pPddObject->lpvMemoryObject);
	if (pPddObject->dwSysIntr!= SYSINTR_UNDEFINED)
	{
		DWORD dummy;
		KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, (PVOID)&pPddObject->dwSysIntr,sizeof(pPddObject->dwSysIntr), NULL, 0, &dummy);
	}
	if (pPddObject->v_pUHPRegs)
		VirtualFree ((PVOID) pPddObject->v_pUHPRegs, 0, MEM_RELEASE);



	// Stop UHP clocks 


	if (v_PMCRegs != NULL)
	{
		v_PMCRegs->PMC_SCDR = AT91C_PMC_UHP_MASK;			// Stop the clock	
		v_PMCRegs->PMC_PCDR = (1 << AT91C_ID_UHP);		
	    
		MmUnmapIoSpace(v_PMCRegs,sizeof(AT91S_PMC)); //unmap the UHP registers' space 
	}
	

    return TRUE;
}

//-----------------------------------------------------------------------------
//! \fn			DWORD HcdPdd_Open(DWORD hDeviceContext, DWORD AccessCode, DWORD ShareMode)
//!
//! \brief    		This function is not implemented
//!
//! \param		hDeviceContext IN - Device driver context
//! \param		AccessCode IN - Access Mode
//! \param		ShareMode IN - Share Mode
//!
//! \return		\e TRUE when all is good
//!	\return		\e FALSE when all is bad
//!
//! This function is not implemented
//-----------------------------------------------------------------------------
DWORD HcdPdd_Open(DWORD hDeviceContext, DWORD AccessCode, DWORD ShareMode)
{
    UnusedParameter(hDeviceContext);
    UnusedParameter(AccessCode);
    UnusedParameter(ShareMode);

    return 1; // we can be opened, but only once!
}

//-----------------------------------------------------------------------------
//! \fn			BOOL HcdPdd_Close(DWORD hOpenContext)
//!
//! \brief   		This function is not implemented
//!
//! \param		hOpenContext Handle to the open context of the device.
//!
//! \return		\e TRUE when all is good
//!	\return		\e FALSE when all is bad
//!
//! This function is not implemented
//-----------------------------------------------------------------------------
BOOL HcdPdd_Close(DWORD hOpenContext)
{   
	UnusedParameter(hOpenContext);

    return TRUE;
}

//-----------------------------------------------------------------------------
//! \fn			DWORD HcdPdd_Read(DWORD hOpenContext, LPVOID pBuffer, DWORD Count)
//!
//! \brief		This function reads data from the device identified by the open context.
//!
//! \note     		This function is not implemented
//!
//! \param		hOpenContext	Handle to the open context of the device. The <b>HcdPdd_Open</b> 
//!								(Device Manager) function creates and returns this identifier.  
//! \param		pBuffer			Pointer to the buffer that stores the data read from 
//!								the device. This buffer should be at least <i>Count</i> bytes long. 
//! \param		Count			Number of bytes to read from the device into <i>pBuffer</i>.
//!
//! \return		\e zero to indicate <i>end-of-file</i>. 
//! \return		\e -1 to indicate an error. 
//! \return		The number of bytes read to indicate success.
//!
//! After an application calls the ReadFile function to read from the device, the operating system
//! invokes this function. The <i>hFile</i> parameter is a handle to the device. The <i>pBuffer</i> parameter 
//! points to the buffer that contains the data read from the device. The <i>dwCount</i> parameter indicates 
//! the number of bytes that the application requests to read from the device.
DWORD HcdPdd_Read(DWORD hOpenContext, LPVOID pBuffer, DWORD Count)
{
    UnusedParameter(hOpenContext);
    UnusedParameter(pBuffer);
    UnusedParameter(Count);

    return (DWORD)-1; // an error occured
}

//-----------------------------------------------------------------------------
//! \fn			DWORD HcdPdd_Write(DWORD hOpenContext, LPCVOID pSourceBytes, DWORD NumberOfBytes)
//!
//! \brief		This function writes data to the device.
//!
//! \note     		This function is not implemented
//!
//! \param		hOpenContext	Handle to the open context of the device. The <b>HcdPdd_Open</b> 
//!								(Device Manager) function creates and returns this identifier.  
//! \param		pSourceBytes			Pointer to the buffer that contains the data to write. 
//!								This buffer should be at least <i>NumberOfBytes</i> bytes long. 
//! \param		NumberOfBytes			Number of bytes to write from the <i>pSourceBytes</i> buffer into the device.
//!
//! \return		The number of bytes  written indicates success
//! \return		\e -1 to indicate an error. 
//!
//! After an application uses the WriteFile function to write to the device, the operating system, 
//! invokes this function. The <i>hFile</i> parameter is a handle to the device. The <i>pBuffer</i> parameter 
//! points to the buffer that contains the data read from the device. The <i>dwCount</i> parameter indicates 
//! the number of bytes that the application requests to write to the device.
//-----------------------------------------------------------------------------
DWORD HcdPdd_Write(DWORD hOpenContext, LPCVOID pSourceBytes, DWORD NumberOfBytes)
{
    UnusedParameter(hOpenContext);
    UnusedParameter(pSourceBytes);
    UnusedParameter(NumberOfBytes);

    return (DWORD)-1;
}

//-----------------------------------------------------------------------------
//! \fn			DWORD HcdPdd_Seek(DWORD hOpenContext, LONG Amount, DWORD Type)
//!
//! \brief		This function moves the data pointer in the device.
//!
//! \note     		This function is not implemented
//!
//! \param		hOpenContext	Handle to the open context of the device. The <b>HcdPdd_Open</b> 
//!								(Device Manager) function creates and returns this identifier.  
//! \param		Amount			Number of bytes to move the data pointer in the device. A positive value 
//!								moves the data pointer toward the end of the file and a negative value 
//!								moves it toward the beginning.
//! \param		Type			Starting point for the data pointer. The following table shows the available values for this parameter.
//!
//! \return		The new data pointer for the device indicates success.
//! \return		\e -1 to indicate an error. 
//!
//! After an application calls the SetFilePointer function to move the data pointer in the device, 
//! the operating system invokes this function. If your device is capable of opening more than once, 
//! this function modifies only the data pointer for the instance specified by <i>pOpenContext</i>.
//-----------------------------------------------------------------------------
DWORD HcdPdd_Seek(DWORD hOpenContext, LONG Amount, DWORD Type)
{
    UnusedParameter(hOpenContext);
    UnusedParameter(Amount);
    UnusedParameter(Type);

    return (DWORD)-1;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL HcdPdd_IOControl(DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut)
//!
//! \brief		This function moves the data pointer in the device.
//!
//! \note     		This function is not implemented
//!
//! \param		hOpenContext	Handle to the open context of the device. The <b>HcdPdd_Open</b> 
//!								(Device Manager) function creates and returns this identifier.  
//! \param		dwCode			I/O control operation to perform. These codes are device-specific and 
//!								are usually exposed to developers through a header file. 
//!								Use <b>CTL_CODE</b> macro to generate a driver unique identifier for your iocontrol.
//! \param		pBufIn			Pointer to the buffer containing data to transfer to the device. 
//! \param		dwLenIn			Number of bytes of data in the buffer specified for <i>pBufIn</i>.
//! \param		pBufOut			Pointer to the buffer used to transfer the output data from the device.
//! \param		dwLenOut		Maximum number of bytes in the buffer specified by <i>pBufOut</i>.
//! \param		pdwActualOut	Pointer to the <b>DWORD</b> buffer that this function uses to 
//!								return the actual number of bytes received from the device. 
//!
//! \return		\e TRUE indicates success.
//! \return		\e FALSE indicates failure.
//!
//-----------------------------------------------------------------------------
BOOL HcdPdd_IOControl(DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn,
        DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut)
{
    UnusedParameter(hOpenContext);
    UnusedParameter(dwCode);
    UnusedParameter(pBufIn);
    UnusedParameter(dwLenIn);
    UnusedParameter(pBufOut);
    UnusedParameter(dwLenOut);
    UnusedParameter(pdwActualOut);

    return FALSE;
}

/// This gets called by the MDD's IST when it detects a power resume.
///
/// not implemented
//-----------------------------------------------------------------------------
//! \fn			void HcdPdd_InitiatePowerUp(void)
//!
//! \brief		This function gets called by the MDD's IST when it detects a power resume.
//!
//! \note     		This function is not implemented
//!
//-----------------------------------------------------------------------------
void HcdPdd_InitiatePowerUp(void)
{
    return;
}

//! @}

//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/USBHcd/ohcd.c $
//-----------------------------------------------------------------------------
//
