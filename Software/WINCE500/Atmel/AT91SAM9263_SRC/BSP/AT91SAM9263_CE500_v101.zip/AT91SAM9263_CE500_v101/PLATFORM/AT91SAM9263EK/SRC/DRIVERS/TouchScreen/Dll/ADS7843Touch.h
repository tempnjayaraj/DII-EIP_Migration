//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//! \addtogroup	TOUCHSCREEN
//! @{
//!  
//  All rights reserved ADENEO SAS 2006
//!
//-----------------------------------------------------------------------------
//! \file		ADS7843Touch.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/TouchScreen/Dll/ADS7843Touch.h $
//!   $Author: ltourlonias $
//!   $Revision: 684 $
//!   $Date: 2007-04-13 14:35:48 +0200 (ven., 13 avr. 2007) $
//! \endif
//!
//! \brief Header for ADS7843 TouchScreen driver
//-----------------------------------------------------------------------------

#ifndef __ADS7843TOUCH_H__
#define __ADS7843TOUCH_H__

//--------------------------------------------------------------
// Defines
//--------------------------------------------------------------

// Enable Debug Output
#define ADS7843_DEBUG 0

// Spi Driver
#define SPI_DRIVER_NAME		TEXT("SPI2:")

// Low sampling rate in ms.
#define TOUCHPANEL_SAMPLE_RATE_LOW					30

// High sampling rate in ms.
#define TOUCHPANEL_SAMPLE_RATE_HIGH					10

#endif //#ifndef __ADS7843SPI_H__

//! @}
//! @}

////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/TouchScreen/Dll/ADS7843Touch.h $
////////////////////////////////////////////////////////////////////////////////
//
