//-----------------------------------------------------------------------------
//! \addtogroup   USBHCD
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				AT91RM9200_ohcd.c
//!
//! \brief				Platform independant part of the USB Open Host Controller Driver (OHCD).
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/DRIVERS/USBHCD/AT91RM9200_ohcd.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------
#include <windows.h>
#include <AT91RM9200_oal_intr.h>
#include <ceddk.h>
#include <ohcdddsi.h>
#include <at91rm9200.h>
#include <Devload.h.>


#define TOTAL_AVAILABLE_PHYS_MEM_VALUE_NAME     L"TotalAvailablePhysMem"
#define HIGH_PRIO_PHYS_MEM_VALUE_NAME           L"HighPrioPhysMem"

// Default amount of memory to use for HCD buffer. Can be overriden by settings in the registry
static DWORD gcTotalAvailablePhysicalMemory = 65536; // 64K
static DWORD gcHighPriorityPhysicalMemory = 0x4000; // 16K

typedef struct _SOhcdPdd
{
    LPVOID		lpvMemoryObject;
    LPVOID		lpvOhcdMddObject;
	DWORD		dwSysIntr;
	AT91PS_UHP	v_pUHPRegs;
	AT91PS_PMC	v_pPMC;
	AT91PS_CKGR v_pCKGR;
} SOhcdPdd;

#define UnusedParameter(x)  x = x


/* OhcdPdd_DllMain
 * 
 *  DLL Entry point.
 *
 * Return Value:
 */
extern BOOL HcdPdd_DllMain(HANDLE hinstDLL, DWORD dwReason, LPVOID lpvReserved)
{
    UnusedParameter(hinstDLL);
    UnusedParameter(dwReason);
    UnusedParameter(lpvReserved);

    return TRUE;
}


/* InitializeOHCI
 *
 *  Configure and initialize OHCI card
 *
 * Return Value:
 *  Return TRUE if card could be located and configured, otherwise FALSE
 */
static BOOL 
InitializeOHCI(
    SOhcdPdd * pPddObject,    // IN - Pointer to PDD structure
    LPCWSTR szDriverRegKey)   // IN - Pointer to active registry key string
{    
    LPVOID pobMem = NULL;
	LPVOID pobOhcd = NULL;
	DWORD logintr;
	PHYSICAL_ADDRESS	PA_UHPReg, PA_PMCReg, PA_CKGRReg;


	RETAILMSG(1, (TEXT("++InitializeOHCI\r\n")));

	PA_UHPReg.QuadPart	= (LONGLONG) AT91C_BASE_UHP;
	pPddObject->v_pUHPRegs = (AT91PS_UHP) MmMapIoSpace(PA_UHPReg, sizeof(AT91S_UHP), FALSE);

	PA_PMCReg.QuadPart	= (LONGLONG) AT91C_BASE_PMC;
	pPddObject->v_pPMC = (AT91PS_PMC) MmMapIoSpace(PA_PMCReg, sizeof(AT91S_PMC), FALSE);
	
	PA_CKGRReg.QuadPart	= (LONGLONG) AT91C_BASE_CKGR;
	pPddObject->v_pCKGR = (AT91PS_CKGR) MmMapIoSpace(PA_CKGRReg, sizeof(AT91S_CKGR), FALSE);

    if ((pPddObject->v_pUHPRegs == NULL) || (pPddObject->v_pPMC == NULL) || (pPddObject->v_pCKGR == NULL))
    {        
		goto error;
	}

	// Power-up the USB Host Port
	pPddObject->v_pCKGR->CKGR_PLLBR |= AT91C_CKGR_USB_PLL;		// Disable PLL B automatic power-down 
	Sleep(10);
	pPddObject->v_pPMC->PMC_SCER = AT91C_PMC_UHP;				// Start the clock here
	pPddObject->v_pPMC->PMC_PCER = (1 << AT91C_ID_UHP);			// Start the clock here


	logintr = AT91C_ID_UHP;
	if (!KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &logintr, sizeof(logintr), &pPddObject->dwSysIntr, sizeof(pPddObject->dwSysIntr), NULL))
	{
		RETAILMSG(1, (TEXT("ERROR: Failed to request the serial sysintr for USB Device (logintr :%d).\r\n"),logintr));
		pPddObject->dwSysIntr = SYSINTR_UNDEFINED;
	}       

    // The PDD can supply a buffer of contiguous physical memory here, or can let the 
    // MDD try to allocate the memory from system RAM.  In our case, let the MDD do it.
    pobMem = HcdMdd_CreateMemoryObject(gcTotalAvailablePhysicalMemory,gcHighPriorityPhysicalMemory, NULL,NULL); 
    if(pobMem == NULL)
    {
		RETAILMSG(1,(TEXT("OHCD: Memory Object FAILED\r\n")));
		goto error;
	}

    pobOhcd = HcdMdd_CreateHcdObject(pPddObject, pobMem, szDriverRegKey, (PUCHAR)pPddObject->v_pUHPRegs, pPddObject->dwSysIntr);
	if (pobOhcd == NULL)
	{
		goto error;
	}
    
    pPddObject->lpvMemoryObject = pobMem;
    pPddObject->lpvOhcdMddObject = pobOhcd;

    RETAILMSG(1, (TEXT("--InitializeOHCI\r\n")));
    
    return TRUE;
error:
	if (pobOhcd)
        HcdMdd_DestroyHcdObject(pobOhcd);
    if (pobMem)
        HcdMdd_DestroyMemoryObject(pobMem);
	if (pPddObject->v_pUHPRegs)
		MmUnmapIoSpace(pPddObject->v_pUHPRegs, sizeof(AT91S_UHP));
	if (pPddObject->v_pPMC != NULL)
		MmUnmapIoSpace(pPddObject->v_pPMC, sizeof(AT91S_PMC));
	if (pPddObject->v_pCKGR != NULL)
		MmUnmapIoSpace(pPddObject->v_pCKGR, sizeof(AT91S_CKGR));

	if (pPddObject->dwSysIntr!= SYSINTR_UNDEFINED)
	{
		DWORD dummy;
		KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, (PVOID)&pPddObject->dwSysIntr,sizeof(pPddObject->dwSysIntr), NULL, 0, &dummy);
	}

    pobOhcd = NULL;
    pobMem = NULL;

	RETAILMSG(1, (TEXT("--InitializeOHCI FAILED!!!\r\n")));

	return FALSE;
}

/* OhcdPdd_Init
 *
 *   PDD Entry point - called at system init to detect and configure OHCI card.
 *
 * Return Value:
 *   Return pointer to PDD specific data structure, or NULL if error.
 */
extern DWORD 
HcdPdd_Init(
    DWORD dwContext)  // IN - Pointer to context value. For device.exe, this is a string 
                      //      indicating our active registry key.
{
    SOhcdPdd *  pPddObject = malloc(sizeof(SOhcdPdd));
    BOOL        fRet = FALSE;
    HKEY hKey = NULL;

    RETAILMSG(1, (TEXT("USB:OhcdPdd_Init\r\n"))); 
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, (LPCTSTR )dwContext, 0, 0, &hKey) != ERROR_SUCCESS)

//	the function "OpenDeviceKey" always return hKey=NULL ???
//  hKey = OpenDeviceKey((LPCTSTR )dwContext);
//  if ( !hKey ) 
	{
        RETAILMSG(1,(TEXT("Failed to open device key, Using default buffer sizes\r\n")));                
    }
    else
    {
        DWORD dwType,dwValue,dwSize;
        
        dwSize = sizeof(DWORD);
        if ( RegQueryValueEx(hKey,TOTAL_AVAILABLE_PHYS_MEM_VALUE_NAME, NULL, &dwType,(LPBYTE)&dwValue, &dwSize) ) {
            RETAILMSG(1,(TEXT("Failed to get %s value, Using default 'Total Available Physical Memory' size\r\n")));         
        }
        else
        {
            gcTotalAvailablePhysicalMemory = dwValue;
        }
        
        dwSize = sizeof(DWORD);
        if ( RegQueryValueEx(hKey,HIGH_PRIO_PHYS_MEM_VALUE_NAME, NULL, &dwType,(LPBYTE)&dwValue, &dwSize) ) {
            RETAILMSG(1,(TEXT("Failed to get %s value, Using default 'High Priority Physical Memory' size\r\n")));         
        }
        else
        {
            gcHighPriorityPhysicalMemory = dwValue;
        }
        
        RegCloseKey(hKey);
    }
    
    

    fRet = InitializeOHCI(pPddObject, (LPCWSTR)dwContext);

    if(!fRet)
    {
        free(pPddObject);
        pPddObject = NULL;
    }
    
    return (DWORD)pPddObject;
}

/* OhcdPdd_CheckConfigPower
 *
 *    Check power required by specific device configuration and return whether it
 *    can be supported on this platform.  For CEPC, this is trivial, just limit to
 *    the 500mA requirement of USB.  For battery powered devices, this could be 
 *    more sophisticated, taking into account current battery status or other info.
 *
 * Return Value:
 *    Return TRUE if configuration can be supported, FALSE if not.
 */
extern BOOL HcdPdd_CheckConfigPower(
    UCHAR bPort,         // IN - Port number
    DWORD dwCfgPower,    // IN - Power required by configuration
    DWORD dwTotalPower)  // IN - Total power currently in use on port
{
    return ((dwCfgPower + dwTotalPower) > 500) ? FALSE : TRUE;
}

extern void HcdPdd_PowerUp(DWORD hDeviceContext)
{
    SOhcdPdd * pPddObject = (SOhcdPdd *)hDeviceContext;
    // No need to enable UHP clocks, here it'll be done by HcdMdd_PowerUp which reinitialize the hardware (HcdPdd_Init)
	HcdMdd_PowerUp(pPddObject->lpvOhcdMddObject);

    return;
}

extern void HcdPdd_PowerDown(DWORD hDeviceContext)
{
    SOhcdPdd * pPddObject = (SOhcdPdd *)hDeviceContext;

	HcdMdd_PowerDown(pPddObject->lpvOhcdMddObject);
    return;
}


extern BOOL HcdPdd_Deinit(DWORD hDeviceContext)
{
    SOhcdPdd * pPddObject = (SOhcdPdd *)hDeviceContext;
	
    if(pPddObject->lpvOhcdMddObject)
        HcdMdd_DestroyHcdObject(pPddObject->lpvOhcdMddObject);
    if(pPddObject->lpvMemoryObject)
        HcdMdd_DestroyMemoryObject(pPddObject->lpvMemoryObject);
	if (pPddObject->dwSysIntr!= SYSINTR_UNDEFINED)
	{
		DWORD dummy;
		KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, (PVOID)&pPddObject->dwSysIntr,sizeof(pPddObject->dwSysIntr), NULL, 0, &dummy);
	}

	// Stop UHP clocks 
	pPddObject->v_pPMC->PMC_SCDR = AT91C_PMC_UHP;				// Stop the clock here
	pPddObject->v_pCKGR->CKGR_PLLBR &= ~AT91C_CKGR_USB_PLL;		// Enable PLL B automatic power-down 

    pPddObject->v_pPMC->PMC_PCDR = (1 << AT91C_ID_UHP);		// Start the clock here

	if (pPddObject->v_pUHPRegs)
		MmUnmapIoSpace(pPddObject->v_pUHPRegs, sizeof(AT91S_UHP));
	if (pPddObject->v_pPMC != NULL)
		MmUnmapIoSpace(pPddObject->v_pPMC, sizeof(AT91S_PMC));
	if (pPddObject->v_pCKGR != NULL)
		MmUnmapIoSpace(pPddObject->v_pCKGR, sizeof(AT91S_CKGR));

    return TRUE;
}


extern DWORD HcdPdd_Open(DWORD hDeviceContext, DWORD AccessCode,
        DWORD ShareMode)
{
    UnusedParameter(hDeviceContext);
    UnusedParameter(AccessCode);
    UnusedParameter(ShareMode);

    return 1; // we can be opened, but only once!
}


extern BOOL HcdPdd_Close(DWORD hOpenContext)
{
    UnusedParameter(hOpenContext);

    return TRUE;
}


extern DWORD HcdPdd_Read(DWORD hOpenContext, LPVOID pBuffer, DWORD Count)
{
    UnusedParameter(hOpenContext);
    UnusedParameter(pBuffer);
    UnusedParameter(Count);

    return (DWORD)-1; // an error occured
}


extern DWORD HcdPdd_Write(DWORD hOpenContext, LPCVOID pSourceBytes,
        DWORD NumberOfBytes)
{
    UnusedParameter(hOpenContext);
    UnusedParameter(pSourceBytes);
    UnusedParameter(NumberOfBytes);

    return (DWORD)-1;
}


extern DWORD HcdPdd_Seek(DWORD hOpenContext, LONG Amount, DWORD Type)
{
    UnusedParameter(hOpenContext);
    UnusedParameter(Amount);
    UnusedParameter(Type);

    return (DWORD)-1;
}


extern BOOL HcdPdd_IOControl(DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn,
        DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut)
{
    UnusedParameter(hOpenContext);
    UnusedParameter(dwCode);
    UnusedParameter(pBufIn);
    UnusedParameter(dwLenIn);
    UnusedParameter(pBufOut);
    UnusedParameter(dwLenOut);
    UnusedParameter(pdwActualOut);

    return FALSE;
}


static void OHCI_Reset(void)
{
	// Not yet implemented
}


// This gets called by the MDD's IST when it detects a power resume.
void HcdPdd_InitiatePowerUp(void)
{
    OHCI_Reset();
    return;
}

//! @}
