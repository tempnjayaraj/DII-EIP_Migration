//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//
//  All rights reserved ADENEO SAS 2005
//
//! \file		EmacbNDIS/device.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/EmacbNDIS/device.h $
//!   $Author: pgal $
//!   $Revision: 945 $
//!   $Date: 2007-06-06 09:23:33 +0200 (mer., 06 juin 2007) $
//! \endif
//
//-----------------------------------------------------------------------------
//! \addtogroup EMACNDIS
//! @{

#ifndef	__WINCE_DEVICE_H__
#define	__WINCE_DEVICE_H__

#include	"common.h"
#include	"driver.h"

typedef	enum {
	NIC_HW_OK,
	NIC_HW_TX_IDLE,
	NIC_HW_TX_BUSY,
} NIC_HW_STATUS_TYPE;

#ifdef	IMPL_STATISTICS
#define	REPORT(evt,val)	if((val)) DeviceReportStatistics(evt,val)
#else
#define	REPORT(evt,val)
#endif

#ifdef	IMPL_RESET
#define	CHECK_SHUTDOWN()	if(m_bShutdown) break
#else
#define	CHECK_SHUTDOWN()
#endif


#define MAC_ADDR_SIZE	6

extern "C" void DeviceTimerTrunkRoutine(LPVOID,LPVOID,LPVOID,LPVOID);

/******************************************************************************
 *
 * . about the DeviceOnSetupFilter
 *
 *	Basically, filter modification is one memoryless task. The driver needs not
 *	to remember the last state of filter. It simply sets the filter to meet
 *	the request.
 *	The driver object will call DeviceOnSetupFilter at the late stage of
 *	EDeviceInitialize for filter reset. The device object need call this
 *	function at DeviceReset routine if the reset action will impact the filter.
 *	The driver will later call this routine when NDIS submits set request.
 *
 *	Argument zero means reset the filter, the routine should set the NIC in
 *	unicast mode only and clear the multicast list and counts.
 *
 *****************************************************************************/
class	NIC_DEVICE_OBJECT
{
public:
	NIC_DEVICE_OBJECT(NIC_DRIVER_OBJECT*	pUpper,PVOID)
	{
		m_pUpper = pUpper;
		m_nResetCounts = 0;
		m_nMulticasts = 0;

		memset((void*)&m_szStatistics,0,sizeof(m_szStatistics));
		memset((void*)&m_szLastStatistics,0,sizeof(m_szLastStatistics));
		memset((void*)&m_szConfigures,0xFF,sizeof(m_szConfigures));
		memset((void*)&m_szCurrentSettings,0,sizeof(m_szCurrentSettings));

		memset((void*)&m_InterruptHandle,0,sizeof(m_InterruptHandle));
		memset((void*)&m_timerObject,0,sizeof(m_timerObject));

#ifdef	IMPL_RESET
		m_bShutdown=0;
#endif	
	};

	~NIC_DEVICE_OBJECT()
	{
	};

public:

	void	DeviceReportStatistics(U32,U32);
	U32		DeviceCalculateCRC32(PU8,int,BOOL bReservse=TRUE);

	// device attributes or characteristics
	virtual	U32		DevicePCIID(void)=0;
	virtual	PU8		DeviceMacAddress(PU8);
	virtual	U16		DeviceVendorID(void);
	virtual	U16		DeviceProductID(void);
	virtual	PCONFIG_PARAMETER	DeviceConfigureParameters(void)=0;
	virtual	void	DeviceSetDefaultSettings(void);
	virtual	void	DeviceRegisterAdapter(void);
	virtual	BOOL	DeviceQueryInformation(
		OUT NDIS_STATUS		*Status,
		IN NDIS_OID		Oid,
		IN PVOID		InfoBuffer, 
		IN ULONG		InfoBufferLength, 
		OUT PULONG		BytesWritten,
		OUT PULONG		BytesNeeded){ return FALSE; }
	virtual	BOOL	DeviceSetInformation(
		OUT NDIS_STATUS		*Status,
		IN NDIS_OID		Oid,
		IN PVOID		InfoBuffer, 
		IN ULONG		InfoBufferLength, 
		OUT PULONG		BytesRead,
		OUT PULONG		BytesNeeded){ return FALSE; }
	
	// device control routines
	virtual	void	EDeviceInitialize(int)=0;
	virtual	void	DeviceRetriveConfigurations(NDIS_HANDLE);
	virtual void	EDeviceValidateConfigurations(void)=0;
	virtual	void	EDeviceRegisterInterrupt(void);
	virtual void	DeviceStart(void)=0;
	virtual int		DeviceOnSetupFilter(U32)=0;
	virtual	void	DeviceHalt(void)=0;

	virtual U16		DeviceReadPhy(U32 nPhy,U32 nOff)=0;
	virtual U16		DeviceWritePhy(U32 nPhy,U32 nOff,U16)=0;
	virtual	void	EDeviceLoadRegister(NDIS_HANDLE hconfig);


	virtual int	DeviceSend(PCQUEUE_GEN_HEADER) = 0;
	virtual BOOL	DeviceCheckForHang(void);
	virtual	U32		DeviceHardwareStatus(void) { return NIC_HW_OK; };
	virtual	void	DeviceReset(void)=0;
	virtual	void	DeviceResetPHYceiver(void)=0;

	virtual	void DeviceEnableInterrupt(void)=0;
	virtual BOOL	CheckCable(void)=0;
	virtual	void DeviceDisableInterrupt(void)=0;
	virtual	void DeviceEnableReceive(void)=0;
	virtual	void DeviceDisableReceive(void)=0;
	virtual	void DeviceEnableTransmit(void){};
	virtual	void DeviceDisableTransmit(void){};
	virtual	U32 DeviceGetInterruptStatus(void)=0;
	virtual	U32 DeviceSetInterruptStatus(U32)=0;
	virtual	U32	DeviceGetReceiveStatus(void)=0;
	virtual	void DeviceInterruptEventHandler(U32)=0;

#ifdef	IMPL_HOOK_INDICATION
	virtual void	DeviceIndication(U32)=0;
	virtual	void	DeviceSendCompleted(PCQUEUE_GEN_HEADER, NDIS_STATUS)=0;
	virtual	void	DeviceReceiveIndication(int,PVOID,int)=0;
#else
#define	DeviceIndication(u) m_pUpper->DriverIndication(u)
#define DeviceSendCompleted(p,s) m_pUpper->DriverSendCompleted(p,s)
#define DeviceReceiveIndication(a,b,c) \
		 m_pUpper->DriverReceiveIndication(a,b,c)
#endif


	// Device timer routine
	virtual	void	DeviceOnTimer(void);
	virtual void	DeviceInitializeTimer(void);
	virtual void	DeviceCancelTimer(void);
	virtual void	DeviceSetTimer(U32 milliseconds);

#ifdef	IMPL_DEVICE_ISR
	virtual	void	DeviceIsr(U32)=0;
#endif

	virtual	int	DeviceQueryTxResources(void)=0;
	
public:

	class NIC_DRIVER_OBJECT*	m_pUpper;
	
	BOOL		m_fTxEnabled;


	CQueue	m_TQWaiting;
	
	CMutex	m_mutexRxValidate;
	CMutex	m_mutexTxValidate;

	BOOL	m_Cable;
	
	U32		m_szConfigures[CID_SIZE];
	U32		m_szCurrentSettings[SID_SIZE];
	U32		m_szStatistics[TID_SIZE];
	U32		m_szLastStatistics[TID_SIZE];
	U8		m_szMulticastList[MAX_MULTICAST_LIST][ETH_ADDRESS_LENGTH];
	int		m_nMulticasts;
	int		m_nResetCounts;

#ifdef	IMPL_RESET
	int		m_bShutdown;
#endif
		
	NDIS_MINIPORT_INTERRUPT	m_InterruptHandle;
	

	CMutex	m_mutexTimer;
	NDIS_MINIPORT_TIMER	m_timerObject;


protected:
	U8		m_MacAddr[MAC_ADDR_SIZE];
};

#endif
//! @}

//! @}
