//-----------------------------------------------------------------------------
//! \addtogroup   OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				AT91RM9200_oal_ioctl.h
//!
//! \brief				Custom kernel IOCTLs declaration file
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/INC/IOCTL/AT91RM9200_oal_ioctl.h $
//!   $Author: glemercier $
//!   $Revision: 628 $
//!   $Date: 2007-04-03 07:26:37 -0700 (Tue, 03 Apr 2007) $
//! \endif
//!
//-----------------------------------------------------------------------------
#ifndef __AT91RM9200_OALIOCTL_H__
#define __AT91RM9200_OALIOCTL_H__

#define SOFT_REBOOT_MAGIC 0xA5CAFE5A

#define COLD_BOOT	1
#define WARM_BOOT	2
#define SOFT_BOOT	3

#define HAL_SHUTDOWN_CMD		1
#define HAL_MASTERCLOCK_CMD		2
#define HAL_PLLACLOCK_CMD		3
#define HAL_PLLBCLOCK_CMD		4
#define HAL_PROCESSORCLOCK_CMD	5
#define HAL_KITLARGS_CMD		6
#define HAL_MAX_CMD				7

#define IOCTL_HAL_SHUTDOWN			CTL_CODE(FILE_DEVICE_HAL, IOCTL_KLIB_USER + HAL_SHUTDOWN_CMD,		METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_HAL_MASTERCLOCK		CTL_CODE(FILE_DEVICE_HAL, IOCTL_KLIB_USER + HAL_MASTERCLOCK_CMD,	METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_HAL_PLLACLOCK			CTL_CODE(FILE_DEVICE_HAL, IOCTL_KLIB_USER + HAL_PLLACLOCK_CMD,		METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_HAL_PLLBCLOCK			CTL_CODE(FILE_DEVICE_HAL, IOCTL_KLIB_USER + HAL_PLLBCLOCK_CMD,		METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_HAL_PROCESSORCLOCK	CTL_CODE(FILE_DEVICE_HAL, IOCTL_KLIB_USER + HAL_PROCESSORCLOCK_CMD, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_HAL_GET_KITL_ARGS		CTL_CODE(FILE_DEVICE_HAL, IOCTL_KLIB_USER + HAL_KITLARGS_CMD, METHOD_BUFFERED, FILE_ANY_ACCESS)


BOOL OALIoCtlHalShutdown(UINT32 code, VOID *pInpBuffer, 
                       UINT32 inpSize, VOID *pOutBuffer, 
                       UINT32 outSize, UINT32 *pOutSize);

BOOL OALIoCtlHalGetMasterClock(	UINT32 code, VOID *pInpBuffer, 
								UINT32 inpSize, VOID *pOutBuffer, 
								UINT32 outSize, UINT32 *pOutSize);

BOOL OALIoCtlHalGetPLLAClock(	UINT32 code, VOID *pInpBuffer, 
								UINT32 inpSize, VOID *pOutBuffer, 
								UINT32 outSize, UINT32 *pOutSize);

BOOL OALIoCtlHalGetPLLBClock(	UINT32 code, VOID *pInpBuffer, 
								UINT32 inpSize, VOID *pOutBuffer, 
								UINT32 outSize, UINT32 *pOutSize);

BOOL OALIoCtlHalGetProcessorClock(	UINT32 code, VOID *pInpBuffer, 
								UINT32 inpSize, VOID *pOutBuffer, 
								UINT32 outSize, UINT32 *pOutSize);


extern BOOL (*g_pfnBSPIoCtlHalShutdown)(UINT32 code, VOID *pInpBuffer,		
									UINT32 inpSize, VOID *pOutBuffer,
									UINT32 outSize, UINT32 *pOutSize);

#endif //__AT91RM9200_OALIOCTL_H__

//! @}

