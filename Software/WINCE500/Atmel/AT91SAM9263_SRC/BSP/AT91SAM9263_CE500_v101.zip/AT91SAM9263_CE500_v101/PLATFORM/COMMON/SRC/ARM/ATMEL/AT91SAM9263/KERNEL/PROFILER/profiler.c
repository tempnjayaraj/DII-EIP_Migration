//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9263/KERNEL/PROFILER/profiler.c
//!
//! \brief		Profiler's option for the AT91SAM9263
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/KERNEL/PROFILER/profiler.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//-----------------------------------------------------------------------------
#include <windows.h>
#include <oal.h>
#include "AT91SAM926x.h"
#include "AT91SAM926x_oal_profiler.h"


#ifndef OAL_PROFILER_TIMER_NUMBER
/// This defines the TimerCounter controller that's going to be used for the profiler
///
/// \note Do not change the default Timer Counter value in the code.
/// If you want to select another timer counter for profiling then set the environment variable
/// OAL_PROFILER_TIMER_NUMBER to the correct value
#define OAL_PROFILER_TIMER_NUMBER	0
#endif


/// This gives information to the generic profiler engine about the Timer Counter that will be used
const T_PROFILER_TIMER_DESCRIPTION ProfilerDesc = {
#if   (OAL_PROFILER_TIMER_NUMBER == 0)
AT91C_ID_TC012, AT91C_BASE_TC0
#elif (OAL_PROFILER_TIMER_NUMBER == 1)
AT91C_ID_TC012, AT91C_BASE_TC1
#elif (OAL_PROFILER_TIMER_NUMBER == 2)
AT91C_ID_TC012, AT91C_BASE_TC2
#else
#error Invalid timer number
#endif 
};

const T_PROFILER_TIMER_DESCRIPTION *pProfilerDesc =  &ProfilerDesc;

//------------------------------------------------------------------------------

//! @}

////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/KERNEL/PROFILER/profiler.c $
////////////////////////////////////////////////////////////////////////////////
//
