//-----------------------------------------------------------------------------
//! \addtogroup	HMATRIX
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9263EK_HMATRIX.h
//!
//! \brief		AT91SAM9263EK HMATRIX CONFIGURATION
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9623EK/SRC/INC/AT91SAM9263EK_HMATRIX.h $
//!   $Author: jjhiblot $
//!   $Revision: 104 $
//!   $Date: 2006-02-15 14:25:52 +0100 (mer., 15 f�vr. 2006) $
//! \endif
//-----------------------------------------------------------------------------

#ifndef AT91SAM9263EK_HMATRIX_H
#define AT91SAM9263EK_HMATRIX_H

T_SLAVE_CONFIG g_MatrixSlaveConfig[AT91SAM9263_NB_SLAVES] =
{
	//Slave 0 Internal ROM
	{RoundRobin,	LastMaster,	0, 16, {0,0,0,0,0,0,0,0,0}},
	//Slave 1 Internal 80 Kbyte SRAM
	{RoundRobin,	LastMaster,	1, 16, {0,0,0,0,0,0,0,0,0}},
	//Slave 2 Internal 16 Kbyte SRAM
	{RoundRobin,	NoDefaultMaster,	0, 16, {0,0,0,0,0,0,0,0,0}},
	//Slave 3 LCD Controller User Interface / DMA Controller User Interface / USB Host User Interface
	{RoundRobin,	NoDefaultMaster,	0, 16, {0,0,0,0,0,0,0,0,0}},
	//Slave 4 External Bus Interface 0
	{Priority,		NoDefaultMaster,	0, 16, {0,0,0,0,3,3,0,0,0}},
	//Slave 5 External Bus Interface 1
	{RoundRobin,	NoDefaultMaster,	0, 16, {0,0,0,0,0,0,0,0,0}},
	//Slave 6 Peripheral Bridge
	{RoundRobin,	NoDefaultMaster,	0, 16, {0,0,0,0,0,0,0,0,0}},
	//Slave 7 Peripheral Bridge
	{RoundRobin,	NoDefaultMaster,	0, 16, {0,0,0,0,0,0,0,0,0}},
};

DWORD g_MatrixMasterConfig[AT91SAM9263_NB_MASTER] = {
	UNDEFINED_BURST_LENGTH_NOT_SPLIT,	//Master 0 => OHCI USB Host Controller
	UNDEFINED_BURST_LENGTH_NOT_SPLIT,	//Master 1 => Image Sensor Interface
	UNDEFINED_BURST_LENGTH_NOT_SPLIT,	//Master 2 => 2D Graphic Controller
	UNDEFINED_BURST_LENGTH_NOT_SPLIT,	//Master 3 => DMA Controller
	UNDEFINED_BURST_LENGTH_NOT_SPLIT,	//Master 4 => Ethernet MAC
	UNDEFINED_BURST_LENGTH_NOT_SPLIT,	//Master 5 => LCD Controller
	UNDEFINED_BURST_LENGTH_NOT_SPLIT,	//Master 6 => Peripheral DMA Controller
	UNDEFINED_BURST_LENGTH_NOT_SPLIT,	//Master 7 => ARM926 Data
	UNDEFINED_BURST_LENGTH_NOT_SPLIT,	//Master 8 => ARM926 Instruction
};

#endif // AT91SAM9263EK_HMATRIX_H



//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9623EK/SRC/INC/AT91SAM9263EK_HMATRIX.h $
//-----------------------------------------------------------------------------
//