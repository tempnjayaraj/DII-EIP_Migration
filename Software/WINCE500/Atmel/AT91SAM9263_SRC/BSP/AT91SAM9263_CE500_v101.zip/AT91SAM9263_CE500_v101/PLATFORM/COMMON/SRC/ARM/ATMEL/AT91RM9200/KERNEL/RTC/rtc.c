//-----------------------------------------------------------------------------
//! \addtogroup   OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file			rtc.c
//!
//! \brief			RTC management implementation (OEMSetAlarmTime is not implemented yet)
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/KERNEL/RTC/rtc.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

#include <windows.h>
#include <oal.h>
#include <nkintr.h>

#ifdef RTC_IS_BASED_ON_AT91C_RTC

#define BCD2BIN(val) (((val)&15) + ((val)>>4)*10)
#define BIN2BCD(val) ((((val)/10)<<4) + (val)%10)

// CS to make OEMSetRealTime/OEMGetRealTime reentrant
extern CRITICAL_SECTION csSetRTC;

#include "AT91RM9200.h"

static DWORD AT91GetMSec(AT91PS_SYS pSys)
{
	// Returning counter value from RTC in timer
	// Msec with an error of 2.4%
	// 1 inc of CRTR = RTMR tick at SLOW_CLOCK_FREQUENCY Hz
	// => 1 inc = (RTMR / SLOW_CLOCK_FREQUENCY) s => 
	// for RTMR max is 0 => 0x10000
	volatile DWORD crtr=pSys->ST_CRTR;
	LONGLONG llMsec;
	while( crtr!=pSys->ST_CRTR)
	{
		crtr=pSys->ST_CRTR;
	}
	// Use 64bits, because during computing value can reach near 46bit (rtmr:16bits*
	// crtr:20bits*1000:10bits), but result can't be greater than 30bits.
	llMsec = ((LONGLONG)(pSys->ST_RTMR ? pSys->ST_RTMR : 0x10000)* (LONGLONG)crtr * (LONGLONG)1000) / SLOW_CLOCK_FREQUENCY;
	return((DWORD)llMsec);
}

static void AT91WaitMsec(AT91PS_SYS pSys,DWORD dwMSec)
{
	DWORD dwCurrMSec, dwStartMsec = AT91GetMSec(pSys);

	do 
	{
		dwCurrMSec = AT91GetMSec(pSys);
		if (dwCurrMSec < dwStartMsec ) // We reach max and then return to 0
		{
			dwStartMsec -= 0xFFFFF;		// STRTC 20 bits length
		}
	} while ( dwCurrMSec - dwStartMsec < dwMSec );
}


//-----------------------------------------------------------------------------
//! \fn		BOOL OALIoCtlHalInitRTC(UINT32 code, void* pInpBuffer, UINT32 inpSize,
//!			 void* pOutBuffer, UINT32 outSize, UINT32* pOutSize)
//!
//! \brief		This function implements the IOCTL_HAL_INITRTC IOControl
//!				This function is called by WinCE OS to initialize the time after boot.
//!				Input buffer contains SYSTEMTIME structure with default time value.
//!				If hardware has persistent real time clock it will ignore this value
//!				(or all call).
//!
//!	\param		code		not used
//!	\param		pInpBuffer	Initial time
//!	\param		inpSize		sizeof(SYSTEMTIME)
//!	\param		pOutBuffer	not used
//!	\param		outSize		not used
//!	\param		pOutSize	not used
//!
//! \return		TRUE indicates success
//! \return		FALSE indicates failure (bad parameters)
//! 
//-----------------------------------------------------------------------------
BOOL OALIoCtlHalInitRTC(UINT32 code, void* pInpBuffer, UINT32 inpSize, void* pOutBuffer, UINT32 outSize, UINT32* pOutSize)
{
	BOOL rc = FALSE;

    OALMSG(OAL_IOCTL&&OAL_FUNC, (L"+OALIoCtlHalInitRTC(...)\r\n"));


	if (!pInpBuffer || !pOutSize || (inpSize < sizeof(SYSTEMTIME)))
	{
		return(FALSE);
	}

	if (OEMSetRealTime((LPSYSTEMTIME)pInpBuffer))
	{
		*pOutSize = sizeof(SYSTEMTIME);
	}

    OALMSG(OAL_IOCTL&&OAL_FUNC, (L"-OALIoCtlHalInitRTC(rc = %d)\r\n", rc));
    return rc;
}

//-----------------------------------------------------------------------------
//! \fn BOOL OEMGetRealTime(SYSTEMTIME *pTime)
//!
//!	\brief This function is called by the kernel to retrieve the time from the real-time clock.
//!
//!	\param pTime Pointer to return current time from the real-time clock
//!
//!	\return True if success, FALSE if not
//! 
//-----------------------------------------------------------------------------
BOOL OEMGetRealTime(SYSTEMTIME *pTime)
{
    BOOL		rc = TRUE;
    UINT		date,time;
    AT91PS_RTC	pRTC = (AT91PS_RTC) OALPAtoVA((DWORD)AT91C_BASE_RTC,FALSE);


    OALMSG(OAL_RTC&&OAL_FUNC, (L"+OEMGetRealTime\r\n"));

	EnterCriticalSection(&csSetRTC);	//be sure RTC read is atomic

	do 
	{// must read twice in case it changes 
		time = pRTC->RTC_TIMR;
		date = pRTC->RTC_CALR;
	} while ((time != pRTC->RTC_TIMR) || (date != pRTC->RTC_CALR));

	LeaveCriticalSection(&csSetRTC);	//be sure RTC read is atomic

	pTime->wMilliseconds = 0; //No ms in AT91 RTC 

	pTime->wSecond = BCD2BIN((time & AT91C_RTC_SEC) >> 0);
	pTime->wMinute = BCD2BIN((time & AT91C_RTC_MIN) >> 8);
	pTime->wHour = BCD2BIN((time & AT91C_RTC_HOUR) >> 16);

	// The Calendar Alarm register does not have a field for
	// the year - so these will return an invalid value.  When an
	// alarm is set, at91_alarm_year will store the current year.
	pTime->wYear = BCD2BIN(date & AT91C_RTC_CENT) * 100;		// century
	pTime->wYear += BCD2BIN((date & AT91C_RTC_YEAR) >> 8);		// year
	pTime->wDayOfWeek = BCD2BIN((date & AT91C_RTC_DAY) >> 21) - 1;	// day of the week [0-6], Sunday=0
	pTime->wMonth = BCD2BIN(((date & AT91C_RTC_MONTH) >> 16));
	pTime->wDay  = BCD2BIN((date & AT91C_RTC_DATE) >> 24);

    OALMSG(OAL_RTC&&OAL_FUNC, (
        L"-OEMGetRealTime(rc = %d %d/%d/%d %d:%d:%d.%03d)\r\n", rc, 
        pTime->wYear, pTime->wMonth, pTime->wDay, pTime->wHour, pTime->wMinute,
        pTime->wSecond, pTime->wMilliseconds
    ));
    return rc;
}

//-----------------------------------------------------------------------------
//! \fn BOOL BOOL OEMSetRealTime(SYSTEMTIME *pTime)
//!
//!	\brief This function is called by the kernel to set the real-time clock.
//!
//!	\param pTime Pointer to time to set in the real-time clock
//!
//!	\return True if success, FALSE if not
//! 
//-----------------------------------------------------------------------------
BOOL OEMSetRealTime(SYSTEMTIME *pTime)
{
#define WAIT_LOOP 200

    BOOL		rc = FALSE;
	int			i=0;
    AT91PS_RTC	pRTC = (AT91PS_RTC) OALPAtoVA((DWORD)AT91C_BASE_RTC,FALSE);
	AT91PS_SYS	pSys = (AT91PS_SYS) OALPAtoVA((DWORD)AT91C_BASE_SYS,FALSE);

    OALMSG(OAL_RTC&&OAL_FUNC, (
        L"+OEMSetRealTime(%d/%d/%d %d:%d:%d.%03d)\r\n", 
        pTime->wYear, pTime->wMonth, pTime->wDay, pTime->wHour, pTime->wMinute,
        pTime->wSecond, pTime->wMilliseconds
    ));

	// Stop Time/Calendar from counting
	pRTC->RTC_CR |= (AT91C_RTC_UPDCAL | AT91C_RTC_UPDTIM);

	while ( !(pRTC->RTC_SR & AT91C_RTC_ACKUPD) && (i < WAIT_LOOP) ) //2s time-out
	{
		AT91WaitMsec(pSys,10);
		i++;
	}

	if ( (i<WAIT_LOOP) && (pTime->wSecond < 60) && (pTime->wMinute < 60) 
		&& 	(pTime->wHour < 24) && (pTime->wYear < 2100) && (pTime->wYear > 1900 ) 
		&& (pTime->wMonth <= 12) && (pTime->wDay <= 31) ) 
	{	//RTC is ready to be updated, and value are correct

		EnterCriticalSection(&csSetRTC);	//be sure RTC update is atomic

		pRTC->RTC_TIMR = BIN2BCD(pTime->wSecond) << 0
				| BIN2BCD(pTime->wMinute) << 8
				| BIN2BCD(pTime->wHour) << 16;

		pRTC->RTC_CALR = BIN2BCD(pTime->wYear / 100)		// century
	    			| BIN2BCD(pTime->wYear % 100) << 8		// year
	    			| BIN2BCD(pTime->wMonth ) << 16	
	    			| BIN2BCD(pTime->wDayOfWeek + 1) << 21	// day of the week [0-6], Sunday=0 
					| BIN2BCD(pTime->wDay) << 24;
					

		// Restart Time/Calendar 
		pRTC->RTC_CR &= ~(AT91C_RTC_UPDCAL | AT91C_RTC_UPDTIM);

		// Reset update flag
		pRTC->RTC_SCCR |= AT91C_RTC_ACKUPD;

		LeaveCriticalSection(&csSetRTC);	//be sure RTC update is atomic

		// It should be possible to test if value are correct with RTC_VER register
		// but shall we wait before test?
		rc = TRUE;
	}

    OALMSG(OAL_RTC&&OAL_FUNC, (L"-OEMSetRealTime(rc = %d)\r\n", rc));
    return rc;
}

//-----------------------------------------------------------------------------
//! \fn BOOL OEMSetAlarmTime(SYSTEMTIME *pTime)
//!
//!	\brief This function is called by the kernel to set the real-time clock alarm.
//!
//!	\param pTime Pointer to alarm time
//!
//!	\return True if success, FALSE if not
//! 
//-----------------------------------------------------------------------------
BOOL OEMSetAlarmTime(SYSTEMTIME *pTime)
{
    BOOL		rc = FALSE;
	SYSTEMTIME	sCurrent_time;
	FILETIME	fCurrent_time, fAlarm;
    AT91PS_RTC	pRTC = (AT91PS_RTC) OALPAtoVA((DWORD)AT91C_BASE_RTC,FALSE);

    OALMSG(OAL_RTC&&OAL_FUNC, (
        L"+OEMSetAlarmTime(%d/%d/%d %d:%d:%d.%03d)\r\n", 
        pTime->wYear, pTime->wMonth, pTime->wDay, pTime->wHour, pTime->wMinute,
        pTime->wSecond, pTime->wMilliseconds
    ));


	if ((pTime->wSecond < 60) && (pTime->wMinute < 60) && (pTime->wHour < 24)
		 && (pTime->wYear < 2100) && (pTime->wYear > 1900 ) 
		&& (pTime->wMonth <= 12) && (pTime->wDay <= 31) ) 
	{ //Value are correct
	
		// get the current time and convert to filetime to compare it
		if (OEMGetRealTime(&sCurrent_time) && (KSystemTimeToFileTime(pTime,&fAlarm))
			&& (KSystemTimeToFileTime(&sCurrent_time,&fCurrent_time)) ) 
		{
			
			// make sure the alarm occurs in the future
			if ( KCompareFileTime(&fAlarm,&fCurrent_time) <= 0 ) 
			{
				RETAILMSG(0, (TEXT("OEMSetAlarmTime: alarm %d:%d:%d %d/%d/%d occurs before %d:%d:%d %d/%d/%d \r\n"),
					pTime->wHour,pTime->wMinute,pTime->wSecond,pTime->wDay,pTime->wMonth,pTime->wYear,
					sCurrent_time.wHour,sCurrent_time.wMinute,sCurrent_time.wSecond,
					sCurrent_time.wDay,sCurrent_time.wMonth,sCurrent_time.wYear));
			} 
			else 
			{ //OK we can set alarm now
				pRTC->RTC_TIMALR = BIN2BCD(pTime->wSecond) << 0
						| BIN2BCD(pTime->wMinute) << 8
						| BIN2BCD(pTime->wHour) << 16
						| AT91C_RTC_HOUREN | AT91C_RTC_MINEN
						| AT91C_RTC_SECEN;

				pRTC->RTC_CALR = BIN2BCD(pTime->wMonth ) << 16	
							| BIN2BCD(pTime->wDay) << 24
							| AT91C_RTC_DATEEN | AT91C_RTC_MONTHEN;
				pRTC->RTC_IER = AT91C_RTC_ALARM;
				rc = TRUE;
			}
		}
	}

    OALMSG(OAL_RTC&&OAL_FUNC, (L"-OEMSetAlarmTime(rc = %d)\r\n", rc));
	
	return rc;
}

//! @}
#else // RTC_IS_BASED_ON_AT91C_RTC

//------------------------------------------------------------------------------
//
//  Global: g_oalRTCTicks/g_pOALRTCTicks
//
//  This variable in increment by one in timer interrupt handler. It contains
//  relative time in miliseconds since January 1, 1601.
//
UINT64 g_oalRTCTicks = 12685896000000;

//------------------------------------------------------------------------------
//
//  Global: g_oalRTCAlarm
//
//  This variable contains number of miliseconds till next SYSINTR_ALARM. It
//  is zero when alarm isn't active.
//
UINT64 g_oalRTCAlarm = 0;



//-----------------------------------------------------------------------------
//! \fn void UpdateTimer()
//!
//!	\brief This function update actual time 
//!			Update timer using SC_GetTickCount
//!			Each time you can try to call this function
//! 
//-----------------------------------------------------------------------------
void UpdateTimer()
{
	BOOL	enabled = FALSE;
	static	DWORD dwOldTime = 0;
	static	DWORD dwActualTime = 0;
	int		i=0;

	if (dwOldTime==0 && dwActualTime==0)
	{
		dwOldTime = CurMSec;
		for (;i<100000;i++);
	}

//	DEBUGMSG( 1,(TEXT("UpdateTimer, seconds from start:%d\n\r"), CurMSec/1000));

	dwActualTime = CurMSec;

    enabled = INTERRUPTS_ENABLE(FALSE);
	g_oalRTCTicks += dwActualTime - dwOldTime;
    INTERRUPTS_ENABLE(enabled);

	dwOldTime = dwActualTime;
}

//-----------------------------------------------------------------------------
//! \fn		BOOL OALIoCtlHalInitRTC(UINT32 code, void* pInpBuffer, UINT32 inpSize,
//!			 void* pOutBuffer, UINT32 outSize, UINT32* pOutSize)
//!
//! \brief		This function implements the IOCTL_HAL_INITRTC IOControl
//!				This function is called by WinCE OS to initialize the time after boot.
//!				Input buffer contains SYSTEMTIME structure with default time value.
//!				If hardware has persistent real time clock it will ignore this value
//!				(or all call).
//!
//!	\param		code		not used
//!	\param		pInpBuffer	Initial time
//!	\param		inpSize		sizeof(SYSTEMTIME)
//!	\param		pOutBuffer	not used
//!	\param		outSize		not used
//!	\param		pOutSize	not used
//!
//! \return		TRUE indicates success
//! \return		FALSE indicates failure (bad parameters)
//! 
//-----------------------------------------------------------------------------
BOOL OALIoCtlHalInitRTC(UINT32 code, void* pInpBuffer, UINT32 inpSize, void* pOutBuffer, UINT32 outSize, UINT32* pOutSize)
{
    BOOL rc = FALSE;
    SYSTEMTIME *pTime = (SYSTEMTIME*)pInpBuffer;

	RETAILMSG(1, (L"+OALIoCtlHalInitRTC(...)\r\n"));
    OALMSG(OAL_IOCTL&&OAL_FUNC, (L"+OALIoCtlHalInitRTC(...)\r\n"));

	// Update timer value
	UpdateTimer();

    // Validate inputs
    if (pInpBuffer == NULL || inpSize < sizeof(SYSTEMTIME)) {
        NKSetLastError(ERROR_INVALID_PARAMETER);
        OALMSG(OAL_ERROR, (
            L"ERROR: OALIoCtlHalInitRTC: Invalid parameter\r\n"
        ));
        
    }
	else
	{
		rc = OEMSetRealTime(pTime);
	}   
    OALMSG(OAL_IOCTL&&OAL_FUNC, (L"-OALIoCtlHalInitRTC(rc = %d)\r\n", rc));
    return rc;
}

//-----------------------------------------------------------------------------
//! \fn BOOL OEMGetRealTime(SYSTEMTIME *pTime)
//!
//!	\brief This function is called by the kernel to retrieve the time from the real-time clock.
//!
//!	\param pTime Pointer to return current time from the real-time clock
//!
//!	\return True if success, FALSE if not
//! 
//-----------------------------------------------------------------------------
BOOL OEMGetRealTime(SYSTEMTIME *pTime)
{
    BOOL rc;
    ULARGE_INTEGER time;
    FILETIME fileTime;
    UINT64 ticks;
    BOOL enabled;

    OALMSG(OAL_RTC&&OAL_FUNC, (L"+OEMGetRealTime\r\n"));

	UpdateTimer();

    enabled = INTERRUPTS_ENABLE(FALSE);
	ticks = g_oalRTCTicks;
    INTERRUPTS_ENABLE(enabled);

    // Convert time to appropriate format
    time.QuadPart = ticks * 10000;

    fileTime.dwLowDateTime = time.LowPart;
    fileTime.dwHighDateTime = time.HighPart;

    rc = KFileTimeToSystemTime(&fileTime, pTime);

    OALMSG(OAL_RTC&&OAL_FUNC, (
        L"-OEMGetRealTime(rc = %d %d/%d/%d %d:%d:%d.%03d)\r\n", rc, 
        pTime->wYear, pTime->wMonth, pTime->wDay, pTime->wHour, pTime->wMinute,
        pTime->wSecond, pTime->wMilliseconds
    ));
    return rc;
}


//-----------------------------------------------------------------------------
//! \fn BOOL BOOL OEMSetRealTime(SYSTEMTIME *pTime)
//!
//!	\brief This function is called by the kernel to set the real-time clock.
//!
//!	\param pTime Pointer to time to set in the real-time clock
//!
//!	\return True if success, FALSE if not
//! 
//-----------------------------------------------------------------------------
BOOL OEMSetRealTime(SYSTEMTIME *pTime)
{
    BOOL rc = FALSE;
    ULARGE_INTEGER time;
    FILETIME fileTime;
    BOOL enabled;

	DEBUGMSG(1, (_T("OEMSetRealTime-------------------\r\n")));

    OALMSG(OAL_RTC&&OAL_FUNC, (
        L"+OEMSetRealTime(%d/%d/%d %d:%d:%d.%03d)\r\n", 
        pTime->wYear, pTime->wMonth, pTime->wDay, pTime->wHour, pTime->wMinute,
        pTime->wSecond, pTime->wMilliseconds
    ));

	UpdateTimer();

    if (KSystemTimeToFileTime(pTime, &fileTime))
	{
		// Convert time to miliseconds since Jan 1, 1601
		time.LowPart = fileTime.dwLowDateTime;
		time.HighPart = fileTime.dwHighDateTime;
		time.QuadPart /= 10000;

		enabled = INTERRUPTS_ENABLE(FALSE);

		g_oalRTCTicks = time.QuadPart;

		INTERRUPTS_ENABLE(enabled);

		rc = TRUE;
    
	}
    OALMSG(OAL_RTC&&OAL_FUNC, (L"-OEMSetRealTime(rc = %d)\r\n", rc));
    return rc;
}

//-----------------------------------------------------------------------------
//! \fn BOOL OEMSetAlarmTime(SYSTEMTIME *pTime)
//!
//!	\brief This function is called by the kernel to set the real-time clock alarm.
//!
//!	\param pTime Pointer to alarm time
//!
//!	\return True if success, FALSE if not
//! 
//-----------------------------------------------------------------------------
BOOL OEMSetAlarmTime(SYSTEMTIME *pTime)
{
    BOOL rc = FALSE;
    ULARGE_INTEGER time;
    FILETIME fileTime;
    BOOL enabled;

	DEBUGMSG(1, (_T("OEMSetAlarmTime-------------------\r\n")));

    OALMSG(OAL_RTC&&OAL_FUNC, (
        L"+OEMSetAlarmTime(%d/%d/%d %d:%d:%d.%03d)\r\n", 
        pTime->wYear, pTime->wMonth, pTime->wDay, pTime->wHour, pTime->wMinute,
        pTime->wSecond, pTime->wMilliseconds
    ));

	UpdateTimer();

    // Convert time to miliseconds since Jan 1, 1601
    if (KSystemTimeToFileTime(pTime, &fileTime))
	{
		time.LowPart = fileTime.dwLowDateTime;
		time.HighPart = fileTime.dwHighDateTime;
		time.QuadPart /= 10000;

		enabled = INTERRUPTS_ENABLE(FALSE);
		g_oalRTCAlarm = time.QuadPart - g_oalRTCTicks;
		INTERRUPTS_ENABLE(enabled);

		// We are done
		rc = TRUE;
	}
      
    OALMSG(OAL_RTC&&OAL_FUNC, (L"-OEMSetAlarmTime(rc = %d)\r\n", rc));
    return rc;
}
#endif //RTC_IS_BASED_ON_AT91C_RTC

//! @}
