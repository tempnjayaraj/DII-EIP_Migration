//-----------------------------------------------------------------------------
//! \addtogroup	DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM9263/BOOTLOADER/NandFlashEBOOT/NandFlash.c
//!
//! \brief		NandFlash driver for AT91SAM926x chipset
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/BOOTLOADER/NandFlashEBOOT/NandFlash.c $
//!   $Author: ltourlonias $
//!   $Revision: 657 $
//!   $Date: 2007-04-10 16:52:09 +0200 (mar., 10 avr. 2007) $
//! \endif
//!
//! 
//-----------------------------------------------------------------------------
//! \addtogroup	NandFlash
//! @{
//!

// System specific include
#include <windows.h>
#include <nkintr.h>
#include <oal.h>
#include <fmd.h>

// Platform specific include
#include "at91sam926x_oal_ioctl.h"
#include "at91sam926x.h"
#include "at91sam926x_interface.h"

#include "NandFlash.h"

static volatile	AT91PS_MATRIX	pMatrix			; //!< Matrix register
static volatile	AT91PS_SMC		pSMC			; //!< SMC register
static volatile	AT91PS_PMC		pPMC			; //!< PMC Register

void NandFlashProc_RegistersInit(NandChip * pChip)
{
	pMatrix		= (AT91PS_MATRIX) 	OALPAtoVA((DWORD) AT91C_BASE_MATRIX, FALSE);
	pSMC		= (AT91PS_SMC) 		OALPAtoVA((DWORD) AT91C_BASE_SMC0, FALSE);
	pPMC		= (AT91PS_PMC) 		OALPAtoVA((DWORD) AT91C_BASE_PMC, FALSE);	
}

void NandFlashProc_RegistersRelease(NandChip * pChip)
{
	pMatrix = NULL;
	pSMC = NULL;
	pPMC = NULL;
}

void NandFlashProc_ChipSelect(NandChip * pChip, DWORD dwBW)
{
	// Enable the address range of CS3
	pMatrix->MATRIX_EBI0 |= AT91C_MATRIX_CS3A_SM;

	// Configure SMC CS3
	AT91SAM926x_SetChipSelectTimingIn_ns(	pSMC					,  // SMC register
											AT91C_NAND_CHIPSELECT		,  // Chip Select
											pChip->dwMasterClock		,  // Master Clock value
											AT91C_NAND_NWE_SETUP		,  // NWE_SETUP
											AT91C_NAND_NCS_WR_SETUP		,  // NCS_WR_SETUP
											AT91C_NAND_NRD_SETUP		,  // NRD_SETUP
											AT91C_NAND_NCS_RD_SETUP		,  // NCS_RD_SETUP
											AT91C_NAND_NWE_PULSE		,  // NWE_PULSE		
											AT91C_NAND_NCS_WR_PULSE		,  // NCS_WR_PULSE
											AT91C_NAND_NRD_PULSE		,  // NRD_PULSE
											AT91C_NAND_NCS_RD_PULSE		,  // NCS_RD_PULSE
											AT91C_NAND_NRD_CYCLE		,  // NRD_CYCLE
											AT91C_NAND_NWE_CYCLE		); // NWE_CYCLE

	pSMC->SMC_CTRL3 = (AT91C_SMC_READMODE | AT91C_SMC_WRITEMODE | AT91C_SMC_NWAITM_NWAIT_DISABLE | AT91C_NAND_TDF | AT91C_SMC_TDFEN);
	
	pSMC->SMC_CTRL3 |= (dwBW == 16) ? AT91C_SMC_DBW_WIDTH_SIXTEEN_BITS : AT91C_SMC_DBW_WIDTH_EIGTH_BITS;

	// Enable the clock 
	pPMC->PMC_PCER = 1<<AT91C_ID_PIOA;
    pPMC->PMC_PCER = 1<<AT91C_ID_PIOCDE;
}

void NandFlashProc_BusWidth16(NandChip *pChip)
{
	pSMC->SMC_CTRL3 &=~AT91C_SMC_DBW_WIDTH_EIGTH_BITS;
	pSMC->SMC_CTRL3 |= AT91C_SMC_DBW_WIDTH_SIXTEEN_BITS;
}

// End of Doxygen group NandFlash Driver
//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/BOOTLOADER/NandFlashEBOOT/NandFlash.c $
//-----------------------------------------------------------------------------
//
//! @}
