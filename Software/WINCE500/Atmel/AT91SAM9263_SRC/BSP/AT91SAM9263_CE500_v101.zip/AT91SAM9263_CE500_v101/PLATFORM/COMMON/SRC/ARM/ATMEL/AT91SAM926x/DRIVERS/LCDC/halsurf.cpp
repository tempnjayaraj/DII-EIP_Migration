//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//
//  All rights reserved ADENEO SAS 2005
//
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x/DRIVERS/LCDC/halsurf.cpp
//!
//! \brief		Surface specific functions pack
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/LCDC/halsurf.cpp $
//!   $Author: pblanchard $
//!   $Revision: 984 $
//!   $Date: 2007-06-11 09:19:22 -0700 (Mon, 11 Jun 2007) $
//! \endif
//
//-----------------------------------------------------------------------------
//! \addtogroup	LCDC
//! @{

//-----------------------------------------------------------------------------
//
// This file is kept as is for the AT91SAM9261EK, no modification as been made.
// Here you had code your DirectDraw 2D accelerations. Refer to GDI/GPE acceleration
// to understand the HW acceleration command mechanism.
// The main work you had to do is to translate DDraw calls into intelligible
// 2D Chip commands.
// .DMR
//
//-----------------------------------------------------------------------------


#include "LCDC\precomp.h"

#ifdef DDRAW_ENABLE

//! \addtogroup	DirectDraw
//! @{

//////////////////////////// DDHAL_DDEXEBUFCALLBACKS ////////////////////////////

DWORD WINAPI HalCanCreateSurface( LPDDHAL_CANCREATESURFACEDATA pd )
{
	DEBUGENTER( HalCanCreateSurface );
	/*
	typedef struct _DDHAL_CANCREATESURFACEDATA
	{
	    LPDDRAWI_DIRECTDRAW_GBL	lpDD;				// driver struct
	    LPDDSURFACEDESC			lpDDSurfaceDesc;	// description of surface being created
	    DWORD					bIsDifferentPixelFormat;
												// pixel format differs from primary surface
	    HRESULT					ddRVal; 			// return value
	    LPDDHAL_CANCREATESURFACE	CanCreateSurface;
												// PRIVATE: ptr to callback
	} DDHAL_CANCREATESURFACEDATA;
	*/

	// Implementation

	DDPIXELFORMAT	*pddpf	= &pd->lpDDSurfaceDesc->ddpfPixelFormat;
	DWORD			caps	= pd->lpDDSurfaceDesc->ddsCaps.dwCaps;

	//
	// bIsDifferentPixelFormat indicates whether the pixel format differs from the primary surface. 
	// This member has always been FALSE for z-buffers. However, drivers implementing the GetDriverInfo function 
	// with a GUID_ZPixelFormat instance should expect this member to be TRUE. 
	//
	if (pd->bIsDifferentPixelFormat) {

		if (caps & DDSCAPS_ZBUFFER) {
			goto CanCreate;		// make an exception for Z buffer
		}
		else 
		{
			
			/*
			 * nav: Create plain surface???
			 * we better check pixel format here 'cos some games, they
			 * try to create 555 format 1st, if failed, they will create 565.
			 *
			 */
			if (DDPF_RGB & pddpf->dwFlags) {
				
				if (16 == ((LCDC6xhw *)g_pGPE)->GetBpp())
				{
					if ( (16 != pddpf->dwRGBBitCount) || (0xF800 != pddpf->dwRBitMask) )
						goto CannotCreate;
				}
				else
				{
					if (8 != pddpf->dwRGBBitCount)
						goto CannotCreate;
				}
			} // endif: if (DDPF_RGB & pddpf->dwFlags)
		} // endif if:  if (caps & DDSCAPS_ZBUFFER)
	} // endif: if (pd->bIsDifferentPixelFormat)

CanCreate:
	pd->ddRVal = DD_OK;
	return DDHAL_DRIVER_HANDLED;
CannotCreate:
	pd->ddRVal = DDERR_UNSUPPORTEDFORMAT;
	return DDHAL_DRIVER_HANDLED;
}

DWORD WINAPI HalCreateExecuteBuffer( LPDDHAL_CREATESURFACEDATA pd )
{
	DEBUGENTER( HalCreateExecuteBuffer );
	/*
	typedef struct _DDHAL_CREATESURFACEDATA
	{
	    LPDDRAWI_DIRECTDRAW_GBL	lpDD;		// driver struct
	    LPDDSURFACEDESC		lpDDSurfaceDesc;// description of surface being created
	    LPDDRAWI_DDRAWSURFACE_LCL	FAR *lplpSList; // list of created surface objects
	    DWORD			dwSCnt; 	// number of surfaces in SList
	    HRESULT			ddRVal; 	// return value
	    LPDDHAL_CREATESURFACE	CreateSurface;	// PRIVATE: ptr to callback
	} DDHAL_CREATESURFACEDATA;
	*/

	// Implementation
	pd->ddRVal = DD_OK;

	return DDHAL_DRIVER_HANDLED;
}


DWORD WINAPI HalDestroyExecuteBuffer( LPDDHAL_DESTROYSURFACEDATA pd )
{
	DEBUGENTER( HalDestroyExecutebuffer );
	/*
	typedef struct _DDHAL_DESTROYSURFACEDATA
	{
	    LPDDRAWI_DIRECTDRAW_GBL	lpDD;		// driver struct
	    LPDDRAWI_DDRAWSURFACE_LCL	lpDDSurface;	// surface struct
	    HRESULT			ddRVal; 	// return value
	    LPDDHALSURFCB_DESTROYSURFACE DestroySurface;// PRIVATE: ptr to callback
		BOOL						fDestroyGlobal;
	} DDHAL_DESTROYSURFACEDATA;
	*/

	// Implementation
	pd->ddRVal = DD_OK;

	return DDHAL_DRIVER_HANDLED;
}

DWORD WINAPI HalLock( LPDDHAL_LOCKDATA pd )
{
	DEBUGENTER( HalLock );
	/*
	typedef struct _DDHAL_LOCKDATA
	{
	    LPDDRAWI_DIRECTDRAW_GBL	lpDD;		// driver struct
	    LPDDRAWI_DDRAWSURFACE_LCL	lpDDSurface;	// surface struct
	    DWORD			bHasRect;	// rArea is valid
	    RECTL			rArea;		// area being locked
	    LPVOID			lpSurfData;	// pointer to screen memory (return value)
	    HRESULT			ddRVal; 	// return value
	    LPDDHALSURFCB_LOCK		Lock;		// PRIVATE: ptr to callback
	} DDHAL_LOCKDATA;
	*/

	// Implementation

	pd->ddRVal = (((LCDC6xhw *)g_pGPE)->FlipInProgress())? DDERR_WASSTILLDRAWING : DD_OK;

	if (DDERR_WASSTILLDRAWING == pd->ddRVal) {
		if (pd->dwFlags & DDLOCK_WAIT) {
			while ( (((LCDC6xhw *)g_pGPE)->FlipInProgress()) != DD_OK );
		}
		else {
			return DDHAL_DRIVER_HANDLED;
		}
	}

	// return DDGPELock(pd);

    DDGPESurf* pSurf = DDGPESurf::GetDDGPESurf(pd->lpDDSurface);
    ULONG ulAddress = pd->lpDDSurface->lpGbl->fpVidMem;

    if (pd->bHasRect)
    {
        DWORD bitcnt;
        LPDDRAWI_DDRAWSURFACE_GBL pGbl = pd->lpDDSurface->lpGbl;

        if (pd->lpDDSurface->dwFlags & DDRAWISURF_HASPIXELFORMAT)
            bitcnt = pGbl->ddpfSurface.dwRGBBitCount;
        else
            bitcnt = pGbl->lpDD->vmiData.ddpfDisplay.dwRGBBitCount;

        ulAddress += ((DWORD)pd->rArea.top * pSurf->Stride() +
                      ((DWORD)pd->rArea.left * (UINT)(bitcnt)) / 8);
    }

    *(int *)&(pd->lpSurfData) = ulAddress;

    pd->ddRVal = DD_OK;
    return DDHAL_DRIVER_HANDLED;
}

DWORD WINAPI HalUnlock( LPDDHAL_UNLOCKDATA pd )
{
	DEBUGENTER( HalUnlock );
	/*
	typedef struct _DDHAL_UNLOCKDATA
	{
	    LPDDRAWI_DIRECTDRAW_GBL	lpDD;		// driver struct
	    LPDDRAWI_DDRAWSURFACE_LCL	lpDDSurface;	// surface struct
	    HRESULT			ddRVal; 		// return value
	    LPDDHALSURFCB_UNLOCK	Unlock; 	// PRIVATE: ptr to callback
	} DDHAL_UNLOCKDATA;
	*/

	// Implementation
	pd->ddRVal = DD_OK;

	return DDHAL_DRIVER_HANDLED;
}


DWORD WINAPI HalSetSurfaceDesc(LPDDHAL_HALSETSURFACEDESCDATA pd)
{
	DEBUGENTER( HalSetSurfaceDesc );
	/*
		typedef struct _DDHAL_HALSETSURFACEDESCDATA
		{
		    DWORD		dwSize; 		// Size of this structure
		    LPDDRAWI_DDRAWSURFACE_LCL  lpDDSurface; // Surface
			LPDDSURFACEDESC lpddsd; 				// Description of surface
		    HRESULT		ddrval;
		} DDHAL_HALSETSURFACEDESCDATA;
	*/

	// Implementation
	pd->ddrval = DD_OK;

	return DDHAL_DRIVER_HANDLED;
}


DWORD WINAPI HalFlip( LPDDHAL_FLIPDATA pd )
{

	DEBUGENTER( HalFlip );
	/*
	typedef struct _DDHAL_FLIPDATA
	{
	    LPDDRAWI_DIRECTDRAW_GBL	lpDD;		// driver struct
	    LPDDRAWI_DDRAWSURFACE_LCL	lpSurfCurr;	// current surface
	    LPDDRAWI_DDRAWSURFACE_LCL	lpSurfTarg;	// target surface (to flip to)
	    DWORD			dwFlags;	// flags
	    HRESULT			ddRVal; 	// return value
	    LPDDHALSURFCB_FLIP		Flip;		// PRIVATE: ptr to callback
	} DDHAL_FLIPDATA;
	*/

	DDGPESurf* surfTarg = DDGPESurf::GetDDGPESurf(pd->lpSurfTarg);

	if (IS_BUSY)
    {
		if (pd->dwFlags & DDFLIP_WAIT)
        {
			WAIT_FOR_NOT_BUSY;
		}
		else
        {
			DEBUGMSG(GPE_ZONE_FLIP,(TEXT("Graphics engine busy\r\n")));
			pd->ddRVal = DDERR_WASSTILLDRAWING;
			return DDHAL_DRIVER_HANDLED;
		}
	}

	if (!(pd->dwFlags & DDFLIP_WAIT))
    {
		pd->ddRVal = (((LCDC6xhw *)g_pGPE)->FlipInProgress())? DDERR_WASSTILLDRAWING : DD_OK;
		if (DDERR_WASSTILLDRAWING == pd->ddRVal)
        {
			return DDHAL_DRIVER_HANDLED;
		}
	}
	
	if (!(pd->dwFlags & DDFLIP_NOVSYNC))
	{
		while ( ((LCDC6xhw *)g_pGPE)->FlipInProgress() );
	}
	pd->dwFlags &= ~DDFLIP_WAIT;				/* we wait already */

	((LCDC6xhw *)g_pGPE)->SetVisibleSurface((hwSurf*)surfTarg);

	DEBUGMSG(GPE_ZONE_FLIP,(TEXT("Flip done\r\n")));

	pd->ddRVal = DD_OK;
	return DDHAL_DRIVER_HANDLED;
}


DWORD WINAPI HalSetClipList( LPDDHAL_SETCLIPLISTDATA pd )
{
	DEBUGENTER( HalSetClipList );
	/*
	typedef struct _DDHAL_SETCLIPLISTDATA
	{
	    LPDDRAWI_DIRECTDRAW_GBL	lpDD;		// driver struct
	    LPDDRAWI_DDRAWSURFACE_LCL	lpDDSurface;	// surface struct
	    HRESULT			ddRVal; 	// return value
	    LPDDHALSURFCB_SETCLIPLIST	SetClipList;	// PRIVATE: ptr to callback
	} DDHAL_SETCLIPLISTDATA;
	*/

	// Implementation
	pd->ddRVal = DD_OK;

	return DDHAL_DRIVER_HANDLED;
}


DWORD WINAPI HalBlt( LPDDHAL_BLTDATA pd )
{
	DEBUGENTER( HalBlt );
	/*
	typedef struct _DDHAL_BLTDATA
	{
	    LPDDRAWI_DIRECTDRAW_GBL	lpDD;		// driver struct
	    LPDDRAWI_DDRAWSURFACE_LCL	lpDDDestSurface;// dest surface
	    RECTL			rDest;		// dest rect
	    LPDDRAWI_DDRAWSURFACE_LCL	lpDDSrcSurface; // src surface
	    RECTL			rSrc;		// src rect
	    DWORD			dwFlags;	// blt flags
	    DWORD			dwROPFlags;	// ROP flags (valid for ROPS only)
	    DDBLTFX			bltFX;		// blt FX
	    HRESULT			ddRVal; 	// return value
	    LPDDHALSURFCB_BLT		Blt;		// PRIVATE: ptr to callback
	} DDHAL_BLTDATA;
	*/

	// Implementation
	return DDGPEBlt(pd);
}


// not to be confused with
// DWORD WINAPI HalSetColorKey( LPDDHAL_DRVSETCOLORKEYDATA pd )
DWORD WINAPI HalSetColorKey( LPDDHAL_SETCOLORKEYDATA pd )
{
	DEBUGENTER( HalSetColorKey );
	/*
	typedef struct _DDHAL_DRVSETCOLORKEYDATA
	{
	    LPDDRAWI_DDRAWSURFACE_LCL	lpDDSurface;	// surface struct
	    DWORD			dwFlags;	// flags
	    DDCOLORKEY			ckNew;		// new color key
	    HRESULT			ddRVal; 	// return value
	    LPDDHAL_SETCOLORKEY 	SetColorKey;	// PRIVATE: ptr to callback
	} DDHAL_DRVSETCOLORKEYDATA;
	*/

	//	This is what DDGPESetColorKey(pd) would do
	DDGPESurf* pSurf = DDGPESurf::GetDDGPESurf(pd->lpDDSurface);
	if (pSurf != NULL)
	{
		pSurf->SetColorKeyLow(pd->ckNew.dwColorSpaceLowValue);
		pSurf->SetColorKeyHigh(pd->ckNew.dwColorSpaceHighValue);
	}

	pd->ddRVal = DD_OK;
	return DDHAL_DRIVER_HANDLED;


}


DWORD WINAPI HalAddAttachedSurface( LPDDHAL_ADDATTACHEDSURFACEDATA pd )
{
	DEBUGENTER( HalAddAttachedSurface );
	/*
	typedef struct _DDHAL_ADDATTACHEDSURFACEDATA
	{
	    LPDDRAWI_DIRECTDRAW_GBL		lpDD;		// driver struct
	    LPDDRAWI_DDRAWSURFACE_LCL	lpDDSurface;	// surface struct
	    LPDDRAWI_DDRAWSURFACE_LCL	lpSurfAttached; // surface to attach
	    HRESULT						ddRVal; 	// return value
	    LPDDHALSURFCB_ADDATTACHEDSURFACE AddAttachedSurface;
												// PRIVATE: ptr to callback
	} DDHAL_ADDATTACHEDSURFACEDATA;
	*/

	// Implementation
	pd->ddRVal = DD_OK;

	return DDHAL_DRIVER_HANDLED;
}


DWORD WINAPI HalGetBltStatus( LPDDHAL_GETBLTSTATUSDATA pd )
{
	DEBUGENTER( HalGetBltStatus );
	/*
	typedef struct _DDHAL_GETBLTSTATUSDATA
	{
	    LPDDRAWI_DIRECTDRAW_GBL	lpDD;		// driver struct
	    LPDDRAWI_DDRAWSURFACE_LCL	lpDDSurface;	// surface struct
	    DWORD			dwFlags;	// flags
	    HRESULT			ddRVal; 	// return value
	    LPDDHALSURFCB_GETBLTSTATUS	GetBltStatus;	// PRIVATE: ptr to callback
	} DDHAL_GETBLTSTATUSDATA;
	*/

	// Implementation

	pd->ddRVal = DD_OK;

	if (IS_BUSY)
	{
		pd->ddRVal = DDERR_WASSTILLDRAWING;
	}
	else
	{
		pd->ddRVal = DD_OK;
	}

	return DDHAL_DRIVER_HANDLED;
}


DWORD WINAPI HalGetFlipStatus( LPDDHAL_GETFLIPSTATUSDATA pd )
{
	DEBUGENTER( HalGetFlipStatus );
	/*
	typedef struct _DDHAL_GETFLIPSTATUSDATA
	{
	    LPDDRAWI_DIRECTDRAW_GBL	lpDD;		// driver struct
	    LPDDRAWI_DDRAWSURFACE_LCL	lpDDSurface;	// surface struct
	    DWORD			dwFlags;	// flags
	    HRESULT			ddRVal; 	// return value
	    LPDDHALSURFCB_GETFLIPSTATUS GetFlipStatus;	// PRIVATE: ptr to callback
	} DDHAL_GETFLIPSTATUSDATA;
	*/

	// Implementation

	pd->ddRVal = (((LCDC6xhw *)g_pGPE)->FlipInProgress())? DDERR_WASSTILLDRAWING : DD_OK;

	return DDHAL_DRIVER_HANDLED;
}


DWORD WINAPI HalSetPalette( LPDDHAL_SETPALETTEDATA pd )
{
	DEBUGENTER( HalSetPalette );
	/*
	typedef struct _DDHAL_SETPALETTEDATA
	{
	    LPDDRAWI_DIRECTDRAW_GBL	lpDD;		// driver struct
	    LPDDRAWI_DDRAWSURFACE_LCL	lpDDSurface;	// surface struct
	    LPDDRAWI_DDRAWPALETTE_GBL	lpDDPalette;	// palette to set to surface
	    HRESULT			ddRVal; 	// return value
	    LPDDHALSURFCB_SETPALETTE	SetPalette;	// PRIVATE: ptr to callback
	    BOOL			Attach; 	// attach this palette?
	} DDHAL_SETPALETTEDATA;
	*/

	// Implementation
	pd->ddRVal = DD_OK;

	return DDHAL_DRIVER_HANDLED;
}

#endif DDRAW_ENABLE

//! @}

//! @}

//! @}

////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/LCDC/halsurf.cpp $
////////////////////////////////////////////////////////////////////////////////
//