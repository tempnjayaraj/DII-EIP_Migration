//-----------------------------------------------------------------------------
//! \addtogroup MISC
//! @{
//
//  All rights reserved ADENEO SAS 2005
//
//! \file		AT91SAM9261_gpio.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9261/INC/AT91SAM9261_gpio.h $
//!   $Author: ltourlonias $
//!   $Revision: 657 $
//!   $Date: 2007-06-07 16:52:09 +0200 (mar., 10 avr. 2007) $
//! \endif
//
//-----------------------------------------------------------------------------
//! \addtogroup GPIO
//! @{
//

#ifndef __AT91SAM9261_GPIO_H__
#define __AT91SAM9261_GPIO_H__

#include "atmel_gpio.h"

/* these pin numbers double as IRQ numbers, like AT91C_ID_* values */
#define PIO_NB_IO		32 /* Number of IO handled by one PIO controller */
#define	AT91C_PIN_PA(io)	(0 * PIO_NB_IO + io)
#define	AT91C_PIN_PB(io)	(1 * PIO_NB_IO + io)
#define	AT91C_PIN_PC(io)	(2 * PIO_NB_IO + io)

#endif /* __AT91SAM9261_GPIO_H__*/
//! @}
//! @}
