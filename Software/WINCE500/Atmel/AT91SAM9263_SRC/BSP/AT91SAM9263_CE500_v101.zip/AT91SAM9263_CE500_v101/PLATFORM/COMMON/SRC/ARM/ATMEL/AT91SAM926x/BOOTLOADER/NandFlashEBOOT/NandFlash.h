//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/NandFlashEBOOT/NandFlash.h
//!
//! \brief		NandFlash driver for AT91SAM926x chipset
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/NandFlashEBOOT/NandFlash.h $
//!   $Author: ltourlonias $
//!   $Revision: 657 $
//!   $Date: 2007-04-10 16:52:09 +0200 (mar., 10 avr. 2007) $
//! \endif
//!
//! 
//-----------------------------------------------------------------------------
//! \addtogroup	NandFlash
//! @{
//!

#ifndef __NAND_FLASH__
#define __NAND_FLASH__

#include <windows.h>

#include "NandIds.h"

/*
 * Standard NAND flash commands
 */
#define NAND_CMD_READ0          0x00
#define NAND_CMD_READ1          0x01
#define NAND_CMD_READOOB        0x50

#define NAND_CMD_WRITE0          0x00
#define NAND_CMD_WRITE1          0x01
#define NAND_CMD_WRITEOOB        0x50

#define NAND_CMD_RNDOUT         5
#define NAND_CMD_PAGEPROG       0x10
#define NAND_CMD_ERASE1         0x60
#define NAND_CMD_STATUS         0x70
#define NAND_CMD_STATUS_MULTI   0x71
#define NAND_CMD_SEQIN          0x80
#define NAND_CMD_RNDIN          0x85
#define NAND_CMD_READID         0x90
#define NAND_CMD_ERASE2         0xD0
#define NAND_CMD_RESET          0xFF

/* Extended commands for large page devices */
#define NAND_CMD_READSTART      0x30
#define NAND_CMD_RNDOUTSTART    0xE0
#define NAND_CMD_CACHEDPROG     0x15

// Nand flash chip status codes
#define NAND_STATUS_FAIL        0x01
#define NAND_STATUS_FAIL_N1     0x02
#define NAND_STATUS_TRUE_READY  0x20
#define NAND_STATUS_READY       0x40
#define NAND_STATUS_WP          0x80

#define TIMER_GRANULARITY		400

// Wait mode
#define WAIT_POOL			POOL_ON_READYBUSY			//!< Default pool mode
#define WAIT_INTERRUPT			INTERRUPT_ON_READYBUSY		//!< Default interrupt mode
#define	ERASE_TIMEOUT			(100 + TIMER_GRANULARITY)	//!< erase maximum time in ms
#define RESET_TIMEOUT			(10	+ TIMER_GRANULARITY)	//!< reset maximum time in ms
#define READ_TIMEOUT			(10	+ TIMER_GRANULARITY)	//!< read maximum time in ms
#define WRITE_TIMEOUT			(10 + TIMER_GRANULARITY)	//!< write maximum time in ms

#define POOL_ON_READYBUSY		0x01						//!< Pool on ReadyBusy PIO
#define INTERRUPT_ON_READYBUSY		0x02						//!< Interrupt on ReadyBusy PIO
#define POOL_ON_STATUS			0x04						//!< Pool on Status byte

// Chip select timings
#define AT91C_NAND_CHIPSELECT		3							//!< Num for flash chip select

#define AT91C_NAND_NWE_SETUP		0							// timing for flash in ns
#define AT91C_NAND_NWE_PULSE 		28
#define AT91C_NAND_NWE_CYCLE		56

#define AT91C_NAND_NCS_WR_SETUP		0
#define AT91C_NAND_NCS_WR_PULSE		42

#define AT91C_NAND_NRD_SETUP		0
#define AT91C_NAND_NRD_PULSE		28
#define AT91C_NAND_NRD_CYCLE		56

#define AT91C_NAND_NCS_RD_SETUP		0
#define AT91C_NAND_NCS_RD_PULSE		42
	
#define AT91C_NAND_TDF			(1 << 16)


typedef struct _NandChip NandChip;

#define LLD_ERASEBLOCK(pChip, dwPhyBlckNb)			(pChip)->LLDIface.EraseBlock(pChip, dwPhyBlckNb)
#define LLD_READSECTOR(pChip, fZone, dwSectorAddr, pOutBuffer)	(pChip)->LLDIface.ReadSector(pChip, fZone, dwSectorAddr, pOutBuffer)
#define LLD_WRITESECTOR(pChip, fZone, dwSectorAddr, pInBuffer)	(pChip)->LLDIface.WriteSector(pChip, fZone, dwSectorAddr, pInBuffer)

typedef struct _LLD_Interface
{
	BOOL (*EraseBlock)(NandChip *, DWORD);
	BOOL (*ReadSector)(NandChip *, DWORD, DWORD, PBYTE);
	BOOL (*WriteSector)(NandChip *, DWORD, DWORD, PBYTE);
} LLD_Interface;

#define NF_ENABLE(pChip)			(pChip)->NFIface.Enable(pChip)
#define NF_DISABLE(pChip)			(pChip)->NFIface.Disable(pChip)
#define NF_WRITEBUF(pChip, pInBuffer, len)	(pChip)->NFIface.WriteBuf(pChip, pInBuffer, len)
#define NF_READBUF(pChip, pOutBuffer, len)	(pChip)->NFIface.ReadBuf(pChip, pOutBuffer, len)
#define NF_READWORD(pChip)			(pChip)->NFIface.ReadWord(pChip)
#define NF_READBYTE(pChip)			(pChip)->NFIface.ReadByte(pChip)
#define NF_WRITEADDR(pChip, addr)		(pChip)->NFIface.WriteAddr(pChip, addr)
#define NF_WRITECMD(pChip, cmd)			(pChip)->NFIface.WriteCmd(pChip, cmd)
#define NF_ISREADY(pChip)			(pChip)->NFIface.IsReady(pChip)

typedef struct _NF_Interface {
	void (*Enable)(NandChip *pChip);
	void (*Disable)(NandChip *pChip);
	void (*WriteBuf)(NandChip *pChip, BYTE *pInBuffer, DWORD len);
	void (*ReadBuf)(NandChip *pChip, BYTE *pOutBuffer, DWORD len);
	WORD (*ReadWord)(NandChip *pChip);
	BYTE (*ReadByte)(NandChip *pChip);
	void (*WriteAddr)(NandChip *pChip, UCHAR addr);
	void (*WriteCmd)(NandChip *pChip, UCHAR cmd);
	BOOL (*IsReady)(NandChip *pChip);
} NF_Interface;

typedef struct _NandChip {
	NandFlashDev	*pFlashDev;		//<! Flash Dev infos
	LLD_Interface	LLDIface;		//!< Here are pointers to LLD functions
	NF_Interface	NFIface;		//!< Here are pointers to NF functions
	volatile	PVOID			pFlashBase		; //!< Flash Base register
	volatile	PUCHAR			pFlashCmd		; //!< Flash Cmd  register
	volatile	PUCHAR			pFlashAddr		; //!< Flash Addr register
	DWORD					dwNbBytes		; //!< Nb of MBytes in device
	DWORD					dwMasterClock;
	DWORD					dwPhyNandBaseAddr;
	DWORD					dwPhyNandAleAddr;
	DWORD					dwPhyNandCleAddr;
} NandChip;

NandChip *NandFlash_Alloc();
BOOL NandFlash_LowLevelInit(NandChip *pChip);
BOOL NandFlash_Release(NandChip *pChip);
BOOL NandFlash_WaitForReady(NandChip * pChip, DWORD fWaitType, DWORD dwTimeout);
BOOL NandFlash_RetreiveIDs(NandChip *pChip, WORD* wManufacturerID, WORD* wDeviceID);

#endif

// End of Doxygen group NandFlash Driver
//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/NandFlashEBOOT/NandFlash.h $
//-----------------------------------------------------------------------------
//
//! @}
