//-----------------------------------------------------------------------------
//! \addtogroup	MISC
//! @{
//!  
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		crc32.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/crc32.h $
//!   $Author: pgal $
//!   $Revision: 617 $
//!   $Date: 2007-04-02 15:52:12 +0200 (lun., 02 avr. 2007) $
//! \endif
//!
//! Header for crc32 lib
//-----------------------------------------------------------------------------

// Make a Doxygen group
//! \addtogroup CRC32
//! @{

#ifndef _CRC32_H_
#define _CRC32_H_

unsigned long ComputeCRC32(unsigned char *buffer, int len);

#endif /* _CRC32_H_ */

// End of Doxygen group crc32
//! @}

//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/crc32.h $
//-----------------------------------------------------------------------------
