//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x_usbfn_endpoint_IN.cpp
//!
//! \brief		Implementation of the IN endpoint
//!
//! 
//-----------------------------------------------------------------------------
//! \addtogroup	USBFN
//! @{
//!

#include <windows.h>
#include <ceddk.h>
#include <ddkreg.h>
#include <nkintr.h> // needed for SYSINTR_NOP
#include "AT91SAM926x_usbfn.h"
#include "AT91SAM926x.h"
#include "AT91SAM926x_oal_intr.h"

#include "AT91SAM926x_USBFN_EndPoint.h"
#include "AT91SAM926x_USBFN_EndPoint_IN.h"


//-----------------------------------------------------------------------------
//! \brief		This function handles interrupt on In endpoint.
//!
//! \param		dwIRBit		Status of the interrupt
//!
//! \return		ERROR_SUCCESS	Always return this
//!
//! This function handles interrupt on endpoint. Calls XmitData, CompleteTransfer, SendFakeFeature
//-----------------------------------------------------------------------------
DWORD   AT91SAMEndpointIn::IST(DWORD dwIRBit)
{
    Lock();
    BOOL bContinue = TRUE;
    SETFNAME();
    FUNCTION_ENTER_MSG();
    while (bContinue) 
    { // Loop until all the event clear.
        bContinue = FALSE;
        DEBUGMSG(ZONE_TRANSFER, (_T(" IN::IST(%d) CSR=0x%x"), m_dwEndpointIndex, m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex]));
        
		
		if ((m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] & AT91C_UDP_TXCOMP) || ((1 | m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] & AT91C_UDP_TXPKTRDY) == 0))
		{			
			// // The Host has acknowledged our IN packet...  Clear the TXCOMP bit
			if (m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] & AT91C_UDP_TXCOMP)
			{
				m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] &= ~AT91C_UDP_TXCOMP;
			}
			if (m_pCallBackInfo)
			{

				if (m_pCallBackInfo->m_pFnCallBack)
				{
					m_pCallBackInfo->m_pFnCallBack(m_pCallBackInfo->m_pContext,m_pCallBackInfo->m_dwParam);
				}
				delete m_pCallBackInfo;
				m_pCallBackInfo = NULL;
				bContinue = TRUE;
			}
			
			//Are we currently transferring a IN packet
			if (m_pCurTransfer && (m_pCurTransfer->dwFlags & USB_IN_TRANSFER))
			{
				//Was this the las packet of the transfer ?
				if ((DWORD) m_pCurTransfer->pvPddTransferInfo == AT91SAM926X_END_OF_TRANSFER)
				{
					//Tell the MDD that the transfer is complete with no error
					CompleteTransfer(UFN_NO_ERROR);
				}
				// It wasn't the last packet so we try to send the next packet...
				else 
				{
					BOOL bResult;
					DWORD dwToSend;
					
					dwToSend = MIN(m_pCurTransfer->cbBuffer - m_pCurTransfer->cbTransferred, m_epDesc.wMaxPacketSize);

					if (dwToSend == m_pCurTransfer->cbBuffer - m_pCurTransfer->cbTransferred)
					{
						m_pCurTransfer->pvPddTransferInfo = (PVOID) AT91SAM926X_END_OF_TRANSFER;
					}
					
					// If the data amount is less than the fifo limit it will be the last packet.
					// If the data amount is exactly the fifo size, then will send a zero length packet after this one.
					if (dwToSend < m_epDesc.wMaxPacketSize)
					{
						m_pCurTransfer->pvPddTransferInfo = (PVOID) AT91SAM926X_END_OF_TRANSFER;
					}			
				
					bResult = XmitData(((UCHAR*)m_pCurTransfer->pvBuffer)+ m_pCurTransfer->cbTransferred, dwToSend);					
				
					if (bResult != dwToSend)
					{
						RETAILMSG(1,(TEXT("IST end point zero, XmitData failed....\r\n")));
						//Tell the MDD that we failed ....						
						CompleteTransfer(UFN_NOT_COMPLETE_ERROR);
					}
					else
					{
						m_pCurTransfer->cbTransferred+= dwToSend;
					}
				}
				bContinue = TRUE;
			}
		}

    }
    Unlock();
    FUNCTION_LEAVE_MSG();
    return ERROR_SUCCESS;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL AT91SAMEndpointIn:: Init( PUSB_ENDPOINT_DESCRIPTOR pEndpointDesc, BYTE bConfigurationValue, BYTE bInterfaceNumber, BYTE bAlternateSetting)
//! \brief		This function initializes the Bulk IN endpoint.
//!
//! \param		pEndpointDesc			Endpoint descriptor
//! \param		bConfigurationValue		Configuration value
//! \param		bInterfaceNumber		Interface number
//! \param		bAlternateSetting		Alternate setting
//!
//! \return		Does the init succeed ?
//!
//-----------------------------------------------------------------------------
BOOL AT91SAMEndpointIn:: Init( PUSB_ENDPOINT_DESCRIPTOR pEndpointDesc,
            BYTE bConfigurationValue, BYTE bInterfaceNumber, BYTE bAlternateSetting)
{
    Lock();
    BOOL bReturn = FALSE;
    SETFNAME();
    FUNCTION_ENTER_MSG();
    
	// Set in control mode		
    if ( pEndpointDesc && m_pUsbDevice!=NULL && m_dwEndpointIndex < MAX_ENDPOINT_NUMBER) 
	{
		if (AT91SAMEndpoint::Init(pEndpointDesc,bConfigurationValue,bInterfaceNumber,bAlternateSetting))
		{
			if (pEndpointDesc->bmAttributes == USB_ENDPOINT_TYPE_BULK)
			{
				m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] = m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] & ~AT91C_UDP_EPTYPE | AT91C_UDP_EPTYPE_BULK_IN;
			}
			else if (pEndpointDesc->bmAttributes == USB_ENDPOINT_TYPE_INTERRUPT)
			{
				m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] = m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] & ~AT91C_UDP_EPTYPE | AT91C_UDP_EPTYPE_INT_IN;
			}
			bReturn = TRUE;
		}
    }
    Unlock();
    FUNCTION_LEAVE_MSG();
    return bReturn;
}

//! @}
//! @}
