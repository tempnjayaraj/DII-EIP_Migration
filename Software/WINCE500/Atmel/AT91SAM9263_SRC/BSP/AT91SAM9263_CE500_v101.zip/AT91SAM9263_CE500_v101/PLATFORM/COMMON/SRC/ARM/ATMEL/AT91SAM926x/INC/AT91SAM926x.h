//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x.h
//!
//! \brief		includes the definitions for the AT91SAM926x processors.
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/AT91SAM926x.h $
//!   $Author: pblanchard $
//!   $Revision: 1058 $
//!   $Date: 2007-07-05 01:34:39 -0700 (Thu, 05 Jul 2007) $
//! \endif
//-----------------------------------------------------------------------------


#ifndef AT91SAM926X_H
#define AT91SAM926X_H

#include <windows.h>


#if defined   PROC_AT91SAM9260
	#include "at91sam9260.h"
#elif   defined   PROC_AT91SAM9261
	#include "at91sam9261.h"
#elif defined   PROC_AT91SAM9262
	#include "at91sam9262.h"
#elif defined   PROC_AT91SAM9263
	#include "at91sam9263.h"
#else
	#error A Processor must be defined
#endif


#define SLOW_CLOCK_FREQUENCY    32768

typedef struct _PROC_INFO {
	WCHAR cManufacturer[16];
	WCHAR cCore[16];
	WCHAR cProcessor[32];
	WORD wCoreRevision;
	WORD wProcessorRevision;
	WCHAR cCatalogNumber[32];
	DWORD dwInstructionSet;
	DWORD dwClockSpeed;
} T_PROC_INFO, *PT_PROC_INFO;

#endif //AT91SAM926X_H

//! @}


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/AT91SAM926x.h $
////////////////////////////////////////////////////////////////////////////////
//
