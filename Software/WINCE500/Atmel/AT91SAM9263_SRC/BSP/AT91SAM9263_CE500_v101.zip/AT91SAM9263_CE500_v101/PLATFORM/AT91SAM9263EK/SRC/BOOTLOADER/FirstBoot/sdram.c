//-----------------------------------------------------------------------------
//! \addtogroup BOOTLOADER
//! @{
//
//  All rights reserved ADENEO SAS 2005
//
//! \file		sdram.c
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/BOOTLOADER/FirstBoot/sdram.c $
//!   $Author: ltourlonias $
//!   $Revision: 684 $
//!   $Date: 2007-04-13 14:35:48 +0200 (ven., 13 avr. 2007) $
//! \endif
//		TODO
//
//-----------------------------------------------------------------------------
//! \addtogroup FIRSTBOOT
//! @{
//System include
#include <windows.h>

// Local include
#include "AT91SAM9263EK.h"
#include "AT91SAM926x.h"
#include "lib_AT91SAM926x.h"
#include "AT91SAM926x_interface.h"
#include "oal_memory.h"
#include "dbgu.h"

#define AT91C_MASTER_CLOCK              48000000
#define AT91C_SDRAM 		((unsigned int *)0x20000000)

//-----------------------------------------------------------------------------
//! \fn			void AT91F_InitSdram(void)
//!
//! \brief		This function performs SDRAM initialization
//-----------------------------------------------------------------------------
void AT91F_InitSdram (void)
{
	volatile unsigned int i;
	AT91PS_SDRAMC	psdrc = AT91C_BASE_SDRAMC0;
	
    AT91C_BASE_MATRIX->MATRIX_EBI0 |= AT91C_MATRIX_CS1A_SDRAMC;

	// Configure PIOs
	AT91C_BASE_PIOD->PIO_PDR =  
		(((unsigned int) AT91C_PD9_EBI0_CFCE2) |
		((unsigned int) AT91C_PD30_EBI0_D30) |
		((unsigned int) AT91C_PD28_EBI0_D28) |
		((unsigned int) AT91C_PD26_EBI0_D26) |
		((unsigned int) AT91C_PD25_EBI0_D25) |
		((unsigned int) AT91C_PD23_EBI0_D23) |
		((unsigned int) AT91C_PD14_EBI0_A25_CFNRW) |
		((unsigned int) AT91C_PD20_EBI0_D20) |
		((unsigned int) AT91C_PD13_EBI0_A24) |
		((unsigned int) AT91C_PD29_EBI0_D29) |
		((unsigned int) AT91C_PD7_EBI0_NCS5_CFCS1) |
		((unsigned int) AT91C_PD22_EBI0_D22) |
		((unsigned int) AT91C_PD19_EBI0_D19) |
		((unsigned int) AT91C_PD18_EBI0_D18) |
		((unsigned int) AT91C_PD31_EBI0_D31) |
		((unsigned int) AT91C_PD6_EBI0_NCS4_CFCS0) |
		((unsigned int) AT91C_PD12_EBI0_A23) |
		((unsigned int) AT91C_PD5_EBI0_NWAIT) |
		((unsigned int) AT91C_PD8_EBI0_CFCE1) |
		((unsigned int) AT91C_PD17_EBI0_D17) |
		((unsigned int) AT91C_PD11_EBI0_NCS2) |
		((unsigned int) AT91C_PD16_EBI0_D16) |
		((unsigned int) AT91C_PD27_EBI0_D27) |
		((unsigned int) AT91C_PD24_EBI0_D24) |
		((unsigned int) AT91C_PD21_EBI0_D21) |
		((unsigned int) AT91C_PD15_EBI0_NCS3_NANDCS));

	AT91C_BASE_PIOD->PIO_ASR =  
		(((unsigned int) AT91C_PD9_EBI0_CFCE2) |
		((unsigned int) AT91C_PD30_EBI0_D30) |
		((unsigned int) AT91C_PD28_EBI0_D28) |
		((unsigned int) AT91C_PD26_EBI0_D26) |
		((unsigned int) AT91C_PD25_EBI0_D25) |
		((unsigned int) AT91C_PD23_EBI0_D23) |
		((unsigned int) AT91C_PD14_EBI0_A25_CFNRW) |
		((unsigned int) AT91C_PD20_EBI0_D20) |
		((unsigned int) AT91C_PD13_EBI0_A24) |
		((unsigned int) AT91C_PD29_EBI0_D29) |
		((unsigned int) AT91C_PD7_EBI0_NCS5_CFCS1) |
		((unsigned int) AT91C_PD22_EBI0_D22) |
		((unsigned int) AT91C_PD19_EBI0_D19) |
		((unsigned int) AT91C_PD18_EBI0_D18) |
		((unsigned int) AT91C_PD31_EBI0_D31) |
		((unsigned int) AT91C_PD6_EBI0_NCS4_CFCS0) |
		((unsigned int) AT91C_PD12_EBI0_A23) |
		((unsigned int) AT91C_PD5_EBI0_NWAIT) |
		((unsigned int) AT91C_PD8_EBI0_CFCE1) |
		((unsigned int) AT91C_PD17_EBI0_D17) |
		((unsigned int) AT91C_PD11_EBI0_NCS2) |
		((unsigned int) AT91C_PD16_EBI0_D16) |
		((unsigned int) AT91C_PD27_EBI0_D27) |
		((unsigned int) AT91C_PD24_EBI0_D24) |
		((unsigned int) AT91C_PD21_EBI0_D21) |
		((unsigned int) AT91C_PD15_EBI0_NCS3_NANDCS));
	
	/* CFG 100 */
	psdrc->SDRAMC_CR =  AT91C_SDRAMC_NC_9  |
						AT91C_SDRAMC_NR_13 |
						AT91C_SDRAMC_CAS_2 |
						AT91C_SDRAMC_NB_4_BANKS |
						AT91C_SDRAMC_DBW_32_BITS |
						AT91C_SDRAMC_TWR_2 |
						AT91C_SDRAMC_TRC_7 |
						AT91C_SDRAMC_TRP_2 |
						AT91C_SDRAMC_TRCD_2 |
						AT91C_SDRAMC_TRAS_5 |
						AT91C_SDRAMC_TXSR_8 ;

	for (i =0; i< 1000;i++);

	psdrc->SDRAMC_MR	= 0x00000002;		// Set PRCHG AL
	*AT91C_SDRAM	= 0x00000000;			// Perform PRCHG

	for (i =0; i< 10000;i++);
	
	psdrc->SDRAMC_MR	= AT91C_SDRAMC_MODE_RFSH_CMD;		// Set 1st CBR
	*(AT91C_SDRAM+4)	= 0x00000001;	// Perform CBR

	psdrc->SDRAMC_MR	= 0x00000004;						// Set 2 CBR
	*(AT91C_SDRAM+8)	= 0x00000002;	// Perform CBR

	psdrc->SDRAMC_MR	= AT91C_SDRAMC_MODE_RFSH_CMD;		// Set 3 CBR
	*(AT91C_SDRAM+0xc)	= 0x00000003;	// Perform CBR

	psdrc->SDRAMC_MR	= AT91C_SDRAMC_MODE_RFSH_CMD;		// Set 4 CBR
	*(AT91C_SDRAM+0x10)	= 0x00000004;	// Perform CBR

	psdrc->SDRAMC_MR	= AT91C_SDRAMC_MODE_RFSH_CMD;		// Set 5 CBR
	*(AT91C_SDRAM+0x14)	= 0x00000005;	// Perform CBR

	psdrc->SDRAMC_MR	= AT91C_SDRAMC_MODE_RFSH_CMD;		// Set 6 CBR
	*(AT91C_SDRAM+0x18)	= 0x00000006;	// Perform CBR

	psdrc->SDRAMC_MR	= AT91C_SDRAMC_MODE_RFSH_CMD;		// Set 7 CBR
	*(AT91C_SDRAM+0x1c)	= 0x00000007;	// Perform CBR

	psdrc->SDRAMC_MR	= AT91C_SDRAMC_MODE_RFSH_CMD;		// Set 8 CBR
	*(AT91C_SDRAM+0x20)	= 0x00000008;	// Perform CBR

	psdrc->SDRAMC_MR	= AT91C_SDRAMC_MODE_LMR_CMD;		// Set LMR operation
	*(AT91C_SDRAM+0x24)	= 0xcafedede;						// Perform LMR burst=1, lat=2

	psdrc->SDRAMC_TR	= (AT91C_MASTER_CLOCK * 15)/1000000;	// Set Refresh Timer 390 for 25MHz (TR= 15.6 * F )
															// (F : system clock freq. MHz
	psdrc->SDRAMC_MR	= AT91C_SDRAMC_MODE_NORMAL_CMD;		// Set Normal mode
	*AT91C_SDRAM	= 0x00000000;							// Perform Normal mode
}
//! @}

//! @}
