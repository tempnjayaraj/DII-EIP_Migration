//-----------------------------------------------------------------------------
//! \addtogroup   OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				idle.c 
//!
//! \brief			implements OEMIdle function
//!					This file contains fake/busy loop implementation if OALCPUIdle function. 
//!					It is assumed to be used in development only.
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/KERNEL/TIMER/idle.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

#include <windows.h>
#include <nkintr.h>
#include <oal.h>
#include "at91rm9200_interface.h"
#include "AT91RM9200_oal_timer.h"

 
//------------------------------------------------------------------------------
//
//  Global:  g_oalLastSysIntr
//
//  This global variable is set by fake version of interrupt/timer handler
//  to last SYSINTR value.
//
volatile UINT32 g_oalLastSysIntr;

//-----------------------------------------------------------------------------
//! \fn VOID OALCPUIdle()
//!
//!	\brief This Idle function implements a busy idle. It is intend to be used only
//!			in development (when CPU doesn't support idle mode it is better to stub
//!			OEMIdle function instead use this busy loop). The busy wait is cleared by
//!			an interrupt from interrupt handler setting the g_oalLastSysIntr.
//!
//-----------------------------------------------------------------------------
VOID OALCPUIdle()
{
	// Clear last SYSINTR global value
    g_oalLastSysIntr = SYSINTR_NOP;
    INTERRUPTS_ON();

#ifdef FAKE_IDLE    
    // Wait until interrupt handler set interrupt flag
    while (g_oalLastSysIntr == SYSINTR_NOP);
#else
	while (g_oalLastSysIntr == SYSINTR_NOP)
	{
		AT91RM9200_TurnProcessorClockOff();
	}
#endif    
    INTERRUPTS_OFF();
}


//-----------------------------------------------------------------------------
//! \fn void OEMIdle(DWORD idleParam)
//!
//!	\brief	This function is called by the kernel when there are no threads ready to 
//!			run. The CPU should be put into a reduced power mode if possible and halted. 
//!			It is important to be able to resume execution quickly upon receiving an 
//!			interrupt.
//!
//!			Interrupts are disabled when OEMIdle is called and when it returns.
//!
//!			Note that system timer must be running when CPU/SoC is moved to reduced
//!			power mode.
//!
//!	\param idleParam not use
//! 
//-----------------------------------------------------------------------------
void OEMIdle(DWORD idleParam)
{
	/*

    UINT32 baseMSec, idleMSec, idleSysTicks;
    ULARGE_INTEGER idle;
	
    // Get current system timer counter
    baseMSec = CurMSec;

    // Compute the remaining idle time
    idleMSec = dwReschedTime - baseMSec;
	    
    // Idle time has expired - we need to return
    if ((INT32)idleMSec <= 0) return;

    // Limit the maximum idle time to what is supported.  
    // Counter size is the limiting parameter.  When kernel 
    // profiler or interrupt latency timing is active it is set
    // to one system tick.
    if (idleMSec > g_oalTimer.maxPeriodMSec) {	
        idleMSec = g_oalTimer.maxPeriodMSec;
    }
    
    idleSysTicks = idleMSec/g_oalTimer.msecPerSysTick;
    

    // Prolong beat period to idle time -- don't do it idle time isn't
    // longer than one system tick. Even if OALTimerExtendSysTick function
    // should accept this value it can cause problems if kernel profiler
    // or interrupt latency timing is active.
    if (idleSysTicks > 1) {
        // Extend timer period
       
	   OALTimerEnterIdle(idleMSec);
    }

    // Move SoC/CPU to idle mode
    OALCPUIdle();
		

    // Return system tick period back to original. Don't call when idle
    // time was one system tick. See comment above.
    if (idleSysTicks > 1) {

        // We have to restore the normal timer interrupt period
        
        // Return system tick period back to original
        
		OALTimerExitFromIdle();      		

    } 
    
    // Update idle counters
    idle.LowPart = curridlelow;
    idle.HighPart = curridlehigh;
    curridlelow  = idle.LowPart;
    curridlehigh = idle.HighPart;
	*/

}

//! @}
