//-----------------------------------------------------------------------------
//! \addtogroup   OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				intr.c
//!
//! \brief				Implements the interrupt engine
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/KERNEL/INTR/intr.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

#include <windows.h>
#include <ceddk.h>
#include <nkintr.h>
#include <oal.h>
#include <oal_intr.h>
#include <intr.h>
#include "AT91RM9200.h"
#include "lib_AT91RM9200.h"
#include "AT91RM9200_oal_intr.h"
#include "AT91RM9200_oal_timer.h"
#include "pio_intr.h"



/// This defines the maximum number of physical interrupts handled by the BSP. 
///
/// \note : This value is much higher than the actual number of interrupt managed by the AIC (interrupt controller). It's because the PIOs interrupts go through an abstraction engine allowing to handle any PIO as a distinct interrupt line.
#define AT91RM9200_OAL_INTR_IRQ_MAXIMUM    192 

/// this variable contains the maximum number of physical interrupts handled by the BSP.
const DWORD oal_intr_irq_maximum = AT91RM9200_OAL_INTR_IRQ_MAXIMUM;

///  This is the table used to do the translation from SYSINTR (system interrupt number) to LOGINTR (physical interrupt number)
///
///  \note SYSINTR_MAXIMUM is defined by the OS itself and cannot be changed.
UINT32 g_oalSysIntr2Irq[SYSINTR_MAXIMUM];
///  This is the table used to do the translation from LOGINTR (physical interrupt number) to SYSINTR (system interrupt number)
UINT32 g_oalIrq2SysIntr[AT91RM9200_OAL_INTR_IRQ_MAXIMUM];

/// this variable contains the number of PIOs's bank
DWORD g_dwOalPioBankNumber= NB_PIO_BANK; 

/// PIOs' banks description table. This is used by the generic PIO interrupt engine.
/// \note the following table is for AT91RM9200 only
PIOBANKDESCRIPTION g_PioBankDescTab[NB_PIO_BANK]={
	{AT91C_BASE_PIOA,32,0,0,LOGINTR_BASE_PIOA,AT91C_ID_PIOA,0,0},
	{AT91C_BASE_PIOB,32,0,0,LOGINTR_BASE_PIOB,AT91C_ID_PIOB,0,0},		
	{AT91C_BASE_PIOC,32,0,0,LOGINTR_BASE_PIOC,AT91C_ID_PIOC,0,0}, 		
	{AT91C_BASE_PIOD,32,0,0,LOGINTR_BASE_PIOD,AT91C_ID_PIOD,0,0}, 
};

//------------------------------------------------------------------------------
//
//  Globals.

//Profiler interrupt handler
PFN_PROFILER_ISR g_pProfilerISR = NULL;

//Profiler IRQ
DWORD g_dwProfilerIRQ = 0xFFFFFFFF;

//Interrupts save for future restoration
static DWORD AICResumeMask;

//Pointer to the AIC controller
AT91PS_AIC g_pAIC = 0;

//Pointer to the SYS structure
AT91PS_SYS g_pSYS = 0;

//Pointer to the system timer
AT91PS_ST g_pST = NULL;


//-----------------------------------------------------------------------------
//! \fn			BOOL OALIntrInit()
//!
//! \brief		This function initialize interrupt mapping, hardware and call platform specific initialization.
//!
//! \return 	TRUE if OALIntrInit works well, FALSE if not
//!
//-----------------------------------------------------------------------------
BOOL OALIntrInit()
{
    BOOL result = TRUE;
    int i;
       
    RETAILMSG(1, (L"+OALIntrInit\r\n") );
	g_pSYS = (AT91PS_SYS) OALPAtoVA((DWORD)AT91C_BASE_SYS,FALSE);

	// Setting pAIC
	if (g_pAIC == 0)
	{
		g_pAIC = (AT91PS_AIC) OALPAtoVA((DWORD)AT91C_BASE_AIC,FALSE);

		//Sanity Check
		if (g_pAIC == NULL)
		{
			RETAILMSG(1, (L"+%s OALPAtoVA((DWORD)AT91C_BASE_AIC,FALSE) failed \r\n",__FUNCTION__ ));
			return FALSE;
		}
	}
	
	//Sanity Check
	if (g_pSYS == NULL)
	{
		RETAILMSG(1, (L"+%s OALPAtoVA((DWORD)AT91C_BASE_SYS,FALSE) failed \r\n",__FUNCTION__ ));
		return FALSE;
	}

    // Disable all interrupts
    g_pSYS->AIC_IDCR = -1;
    // clear all interrupts
    g_pSYS->AIC_ICCR = -1;
    
    // Configure the AIC to correctly manage the interrupts from the peripheral controllers.
    // Later the user would be able to change those properties by calling a kernelIoControl (IOCTL_HAL_SET_IRQ_PROPERTIES -not implemented yet-)
    // in order for example to handle interrupt on IRQ0-IRQ6
    for (i = 0; i <= LOGINTR_AIC_LAST; i++) 
    {
		// Create an IRQ descriptor for each AIC entry
		// Init each SMR AIC entry
		g_pSYS->AIC_SVR[i] = i;
		g_pSYS->AIC_SMR[i] = AT91C_AIC_PRIOR_LOWEST | AT91C_AIC_SRCTYPE_INT_LEVEL_SENSITIVE;

		// Perform 8 End Of Interrupt Command to make sure AIC will not Lock out nIRQ
		if (i < 8)
			g_pSYS->AIC_EOICR = g_pSYS->AIC_EOICR;

    }

    // Initialize interrupt mapping
    OALIntrMapInit();
    
    // Initialize PIO controllers
    SOCPioIntrInit();

#ifdef OAL_BSP_CALLBACKS    
	/// \note this functions gives a chance to the BSP to perform something specific here like to initializing a subordinate controller
    result = BSPIntrInit();
#endif

    RETAILMSG(1, (L"-OALIntrInit(rc = %d)\r\n", result));
	// Disable all interrupts
	 
    return result;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL SOCDisableIrq(DWORD irq,BOOL* pOldState)
//!
//! \brief		Turns the interrupt source off
//!				Update the register on the target which masks the irq passed to the CPU.
//!
//! \param		irq IRQ to disable
//! \param		pOldState pointer to a BOOLEAN indicating if the interrupt was previously enabled
//!
//! \return 	TRUE if irq is disable, FALSE if irq hasn't be found
//!
//-----------------------------------------------------------------------------
BOOL SOCDisableIrq(DWORD irq,BOOL* pOldState)
{
    	// Depending on IRQ number use AIC or PIO controler register
        if ((irq >= LOGINTR_AIC_FIRST) && (irq <= LOGINTR_AIC_LAST)) {
            // Use AIC interrupt register
//            RETAILMSG(1, ( L"+SOCDisableIrq(%d) AIC mask %x\r\n", irq , (1<<irq)));
			if (pOldState!=NULL)
			{
				*pOldState = g_pAIC->AIC_IMR & (1<<irq);
			}
            g_pAIC->AIC_IDCR = (1<<irq);
        } 
        else 
        {
        	//try to use PIO registers
        	if (SOCDisablePioIrq(irq, pOldState) == FALSE)
        		return FALSE;
           
        }
	return TRUE;
}



//-----------------------------------------------------------------------------
//! \fn			BOOL SOCEnableIrq(DWORD irq)
//!
//! \brief		Turns the interrupt source on
//!				Update the register on the target which masks the irq passed to the CPU.
//!
//! \param		irq IRQ to disable
//!
//! \return 	TRUE if irq is enable, FALSE if irq hasn't be found
//!
//-----------------------------------------------------------------------------
 BOOL SOCEnableIrq(DWORD irq)
{	
	// Depending on IRQ number use AIC or PIO controler register
        if ((irq >= LOGINTR_AIC_FIRST) && (irq <= LOGINTR_AIC_LAST)) {
            // Use AIC interrupt register
            //RETAILMSG(1, ( L"+SOCEnableIrq(%d) AIC mask %x\r\n", irq , (1<<irq)));
            g_pAIC->AIC_IECR = (1<<irq);
        } 
        else 
        {
        	//try to use PIO registers
        	if (SOCEnablePioIrq(irq) == FALSE)
        		return FALSE;
           
        }
	return TRUE;
}


//-----------------------------------------------------------------------------
//! \fn			void SOCSaveAndDisableAllIntrBeforeSuspend()
//!
//! \brief		Save interrupts mask and turn all interrupt sources off.
//!				This function is called before entering suspend.
//!
//-----------------------------------------------------------------------------
void SOCSaveAndDisableAllIntrBeforeSuspend()
{
	RETAILMSG(1, ( L"+SOCSaveAndDisableAllIntrBeforeSuspend()\r\n" )); 	
 	AICResumeMask = g_pAIC->AIC_IMR;
	g_pAIC->AIC_IDCR = 0xFFFFFFFF; //mask all the interrupts
	SOCPioSaveAndDisableAllIntrBeforeSuspend();
	SOCPioControllerIntrEnable(); //Leave the interrupt for the pio controllers !
}


//-----------------------------------------------------------------------------
//! \fn			void SOCRestoreAllIntrAfterSuspend()
//!
//! \brief		retore the previously backed-up interrupt mask (\sa SOCSaveAndDisableAllIntrBeforeSuspend)
//!				This function is called juste before leaving suspend mode
//!
//-----------------------------------------------------------------------------
void SOCRestoreAllIntrAfterSuspend()
{
	RETAILMSG(1, ( L"+SOCRestoreAllIntrAfterSuspend()\r\n" ));
	g_pAIC->AIC_IECR = AICResumeMask;
	SOCPioRestoreAllIntrAfterSuspend();	
}
 
//-----------------------------------------------------------------------------
//! \fn			BOOL OALIntrRequestIrqs(DEVICE_LOCATION *pDevLoc, UINT32 *pCount, UINT32 *pIrqs)
//!
//! \brief		This function returns IRQs for CPU/SoC devices based on their physical address.
//!
//! \param		pDevLoc	Pointer to device location wich request IRQ
//! \param		pCount	Number of IRQ request
//!	\param		pIRQs	Returns table of IRQs
//!
//! \return		TRUE if IRQs requested are allocated, FALSE if not
//!
//-----------------------------------------------------------------------------
BOOL OALIntrRequestIrqs(DEVICE_LOCATION *pDevLoc, UINT32 *pCount, UINT32 *pIrqs)
{
    BOOL rc = FALSE;

    RETAILMSG(1, (
        L"+OALIntrRequestIrqs(0x%08x->%d/%d/0x%08x/%d, 0x%08x, 0x%08x)\r\n",
        pDevLoc, pDevLoc->IfcType, pDevLoc->BusNumber, pDevLoc->LogicalLoc,
        pDevLoc->Pin, pCount, pIrqs
    ));

    // This shouldn't happen
    if (*pCount >= 1)
	{
	#ifdef OAL_BSP_CALLBACKS
		/// \note this functions gives a chance to the BSP to perform something specific here
		rc = BSPIntrRequestIrqs(pDevLoc, pCount, pIrqs);
	#endif
    }
       
    RETAILMSG(1, (L"-OALIntrRequestIrqs(rc = %d)\r\n", rc));
    return rc;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL OALIntrEnableIrqs(UINT32 count, const UINT32 *pIrqs)
//!
//! \brief		OAL function to enable IRQs based on their physicall interrupt number
//!
//! \param		count	size of pIrqs
//!	\param		pIRQs	table of IRQs
//!
//! \return		TRUE if all IRQs are enabled, FALSE if not
//!
//-----------------------------------------------------------------------------
BOOL OALIntrEnableIrqs(UINT32 count, const UINT32 *pIrqs)
{
    BOOL rc = TRUE;
    UINT32 i, irq;

    for (i = 0; i < count; i++) {
#ifndef OAL_BSP_CALLBACKS
        irq = pIrqs[i];
#else
		/// \note this functions gives a chance to the BSP to perform something specific here like enabling irq on subordinate interrupt controller
        irq = BSPIntrEnableIrq(pIrqs[i]);
#endif
        if (irq == OAL_INTR_IRQ_UNDEFINED) continue;
        
        if (SOCEnableIrq(irq) == FALSE)
        	rc = FALSE;
    }        

 return rc;    
}


//-----------------------------------------------------------------------------
//! \fn			VOID OALIntrDisableIrqs(UINT32 count, const UINT32 *pIrqs)
//!
//! \brief		OAL function to disable IRQs based on their physicall interrupt number
//!
//! \param		count	size of pIrqs
//!	\param		pIRQs	table of IRQs
//!
//-----------------------------------------------------------------------------
VOID OALIntrDisableIrqs(UINT32 count, const UINT32 *pIrqs)
{
    UINT32 i, irq;

    

    for (i = 0; i < count; i++) {
#ifndef OAL_BSP_CALLBACKS
        irq = pIrqs[i];
#else
		/// \note this functions gives a chance to the BSP to perform something specific here like disabling irq on subordinate interrupt controller
        irq = BSPIntrDisableIrq(pIrqs[i]);
#endif
        if (irq == OAL_INTR_IRQ_UNDEFINED) continue;
        
        SOCDisableIrq(irq, 0);
    }        
}



//-----------------------------------------------------------------------------
//! \fn			VOID OALIntrDoneIrqs(UINT32 count, const UINT32 *pIrqs)
//!
//! \brief		OAL function to finish IRQs based on their physicall interrupt number
//!				On this architecture this is mostly the same as enabling the interrupt
//!
//! \param		count	size of pIrqs
//!	\param		pIRQs	table of IRQs
//!
//-----------------------------------------------------------------------------
VOID OALIntrDoneIrqs(UINT32 count, const UINT32 *pIrqs)
{
    UINT32 i, irq;


    for (i = 0; i < count; i++) {
#ifndef OAL_BSP_CALLBACKS
        irq = pIrqs[i];
#else
		/// \note this functions gives a chance to the BSP to perform something specific here like finishing the irq on subordinate interrupt controller
        irq = BSPIntrDoneIrq(pIrqs[i]);
#endif    
       if (irq == OAL_INTR_IRQ_UNDEFINED) continue;
        
        // Depending on IRQ number use AIC or PIO controler register
        
        SOCEnableIrq(irq);
     }

}


//-----------------------------------------------------------------------------
//! \fn			int OEMInterruptHandler(unsigned int ra)
//!
//! \brief		This is the main Interrupt handler
//!
//! \param		ra is reserved for future use. In case of a kernel with profiler enabled it's the location of the PC when the interrupt occured
//!
//!	\return		SYSIntr corresponding to Interrupt occured
//!
//-----------------------------------------------------------------------------
int OEMInterruptHandler(unsigned int ra)
{

	ULONG nSysIntr = SYSINTR_NOP;
	DWORD nIVR;
    extern volatile UINT32 g_oalLastSysIntr;
	DWORD dwTempCountSinceSysTick = OALTimerCountsSinceSysTick();

	//Sanity Check
	if (g_pSYS == NULL)
	{
		g_pSYS = (AT91PS_SYS) OALPAtoVA((DWORD)AT91C_BASE_SYS,FALSE);
		if (g_pSYS == NULL)
		{
			RETAILMSG(1, (L"+%s OALPAtoVA((DWORD)AT91C_BASE_SYS,FALSE) failed \r\n",__FUNCTION__ ));
			return SYSINTR_NOP;
		}
	}

	//Sanity Check
	if (g_pST == NULL)
	{
		g_pST = (AT91PS_ST) OALPAtoVA((DWORD)AT91C_BASE_ST,FALSE);
		if (g_pST == NULL)
		{
			RETAILMSG(1, (L"+%s OALPAtoVA((DWORD)AT91C_BASE_ST,FALSE) failed \r\n",__FUNCTION__ ));
			return SYSINTR_NOP;
		}
	}

	nIVR = g_pSYS->AIC_IVR;

    //First aknowledge the interrupt at the AIC level
	g_pSYS->AIC_EOICR = g_pSYS->AIC_EOICR;

	//Then check if it's a system controller interrupt
	if (nIVR == AT91C_ID_SYS) 
	{
#if 0	//if a System Timer Interrupt occured, then call the timer interrupt handler
	    if (g_pST->ST_SR & AT91C_ST_PITS) 
	    {
	        nSysIntr = OALTimerIntrHandlerWithILTSupport(dwTempCountSinceSysTick);
		}
	    
	    else if (XXXXXXX) //Other system controller interrupt management
	    {
	        
	    }
#endif	    
	    
	}
	else if(nIVR == AT91C_ID_TC0)
	{
	    nSysIntr = OALTimerIntrHandlerWithILTSupport(dwTempCountSinceSysTick);		
	}
	//if a profiler Interrupt occured, then call the profiler interrupt handler
	else if ((nIVR == g_dwProfilerIRQ) && (g_pProfilerISR))
	{
		nSysIntr = g_pProfilerISR(ra); 
	}
	//If this is another interrupt then it must be a device's interrupt
    else
    {
		DWORD oldInt = nIVR;

		// \par
    	// First let the SOC-dedicated interrupt susbsytem check if this is a pio interrupt
    	nIVR = SOCIntrActiveIrq(nIVR);


#ifdef OAL_BSP_CALLBACKS
		// \par
        // Then let the BSP-specific interrupt susbsytem check if it wants to say that's another interrupt number (think of secondary interrupt controller on board, then it makes sense)
        nIVR = BSPIntrActiveIrq(nIVR);
#endif

		// \par
    	// Mask the interrupt so that it won't occur again before being finished with SOCInterruptDone
    	SOCDisableIrq(nIVR, 0);
  	

		// \par
    	// Then find if IRQ is claimed by chain (see NKCallIntChain and LoadIntrChainHandler in PB doc)
        nSysIntr = NKCallIntChain((UCHAR)nIVR);

        if (nSysIntr == SYSINTR_CHAIN || !NKIsSysIntrValid(nSysIntr))
		{
			// \par
            // If the IRQ wasn't claimed by the chain, we use static LOGINTR -> SYSINTR mapping.
            nSysIntr = OALIntrTranslateIrq(nIVR);
        }
	

        if (nSysIntr == SYSINTR_NOP || nSysIntr == SYSINTR_UNDEFINED || !NKIsSysIntrValid(nSysIntr))
		{
			/// \par
			/// \par
            ///If not a valid sysintr then put the inteerupt back to normal (enabled)
            /// \note what's the point to enabling an interrupt that's handled ?.......
			/// answer is : To do some ISR treatment only !
			/// \warning Beware that this a flaw in the robustness of the kernel; If an interrupt is triggered 
			/// and not acknowledged at the peripheral level, it may trigger again and again ... and again. And the system will be stopped in this loop
            SOCEnableIrq(nIVR);

        }
    }
	
    ///save the last Sysintr value. It's used by the suspend system and the fake idle routine
	g_oalLastSysIntr = nSysIntr; 
    
	return nSysIntr;
}

//! @}

