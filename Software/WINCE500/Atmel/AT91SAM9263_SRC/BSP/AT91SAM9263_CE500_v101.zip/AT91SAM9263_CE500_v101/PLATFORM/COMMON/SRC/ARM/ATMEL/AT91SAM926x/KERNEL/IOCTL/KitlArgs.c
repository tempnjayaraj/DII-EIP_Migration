//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		KitlArgs.c 
//!
//! \brief		implements AT91SAM926x GetMasterClock feature
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/IOCTL/KitlArgs.c $
//!   $Author: pblanchard $
//!   $Revision: 1090 $
//!   $Date: 2007-07-13 07:07:28 -0700 (Fri, 13 Jul 2007) $
//! \endif
//-----------------------------------------------------------------------------


//! \addtogroup	IOCTL
//! @{

#include <windows.h>
#include <oal.h>

#include "at91sam926x.h"
#include "AT91SAM926x_interface.h"

//-----------------------------------------------------------------------------
//! \fn			BOOL OALIoCtlHalGetKitlArgs(	UINT32 code, VOID *pInpBuffer, UINT32 inpSize, VOID *pOutBuffer, UINT32 outSize, UINT32 *pOutSize)
//!
//! \brief		This function returns the Kitl Args Structure
//!
//!	\param		code			not used
//!	\param		pInpBuffer	not used
//!	\param		inpSize		not used
//!	\param		pOutBuffer	KITL args
//!	\param		outSize		Size of pOutBuffer
//!	\param		pOutSize		Size of pOutBuffer used
//!
//! \return		TRUE indictaes success
//! \return		FALSE indictaes failure (bad parameters)
//!
//-----------------------------------------------------------------------------
BOOL OALIoCtlHalGetKitlArgs(	UINT32 code, VOID *pInpBuffer, 
								UINT32 inpSize, VOID *pOutBuffer, 
								UINT32 outSize, UINT32 *pOutSize)
{
	OAL_KITL_ARGS* pKitl;
	
	if ( pOutBuffer==NULL || outSize<sizeof(OAL_KITL_ARGS) )
	{
		return FALSE;
	}

	pKitl = (OAL_KITL_ARGS*) OALArgsQuery(OAL_ARGS_QUERY_KITL);

	if(pKitl !=  INVALID_HANDLE_VALUE)
	{
		memcpy( pOutBuffer, pKitl, sizeof(OAL_KITL_ARGS));
	}

	if (pOutSize!=0)
	{
		*pOutSize = sizeof(OAL_KITL_ARGS);
	}

	return TRUE;
}

//! @} end of subgroup IOCTL

//! @} end of group OAL

///////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/IOCTL/KitlArgs.c $
////////////////////////////////////////////////////////////////////////////////
//
