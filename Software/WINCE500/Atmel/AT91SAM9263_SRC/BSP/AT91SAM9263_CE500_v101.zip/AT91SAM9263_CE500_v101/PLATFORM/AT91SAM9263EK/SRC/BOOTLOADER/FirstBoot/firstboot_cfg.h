//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//-----------------------------------------------------------------------------
//! \file		firstboot_cfg.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/BOOTLOADER/FirstBoot/firstboot_cfg.h $
//!   $Author: ltourlonias $
//!   $Revision: 684 $
//!   $Date: 2007-04-13 14:35:48 +0200 (ven., 13 avr. 2007) $
//! \endif
//!
//! Header for firstboot configuration
//-----------------------------------------------------------------------------
//! \addtogroup	FIRSTBOOT
//! @{
//!  

#ifndef _FIRSTBOOT_CFG_H
#define _FIRSTBOOT_CFG_H

#include "bootloader_cfg.h"

//--------------------------------------------------------------
// Type of support for eboot :
// - SPI Dataflash CS0 (for Serial Dataflash slot B)
// - SPI Dataflash CS1 (for Serial Dataflash slot A)
// - NandFlash CS3 (for internal nandflash)
//--------------------------------------------------------------
#define EBOOT_FLASH_CODE_ADDR		DATAFLASH_CS0_LOGIC_BASE_ADDR | DATAFLASH_BOOTLOADER_CODE_LOGICAL_OFFSET
#define EBOOT_FLASH_SETTINGS_ADDR	DATAFLASH_CS0_LOGIC_BASE_ADDR | DATAFLASH_BOOTLOADER_SETTINGS_LOGICAL_OFFSET

//--------------------------------------------------------------
// Low level initializer configuration
//--------------------------------------------------------------
#define AT91C_MASTER_CLOCK      48000000
#define DBGU_BAUDRATE			115200
#define AT91C_US_ASYNC_MODE		( AT91C_US_USMODE_NORMAL + \
								  AT91C_US_NBSTOP_1_BIT  + \
		                          AT91C_US_PAR_NONE		 + \
				                  AT91C_US_CHRL_8_BITS   + \
						          AT91C_US_CLKS_CLOCK )

#endif
//! @}

//! @}