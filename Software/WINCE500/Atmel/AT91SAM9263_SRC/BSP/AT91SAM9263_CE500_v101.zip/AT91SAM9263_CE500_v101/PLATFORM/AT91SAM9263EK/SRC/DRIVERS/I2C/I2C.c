//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9263EK/SRC/DRIVERS/I2C/i2c.c
//!
//! \brief		i2c.c
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/I2C/i2c.c $
//!   $Author: ltourlonias $
//!   $Revision: 684 $
//!   $Date: 2007-04-13 14:35:48 +0200 (ven., 13 avr. 2007) $
//! \endif
//!
//! This driver manages 3 PWM channels and each channel can drive 2 PWM signals
//-----------------------------------------------------------------------------
//! \addtogroup	I2C
//! @{
//!

// System include
#include <windows.h>

// Local include
#include "AT91SAM926x.h"
#include "lib_AT91SAM926x.h"
#include "AT91SAM926x_i2c_ioctl.h"
#include "at91sam9263_gpio.h"
#include "atmel_gpio.h"

//-----------------------------------------------------------------------------
//! \fn			BOOL I2C_InitHW ()
//!
//! \brief		This function configures the TWI Peripheral PIOs
//!
//! \return		\e TRUE when all is good
//!	\return		\e FALSE when all is bad
//!
//! This function intialize TWI hardware
//-----------------------------------------------------------------------------
BOOL I2C_InitHW ()
{
	BOOL bRet = TRUE;
	const struct pio_desc hw_pio[] = 
	{
		{"TWD", AT91C_PIN_PB(4), 0, PIO_PULLUP, PIO_PERIPH_A},
		{"TWCK", AT91C_PIN_PB(5), 0, PIO_PULLUP, PIO_PERIPH_A},
	};

	// Configure PIO controllers to periph mode
	pio_setup(hw_pio, sizeof(hw_pio)/sizeof(struct pio_desc));
	return bRet;
}

// End of Doxygen group I2C Driver
//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/I2C/i2c.c $
//-----------------------------------------------------------------------------

//! @}
