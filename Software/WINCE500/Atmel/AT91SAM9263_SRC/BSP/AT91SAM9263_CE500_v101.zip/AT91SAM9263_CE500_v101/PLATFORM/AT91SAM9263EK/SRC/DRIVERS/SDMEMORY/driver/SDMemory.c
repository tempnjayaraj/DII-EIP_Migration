//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//!	\file		AT91SAM9263EK/SRC/DRIVERS/SDMEMORY/driver/sdmemory.c
//!
//! \brief		Specific part of the SD Memory Card driver
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/SDMEMORY/driver/sdmemory.c $
//!   $Author: ltourlonias $
//!   $Revision: 971 $
//!   $Date: 2007-06-08 11:57:40 +0200 (ven., 08 juin 2007) $
//! \endif
//! 
//! Board-dependent part of the SDMemory driver (PIO configuration)
//-----------------------------------------------------------------------------
//! \addtogroup	SDMEMORY
//! @{
//

// System specific include
#include <windows.h>
#include <ceddk.h>

// Platform specific include
#include "AT91SAM926x.h"
#include "AT91SAM9263EK.h"
#include "at91sam9263_gpio.h"

#define SD_MAX_CLOCK		15000000	// Hz

static HANDLE g_hMutex;

//-----------------------------------------------------------------------------
//! \fn			BOOL SDMemoryBoardSpecificInit(DWORD dwSlotNumber)
//!
//! \brief		Initialize the specific platform 
//!			Create a mutex for sharing the SPI/MCI pins
//!
//! \param		dwSlotNumber : Slot Number, if several slots exist on the board
//!
//! \return		\e TRUE When all is good
//!	\return		\e FALSE When there is an error during initialization
//-----------------------------------------------------------------------------
BOOL SDMemoryBoardSpecificInit(DWORD dwSlotNumber)
{
	BOOL bRet = TRUE;
	
	if (dwSlotNumber == 1)
	{
		// creation of the mutex for sharing the SPI/MCI pins
		g_hMutex = CreateMutex(NULL, FALSE, SPI_MCI_BUS_MUTEX);
		if (g_hMutex == NULL)
		{
			bRet = FALSE;
		}
	}
	return bRet;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL SDMemoryBoardSpecificDeInit(DWORD dwSlotNumber)
//!
//! \brief		DeInitialize the specific platform
//!			
//! \param		dwSlotNumber : Slot Number, if several slots exist on the board
//!			
//!
//-----------------------------------------------------------------------------
void SDMemoryBoardSpecificDeInit(DWORD dwSlotNumber)
{
	if (dwSlotNumber == 1)
	{
		HANDLE hTemp = g_hMutex;
		g_hMutex = NULL;
		CloseHandle(hTemp);
	}
}

//-----------------------------------------------------------------------------
//! \fn			BOOL SDMemoryBoardSpecificGetBus(DWORD dwSlotNumber)
//!
//! \brief		Get the SPI bus during a transfer
//!
//! \param		dwSlotNumber : Slot Number, if several slots exist on the board
//!
//! \return		\e TRUE When all is good
//!	\return		\e FALSE When there is an error 
//-----------------------------------------------------------------------------
BOOL SDMemoryBoardSpecificGetBus(DWORD dwSlotNumber)
{
	BOOL bRet;
	
	if (dwSlotNumber == 1)
	{
		DWORD dwWaitRet;

		bRet = FALSE;
		if(g_hMutex != NULL)
		{
			dwWaitRet = WaitForSingleObject(g_hMutex, INFINITE );
			if ( dwWaitRet != WAIT_TIMEOUT )
			{
				bRet = TRUE;
			}
		}
		else
		{
			RETAILMSG(1, (L"HWSPIControllerBoardSpecificGetBus : Invalid Handle"));
		}
	}
	else
	{
		bRet = TRUE;
	}
	return bRet;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL SDMemoryBoardSpecificReleaseBus(DWORD dwSlotNumber)
//!
//! \brief		Release the Mutex afeter a transfer
//!
//! \param		dwSlotNumber : Slot Number, if several slots exist on the board
//!
//! \return		\e TRUE When all is good
//!	\return		\e FALSE When there is an error 
//-----------------------------------------------------------------------------
BOOL SDMemoryBoardSpecificReleaseBus(DWORD dwSlotNumber)
{
	BOOL bRet;
	if (dwSlotNumber == 1)
	{
		bRet = FALSE;
		if (g_hMutex != NULL)
		{
			ReleaseMutex(g_hMutex);
			bRet = TRUE;
		}
		else
		{
			RETAILMSG(1, (L"HWSPIControllerBoardSpecificReleaseBus : Invalid Handle"));
		}
	}
	else
	{
		bRet = TRUE;
	}
	return bRet;
}


//-----------------------------------------------------------------------------
//! \fn			DWORD SDMemoryBoardSpecificGetMCIID(DWORD dwSlotNumber)
//!
//! \param		dwSlotNumber : Slot Number, if several slots exist on the board
//!
//! \brief		Retreive the ID of the MCI controller
//! This is needed in case there are many controllers (like in AT91SAM9263EK)
//!
//!
//! \return		\e The ID of the MCI controller
//-----------------------------------------------------------------------------
DWORD SDMemoryBoardSpecificGetMCIID(DWORD dwSlotNumber)
{
	switch (dwSlotNumber)
	{
		case 0:
			return AT91C_ID_MCI1;
		case 1:
			return AT91C_ID_MCI0;		
		default :
			return 0;
	}
}

//-----------------------------------------------------------------------------
//! \fn			DWORD SDMemoryBoardSpecificGetMCIBase(DWORD dwSlotNumber)
//!
//! \param		dwSlotNumber : Slot Number, if several slots exist on the board
//!
//! \brief		Retreive the base address of the MCI controller
//! This is needed in case there are many controllers (like in Nadia 2)
//!
//!
//! \return		\e The physical base address of the controller
//-----------------------------------------------------------------------------
DWORD SDMemoryBoardSpecificGetMCIBase(DWORD dwSlotNumber)
{
	switch (dwSlotNumber)
	{
		case 0:
			return (DWORD) AT91C_BASE_MCI1;
		case 1:
			return (DWORD) AT91C_BASE_MCI0;
		default :
			return 0;
	}
	
}


//-----------------------------------------------------------------------------
//! \fn			BOOL SDMemoryBoardSpecificPIOConfiguration(DWORD dwSlotNumber)
//!
//! \brief		Initializes the PIOs for the given SD/MMC Slot
//! This PIO configuration is not compatible with the SPI configuration
//!
//! \param		dwSlotNumber : Slot Number, if several slots exist on the board
//!
//! \return		\e TRUE When all is good
//!	\return		\e FALSE When there is an error during PIO configuration
//-----------------------------------------------------------------------------
BOOL SDMemoryBoardSpecificPIOConfiguration(DWORD dwSlotNumber)
{
	BOOL bResult = TRUE;

	static const struct pio_desc hw_pioSLOT0[] = 
	{
		{"MCI1DA0",	AT91C_PIN_PA(8), 0, PIO_DEFAULT, PIO_PERIPH_A},
		{"MCI1CDA",	AT91C_PIN_PA(7), 0, PIO_PULLUP, PIO_PERIPH_A},
		{"MCI1CK",	AT91C_PIN_PA(6), 0, PIO_PULLUP, PIO_PERIPH_A},
		{"MCI1DA1",	AT91C_PIN_PA(9), 0, PIO_PULLUP, PIO_PERIPH_A},
		{"MCI1DA2",	AT91C_PIN_PA(10), 0, PIO_PULLUP, PIO_PERIPH_A},
		{"MCI1DA3",	AT91C_PIN_PA(11), 0, PIO_PULLUP, PIO_PERIPH_A},
	};

	static const struct pio_desc hw_pioSLOT1[] = 
	{
		{"MCI0DB0",	AT91C_PIN_PA(0), 0, PIO_DEFAULT, PIO_PERIPH_A},
		{"MCI0CDB",	AT91C_PIN_PA(1), 0, PIO_PULLUP, PIO_PERIPH_A},
		{"MCI0DB3",	AT91C_PIN_PA(5), 0, PIO_PULLUP, PIO_PERIPH_A},
		{"MCI0DB2",	AT91C_PIN_PA(4), 0, PIO_PULLUP, PIO_PERIPH_A},
		{"MCI0DB1",	AT91C_PIN_PA(3), 0, PIO_PULLUP, PIO_PERIPH_A},
		{"MCI0CK",	AT91C_PIN_PA(12), 0, PIO_PULLUP, PIO_PERIPH_A},	
		{"PE20",	AT91C_PIN_PE(20), 0, PIO_PULLUP, PIO_OUTPUT},	
	};

	switch (dwSlotNumber)
	{
		case 0:
				{
				pio_setup(hw_pioSLOT0, sizeof(hw_pioSLOT0));
			}
			break;		
		case 1:
				{
				pio_setup(hw_pioSLOT1, sizeof(hw_pioSLOT1));
				}
			break;		
		default:
			return FALSE;
	}

	
	return bResult;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL SDMemoryBoardSpecificIsWriteProtected(DWORD dwSlotNumber)
//!
//! \brief		\return the write protect status of the card in the given Slot
//! \param		dwSlotNumber : Slot Number, if several slots exist on the board
//!
//! \return		\e TRUE When protected
//!	\return		\e FALSE When not protected
//-----------------------------------------------------------------------------
BOOL SDMemoryBoardSpecificIsWriteProtected(DWORD dwSlotNumber)
{
	BOOL bWriteProtected;
	static const struct pio_desc hw_pioSLOT0 = {"WriteProtected",	AT91C_PIN_PE(19), 0, PIO_DEFAULT, PIO_INPUT};	
	static const struct pio_desc hw_pioSLOT1 = {"WriteProtected",	AT91C_PIN_PE(17), 0, PIO_DEFAULT, PIO_INPUT};	
		
	switch (dwSlotNumber)
	{
		case 0:
			pio_setup(&hw_pioSLOT0, sizeof(hw_pioSLOT0)/sizeof(struct pio_desc));
			if (pio_get_value(AT91C_PIN_PE(19)))
			{		
				bWriteProtected = TRUE;
			}
			else
			{		
				bWriteProtected = FALSE;
			}
			break;
		case 1:
			pio_setup(&hw_pioSLOT1, sizeof(hw_pioSLOT1)/sizeof(struct pio_desc));
			if (pio_get_value(AT91C_PIN_PE(17)))
	{		
		bWriteProtected = TRUE;
	}
	else
	{		
		bWriteProtected = FALSE;
	}
			break;
		default :
			return FALSE;
	}
	
	DEBUGMSG(1,(TEXT("SCARD on Slot %c is %s write-protected\r\n"),(dwSlotNumber == 0) ? 'A':'B',bWriteProtected ? L"":L"NOT"));

	return bWriteProtected;
}

#define SLOT_A	0
//-----------------------------------------------------------------------------
//! \fn			DWORD SDMemoryBoardSpecificGetSlotID(DWORD dwSlotNumber)
//!
//! \brief		return the Slot ID at the controller level (A or B) used for this slot
//! \param		dwSlotNumber : Slot Number, if several slots exist on the board
//!
//! \return		\e TRUE When protected
//!	\return		\e FALSE When not protected
//-----------------------------------------------------------------------------
DWORD SDMemoryBoardSpecificGetSlotID(DWORD dwSlotNumber)
{
	return SLOT_A;	//Both MMC/SDCARD connector are connected to SLOT A of the controller
}

//-----------------------------------------------------------------------------
//! \fn			DWORD SDMemoryBoardSpecificGetMaxClock(void)
//!
//! \brief		return the SD Maximum Clock used for this board
//!
//! \return		SD_MAX_CLOCK The Maximum clock frequency for the board
//-----------------------------------------------------------------------------
DWORD SDMemoryBoardSpecificGetMaxClock(void)
{
	return SD_MAX_CLOCK;	
}

//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK60/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/SDMEMORY/driver/sdmemory.c $
//-----------------------------------------------------------------------------
//

//! @}
