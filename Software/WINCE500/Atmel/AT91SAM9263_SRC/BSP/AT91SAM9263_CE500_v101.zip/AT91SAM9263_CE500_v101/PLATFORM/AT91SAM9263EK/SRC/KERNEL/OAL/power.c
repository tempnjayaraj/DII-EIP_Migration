//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		OAL\power.c
//!
//! \brief		Implements the BSP specific power management
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/KERNEL/OAL/power.c $
//!   $Author: jjhiblot $
//!   $Revision: 107 $
//!   $Date: 2006-02-15 14:27:38 +0100 (mer., 15 févr. 2006) $
//! \endif
//-----------------------------------------------------------------------------


//! \addtogroup	POWER
//! @{

#include <windows.h>
#include <oal.h>
#include "at91sam926x.h"

//-----------------------------------------------------------------------------
//! \fn			  VOID BSPPowerOff(DWORD *pdwSavePCConfig, DWORD *pdwSaveSCConfig)
//!
//! \param  pdwSavePCConfig
//! \param  pdwSaveSCConfig
//!
//! \brief		This function is to give a chance to the BSP to perform whatever 
//!     required action before the system is going into suspend
//!
//!
//-----------------------------------------------------------------------------
VOID BSPPowerOff(DWORD *pdwSavePCConfig, DWORD *pdwSaveSCConfig)
{
	AT91PS_PMC pPMC = OALPAtoVA((DWORD)AT91C_BASE_PMC,FALSE);

	RETAILMSG(1,(TEXT("BSPPowerOff\r\n")));
	// Save the settings in order to restore them after a resume
	*pdwSavePCConfig = pPMC->PMC_PCSR;
	*pdwSaveSCConfig = pPMC->PMC_SCSR;

	//stop unecessary clock
	// The PIOC should be awake for resume, PIOA maybe for the Touschscreen IRQ
	// For the others three, poweroff should be implemented in the driver code, in order to correctly manage the poweroff
	pPMC->PMC_PCDR = ~((1 << AT91C_ID_PIOCDE) | (1 << AT91C_ID_PIOA) | (1 << AT91C_ID_AC97C) | (1 << AT91C_ID_2DGE) | (1 << AT91C_ID_EMAC));		//0xFF5BFFEB
	pPMC->PMC_SCDR = ~(AT91C_PMC_PCK);
}


//-----------------------------------------------------------------------------
//! \fn			  VOID BSPPowerOn(DWORD dwSavePCConfig, DWORD dwSaveSCConfig)
//!
//! \param  dwSavePCConfig
//! \param  dwSaveSCConfig
//!
//! \brief		This function is to give a chance to the BSP to perform whatever 
//!     required action after the system resumes from suspend
//!
//!
//-----------------------------------------------------------------------------
VOID BSPPowerOn(DWORD dwSavePCConfig, DWORD dwSaveSCConfig)
{
	AT91PS_PMC pPMC = OALPAtoVA((DWORD)AT91C_BASE_PMC,FALSE);

	// Restore the settings saved in BSPPowwerOff
	pPMC->PMC_SCER = dwSaveSCConfig;
	pPMC->PMC_PCER = dwSavePCConfig;
	RETAILMSG(1,(TEXT("BSPPowerOn\r\n")));
}


//----------------------------------------------------------------------
//! \brief This function is to give a chance to the BSP to perform whatever required action before the system shuts down.(put the SDRAM in self-refresh for example)

BOOL BSPIoCtlHalShutdown (UINT32 code, VOID *pInpBuffer,UINT32 inpSize, VOID *pOutBuffer,UINT32 outSize, UINT32 *pOutSize)
{
/* JJH this is a sample code, provided to show how to put the SDRAM in sleep mode. This is useless on at91sam9263ek since the /SD pin of the SDRAM's power supply  is asserted during shutdown
	AT91PS_SDRAMC pSDRAM = OALPAtoVA((DWORD)AT91C_BASE_SDRAMC0,FALSE);
	//Put SDRAM in POWER DOWN mode
	pSDRAM->SDRAMC_LPR = AT91C_SDRAMC_LPCB_POWER_DOWN | AT91C_SDRAMC_TIMEOUT_128_CLK_CYCLES;
*/

	// The real thing to do for at91sam9263ek is to tell the system that the next boot will be a cold boot because SDRAM is not retained
	NKForceCleanBoot();
	return TRUE;
}

//! @} end of subgroup POWER

//! @} end of group OAL

//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/KERNEL/OAL/power.c $
//-----------------------------------------------------------------------------
//
