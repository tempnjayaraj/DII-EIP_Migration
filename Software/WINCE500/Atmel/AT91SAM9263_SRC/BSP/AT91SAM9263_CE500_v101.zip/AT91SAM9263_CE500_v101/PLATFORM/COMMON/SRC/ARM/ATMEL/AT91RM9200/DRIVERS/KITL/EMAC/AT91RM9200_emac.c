//-----------------------------------------------------------------------------
//! \addtogroup   KITL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				AT91RM9200_emac.c
//!
//! \brief				Routines for the AT91 ethernet controller used for the Windows CE
//!					debug ethernet services, and bootloaders
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/DRIVERS/KITL/EMAC/AT91RM9200_emac.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//!		Based on ne2000.c in ethdbg/ne2000 in public directory and on linux port
//!			of at 91rm9200 ethernet driver
//!			Change applied : basic use of ethernet controller
//-----------------------------------------------------------------------------
#include <windows.h>
#include <halether.h>
#include "AT91RM9200_EMAC.h"
#include "oal_memory.h"

// Multicast not handled


//
// Structure to track receive packets
//
#define RCV_Q_SIZE 32
typedef struct _RCV_ENTRY {
	BYTE re_state;
	WORD re_len;		// packet length
	UCHAR* re_ptr;  	  // location in card's buffer
} RCV_ENTRY, * PRCV_ENTRY;

//
// Receive
//

#define EMAC_DESC_DONE 0x00000001  // ownership bit
#define EMAC_DESC_WRAP 0x00000002  // bit for wrap

#define RCV_FREE 0
#define RCV_USED 1

static RCV_ENTRY g_rcv_list[RCV_Q_SIZE];

static DWORD g_rcv_index;   // Next RCV_ENTRY to use
static DWORD g_rcv_next;	// Next RCV_ENTRY to indicate
static DWORD g_rcv_cnt; 	// Number of packets to indicate

static UCHAR g_uc_eth_buff[RCV_Q_SIZE][AT91C_EMAC_RXBUFF_SZ];
static DWORD g_dlist_index;

struct rbf_t {
	unsigned char* addr;
	unsigned long size;
};  // descriptor table entry

struct rec_des_bufs {
	struct rbf_t descriptors[MAX_RX_BUFFS];  // must be on sizeof (rbf_t) boundary 
	unsigned char* virt_addr[MAX_RX_BUFFS];  // virtual addr copy of descriptors[].addr 
	unsigned int rec_buf[MAX_RX_BUFFS][AT91C_EMAC_RXBUFF_SZ / sizeof(unsigned int)];  // must be on long boundary 
};





struct rec_des_bufs* g_dlist;  // descriptor list address
UCHAR *g_TransmitBuffer;


// Transmit
static BYTE transmitting;
static WORD curr_xmit_len;


// Mask to use for interrupts
static WORD wIntMask;

static BYTE g_ethernetAddr[6];


static AT91PS_SYS g_pSys;
static AT91PS_EMAC g_pEmac;

// Bitmask for configuration options passed to us from bootloader/kernel.
static DWORD dwConfigOptions;

static void InitRcvQueue(void);
static void HWAccess(WORD addr, WORD count, PWORD mem, BYTE direction);


//#define AT91_DUMP_FRAMES

#ifdef AT91_DUMP_FRAMES
static void DumpEtherFrame(BYTE* pFrame, WORD cwFrameLength);
#endif


static AT91PS_PhyOps g_pPhyOps = NULL;






///////////////////////////////////////////////////////////////////////////
//   PhyHWInit - completely initialize the hardware and leave it in a
//  		state that is ready to transmit and receive packets.
///////////////////////////////////////////////////////////////////////////
static BOOL PhyHWInit(void)
{
	BOOL bRet = FALSE;
	
	// Initialize the interface struct to drive the Phy
	g_pPhyOps = AT91_GetPhyInterface();

	bRet = g_pPhyOps->Init(g_pEmac);

	return bRet;
} // PhyHWInit


///////////////////////////////////////////////////////////////////////////
// AT91F_MDIO_ResetPhy - This function reset the phy, so the phy can acquire is phyaddr
///////////////////////////////////////////////////////////////////////////
void AT91F_MDIO_ResetPhy(void)
{
	AT91PS_PIO pPIOA = OALPAtoVA((DWORD)AT91C_BASE_PIOA,FALSE);
	AT91PS_SYS pSYS = OALPAtoVA((DWORD)AT91C_BASE_SYS,FALSE);
	EdbgOutputDebugString("+AT91F_MDIO_ResetPhy\n");
	
	// Set Controler Address (pin name : ADR0 and ASR1)
	// ADR2 = 0 (IO AT91C_PA13_ERX1)
	((AT91PS_PIO)pPIOA)->PIO_PER = AT91C_PA13_ERX1; // Set in PIO mode
	((AT91PS_PIO)pPIOA)->PIO_OER = AT91C_PA13_ERX1; // Configure in Output
	((AT91PS_PIO)pPIOA)->PIO_CODR = AT91C_PA13_ERX1;

	// ADR1 = 0 (IO AT91C_PA12_ERX0)
	((AT91PS_PIO)pPIOA)->PIO_PER = AT91C_PA12_ERX0; // Set in PIO mode
	((AT91PS_PIO)pPIOA)->PIO_OER = AT91C_PA12_ERX0; // Configure in Output
	((AT91PS_PIO)pPIOA)->PIO_CODR = AT91C_PA12_ERX0;

	// Set normal mode (not test mode) (pin name : RX_DV/TESTMODE)
	((AT91PS_PIO)pPIOA)->PIO_PER = AT91C_PA11_ECRS_ECRSDV; // Set in PIO mode
	((AT91PS_PIO)pPIOA)->PIO_OER = AT91C_PA11_ECRS_ECRSDV; // Configure in Output
	((AT91PS_PIO)pPIOA)->PIO_CODR = AT91C_PA11_ECRS_ECRSDV;

	// PIO Disable Register
	pSYS->PIOA_PDR =	AT91C_PA13_ERX1 |
								AT91C_PA12_ERX0 |
								AT91C_PA11_ECRS_ECRSDV ; 	// PIO Disable Register

	EdbgOutputDebugString("-AT91F_MDIO_ResetPhy\n");
}


///////////////////////////////////////////////////////////////////////////
//////////// EMAC functions 
///////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////
// 	AT91_EmacHWInit - Initialise PIO for Emac and enable the clock in the PMC 
///////////////////////////////////////////////////////////////////////////
static void AT91_EmacHWInit(void)
{
	// PIO configuration
	g_pSys->PIOA_PDR =	AT91C_PA16_EMDIO		|
						AT91C_PA15_EMDC			|
						AT91C_PA14_ERXER		|
						AT91C_PA13_ERX1			|
						AT91C_PA12_ERX0			|
						AT91C_PA11_ECRS_ECRSDV	|
						AT91C_PA10_ETX1			|
						AT91C_PA9_ETX0			|
						AT91C_PA8_ETXEN			|
						AT91C_PA7_ETXCK_EREFCK; 	// PIO Disable Register

	g_pSys->PIOA_ASR =	AT91C_PA16_EMDIO		|
						AT91C_PA15_EMDC			|
						AT91C_PA14_ERXER		|
						AT91C_PA13_ERX1			|
						AT91C_PA12_ERX0			|
						AT91C_PA11_ECRS_ECRSDV	|
						AT91C_PA10_ETX1			|
						AT91C_PA9_ETX0			|
						AT91C_PA8_ETXEN			|
						AT91C_PA7_ETXCK_EREFCK; 	// PIO Disable Register

	g_pSys->PIOB_PDR = AT91C_PB25_EF100 | AT91C_PB19_ERXCK;

	g_pSys->PIOB_BSR = AT91C_PB25_EF100 | AT91C_PB19_ERXCK;  // Select B Register
	g_pSys->PMC_PCER = 1 << AT91C_ID_EMAC;  // Peripheral Clock Enable Register

}

///////////////////////////////////////////////////////////////////////////
// 	AT91_SetHWaddr - Initializes the static var ethernetAddress  
//  with the MAC address (function called by the bootloader).
//  The MAC address will be written later by AT91F_EMACInit.
///////////////////////////////////////////////////////////////////////////
void AT91_SetHWaddr(char* pMACAddress)
{
	int n;

	for (n = 0; n < 6; n++) {
		g_ethernetAddr[n] = pMACAddress[n];	//forced mac address by bootloader
	}
}


//////////////////////////////////////////////////////////////////////////
// 	AT91_EmacInit - Initialises the EMAC controller
///////////////////////////////////////////////////////////////////////////
static void AT91_EmacInit(AT91PS_EMAC p_mac)
{
	DWORD tmp;

	// the sequence write EMAC_SA1L and write EMAC_SA1H must be respected
	p_mac->EMAC_SA1L =		((int) g_ethernetAddr[3] << 24) |
							((int) g_ethernetAddr[2] << 16) |
							((int) g_ethernetAddr[1] << 8)  |
								   g_ethernetAddr[0];

	p_mac->EMAC_SA1H =		((int) g_ethernetAddr[5] << 8)  | 
								   g_ethernetAddr[4];

	// Reset the network control register
	p_mac->EMAC_CTL = (p_mac->EMAC_CTL & ~(AT91C_EMAC_LB |
						AT91C_EMAC_LBL |
						AT91C_EMAC_RE |
						AT91C_EMAC_MPE |
						AT91C_EMAC_CSR |
						AT91C_EMAC_ISR |
						AT91C_EMAC_WES |
						AT91C_EMAC_BP));


	// The network config register is set for Unicast, No broadcast
	p_mac->EMAC_CFG = (	p_mac->EMAC_CFG & ~(AT91C_EMAC_CAF	|
											AT91C_EMAC_NBC	|
											AT91C_EMAC_CLK))|
											AT91C_EMAC_UNI;

	// RMII mode for the AT91RM9200DK
	p_mac->EMAC_CFG |= AT91C_EMAC_RMII;

	// Initialisation of Interrupt Register
	tmp = p_mac->EMAC_ISR;

	p_mac->EMAC_IER =	AT91C_EMAC_RCOM |
						AT91C_EMAC_RBNA |
						AT91C_EMAC_TOVR |
						AT91C_EMAC_TUND |
						AT91C_EMAC_TCOM |
						AT91C_EMAC_ROVR;
}

//////////////////////////////////////////////////////////////////////////
// 	AT91_EtherReceiveInit - Initialises the the EMAC receive management
///////////////////////////////////////////////////////////////////////////
static void AT91_EtherReceiveInit(AT91PS_EMAC p_mac)
{
	int i;

	int buff_align = 0;

	// descriptor list is constructed in the Frame buffer

	for (i = 0; i < MAX_RX_BUFFS ; i++) 
	{
		g_dlist->virt_addr[i] = (unsigned char *) &g_dlist->rec_buf[i][0];  // get virt copy
		g_dlist->descriptors[i].addr = (unsigned char *) &((struct rec_des_bufs*)g_dlist_phys)->rec_buf[i][0];  // fill word0
		g_dlist->descriptors[i].size = 0;  // fill word1
	}

	(unsigned int) g_dlist->descriptors[i - 1].addr |= EMAC_DESC_WRAP;  // The Wrap bit is set for the last element


	g_dlist_index = 0;

	// The descriptor list address is assigned to the Rx buffer queue reg
	p_mac->EMAC_RBQP = (DWORD)g_dlist_phys;
}

//////////////////////////////////////////////////////////////////////////
// 	AT91_EtherError - Manage Ether errors
///////////////////////////////////////////////////////////////////////////
static void AT91_EtherError(AT91PS_EMAC p_mac, unsigned long status_error)
{
	if (status_error & AT91C_EMAC_RBNA) 
	{
		EdbgOutputDebugString("Error  RBNA!\n");
		p_mac->EMAC_CTL &= ~AT91C_EMAC_RE;  // disable receive
		p_mac->EMAC_RSR = AT91C_EMAC_BNA;  // reset BNA bit
		p_mac->EMAC_CTL |= AT91C_EMAC_RE;  // enable receive
	}
	if (status_error & AT91C_EMAC_ROVR) 
	{
		EdbgOutputDebugString("Error  Receive Overrun!\n");
		p_mac->EMAC_RSR = 0x04;  // reset OVR bit in RSR		
	}
	if (status_error & AT91C_EMAC_TOVR) 
	{
		EdbgOutputDebugString("Error Transmit Overrun!\n");
		p_mac->EMAC_TSR = AT91C_EMAC_OVR;  // reset OVR bit in TSR
	}
	if (status_error & AT91C_EMAC_TUND) 
	{
		EdbgOutputDebugString("Error Transmit Underrun!\n");
		p_mac->EMAC_TSR = AT91C_EMAC_UND;  // reset UND bit in TSR
	}
}





// This is called to initialze the ethernet low level driver.  The base address of the ethernet hardware
// is passed into the routine.  The routine will return TRUE for a successful initialization. 
// dwMultiplier is unused for at91_net
BOOL AT91Init(BYTE* pbBaseAddress, DWORD dwMultiplier, USHORT MacAddr[3])
{
	BOOL bRet;
	BOOL bNeedInit = FALSE;
	

	EdbgOutputDebugString("+EDBG : AT91Init\r\n");

	///////////////////////////////////////
	// 1 - Init Base Reg
	///////////////////////////////////////

	g_pEmac = (AT91PS_EMAC) pbBaseAddress;
	
	EdbgOutputDebugString("EDBG:AT91Init using I/O range at 0x%X\r\n", g_pEmac);



	//Virtual address
	g_dlist = (struct rec_des_bufs *) OALPAtoVA(g_dlist_phys,FALSE);
	g_TransmitBuffer = (UCHAR*) OALPAtoVA(g_TransmitBuffer_Phys,FALSE);
	g_pSys = (AT91PS_SYS)OALPAtoVA((DWORD) AT91C_BASE_SYS,FALSE);
	

	InitRcvQueue();

	///////////////////////////////////////
	// 2 - Init Emac just for Management (Comm with PHY)
	///////////////////////////////////////
	AT91_EmacHWInit();			// clock & pio of Emac
	

	if (g_pEmac->EMAC_TAR == 0)
	{
		bNeedInit = TRUE;
	}

	///////////////////////////////////////
	// 3 - Init PHY
	///////////////////////////////////////
	if (bNeedInit)
	{
		AT91F_MDIO_ResetPhy();	// enable phy clock & reset phy

		bRet = PhyHWInit();		// getPhyInterface & PHY init, autonegociate
	}
	else
	{
		bRet = TRUE;
	}


	///////////////////////////////////////
	// 4 - Init Emac
	///////////////////////////////////////
	if (bRet)
	{
		if (bNeedInit)
		{
			AT91_EmacInit(g_pEmac);
		}

		if (NULL != MacAddr) 
		{
			MacAddr[0] = (g_pEmac->EMAC_SA1L & 0x0000FFFF);
			MacAddr[1] = (g_pEmac->EMAC_SA1L & 0xFFFF0000) >> 16;
			MacAddr[2] = (g_pEmac->EMAC_SA1H & 0x0000FFFF);

			EdbgOutputDebugString("EDBG:AT91Init Reading MAC address 0x%X 0x%X 0x%X\r\n",
														MacAddr[0], MacAddr[1], MacAddr[2]);
		}

		AT91_EtherReceiveInit(g_pEmac);
		// Receive and Transmit enable bits are set in network control register
		g_pEmac->EMAC_CTL |= (AT91C_EMAC_RE | AT91C_EMAC_TE);
	}

	EdbgOutputDebugString("-EDBG : AT91Init\r\n");
	return bRet;
}


// Interrupts left disabled at init, call this function to turn them on
void AT91EnableInts()
{
	EdbgOutputDebugString("++AT91EnableInts\n");
	g_pEmac->EMAC_IER = AT91C_EMAC_RCOM |
		AT91C_EMAC_RBNA |
		AT91C_EMAC_TOVR |
		AT91C_EMAC_TUND |
		AT91C_EMAC_TCOM |
		AT91C_EMAC_ROVR;
	g_pSys->AIC_IECR = 1 << AT91C_ID_EMAC; //JJH move to the interrupt enable wrapper
	//SOCEnableIrq(LOGINTR_ETHER);
}

void AT91DisableInts()
{
	EdbgOutputDebugString("--AT91DisableInts\n");
	g_pSys->AIC_IDCR = 1 << AT91C_ID_EMAC;
	g_pEmac->EMAC_IDR = AT91C_EMAC_RCOM |
		AT91C_EMAC_RBNA |
		AT91C_EMAC_TOVR |
		AT91C_EMAC_TUND |
		AT91C_EMAC_TCOM |
		AT91C_EMAC_ROVR;
}



////////////////////////////////////////////////////////////////////////////////
//	ComputeCrc()
//	
//	Description:
//
//		Runs the AUTODIN II CRC algorithm on buffer Buffer of length Length.
//
//	Arguments:
//
//		Buffer - the input buffer
//		Length - the length of Buffer
//
//	Return value:
//
//		The 32-bit CRC value.
//
//	Note:
//
//		This function is adopted from netcard\at91 miniport driver.
//		
ULONG ComputeCrc(IN PUCHAR Buffer, IN UINT Length)
{
	ULONG Crc, Carry;
	UINT i, j;
	UCHAR CurByte;

	Crc = 0xffffffff;

	for (i = 0; i < Length; i++) {
		CurByte = Buffer[i];

		for (j = 0; j < 8; j++) {
			Carry = ((Crc & 0x80000000) ? 1 : 0) ^ (CurByte & 0x01);

			Crc <<= 1;

			CurByte >>= 1;

			if (Carry) {
				Crc = (Crc ^ 0x04c11db6) | Carry;
			}
		}
	}

	return Crc;
}	//	ComputeCrc()
//////////////////////////////////////////////////////////////////
//// initialize the receive queue use for Ethernet reiceiving
//////////////////////////////////////////////////////////////////
static void InitRcvQueue(void)
{
	DWORD n;

	for (n = 0; n < RCV_Q_SIZE; n++) {
		g_rcv_list[n].re_state = RCV_FREE;
	}
	g_rcv_index = 0;
	g_rcv_next = 0;
	g_rcv_cnt = 0;
}

//////////////////////////////////////////////////////////////////
//// initialize the receive queue use for Ethernet reiceiving
//////////////////////////////////////////////////////////////////
static BOOL QueueRcv(WORD packetlen, UCHAR* packetptr)
{
	PRCV_ENTRY prcv = &(g_rcv_list[g_rcv_index]);

	if (prcv->re_state != RCV_FREE) {
		return FALSE;
	}

	prcv->re_state = RCV_USED;
	prcv->re_len = packetlen;
	prcv->re_ptr = packetptr;
	g_rcv_cnt++;
	g_rcv_index++;
	if (g_rcv_index == RCV_Q_SIZE) {
		g_rcv_index = 0;
	}
	return TRUE;
} // QueueRcv


//
//   HandleReceive - Check that there is a packet in the receive buffer and
//  		  check its length and status.  Then queue the receive if
//  		  the packet is OK.
//
static void HandleReceive(AT91PS_EMAC p_mac)
{
	WORD packetlen;
	p_mac->EMAC_RSR |= AT91C_EMAC_REC;  // clear receive bit	

	while (1) {
		if ((unsigned int)
			g_dlist->descriptors[g_dlist_index].addr & EMAC_DESC_DONE) {
			if ((g_rcv_index == g_rcv_next) && (g_rcv_cnt > 0)) {
				// no more free buffers. Packet is dropped.
				break;
			}

			packetlen = (WORD)(g_dlist->descriptors[g_dlist_index].size & 0x7ff);
			memcpy(g_uc_eth_buff[g_rcv_index], g_dlist->virt_addr[g_dlist_index], packetlen);
			QueueRcv(packetlen, g_uc_eth_buff[g_rcv_index]);

			(UINT) g_dlist->descriptors[g_dlist_index].addr &= ~EMAC_DESC_DONE;  // reset ownership bit
			if ((unsigned int)
				(g_dlist->descriptors[g_dlist_index].addr) & EMAC_DESC_WRAP)  // check wrap bit
				g_dlist_index = 0;
			else
				g_dlist_index++;
		} else
			break;
	}
}   // HandleReceive


// Manage Ethernet interrupt event
void AT91_ISR(void)
{
	DWORD intstatus, status_error;

	AT91PS_EMAC p_mac = (AT91PS_EMAC) g_pEmac;  // pointer to MAC

	// The MAC Interrupt status register is read and its bits are compared
	// to call the respective functions
	intstatus = p_mac->EMAC_ISR;
	// Receive Complete
	if (intstatus & AT91C_EMAC_RCOM)
		HandleReceive(p_mac);

	// Transmit Complete
	if (intstatus & AT91C_EMAC_TCOM) 
	{
		transmitting = 0;
	}

	status_error = intstatus & (AT91C_EMAC_RBNA |
								AT91C_EMAC_ROVR |
								AT91C_EMAC_TOVR |
								AT91C_EMAC_TUND);
	// Error
	if (status_error)
	{
		AT91_EtherError(p_mac, status_error);
	}
}   // AT91_ISR


//// call the ISR routine in polling mode, to check for received data
DWORD AT91GetPendingInts()
{
	EdbgOutputDebugString("+AT91GetPendingInts\r\n");
	AT91_ISR();
	if (g_rcv_cnt) {
		return INTR_TYPE_RX;
	}
	return 0;
}   // AT91GetPendingInts


//
// This routine is polled to find out if a frame has been received.  If there are no frames
//  in the RX FIFO, the routine will return 0.  If there was a frame that was received correctly,
//  it will be stored in pwData, otherwise it will be discarded.  
//

UINT16 AT91GetFrame(BYTE* pbData, UINT16* pwLength)
{
	PRCV_ENTRY prcv;
	WORD len;
	
	len = *pwLength;
	*pwLength = 0;

	// If no frame has been received, do one attempt to retreive a pending one.
	if (!g_rcv_cnt) {
		AT91_ISR();
	}
	if (g_rcv_cnt) {
		prcv = &(g_rcv_list[g_rcv_next]);
		if (prcv->re_state == RCV_USED) {
#ifdef AT91_DUMP_FRAMES			
			DumpEtherFrame((BYTE*)prcv->re_ptr, len);
#endif
			if (prcv->re_len < len) {
				len = prcv->re_len;
			}
			// Copy the frame to the specified buffer
			memcpy(pbData, prcv->re_ptr, len);
			// Return the number of bytes written
			*pwLength = len;
			
			// Free some resources
			prcv->re_state = RCV_FREE;
			g_rcv_cnt--;
			g_rcv_next++;
			if (g_rcv_next == RCV_Q_SIZE) {
				g_rcv_next = 0;
			}
		}
	} 

	return *pwLength;
} // AT91GetFrame()



//
// This routine should be called with a pointer to the ethernet frame data.  It is the caller's
//  responsibility to fill in all information including the destination and source addresses and
//  the frame type.  The length parameter gives the number of bytes in the ethernet frame.
// The routine will not return until the frame has been transmitted or an error has occured.  If
//  the frame transmits successfully, 0 is returned.  If an error occured, a message is sent to
//  the serial port and the routine returns non-zero.
//
UINT16 AT91SendFrame(BYTE* pbData, DWORD dwLength)
{
	int nIters, idle = 1;
	
	
	curr_xmit_len = (WORD) dwLength;

	// Loop here until the request is satisfied, or we timeout
	//
	for (nIters = 0; !(idle); nIters ++) {

		if (g_pEmac->EMAC_TSR & AT91C_EMAC_TXIDLE)
			idle = 0;
		//Sleep(1);
		if (nIters > 1000) {
			EdbgOutputDebugString("AT91SendFrame Timed out waiting for transmit buffers\n");
			//
			// 2 seconds ought to be enough to transmit a packet!!! Reset for transmit errors
			// 
			idle = 0;
		}
	}
	curr_xmit_len = ((WORD) dwLength < ETH_ZLEN) ? ETH_ZLEN : (WORD) dwLength;
	curr_xmit_len = ((WORD) dwLength > AT91C_EMAC_TXBUFF_SZ) ?
		AT91C_EMAC_TXBUFF_SZ :
		(WORD) dwLength;


	// Physical Address of data is set in Transmit address reg
	// We have ton convert sytem add to physical add
	memcpy(g_TransmitBuffer, pbData, curr_xmit_len);
	g_pEmac->EMAC_TAR = (DWORD) g_TransmitBuffer_Phys;

#ifdef AT91_DUMP_FRAMES			
	DumpEtherFrame(g_TransmitBuffer, curr_xmit_len);			
#endif

	// Length of packet is set in Transmit control reg
	g_pEmac->EMAC_TCR = curr_xmit_len;

	// Loop here until the request is satisfied, or we timeout
	//
	for (nIters = 0; transmitting; nIters ++) {
		//Sleep(1);
		AT91_ISR();
		if (nIters > 1000) {
			EdbgOutputDebugString("AT91SendFrame Timed out waiting for transmit buffers\n");
			//
			// 2 seconds ought to be enough to transmit a packet!!! Reset for transmit errors
			// 
			transmitting = 0;
			
			return 1;//send error
		}
	}
	transmitting = 1;
	
	return 0;
} // AT91SendFrame()



#ifdef AT91_DUMP_FRAMES
// Output the packet pointed by pFrame on the debug port
static void DumpEtherFrame(BYTE* pFrame, WORD cwFrameLength)
{
	int i, j;

	EdbgOutputDebugString("Frame Buffer Address: 0x%X\r\n", pFrame);
	EdbgOutputDebugString("To: %B:%B:%B:%B:%B:%B  From: %B:%B:%B:%B:%B:%B  Type: 0x%H  Length: %u\r\n",
		pFrame[0], pFrame[1], pFrame[2], pFrame[3], pFrame[4], pFrame[5],
		pFrame[6], pFrame[7], pFrame[8], pFrame[9], pFrame[10], pFrame[11],
		ntohs(*((UINT16 *) (pFrame + 12))), cwFrameLength);
	for (i = 0; i < cwFrameLength / 16; i++) {
		for (j = 0; j < 16; j++)
			EdbgOutputDebugString(" %B", pFrame[i * 16 + j]);
		EdbgOutputDebugString("\r\n");
	}
	for (j = 0; j < cwFrameLength % 16; j++)
		EdbgOutputDebugString(" %B", pFrame[i * 16 + j]);
	EdbgOutputDebugString("\r\n");
}

#endif  // AT91_DUMP_FRAMES


//
// This routine is used by the OAL to configure the debug Ethernet driver. Currently
// the following options are defined:
//    -----  Not used for now -----
//     OPT_BROADCAST_FILTERING  -- If set, filter out all broadcast packets except ARP packets
// 
DWORD AT91SetOptions(DWORD dwOptions)
{
	DWORD dwOldOptions = dwConfigOptions;
	dwConfigOptions = dwOptions;
	return dwOldOptions;
}


VOID   EMACCurrentPacketFilter(UINT32 filter) {}
BOOL   EMACMulticastList(UINT8 *pAddresses, UINT32 count) {return TRUE;}


//! @}
