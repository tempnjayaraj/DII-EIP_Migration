//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//-----------------------------------------------------------------------------
//! \file		ether.c 
//!
//! \brief		All common bootloader ethernet entry implementation
//!
//! \if subversion
///   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/GenericEBOOT/ether.c $
//!   $Author: ltourlonias $
//!   $Revision: 985 $
//!   $Date: 2007-06-12 09:30:21 +0200 (mar., 12 juin 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	EBOOT
//! @{
//!
//------------------------------------------------------------------------------
//                                                                      Includes
//------------------------------------------------------------------------------
// Standard includes
#include <windows.h>
#include <halether.h>
#include <nkintr.h>
#include <oal.h>


// Project include
#include "bootloader_struct.h"
#include "eboot_msg.h"
#include "key_code.h"

//------------------------------------------------------------------------------
//                                                                       Defines
//------------------------------------------------------------------------------
#define NB_ETHERNET_RETRY		5
#define ETHERNET_RETRY_DELAY	10

#define NB_SENDFRAME_RETRY		4

//------------------------------------------------------------------------------
//                                                                     Variables
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
//                                                            Imported functions
//------------------------------------------------------------------------------
extern DWORD EBOOT_GetCurrentSec(void);
extern BOOL  EBOOT_EtherGetFrame(BYTE *pData, UINT16 *pwLength);
extern BOOL  EBOOT_EtherSendFrame(BYTE *pData, DWORD dwLength);
extern BOOL  EBOOT_EtherInitHW(UCHAR targetMacAddress[6], OAL_KITL_ARGS *pKITLArgs);
extern int	 EBOOT_ReadDebugByte(void);


//------------------------------------------------------------------------------
//                                                            Exported functions
//------------------------------------------------------------------------------

//--------------------------------------------------------------------------------
//! \fn BOOL OEMEthGetFrame(BYTE *pData,UINT16 *pwLength)
//! 
//! This function try to initialize the ethnet driver by calling specific hardware
//! function.
//!
//! \param pData Frame data buffer to send. The buffer must be DWORD aligned. 
//!
//! \param pwLength Number of bytes in the receiving buffer when the function is entered. 
//!
//! \return \e TRUE if succeed
//! \return \e FALSE if failed
//!
//--------------------------------------------------------------------------------
BOOL EBOOT_EtherInit(EBOOT_CFG * pEbootCFG, OAL_KITL_ARGS *pKITLArgs)
{
	BOOL	bStatus = FALSE;
	DWORD	dwNbRemaingInitRetry = NB_ETHERNET_RETRY + 1;
	DWORD	dwCurrentTime, dwStartTime, dwPreviousTime, dwTime, i;
	BYTE	selection = NO_KEY;
	
	do
	{
		RETAILMSG (1,(EMSG_CRLF));
		bStatus = EBOOT_EtherInitHW(pEbootCFG->macAddress, pKITLArgs);
		
		if (bStatus == TRUE)
		{
			dwNbRemaingInitRetry = 0;
		}
		else
		{
			dwNbRemaingInitRetry--;
	
			dwStartTime = EBOOT_GetCurrentSec();
			dwCurrentTime = dwStartTime;
			dwPreviousTime = dwStartTime;
			dwTime = ETHERNET_RETRY_DELAY;

			RETAILMSG (1,(EMSG_NO_ETHER_LINK));
			RETAILMSG (1,(EMSG_CRLF));
			RETAILMSG (1,(EMSG_RETRY_ETHER_LINK));
			RETAILMSG (1,(EMSG_CRLF));
			RETAILMSG (1,(L"Initiating image download in %3d seconds", dwTime));

			while (dwTime > 0)
			{
				selection = EBOOT_ReadDebugByte(); 
				if ((selection == KEY_ENTER) || (selection == KEY_SPACE))
				{
					break;
				}

				dwCurrentTime = EBOOT_GetCurrentSec();
				if (dwCurrentTime != dwPreviousTime)
				{
					dwTime--;
					dwPreviousTime = dwCurrentTime;

					// Erase old second counter
					for (i=0;i<11;i++)
					{
						OEMWriteDebugByte((BYTE)0x08); // print back space
					}
					RETAILMSG (1,( L"%3d seconds", dwTime));
				}
			}
		}
	}
	while (dwNbRemaingInitRetry >= 1);


	return bStatus;
}

//--------------------------------------------------------------------------------
//! \fn BOOL OEMEthGetFrame(BYTE *pData,UINT16 *pwLength)
//! 
//! This function receives data from the debug Ethernet adapter. 
//!
//! \param pData Frame data buffer to send. The buffer must be DWORD aligned. 
//!
//! \param pwLength Number of bytes in the receiving buffer when the function is entered. 
//!
//! \return \e TRUE if succeed
//! \return \e FALSE if failed
//!
//--------------------------------------------------------------------------------
BOOL OEMEthGetFrame(BYTE *pData, UINT16 *pwLength)
{
    return (EBOOT_EtherGetFrame(pData, pwLength));
}

//--------------------------------------------------------------------------------
//! \fn BOOL OEMEthSendFrame(BYTE *pData,DWORD dwLength)
//! 
//! This function sends data over the debug Ethernet adapter. 
//! 
//! \param pData Buffer to hold received frame bytes. The buffer must be DWORD aligned. 
//!
//! \param dwLength Number of bytes in the buffer.
//!
//! \return \e TRUE if succeed
//! \return \e FALSE if failed
//!
//--------------------------------------------------------------------------------
BOOL OEMEthSendFrame(BYTE *pData, DWORD dwLength)
{
    DWORD dwRetries = 0;
	// Let's be persistant here
    while (dwRetries++ < NB_SENDFRAME_RETRY)
    {
        if (!EBOOT_EtherSendFrame(pData, dwLength))
		{
			return TRUE;
		}
    }
    return FALSE;
}

//------------------------------------------------------------------------------
//! \brief Get the number of sec since the timer initialization
//! 
//! \return		number of seconds
//------------------------------------------------------------------------------
DWORD OEMEthGetSecs(void)
{
	return EBOOT_GetCurrentSec();
}

//------------------------------------------------------------------------------
//! \brief Read data from input
//! 
//! \param cbData       data length
//!
//! \param pbData       data
//!
//! \return		Status
//------------------------------------------------------------------------------
BOOL  OEMReadData (DWORD cbData, LPBYTE pbData)
{
	return (EbootEtherReadData(cbData, pbData));
}


//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/GenericEBOOT/ether.c $
//------------------------------------------------------------------------------

//
//! @}
//
//! @}
//