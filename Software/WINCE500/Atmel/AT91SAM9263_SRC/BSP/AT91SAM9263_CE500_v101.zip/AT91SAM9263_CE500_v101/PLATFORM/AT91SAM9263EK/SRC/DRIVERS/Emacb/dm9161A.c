//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{	
//
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		DM9161A.c
//
//! \brief		Implementaion of the Common PHY Interface for the DM9161A Phy
//
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/Emacb/dm9161A.c $
//!   $Author: ltourlonias $
//!   $Revision: 684 $
//!   $Date: 2007-04-13 14:35:48 +0200 (ven., 13 avr. 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	EMAC
//! @{
//
//! \addtogroup	PHY
//! @{	
//
//! \addtogroup	DM9161A
//! @{	


#include <windows.h>
#include <oal.h>
#include "phyInterface.h"

#define DM9161A_CONTROL_REG	0
#define DM9161A_CONTROL_REG_RESET					(1<<15)
#define DM9161A_CONTROL_REG_AUTONEGOCIATION_ENABLE	(1<<12)
#define DM9161A_CONTROL_REG_RESTART_AUTONEGOCIATION	(1<<9)
#define DM9161A_CONTROL_REG_FULL_DUPLEX				(1<<8)
#define DM9161A_CONTROL_REG_SPEED_SELECT				(1<<13)

#define DM9161A_STATUS_REG	1
#define DM9161A_STATUS_REG_LINK						(1<<2)
#define DM9161A_STATUS_REG_AUTONEGOCIATION_COMPLETE	(1<<5)


#define DM9161A_ID1_REG	2
#define DM9161A_ID2_REG	3
#define MII_DM9161A_ID   0x0181b880


#define DM9161A_LINK_PARTNER_REG	5
#define DM9161A_LINK_PARTNER_100FULL			(1<<8)
#define DM9161A_LINK_PARTNER_100HALF			(1<<7)
#define DM9161A_LINK_PARTNER_10FULL			(1<<6)
#define DM9161A_LINK_PARTNER_10HALF			(1<<5)

#define DM9161A_DAVICOM_SPEC_CONF_REG	16
#define DM9161A_DAVICOM_SPEC_CONF_RMII_ENABLED	(1<<8)



static BOOL PHY_Reset(T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr)
{
	RETAILMSG(1,(TEXT("RESET PHY!!!\r\n")));
	pMacInfo->write_phy(pMacInfo->pDeviceLocation,ucPhyAddr,DM9161A_CONTROL_REG,DM9161A_CONTROL_REG_RESET);
	
	return TRUE;
}

static BOOL PHY_StartAutoNegociation(T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr)
{
	pMacInfo->write_phy(pMacInfo->pDeviceLocation,ucPhyAddr,DM9161A_CONTROL_REG,DM9161A_CONTROL_REG_AUTONEGOCIATION_ENABLE | DM9161A_CONTROL_REG_RESTART_AUTONEGOCIATION);	
	return TRUE;
}



static BOOL PHY_WaitForLink(T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr, DWORD dwTimeout)
{
	DWORD dwValue;
	DWORD dwEndOfWait = OALGetTickCount() + dwTimeout;	
	do
	{
		/* Link status is latched, so read twice to get current value */
		pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,DM9161A_STATUS_REG,&dwValue);
		pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,DM9161A_STATUS_REG,&dwValue);
//		RETAILMSG(1,(TEXT("Status = %d\r\n"),dwValue));
		if (dwValue & DM9161A_STATUS_REG_LINK)
		{
			break;
		}
	}
	while (OALGetTickCount() < dwEndOfWait);

	if ((dwValue & DM9161A_STATUS_REG_LINK)==0)
	{
		return FALSE;
	}
	
	return TRUE;
}

static BOOL PHY_WaitForAutonegociationComplete(T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr, DWORD dwTimeout)
{
	DWORD dwValue;
	DWORD dwEndOfWait = OALGetTickCount() + dwTimeout;
	do
	{
		/* Link status is latched, so read twice to get current value */
		pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,DM9161A_STATUS_REG,&dwValue);
		pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,DM9161A_STATUS_REG,&dwValue);
		if (dwValue & DM9161A_STATUS_REG_AUTONEGOCIATION_COMPLETE)
		{
			break;
		}
	}
	while (OALGetTickCount() < dwEndOfWait);

	if ((dwValue & DM9161A_STATUS_REG_AUTONEGOCIATION_COMPLETE)==0)
	{		
		return FALSE;
	}
	
	return TRUE;
}


static BOOL PHY_GetID(T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr,DWORD* pdwID)
{
	DWORD dwID,dwValue;
	pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,DM9161A_ID1_REG,&dwValue);
	dwID = dwValue << 16;
	
	dwValue = 0;
	pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,DM9161A_ID2_REG,&dwValue);
	dwID |= dwValue;	

	
	if (pdwID)
	{
		*pdwID = dwID;
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

static BOOL PHY_CheckID(T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr)
{
#define ID_MASK	0xFFFFF800
	DWORD dwID,dwID2;
	int i =0;
	PHY_GetID(pMacInfo,ucPhyAddr,&dwID);
	PHY_GetID(pMacInfo,ucPhyAddr,&dwID2);
	
	for(i=0;i<200 && dwID==dwID2;i++)
		PHY_GetID(pMacInfo,ucPhyAddr,&dwID);
	
/*	if(dwID!=dwID2)
		 RETAILMSG(1,(TEXT("PHY ID instable 1: %d, 2: %d.\r\n"),dwID,dwID2));
	else
		RETAILMSG(1,(TEXT("PHY ID : %d"),dwID));
*/
	PHY_GetID(pMacInfo,ucPhyAddr,&dwID);
	if ((dwID & ID_MASK) != (MII_DM9161A_ID & ID_MASK))
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}


static BOOL PHY_SetConfiguration(T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr, T_PHY_CONFIGURATION* pPhyCfg)
{	
	DWORD dwControlReg;
	DWORD dwDavicomSpecifiedConfReg;
	// Check parameters !
	if (pPhyCfg == NULL)
	{
		return FALSE;
	}
	

	pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,DM9161A_DAVICOM_SPEC_CONF_REG,&dwDavicomSpecifiedConfReg);
		
	if ((pPhyCfg->bRMII == FALSE)  && (dwDavicomSpecifiedConfReg & DM9161A_DAVICOM_SPEC_CONF_RMII_ENABLED))
	{
		RETAILMSG(1,(TEXT("PHY_SetConfiguration : MII mode not available\r\n")));
		return FALSE;
	}
	if ((pPhyCfg->bRMII == TRUE)  && (!(dwDavicomSpecifiedConfReg & DM9161A_DAVICOM_SPEC_CONF_RMII_ENABLED)))
	{
		RETAILMSG(1,(TEXT("PHY_SetConfiguration : RMII mode not available\r\n")));
		return FALSE;
	}



	if (pPhyCfg->bAutoNegociation)
	{
		return PHY_StartAutoNegociation(pMacInfo,ucPhyAddr);
	}
	
	
	// Check parameters
	if ((pPhyCfg->dwSpeed != SPEED_100) && (pPhyCfg->dwSpeed != SPEED_10))
	{
		return FALSE;
	}
	
	
	dwControlReg = 0;
	if (pPhyCfg->dwSpeed  == SPEED_100)
	{
		dwControlReg |= DM9161A_CONTROL_REG_SPEED_SELECT;
	}
	if (pPhyCfg->bFullDuplex)
	{
		dwControlReg |= DM9161A_CONTROL_REG_FULL_DUPLEX;
	}
	
	
	pMacInfo->write_phy(pMacInfo->pDeviceLocation,ucPhyAddr,DM9161A_CONTROL_REG,dwControlReg);	
	
	return FALSE;
}



static BOOL PHY_GetConfiguration(T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr, T_PHY_CONFIGURATION* pPhyCfg)
{
	/*
	DWORD dwBMCR, dwANLPAR, dwDSCR;
	DWORD dwValue;
	DWORD dwEndOfWait = 10000;
	DWORD temp;

	pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,DM9161A_CONTROL_REG,&dwBMCR);
	
	dwBMCR |= DM9161A_CONTROL_REG_RESTART_AUTONEGOCIATION;
	pMacInfo->write_phy(pMacInfo->pDeviceLocation,ucPhyAddr,DM9161A_CONTROL_REG,dwBMCR);
	
	pPhyCfg->bAutoNegociation  = FALSE;
	
	temp = OALGetTickCount();
	do
	{
		// Link status is latched, so read twice to get current value 
		pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,DM9161A_STATUS_REG,&dwValue);
		pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,DM9161A_STATUS_REG,&dwValue);
		if (dwValue & DM9161A_STATUS_REG_AUTONEGOCIATION_COMPLETE)
		{
			RETAILMSG(1, (L"autoneg completed\r\n"));
			pPhyCfg->bAutoNegociation  = TRUE;
			break;
		}
	}
	while ((OALGetTickCount() - temp) < dwEndOfWait);
	
	if(pPhyCfg->bAutoNegociation == TRUE)
	{
		pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,DM9161A_LINK_PARTNER_REG,&dwANLPAR);
		pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,DM9161A_DAVICOM_SPEC_CONF_REG,&dwDSCR);
		
		if ((dwANLPAR & DM9161A_LINK_PARTNER_100FULL) || (dwANLPAR & DM9161A_LINK_PARTNER_100HALF)) 
		{
			pPhyCfg->dwSpeed  = SPEED_100;
		}
		else 
		{
			pPhyCfg->dwSpeed = SPEED_10;
		}
		
		if ((dwANLPAR & DM9161A_LINK_PARTNER_100FULL) || (dwANLPAR & DM9161A_LINK_PARTNER_10FULL)) 
		{
			pPhyCfg->bFullDuplex = TRUE;
		}		
		else
		{
			pPhyCfg->bFullDuplex = FALSE;
		}
		
		
		if (dwDSCR & DM9161A_DAVICOM_SPEC_CONF_RMII_ENABLED)
		{
			pPhyCfg->bRMII = TRUE;		
		}
		else
		{
			pPhyCfg->bRMII = FALSE;
		}
	}
	else
	{
		return FALSE;
	}
	return TRUE;
	*/

	DWORD dwCtrlReg;
	DWORD dwStatusReg;
	DWORD dwLinkPartnerReg;
	DWORD dwDavicomSpecifiedConfReg;

	if (pPhyCfg == NULL)
	{
		return FALSE;
	}
	
	
	pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,DM9161A_CONTROL_REG,&dwCtrlReg);
	pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,DM9161A_STATUS_REG,&dwStatusReg);
	
	RETAILMSG(1,(TEXT("CONTROL REG : 0x%x\r\n"), dwCtrlReg));
	RETAILMSG(1,(TEXT("STATUS REG : 0x%x\r\n"), dwStatusReg));
	

	if (dwCtrlReg & DM9161A_CONTROL_REG_AUTONEGOCIATION_ENABLE) 
	{	
		pPhyCfg->bAutoNegociation = TRUE;	
		
				/* AutoNegotiation is enabled */
		if (!(dwStatusReg & DM9161A_STATUS_REG_AUTONEGOCIATION_COMPLETE)) 
		{
			return FALSE;		/* auto-negotitation in progress */
		}

		
		pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,DM9161A_LINK_PARTNER_REG,&dwLinkPartnerReg);
		if ((dwLinkPartnerReg & DM9161A_LINK_PARTNER_100FULL) || (dwLinkPartnerReg & DM9161A_LINK_PARTNER_100HALF)) 
		{
			pPhyCfg->dwSpeed  = SPEED_100;
		}
		else 
		{
			pPhyCfg->dwSpeed = SPEED_10;
		}
		
		if ((dwLinkPartnerReg & DM9161A_LINK_PARTNER_100FULL) || (dwLinkPartnerReg & DM9161A_LINK_PARTNER_10FULL)) 
		{
			pPhyCfg->bFullDuplex = TRUE;
		}		
		else
		{
			pPhyCfg->bFullDuplex = FALSE;
		}		
	} 
	else 
	{
		pPhyCfg->bAutoNegociation = FALSE;
		if (dwCtrlReg & DM9161A_CONTROL_REG_SPEED_SELECT)
		{
			pPhyCfg->dwSpeed = SPEED_100;
		}
		else
		{	
			pPhyCfg->dwSpeed = SPEED_10;
		}
		if (dwCtrlReg & DM9161A_CONTROL_REG_FULL_DUPLEX)
		{
			pPhyCfg->bFullDuplex = TRUE;
		}
		else
		{
			pPhyCfg->bFullDuplex = FALSE;
		}
	}

	pMacInfo->read_phy(pMacInfo->pDeviceLocation,ucPhyAddr,DM9161A_DAVICOM_SPEC_CONF_REG,&dwDavicomSpecifiedConfReg);
		
	if (dwDavicomSpecifiedConfReg & DM9161A_DAVICOM_SPEC_CONF_RMII_ENABLED)
	{
		pPhyCfg->bRMII = TRUE;		
	}
	else
	{
		pPhyCfg->bRMII = FALSE;
	}

	return TRUE;
}


static const WCHAR PhyName[] = L"DM9161A";



T_PHY_INTERFACE DM9161A_PhyInterface = {
	PHY_Reset,
	PHY_SetConfiguration,
	PHY_GetConfiguration,	
	PHY_StartAutoNegociation,
	PHY_WaitForLink,
	PHY_WaitForAutonegociationComplete,
	PHY_GetID,	
	PHY_CheckID,
	PhyName
};




//! @}

//! @}
//! @}

//! @}