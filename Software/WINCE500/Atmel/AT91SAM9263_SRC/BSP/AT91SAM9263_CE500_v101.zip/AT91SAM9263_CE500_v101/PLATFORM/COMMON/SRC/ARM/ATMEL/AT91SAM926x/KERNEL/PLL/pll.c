//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/PLL/pll.c
//!
//! \brief		PLL management for the AT91SAM926x processors
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/PLL/pll.c $
//!   $Author: pblanchard $
//!   $Revision: 1090 $
//!   $Date: 2007-07-13 07:07:28 -0700 (Fri, 13 Jul 2007) $
//! \endif
//-----------------------------------------------------------------------------

//! \addtogroup	PLL
//! @{

#include <windows.h>
#include <nkintr.h>
#include <oal.h>
#include "AT91SAM926x.h"
#include "AT91SAM926x_interface.h"
#include "AT91SAM926x.h"
#include "lib_AT91SAM926x.h"

#define TOLERANCE 					0.25 	// + or - 0.25% for output frequency
#define ACCURACY					10000	// used to replace float operations

#define MAX_PRESCALER				6
#define DEFAULT_BUS_RATIO			4

extern void DisableDBGU();
extern void EnableDBGU();

extern DWORD PLLProcSpecificGetPLLMultiplierMax(void);
extern DWORD PLLProcSpecificGetPLLDividerMax(void);
extern DWORD PLLProcSpecificGetPLLInRangeMin(void);
extern DWORD PLLProcSpecificGetPLLBOutRangeLimit(void);
extern DWORD PLLProcSpecificGetPLLBOutFieldInf(void);
extern DWORD PLLProcSpecificGetPLLBOutFieldSup(void);
extern DWORD PLLProcSpecificGetPLLAOutRangeMin(void);
extern DWORD PLLProcSpecificGetPLLAOutRangeLimit(void);

//-----------------------------------------------------------------------------
//! \fn        static void ComputeMulAndDiv(DWORD dwSrcFreqInHz,DWORD dwDestFreqInHz,DWORD *pMul,DWORD *pDiv)
//!
//! \brief     This function computes the correct divider and multiplier whiwh match with the wanted frequency
//!
//!	\param     dwSrcFreqInHz input frequency
//!	\param     dwDestFreqInHz output frequency
//!	\param     pMul computed multiplier
//!	\param     pDiv comupted divider
//!
//!
//-----------------------------------------------------------------------------
static void ComputeMulAndDiv(DWORD dwSrcFreqInHz, DWORD dwTargetFreqInHz, DWORD *pMul, DWORD *pDiv)
{
	DWORD dwMul, dwDiv;
	DWORD dwBestMul = 1;
	DWORD dwBestDiv = 1;
	DWORD dwMaxDiv;
	UINT64 uiTargetSrcRatio, uiMulDivRatio;
	BOOL bRatioTrouve = FALSE;
	UINT64 uiSrcFreq = dwSrcFreqInHz;
	UINT64 uiTargetFreq = dwTargetFreqInHz;

	// 'Max divider choice' algorithm -> deprecated because of jitter created
	/*	
	dwDiv = PLL_DIVIDER_MAX * 2;	
	do
	{
		dwDiv /= 2;
		dwMul = (dwTargetFreqInKHz * dwDiv) / dwSrcFreqInKHz;
		
	} 
	while (dwMul > PLL_MULTIPLIER_MAX);
	*/

	//  New algorithm : computes the best (lowest) multiplier and divider
	if (uiSrcFreq != 0 && uiTargetFreq != 0)
	{
		uiTargetSrcRatio = uiTargetFreq * ACCURACY / uiSrcFreq;
		for(dwMul = 1; dwMul <= PLLProcSpecificGetPLLMultiplierMax(); dwMul++)
		{
			if (dwMul < PLLProcSpecificGetPLLDividerMax() && uiTargetSrcRatio > 1 * ACCURACY)
			{
				dwMaxDiv = dwMul;
			}
			else
			{
				dwMaxDiv = PLLProcSpecificGetPLLDividerMax();
			}
			
			for(dwDiv = 1; dwDiv <= dwMaxDiv; dwDiv++)
			{
				// Check if we are in data range in order to reduce computing time
				if ((uiSrcFreq/dwDiv) < PLLProcSpecificGetPLLInRangeMin())
				{
					break;
				}
				
				// With these MUL and DIV we have the fine ratio
				uiMulDivRatio = dwMul * ACCURACY / dwDiv;
				//if (dwMulDivRatio == dwDestSrcRatio)
				if ((_abs64(uiTargetFreq*ACCURACY-(uiMulDivRatio*uiSrcFreq)) * 100) / uiTargetFreq <= TOLERANCE * ACCURACY)
				{
					dwBestMul = dwMul;
					dwBestDiv = dwDiv;
					bRatioTrouve = TRUE;
					break;
				}
				
				// We hold the current values because the current MUL/DIV ratio is better
				if ((_abs64((uiMulDivRatio*ACCURACY/uiTargetSrcRatio)-1*ACCURACY)) < (_abs64(((dwBestMul*ACCURACY/dwBestDiv)*ACCURACY/uiTargetSrcRatio)-1*ACCURACY)))
				{
					dwBestMul = dwMul;
					dwBestDiv = dwDiv;
				}
			}
			
			if (bRatioTrouve)
			{
				break;
			}
		}
	}

	*pMul = dwBestMul - 1;
	*pDiv = dwBestDiv;
}

//-----------------------------------------------------------------------------
//! \fn		DWORD GetMainClockFreq(AT91PS_PMC pPMC)
//!
//! \brief		Returns value of Main clock in Hz
//!
//!	\param		pPMC pointer to clock generator controller
//!
//! \return		value of Main clock in Hz
//-----------------------------------------------------------------------------
DWORD GetMainClockFreq(AT91PS_PMC pPMC)
{
	if (pPMC->PMC_MCFR & AT91C_CKGR_MAINRDY)
	{		
		return ((pPMC->PMC_MCFR & AT91C_CKGR_MAINF) * (SLOW_CLOCK_FREQUENCY)) / 16;
	}
	else
	{
		return 0;
	}
}

//-----------------------------------------------------------------------------
//! \fn		     DWORD GetPLLAFreq(AT91PS_PMC pPMC)
//!
//! \brief		Returns value of PLLA clock in Hz
//!
//!	\param		pPMC pointer to clock generator controller
//!
//! \return		value of PLLA clock in Hz
//-----------------------------------------------------------------------------
DWORD GetPLLAFreq(AT91PS_PMC pPMC)
{
    DWORD dwMainClk;
    DWORD dwMUL,dwDIV;

	
	dwMainClk = GetMainClockFreq(pPMC);
    dwMUL = (pPMC->PMC_PLLAR & AT91C_CKGR_MULA) >> 16;
    dwDIV = (pPMC->PMC_PLLAR & AT91C_CKGR_DIVA) >> 0;
    
    if (dwDIV == 0)
        return 0;

    return (dwMainClk / dwDIV) * (dwMUL+1);
}

//-----------------------------------------------------------------------------
//! \fn		     DWORD GetPLLBFreq(AT91PS_PMC pPMC)
//!
//! \brief		Returns value of PLLB clock in Hz
//!
//!	\param		pPMC	pointer to clock generator controller
//!
//! \return		value of PLLB clock in Hz
//-----------------------------------------------------------------------------
DWORD GetPLLBFreq(AT91PS_PMC pPMC)
{

    DWORD dwMainClk;
    DWORD dwMUL,dwDIV;

	dwMainClk = GetMainClockFreq(pPMC);

    dwMUL = (pPMC->PMC_PLLBR & AT91C_CKGR_MULB) >> 16;
    dwDIV = (pPMC->PMC_PLLBR & AT91C_CKGR_DIVB) >> 0;
    
    if (dwDIV == 0)
        return 0;

    return (dwMainClk  / dwDIV) * (dwMUL+1);
}

//-----------------------------------------------------------------------------
//! \fn		DWORD AT91SAM926x_GetPLLAClock(BOOL bUseShadowedValue)
//!
//! \brief		This function is called by the kernel to retreive the value of the PLLA clock in Hz
//!
//!	\param		bUseShadowedValue TRUE to use shadowed value
//!
//! \return		value of PLLA clock in Hz
//-----------------------------------------------------------------------------
DWORD AT91SAM926x_GetPLLAClock(BOOL bUseShadowedValue)
{
#ifdef IS_MISTRAL
	return FALSE;  	
#else
	
    static DWORD dwPLLAClock = 0xFFFFFFFF;

    if ((dwPLLAClock == 0xFFFFFFFF) || (!bUseShadowedValue))
    {        
        	    
		AT91PS_PMC pPMC;
		pPMC = (AT91PS_PMC) OALPAtoVA((DWORD) AT91C_BASE_PMC,FALSE);
		dwPLLAClock = GetPLLAFreq(pPMC);
    }           
	RETAILMSG(1,(TEXT("PLLA Clock is %d Hz\r\n"),dwPLLAClock));
    return dwPLLAClock; 
#endif
}

//-----------------------------------------------------------------------------
//! \fn		DWORD AT91SAM926x_GetPLLBClock(BOOL bUseShadowedValue)
//!
//! \brief		This function is called by the kernel to retreive the value of the PLLB clock in Hz
//!
//!	\param		bUseShadowedValue TRUE to use shadowed value
//!
//! \return		value of PLLB clock in Hz
//-----------------------------------------------------------------------------
DWORD AT91SAM926x_GetPLLBClock(BOOL bUseShadowedValue)
{
#ifdef IS_MISTRAL
	return FALSE;  	
#else
    static DWORD dwPLLBClock = 0xFFFFFFFF;

    if ((dwPLLBClock == 0xFFFFFFFF) || (!bUseShadowedValue))
    {        
        	    
		AT91PS_PMC pPMC;
		pPMC = (AT91PS_PMC) OALPAtoVA((DWORD) AT91C_BASE_PMC,FALSE);
		dwPLLBClock = GetPLLBFreq(pPMC);
    }           
	RETAILMSG(1,(TEXT("PLLB Clock is %d Hz\r\n"),dwPLLBClock));
    return dwPLLBClock;
#endif
}

//-----------------------------------------------------------------------------
//! \fn		DWORD AT91SAM926x_GetProcessorClock(BOOL bUseShadowedValue)
//!
//! \brief		This function is called by the kernel to retreive the value of the Processor clock in Hz
//!
//!	\param		bUseShadowedValue TRUE to use shadowed value
//!
//! \return		value of Processor clock in Hz
//-----------------------------------------------------------------------------
DWORD AT91SAM926x_GetProcessorClock(BOOL bUseShadowedValue)
{
#ifdef IS_MISTRAL
	return FALSE;  	
#else
	  static DWORD dwProcessorClock = 0xFFFFFFFF;

    if ((dwProcessorClock == 0xFFFFFFFF) || (!bUseShadowedValue))
    {        
		DWORD dwInputFreq;	    
		AT91PS_PMC pPMC;
		pPMC = (AT91PS_PMC) OALPAtoVA((DWORD) AT91C_BASE_PMC,FALSE);
		switch (pPMC->PMC_MCKR & AT91C_PMC_CSS)
		{
			case AT91C_PMC_CSS_SLOW_CLK: dwInputFreq = SLOW_CLOCK_FREQUENCY; break;
			case AT91C_PMC_CSS_MAIN_CLK: dwInputFreq = GetMainClockFreq(pPMC); break;
			case AT91C_PMC_CSS_PLLA_CLK: dwInputFreq = GetPLLAFreq(pPMC); break;
			case AT91C_PMC_CSS_PLLB_CLK: dwInputFreq = GetPLLBFreq(pPMC); break;
		}

        if (dwInputFreq != 0)
		{
			dwProcessorClock = dwInputFreq >> ((pPMC->PMC_MCKR & AT91C_PMC_PRES)>>2);
		}
    }           
	RETAILMSG(1,(TEXT("Processor Clock is %d Hz\r\n"),dwProcessorClock));
    return dwProcessorClock;
#endif
}

//-----------------------------------------------------------------------------
//! \fn		DWORD AT91SAM926x_GetMasterClock(BOOL bUseShadowedValue)
//!
//! \brief		This function is called by the kernel to retreive the value of the Master clock in Hz
//!
//!	\param		bUseShadowedValue TRUE to use shadowed value
//!
//! \return		value of Master clock in Hz
//-----------------------------------------------------------------------------
DWORD AT91SAM926x_GetMasterClock(BOOL bUseShadowedValue)
{        
#ifdef IS_MISTRAL
	return 25000000;  	
#else

    static DWORD dwMasterClock = 0xFFFFFFFF;

    if ((dwMasterClock == 0xFFFFFFFF) || (!bUseShadowedValue))
    {        
        
		DWORD temp;
		DWORD dwInputFreq;	    
		AT91PS_PMC pPMC;
		pPMC = (AT91PS_PMC) OALPAtoVA((DWORD) AT91C_BASE_PMC,FALSE);
		switch (pPMC->PMC_MCKR & AT91C_PMC_CSS)
		{
			case AT91C_PMC_CSS_SLOW_CLK: dwInputFreq = SLOW_CLOCK_FREQUENCY; break;
			case AT91C_PMC_CSS_MAIN_CLK: dwInputFreq = GetMainClockFreq(pPMC); break;
			case AT91C_PMC_CSS_PLLA_CLK: dwInputFreq = GetPLLAFreq(pPMC); break;
			case AT91C_PMC_CSS_PLLB_CLK: dwInputFreq = GetPLLBFreq(pPMC); break;
		}

        if (dwInputFreq != 0)
		{
			temp = dwInputFreq >> ((pPMC->PMC_MCKR & AT91C_PMC_PRES)>>2);
			dwMasterClock = temp >> ((pPMC->PMC_MCKR & AT91C_PMC_MDIV) >> 8);
		}
		        
    }           
	RETAILMSG(1,(TEXT("Master Clock is %d Hz\r\n"),dwMasterClock));
    return dwMasterClock;    
#endif
}

//-----------------------------------------------------------------------------
//! \fn		static log2(DWORD dw)
//!
//! \brief		This function computes log2(dw)
//!
//-----------------------------------------------------------------------------
static log2(DWORD dw)
{
    DWORD log2=0;
	while (dw)
    {
	    log2++;
        dw >>= 1;
    }
	return log2-1;
}

//-----------------------------------------------------------------------------
//! \fn		void AT91SAM926x_TurnProcessorClockOff()
//!
//! \brief		This function is called by the kernel to stop the processor clock and thus enter the idle/suspend mode.
//!
//-----------------------------------------------------------------------------
void AT91SAM926x_TurnProcessorClockOff()
{
	AT91PS_PMC pPMC;
	pPMC = (AT91PS_PMC) OALPAtoVA((DWORD) AT91C_BASE_PMC,FALSE);
	if (pPMC == NULL)
	{
		return;
	}
	pPMC->PMC_SCDR = AT91C_PMC_PCK;
}

//-----------------------------------------------------------------------------
//! \fn		DWORD AT91SAM926x_SetPLLBFreq(AT91PS_PMC pPMC, DWORD dwFreqInMHz, DWORD dwUSBDivider)
//!
//! \brief		This function is called by the kernel to set the PLLB frequency
//!
//!
//! 
//!
//-----------------------------------------------------------------------------
DWORD AT91SAM926x_SetPLLBFreq(AT91PS_PMC pPMC,DWORD dwFreqInMHz, DWORD dwUSBDivider)
{
#ifdef IS_MISTRAL
	return 0;
#else

    DWORD dwTemp = 0;
    DWORD dwFreq, dwMainClock;
	DWORD dwDiv;
	DWORD dwMul;

	dwMainClock = GetMainClockFreq(pPMC);
	ComputeMulAndDiv(dwMainClock, dwFreqInMHz * 1000000, &dwMul, &dwDiv);
	
    dwTemp |= (dwMul << 16) | (dwDiv);
    dwTemp |= dwUSBDivider;

    dwFreq = (dwMainClock / dwDiv) * (dwMul+1);    
    if (dwFreq < PLLProcSpecificGetPLLBOutRangeLimit())
    {
        dwTemp |= PLLProcSpecificGetPLLBOutFieldInf();
    }
    else
    {
        dwTemp |= PLLProcSpecificGetPLLBOutFieldSup();
    }
    
    dwTemp |= (AT91C_CKGR_PLLBCOUNT & (0x3FF << 8)); //Maximum setup time (we don't really know the characteristics of the PLL filter implemented on the board).
    
    
    pPMC->PMC_PLLBR = dwTemp;
    
    while ((pPMC->PMC_SR & AT91C_PMC_LOCKB) == 0);    
    
    return 0;
#endif
}


//-----------------------------------------------------------------------------
//! \fn		DWORD AT91SAM926x_SetProcessorAndMasterClocks(AT91PS_PMC pPMC, DWORD dwProcessorClockInMHz, DWORD dwBusClockRatio)
//!
//! \brief		This function is called by the kernel to retreive the value of the Master clock in Hz
//!
//!	\param		pPMC			TODO
//!	\param		dwProcessorClockInMHz	TODO
//!	\param		dwBusClockRatio		TODO
//!
//! \return		value of Master clock in Hz
//-----------------------------------------------------------------------------
BOOL AT91SAM926x_SetProcessorAndMasterClocks(AT91PS_PMC pPMC, DWORD dwProcessorClockInMHz, DWORD dwBusClockRatio)
{
#ifdef IS_MISTRAL
	return TRUE;
#else
	DWORD PLLA_CountBeforeStable;
	DWORD PLLA_Divider;
	DWORD PLLA_Multiplier;
	DWORD PLLA_BusRatio;
	DWORD dwTemp;
	DWORD dwPrescaler = 0;

	DWORD dwTargetPLLFrequencyInMHz = dwProcessorClockInMHz;

	DEBUGMSG(1,(TEXT("Target processor Frequency is %d MHz\r\nTarget Bus Frequency is %d MHz\r\n"),dwProcessorClockInMHz,dwProcessorClockInMHz/dwBusClockRatio));

	/* Compute the prescaler if needed */
	while (dwTargetPLLFrequencyInMHz * 1000000 < PLLProcSpecificGetPLLAOutRangeMin())
	{
		dwPrescaler++;
		if (dwPrescaler > MAX_PRESCALER)
		{
			return FALSE;
		}
		dwTargetPLLFrequencyInMHz = dwProcessorClockInMHz * (1 << dwPrescaler);
	}

	// Clip the selected bus ratio
	if ((dwBusClockRatio != 1) && (dwBusClockRatio != 2) && (dwBusClockRatio != 4))
	{
		RETAILMSG(1,(TEXT("AT91SAM926x_SetProcessorAndMasterClocks : Invalid bus ratio (%d). Setting default (%d)\r\n"),dwBusClockRatio,DEFAULT_BUS_RATIO));
		dwBusClockRatio = DEFAULT_BUS_RATIO;
	}

	PLLA_CountBeforeStable	= 0x1F;	
	PLLA_BusRatio			= 0;

	//DEBUGMSG(1,(TEXT("Prescaler is %d\r\nTarget PLL A Frequency is %d MHz\r\n"),dwPrescaler,dwTargetPLLFrequencyInMHz));

	ComputeMulAndDiv(GetMainClockFreq(pPMC), dwTargetPLLFrequencyInMHz*1000000, &PLLA_Multiplier, &PLLA_Divider);	
	
	//DEBUGMSG(1,(TEXT("PLLA_Divider %d\r\nPLLA_Multiplier %d\r\n"),PLLA_Divider,PLLA_Multiplier));	

	{
		// Short delay to let the Chip a bit time to settle.
		// Someow it's no good to write characters on the serial before a bit.
		volatile DWORD dwTempo = 10000;
		while (dwTempo--);
	}
	
	DisableDBGU();
	/*
	// Switch MasterClock To SlowClock, with a prescaler of 1 and a bus divider of 2
	pPMC->PMC_MCKR |= AT91C_PMC_CSS_SLOW_CLK;
	// Waiting that MasterClock is stable
   	while ((pPMC->PMC_SR & AT91C_PMC_MCKRDY) == 0);
	
    pPMC->PMC_MCKR = AT91C_PMC_MDIV_2 | AT91C_PMC_PRES_CLK;
	// Waiting that MasterClock is stable
   	while ((pPMC->PMC_SR & AT91C_PMC_MCKRDY) == 0);
	*/

	// PLLA Configuration
	dwTemp = AT91C_CKGR_SRCA | (PLLA_Multiplier<<16) | (PLLA_CountBeforeStable<<8) | PLLA_Divider;

	if ((dwTargetPLLFrequencyInMHz*1000000) < PLLProcSpecificGetPLLAOutRangeLimit())
    {
        dwTemp |= AT91C_CKGR_OUTA_0;
    }
    else
    {
        dwTemp |= AT91C_CKGR_OUTA_2;
    }

	pPMC->PMC_PLLAR = dwTemp;
	
	// Waiting for PLLA to be stable
	while ((pPMC->PMC_SR & (AT91C_PMC_LOCKA | AT91C_PMC_MCKRDY)) != (AT91C_PMC_LOCKA | AT91C_PMC_MCKRDY));

	// Selecting the right Bus Ratio
	switch (dwBusClockRatio)
	{
		case 1:
			PLLA_BusRatio = AT91C_PMC_MDIV_1;
			break;
		case 2:
			PLLA_BusRatio = AT91C_PMC_MDIV_2;
			break;
		case 4:
			PLLA_BusRatio = AT91C_PMC_MDIV_3;
			break;
		default:
			PLLA_BusRatio = AT91C_PMC_MDIV_3;
	}

	// Switch MasterClock to PLLA
	pPMC->PMC_MCKR = PLLA_BusRatio | (dwPrescaler << 2);
	// Waiting for MasterClock to be locked
	while ((pPMC->PMC_SR & AT91C_PMC_MCKRDY) == 0);

	pPMC->PMC_MCKR |= AT91C_PMC_CSS_PLLA_CLK;
	// Waiting for MasterClock to be locked
	while ((pPMC->PMC_SR & AT91C_PMC_MCKRDY) == 0);

	{
		// Short delay to let the Chip a bit time to settle.
		// Someow it's no good to write characters on the serial before a bit.
		volatile DWORD dwTempo = 10000;
		while (dwTempo--);
	}

	EnableDBGU();

    return TRUE;
#endif
}

//! @} end of subgroup PLL

//! @} end of group OAL


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/PLL/pll.c $
////////////////////////////////////////////////////////////////////////////////
//
