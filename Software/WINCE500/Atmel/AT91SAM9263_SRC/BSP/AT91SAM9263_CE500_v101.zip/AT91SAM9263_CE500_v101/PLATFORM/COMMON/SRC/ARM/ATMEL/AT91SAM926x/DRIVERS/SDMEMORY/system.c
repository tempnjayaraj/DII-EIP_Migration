//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		system.c
//!
//! \brief		Common part of the SD Memory Card driver
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/SDMEMORY/system.c $
//!   $Author: pblanchard $
//!   $Revision: 980 $
//!   $Date: 2007-06-11 07:26:34 -0700 (Mon, 11 Jun 2007) $
//! \endif
//!
//! This driver initializes the MCI peripheral and allows read/write on an SD Card
//-----------------------------------------------------------------------------
//! \addtogroup	SDMEMORY
//! @{
//!

// System include
#include <windows.h>
#include <diskio.h>
#include <storemgr.h>
#include <Devload.h>

#include "at91sam926x.h"

// Local include
#include "sdmmc.h"
#include "AT91SAM926x_oal_ioctl.h"

#ifdef DEBUG
// These defines must match the ZONE_* defines
#define DBG_ERROR      1
#define DBG_WARNING    2
#define DBG_FUNCTION   4
#define DBG_INIT       8
#define DGB_PCMCIA	   16
#define DBG_IO         32

// The dpCurSettings structure for debug zones
DBGPARAM dpCurSettings = {
    TEXT("RAM Disk"), {
    TEXT("Errors"),TEXT("Warnings"),TEXT("Functions"),TEXT("Initialization"),
    TEXT("Undefined"),TEXT("Disk I/O"),TEXT("Misc"),TEXT("Undefined"),
    TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined"),
    TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined") },
    0xFFFF
};
#endif  // #ifdef DEBUG

extern DWORD SDMemoryBoardSpecificGetMaxClock(void);

// Globals

//AT91S_MciDeviceDesc		g_DeviceDesc;
//AT91S_MciDeviceFeatures g_DeviceFeatures;
//AT91S_MciDevice			g_MciDevice;


//-----------------------------------------------------------------------------
//! \fn			BOOL WINAPI DllMain(HINSTANCE DllInstance, DWORD Reason, LPVOID Reserved)
//!
//! \brief		This function is the entry point of the Dll driver
//!
//! \param		DllInstance	DLL instance
//! \param		Reason	Reason of the call
//! \param		Reserved	Not used
//!
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//!
//! This function intialize debug zone when called with the DLL_PROCESS_ATTACH reason
//-----------------------------------------------------------------------------
BOOL WINAPI DllMain(HINSTANCE DllInstance, DWORD Reason, LPVOID Reserved)
{
    switch(Reason) 
    {
        case DLL_PROCESS_ATTACH:
            DEBUGMSG(ZONE_INIT, (TEXT("SDMMC: DLL_PROCESS_ATTACH\r\n")));
            DEBUGREGISTER(DllInstance);
			DisableThreadLibraryCalls((HMODULE) DllInstance);
            break;
    
        case DLL_PROCESS_DETACH:
            DEBUGMSG(ZONE_INIT, (TEXT("SDMMC: DLL_PROCESS_DETACH\r\n")));
            break;
    }
    return TRUE;
}

static DWORD g_SlotID = 0xFFFFFFFF;

//-----------------------------------------------------------------------------
//! \fn			DWORD DSK_Init(DWORD dwContext)
//!
//! \brief		This function initializes the device.
//!
//! \param		dwContext		Pointer to a string containing the registry path to the active key for the stream interface driver.
//!
//! \return		Returns a pointer to a DISK structure
//!	\return		\e zero if not successful.
//!
//! Device Manager calls this function as a result of a call to the ActivateDeviceEx 
//! function. When the user starts using a device, such as inserting a SD Memory Card, 
//! Device Manager calls this function to initialize the device. Applications do not call this function. 
//-----------------------------------------------------------------------------
DWORD DSK_Init(DWORD dwContext)
{
    PDISK pDisk;
	HKEY hKey;

	DWORD dwSlotNumber = 0xFFFFFFFF;
    LPWSTR ActivePath = (LPWSTR) dwContext;

    DEBUGMSG(ZONE_INIT, (TEXT("+SDMMC: DSK_Init entered\n\r")));
	
    pDisk = CreateDiskObject();
    if (pDisk == NULL) 
    {
        RETAILMSG(1,(TEXT("SDMMC: LocalAlloc(PDISK) failed %d\r\n"), GetLastError()));
        return 0;
    }

    if (ActivePath) 
    {
        DEBUGMSG(ZONE_INIT, (TEXT("SDMMC: ActiveKey = %s\r\n"), ActivePath));
        if (pDisk->d_ActivePath = LocalAlloc(LPTR, wcslen(ActivePath)*sizeof(WCHAR)+sizeof(WCHAR))) 
        {
            wcscpy(pDisk->d_ActivePath, ActivePath);
        }
        DEBUGMSG(ZONE_INIT, (TEXT("SDMMC : ActiveKey (copy) = %s (@ 0x%08X)\r\n"), pDisk->d_ActivePath, pDisk->d_ActivePath));
    }

	hKey = OpenDeviceKey((LPCTSTR) dwContext);
	if (hKey)
	{
		DWORD dwData;
		DWORD dwSize = sizeof(dwData);
	    if (ERROR_SUCCESS == RegQueryValueEx(hKey,L"SlotID",NULL,NULL,(LPBYTE)(&dwData),&dwSize))
		{
			dwSlotNumber = dwData;
		}
		RegCloseKey(hKey);
	}
	pDisk->dwSlotNumber = dwSlotNumber;
    
	// Initialization of the specific platform.
	SDMemoryBoardSpecificInit(dwSlotNumber);


	if(!InitDisk(pDisk))
	{
		DEBUGMSG(ZONE_INIT, (TEXT("-SDMMC: DSK_Init (failure)\r\n")));
		DeinitDisk(pDisk);
		return 0;
	}

	ConfigClockFromRegistry(ActivePath,pDisk->pMCI_VirtualBase);

    DEBUGMSG(ZONE_INIT, (TEXT("SDMMC: sectors = %d\r\n"), pDisk->d_DiskInfo.di_total_sectors));
    
    if (pDisk->d_DiskCardState == STATE_INITING) 
    {
        DEBUGMSG(ZONE_INIT,(TEXT("-SDMMC: DSK_Init returning 0x%x\r\n"), pDisk));
        return (DWORD) pDisk;
    }

    DEBUGMSG(ZONE_INIT, (TEXT("-SDMMC: DSK_Init (failure)\r\n")));
    DeinitDisk(pDisk);
    return 0;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL DSK_Deinit(DWORD dwContext)
//!
//! \brief		This function uninitializes the device.
//!
//! \param		dwContext	Pointer to the the device init context. The DSK_Init (Device Manager)
//!								function creates and returns this pointer.
//!
//! \return		\e TRUE
//!
//! When the user stops using a device, such as when an SD Memory Card is removed from its socket, 
//! Device Manager calls this function. Applications do not call this function. Device Manager 
//! calls the DSK_Deinit driver function as a result of a call to the DeactivateDevice function. 
//! Your stream interface driver should free any resources it has allocated, and then terminate.
//-----------------------------------------------------------------------------
BOOL DSK_Deinit(DWORD dwContext)
{
    DEBUGMSG(ZONE_INIT, (TEXT("SDMMC: DSK_Deinit entered\r\n")));
    DSK_Close(dwContext);
    DeinitDisk((PDISK)dwContext);
    DEBUGMSG(ZONE_INIT, (TEXT("SDMMC: DSK_Deinit done\r\n")));
    return TRUE;
}


//-----------------------------------------------------------------------------
//! \fn			DWORD DSK_Open(DWORD dwData, DWORD dwAccess, DWORD dwShareMode)
//!
//! \brief		This function opens a device for reading, writing, or both.
//!
//! \param		dwData			Pointer to the the device open context. The <b>DSK_Init</b> (Device Manager)
//!								function creates and returns this identifier.
//! \param		dwAccess		Access code for the device. The access is a combination
//!								of read and write access from <b>CreateFile</b>. 
//! \param		dwShareMode		File share mode of the device. The share mode is a combination 
//!								of read and write access sharing from <b>CreateFile</b>. 
//!
//! \return		This function returns a pointer to a DISK structure
//!
//! When this function executes, your device should allocate the resources that it needs for 
//! each open context and prepare for operation. This might involve preparing the device for 
//! reading or writing and initializing data structures it uses for operation.
//-----------------------------------------------------------------------------
DWORD DSK_Open(DWORD dwData, DWORD dwAccess, DWORD dwShareMode)
{
    PDISK pDisk = (PDISK)dwData;
    DWORD ret = 0;

    DEBUGMSG(ZONE_IO, (TEXT("+SDMMC: DSK_Open(0x%x)\r\n"),dwData));

    if (IsValidDisk(pDisk) == FALSE) 
    {
        DEBUGMSG(ZONE_IO, (TEXT("SDMMC: DSK_Open - Passed invalid disk handle\r\n")));
        return ret;
    }

    if (pDisk->d_DiskCardState == STATE_INITING) 
    {
        if (pDisk->d_DiskInfo.di_total_sectors == 0) 
		{
            pDisk->d_DiskCardState = STATE_DEAD;
        }
        else
		{
			pDisk->d_DiskCardState = STATE_CLOSED;
        }
    }

    if ((pDisk->d_DiskCardState != STATE_OPENED) &&
        (pDisk->d_DiskCardState != STATE_CLOSED))
	{
        SetLastError(GetDiskStateError(pDisk->d_DiskCardState));
        return 0;
    }

    EnterCriticalSection(&(pDisk->d_DiskCardCrit));
    if (pDisk->d_DiskCardState == STATE_CLOSED) 
    {
        pDisk->d_DiskCardState = STATE_OPENED;
    }
    
    ret = (DWORD)pDisk;
    pDisk->d_OpenCount++;
    LeaveCriticalSection(&(pDisk->d_DiskCardCrit));
    DEBUGMSG(ZONE_IO, (TEXT("-SDMMC: DSK_Open(0x%x) returning %d\r\n"),dwData, ret));
    return ret;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL DSK_Close(DWORD Handle)
//!
//! \brief		This function closes a device context created by the Handle parameter.
//!
//! \param		Handle		Pointer returned by the <b>DSK_Open</b> (Device Manager) function, 
//!							which is used to identify the open context of the device. 
//!
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//!
//! An application calls the CloseHandle function to stop using a stream interface driver. 
//! The hFile parameter specifies the handle associated with the device context. In response
//! to <b>CloseHandle</b>, the operating system invokes <b>DSK_Close</b>.
//-----------------------------------------------------------------------------
BOOL DSK_Close(DWORD Handle)
{
    PDISK pDisk = (PDISK)Handle;
    BOOL bClose = FALSE;

    DEBUGMSG(ZONE_IO, (TEXT("SDMMC: DSK_Close entered\r\n")));

    if (!IsValidDisk(pDisk)) 
    {
        return FALSE;
    }

    if (pDisk->d_DiskCardState == STATE_OPENED) 
    {
        EnterCriticalSection(&(pDisk->d_DiskCardCrit));
        pDisk->d_OpenCount--;
        if (pDisk->d_OpenCount == 0) 
        {
            pDisk->d_DiskCardState = STATE_CLOSED;
            bClose = TRUE;
        }
        LeaveCriticalSection(&(pDisk->d_DiskCardCrit));
    }
    DEBUGMSG(ZONE_IO, (TEXT("SDMMC: DSK_Close done\r\n")));
    return TRUE;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL DSK_IOControl(DWORD Handle, DWORD dwIoControlCode, PBYTE pInBuf, DWORD dwInBufSize, PBYTE pOutBuf, DWORD dwOutBufSize, PDWORD pBytesReturned)
//!
//! \brief		This function sends a command to a device.
//!
//! \param		Handle			Handle to the open context of the device. The <b>DSK_Open</b> 
//!								(Device Manager) function creates and returns this identifier.  
//! \param		dwIoControlCode	I/O control operation to perform. These codes are device-specific and 
//!								are usually exposed to developers through a header file. 
//!								Use <b>CTL_CODE</b> macro to generate a driver unique identifier for your iocontrol.
//! \param		pInBuf			Pointer to the buffer containing data to transfer to the device. 
//! \param		dwInBufSize		Number of bytes of data in the buffer specified for <i>pInBuf</i>.
//! \param		pOutBuf			Pointer to the buffer used to transfer the output data from the device.
//! \param		dwOutBufSize	Maximum number of bytes in the buffer specified by <i>pOutBuf</i>.
//! \param		pBytesReturned	Pointer to the <b>DWORD</b> buffer that this function uses to 
//!								return the actual number of bytes received from the device. 
//!
//! \return		\e TRUE indicates success.
//! \return		\e FALSE indicates failure.
//!
//! The device manager, invokes the <b>DSK_IOControl</b> function. The <i>dwIoControlCode</i> parameter contains 
//! the Input or Output operation to perform.
//!
//! IOControls are :
//!
//!		- DISK_IOCTL_FORMAT_MEDIA	: Format the SD Memory Card
//!			- \e pInBuf		: (DISK_INFO *)
//!			- \e pOutBuf	: NULL
//!
//!		- DISK_IOCTL_READ	: This IOCTL services FAT file system requests to read data from the block device
//!		- DISK_IOCTL_WRITE	: This IOCTL services FAT file system requests to write data to the block device
//!			- \e pInBuf		: (SG_REQ *)
//!			- \e pOutBuf	: NULL
//!
//!		- DISK_IOCTL_GETINFO: This IOCTL notifies block device drivers to return disk information
//!			- \e pInBuf		: (DISK_INFO *)
//!			- \e pOutBuf	: NULL
//!
//!		- DISK_IOCTL_SETINFO: This IOCTL services FAT file system requests to set disk information
//!			- \e pInBuf		: (DISK_INFO *)
//!			- \e pOutBuf	: NULL
//!
//!		- DISK_IOCTL_GETNAME: This IOCTL returns from the FAT file system, the name of the folder that determines 
//!								how users access the block device
//!			- \e pInBuf		: NULL
//!			- \e pOutBuf	: (LPWSTR)
//!
//!		- IOCTL_DISK_DEVICE_INFO: This IOCTL returns storage information to block device drivers.
//!			- \e pInBuf		: (STORAGEDEVICEINFO *)
//!			- \e pOutBuf	: NULL
//-----------------------------------------------------------------------------
BOOL
DSK_IOControl(
    DWORD Handle,
    DWORD dwIoControlCode,
    PBYTE pInBuf,
    DWORD dwInBufSize,
    PBYTE pOutBuf,
    DWORD dwOutBufSize,
    PDWORD pBytesReturned
    )
{
    PSG_REQ pSG;
    PDISK pDisk = (PDISK) Handle;

    DEBUGMSG(ZONE_FUNCTION, (TEXT("+DSK_IOControl (%d) \r\n"), dwIoControlCode));
    
    if (IsValidDisk(pDisk) == FALSE) 
    {
        SetLastError(ERROR_INVALID_HANDLE);
        DEBUGMSG(ZONE_FUNCTION, (TEXT("-DSK_IOControl (invalid disk) \r\n")));
        return FALSE;
    }

    if (pDisk->d_DiskCardState != STATE_OPENED) 
    {
        SetLastError(GetDiskStateError(pDisk->d_DiskCardState));
        DEBUGMSG(ZONE_FUNCTION, (TEXT("-DSK_IOControl (disk card state) \r\n")));
        return FALSE;
    }

    //
    // Check parameters
    //
    switch (dwIoControlCode) 
    {
	case IOCTL_POWER_CAPABILITIES:
	break;
	case IOCTL_POWER_QUERY:
	break;
	case IOCTL_POWER_SET:
	break;
	case IOCTL_POWER_GET:
	break;
	case DISK_IOCTL_READ:
	case DISK_IOCTL_WRITE:
	case DISK_IOCTL_GETINFO:
	case DISK_IOCTL_SETINFO:
	case DISK_IOCTL_INITIALIZED:
       	if (pInBuf == NULL) 
		{
			SetLastError(ERROR_INVALID_PARAMETER);
			return FALSE;
		}
        break;

    case DISK_IOCTL_GETNAME:
		if (pOutBuf == NULL) 
		{
			SetLastError(ERROR_INVALID_PARAMETER);
			return FALSE;
		}
		break;

    case IOCTL_DISK_DEVICE_INFO:
		if(!pInBuf || dwInBufSize != sizeof(STORAGEDEVICEINFO)) 
		{
			SetLastError(ERROR_INVALID_PARAMETER);   
			return FALSE;
		}
		break;
	
	case DISK_IOCTL_FORMAT_MEDIA:
		SetLastError(ERROR_SUCCESS);
		return TRUE;
	
	default:
		SetLastError(ERROR_INVALID_PARAMETER);
		return FALSE;
	}

    //
    // Execute dwIoControlCode
    //
    switch (dwIoControlCode) 
    {
	case DISK_IOCTL_FORMAT_MEDIA:
        DEBUGMSG(ZONE_FUNCTION, (TEXT("-DSK_IOControl (format) \r\n")));
		return FormatDisk(pDisk, (PDISK_INFO) pInBuf);

    case DISK_IOCTL_READ:
    case DISK_IOCTL_WRITE:
        pSG = (PSG_REQ) pInBuf;
/*
		{
            PSG_REQ pSgReq = pSG;
            if  (pSgReq && dwInBufSize >= (sizeof(SG_REQ) + sizeof(SG_BUF) * (pSgReq->sr_num_sg - 1))) 
			{
			
			}
            else 
			{// Parameter Wrong.
                SetLastError(ERROR_INVALID_PARAMETER);
                return FALSE;
            };
        }
*/
        DoDiskIO(pDisk, dwIoControlCode, pSG);

		if (pSG->sr_status != ERROR_SUCCESS)
		{
			if (pBytesReturned)
			{
				*pBytesReturned = 0;
			}
			SetLastError(pSG->sr_status);
			return FALSE;
		}
		else
		{
			if (pBytesReturned)
			{
				*pBytesReturned = (DWORD) pSG->sr_num_sec * SD_BYTES_PER_SECTOR;
			}
		}	
		
        return TRUE;
		
    case DISK_IOCTL_GETINFO:
        SetLastError(GetDiskInfo(pDisk, (PDISK_INFO)pInBuf));
        return TRUE;
		
    case DISK_IOCTL_SETINFO:
        SetLastError(SetDiskInfo(pDisk, (PDISK_INFO)pInBuf));
        return TRUE;
		
    case DISK_IOCTL_INITIALIZED:
        return TRUE;
		
    case DISK_IOCTL_GETNAME:
        DEBUGMSG(ZONE_FUNCTION, (TEXT("-DSK_IOControl (name) \r\n")));
        return GetFolderName(pDisk, (LPWSTR)pOutBuf, dwOutBufSize, pBytesReturned);
		
    case IOCTL_DISK_DEVICE_INFO: // new ioctl for disk info
        DEBUGMSG(ZONE_FUNCTION, (TEXT("-DSK_IOControl (device info) \r\n")));
        return GetDeviceInfo(pDisk, (PSTORAGEDEVICEINFO)pInBuf);
		
		//---------------------------//
		//     Power management      //
		//							 //
		// States :					 //
		//   - D0 : On				 //
		//	 - D1 : UserIdle		 //
		//   - D2 : SystemIdle		 //
		//	 - D3 : Suspend			 //
		//   - D4 : Off				 //
		//							 //
		//---------------------------//
	case IOCTL_POWER_CAPABILITIES:
		if (pOutBuf != NULL && dwOutBufSize == sizeof(POWER_CAPABILITIES))
		{
			PPOWER_CAPABILITIES ppc = (PPOWER_CAPABILITIES) pOutBuf;
			memset(ppc, 0, sizeof(*ppc));
			ppc->DeviceDx = (1<<D0) | (1<<D1) | (1<<D2) | (1<<D3) | (1<<D4);	// support D0,D1,D2,D3 and D4
			*pBytesReturned = sizeof(POWER_CAPABILITIES);
			DEBUGMSG(ZONE_FUNCTION, (TEXT("SDMemory Driver: IOCTL_POWER_CAPABILITIES\r\n")));
		}
		return TRUE;
		
	case IOCTL_POWER_QUERY:
		if(pOutBuf != NULL && dwOutBufSize == sizeof(CEDEVICE_POWER_STATE))
		{
			// return a good status on any valid query, since we are always ready to
			// change power states.
			CEDEVICE_POWER_STATE NewDx = *(PCEDEVICE_POWER_STATE) pOutBuf;
			if(!VALID_DX(NewDx))
			{
				// this is a valid Dx state so return a good status
				return FALSE;
			}
			DEBUGMSG(ZONE_FUNCTION, (TEXT("SDMemory Driver: IOCTL_POWER_QUERY\r\n")));
		}
		return TRUE;
		
	case IOCTL_POWER_SET:
		if(pOutBuf != NULL && dwOutBufSize == sizeof(CEDEVICE_POWER_STATE))
		{
			
			CEDEVICE_POWER_STATE NewDx = *(PCEDEVICE_POWER_STATE) pOutBuf;
			DEBUGMSG(ZONE_FUNCTION, (TEXT("SDMemory Driver: IOCTL_POWER_SET to %x\r\n"),NewDx));
			if(VALID_DX(NewDx))
			{
				if (NewDx == D0) // D0
				{
				ConfigPMC (pDisk,TRUE);
				}
				if (NewDx == D3 || NewDx == D4)
				{
				ConfigPMC ( pDisk,FALSE);	
				}
				else // D1, D2
				{
					// Nothing more when entering in this power state
				}
				
				pDisk->CurrentDx = NewDx;
			}			
		}
		return TRUE;
		
	case IOCTL_POWER_GET:
		if(pOutBuf != NULL && dwOutBufSize == sizeof(CEDEVICE_POWER_STATE))
		{
			
			*(PCEDEVICE_POWER_STATE) pOutBuf = 	pDisk->CurrentDx;			
			*pBytesReturned = sizeof(CEDEVICE_POWER_STATE);
			DEBUGMSG(ZONE_FUNCTION, (TEXT("SDMemory Driver: IOCTL_POWER_GET to %x\r\n"),pDisk->CurrentDx));
		}
		return TRUE;
		
		
		
		
		
		
		
		
		
		
    default:
        DEBUGMSG(ZONE_FUNCTION, (TEXT("-DSK_IOControl (default) \r\n")));
        SetLastError(ERROR_INVALID_PARAMETER);
        return FALSE;
    }
}

//-----------------------------------------------------------------------------
//! \fn			PDISK CreateDiskObject(void)
//!
//! \brief		This function initializes the global disk object
//!
//!	\return		\return a pointer to the disk object
//-----------------------------------------------------------------------------
PDISK CreateDiskObject(void)
{
    PDISK 						pDisk;
    /*
	AT91PS_MciDeviceDesc 		pDeviceDesc;	
	AT91PS_MciDeviceFeatures	pDeviceFeatures;
    AT91PS_MciDevice			pMciDevice;
*/

    DEBUGMSG(ZONE_FUNCTION, (TEXT("+CreateDiskObject\r\n")));

    pDisk = LocalAlloc(LMEM_ZEROINIT | LMEM_FIXED,sizeof(DISK));
	if (pDisk == NULL)
	{
		return NULL;
	}

	//pDeviceDesc = &(pDisk->DeviceDesc);
	//pDeviceFeatures = &(pDisk->DeviceFeatures);
	//pMciDevice = &g_MciDevice;
	
    //if ((pDisk != NULL)&&(pDeviceDesc != NULL)&&(pDeviceFeatures != NULL)&&(pMciDevice != NULL))
    {
        pDisk->d_OpenCount = 0;
        pDisk->d_ActivePath = NULL;
        InitializeCriticalSection(&(pDisk->d_DiskCardCrit));
        pDisk->d_DiskCardState = STATE_INITING;
        pDisk->dwMagicNumber = SDMAGICNUMBER;
         
        pDisk->MciDevice.pMCI_DeviceDesc = &(pDisk->DeviceDesc);
        pDisk->MciDevice.pMCI_DeviceFeatures = &(pDisk->DeviceFeatures);
         
		pDisk->MciDevice.pMCI_DeviceFeatures->Relative_Card_Address 		= 0;
		pDisk->MciDevice.pMCI_DeviceFeatures->Card_Inserted 				= AT91C_CARD_REMOVED;
		pDisk->MciDevice.pMCI_DeviceFeatures->Max_Read_DataBlock_Length	= 0;
		pDisk->MciDevice.pMCI_DeviceFeatures->Max_Write_DataBlock_Length 	= 0;
		pDisk->MciDevice.pMCI_DeviceFeatures->Read_Partial 				= 0;
		pDisk->MciDevice.pMCI_DeviceFeatures->Write_Partial 				= 0;
		pDisk->MciDevice.pMCI_DeviceFeatures->Erase_Block_Enable 			= 0;
		pDisk->MciDevice.pMCI_DeviceFeatures->Sector_Size 					= 0;
		pDisk->MciDevice.pMCI_DeviceFeatures->Memory_Capacity 				= 0;
		
		pDisk->MciDevice.pMCI_DeviceDesc->state							= AT91C_MCI_IDLE;
		pDisk->MciDevice.pMCI_DeviceDesc->SDCard_bus_width					= 4;       
        pDisk->dwSysIntr													= 0;
		pDisk->hInterruptEvent												= NULL;

    }
    
    DEBUGMSG(ZONE_FUNCTION, (TEXT("-CreateDiskObject\r\n")));
    return pDisk;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL IsValidDisk(PDISK pDisk)
//!
//! \brief		Dummy function to know if the structure is valid or not (according to a 'magic number').
//!
//! \param		pDisk	Pointer to a disk object.
//!
//! \return		\e TRUE indicates the disk is valid.
//! \return		\e FALSE indicates the disk is not valid.
//-----------------------------------------------------------------------------
BOOL IsValidDisk(PDISK pDisk)
{
   if (pDisk)
   {
   		if (pDisk->dwMagicNumber == SDMAGICNUMBER)
   		{
   			return TRUE;
   		}
   	}
   	return FALSE;
}


//-----------------------------------------------------------------------------
//! \fn			DWORD GetDiskStateError(DWORD dwDiskState)
//!
//! \brief		Give the Microsoft Error Code in function of a local error code.
//!
//! \param		dwDiskState	Local error code
//!
//! \return		Returns a Microsoft Error Code
//!
//! The OS invokes this function to suspend power to a device.
//-----------------------------------------------------------------------------
DWORD GetDiskStateError(DWORD dwDiskState)
{
    switch (dwDiskState)
    {
    case STATE_DEAD:
        return DISK_DEAD_ERROR;
        
    case STATE_REMOVED:
        return DISK_REMOVED_ERROR;
        
    }
    return ERROR_GEN_FAILURE;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL ConfigClockFromRegistry(LPCTSTR ActiveKey, AT91PS_MCI pMCI)
//!
//! \brief		Configure the MCI clock with the clock set by the user in registry
//!
//! \param		ActiveKey	Pointer to a string containing the registry path to the active key.
//! \param		pMCI		Pointer to the MCI controller
//!
//! \return		Returns a Microsoft Error Code
//!
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//-----------------------------------------------------------------------------
BOOL ConfigClockFromRegistry(LPCTSTR ActiveKey, AT91PS_MCI pMCI)
{
	HKEY hKey;
	DWORD dwData = 0;
	DWORD dwMasterClock = 0;
	DWORD dwComputedClock;
	DWORD dwClkdiv;
	DWORD dwSizeOfData = sizeof(DWORD);
	DWORD dwSDMaxClk = SDMemoryBoardSpecificGetMaxClock();

	hKey = OpenDeviceKey(ActiveKey);

	if (KernelIoControl(IOCTL_HAL_MASTERCLOCK, NULL, 0, &dwMasterClock, sizeof(dwMasterClock), 0) == FALSE)
	{
		DEBUGMSG(ZONE_ERROR, (TEXT("ConfigClockFromRegistry : KernelIoControl IOCTL_HAL_MASTERCLOCK FAILED\r\n")));
		return FALSE;
	}

	if (RegQueryValueEx(hKey, TEXT("Clock"), NULL, NULL, (LPBYTE)&dwData, &dwSizeOfData) != ERROR_SUCCESS)
	{
		DEBUGMSG(ZONE_ERROR, (TEXT("ConfigClockFromRegistry : RegQueryValueEx Clock Value FAILED\r\n")));
		return FALSE;
	}

	if (dwData > dwSDMaxClk)
	{
		RETAILMSG(1, (TEXT("ConfigClockFromRegistry : Clock is too high. Clipping it to %d Hz\r\n"),dwSDMaxClk));
		dwData = dwSDMaxClk;
	}
	if ((2*dwData) > (dwMasterClock))
	{
		RETAILMSG(1, (TEXT("ConfigClockFromRegistry : Clock is too high (couldn't be more than 2xMCK). Clipping it to %d Hz\r\n"),dwMasterClock/2));
		dwData = dwMasterClock/2;
	}
	
	{
		dwClkdiv = ((dwMasterClock / (2 * dwData)) - 1);

		if (dwClkdiv > 0xFF)
		{
			dwClkdiv = 0xFF;
		}


		dwComputedClock = dwMasterClock / (2 * (dwClkdiv + 1));		
		if ((dwComputedClock > dwData) && (dwClkdiv < 0xFF))
		{
			dwClkdiv++; 
		}
	}

	dwComputedClock = dwMasterClock / (2 * (dwClkdiv + 1));
	RETAILMSG(1, (TEXT("ConfigClockFromRegistry : Computed Clock = %d Hz\r\n"), dwComputedClock));

	pMCI->MCI_MR &= ~AT91C_MCI_CLKDIV;
	pMCI->MCI_MR |= (dwClkdiv & AT91C_MCI_CLKDIV);

	return TRUE;
}




//-----------------------------------------------------------------------------
//! \fn			VOID DSK_PowerDown(VOID)
//!
//! \brief		TODO
//!
//-----------------------------------------------------------------------------
VOID DSK_PowerDown(VOID)
{
		DEBUGMSG(1, (TEXT("DSK_PowerDown\n\r")));

}

//-----------------------------------------------------------------------------
//! \fn			VOID DSK_PowerUp(VOID)
//!
//! \brief		TODO
//!
//-----------------------------------------------------------------------------
VOID DSK_PowerUp(VOID)
{
	DEBUGMSG(1, (TEXT("DSK_PowerUP\n\r")));


}





DWORD DSK_Read(DWORD Handle, LPVOID pBuffer, DWORD dwNumBytes){return 0;}
DWORD DSK_Write(DWORD Handle, LPCVOID pBuffer, DWORD dwNumBytes){return 0;}
DWORD DSK_Seek(DWORD Handle, long lDistance, DWORD dwMoveMethod){return 0;}



//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/SDMEMORY/system.c $
//-----------------------------------------------------------------------------
//
//! @}
