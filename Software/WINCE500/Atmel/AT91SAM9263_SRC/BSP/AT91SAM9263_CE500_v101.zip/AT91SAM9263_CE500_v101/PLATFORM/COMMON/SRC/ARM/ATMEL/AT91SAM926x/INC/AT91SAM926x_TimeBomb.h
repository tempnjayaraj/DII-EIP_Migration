//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x_TimeBomb.h
//!
//! \brief		Time Bomb helpers
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/AT91SAM926x_TimeBomb.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//-----------------------------------------------------------------------------


#ifndef AT91SAM926X_TIMEBOMB_H
#define AT91SAM926X_TIMEBOMB_H

#ifdef OAL_TIMEBOMB

extern DWORD SC_GetTickCount(void);
#define DEFAULT_TIME_BOMB			(3600000) //Reset after 60 s
static DWORD g_dwResetTime = 0;
static BOOL coldReboot()
{
#define RESET_LENGTH  1 //in number of slow clock period


	AT91PS_RSTC pResetCtrl = (AT91PS_RSTC) OALPAtoVA((DWORD)AT91C_BASE_RSTC,FALSE);

	if (pResetCtrl == NULL)
	{
		return FALSE;
	}

	//Set up the length of the nRST pin assertion.
	pResetCtrl->RSTC_RMR = (pResetCtrl->RSTC_RMR & AT91C_RSTC_URSTEN & AT91C_RSTC_URSTIEN) | (0xA5 << 24 ) | (RESET_LENGTH << 8);

	//Assert the nRST pin
	pResetCtrl->RSTC_RCR = (0xA5 << 24 ) | AT91C_RSTC_EXTRST | AT91C_RSTC_PROCRST | AT91C_RSTC_PERRST;

	return TRUE;
}

#define TIMEBOMB_INIT_ONCE(y) \
{\
	/*ERRORMSG(1,(L"TIMEBOMB_INIT_ONCE ! \r\n"));*/\
	if (g_dwResetTime == 0)\
		g_dwResetTime = SC_GetTickCount() + (y);\
}


#define TIMEBOMB_CHECK(x) \
{\
	if (SC_GetTickCount() > g_dwResetTime)\
	{\
		/*RETAILMSG(1,(TEXT("TIMEBOMB ! "x##L"\r\n")));*/\
		RETAILMSG(1,(TEXT("TIMEBOMB ! (this binary version is limited in execution time.)\r\n")));\
		coldReboot();\
	}\
}

#else //OAL_TIMEBOMB

#define TIMEBOMB_INIT_ONCE(y)
#define TIMEBOMB_CHECK(x)

#endif //OAL_TIMEBOMBMB

#endif //AT91SAM926X_TIMEBOMB_H

//! @}


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/AT91SAM926x_TimeBomb.h $
////////////////////////////////////////////////////////////////////////////////
//
