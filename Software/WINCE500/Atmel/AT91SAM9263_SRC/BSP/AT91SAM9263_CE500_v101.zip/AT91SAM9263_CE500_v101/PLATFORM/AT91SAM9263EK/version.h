//-----------------------------------------------------------------------------
//! \addtogroup AT91SAM9263EK
//! @{
//
//  All rights reserved ADENEO SAS 2005
//
//! \file		version.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/version.h $
//!   $Author: ltourlonias $
//!   $Revision: 937 $
//!   $Date: 2007-06-05 13:41:56 +0200 (mar., 05 juin 2007) $
//! \endif
//
//-----------------------------------------------------------------------------

#define BSP_VERSION_MAJOR	1
#define BSP_VERSION_MINOR	0
#define BSP_VERSION_RELEASE	0
#define BUILD_NUMBER 001

//! @}
