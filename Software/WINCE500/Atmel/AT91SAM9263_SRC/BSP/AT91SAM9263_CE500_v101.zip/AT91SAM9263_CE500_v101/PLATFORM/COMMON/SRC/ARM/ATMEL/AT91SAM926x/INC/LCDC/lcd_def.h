//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		lcd_def.h
//!
//! \brief		Register definition
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/LCDC/lcd_def.h $
//!   $Author: pblanchard $
//!   $Revision: 993 $
//!   $Date: 2007-06-12 08:36:50 -0700 (Tue, 12 Jun 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	LCDC
//! @{
//!

#ifndef __LCDC_DEF__
#define __LCDC_DEF__

#include "AT91SAM926x.h"
#include "lib_AT91SAM926x.h"

#if CPLUSPLUS == 1
	#ifdef C_CALL
		#undef C_CALL
	#endif
	#define C_CALL	"C"
#else
	#ifdef C_CALL
		#undef C_CALL
	#endif
	#define C_CALL
#endif

/*// define which clocks will be used in PMC
#define LCDC_HCLK_ENABLE    (1 << 17)
#define LCDC_CORECLK_ENABLE (1 << 12)
#define LCDC_PCKR_ID        4
*/

typedef struct _AT91S_LCD_DMA  
{
    unsigned int DMABADDR1;
    unsigned int DMABADDR2;
    unsigned int DMAFRMPT1;
    unsigned int DMAFRMPT2;
    unsigned int DMAFRMADD1;
    unsigned int DMAFRMADD2;
    unsigned int DMAFRMCFG;
    unsigned int DMACON;
    unsigned int DMA2DCFG;    
}AT91S_LCD_DMA, *AT91PS_LCD_DMA;

typedef struct _AT91S_LCD_CONTROL  
{
    unsigned int LCDCON1;
    unsigned int LCDCON2;
    unsigned int LCDTIM1;
    unsigned int LCDTIM2;
    unsigned int LCDFRMCFG;
    unsigned int LCDFIFO;
    unsigned int LCDMVAL;
    unsigned int DP1_2;
    unsigned int DP4_7;
    unsigned int DP3_5;
    unsigned int DP2_3;
    unsigned int DP5_7;
    unsigned int DP3_4;
    unsigned int DP4_5;
    unsigned int DP6_7;
    unsigned int PWRCON;
    unsigned int CONTRAST_CTR;
    unsigned int CONTRAST_VAL;
    unsigned int LCD_IER;
    unsigned int LCD_IDR;
    unsigned int LCD_IMR;
    unsigned int LCD_ISR;
    unsigned int LCD_ICR;
    unsigned int LCD_GPR;
}AT91S_LCD_CONTROL, *AT91PS_LCD_CONTROL;


typedef struct _AT91S_LCD_LUT
{
    unsigned int LCDLUT[256];
}AT91S_LCD_LUT, *AT91PS_LCD_LUT;


typedef struct _AT91S_LCD
{
	AT91PS_LCD_DMA	    pdma_reg;
	AT91PS_LCD_CONTROL  pctrl_reg;
	AT91PS_LCD_LUT      plut_reg;
}AT91S_LCD, *AT91PS_LCD;




#define AT91C_LCD_PHYS_DMAREG_ADDR	       0x00600000
#define AT91C_LCD_PHYS_DMAREG_SIZE 	       0x20
#define AT91C_LCD_PHYS_CONTREG_ADDR	       0x00600800
#define AT91C_LCD_PHYS_CONTREG_SIZE	       0x60
#define AT91C_LCD_PHYS_LUT_ADDR		       0x00600C00
#define AT91C_LCD_PHYS_LUT_SIZE		       0x100

#define FR_PALETTE	256	

//! The lCD timings are hard coded, changing the �P clock may result in display bug

	#define AT91C_CLKVAL	3
	#define BRSTLN			3
	#define FIFO_MAX_SIZE	(512 - (2*(BRSTLN+1)+3))
	#define MVAL			0
	#define DISPPARAM		(AT91C_LCDC_MEMOR_LITTLEIND | AT91C_LCDC_DISTYPE_TFT | DISP16BIT | AT91C_LCDC_CLKMOD)
	#define CONTRAST		(CNT_SCLKDIV8 | PULSE_HIGH | CNT_ENABLE)
	#define CONTRASTVAL		0x000000DA




/********** DEFINITIONS **********/
// DMA Frame Configuration Register (32 bits)
//
// bit:  31.28, 27..24,23.22,21....0
//       0000 , BRSTLN,  00 ,FRMSIZE

#define BRSTLN_SHFT     24

// DMA Control Register (3 bits)
//
// bit:    2  ,   1    ,   0
//     DMABUSY, DNARST , DMAEN

#define DMA_BUSY        0x4
#define DMA_IDLE        0x0
#define DMA_RESET       0x2
#define DMA_2DEN		(1<<4)
#define DMA_UPDT		(1<<3)
#define ENABLE_DMA      0x1
#define DISABLE_DMA     0x0


// LCD Control 1 Register (32 bits):
// bit: 31..21, 20..12 ,11...1, 0
//      00..00, CLKVAL ,00..00,BYPASS

#define CLKVAL_SHFT     12
#define BYPASS_ENA	1

// LCD Control 2 Register (32 bits):
//
// bit: 31....20..16.... 15,   12     ,  11  ,   10  ,   9    ,  8  ,  7 . 5  , 4..3
//      MEMOR,00..00,CLKMOD,00,INVDVAL,INVCLK,INVLINE,INVFRAME,INVVD,PIXELSIZE,IFWIDTH
//         2   ,  1 . 0
//      SCANMOD,DISTYPE
#define BIGENDIAN       0x00000000
#define LITTLEENDIAN    0x80000000
#define CLKMOD          0x00008000
#define INVERT_DVAL     0x00001000
#define INVERT_CLK      0x00000800
#define INVERT_LINE     0x00000400
#define INVERT_FRM      0x00000200
#define INVERT_DATA     0x00000100

// PIXELSIZE
#define PS1BPP          0x00000000
#define PS2BPP          0x00000020
#define PS4BPP          0x00000040
#define PS8BPP          0x00000060
#define PS16BPP         0x00000080
#define PS24BPP         0x000000A0

// IFWIDTH
#define DISP4BIT        0x00000000
#define DISP8BIT        0x00000008
#define DISP16BIT       0x00000010

// SCANMOD
#define SINGLESCAN      0x00000000
#define DUALSCAN        0x00000004

// DISTYPE
#define STNMONO         0x00000000
#define STNCOLOR        0x00000001
#define TFT             0x00000002


// LCD Timing 1 Register (32 bits):
//
// bit: 31..21,20..12,11..8,7..4,3.1, 0

#define VFP_SHFT		0	// 0
#define VBP_SHFT		8	// 8
#define VPW_SHFT		16	// 16
#define VHDLY_SHFT		24	// 24

// LCD Timing 2 Register (32 bits):
//
// bit: 31..21,20..12,11..8,7..4,3.1, 0

#define HBP_SHFT	0	// 0
#define HPW_SHFT 	8	// 8
#define HFP_SHFT	21	// 21

// LCD Frame COnfiguration Register (32 bits):
//
// bit: 31. 21 , 20...11, 10 .. 0
//      HOZVAL , 0000000, LINEVAL

#define HOZVAL_SHFT     21

// LCD_MODE TOGGLE RATE Selection
// bit:  31 ,30....8,7..0
//     MMODE,00...00,MVAL

#define FRMMODE         0
#define MVALMODE        0x80000000


// Dithering Pattern recommended values
#define DP1_2_VAL       0xA5A5
#define DP4_7_VAL       0x5AF0FA5
#define DP3_5_VAL       0xA5A5F
#define DP2_3_VAL       0xAF5
#define DP5_7_VAL       0xFAF5FA5
#define DP3_4_VAL       0xFA5F
#define DP4_5_VAL       0xFAF5F
#define DP6_7_VAL       0xF5FFAFF

#define INIT_DITH       1
#define NO_INIT_DITH    0


// Power Control Register (8 bits):
//
// bit: 7  ....  1 ,    0
//      GUARD_TIME ,  ENABLE	

#define GUARDTIME_SHFT  1
#define ENABLE_LCD      0x01
#define DISABLE_LCD     0x00

// Contrast Control Register (4 bits):
//
// bit:  3  ,  2  , 1..0
//      ENA , POL ,  PS

#define CNT_ENABLE      0x8
#define PULSE_HIGH      0x4
#define PULSE_LOW       0x0
#define CNT_SCLK        0x0
#define CNT_SCLKDIV2    0x1
#define CNT_SCLKDIV4    0x2
#define CNT_SCLKDIV8    0x3


// Interrupt registers (Enable, Disable, Clear) (7 bits):
// bit:  6 , 5 ,  4 ,  3  , 2 ,  1  , 0
//      MER,OWR,UFLW,CRRPT,EOF,LSTLN,LN

//#define NO_IRQ          0x00
#define MER_IRQ         0x40
#define OWR_IRQ         0x20
#define UFLW_IRQ        0x10
#define CRRPT_IRQ       0x08
#define EOF_IRQ         0x04
#define LASTLINE_IRQ    0x02
#define LINE_IRQ        0x01
#define ALL_IRQ         0x7F


extern struct s_attributs attribs_lcd;	

#endif /*__LCDC_DEF__*/

//extern /*"C"*/ void AT91F_InitBWLcd();
//extern void AT91F_InitLcd(void);

//! @}

////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/LCDC/lcd_def.h $
////////////////////////////////////////////////////////////////////////////////


//! @}
