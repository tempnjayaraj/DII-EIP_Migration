//-----------------------------------------------------------------------------
//! \addtogroup   SDMMC
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				AT91RM9200_MCI_device.c
//!
//! \brief				Low level functions for MCI
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/DRIVERS/Sdcard/AT91RM9200_mci_device.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//! Implementation based on ATMEL Microcontroller Software Support  -  ROUSSET  -
//! 
//-----------------------------------------------------------------------------

#include <windows.h>
#include <diskio.h>
#include <storemgr.h>

#include "AT91RM9200_MCI_Device.h"
#include "AT91RM9200_sdmmc.h"


#define DEFAULT_TIMEOUT 1000
#define MAX_LOOP_GETSTATUS 1000


DWORD WaitForStatus(AT91PS_MciDevice pMCI_Device,DWORD targetStatusMask,DWORD Timeout,PDISK pDisk)
{
	DWORD count=0;
	DWORD date = GetTickCount();
	//Get the current interrupt mask
	DWORD oldInterruptMask = g_pMCI->MCI_IMR;
	//Enable only the interrupts we're interrested in
	g_pMCI->MCI_IDR = 0xFFFFFFFF;
	g_pMCI->MCI_IER = targetStatusMask;


	while (((g_pMCI->MCI_SR & targetStatusMask) != targetStatusMask) && (GetTickCount() - date < Timeout))
	{
		if (count)
		{
		// 	RETAILMSG(1,(TEXT("WaitForStatus count %d\r\n"),count));

		}
		if (WaitForSingleObject(pDisk->hInterruptEvent,Timeout) == WAIT_TIMEOUT)
		{
			RETAILMSG(1,(TEXT("WaitForSingleObject(pDisk->hInterruptEvent,Timeout) == WAIT_TIMEOUT\r\nstatux 0x%x\r\n"),g_pMCI->MCI_SR));
		}
		else
		{
			InterruptDone(pDisk->dwSysIntr);
		}
		count++;
	}

	//Restore old interrupt mask;
	g_pMCI->MCI_IDR = 0xFFFFFFFF;
	g_pMCI->MCI_IER = oldInterruptMask;

	return (g_pMCI->MCI_SR & targetStatusMask);
}

 
//*----------------------------------------------------------------------------
//* \fn    AT91F_MCI_SendCommand
//* \brief Generic function to send a command to the MMC or SDCard
//*----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_SendCommand (
	AT91PS_MciDevice pMCI_Device,
	unsigned int Cmd,
	unsigned int Arg,PDISK pDisk)
{
	unsigned int	error;
	//unsigned int	tick=0;

    // Send the command
    g_pMCI->MCI_ARGR = Arg;
    g_pMCI->MCI_CMDR = Cmd;

	// wait for CMDRDY Status flag to read the response
	WaitForStatus(pMCI_Device,AT91C_MCI_CMDRDY,100,pDisk);

    // Test error  ==> if crc error and response R3 ==> don't check error
    error = (g_pMCI->MCI_SR) & AT91C_MCI_SR_CMD_ERROR;
	if(error != 0 )
	{
		// if the command is SEND_OP_COND the CRC error flag is always present (cf : R3 response)
		if ( (Cmd != AT91C_SDCARD_APP_OP_COND_CMD) && (Cmd != AT91C_MMC_SEND_OP_COND_CMD) )
			return ((g_pMCI->MCI_SR) & AT91C_MCI_SR_ERROR);
		else
		{
			if (error != AT91C_MCI_RCRCE)
				return ((g_pMCI->MCI_SR) & AT91C_MCI_SR_ERROR);
		}
	}
	//Wait for the device to be ready
	//WaitForStatus(pMCI_Device,AT91C_MCI_NOTBUSY,100,pDisk);

    return AT91C_CMD_SEND_OK;
}

//*----------------------------------------------------------------------------
//* \fn    AT91F_MCI_SDCard_SendAppCommand
//* \brief Specific function to send a specific command to the SDCard
//*----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_SDCard_SendAppCommand (
	AT91PS_MciDevice pMCI_Device,
	unsigned int Cmd_App,
	unsigned int Arg,
	PDISK pDisk)
{
	unsigned int error;
	//unsigned int	tick=0;

	// Send the CMD55 for application specific command
    g_pMCI->MCI_ARGR = (pMCI_Device->pMCI_DeviceFeatures->Relative_Card_Address << 16 );
    g_pMCI->MCI_CMDR = AT91C_APP_CMD;

	// wait for CMDRDY Status flag to read the response
	WaitForStatus(pMCI_Device,AT91C_MCI_CMDRDY,100,pDisk);

    // check if it is a specific command and then send the command
	if ( (Cmd_App && AT91C_SDCARD_APP_ALL_CMD) == 0)
		return AT91C_CMD_SEND_ERROR;
	
	error = AT91F_MCI_SendCommand(pMCI_Device,Cmd_App,Arg,pDisk);

	return(error);
}


//*----------------------------------------------------------------------------
//* \fn    AT91F_MCI_GetStatus
//* \brief Addressed card sends its status register
//*----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_GetStatus(AT91PS_MciDevice pMCI_Device,unsigned int relative_card_address,PDISK pDisk)
{
	if (AT91F_MCI_SendCommand(pMCI_Device,
								AT91C_SEND_STATUS_CMD,
								relative_card_address <<16,pDisk) == AT91C_CMD_SEND_OK)
		return (g_pMCI->MCI_RSPR[0]);

		return AT91C_CMD_SEND_ERROR;
}

//*----------------------------------------------------------------------------
//* \fn    AT91F_MCI_ReadBlock
//* \brief Read an ENTIRE block or PARTIAL block
//*----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_ReadBlock(
	AT91PS_MciDevice pMCI_Device,
	int src,
	unsigned int *dataBuffer,
	unsigned int sizeToRead,
	PDISK pDisk)
{
    unsigned int status;
	unsigned char loop;

	////////////////////////////////////////////////////////////////////////////////////////////
     if(pMCI_Device->pMCI_DeviceDesc->state != AT91C_MCI_IDLE)
  	{
		RETAILMSG(1, (TEXT("AT91F_MCI_ReadBlock-ERROR-test1\n\r")));
		 return AT91C_READ_ERROR;
    }
  	

    if ( (unsigned)(src + sizeToRead) > pMCI_Device->pMCI_DeviceFeatures->Memory_Capacity )
  	{
		RETAILMSG(1, (TEXT("AT91F_MCI_ReadBlock-ERROR-test3\n\r")));
		 return AT91C_READ_ERROR;
    }

    // If source does not fit a begin of a block
	if ( (src % pMCI_Device->pMCI_DeviceFeatures->Max_Read_DataBlock_Length) != 0 )
  	{
		RETAILMSG(1, (TEXT("AT91F_MCI_ReadBlock-ERROR-test4\n\r")));
		 return AT91C_READ_ERROR;
    }
   
     // Test if the MMC supports Partial Read Block
     // ALWAYS SUPPORTED IN SD Memory Card
     if( (sizeToRead < pMCI_Device->pMCI_DeviceFeatures->Max_Read_DataBlock_Length) 
    	&& (pMCI_Device->pMCI_DeviceFeatures->Read_Partial == 0x00) )
  	{
		RETAILMSG(1, (TEXT("AT91F_MCI_ReadBlock-ERROR-test5\n\r")));
		 return AT91C_READ_ERROR;
    }
   	
    if( sizeToRead > pMCI_Device->pMCI_DeviceFeatures->Max_Read_DataBlock_Length)
  	{
		RETAILMSG(1, (TEXT("AT91F_MCI_ReadBlock-ERROR-test6\n\r")));
		 return AT91C_READ_ERROR;
    }


    ////////////////////////////////////////////////////////////////////////////////////////////
      
    // Init Mode Register
	g_pMCI->MCI_MR |= ((pMCI_Device->pMCI_DeviceFeatures->Max_Read_DataBlock_Length << 16) | AT91C_MCI_PDCMODE);
	 
    if (sizeToRead %4)
		sizeToRead = (sizeToRead /4)+1;
	else
		sizeToRead = sizeToRead/4;


	loop = 0;
	do
	{
		// wait for AT91C_MCI_NOTBUSY flag to be set.
		WaitForStatus(pMCI_Device,AT91C_MCI_NOTBUSY,1000,pDisk);
		
		g_pPDC->PDC_PTCR = (AT91C_PDC_TXTDIS | AT91C_PDC_RXTDIS);
		g_pPDC->PDC_RPR  = (unsigned int) dataBuffer;
		g_pPDC->PDC_RCR  = sizeToRead;
		pMCI_Device->pMCI_DeviceDesc->state = AT91C_MCI_RX_SINGLE_BLOCK;
	
		// (PDC) Receiver Transfer Enable
		g_pPDC->PDC_PTCR = AT91C_PDC_RXTEN;

		// Send the Read single block command & test errors
		AT91F_MCI_SendCommand(pMCI_Device, AT91C_READ_SINGLE_BLOCK_CMD, src,pDisk);

	 	// wait for ENDRX flag to be set.
		WaitForStatus(pMCI_Device,AT91C_MCI_ENDRX,100,pDisk);


		status = (g_pMCI->MCI_SR & AT91C_MCI_SR_DATA_TRANSFER_ERROR);
		//DEBUGMSG(ZONE_IO, (TEXT("Read_block_CMD_status ->0x%x\r\n"),status));
		//DEBUGMSG(ZONE_IO, (TEXT("RD_loop -> %d\n\r"),loop));

	}
	while((status != AT91C_CMD_SEND_OK) && (loop++ < 10));

	if(status != AT91C_CMD_SEND_OK)
	{
		RETAILMSG(1, (TEXT("AT91F_MCI_ReadBlock-ERROR-%d\n\r"),loop));
		return AT91C_READ_ERROR;
	}
	else
	{
		//RETAILMSG(1, (TEXT("AT91F_MCI_ReadBlock-OK-%d\n\r"),count));
		return AT91C_READ_OK;
	}
}

//*----------------------------------------------------------------------------
//* \fn    AT91F_MCI_WriteBlock
//* \brief  Write an ENTIRE block but not always PARTIAL block !!!
//*----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_WriteBlock(
	AT91PS_MciDevice pMCI_Device,
	int dest,
	unsigned int *dataBuffer,
	unsigned int sizeToWrite,
	PDISK pDisk)
{
    unsigned int status;
	unsigned char loop;

    ////////////////////////////////////////////////////////////////////////////////////////////
	if(pMCI_Device->pMCI_DeviceDesc->state != AT91C_MCI_IDLE)
	{
		RETAILMSG(1, (TEXT("AT91F_MCI_WriteBlock-ERROR-test1\n\r")));
		return AT91C_WRITE_ERROR;
    }


    if ((unsigned)(dest + sizeToWrite) > pMCI_Device->pMCI_DeviceFeatures->Memory_Capacity )
	{
		RETAILMSG(1, (TEXT("AT91F_MCI_WriteBlock-ERROR-test3\n\r")));
		return AT91C_WRITE_ERROR;
    }

    // If source does not fit a begin of a block
	if ( (dest % pMCI_Device->pMCI_DeviceFeatures->Max_Read_DataBlock_Length) != 0 )
	{
		RETAILMSG(1, (TEXT("AT91F_MCI_WriteBlock-ERROR-test4\n\r")));
		return AT91C_WRITE_ERROR;
    }
   
    // Test if the MMC supports Partial Write Block 
    if((sizeToWrite < pMCI_Device->pMCI_DeviceFeatures->Max_Write_DataBlock_Length) 
    	&& (pMCI_Device->pMCI_DeviceFeatures->Write_Partial == 0x00) )
	{
		RETAILMSG(1, (TEXT("AT91F_MCI_WriteBlock-ERROR-test5\n\r")));
		return AT91C_WRITE_ERROR;
    }
   		
   	if(sizeToWrite > pMCI_Device->pMCI_DeviceFeatures->Max_Write_DataBlock_Length )
	{
		RETAILMSG(1, (TEXT("AT91F_MCI_WriteBlock-ERROR-test6\n\r")));
		return AT91C_WRITE_ERROR;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////
  
    // Init Mode Register
	g_pMCI->MCI_MR |= ((pMCI_Device->pMCI_DeviceFeatures->Max_Write_DataBlock_Length << 16) | AT91C_MCI_PDCMODE);
	
	if (sizeToWrite %4)
		sizeToWrite = (sizeToWrite /4)+1;
	else
		sizeToWrite = sizeToWrite/4;


	// Init PDC for write sequence
	loop = 0;
	do
	{
		// wait for AT91C_MCI_NOTBUSY flag to be set.
		WaitForStatus(pMCI_Device,AT91C_MCI_NOTBUSY,1000,pDisk);

		g_pPDC->PDC_PTCR = (AT91C_PDC_TXTDIS | AT91C_PDC_RXTDIS);
		g_pPDC->PDC_TPR = (unsigned int)dataBuffer;
		g_pPDC->PDC_TCR = sizeToWrite;
		pMCI_Device->pMCI_DeviceDesc->state = AT91C_MCI_TX_SINGLE_BLOCK;


		 // Send the write single block command & test errors
		AT91F_MCI_SendCommand(pMCI_Device, AT91C_WRITE_BLOCK_CMD/* AT91C_WRITE_MULTIPLE_BLOCK_CMD*/, dest,pDisk);


		// Enables TX for PDC transfert requests
		g_pPDC->PDC_PTCR = AT91C_PDC_TXTEN;


	 	// wait for ENDTX flag to be set.
		WaitForStatus(pMCI_Device,AT91C_MCI_ENDTX,100,pDisk);
		
		status = (g_pMCI->MCI_SR & AT91C_MCI_SR_DATA_TRANSFER_ERROR);
		DEBUGMSG(ZONE_IO, (TEXT("write_block_CMD_status ->0x%x\r\n"),status));
		DEBUGMSG(ZONE_IO, (TEXT("WR_loop -> %d\n\r"),loop));

	}
	while((status != AT91C_CMD_SEND_OK) && (loop++ < 10));

	if(status != AT91C_CMD_SEND_OK)
	{
		RETAILMSG(1, (TEXT("AT91F_MCI_WriteBlock-ERROR-loop %d\n\r"),loop));
		return AT91C_WRITE_ERROR;
	}

	else
	{
	//	RETAILMSG(1, (TEXT("AT91F_MCI_WriteBlock-OK-%d\n\r"),count));
		return AT91C_WRITE_OK;
	}
}

//*------------------------------------------------------------------------------------------------------------
//* \fn    AT91F_MCI_MMC_SelectCard
//* \brief Toggles a card between the Stand_by and Transfer states or between Programming and Disconnect states
//*------------------------------------------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_MMC_SelectCard(AT91PS_MciDevice pMCI_Device, unsigned int relative_card_address,
	PDISK pDisk)
{
    int status;
	
	//* Check if the MMC card chosen is already the selected one
	status = AT91F_MCI_GetStatus(pMCI_Device,relative_card_address,pDisk);

	if (status < 0)
		return AT91C_CARD_SELECTED_ERROR;

	if ((status & AT91C_SR_CARD_SELECTED) == AT91C_SR_CARD_SELECTED)
		return AT91C_CARD_SELECTED_OK;

	//* Search for the MMC Card to be selected, status = the Corresponding Device Number
	status = 0;
	while( (pMCI_Device->pMCI_DeviceFeatures[status].Relative_Card_Address != relative_card_address)
		   && (status < AT91C_MAX_MCI_CARDS) )
		status++;

	if (status > AT91C_MAX_MCI_CARDS)
    	return AT91C_CARD_SELECTED_ERROR;

    if (AT91F_MCI_SendCommand( pMCI_Device,
    								   AT91C_SEL_DESEL_CARD_CMD,
    								   pMCI_Device->pMCI_DeviceFeatures[status].Relative_Card_Address << 16,pDisk) == AT91C_CMD_SEND_OK)
    	return AT91C_CARD_SELECTED_OK;
    return AT91C_CARD_SELECTED_ERROR;
}

//*----------------------------------------------------------------------------
//* \fn    AT91F_MCI_GetCSD
//* \brief Asks to the specified card to send its CSD
//*----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_GetCSD (AT91PS_MciDevice pMCI_Device, unsigned int relative_card_address , unsigned int * response,
	PDISK pDisk)
{
 	
 	if(AT91F_MCI_SendCommand(pMCI_Device,
								  AT91C_SEND_CSD_CMD,
								  (relative_card_address << 16),pDisk) != AT91C_CMD_SEND_OK)
		return AT91C_CMD_SEND_ERROR;
	
    response[0] = g_pMCI->MCI_RSPR[0];
   	response[1] = g_pMCI->MCI_RSPR[1];
    response[2] = g_pMCI->MCI_RSPR[2];
    response[3] = g_pMCI->MCI_RSPR[3];
    
    return AT91C_CMD_SEND_OK;
}

//*----------------------------------------------------------------------------
//* \fn    AT91F_MCI_SetBlocklength
//* \brief Select a block length for all following block commands (R/W)
//*----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_SetBlocklength(AT91PS_MciDevice pMCI_Device,unsigned int length,
	PDISK pDisk)
{
    return( AT91F_MCI_SendCommand(pMCI_Device, AT91C_SET_BLOCKLEN_CMD, length,pDisk) );
}

//*----------------------------------------------------------------------------
//* \fn    AT91F_MCI_MMC_GetAllOCR
//* \brief Asks to all cards to send their operations conditions
//*----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_MMC_GetAllOCR (AT91PS_MciDevice pMCI_Device,
	PDISK pDisk)
{
	unsigned int	response =0x0;
 	
 	while(1)
    {
    	response = AT91F_MCI_SendCommand(pMCI_Device,
  										AT91C_MMC_SEND_OP_COND_CMD,
  										AT91C_MMC_HOST_VOLTAGE_RANGE,pDisk);
		if (response != AT91C_CMD_SEND_OK)
			return AT91C_INIT_ERROR;
		
		response = g_pMCI->MCI_RSPR[0];
		
		if ( (response & AT91C_CARD_POWER_UP_BUSY) == AT91C_CARD_POWER_UP_BUSY)
			return(response);	
	}
}

//*----------------------------------------------------------------------------
//* \fn    AT91F_MCI_MMC_GetAllCID
//* \brief Asks to the MMC on the chosen slot to send its CID
//*----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_MMC_GetAllCID (AT91PS_MciDevice pMCI_Device, unsigned int *response,
	PDISK pDisk)
{
	int Nb_Cards_Found=-1;
  
	while(1)
	{
	 	if(AT91F_MCI_SendCommand(pMCI_Device,
								AT91C_MMC_ALL_SEND_CID_CMD,
								AT91C_NO_ARGUMENT,pDisk) != AT91C_CMD_SEND_OK)
			return Nb_Cards_Found;
		else
		{		
			Nb_Cards_Found = 0;
			//* Assignation of the relative address to the MMC CARD
			pMCI_Device->pMCI_DeviceFeatures[Nb_Cards_Found].Relative_Card_Address = Nb_Cards_Found + AT91C_FIRST_RCA;
			//* Set the insert flag
			pMCI_Device->pMCI_DeviceFeatures[Nb_Cards_Found].Card_Inserted = AT91C_MMC_CARD_INSERTED;
	
			if (AT91F_MCI_SendCommand(pMCI_Device,
									 AT91C_MMC_SET_RELATIVE_ADDR_CMD,
									 (Nb_Cards_Found + AT91C_FIRST_RCA) << 16,pDisk) != AT91C_CMD_SEND_OK)
				return AT91C_CMD_SEND_ERROR;
				 
			//* If no error during assignation address ==> Increment Nb_cards_Found
			Nb_Cards_Found++ ;
		}
	}
}

//*----------------------------------------------------------------------------
//* \fn    AT91F_MCI_MMC_Init
//* \brief Return the MMC initialisation status
//*----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_MMC_Init (AT91PS_MciDevice pMCI_Device,
	PDISK pDisk)
{
    unsigned int	tab_response[4];
	unsigned int	mult,blocknr;
	unsigned int 	i,Nb_Cards_Found=0;

	//* Resets all MMC Cards in Idle state
	AT91F_MCI_SendCommand(pMCI_Device, AT91C_MMC_GO_IDLE_STATE_CMD, AT91C_NO_ARGUMENT,pDisk);

    if(AT91F_MCI_MMC_GetAllOCR(pMCI_Device,pDisk) == AT91C_INIT_ERROR)
    	return AT91C_INIT_ERROR;

	Nb_Cards_Found = AT91F_MCI_MMC_GetAllCID(pMCI_Device,tab_response,pDisk);
	if (Nb_Cards_Found != AT91C_CMD_SEND_ERROR)
	{
	    //* Set the Mode Register
    	g_pMCI->MCI_MR = AT91C_MCI_MR_PDCMODE | 0xFF;

		for(i = 0; i < Nb_Cards_Found; i++)
		{
			if (AT91F_MCI_GetCSD(pMCI_Device,
									  pMCI_Device->pMCI_DeviceFeatures[i].Relative_Card_Address,
									  tab_response,pDisk) != AT91C_CMD_SEND_OK)
				pMCI_Device->pMCI_DeviceFeatures[i].Relative_Card_Address = 0;					  
			else
			{
				pMCI_Device->pMCI_DeviceFeatures[i].Max_Read_DataBlock_Length = 1 << ((tab_response[1] >> AT91C_CSD_RD_B_LEN_S) & AT91C_CSD_RD_B_LEN_M );
	 			pMCI_Device->pMCI_DeviceFeatures[i].Max_Write_DataBlock_Length =	1 << ((tab_response[3] >> AT91C_CSD_WBLEN_S) & AT91C_CSD_WBLEN_M );
				pMCI_Device->pMCI_DeviceFeatures[i].Sector_Size = 1 + ((tab_response[2] >> AT91C_CSD_v22_SECT_SIZE_S) & AT91C_CSD_v22_SECT_SIZE_M );
		  		pMCI_Device->pMCI_DeviceFeatures[i].Read_Partial = (tab_response[1] >> AT91C_CSD_RD_B_PAR_S) & AT91C_CSD_RD_B_PAR_M;
				pMCI_Device->pMCI_DeviceFeatures[i].Write_Partial = (tab_response[3] >> AT91C_CSD_WBLOCK_P_S) & AT91C_CSD_WBLOCK_P_M;
				
				// None in MMC specification version 2.2
				pMCI_Device->pMCI_DeviceFeatures[i].Erase_Block_Enable = 0;
				
				pMCI_Device->pMCI_DeviceFeatures[i].Read_Block_Misalignment = (tab_response[1] >> AT91C_CSD_RD_B_MIS_S) & AT91C_CSD_RD_B_MIS_M;
				pMCI_Device->pMCI_DeviceFeatures[i].Write_Block_Misalignment = (tab_response[1] >> AT91C_CSD_WR_B_MIS_S) & AT91C_CSD_WR_B_MIS_M;

				//// Compute Memory Capacity
				// compute MULT
				mult = 1 << ( ((tab_response[2] >> AT91C_CSD_C_SIZE_M_S) & AT91C_CSD_C_SIZE_M_M) + 2 );
				// compute MSB of C_SIZE
				blocknr = ((tab_response[1] >> AT91C_CSD_CSIZE_H_S) & AT91C_CSD_CSIZE_H_M) << 2;
				// compute MULT * (LSB of C-SIZE + MSB already computed + 1) = BLOCKNR
				blocknr = mult * ( ( blocknr + ( (tab_response[2] >> AT91C_CSD_CSIZE_L_S) & AT91C_CSD_CSIZE_L_M) ) + 1 );

				pMCI_Device->pMCI_DeviceFeatures[i].Memory_Capacity =  pMCI_Device->pMCI_DeviceFeatures[i].Max_Read_DataBlock_Length * blocknr;
		  		//// End of Compute Memory Capacity

				// From now on, ignore the MAX Block length given by the SDCARD, we'll always use a 512 bytes sector size
				pMCI_Device->pMCI_DeviceFeatures[i].Max_Read_DataBlock_Length = SD_BYTES_PER_SECTOR;
				pMCI_Device->pMCI_DeviceFeatures[i].Max_Write_DataBlock_Length = SD_BYTES_PER_SECTOR;
			}	// end of else	
		}	// end of for
		
		return AT91C_INIT_OK;
	}	// end of if

    return AT91C_INIT_ERROR;
}

//*----------------------------------------------------------------------------
//* \fn    AT91F_MCI_SDCard_GetOCR
//* \brief Asks to all cards to send their operations conditions
//*----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_SDCard_GetOCR (AT91PS_MciDevice pMCI_Device,
	PDISK pDisk)
{
	unsigned int	response =0x0;

	// The RCA to be used for CMD55 in Idle state shall be the card's default RCA=0x0000.
	pMCI_Device->pMCI_DeviceFeatures->Relative_Card_Address = 0x0;
 	
 	while( (response & AT91C_CARD_POWER_UP_BUSY) != AT91C_CARD_POWER_UP_BUSY )
    {
    	response = AT91F_MCI_SDCard_SendAppCommand(pMCI_Device,
  										AT91C_SDCARD_APP_OP_COND_CMD,
  										AT91C_MMC_HOST_VOLTAGE_RANGE,pDisk);
		//if (response != AT91C_CMD_SEND_OK)
		//	return AT91C_INIT_ERROR;
		
		response = (g_pMCI->MCI_RSPR[0]);
	}
		
	return(g_pMCI->MCI_RSPR[0]);
}

//*----------------------------------------------------------------------------
//* \fn    AT91F_MCI_SDCard_GetCID
//* \brief Asks to the SDCard on the chosen slot to send its CID
//*----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_SDCard_GetCID (AT91PS_MciDevice pMCI_Device, unsigned int *response,
	PDISK pDisk)
{
 	if(AT91F_MCI_SendCommand(pMCI_Device,
							AT91C_ALL_SEND_CID_CMD,
							AT91C_NO_ARGUMENT,pDisk) != AT91C_CMD_SEND_OK)
		return AT91C_CMD_SEND_ERROR;
	
    response[0] = g_pMCI->MCI_RSPR[0];
   	response[1] = g_pMCI->MCI_RSPR[1];
    response[2] = g_pMCI->MCI_RSPR[2];
    response[3] = g_pMCI->MCI_RSPR[3];
    
    return AT91C_CMD_SEND_OK;
}

//*----------------------------------------------------------------------------
//* \fn    AT91F_MCI_SDCard_SetBusWidth
//* \brief  Set bus width for SDCard
//*----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_SDCard_SetBusWidth(AT91PS_MciDevice pMCI_Device,
	PDISK pDisk)
{
	volatile int	ret_value;
	char			bus_width;

	do
	{
		ret_value =AT91F_MCI_GetStatus(pMCI_Device,pMCI_Device->pMCI_DeviceFeatures->Relative_Card_Address,pDisk);
	}
	while((ret_value > 0) && ((ret_value & AT91C_SR_READY_FOR_DATA) == 0));

	// Select Card
    AT91F_MCI_SendCommand(pMCI_Device,
    						AT91C_SEL_DESEL_CARD_CMD,
    						(pMCI_Device->pMCI_DeviceFeatures->Relative_Card_Address)<<16,pDisk);

	// Set bus width for Sdcard
	if(pMCI_Device->pMCI_DeviceDesc->SDCard_bus_width == AT91C_MCI_SCDBUS)
		 	bus_width = AT91C_BUS_WIDTH_4BITS;
	else	bus_width = AT91C_BUS_WIDTH_1BIT;

	if (AT91F_MCI_SDCard_SendAppCommand(pMCI_Device,AT91C_SDCARD_SET_BUS_WIDTH_CMD,bus_width,pDisk) != AT91C_CMD_SEND_OK)
		return AT91C_CMD_SEND_ERROR;

	return AT91C_CMD_SEND_OK;
}

//*----------------------------------------------------------------------------
//* \fn    AT91F_MCI_SDCard_Init
//* \brief Return the SDCard initialisation status
//*----------------------------------------------------------------------------
AT91S_MCIDeviceStatus AT91F_MCI_SDCard_Init (AT91PS_MciDevice pMCI_Device,
	PDISK pDisk)
{
    unsigned int	tab_response[4];
	unsigned int	mult,blocknr;

	AT91F_MCI_SendCommand(pMCI_Device, AT91C_GO_IDLE_STATE_CMD, AT91C_NO_ARGUMENT,pDisk);

	if(AT91F_MCI_SDCard_GetOCR(pMCI_Device,pDisk) == AT91C_INIT_ERROR)
		return AT91C_INIT_ERROR;
    
/*	if */AT91F_MCI_SDCard_GetCID(pMCI_Device,tab_response,pDisk);// == AT91C_CMD_SEND_OK)
	{
	    pMCI_Device->pMCI_DeviceFeatures->Card_Inserted = AT91C_SD_CARD_INSERTED;

	    /*if (*/AT91F_MCI_SendCommand(pMCI_Device, AT91C_SET_RELATIVE_ADDR_CMD, 0,pDisk); //== AT91C_CMD_SEND_OK)
		{
			pMCI_Device->pMCI_DeviceFeatures->Relative_Card_Address = (g_pMCI->MCI_RSPR[0] >> 16);
		/*	if (*/AT91F_MCI_GetCSD(pMCI_Device,pMCI_Device->pMCI_DeviceFeatures->Relative_Card_Address,tab_response,pDisk); //== AT91C_CMD_SEND_OK)
			{
		  		pMCI_Device->pMCI_DeviceFeatures->Max_Read_DataBlock_Length = 1 << ((tab_response[1] >> AT91C_CSD_RD_B_LEN_S) & AT91C_CSD_RD_B_LEN_M );
	 			pMCI_Device->pMCI_DeviceFeatures->Max_Write_DataBlock_Length =	1 << ((tab_response[3] >> AT91C_CSD_WBLEN_S) & AT91C_CSD_WBLEN_M );
				pMCI_Device->pMCI_DeviceFeatures->Sector_Size = 1 + ((tab_response[2] >> AT91C_CSD_v21_SECT_SIZE_S) & AT91C_CSD_v21_SECT_SIZE_M );
		  		pMCI_Device->pMCI_DeviceFeatures->Read_Partial = (tab_response[1] >> AT91C_CSD_RD_B_PAR_S) & AT91C_CSD_RD_B_PAR_M;
				pMCI_Device->pMCI_DeviceFeatures->Write_Partial = (tab_response[3] >> AT91C_CSD_WBLOCK_P_S) & AT91C_CSD_WBLOCK_P_M;
				pMCI_Device->pMCI_DeviceFeatures->Erase_Block_Enable = (tab_response[3] >> AT91C_CSD_v21_ER_BLEN_EN_S) & AT91C_CSD_v21_ER_BLEN_EN_M;
				pMCI_Device->pMCI_DeviceFeatures->Read_Block_Misalignment = (tab_response[1] >> AT91C_CSD_RD_B_MIS_S) & AT91C_CSD_RD_B_MIS_M;
				pMCI_Device->pMCI_DeviceFeatures->Write_Block_Misalignment = (tab_response[1] >> AT91C_CSD_WR_B_MIS_S) & AT91C_CSD_WR_B_MIS_M;

				// Compute Memory Capacity
				// compute MULT
				mult = 1 << ( ((tab_response[2] >> AT91C_CSD_C_SIZE_M_S) & AT91C_CSD_C_SIZE_M_M) + 2 );
				// compute MSB of C_SIZE
				blocknr = ((tab_response[1] >> AT91C_CSD_CSIZE_H_S) & AT91C_CSD_CSIZE_H_M) << 2;
				// compute MULT * (LSB of C-SIZE + MSB already computed + 1) = BLOCKNR
				blocknr = mult * ( ( blocknr + ( (tab_response[2] >> AT91C_CSD_CSIZE_L_S) & AT91C_CSD_CSIZE_L_M) ) + 1 );

				pMCI_Device->pMCI_DeviceFeatures->Memory_Capacity =  pMCI_Device->pMCI_DeviceFeatures->Max_Read_DataBlock_Length * blocknr;
				// End of Compute Memory Capacity

				// From now on, ignore the MAX Block length given by the SDCARD, we'll always use a 512 bytes sector size
				pMCI_Device->pMCI_DeviceFeatures->Max_Read_DataBlock_Length = SD_BYTES_PER_SECTOR;
				pMCI_Device->pMCI_DeviceFeatures->Max_Write_DataBlock_Length = SD_BYTES_PER_SECTOR;
				
		  		if( AT91F_MCI_SDCard_SetBusWidth(pMCI_Device,pDisk) == AT91C_CMD_SEND_OK )
				{	
					if (AT91F_MCI_SetBlocklength(pMCI_Device,SD_BYTES_PER_SECTOR,pDisk) == AT91C_CMD_SEND_OK)
					return AT91C_INIT_OK;
				}
			}
		}
	}
    return AT91C_INIT_ERROR;
}

//*----------------------------------------------------------------------------
//* \fn    AT91F_MCIDeviceWaitReady
//* \brief Wait for MCI Device ready
//*----------------------------------------------------------------------------
void AT91F_MCIDeviceWaitReady(AT91PS_MciDevice pMCI_Device,unsigned int timeout,
	PDISK pDisk)
{
	WaitForStatus(pMCI_Device,AT91C_MCI_NOTBUSY,timeout,pDisk);
}

//! @}
