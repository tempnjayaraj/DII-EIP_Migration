//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		PLLClock.c 
//!
//! \brief		implements AT91SAM926x GetPLLAClock, GetPLLBClock, GetProcessorClock features
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/IOCTL/PLLClock.c $
//!   $Author: pblanchard $
//!   $Revision: 1058 $
//!   $Date: 2007-07-05 01:34:39 -0700 (Thu, 05 Jul 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------


//! \addtogroup	IOCTL
//! @{

#include <windows.h>
#include <oal.h>

#include "at91sam926x.h"
#include "AT91SAM926x_interface.h"

//-----------------------------------------------------------------------------
//! \fn			BOOL OALIoCtlHalGetPLLAClock(	UINT32 code, VOID *pInpBuffer, UINT32 inpSize, VOID *pOutBuffer, UINT32 outSize, UINT32 *pOutSize)
//!
//! \brief		This function returns the Frequency of the PLLA Clock 
//!
//!	\param		code			not used
//!	\param		pInpBuffer	not used
//!	\param		inpSize		not used
//!	\param		pOutBuffer	Frequency of the PLLA clock in Hz
//!	\param		outSize		Size of pOutBuffer
//!	\param		pOutSize		Size of pOutBuffer used
//!
//! \return		TRUE indictaes success
//! \return		FALSE indictaes failure (bad parameters)
//-----------------------------------------------------------------------------
BOOL OALIoCtlHalGetPLLAClock(	UINT32 code, VOID *pInpBuffer, 
								UINT32 inpSize, VOID *pOutBuffer, 
								UINT32 outSize, UINT32 *pOutSize)
{
	if ( pOutBuffer==NULL || outSize<sizeof(DWORD) )
	{
		return FALSE;
	}

	*(DWORD*)pOutBuffer = AT91SAM926x_GetPLLAClock(FALSE);

	if (pOutSize!=0)
	{
		*pOutSize = sizeof(DWORD);
	}

	return TRUE;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL OALIoCtlHalGetPLLBClock(	UINT32 code, VOID *pInpBuffer, UINT32 inpSize, VOID *pOutBuffer, UINT32 outSize, UINT32 *pOutSize)
//!
//! \brief		This function returns the Frequency of the PLLB Clock
//!
//!	\param		code			not used
//!	\param		pInpBuffer	not used
//!	\param		inpSize		not used
//!	\param		pOutBuffer	Frequency of the PLLB clock in Hz
//!	\param		outSize		Size of pOutBuffer
//!	\param		pOutSize		Size of pOutBuffer used
//!
//! \return		TRUE indictaes success
//! \return		FALSE indictaes failure (bad parameters)
//-----------------------------------------------------------------------------
BOOL OALIoCtlHalGetPLLBClock(	UINT32 code, VOID *pInpBuffer, 
								UINT32 inpSize, VOID *pOutBuffer, 
								UINT32 outSize, UINT32 *pOutSize)
{
	if ( pOutBuffer==NULL || outSize<sizeof(DWORD) )
	{
		return FALSE;
	}

	*(DWORD*)pOutBuffer = AT91SAM926x_GetPLLBClock(FALSE);

	if (pOutSize!=0)
	{
		*pOutSize = sizeof(DWORD);
	}

	return TRUE;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL OALIoCtlHalGetProcessorClock(	UINT32 code, VOID *pInpBuffer, UINT32 inpSize, VOID *pOutBuffer, UINT32 outSize, UINT32 *pOutSize)
//!
//! \brief		This function returns the Frequency of the Processor Clock 
//!
//!	\param		code			not used
//!	\param		pInpBuffer	not used
//!	\param		inpSize		not used
//!	\param		pOutBuffer	Frequency of the Processor clock in Hz
//!	\param		outSize		Size of pOutBuffer
//!	\param		pOutSize		Size of pOutBuffer used
//!
//! \return		TRUE indicates success
//! \return		FALSE indicates failure (bad parameters)
//-----------------------------------------------------------------------------
BOOL OALIoCtlHalGetProcessorClock(	UINT32 code, VOID *pInpBuffer, 
								UINT32 inpSize, VOID *pOutBuffer, 
								UINT32 outSize, UINT32 *pOutSize)
{
	if ( pOutBuffer==NULL || outSize<sizeof(DWORD) )
	{
		return FALSE;
	}

	*(DWORD*)pOutBuffer = AT91SAM926x_GetProcessorClock(FALSE);

	if (pOutSize!=0)
	{
		*pOutSize = sizeof(DWORD);
	}

	return TRUE;
}

//! @} end of subgroup IOCTL

//! @} end of group OAL


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/IOCTL/PLLClock.c $
////////////////////////////////////////////////////////////////////////////////
