//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		Serial_SAM926X_IST.cpp
//!
//! \brief		Serial driver Interrupt Service Thread for AT91SAM926x chipset
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/Serial/Serial_SAM926X_IST.cpp $
//!   $Author: pgal $
//!   $Revision: 982 $
//!   $Date: 2007-06-11 08:00:23 -0700 (Mon, 11 Jun 2007) $
//! \endif
//!
//! 
//-----------------------------------------------------------------------------
//! \addtogroup	Serial
//! @{
//!

//------------------------------------------------------------------------------
//                                                                      Includes
//------------------------------------------------------------------------------
// Standard includes
#include <windows.h>
#include <ceddk.h>
#include <Devload.h>
#include <nkintr.h>
#include <pegdser.h>
#include <serdbg.h>

// Project include
#include "Serial_SAM926X.h"
#include "Serial_SAM926X_DbgZones.h"
#include "Serial_SAM926X_HW.h"


//------------------------------------------------------------------------------
//                                                            Imported functions
//------------------------------------------------------------------------------

extern "C" void DisableInt(void);
extern "C" void EnableInt(void);

extern VOID EvaluateEventFlag(PVOID pHead, ULONG fdwEventMask);

//------------------------------------------------------------------------------
//                                                               Defines & Types
//------------------------------------------------------------------------------

#define IST_TIMEOUT				1000


//			 AT91C_US_RXRDY		// (USART) RXRDY Interrupt						--> Not used
//			 AT91C_US_TXRDY		// (USART) TXRDY Interrupt						--> Not used
//			 AT91C_US_RXBRK		// (USART) Break Received/End of Break
//			 AT91C_US_ENDRX		// (USART) End of Receive Transfer Interrupt		--> Managed
//			 AT91C_US_ENDTX		// (USART) End of Transmit Interrupt
//			 AT91C_US_OVRE		// (USART) Overrun Interrupt
//			 AT91C_US_FRAME		// (USART) Framing Error Interrupt
//			 AT91C_US_PARE		// (USART) Parity Error Interrupt
//			 AT91C_US_TIMEOUT	// (USART) Receiver Time-out
//			 AT91C_US_TXEMPTY	// (USART) TXEMPTY Interrupt
//			 AT91C_US_ITERATION	// (USART) Max number of Repetitions Reached
//			 AT91C_US_TXBUFE	// (USART) TXBUFE Full Interrupt
///			 AT91C_US_RXBUFF	// (USART) RXBUFF Full Interrupt					--> Managed
//			 AT91C_US_NACK		// (USART) Non Acknowledge
//			 AT91C_US_CTSIC		// (USART) Clear To Send Input Change Flag
//			 AT91C_US_DSRIC		// (USART) Data Set Ready Input Change Flag
//			 AT91C_US_RIIC		// (USART) Ring Input Change Flag
//			 AT91C_US_DCDIC		// (USART) Data Carrier Detect Input Change Flag

//------------------------------------------------------------------------------
//                                                            Exported functions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//!	\fn				DWORD SerialIST( LPVOID lpvParam )
//!
//! \brief			Interrupt Service Thread of the serial port
//! 
//! \param lpvParam	Context pointer returned from COM_Init.
//!
//! \return			0
//------------------------------------------------------------------------------
DWORD SerialIST( LPVOID lpvParam )
{
  DWORD  dwStatus;
  DWORD  dwInterruptStatus;

  BOOL  fState = TRUE;
  T_SERIAL_INIT_STRUCTURE *pSerialInitStructure = (T_SERIAL_INIT_STRUCTURE*)lpvParam;

  // Always chec the running flag
  //
  while( pSerialInitStructure->bSerialISTRun )
  {
    dwStatus = WaitForSingleObject(pSerialInitStructure->hSerialEvent, IST_TIMEOUT);

    // Check to see if we are finished
    //
    if(!pSerialInitStructure->bSerialISTRun) return 0;

    // Make sure we have the object
    //
    if( dwStatus == WAIT_OBJECT_0 )
    {
		// Get interrupt status
		dwInterruptStatus = HWGetInterruptStatus(pSerialInitStructure);

		// If a received interrupt occured
		if ( dwInterruptStatus & (AT91C_US_TIMEOUT | AT91C_US_RXBUFF | AT91C_US_ENDRX ) )
		{
			// Create a critical section for Received IST.
			// It's very important that during the IST work, no other interrupt occured
			DisableInt();
			// Disable char received
			HWDisableReceive(pSerialInitStructure);

			// Update avalaible data pointer
			// This value cannot be higher than buffer size
			// Protections are not need, because we are always in a critical section
			pSerialInitStructure->dwPAControllerRxData = pSerialInitStructure->pPDCReg->PDC_RPR;

			// If RCR counter == 0, ENDRX interrupt
			if (dwInterruptStatus & AT91C_US_ENDRX)
			{
				DWORD dwRNPR, dwRNCR, dwAvailableSpace;

				// FLOW CONTROL MECHANISM: if flow control activated
				if (pSerialInitStructure->dcb.fRtsControl == RTS_CONTROL_HANDSHAKE)
				{
					dwAvailableSpace = ComputeFreeSpace(pSerialInitStructure);
					
					// If no enougth available data ... 
					if ((pSerialInitStructure->dwRxBufferSize - dwAvailableSpace) >= pSerialInitStructure->dwRxFCLLimit)
					{
						//... set RTS line
						HWSetRTS(pSerialInitStructure);
					}
					else
					{
						// If there are enought available data,
						// Look up if current Received register value are not too high
						if (((pSerialInitStructure->dwRxBufferSize - dwAvailableSpace) + pSerialInitStructure->pPDCReg->PDC_RCR) >= pSerialInitStructure->dwRxFCLLimit)
						{
							// Change RCR value to the limit
							pSerialInitStructure->pPDCReg->PDC_RCR = pSerialInitStructure->dwRxFCLLimit - (pSerialInitStructure->dwRxBufferSize - dwAvailableSpace);
							//RETAILMSG(1,(L"pSerialInitStructure->pPDCReg->PDC_RCR = %d", pSerialInitStructure->pPDCReg->PDC_RCR));
						}
					}
				}

				// Compute the new dma received next register
				if (ComputeRNR	(pSerialInitStructure
								,pSerialInitStructure->pPDCReg->PDC_RPR
								,pSerialInitStructure->pPDCReg->PDC_RCR
								,&dwRNPR
								,&dwRNCR
								) == TRUE)
				{
					// Apply new value to dma next buffer register
					HWSetRxDmaRegisterNextValue(pSerialInitStructure, dwRNPR, dwRNCR);
				}
				else
				{
					HWDisableRxENDInterrupt(pSerialInitStructure);
				}
			}

			// If AT91C_US_RXBUFF : RCR counter == 0 AND RNCR counter == 0, ENDRX AND RXBUFF interrupt
			if (dwInterruptStatus & AT91C_US_RXBUFF)
			{
				RETAILMSG(1,(L"AT91C_US_RXBUFF 0x%x 0x%x 0x%x 0x%x", pSerialInitStructure->pPDCReg->PDC_RPR,pSerialInitStructure->pPDCReg->PDC_RCR,pSerialInitStructure->pPDCReg->PDC_RNPR,pSerialInitStructure->pPDCReg->PDC_RNCR));
				HWDisableRxInterrupt(pSerialInitStructure);
			}
			
			if (dwInterruptStatus & AT91C_US_TIMEOUT)
			{
				// Set booteen to indicate a timeout
				((T_SERIAL_OPEN_STRUCTURE *)pSerialInitStructure->pReadAccessOwner)->bTimeoutInterval = TRUE;

				// Disable the timeout interrupt
				HWDisableTimeOutInterrupt(pSerialInitStructure);
			}

			// Enable car received
			HWEnableReceive(pSerialInitStructure);

			// Re-Activate interrupt (critical section is ended)
			EnableInt();

			// Signal that a Rx event occurerd (for event flags mechanism)
			EvaluateEventFlag(pSerialInitStructure, EV_RXCHAR);

			// Signal that a Rx event occurerd
			SetEvent(pSerialInitStructure->hRxEvent);
		}

		// If an overrun occured
		if (dwInterruptStatus & AT91C_US_OVRE)
		{
			RETAILMSG(1, (L"Error OverRun ... %c %d %d %d %d",pSerialInitStructure->pUSARTReg->US_RHR,pSerialInitStructure->pPDCReg->PDC_RPR,pSerialInitStructure->pPDCReg->PDC_RCR,pSerialInitStructure->pPDCReg->PDC_RNPR,pSerialInitStructure->pPDCReg->PDC_RNCR));
			pSerialInitStructure->pUSARTReg->US_CR = AT91C_US_RSTSTA;

			// if there is an overrun, liberate ten percent of the buffer
			pSerialInitStructure->dwPAUserRxData += pSerialInitStructure->dwRxBufferSize / 10;

			// If User read data pointer has attempt the buffer true end
			if (pSerialInitStructure->dwPAUserRxData >= pSerialInitStructure->dwPADmaRxBufferTrueEnd)
			{
				// Reset the User start pointer
				pSerialInitStructure->dwPAUserRxData = pSerialInitStructure->dwPADmaRxBufferStart;
				// Reset the true end buffer pointer
				pSerialInitStructure->dwPADmaRxBufferTrueEnd = pSerialInitStructure->dwPADmaRxBufferEnd;
			}

			HWEnableRxInterrupt(pSerialInitStructure);
		}

		if (dwInterruptStatus & AT91C_US_ENDTX)
		{		
			// Signal that a Tx event arrived (for write timeout)
			SetEvent(pSerialInitStructure->hTxEvent);

			HWDisableTxENDInterrupt(pSerialInitStructure);
		}

		if (dwInterruptStatus & AT91C_US_TXEMPTY)
		{
			// Signal that a Tx event arrived (for write timeout)
			SetEvent(pSerialInitStructure->hTxEvent);

			HWDisableTxEMPTYInterrupt(pSerialInitStructure);
		}


		// Generate the EV_BREAK CommEvent
		if (dwInterruptStatus & AT91C_US_RXBRK)
		{
			// Reset status flag
			pSerialInitStructure->pUSARTReg->US_CR = AT91C_US_RSTSTA;
			EvaluateEventFlag(pSerialInitStructure, EV_BREAK);
		}

		// Generate the EV_ERR CommEvent
		if (dwInterruptStatus & (AT91C_US_OVRE | AT91C_US_FRAME | AT91C_US_PARE))
		{
			EvaluateEventFlag(pSerialInitStructure, EV_ERR);
		}

		// Generate the EV_RLSD CommEvent
		if (dwInterruptStatus & (AT91C_US_DCDIC))
		{
			EvaluateEventFlag(pSerialInitStructure, EV_RLSD);
		}
		// Generate the EV_CTS CommEvent
		if (dwInterruptStatus & (AT91C_US_CTSIC))
		{
			EvaluateEventFlag(pSerialInitStructure, EV_CTS);
		}

		// Finish the interrupt
		InterruptDone( pSerialInitStructure->dwSysIntr );
    }
  }

  return 0;
}
//! @}
//! @}
