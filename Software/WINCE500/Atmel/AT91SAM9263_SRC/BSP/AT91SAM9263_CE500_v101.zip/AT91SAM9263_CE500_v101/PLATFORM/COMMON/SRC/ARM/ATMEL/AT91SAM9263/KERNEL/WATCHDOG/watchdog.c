//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file	COMMON/SRC/ARM/ATMEL/AT91SAM9263/KERNEL/WATCHDOG/watchdog.c
//!
//! \brief		AT91SAM9263 processor's watchdog
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/KERNEL/WATCHDOG/watchdog.c $
//!   $Author: edaniel $
//!   $Revision: 754 $
//!   $Date: 2007-04-19 11:57:46 +0200 (jeu., 19 avr. 2007) $
//! \endif
//-----------------------------------------------------------------------------


#include <windows.h>

#include "at91sam926x.h"


//-----------------------------------------------------------------------------
//! \fn			DWORD WatchdogProcSpecificGetWDTCBaseAddress(void)
//!
//! \brief		This function returns the WDTC base adress
//!
//! \return		WDTC base adress
//!
//-----------------------------------------------------------------------------
DWORD WatchdogProcSpecificGetWDTCBaseAddress(void)
{
	return (DWORD) AT91C_BASE_WDTC;
}

//-----------------------------------------------------------------------------
//! \fn			DWORD WatchdogProcSpecificGetClockFrequency(void)
//!
//! \brief		This function returns the clock frequency
//!
//! \return		clock frequency
//!
//-----------------------------------------------------------------------------
DWORD WatchdogProcSpecificGetClockFrequency(void)
{
	return (DWORD) SLOW_CLOCK_FREQUENCY;
}

//------------------------------------------------------------------------------

//! @}


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/KERNEL/WATCHDOG/watchdog.c $
////////////////////////////////////////////////////////////////////////////////
//
