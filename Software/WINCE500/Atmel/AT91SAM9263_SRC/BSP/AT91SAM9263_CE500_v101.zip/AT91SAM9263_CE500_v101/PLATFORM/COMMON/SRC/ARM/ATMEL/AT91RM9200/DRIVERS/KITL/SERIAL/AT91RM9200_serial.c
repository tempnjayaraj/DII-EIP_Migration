//-----------------------------------------------------------------------------
//! \addtogroup   KITL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				kitlserial.c
//!
//! \brief				Support routines for KITL with serial transport.
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91RM9200EK/Src/KERNEL/kitlserial.c $
//!   $Author: glemercier $
//!   $Revision: 669 $
//!   $Date: 2007-04-12 11:36:31 +0200 (jeu., 12 avr. 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

//! \addtogroup	KITL
//! @{

#include <windows.h>
#include <nkintr.h>
#include <oal.h>
#include "AT91RM9200.h"
#include "AT91RM9200_interface.h"
#include "lib_AT91RM9200.h"
#include <windows.h>
#include <oal.h>
#include <nkintr.h>

#define DBGU_TXFIFO_DEPTH	1
#define DBGU_BAUDRATE	(115200)

static AT91PS_DBGU g_pDBGU;

//-----------------------------------------------------------------------------
//!
//! \brief Initializes the interal UART with the specified communication settings.
//!
//! \param [in/out] pointer to KITL_SERIAL_INFO structure that contains information about how to initialize the serial KITL transport.
//!
//! \return TRUE if the function succeeds.
//!
//-----------------------------------------------------------------------------
BOOL SerialInit(KITL_SERIAL_INFO *pSerInfo)
{
	DWORD	dwMasterClock;
	AT91PS_PIO pPIOA = OALPAtoVA((DWORD) AT91C_BASE_PIOA,FALSE);
    BOOL bRet = TRUE;

	// Get pointer to peripheral base
    g_pDBGU = (AT91PS_DBGU) OALPAtoVA((UINT32)AT91C_BASE_DBGU,FALSE);

    if (g_pDBGU == NULL) return FALSE;

    // Tell KITL upper layers that optimal tranfer size is TXFIFO size
    pSerInfo->bestSize = DBGU_TXFIFO_DEPTH;

    if (g_pDBGU == NULL)
    {
        g_pDBGU = OALPAtoVA((DWORD) AT91C_BASE_DBGU,FALSE);
		bRet = FALSE;
    }
 
	dwMasterClock = AT91RM9200_GetMasterClock(FALSE);

   	// Open PIO for DBGU
	pPIOA->PIO_PDR = (AT91C_PA31_DTXD | AT91C_PA30_DRXD);
	pPIOA->PIO_ASR = (AT91C_PA31_DTXD | AT91C_PA30_DRXD);
	

	// Configure DBGU
	AT91F_US_Configure (
		(AT91PS_USART) g_pDBGU,          // DBGU base address
		dwMasterClock,             // 33.3 MHz
		AT91C_US_ASYNC_MODE,  // mode Register to be programmed
		DBGU_BAUDRATE ,              // baudrate to be programmed
		0);                   // timeguard to be programmed

	// Enable Transmitter
	g_pDBGU->DBGU_CR = AT91C_US_TXEN;
    // Enable receiver
    g_pDBGU->DBGU_CR = AT91C_US_RXEN;  

    return bRet;
}

//-----------------------------------------------------------------------------
//!
//! \brief Deinitializes the internal UART previously configured with SerialInit.
//!
//! \return TRUE if the function succeeds.
//!
//-----------------------------------------------------------------------------
VOID SerialDeinit(void)
{
}

//-----------------------------------------------------------------------------
//!
//! \brief This function is used by KITL protocol to receive a packet/frame from the desktop KITL transport.
//!
//! \param [out] pData pointer to an array which will be filled with received data
//! \param [out] size  length of the received data array.
//!
//! \return TRUE if the function received data successfully.
//!
//-----------------------------------------------------------------------------
UINT16 SerialRecv(UINT8 *pData, UINT16 size)
{    
    UINT8 urxd;
    USHORT cbRead = 0;
	// read until buffer size is reached or an error occurs
    for(cbRead = 0; cbRead < size; cbRead++)
    {         
		if(g_pDBGU == NULL)
        {
			KITLOutputDebugString("KitlSerialRecvRaw:  receive error\n");
            cbRead= 0;
            break;
        }
        if (!(g_pDBGU->DBGU_CSR & AT91C_US_RXRDY)) //Did we receive at least one byte ?
		{
			cbRead = 0;
			break;
		}
        // read char from FIFO
        urxd = g_pDBGU->DBGU_RHR & 0xff;

        // If error detected in current character
        if (g_pDBGU->DBGU_CSR & AT91C_US_PARE)
        {
			KITLOutputDebugString("KitlSerialRecvRaw:  receive error\n");
            cbRead= 0;
            break;
        }
        
        // Place read char into buffer
        *(pData + cbRead) = urxd;
    }
    // If we ready any characters successfully, return TRUE
    if (cbRead > 0) return cbRead;

    return FALSE;
}

//-----------------------------------------------------------------------------
//!
//! \brief This function is used by KITL protocol to send a packet/frame to the desktop KITL transport.
//!
//! \param [in] pData pointer to a buffer holding data to be transmitted.
//! \param [in] size  set to the size of the buffer.
//!
//! \return TRUE if the function succeeds.
//!
//-----------------------------------------------------------------------------
UINT16 SerialSend(UINT8 *pData, UINT16 size)
{
	UINT16 cbWrite = 0;

	// Block until send is complete; no timeout
    for(cbWrite=0;cbWrite<size;cbWrite++)
    {
        // Wait until there is room in the FIFO
        while(!(g_pDBGU->DBGU_CSR & AT91C_US_TXRDY));
        // Write character to port
        g_pDBGU->DBGU_THR = *(pData + cbWrite);
    }
    return	cbWrite;
}


VOID SerialSendComplete(UINT16 size)
{
}


//-----------------------------------------------------------------------------
//!
//! \brief This function enables serial interrupts used for the KITL transport.
//!
//-----------------------------------------------------------------------------
VOID SerialEnableInts(void)
{
}


//-----------------------------------------------------------------------------
//!
//! \brief This function disables serial interrupts used for the KITL transport.
//!
//-----------------------------------------------------------------------------
VOID SerialDisableInts(void)
{
}


//! @}
