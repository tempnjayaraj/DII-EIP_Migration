//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//
//  All rights reserved ADENEO SAS 2005
//-----------------------------------------------------------------------------
//! \file		flash_at91sam9263.c 
//!
//! \brief		Specific eboot part for flash
//!
//! \if subversion
///  $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/BOOTLOADER/EBOOT/flash_at91sam9263.c $
//!   $Author: ltourlonias $
//!   $Revision: 759 $
//!   $Date: 2007-04-20 17:46:38 +0200 (ven., 20 avr. 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	EBOOT
//! @{
//


//------------------------------------------------------------------------------
//                                                                      Includes
//------------------------------------------------------------------------------
// Standard includes
#include <windows.h>
#include <nkintr.h>
#include <oal.h>
#include <fmd.h>

// Atmel includes
#include "at91sam9263.h"
#include "AT91SAM9263EK.h"
#include "AT91SAM926x_interface.h"

#include "bootloader_cfg.h"
#include "bootloader_struct.h"

// Project include
#include "SPIDataFlash.h"

//------------------------------------------------------------------------------
//                                                                     Variables
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//                                                            Imported functions
//------------------------------------------------------------------------------

extern PVOID FMD_Init(LPCTSTR lpActiveReg, PPCI_REG_INFO pRegIn, PPCI_REG_INFO pRegOut);
extern BOOL	FMD_EraseChip	(void);
extern BOOL	FMD_DirectWrite	(DWORD	dwOffset,	UCHAR* srcBuffer, DWORD dwLen);
extern BOOL	FMD_DirectRead	(DWORD	dwOffset,	UCHAR* destBuffer, DWORD dwLen);
extern BOOL	FMD_DirectErase	(DWORD	dwOffset,DWORD dwLen);


//------------------------------------------------------------------------------
//                                                            Exported functions
//------------------------------------------------------------------------------

DWORD EBOOT_GetFlashImageLogicalAddress(void)
{
	return WINDOWS_CE_IMAGE_FLASH_LOGIC_ADDR;
}


//----------------------------------------------------------------------------
// \fn    EBOOT_InitFlash(DWORD dwAddress)
// \brief This function initialize the flash.
// \param dwAddress an address within the flash you want to initialize.
//                  This address contain in first byte the logical address of flash
//                  who describing the flash type.
// \return The opeation status
//----------------------------------------------------------------------------
BOOL EBOOT_InitFlash(DWORD dwAddress)
{
	static BOOL bDataFlashInit = FALSE;
	static BOOL bNandFlashInit = FALSE;

	BOOL bResult = FALSE;
	
	switch (dwAddress & LOGIC_ADDR_MASK)
	{
	case DATAFLASH_CS0_LOGIC_BASE_ADDR:
		if (bDataFlashInit == FALSE)
		{
			AT91F_DataflashInit(0);
			bDataFlashInit = TRUE;
		}
		bResult = TRUE;
		break;
	case DATAFLASH_CS1_LOGIC_BASE_ADDR:
		if (bDataFlashInit == FALSE)
		{
			AT91F_DataflashInit(1);
			bDataFlashInit = TRUE;
		}
		bResult = TRUE;
		break;
	case NANDFLASH_CS3_LOGIC_BASE_ADDR:
		if (bNandFlashInit == FALSE)
		{
			if ( FMD_Init(NULL,(PPCI_REG_INFO)AT91SAM9263EK_BASE_NAND,NULL) != NULL)
			{
				bNandFlashInit = TRUE;
				bResult = TRUE;
			}
		}
		else
		{
			bResult = TRUE;
		}
		break;
	default:
		bResult = FALSE;

	}

	return bResult;
}

//----------------------------------------------------------------------------
// \fn    EBOOT_ReadFlash(DWORD dwAddressDst, DWORD dwAddressSrc, DWORD dwLen)
// \brief This function permit to read data from a flash
// \param dwAddressDst Destination address of reading
// \param dwAddressSrc Source of reading
// \param dwLen Length in byte to read
// \return The opeation status
//----------------------------------------------------------------------------
BOOL EBOOT_ReadFlash(DWORD dwAddressDst, DWORD dwAddressSrc, DWORD dwLen)
{
	BOOL bResult = FALSE;

	switch (dwAddressSrc & LOGIC_ADDR_MASK)
	{
	case DATAFLASH_CS0_LOGIC_BASE_ADDR:
		if (read_dataflash(dwAddressSrc,sizeof(EBOOT_CFG),(UCHAR*) dwAddressDst) != AT91C_DATAFLASH_OK)
		{
			RETAILMSG(1,(L"ERROR: LoadEBootCFG: failed to read in SPI CS0 dataflash configuration.\r\n"));
			bResult = FALSE;
		}
		else
		{
			bResult = TRUE;
		}
		break;
	case DATAFLASH_CS1_LOGIC_BASE_ADDR:
		if (read_dataflash(dwAddressSrc,sizeof(EBOOT_CFG),(UCHAR*) dwAddressDst) != AT91C_DATAFLASH_OK)
		{
			RETAILMSG(1,(L"ERROR: LoadEBootCFG: failed to read in SPI CS1 dataflash configuration.\r\n"));
			bResult = FALSE;
		}
		else
		{
			bResult = TRUE;
		}
		break;
	case NANDFLASH_CS3_LOGIC_BASE_ADDR:
		FMD_DirectRead(dwAddressSrc&(~LOGIC_ADDR_MASK), (UCHAR*)dwAddressDst, dwLen);
		bResult = TRUE;
		break;
	default:
		bResult = FALSE;
	}

	return bResult;
}

//----------------------------------------------------------------------------
// \fn    EBOOT_WriteFlash(DWORD dwAddressDst, DWORD dwAddressSrc, DWORD dwLen)
// \brief This function write data to flash
// \param dwAddressDst Destination address of writing
// \param dwAddressSrc Source of writing data
// \param dwLen Length in byte to write
// \return The opeation status
//----------------------------------------------------------------------------
BOOL EBOOT_WriteFlash(DWORD dwAddressDst, DWORD dwAddressSrc, DWORD dwLen)
{
	BOOL bResult = FALSE;

	switch (dwAddressDst & LOGIC_ADDR_MASK)
	{
	case DATAFLASH_CS0_LOGIC_BASE_ADDR:
		if (write_dataflash(dwAddressDst, (UCHAR*)dwAddressSrc,sizeof(EBOOT_CFG)) != AT91C_DATAFLASH_OK)
		{
			RETAILMSG(1,(L"ERROR: EBOOT_WriteFlash - failed to read in SPI CS0 dataflash configuration.\r\n"));
			bResult = FALSE;
		}
		else
		{
			bResult = TRUE;
		}
		break;
	case DATAFLASH_CS1_LOGIC_BASE_ADDR:
		if (write_dataflash(dwAddressDst, (UCHAR*)dwAddressSrc,sizeof(EBOOT_CFG)) != AT91C_DATAFLASH_OK)
		{
			RETAILMSG(1,(L"ERROR: EBOOT_WriteFlash - failed to read in SPI CS1 dataflash configuration.\r\n"));
			bResult = FALSE;
		}
		else
		{
			bResult = TRUE;
		}
		break;
	case NANDFLASH_CS3_LOGIC_BASE_ADDR:
		FMD_DirectWrite(dwAddressDst&(~LOGIC_ADDR_MASK), (UCHAR*)dwAddressSrc, dwLen);
		bResult = TRUE;
		break;
	default:
		bResult = FALSE;
	}

	return bResult;
}

//----------------------------------------------------------------------------
// \fn    EBOOT_EraseFlash(DWORD dwAddress, DWORD dwLen)
// \brief Erase flash
// \param dwAddress Erase start address
// \param dwLen Length in byte to erase
// \return The opeation status
//----------------------------------------------------------------------------
BOOL EBOOT_EraseFlash(DWORD dwAddress, DWORD dwLen)
{
	BOOL bResult = FALSE;

	switch (dwAddress & LOGIC_ADDR_MASK)
	{
	case DATAFLASH_CS0_LOGIC_BASE_ADDR:
		/*if (erase() != AT91C_DATAFLASH_OK)
		{
			RETAILMSG(1,(L"ERROR: EBOOT_WriteFlash - failed to read in SPI CS0 dataflash configuration.\r\n"));
			bResult = FALSE;
		}
		else
		{
			bResult = TRUE;
		}
		*/
		break;
	case DATAFLASH_CS1_LOGIC_BASE_ADDR:
		/*if (erase() != AT91C_DATAFLASH_OK)
		{
			RETAILMSG(1,(L"ERROR: EBOOT_WriteFlash - failed to read in SPI CS1 dataflash configuration.\r\n"));
			bResult = FALSE;
		}
		else
		{
			bResult = TRUE;
		}
		*/
		break;
	case NANDFLASH_CS3_LOGIC_BASE_ADDR:
		FMD_DirectErase(dwAddress&(~LOGIC_ADDR_MASK), dwLen);
		bResult = TRUE;
		break;
	default:
		bResult = FALSE;
	}

	return bResult;
}

//----------------------------------------------------------------------------
// \fn    BOOL EBOOT_EraseAllFlash(DWORD dwAddress)
// \brief Erase all the flash specified by logical address parameters
// \param dwAddress Identify the flash by the logical address
// \return The opeation status
//----------------------------------------------------------------------------
BOOL EBOOT_EraseAllFlash(DWORD dwAddress)
{
	BOOL bResult = FALSE;

	switch (dwAddress & LOGIC_ADDR_MASK)
	{
	case DATAFLASH_CS0_LOGIC_BASE_ADDR:
		RETAILMSG(1,(L"Erase All not supported for DataDlash CS0"));
		bResult = FALSE;
		break;
	case DATAFLASH_CS1_LOGIC_BASE_ADDR:
		RETAILMSG(1,(L"Erase All not supported for DataDlash CS1"));
		bResult = FALSE;
		break;
	case NANDFLASH_CS3_LOGIC_BASE_ADDR:
		FMD_EraseChip();
		bResult = TRUE;
		break;
	default:
		bResult = FALSE;
	}

	return bResult;
}



//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/BOOTLOADER/EBOOT/flash_at91sam9263.c $
//------------------------------------------------------------------------------

//
//! @}
//

//! @}
