//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/GenericEBOOT/main.c 
//!
//! \brief		The eboot main
//!
//! \if subversion
///   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/GenericEBOOT/main.c $
//!   $Author: ltourlonias $
//!   $Revision: 985 $
//!   $Date: 2007-06-12 09:30:21 +0200 (mar., 12 juin 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	EBOOT
//! @{
//!

//------------------------------------------------------------------------------
//                                                                      Includes
//------------------------------------------------------------------------------
// Standard includes
#include <windows.h>
#include <blcommon.h>
#include <nkintr.h>
#include <winsock2.h>
#include <halether.h>
#include <oal_kitl.h>
#include <oal_args.h>
#include <oal_memory.h>
#include <oal.h>


// Eboot includes
#include "bootloader_struct.h"
#include "eboot_msg.h"
#include "eboot_cfg.h"
#include "key_code.h"


//------------------------------------------------------------------------------
//                                                                     Variables
//------------------------------------------------------------------------------

static OAL_KITL_ARGS *				g_pKITLArgs;
static DWORD						g_dwLaunchAction;


T_BOOTLOADER_FLASH_CONFIG			g_bootFlashConfig;
EBOOT_CFG							g_EbootCFG;
BOOL								g_bDownloadImage;

EDBG_ADDR							edbgAddr;
// Required for compilation
// Used in WINCE500\public\common\oak\drivers\ethdbg\eboot\eboot.h(33):extern DWORD EdbgDebugZone;
DWORD								EdbgDebugZone;

static DWORD			dhcpLeaseTime = 0;
static UINT32			tmpSubnetMask;
static BOOL				fGotJumpImg = FALSE;

//------------------------------------------------------------------------------
//                                                               Defines & Types
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
//                                                 Internal functions protorypes
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//                                                            Imported variables
//------------------------------------------------------------------------------

// The platform string used when sending BOOTME frame (must be define in specfic part)
extern CHAR *	g_pPlatformString;
extern UCHAR	g_BspVersionMajor;
extern UCHAR	g_BspVersionMinor;

//------------------------------------------------------------------------------
//                                                            Imported functions
//------------------------------------------------------------------------------
extern void				EBOOT_SpinForever(void);	//< Spin forever
extern void				EBOOT_LowLevelInit(void);	//< Init low level
extern void				EBOOT_WatchdogRefresh(void);
extern OAL_KITL_ARGS *	EBOOT_InitArgs(void);
extern T_BOOTLOADER_FLASH_CONFIG * EBOOT_GetFlashConfig(void);
extern void				EBOOT_SerialDebugInitInterface(void);

extern void				EBOOT_SetArgs(UINT8 deviceId[16], DWORD dwCoreFrequency, DWORD dwBusDivider);

extern BOOL				EBOOT_EtherInit(EBOOT_CFG * pEbootCFG, OAL_KITL_ARGS *pKITLArgs);

extern void				Launch(DWORD uAddr);
extern void*			OALPAtoVA(UINT32 pa, BOOL cached);			//< Mapping function
extern UINT32			OALVAtoPA(VOID *pVA);						//< Mapping function
extern unsigned long	ComputeCRC32(unsigned char *buffer, int len);

extern BOOL				EBOOT_InitTimer(void);

extern BYTE				EBOOT_DisplayPreMenu(EBOOT_CFG * pEbootCFG);
extern BYTE				EBOOT_DisplayMenu(EBOOT_CFG * pEbootCFG);

extern DWORD			EBOOT_GetFlashImageLogicalAddress(void);
extern BOOL				EBOOT_InitFlash(DWORD dwAddress);
extern BOOL				EBOOT_ReadFlash(DWORD dwAddressDst, DWORD dwAddressSrc, DWORD dwLen);
extern BOOL				EBOOT_WriteFlash(DWORD dwAddressDst, DWORD dwAddressSrc, DWORD dwLen);
extern BOOL				EBOOT_EraseFlash(DWORD dwAddress, DWORD dwLen);


extern void ethChipSelectConfiguration(void);
//------------------------------------------------------------------------------
//! \brief Init debug mecanism  
//! 
//! \return		Status (always TRUE)
//------------------------------------------------------------------------------
BOOL  OEMDebugInit(void)
{
	// Initialize the debug UART
	EBOOT_SerialDebugInitInterface();

	OEMInitDebugSerial();

	RETAILMSG(1,(EMSG_SERIAL_INIT));

	return(TRUE);
}

//------------------------------------------------------------------------------
//! \brief  Function call for initialized the platform   
//! 
//! \return		Status
//------------------------------------------------------------------------------
BOOL  OEMPlatformInit(void)
{
	T_BOOTLOADER_FLASH_CONFIG *pBootFlashConfigTmp;
	BOOL bDisplayMenu;
	BOOL bRetVal = TRUE;

	RETAILMSG(1,(EMSG_BOOTLOADER_START));
	RETAILMSG(1,(EMSG_CRLF));

	// Get bootloader flash config
	pBootFlashConfigTmp = EBOOT_GetFlashConfig();
	// Remap it to be in our memory map
	pBootFlashConfigTmp = (T_BOOTLOADER_FLASH_CONFIG *)OALPAtoVA((UINT32)pBootFlashConfigTmp, FALSE);
	
	// Copy settings get by firstboot and test it
	g_bootFlashConfig.dwSize = pBootFlashConfigTmp->dwSize;
	g_bootFlashConfig.dwEbootCodeFlashAddr = pBootFlashConfigTmp->dwEbootCodeFlashAddr;
	g_bootFlashConfig.dwEbootSettingsFlashAddr = pBootFlashConfigTmp->dwEbootSettingsFlashAddr;
	g_bootFlashConfig.dwCrc32 = pBootFlashConfigTmp->dwCrc32;
	if (
		(g_bootFlashConfig.dwSize != sizeof(T_BOOTLOADER_FLASH_CONFIG)) ||
		(g_bootFlashConfig.dwCrc32 != ComputeCRC32( (UCHAR*)&g_bootFlashConfig, sizeof(T_BOOTLOADER_FLASH_CONFIG)-sizeof(DWORD)))
		)
	{
		//RETAILMSG(1,(EMSG_BAD_FIRSTBOOT_CONFIG));
		//RETAILMSG(1,(EMSG_CRLF));
		EBOOT_SpinForever();
	}

	// Initialize timer
	EBOOT_InitTimer();

	// Init flash used for eboot settings
	EBOOT_InitFlash(g_bootFlashConfig.dwEbootSettingsFlashAddr);

	// Initializing used vars
	g_pKITLArgs = EBOOT_InitArgs();
	//   EBOOT CONFIG
	memset((LPVOID)&g_EbootCFG, 0x00, sizeof(EBOOT_CFG));
	

	// FLASH PART ....
	// Read eboot config from flash type
	if (EBOOT_LoadConfigFromFlash(&g_EbootCFG) == FALSE)
	{
		RETAILMSG(1,(EMSG_LOAD_DEFAULT_EBOOTCONFIG));
		RETAILMSG(1,(EMSG_CRLF));
		EBOOT_SetDefaultEBootCFG(&g_EbootCFG);	//< Reset to the default eboot configuration
	}

	// Display pre menu
	switch (EBOOT_DisplayPreMenu(&g_EbootCFG))
	{
	case KEY_ENTER:
		bDisplayMenu = FALSE;
		break;
	case KEY_SPACE:
		bDisplayMenu = TRUE;
		break;
	default:
		//RETAILMSG(1, (EMSG_SELECTION_ERROR));
		bDisplayMenu = FALSE;
		bRetVal = FALSE;
	}

	g_dwLaunchAction = NO_KEY;

	// Display menu
	if (bDisplayMenu == TRUE)
	{
		switch (EBOOT_DisplayMenu(&g_EbootCFG))
		{
		case KEY_L:
			g_dwLaunchAction = KEY_L;
			break;
		case KEY_D:
			g_dwLaunchAction = KEY_D;
			break;
		default:
			//RETAILMSG(1, (EMSG_SELECTION_ERROR));
			bRetVal = FALSE;
		}
	}

	return(bRetVal);
}

//--------------------------------------------------------------------------------
//! \fn DWORD OEMPreDownload(void)
//! 
//! This function is called by the BLCOMMON framework prior to download and can be customized to prompt for user feedback, such as obtaining a static IP address or skipping the download and jumping to a flash-resident run-time image.
//! 
//! \return \e BL_DOWNLOAD = 0 Download the OS image from the host machine. 
//! \return \e BL_JUMP = 1 Skip the download and jump to a resident OS image. 
//! \return \e BL_ERROR = -1 Image download is unsuccessful. 
//!
//--------------------------------------------------------------------------------
DWORD OEMPreDownload(void)
{
	DWORD		dwAction;
	DWORD *		pDhcpLeaseTime;
	UINT8		deviceId[16];

	DEBUGMSG(1, (L"+OEMPreDownload\r\n"));

	// Default value, image isn't download
	g_bDownloadImage = FALSE;

	switch (g_dwLaunchAction)
	{
	case NO_KEY:
		if (g_EbootCFG.autoDownloadImage == TRUE)
		{
			dwAction = BL_DOWNLOAD;
			g_bDownloadImage = TRUE;
		}
		else
		{
			dwAction = BL_JUMP;
		}
		break;
	case KEY_L:
		dwAction = BL_JUMP;
		break;
	case KEY_D:
		dwAction = BL_DOWNLOAD;
		g_bDownloadImage = TRUE;
		break;
	default:
		dwAction = BL_ERROR;
	}

	// If need to download image from ethernet
	if (dwAction == BL_DOWNLOAD)
	{
		//  If send image to flash, initializing dest flash
		if (g_EbootCFG.bImgToFlash == TRUE)
		{
			RETAILMSG(1,(EMSG_INIT_IMGFLASH));
			if(EBOOT_InitFlash(g_EbootCFG.imgBootDesc.dwFlashLogicalAddress) == TRUE)
			{
				RETAILMSG(1,(EMSG_OK));
			}
			else
			{
				RETAILMSG(1,(EMSG_FAILED));
				dwAction = BL_ERROR;
			}
			RETAILMSG(1,(EMSG_CRLF));
		}

		// Initialize debug ethernet interface
		if (EBOOT_EtherInit(&g_EbootCFG, g_pKITLArgs) == FALSE)
		{
			RETAILMSG(1, (EMSG_ERROR_INIT_CRITICAL));
			RETAILMSG(1,(EMSG_CRLF));
			EBOOT_SpinForever();
		}

		// From here we are sure that ethernet interface has been correcly initialized

		// Copy mac address in edbgAddr used by EbootInitEtherTransport()
		memcpy(edbgAddr.wMAC, g_EbootCFG.macAddress, (sizeof(UINT16) * 3));
		edbgAddr.dwIP  = g_EbootCFG.ipAddress;
		edbgAddr.wPort = 0;
		tmpSubnetMask  = g_EbootCFG.subnetMask;

		// If dhcp enable
		if (g_EbootCFG.dhcpEnable == TRUE)
		{
			pDhcpLeaseTime = &dhcpLeaseTime;
			//   DHCP flags
			g_pKITLArgs->flags     |= OAL_KITL_FLAGS_DHCP;
		}
		else // if use static ip
		{
			pDhcpLeaseTime = NULL;
			//   DHCP flags
			g_pKITLArgs->flags     &= ~OAL_KITL_FLAGS_DHCP;
		}

		// Create name for BOOTME frame
		OALKitlCreateName(g_pPlatformString, (UINT16*)g_EbootCFG.macAddress, deviceId);

		// Store deviceid and frequencies settings in the BSP args for the kernel
		EBOOT_SetArgs(deviceId, g_EbootCFG.dwCoreFrequency, g_EbootCFG.dwBusFreqDivider);

		// Initializing ethernet transport layer & get dhcp address.
		if (!EbootInitEtherTransport(&edbgAddr,
									 &tmpSubnetMask,
									 &fGotJumpImg,
									 pDhcpLeaseTime,
									 g_BspVersionMajor,
									 g_BspVersionMinor,
									 g_pPlatformString,
									 deviceId,
									 EDBG_CPU_ARM720,//Should ARM926 but it's not defined 
									 0))
		{
			RETAILMSG(1, (EMSG_ERROR_INIT_CRITICAL));
			RETAILMSG(1,(EMSG_CRLF));
			dwAction = BL_ERROR;
		}
	}
	else if (dwAction == BL_JUMP)
	{
		UINT8 stub[16] = "";
		// Store frequency settings in the BSP args for the kernel
		EBOOT_SetArgs(stub, g_EbootCFG.dwCoreFrequency, g_EbootCFG.dwBusFreqDivider);
	}
	else
	{
		dwAction = BL_ERROR;
	}

	// Set correct parameter in KITL args
	//   Set default mac address in kitl args
	memcpy(g_pKITLArgs->mac,g_EbootCFG.macAddress,(sizeof(UINT16) * 3));
	
	if (g_EbootCFG.dhcpEnable == FALSE)
	{
		//   ip apress
		g_pKITLArgs->ipAddress  = edbgAddr.dwIP;
		//   subnetmask
		g_pKITLArgs->ipMask     = tmpSubnetMask;
	}
	else
	{
		// Set to 0 because of when bsp args read in OAL, need to be 0 if DHCP enable
		g_pKITLArgs->ipAddress = 0;
		g_pKITLArgs->ipMask = 0;
	}

	// Direct jump to imageg or download from ethernet or an error occured
	//BL_JUMP or BL_DOWNLOAD or BL_ERROR;
	return (dwAction);
}

//------------------------------------------------------------------------------
//! \brief Launch windows CE 
//! 
//! \param dwImageStart       Image start address
//!
//! \param dwImageLength      Image length
//!
//! \param dwLaunchAddr       Address where jump to start windows CE
//!
//! \param pRomHdr			  ...
//!
//------------------------------------------------------------------------------
void  OEMLaunch (DWORD dwImageStart, DWORD dwImageLength, DWORD dwLaunchAddr, const ROMHDR *pRomHdr)
{
	EDBG_OS_CONFIG_DATA *pCfgData;
	DWORD				 launchPhysicalAddress;

	/*
	DWORD * toto;
	DWORD m;
	*/

	DEBUGMSG(1, (L"+OEMLaunch (dwImageStart=%x,dwImageLength=%x,dwLaunchAddr=%x\r\n",dwImageStart,dwImageLength,dwLaunchAddr));


	// If no launch address specified, get the last value in eboot config
	if (!dwLaunchAddr)
	{	
		// Be sure that launch information coresponding to flash image
		dwLaunchAddr = g_EbootCFG.imgBootDesc.dwLaunchAddr;
		dwImageLength = g_EbootCFG.imgBootDesc.dwPhysLen;
		dwImageStart = g_EbootCFG.imgBootDesc.dwPhysStart;
	}
	else // If a launch address is specified
	{
		if(g_EbootCFG.bImgToFlash) // If the image is loaded in nandflash save the parameters
		{
			if ((g_EbootCFG.imgBootDesc.dwLaunchAddr != dwLaunchAddr) ||
				(g_EbootCFG.imgBootDesc.dwPhysStart  != dwImageStart) ||
				(g_EbootCFG.imgBootDesc.dwPhysLen    != dwImageLength))
			{
				g_EbootCFG.imgBootDesc.dwLaunchAddr			 = dwLaunchAddr;
				g_EbootCFG.imgBootDesc.dwPhysStart			 = dwImageStart;
				g_EbootCFG.imgBootDesc.dwPhysLen			 = dwImageLength;
				g_EbootCFG.imgBootDesc.dwFlashLogicalAddress = EBOOT_GetFlashImageLogicalAddress();

				RETAILMSG(1,(EMSG_SAVE_IMGBOOTDESC));
				EBOOT_SaveConfigToFlash(&g_EbootCFG);
			}
		}
	}

    if (g_bDownloadImage)
    {
        if (!(pCfgData = EbootWaitForHostConnect(&edbgAddr, NULL)))
        {
            RETAILMSG(1, (EMSG_ERROR_WAITFORHOST));
            EBOOT_SpinForever();
        }

        // If the user selected "passive" KITL (i.e., don't connect to the target at boot time), set the
        // flag in the args structure so the OS image can honor it when it boots.
        //
        if (pCfgData && (pCfgData->KitlTransport & KTS_PASSIVE_MODE))
        {
            g_pKITLArgs->flags |= OAL_KITL_FLAGS_PASSIVE;
        }
    }
	else
	{
		// If image not download
		// Init nand flash
			RETAILMSG(1,(EMSG_INIT_IMGFLASH));
			if(EBOOT_InitFlash(g_EbootCFG.imgBootDesc.dwFlashLogicalAddress) == TRUE)
			{
				RETAILMSG(1,(EMSG_OK));
			}
			else
			{
				RETAILMSG(1,(EMSG_FAILED));
				EBOOT_SpinForever();
			}
			RETAILMSG(1,(EMSG_CRLF));

		// Read image from flash
		EBOOT_ReadFlash(g_EbootCFG.imgBootDesc.dwPhysStart, g_EbootCFG.imgBootDesc.dwFlashLogicalAddress, g_EbootCFG.imgBootDesc.dwPhysLen);
	}

	launchPhysicalAddress = (UINT32) OALVAtoPA((VOID *)dwLaunchAddr);
    
	/*
	RETAILMSG(1,(L"OALVAtoPA passed\r\n"));

	 toto = (DWORD *)(dwImageStart);
	// BEGIN Memory dump
	for (m=0;m<1000;m++)
	{
		RETAILMSG (1, (L"%8x  ",*toto));
		toto ++;
	}
	RETAILMSG (1, (L"\r\n\r\n\r\n\r\n\r\n\r\n",*toto));
	toto = (DWORD *)(dwLaunchAddr);
	// Momory dump
	for (m=0;m<1000;m++)
	{
		RETAILMSG (1, (L"%8x  ",*toto));
		toto ++;
	}
	// END Memory dump
	*/

	// Jump to the image we just downloaded.
	RETAILMSG(1, (EMSG_LAUNCHING_IMAGE_AT, launchPhysicalAddress));
	Launch(launchPhysicalAddress);

    // Should never get here ...
	RETAILMSG(1, (EMSG_ERROR_NEVER_HERE));
    EBOOT_SpinForever();
}

//------------------------------------------------------------------------------
//! \brief Set visual progress   
//! 
//! \param dwPacketNum      value of progress
//------------------------------------------------------------------------------
void  OEMShowProgress(DWORD dwPacketNum)
{
	RETAILMSG(1, (L"X"));
}

//------------------------------------------------------------------------------
//! \brief The main function (call by startup.s)    
//! \return		Never returned !
//------------------------------------------------------------------------------
void main(void)
{

	EBOOT_LowLevelInit();
	EBOOT_WatchdogRefresh();

    // Common boot loader (blcommon) main routine.
    BootloaderMain();

    // Should never get here.
    EBOOT_SpinForever();
}


//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/GenericEBOOT/main.c $
//------------------------------------------------------------------------------

//
//! @}
//

//
//! @}
