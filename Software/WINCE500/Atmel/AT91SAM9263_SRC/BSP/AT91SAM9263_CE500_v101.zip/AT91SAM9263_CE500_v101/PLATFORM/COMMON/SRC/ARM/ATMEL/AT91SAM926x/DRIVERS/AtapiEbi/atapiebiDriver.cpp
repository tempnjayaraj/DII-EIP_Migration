//-----------------------------------------------------------------------------
//!
//! \addtogroup DRIVERS
//! @{
//!
//! All rights reserved ADENEO SAS 2005
//-----------------------------------------------------------------------------
//!
//! \file		atapiebiDriver.cpp
//!
//! \brief		IDE ATAPI hard disk driver on EBI bus\n
//!             based on atapipcmcia.cpp file\n
//!             The ATAPIEBI driver is a DLL loaded by IDE driver, named DSK.\n
//!             It is a block driver, interrupt driven, without IST.\n
//!             It can be unloaded / reloaded
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/AtapiEbi/atapiebiDriver.cpp $
//!   $Author: pblanchard $
//!   $Revision: 1090 $
//!   $Date: 2007-07-13 07:07:28 -0700 (Fri, 13 Jul 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	ATAPIEBI
//! @{
//!

// System include
#include <atapiebiDriver.h>

// Platform specific include
#include "AT91SAM926x.h"
#include "AT91SAM926x_interface.h"
#include "AT91SAM926x_oal_ioctl.h"
#include "lib_AT91SAM926x.h"

// Global variables
static BOOL						g_IDEInitialized	= FALSE; //!< Tell if IDE registers are already initialized
static volatile	AT91PS_MATRIX	g_pMatrix			= NULL;  //!< Matrix register
static volatile	AT91PS_SMC		g_pSMC				= NULL;  //!< SMC register
static volatile	AT91PS_PMC		g_pPMC				= NULL;	 //!< PMC Register

//-----------------------------------------------------------------------------
//! \fn			CDisk* CreateATAPIEBI( HKEY hDevKey )
//!
//! \brief		Driver entry point; Instantiate CATAPIEBIDisk
//!
//! \param		hDevKey	Handle to device driver's instance key
//!
//! \return		Object created
//!
//-----------------------------------------------------------------------------
EXTERN_C
CDisk* CreateATAPIEBI( HKEY hDevKey )
{
    return new CATAPIEBIDisk(hDevKey);
}

//-----------------------------------------------------------------------------
//! \fn			CATAPIEBIDisk::CATAPIEBIDisk( HKEY hKey )
//!
//! \brief		Constructor, Initialize this CATAPIEBIDisk instance
//!
//! \param		hKey Handle to device driver's instance key
//!
//-----------------------------------------------------------------------------
CATAPIEBIDisk::CATAPIEBIDisk( HKEY hKey ) : CDisk(hKey)
{
    m_hIsr = NULL;
    m_hIst = NULL;
    m_pPort = NULL;
    m_fInterruptSupported = FALSE;
    m_bRegAltStatus = ATA_REG_ALT_STATUS;
    m_bRegDrvCtrl = ATA_REG_DRV_CTRL;
}


//-----------------------------------------------------------------------------
//! \fn			CATAPIEBIDisk::~CATAPIEBIDisk()
//!
//! \brief		Destructor, Deinitialize this CATAPIEBIDisk instance
//!
//-----------------------------------------------------------------------------
CATAPIEBIDisk::~CATAPIEBIDisk()
{
    if (NULL != m_hIst) {
        m_pPort->m_dwFlag |= ISTFLG_EXIT; // direct IST to exit
        SetEvent(m_pPort->m_hIRQEvent);   // set IRQ event
        DWORD dwWaitResult;
        dwWaitResult = WaitForSingleObject(m_hIst, INFINITE); // wait for IST to exit
        if (dwWaitResult != WAIT_OBJECT_0) {
            DEBUGMSG(ZONE_ERROR, (_T(
                "Atapi!CATAPIEBIDisk::ConfigPort> failed to wait for IST to exit\r\n"
                )));
        }
        CloseHandle(m_hIst);
        m_hIst = NULL;
        m_pPort->m_dwFlag = 0; // reset IST directive

    }
    if (NULL != m_pPort->m_hIRQEvent) {
        CloseHandle(m_pPort->m_hIRQEvent);
        m_pPort->m_hIRQEvent = NULL;
    }

	// Free interrupt
	InterruptDisable( m_pPort->m_dwSysIntr );

    // Unmap the LogIntr to SysIntr
	if(! KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, &m_pPort->m_dwSysIntr, sizeof(m_pPort->m_dwSysIntr), NULL, 0, 0))
		DEBUGMSG(1, (_T("ATAPI> Failed to unmap the LogIntr\r\n")));

    // DeInit HW blocks
	AT91_IDEDeInit();

    // remove this disk instance from the master position in the associated
    // port table entry
    m_pPort->m_pDisk[0] = NULL;
}


//-----------------------------------------------------------------------------
//! \fn			VOID CATAPIEBIDisk::ConfigureRegisterBlock( DWORD dwStride )
//!
//! \brief		This function is called by DSK_Init before any other CDisk function to
//!      		set up the register block.
//!
//! \param		dwStride	Stride of block
//!
//-----------------------------------------------------------------------------
VOID CATAPIEBIDisk::ConfigureRegisterBlock( DWORD dwStride )
{
    m_dwStride = dwStride;
    m_dwDataDrvCtrlOffset = ATA_REG_DATA * dwStride;
    m_dwFeatureErrorOffset = ATA_REG_FEATURE * dwStride;
    m_dwSectCntReasonOffset = ATA_REG_SECT_CNT * dwStride;
    m_dwSectNumOffset = ATA_REG_SECT_NUM * dwStride;
    m_dwDrvHeadOffset = ATA_REG_DRV_HEAD * dwStride;
    m_dwCommandStatusOffset = ATA_REG_COMMAND * dwStride;
    m_dwByteCountLowOffset = ATA_REG_BYTECOUNTLOW * dwStride;
    m_dwByteCountHighOffset = ATA_REG_BYTECOUNTHIGH * dwStride;
    m_dwAltStatusOffset = ATA_REG_ALT_STATUS_CS1 * dwStride;
    m_dwAltDrvCtrl = ATA_REG_DRV_CTRL_CS1 * dwStride;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL CATAPIEBIDisk::Init( HKEY hActiveKey )
//!
//! \brief		Called by DSK_Init; the first device-specific intialization routine invoked
//!
//!      		This function was taken from promise.cpp; Its implementation is odd
//!
//! \param		hActiveKey Is this the same as hDevKey (device key)?
//! \return		True if all is good
//!
//-----------------------------------------------------------------------------
BOOL CATAPIEBIDisk::Init( HKEY hActiveKey )
{
	DWORD dwInitTime;
	// Hard-disk has 16b data bus
    m_f16Bit = TRUE;

	// Init HW blocks
	if (AT91_IDEConfigure() == FALSE)
	{
		return FALSE;
	}

    // configure channel; i.e., configure I/O port and ISR/IST
    if (!ConfigPort()) {
        RETAILMSG(ZONE_INIT, (_T(
            "Atapi!CATAPIEBIDisk::ConfigPort> failed to configure port; device %u\r\n"
            ), m_dwDeviceId));
        return FALSE;
    }

	// From registry, determine if interrupt can be enabled
    if (m_pPort->m_pDskReg[m_dwDeviceId]->dwInterruptDriven) {
        m_fInterruptSupported = TRUE;
	    }

	
    if (InitController() == FALSE) {
		RETAILMSG(1, (TEXT("InitController > Hard disk ERROR !!!\n\r")));
        return FALSE;
    }
	dwInitTime = GetTickCount();

	// Poll waiting the Hard disk is initialized (if present) or Timeout if not present
    memset(&m_Id, 0, sizeof(IDENTIFY_DATA));
	while (!ATAIssueIdentify(&m_Id)) {				// issue IDENTIFY DEVICE command
		if ((GetTickCount() - dwInitTime )> WAIT_TIME_LONG) {		// Timeout since the initialization
			RETAILMSG(1, (TEXT("ATAPIEBIDisk::Init > Hard disk ERROR !!!\n\r")));
			return FALSE;
		}
		Sleep(500); // Retry detection every 0.5 s
	}

/*
    // issue IDENTIFY DEVICE command
    memset(&m_Id, 0, sizeof(IDENTIFY_DATA));
    if (ATAIssueIdentify(&m_Id) == FALSE) {
		RETAILMSG(1, (TEXT("ATAIssueIdentify > Hard disk ERROR !!!\n\r")));
        return FALSE;
    }
*/
    // populate disk information
    m_fLBAMode = TRUE;
    m_DiskInfo.di_total_sectors = m_Id.TotalUserAddressableSectors;
    m_DiskInfo.di_bytes_per_sect = BYTES_PER_SECTOR;
    m_DiskInfo.di_cylinders = m_Id.NumberOfCylinders;
    m_DiskInfo.di_heads = m_Id.NumberOfHeads;
    m_DiskInfo.di_sectors = m_Id.SectorsPerTrack;
    m_DiskInfo.di_flags = DISK_INFO_FLAG_MBR;

    m_szDiskName = g_szPCCardATADiskName;

	RETAILMSG(1, (TEXT("ATAPIEBIDisk::Init > Hard disk found.\n\r")));

    return TRUE;
}

//-----------------------------------------------------------------------------
//! \fn			BBOOL CATAPIEBIDisk::ConfigPort()
//!
//! \brief		Although misnamed, install the driver's ISR. No IST is created
//!
//! \return		True if all is good
//!
//-----------------------------------------------------------------------------
BOOL CATAPIEBIDisk::ConfigPort()
{
    DWORD dwCleanUp = 0; // track progress for undo on clean up

    // fetch I/O window offsets for the device from the device's device key

    m_bRegAltStatus = (BYTE)m_pPort->m_pController->m_pIdeReg->dwAlternateStatusOffset;
    m_bRegDrvCtrl = (BYTE)m_pPort->m_pController->m_pIdeReg->dwDeviceControlOffset;

    // we are the master; save our disk instance with the master port
    m_pPort->m_pDisk[0] = (HANDLE)this;

    m_pATAReg = (PBYTE)m_pPort->m_dwRegBase;
    m_pATARegAlt = (PBYTE)m_pPort->m_dwRegAlt;

    // IDE_Init fetches the interrupt/SysIntr assignments for the device from
    // the device's key; interrupt/SysIntr assignments are completed by
    // the PC Card stack (or the PCI Bus driver)

    // create an interrupt event

    m_pPort->m_hIRQEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
    if (NULL == m_pPort->m_hIRQEvent) {
        DEBUGMSG(ZONE_INIT, (_T(
            "Atapi!PCMCIADisk::ConfigPort> failed to create interrupt event; device %u\r\n"
            ), m_pPort, m_dwDeviceId));
        goto cleanUp;
    }
    dwCleanUp |= CP_CLNUP_IRQEVENT;

    // No need to map the LogIntr to SysIntr because it is ever done by IDE_Init()
	
	// initialize interrupt

    if (!InterruptInitialize(m_pPort->m_dwSysIntr, m_pPort->m_hIRQEvent, NULL, 0)) {
        DEBUGMSG(ZONE_INIT, (_T(
            "Atapi!CATAPIEBIDisk::ConfigPort> failed to initialize interrupt; device %u, sysintr %u\r\n"
            ), m_dwDeviceId, m_pPort->m_dwSysIntr));
        return FALSE;
    }

    return TRUE;

cleanUp:;
    if (dwCleanUp & CP_CLNUP_INTCHNHDNLR) {
        FreeIntChainHandler(m_hIsr);
        m_hIsr = NULL;
    }
    if (dwCleanUp & CP_CLNUP_IST) {
        m_pPort->m_dwFlag |= ISTFLG_EXIT; // direct IST to exit
        SetEvent(m_pPort->m_hIRQEvent);   // set IRQ event
        DWORD dwWaitResult;
        dwWaitResult = WaitForSingleObject(m_hIst, INFINITE); // wait for IST to exit
        if (dwWaitResult != WAIT_OBJECT_0) {
            DEBUGMSG(ZONE_ERROR, (_T(
                "Atapi!CATAPIEBIDisk::ConfigPort> failed to wait for IST to exit\r\n"
                )));
        }
        CloseHandle(m_hIst);
        m_hIst = NULL;
        m_pPort->m_dwFlag = 0; // reset IST directive

    }
    if (dwCleanUp & CP_CLNUP_IRQEVENT) {
        CloseHandle(m_pPort->m_hIRQEvent);
        m_pPort->m_hIRQEvent = NULL;
    }
    return FALSE;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL CATAPIEBIDisk::InitController( BOOL fForce )
//!
//! \brief		Called by Init. This function was taken from atadisk (the legacy PCMCIA ATA driver)
//!
//! \param		fForce  legacy; not applicable
//! \return		True if all is good
//!
//-----------------------------------------------------------------------------
BOOL CATAPIEBIDisk::InitController( BOOL fForce )
{
    BOOL ret = TRUE;
    UCHAR status;

    __try {
        status = ATA_READ_BYTE(m_pATARegAlt + m_bRegAltStatus);
        if ((status & 0x0f) == 0x0f) {
            ret = FALSE;
            DEBUGMSG(ZONE_ERROR, (_T(
                "Atapi!CATAPIEBIDisk::InitController> error: ata_status=0x%x\r\n"
                ), status));
			return ret; // Added
        }

        // if interrupt is supported, enable interrupt
        if (m_fInterruptSupported) {
	        ATA_WRITE_BYTE(m_pATARegAlt + m_bRegDrvCtrl, ATA_CTRL_ENABLE_INTR);
		    if (ATAWaitForDisk(WAIT_TIME_LONG, WAIT_TYPE_READY) != ERROR_SUCCESS) {
			    ret = FALSE;
			}
		}
    }
    __except (GetExceptionCode() == STATUS_ACCESS_VIOLATION ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        DEBUGMSG(ZONE_ERROR, (_T(
            "Atapi!CATAPIEBIDisk::InitController> exception accessing device registers\r\n"
            )));
        ret = FALSE;
    }
    return ret;
}

//-----------------------------------------------------------------------------
//! \fn			DWORD CATAPIEBIDisk::GetDeviceInfo( PIOREQ pIOReq )
//!
//! \brief		GetDeviceInfo IOCTL_DISK_DEVICE_INFO
//!
//! \param		pIOReq 
//!
//! \return		ERROR_SUCCESS or ERROR_INVALID_PARAMETER
//!
//-----------------------------------------------------------------------------
DWORD CATAPIEBIDisk::GetDeviceInfo( PIOREQ pIOReq )
{
    PSTORAGEDEVICEINFO psdi = (PSTORAGEDEVICEINFO)pIOReq->pInBuf;
    HKEY hKey;
    PTSTR szProfile = NULL;

    if ((pIOReq->dwInBufSize == 0) || (pIOReq->pInBuf == NULL)) {
        return ERROR_INVALID_PARAMETER;
    }

    if (pIOReq->pBytesReturned) {
        *(pIOReq->pBytesReturned) = sizeof(STORAGEDEVICEINFO);
    }

    szProfile = psdi->szProfile;
    wcscpy(szProfile, L"PCMCIA");

    if (ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE, m_szDeviceKey, 0, 0, &hKey)) {
        if (!AtaGetRegistryString(hKey, (_T("Profile")), &szProfile, sizeof(psdi->szProfile))) {
            szProfile = psdi->szProfile;
            wcscpy(szProfile, L"PCMCIA");
        }
    }

    psdi->dwDeviceClass = STORAGE_DEVICE_CLASS_BLOCK;
    psdi->dwDeviceType = STORAGE_DEVICE_TYPE_PCCARD;
    psdi->dwDeviceType |= STORAGE_DEVICE_TYPE_ATA;
    psdi->dwDeviceType |= STORAGE_DEVICE_TYPE_REMOVABLE_DRIVE;
    psdi->dwDeviceFlags = STORAGE_DEVICE_FLAG_READWRITE;

    return ERROR_SUCCESS;
}

//-----------------------------------------------------------------------------
//! \fn			DWORD CATAPIEBIDisk::MainIoctl( PIOREQ pIoReq )
//!
//! \brief		Process IOCTL_DISK_Xxx command; override Xxx_READ/Xxx_WRITE;
//!
//! \param		pIoReq wrapped IOCTL_DISK_Xxx command
//!
//! \return		Win32 error
//!
//-----------------------------------------------------------------------------
DWORD CATAPIEBIDisk::MainIoctl( PIOREQ pIoReq )
{
    PSG_REQ pSG;

    DEBUGCHK(pIoReq);

    // validate parameters

    switch (pIoReq->dwCode) {
    case IOCTL_DISK_READ:
    case IOCTL_DISK_WRITE:
    case DISK_IOCTL_READ:
    case DISK_IOCTL_WRITE:
        if (pIoReq->pInBuf == NULL) {
            SetLastError(ERROR_INVALID_PARAMETER);
            return ERROR_INVALID_PARAMETER;
        }
        break;
    default:
        return CDisk::MainIoctl(pIoReq);
    }

    pSG = (PSG_REQ)pIoReq->pInBuf;
    if (!(pSG && pIoReq->dwInBufSize >= (sizeof(SG_REQ) + sizeof(SG_BUF) * (pSG->sr_num_sg - 1)))) {
        SetLastError(ERROR_INVALID_PARAMETER);
        return ERROR_INVALID_PARAMETER;
    }
    if ((pIoReq->dwCode == IOCTL_DISK_READ) || (pIoReq->dwCode == DISK_IOCTL_READ)) {
        pSG->sr_status = ATARead(pSG);
    }
    else {
        pSG->sr_status = ATAWrite(pSG);
    }
    if (ERROR_SUCCESS != pSG->sr_status) {
        SetLastError(pSG->sr_status);
    }
    return pSG->sr_status;
}

//-----------------------------------------------------------------------------
//! \fn			VOID CATAPIEBIDisk::EnableInterrupt()
//!
//! \brief		Declared as pure virtual in base CDisk class; default (empty) implementation
//!
//-----------------------------------------------------------------------------
VOID CATAPIEBIDisk::EnableInterrupt()
{
    return;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL CATAPIEBIDisk::WaitForInterrupt( DWORD dwTimeOut )
//!
//! \brief		Declared as pure virtual in base CDisk class; default (empty) implementation
//!
//! \return		FALSE
//!
//-----------------------------------------------------------------------------
BOOL CATAPIEBIDisk::WaitForInterrupt( DWORD dwTimeOut )
{
    return FALSE;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL CATAPIEBIDisk::SetupDMA( PSG_BUF pSGBuf, DWORD dwSGBufCount, BOOL fRead )
//!
//! \brief		Declared as pure virtual in base CDisk class; default (empty) implementation
//!
//! \return		FALSE
//!
//-----------------------------------------------------------------------------
BOOL CATAPIEBIDisk::SetupDMA( PSG_BUF pSGBuf, DWORD dwSGBufCount, BOOL fRead )
{
    return FALSE;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL CATAPIEBIDisk::BeginDMA( BOOL fRead )
//!
//! \brief		Declared as pure virtual in base CDisk class; default (empty) implementation
//!
//! \return		FALSE
//!
//-----------------------------------------------------------------------------
BOOL CATAPIEBIDisk::BeginDMA( BOOL fRead )
{
    return FALSE;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL CATAPIEBIDisk::EndDMA()
//!
//! \brief		Declared as pure virtual in base CDisk class; default (empty) implementation
//!
//! \return		FALSE
//!
//-----------------------------------------------------------------------------
BOOL CATAPIEBIDisk::EndDMA()
{
    return FALSE;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL CATAPIEBIDisk::AbortDMA()
//!
//! \brief		Declared as pure virtual in base CDisk class; default (empty) implementation
//!
//! \return		FALSE
//!
//-----------------------------------------------------------------------------
BOOL CATAPIEBIDisk::AbortDMA()
{
    return FALSE;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL CATAPIEBIDisk::CompleteDMA( PSG_BUF pSGBuf, DWORD dwSGBufCount, BOOL fRead )
//!
//! \brief		Declared as pure virtual in base CDisk class; default (empty) implementation
//!
//! \return		FALSE
//!
//-----------------------------------------------------------------------------
BOOL CATAPIEBIDisk::CompleteDMA( PSG_BUF pSGBuf, DWORD dwSGBufCount, BOOL fRead )
{
    return FALSE;
}

//-----------------------------------------------------------------------------
//! \fn			DWORD CATAPIEBIDisk::ATAWaitForDisk( DWORD dwTimeOut, UCHAR ucDeviceCondition )
//!
//! \brief		Wait for disk condition. By polling or interrupt
//!
//! \param		dwTimeOut	      wait timeout
//! \param		ucDeviceCondition device condition to wait for
//!
//! \return		error condition
//!
//-----------------------------------------------------------------------------
DWORD CATAPIEBIDisk::ATAWaitForDisk( DWORD dwTimeOut, UCHAR ucDeviceCondition )
{
    UCHAR ata_status = 0;
    DWORD error = ERROR_SUCCESS;
    DWORD start = GetTickCount();

    do {
        // read device status

        __try {
            ata_status = ATA_READ_BYTE(m_pATARegAlt + m_bRegAltStatus);
        }
        __except (GetExceptionCode() == STATUS_ACCESS_VIOLATION ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
            DEBUGMSG(ZONE_ERROR, (_T(
                "Atapi!CATAPIEBIDisk::ATAWaitForDisk> exception accessing device registers\r\n"
                )));
            error = ERROR_ACCESS_DENIED;
        }
        if (error != ERROR_SUCCESS) {
            return error;
        }

        if (ata_status & ATA_STATUS_BUSY) {

           // no other status bits are valid; if this is what we want, return;
           // else poll

           if (ucDeviceCondition == WAIT_TYPE_BUSY) {
              DEBUGMSG(ZONE_IO, (_T(
                  "Atapi!CATAPIEBIDisk::ATAWaitForDisk> device is busy\r\n"
                  )));
              goto awfd_done;
           }

        }
        else if (ucDeviceCondition == WAIT_TYPE_NOT_BUSY) {

           // we don't care about the error status of the last command here
           // because we're only waiting on the busy status (and because we
           // only do this when we're preparing to submit a new command)

           goto awfd_done;

        }
        else {

           if (ucDeviceCondition == WAIT_TYPE_DRQ_NOERR) {

              // this condition is special; ignore the error bit iff DRQ is set;
              // use this for write operations because the error bit may still be
              // set from the last operation; we have to complete a new operation
              // before the bit gets cleared (or it might be errored again in which
              // case the bit will stay set but DRQ won't be asserted)

              if (ata_status & ATA_STATUS_DATA_REQ) goto awfd_done;

           }
           if (ucDeviceCondition == WAIT_TYPE_RDY_NOERR) {

               if (ata_status & ATA_STATUS_READY) goto awfd_done;

           }

           // check the error condition

           if (ata_status & ATA_STATUS_ERROR) {

              // read Error register
              error = ATA_READ_BYTE(m_pATAReg + ATA_REG_ERROR);

              DEBUGMSG(ZONE_ERROR, (_T(
                  "Atapi!CATAPIEBIDisk::ATAWaitForDisk> error=0x%x\r\n"
                  ), error));

              if (error & ATA_ERROR_BAD_SECT_NUM) {
                  return ERROR_SECTOR_NOT_FOUND;
              }
              if (error & (ATA_ERROR_BAD_BLOCK|ATA_ERROR_UNCORRECTABLE)) {
                  return ERROR_INVALID_BLOCK;
              }
              return ERROR_DISK_OPERATION_FAILED;

           }

           switch (ucDeviceCondition) {
             case WAIT_TYPE_READY:
               if (ata_status & ATA_STATUS_READY) {
                  DEBUGMSG(ZONE_IO, (_T(
                      "Atapi!CATAPIEBIDisk::ATAWaitForDisk> ready (0x%x)\r\n"
                      ), ata_status));
                  goto awfd_done;
               }
               Sleep(10); // waiting for DRDY can take a while
               break;
             case WAIT_TYPE_DRQ:
               if (ata_status & ATA_STATUS_DATA_REQ) {
                  goto awfd_done;
               }
               break;
           }
        }

        // Sleep(1) can be as long as a time slice (~25ms/~100ms); inspect
        // elapsed milliseconds

        if ((GetTickCount() - start) >= dwTimeOut) {
            dwTimeOut = 0;
        }

    } while (dwTimeOut);

awfd_done:
    if (dwTimeOut == 0) {
        DEBUGMSG(ZONE_IO|ZONE_ERROR, (_T(
            "Atapi!CATAPIEBIDisk::ATAWaitForDisk> %s wait timed out\r\n"
            ), WaitTypes[ucDeviceCondition-1]));
        return ERROR_GEN_FAILURE;
    }
    else {
        return ERROR_SUCCESS;
    }
}

//-----------------------------------------------------------------------------
//! \fn			BOOL CATAPIEBIDisk::ATAIssueIdentify( PIDENTIFY_DATA pId )
//!
//! \brief		Issue IDENTIFY DEVICE command\n
//!      		This function was taken from atadisk (the legacy PCMCIA ATA driver)
//!
//! \param		pId IDENTIFY DEVICE container
//!
//! \return		True if all is good
//!
//-----------------------------------------------------------------------------
BOOL CATAPIEBIDisk::ATAIssueIdentify( PIDENTIFY_DATA pId )
{
    PUSHORT pBuf16;
    volatile USHORT *pData16;
    PUCHAR pBuf;
    volatile UCHAR *pData;
    DWORD i;
    BOOL ret;
#ifdef DEBUG
    PUCHAR pCh;
    TCHAR OutBuf[128];
    LPTSTR pOut;
    PUSHORT tempS;
    UCHAR tempByte;
    ULONG j,k;
    // TCHAR tch[100];
#endif

    ret = TRUE;

    // send IDENTIFY command

    __try {
        ATA_WRITE_BYTE(m_pATAReg + ATA_REG_COMMAND, ATA_CMD_IDENTIFY);
    }
    __except (GetExceptionCode() == STATUS_ACCESS_VIOLATION ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        DEBUGMSG(ZONE_ERROR, (_T(
            "Atapi!CATAPIEBIDisk::ATAIssueIdentify> exception accessing device registers\r\n"
            )));
        ret = FALSE;
    }
    if (ret == FALSE) {
        return ret;
    }

    // wait for DRQ or ERROR

    DEBUGMSG(ZONE_INIT, (_T("Atapi!CATAPIEBIDisk::ATAIssueIdentify> Wait for Hard drive identification\r\n")));

    if (ATAWaitForDisk(WAIT_TIME_LONG, WAIT_TYPE_DRQ)) {
        DEBUGMSG(ZONE_ERROR, (_T(
            "Atapi!CATAPIEBIDisk::ATAIssueIdentify> ATAWaitForDisk failed\r\n"
            )));
        return FALSE;
    }

    DEBUGMSG(ZONE_INIT, (_T("Atapi!CATAPIEBIDisk::ATAIssueIdentify> Hard drive identified\r\n")));

    // read identify information

    pBuf = (PUCHAR)pId;
    pBuf16 = (PUSHORT)pId;
    pData = (volatile UCHAR *) m_pATAReg;
    pData16 = (volatile USHORT *) m_pATAReg;
    __try {
        if (m_f16Bit) {
            i = (sizeof(IDENTIFY_DATA) - 4 + 1) / 2;
            while (i) {
                *pBuf16 = ATA_READ_WORD((PUSHORT)pData16);
                i--;
                pBuf16++;
            }
        }
        else {
            i = sizeof(IDENTIFY_DATA) - 4;
            while (i) {
                *pBuf = ATA_READ_BYTE((PUCHAR)pData);
                i--;
                pBuf++;
            }
        }
    }
    __except (GetExceptionCode() == STATUS_ACCESS_VIOLATION ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        DEBUGMSG(ZONE_ERROR, (_T(
            "Atapi!CATAPIEBIDisk::ATAIssueIdentify> exception accessing device registers\r\n"
            )));
        ret = FALSE;
    }
    if (ret == FALSE) {
        return ret;
    }

#ifdef DEBUG

    DEBUGMSG(ZONE_INIT, (TEXT("Atapi!CATAPIEBIDisk::ATAIssueIdentify> ...\r\n")));
    i = sizeof(IDENTIFY_DATA);
    pCh = (PUCHAR)pId;
    while (i) {
        pOut = OutBuf;
        k = (i < 16) ? i : 16;
        for (j = 0; j < k; j++) {
            pOut += wsprintf(pOut, TEXT("%2x "), pCh[j]);
        }
        if (k < 16) {
            for (j = 0; j < 16 - k; j++) {
                pOut += wsprintf(pOut, TEXT("   "));
            }
        }
        for (j = 0; j < k; j++) {
            if ((pCh[j] < ' ') || (pCh[j] > '~')) {
                pOut += wsprintf(pOut, TEXT("."));
            } else {
                pOut += wsprintf(pOut, TEXT("%c"), pCh[j]);
            }
        }
        DEBUGMSG(ZONE_INIT,(TEXT("%s\r\n"), OutBuf));
        i -= k;
        pCh += k;
    }
    if (pId->GeneralConfiguration & 0x8000) {
        DEBUGMSG(ZONE_INIT, (TEXT("    non-magnetic media\r\n")));
    }
    if (pId->GeneralConfiguration & 0x4000) {
        DEBUGMSG(ZONE_INIT, (TEXT("    format speed tolerance gap required\r\n")));
    }
    if (pId->GeneralConfiguration & 0x2000) {
        DEBUGMSG(ZONE_INIT, (TEXT("    track offset option available\r\n")));
    }
    if (pId->GeneralConfiguration & 0x1000) {
        DEBUGMSG(ZONE_INIT, (TEXT("    data strobe offset option available\r\n")));
    }
    if (pId->GeneralConfiguration & 0x0800) {
        DEBUGMSG(ZONE_INIT, (TEXT("    rotational speed tolerance is > 0,5%\r\n")));
    }
    if (pId->GeneralConfiguration & 0x0400) {
        DEBUGMSG(ZONE_INIT, (TEXT("    disk transfer rate > 10Mbs\r\n")));
    }
    if (pId->GeneralConfiguration & 0x0200) {
        DEBUGMSG(ZONE_INIT, (TEXT("    disk transfer rate > 5Mbs but <= 10Mbs\r\n")));
    }
    if (pId->GeneralConfiguration & 0x0100) {
        DEBUGMSG(ZONE_INIT, (TEXT("    disk transfer rate <= 5Mbs\r\n")));
    }
    if (pId->GeneralConfiguration & 0x0080) {
        DEBUGMSG(ZONE_INIT, (TEXT("    removeable cartridge drive\r\n")));
    }
    if (pId->GeneralConfiguration & 0x0040) {
        DEBUGMSG(ZONE_INIT, (TEXT("    fixed drive\r\n")));
    }
    if (pId->GeneralConfiguration & 0x0020) {
        DEBUGMSG(ZONE_INIT, (TEXT("    spindle motor control option implemented\r\n")));
    }
    if (pId->GeneralConfiguration & 0x0010) {
        DEBUGMSG(ZONE_INIT, (TEXT("    head switch time > 15us\r\n")));
    }
    if (pId->GeneralConfiguration & 0x0008) {
        DEBUGMSG(ZONE_INIT, (TEXT("    not MFM encoded\r\n")));
    }
    if (pId->GeneralConfiguration & 0x0004) {
        DEBUGMSG(ZONE_INIT, (TEXT("    soft sectored\r\n")));
    }
    if (pId->GeneralConfiguration & 0x0002) {
        DEBUGMSG(ZONE_INIT, (TEXT("    hard sectored\r\n")));
    }
    DEBUGMSG(ZONE_INIT, (TEXT(
            "    number of cylinders                        : %d\r\n"), pId->NumberOfCylinders));
    DEBUGMSG(ZONE_INIT, (TEXT(
            "    number of heads                            : %d\r\n"),pId->NumberOfHeads));
    DEBUGMSG(ZONE_INIT, (TEXT(
            "    unformatted bytes per track                : %d\r\n"),pId->UnformattedBytesPerTrack));
    DEBUGMSG(ZONE_INIT, (TEXT(
            "    unformatted bytes per sector               : %d\r\n"),pId->UnformattedBytesPerSector));
    DEBUGMSG(ZONE_INIT, (TEXT(
            "    sectors per track                          : %d\r\n"),pId->SectorsPerTrack));
    tempS = pId->ModelNumber;
    for (k=0; k<20; k++) {
        tempByte = (UCHAR)(tempS[k] & 0x00FF);
        tempS[k] = tempS[k] >> 8;
        tempS[k] |= tempByte << 8;
    }
    tempS = pId->FirmwareRevision;
    for (k=0; k<4; k++) {
        tempByte = (UCHAR)(tempS[k] & 0x00FF);
        tempS[k] = tempS[k] >> 8;
        tempS[k] |= tempByte << 8;
    }
    tempS = pId->SerialNumber;
    for (k=0; k<10; k++) {
        tempByte = (UCHAR)(tempS[k] & 0x00FF);
        tempS[k] = tempS[k] >> 8;
        tempS[k] |= tempByte << 8;
    }
    if (pId->BufferType == 0) {
        DEBUGMSG(ZONE_INIT, (TEXT(
            "    buffer type                                : unspecified\r\n")));
    }
    if (pId->BufferType == 1) {
        DEBUGMSG(ZONE_INIT, (TEXT(
            "    buffer type                                : single port; no simultaneous transfers\r\n")));
    }
    if (pId->BufferType == 2) {
        DEBUGMSG(ZONE_INIT, (TEXT(
            "    buffer type                                : dual port; simultaneous transfers supported\r\n")));
    }
    if (pId->BufferType == 3) {
        DEBUGMSG(ZONE_INIT, (TEXT(
            "    buffer type                                : dual port; simultaneous transfer supported, read cache supported\r\n")));
    }
    if (pId->BufferType >= 4) {
        DEBUGMSG(ZONE_INIT, (TEXT(
            "    buffer type                                : reserved\r\n")));
    }
    if (pId->BufferSectorSize == 0) {
        DEBUGMSG(ZONE_INIT, (TEXT(
            "    buffer size                                : unspecified\r\n")));
    }
    else {
        DEBUGMSG(ZONE_INIT, (TEXT(
            "    buffer size                                : %d sectors\r\n"),pId->BufferSectorSize));
    }
    if (pId->MaximumBlockTransfer == 0) {
        DEBUGMSG(ZONE_INIT, (TEXT(
            "    read/write multiple                        : not supported\r\n")));
    }
    else {
        DEBUGMSG(ZONE_INIT, (TEXT(
            "    read/write multiple                        : supported, %d sectors/interrupt\r\n"),
            pId->MaximumBlockTransfer));
    }
    if (pId->DoubleWordIo == 0) {
        DEBUGMSG(ZONE_INIT, (TEXT(
            "    double word IO                             : not supported\r\n")));
    }
    else if (pId->DoubleWordIo == 1) {
        DEBUGMSG(ZONE_INIT, (TEXT(
            "    double word IO                             : supported\r\n")));
    }
    else {
        DEBUGMSG(ZONE_INIT, (TEXT(
            "    double word IO                             : unrecognized mode\r\n")));
    }
    if (pId->Capabilities & 0x0200) {
        DEBUGMSG(ZONE_INIT, (TEXT(
            "    LBA mode                                   : supported\r\n")));
    }
    else {
        DEBUGMSG(ZONE_INIT, (TEXT(
            "    LBA mode                                   : not supported\r\n")));
    }
    if (pId->Capabilities & 0x0100) {
        DEBUGMSG(ZONE_INIT, (TEXT(
            "    DMA                                        : supported\r\n")));
    }
    else {
        DEBUGMSG(ZONE_INIT, (TEXT(
            "    DMA                                        : not supported\r\n")));
    }
    DEBUGMSG(ZONE_INIT, (TEXT(
            "    PIO cycle timing mode                      : %x\r\n"), pId->PioCycleTimingMode));
    DEBUGMSG(ZONE_INIT, (TEXT(
            "    DMA cycle timing mode                      : %x\r\n"), pId->DmaCycleTimingMode));
    if ((pId->TranslationFieldsValid & 1) == 0) {
        DEBUGMSG(ZONE_INIT, (TEXT(
            "    current size fields valid                  : unknown\r\n")));
    }
    else {
        DEBUGMSG(ZONE_INIT, (TEXT(
            "    current size fields valid                  : yes\r\n")));
    }
    DEBUGMSG(ZONE_INIT, (TEXT(
            "    current number of cylinders                : %d\r\n"), pId->NumberOfCurrentCylinders));

    DEBUGMSG(ZONE_INIT, (TEXT(
            "    current number of heads                    : %d\r\n"), pId->NumberOfCurrentHeads));
    DEBUGMSG(ZONE_INIT, (TEXT(
            "    current number of sectors/track            : %d\r\n"), pId->CurrentSectorsPerTrack));
    DEBUGMSG(ZONE_INIT, (TEXT(
            "    current sector capacity                    : %d\r\n"), pId->CurrentSectorCapacity));
    DEBUGMSG(ZONE_INIT, (TEXT(
            "    sectors/interrupt with read/write multiple : %d\r\n"), pId->MultiSectorCount));
    if (pId->MultiSectorSettingValid & 1) {
        DEBUGMSG(ZONE_INIT, (TEXT(
            "    multi sector setting                       : valid\r\n")));
    }
    else {
        DEBUGMSG(ZONE_INIT, (TEXT(
            "    multi sector setting                       : invalid\r\n")));
    }
    DEBUGMSG(ZONE_INIT, (TEXT(
            "    total user addressable sectors             : %d\r\n"), pId->TotalUserAddressableSectors));
    DEBUGMSG(ZONE_INIT, (TEXT(
            "    single word DMA modes supported            : %x\r\n"), pId->SingleDmaModesSupported));
    DEBUGMSG(ZONE_INIT, (TEXT(
            "    single word transfer mode active           : %x\r\n"), pId->SingleDmaTransferActive));
    DEBUGMSG(ZONE_INIT, (TEXT(
            "    multi word DMA modes supported             : %x\r\n"), pId->MultiDmaModesSupported));
    DEBUGMSG(ZONE_INIT, (TEXT(
            "    multi word transfer mode active            : %x\r\n"), pId->MultiDmaTransferActive));

#endif // DEBUG

    return TRUE;
}

//-----------------------------------------------------------------------------
//! \fn			DWORD CATAPIEBIDisk::ATASetSector( DWORD dwStartingSector, DWORD dwSectorsToTransfer, DWORD dwCommand )
//!
//! \brief		Prepare transfer\n
//!				This function was taken from atadisk (the legacy PCMCIA ATA driver)
//! \param		dwStartingSector    starting sector
//! \param		dwSectorsToTransfer number of sectors to transfer
//! \param		dwCommand           transfer command
//!
//! \return		ERROR_SUCCESS, ERROR_GEN_FAILURE
//!
//-----------------------------------------------------------------------------
DWORD CATAPIEBIDisk::ATASetSector( DWORD dwStartingSector, DWORD dwSectorsToTransfer, DWORD dwCommand )
{
    volatile UCHAR* base;
    DWORD sectors;
    DWORD heads;

    if (ATAWaitForDisk(WAIT_TIME_NORMAL, WAIT_TYPE_RDY_NOERR) != ERROR_SUCCESS) {
        return ERROR_GEN_FAILURE;
    }

    base = m_pATAReg;

    DEBUGMSG(ZONE_IO, (_T(
        "Atapi!CATAPIEBIDisk::ATASetSector> requesting %d sectors from %d\r\n"
        ), dwSectorsToTransfer, dwStartingSector));

    // write sector count to Sector Count register

    ATA_WRITE_BYTE((UCHAR*)base + ATA_REG_SECT_CNT, (UCHAR)dwSectorsToTransfer);

    if (m_fLBAMode == TRUE) {

        // write number of sectors to transfer to sector registers

        ATA_WRITE_BYTE((UCHAR*)base + ATA_REG_SECT_NUM, (UCHAR)dwStartingSector);
        ATA_WRITE_BYTE((UCHAR*)base + ATA_REG_CYL_LOW, (UCHAR)(dwStartingSector >> 8));
        ATA_WRITE_BYTE((UCHAR*)base + ATA_REG_CYL_HIGH, (UCHAR)(dwStartingSector >> 16));
        ATA_WRITE_BYTE((UCHAR*)base + ATA_REG_DRV_HEAD, (UCHAR)(((UCHAR)(dwStartingSector>>24))|ATA_HEAD_LBA_MODE|ATA_HEAD_DRIVE_1));

    }
    else {

        sectors = m_DiskInfo.di_sectors;
        heads = m_DiskInfo.di_heads;

        // write number of sectors to transfer sector registers

        ATA_WRITE_BYTE((UCHAR*)base + ATA_REG_SECT_NUM, (UCHAR)((dwStartingSector%sectors)+1));
        ATA_WRITE_BYTE((UCHAR*)base + ATA_REG_CYL_LOW, (UCHAR)(dwStartingSector/(sectors*heads)));
        ATA_WRITE_BYTE((UCHAR*)base + ATA_REG_CYL_HIGH, (UCHAR)((dwStartingSector/(sectors*heads)) >> 8));
        ATA_WRITE_BYTE((UCHAR*)base + ATA_REG_DRV_HEAD, (UCHAR)(((dwStartingSector/sectors)%heads)|ATA_HEAD_DRIVE_1));
    }

    // write transfer command to Command register

    ATA_WRITE_BYTE((UCHAR*)base + ATA_REG_COMMAND, (UCHAR)dwCommand);

    return ERROR_SUCCESS;
}

//-----------------------------------------------------------------------------
//! \fn			DWORD CATAPIEBIDisk::ATARead( PSG_REQ pSG )
//!
//! \brief		Read from the device - direct access to HW
//!
//! \param		pSG   scatter/gather request
//!
//! \return		error status
//!
//-----------------------------------------------------------------------------
DWORD CATAPIEBIDisk::ATARead( PSG_REQ pSG )
{
    DWORD            dwDoubleBufSect = 0;    // sectors in double buffer
    DWORD            dwDoubleBufIdx = 0;     // double buffer index
    PSG_BUF          pSg = NULL;             // current Sg buffer
    PUCHAR           pBuf = NULL;            // mapped Sg buffer
    DWORD            dwCurSgBufNum = 0;      // current Sg buffer number
    DWORD            dwCurSgBufIdx = 0;      // current Sg buffer index
    DWORD            dwStartSectNum = 0;     // starting sector number
    DWORD            dwCurNumSect = 0;       // current number of sectors to transfer
    DWORD            dwSectRemaining = 0;    // sectors remaining in transfer
    DWORD            dwBytesTransferred = 0; // bytes transferred (sub-transfer)
    DWORD            dwErr;                  // return
    volatile USHORT *pData16;                // Data register
    volatile UCHAR  *pData;                  // Data register
    PBYTE            pbDoubleBuf = NULL;     // double buffer
    DWORD            cbDoubleBuf = 0;        // double bufer size

    // validate arguments
    if (NULL == pSG) {
        return ERROR_INVALID_PARAMETER;
    }
    if (pSG->sr_start + pSG->sr_num_sec > m_DiskInfo.di_total_sectors) {
        return ERROR_INVALID_PARAMETER;
    }

    pSg = &(pSG->sr_sglist[0]);

    // map address and check for security violation
    pBuf = (LPBYTE)MapCallerPtr((LPVOID)pSg->sb_buf, pSg->sb_len);
    if (pSg->sb_buf != NULL && pBuf == NULL) {
        // security violation
        DEBUGMSG(ZONE_ERROR, (_T(
            "Atapi!CATAPIEBIDisk::ATARead> failed to map pointer to caller\r\n"
            )));
        return ERROR_INVALID_PARAMETER;
    }

    dwCurSgBufNum = 0;
    dwCurSgBufIdx = 0;
    dwStartSectNum = pSG->sr_start;
    dwCurNumSect = 0;
    dwSectRemaining = pSG->sr_num_sec;
    pData16 = (volatile USHORT*)m_pATAReg;
    pData = (volatile UCHAR*)m_pATAReg;

    // do we have to allocate the double buffer?
    if (NULL == m_rgbDoubleBuffer) {
        DEBUGMSG(ZONE_INIT, (TEXT(
            "Atapi!CATAPIEBIDisk::ATARead> allocating double buffer [first use]\r\n"
            )));
        m_rgbDoubleBuffer = (PBYTE)LocalAlloc(LPTR, m_pPort->m_pDskReg[m_dwDeviceId]->dwDoubleBufferSize);
        if (NULL == m_rgbDoubleBuffer) {
            DEBUGMSG(ZONE_ERROR, (TEXT(
                "Atapi!CATAPIEBIDisk::ATARead> failed to allocate double buffer\r\n"
                )));
            dwErr = ERROR_OUTOFMEMORY;
            return dwErr;
        }
    }

    pbDoubleBuf = m_rgbDoubleBuffer;
    cbDoubleBuf = m_pPort->m_pDskReg[m_dwDeviceId]->dwDoubleBufferSize;
    dwDoubleBufSect = (cbDoubleBuf / BYTES_PER_SECTOR);

    while (dwSectRemaining > 0) {

        // determine number of sectors to read to fill double buffer
        if (dwSectRemaining > dwDoubleBufSect) {
            dwCurNumSect = dwDoubleBufSect;
        }
        else {
            dwCurNumSect = dwSectRemaining;
        }

        // issue command
        __try {
            dwErr = ATASetSector(dwStartSectNum, dwCurNumSect, ATA_CMD_READ);
        }
        __except (GetExceptionCode() == STATUS_ACCESS_VIOLATION ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
            DEBUGMSG(ZONE_ERROR, (_T(
                "Atapi!CATAPIEBIDisk::ATARead> exception accessing device registers\r\n"
                )));
            dwErr = ERROR_READ_FAULT;
        }
        if (dwErr != ERROR_SUCCESS) {
            return dwErr;
        }

        // advance @dwCurNumSect sectors for the next read
        dwStartSectNum += dwCurNumSect;

        if (m_fInterruptSupported) {
			// Allow other threads to be scheduled
			if (WaitForSingleObject(m_pPort->m_hIRQEvent, DISK_IO_TIME_OUT) == WAIT_TIMEOUT) {
				DEBUGMSG(1, (TEXT("ATAPI > ATAWaitForDisk TIMEOUT !!!\r\n")));
			} else {
			    // unmask interrupt
			    InterruptDone(m_pPort->m_dwSysIntr);
			}
		}

        // wait for data
        dwErr = ATAWaitForDisk(WAIT_TIME_NORMAL, WAIT_TYPE_DRQ);
        if (dwErr != ERROR_SUCCESS) {
            DEBUGMSG(ZONE_ERROR, (_T(
                "Atapi!CATAPIEBIDisk::ATARead> failed to wait for DRQ\r\n"
                )));
            return dwErr;
        }

        // read from disk, fill double buffer
        dwBytesTransferred = dwCurNumSect * BYTES_PER_SECTOR;
        dwDoubleBufIdx = 0;
        __try {
            if (m_f16Bit) {
                while (dwBytesTransferred > 0) {
                    *((PUSHORT)(&bDoubleBuf[dwDoubleBufIdx])) = ATA_READ_WORD((PUSHORT)pData16);
                    dwDoubleBufIdx += 2;
                    dwBytesTransferred -= 2;
                    if ((dwDoubleBufIdx % BYTES_PER_SECTOR) == 0 && dwBytesTransferred > 0) {
                        dwErr = ATAWaitForDisk(WAIT_TIME_NORMAL, WAIT_TYPE_DRQ);
                        if (dwErr != ERROR_SUCCESS) {
                            DEBUGMSG(ZONE_ERROR, (_T(
                                "Atapi!CATAPIEBIDisk::ATARead> failed to wait for DRQ\r\n"
                                )));
                            return dwErr;
                        }
                    }
                }
            }
            else {
                while (dwBytesTransferred > 0) {
                    bDoubleBuf[dwDoubleBufIdx] = ATA_READ_BYTE((PUCHAR)pData);
                    dwDoubleBufIdx += 1;
                    dwBytesTransferred -= 1;
                    if ((dwDoubleBufIdx % BYTES_PER_SECTOR) == 0 && dwBytesTransferred > 0) {
                        dwErr = ATAWaitForDisk(WAIT_TIME_NORMAL, WAIT_TYPE_DRQ);
                        if (dwErr != ERROR_SUCCESS) {
                            DEBUGMSG(ZONE_ERROR, (_T(
                                "Atapi!CATAPIEBIDisk::ATARead> failed to wait for DRQ\r\n"
                                )));
                            return dwErr;
                        }
                    }
                }
            }
        }
        __except (GetExceptionCode() == STATUS_ACCESS_VIOLATION ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
            DEBUGMSG(ZONE_ERROR, (_T(
                "Atapi!CATAPIEBIDisk::ATARead> exception accessing device registers\r\n"
                )));
            dwErr = ERROR_READ_FAULT;
        }
        if (dwErr != ERROR_SUCCESS) {
            return dwErr;
        }

        // transfer from double buffer to Sg buffer(s)
        dwBytesTransferred = dwCurNumSect * BYTES_PER_SECTOR;
        dwDoubleBufIdx = 0;

        while (dwBytesTransferred > 0) {

            // copy a byte from the double buffer to the Sg buffer
            *pBuf = bDoubleBuf[dwDoubleBufIdx];
            pBuf++;
            dwCurSgBufIdx += 1;
            dwDoubleBufIdx += 1;
            dwBytesTransferred -= 1;

            // do we need to advance the Sg buffer?
            if (dwCurSgBufIdx == pSg->sb_len) {

                // advance Sg buffer
                dwCurSgBufNum += 1;

                if (dwCurSgBufNum != pSG->sr_num_sg) {
                    // fetch next Sg buffer, reset index and size
                    pSg = &pSG->sr_sglist[dwCurSgBufNum];
                    dwCurSgBufIdx = 0;
                    // map address and check for security violation
                    pBuf = (LPBYTE)MapCallerPtr((LPVOID)pSg->sb_buf, pSg->sb_len);
                    if (pSg->sb_buf != NULL && pBuf == NULL) {
                        // security violation
                        DEBUGMSG(ZONE_ERROR, (_T(
                            "Atapi!CATAPIEBIDisk::ATARead> failed to map pointer to caller\r\n"
                            )));
                        return ERROR_INVALID_PARAMETER;
                    }
                }
            }
        }

        // mark that we've transferred @dwCurNumSect sectors
        dwSectRemaining -= dwCurNumSect;

    }

    return 0;
}

//-----------------------------------------------------------------------------
//! \fn			DWORD CATAPIEBIDisk::ATAWrite( PSG_REQ pSG )
//!
//! \brief		Write from the device - direct access to HW
//!
//! \param		pSG   scatter/gather request
//!
//! \return		error status
//!
//-----------------------------------------------------------------------------
DWORD CATAPIEBIDisk::ATAWrite( PSG_REQ pSG )
{
    DWORD            dwDoubleBufSect = 0;    // sectors in double buffer
    DWORD            dwDoubleBufIdx = 0;     // double buffer index
    PSG_BUF          pSg = NULL;             // current Sg buffer
    PUCHAR           pBuf = NULL;            // mapped Sg buffer
    DWORD            dwCurSgBufNum = 0;      // current Sg buffer number
    DWORD            dwCurSgBufIdx = 0;      // current Sg buffer index
    DWORD            dwStartSectNum = 0;     // starting sector number
    DWORD            dwCurNumSect = 0;       // current number of sectors to transfer
    DWORD            dwSectRemaining = 0;    // sectors remaining in transfer
    DWORD            dwBytesTransferred = 0; // bytes transferred (sub-transfer)
    DWORD            dwErr;                  // result
    volatile USHORT *pData16;                // Data register
    volatile UCHAR  *pData;                  // Data register
    PBYTE            pbDoubleBuf = NULL;     // double buffer
    DWORD            cbDoubleBuf = 0;        // double bufer size

    // validate arguments
    if (NULL == pSG) {
        return ERROR_INVALID_PARAMETER;
    }
    if (pSG->sr_start + pSG->sr_num_sec > m_DiskInfo.di_total_sectors) {
        return ERROR_INVALID_PARAMETER;
    }

    pSg = &(pSG->sr_sglist[0]);

    // map address and check for security violation
    pBuf = (LPBYTE)MapCallerPtr((LPVOID)pSg->sb_buf, pSg->sb_len);
    if (pSg->sb_buf != NULL && pBuf == NULL) {
        // security violation
        DEBUGMSG(ZONE_ERROR, (_T(
            "Atapi!CATAPIEBIDisk::ATAWrite> failed to map pointer to caller\r\n"
            )));
        return ERROR_INVALID_PARAMETER;
    }

    dwCurSgBufNum = 0;
    dwCurSgBufIdx = 0;
    dwStartSectNum = pSG->sr_start;
    dwCurNumSect = 0;
    dwSectRemaining = pSG->sr_num_sec;
    pData16 = (volatile USHORT*)m_pATAReg;
    pData = (volatile UCHAR*)m_pATAReg;

    // do we have to allocate the double buffer?
    if (NULL == m_rgbDoubleBuffer) {
        DEBUGMSG(ZONE_INIT, (TEXT(
            "Atapi!CATAPIEBIDisk::ATAWrite> allocating double buffer [first use]\r\n"
            )));
        m_rgbDoubleBuffer = (PBYTE)LocalAlloc(LPTR, m_pPort->m_pDskReg[m_dwDeviceId]->dwDoubleBufferSize);
        if (NULL == m_rgbDoubleBuffer) {
            DEBUGMSG(ZONE_ERROR, (TEXT(
                "Atapi!CATAPIEBIDisk::ATAWrite> failed to allocate double buffer\r\n"
                )));
            dwErr = ERROR_OUTOFMEMORY;
            return dwErr;
        }
    }

    pbDoubleBuf = m_rgbDoubleBuffer;
    cbDoubleBuf = m_pPort->m_pDskReg[m_dwDeviceId]->dwDoubleBufferSize;
    dwDoubleBufSect = cbDoubleBuf / BYTES_PER_SECTOR;

    while (dwSectRemaining > 0) {

        // determine number of sectors to fill double buffer with (to write to disk)
        if (dwSectRemaining > dwDoubleBufSect) {
            dwCurNumSect = dwDoubleBufSect;
        }
        else {
            dwCurNumSect = dwSectRemaining;
        }

        // transfer from Sg buffer(s) to double buffer

        dwBytesTransferred = dwCurNumSect * BYTES_PER_SECTOR;
        dwDoubleBufIdx = 0;
        ZeroMemory(pbDoubleBuf, cbDoubleBuf);

        while (dwBytesTransferred > 0) {

            // copy a byte from the double buffer to the Sg buffer
            pbDoubleBuf[dwDoubleBufIdx] = *pBuf;
            pBuf++;
            dwCurSgBufIdx += 1;
            dwDoubleBufIdx += 1;
            dwBytesTransferred -= 1;

            // do we need to advance the Sg buffer?
            if (dwCurSgBufIdx == pSg->sb_len) {

                // advance Sg buffer
                dwCurSgBufNum += 1;

                if (dwCurSgBufNum != pSG->sr_num_sg) {
                    // fetch next Sg buffer, reset index and size
                    pSg = &pSG->sr_sglist[dwCurSgBufNum];
                    dwCurSgBufIdx = 0;
                    // map address and check for security violation
                    pBuf = (LPBYTE)MapCallerPtr((LPVOID)pSg->sb_buf, pSg->sb_len);
                    if (pSg->sb_buf != NULL && pBuf == NULL) {
                        // security violation
                        DEBUGMSG(ZONE_ERROR, (_T(
                            "Atapi!CATAPIEBIDisk::ATAWrite> failed to map pointer to caller\r\n"
                            )));
                        return ERROR_INVALID_PARAMETER;
                    }
                }
            }
        }

        // issue command
        __try {
            dwErr = ATASetSector(dwStartSectNum, dwCurNumSect, ATA_CMD_WRITE);
        }
        __except (GetExceptionCode() == STATUS_ACCESS_VIOLATION ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
            DEBUGMSG(ZONE_ERROR, (_T(
                "Atapi!CATAPIEBIDisk::ATAWrite> exception accessing device registers\r\n"
                )));
            dwErr = ERROR_READ_FAULT;
        }
        if (dwErr != ERROR_SUCCESS) {
            return dwErr;
        }

        // advance @dwCurNumSect for the next write
        dwStartSectNum += dwCurNumSect;

        // wait for data
        dwErr = ATAWaitForDisk(WAIT_TIME_NORMAL, WAIT_TYPE_DRQ_NOERR);
        if (dwErr != ERROR_SUCCESS) {
            DEBUGMSG(ZONE_ERROR, (_T(
                "Atapi!CATAPIEBIDisk::ATAWrite> failed to wait for DRQ\r\n"
                )));
            return dwErr;
        }

        // write to disk, empty double buffer
        dwBytesTransferred = dwCurNumSect * BYTES_PER_SECTOR;
        dwDoubleBufIdx = 0;
        __try {
            if (m_f16Bit) {
                while (dwBytesTransferred > 0) {
                    ATA_WRITE_WORD((PUSHORT)pData16, *((PUSHORT)(&pbDoubleBuf[dwDoubleBufIdx])));
                    dwDoubleBufIdx += 2;
                    dwBytesTransferred -= 2;
                    if ((dwDoubleBufIdx % BYTES_PER_SECTOR) == 0 && dwBytesTransferred > 0) {
                        dwErr = ATAWaitForDisk(WAIT_TIME_NORMAL, WAIT_TYPE_DRQ_NOERR);
                        if (dwErr != ERROR_SUCCESS) {
                            DEBUGMSG(ZONE_ERROR, (_T(
                                "Atapi!CATAPIEBIDisk::ATAWrite> failed to wait for DRQ\r\n"
                                )));
                            return dwErr;
                        }
                    }
                }
            }
            else {
                while (dwBytesTransferred > 0) {
                    ATA_WRITE_BYTE((PUCHAR)pData, pbDoubleBuf[dwDoubleBufIdx]);
                    dwDoubleBufIdx += 1;
                    dwBytesTransferred -= 1;
                    if ((dwDoubleBufIdx % BYTES_PER_SECTOR) == 0 && dwBytesTransferred > 0) {
                        dwErr = ATAWaitForDisk(WAIT_TIME_NORMAL, WAIT_TYPE_DRQ_NOERR);
                        if (dwErr != ERROR_SUCCESS) {
                            DEBUGMSG(ZONE_ERROR, (_T(
                                "Atapi!CATAPIEBIDisk::ATAWrite> failed to wait for DRQ\r\n"
                                )));
                            return dwErr;
                        }
                    }

                }
            }
        }
        __except (GetExceptionCode() == STATUS_ACCESS_VIOLATION ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
            DEBUGMSG(ZONE_ERROR, (_T(
                "Atapi!CATAPIEBIDisk::ATAWrite> exception accessing device registers\r\n"
                )));
            dwErr = ERROR_READ_FAULT;
        }
        if (dwErr != ERROR_SUCCESS) {
            return dwErr;
        }

        // mark that we've transferred @dwCurNumSect
        dwSectRemaining -= dwCurNumSect;

    }

    return 0;
}

//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/AtapiEbi/atapiebiDriver.cpp $
//-----------------------------------------------------------------------------

//! @}
