//-----------------------------------------------------------------------------
//! \addtogroup   USBFN
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				AT91RM9200_usbfn_endpoint_ctl.h
//!
//! \brief				Declaration for the OUT endpoint
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/DRIVERS/USBFN/AT91RM9200_usbfn_endpoint_CTL.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------
#include <csync.h>
#include <cmthread.h>
#include <CRegEdit.h>
#include <CRefCon.h>
#include <usbfn.h>


#define EP0_MAX_PACKET_SIZE 0x8 

class AT91RMEndpoint;

class AT91RMEndpointCtrl : public AT91RMEndpoint 
{
public:
    AT91RMEndpointCtrl(AT91RMUsbDevice * const pUsbDevice) 
        : AT91RMEndpoint(pUsbDevice, 0) 
    {
		m_bIgnoreNextHandshakeFromMDD = TRUE;
    }
    BOOL Init(PUSB_ENDPOINT_DESCRIPTOR pEndpointDesc,
            BYTE bConfigurationValue, BYTE bInterfaceNumber, BYTE bAlternateSetting);   
//    virtual BOOL ReInit();
    //DWORD IssueTransfer(PSTransfer pTransfer );
    DWORD SendControlStatusHandshake(CtrlCallBackInfo* pCallBackInfo = NULL) ;
    DWORD   IST(DWORD dwIRBit);
	void SetAddressCompleted(DWORD dwParam);
	void SetConfigurationCompleted(DWORD dwParam);
protected:
    BOOL  ContinueTransfer();
private:    
};





AT91RMUsbDevice * CreateAT91RMUsbDevice(LPCTSTR lpActivePath);





//! @}