//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//
//! \file		EmacbNDIS/emacb.cpp
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/EmacbNDIS/emacb.cpp $
//!   $Author: ltourlonias $
//!   $Revision: 966 $
//!   $Date: 2007-06-08 11:10:11 +0200 (ven., 08 juin 2007) $
//! \endif
// 
//-----------------------------------------------------------------------------
//! \addtogroup EMACNDIS
//! @{
//

// Common includes
#include	<windows.h>
#include	<oal.h>

// Controllers includes

// APIs includes
#include	"at91sam926x.h"
#include	"lib_at91sam926x.h"
#include	"AT91SAM926x_oal_intr.h"

// Driver includes
#include	"cemacb.h"


#define GET_LINK_SPEED_TIMEOUT 3000		//< Timeout value on get link speed mechanism
#define IMR_MASK 0xFFFFC000;			//< Interrupt mask register wanted value

#define AT91C_EMAC_PHY_SOF (0x01 << 30)
#define AT91C_EMAC_PHY_CODE (0x02 << 16)
#define AT91C_EMAC_PHY_BASE_WORD (AT91C_EMAC_PHY_SOF | AT91C_EMAC_PHY_CODE)

#define AT91C_EMAC_READ_PHY (0x02 << 28)
#define AT91C_EMAC_WRITE_PHY (0x01 << 28)

extern "C" DWORD EMACBProcSpecificGetMacbBaseAddress(void);	//< Imported function for get Emac base address
extern "C" void  EMACBProcSpecificActivatePMC(void);		//< Imported function for activate PMC on emacb controller


// This table contains driver configuration. (configuration ID / default value / NDIS Name
CONFIG_PARAMETER	g_szEMACBConfigParams[] =
{
	{ CID_CONNECTION_TYPE, -1, NDIS_STRING_CONST("ConnectionType") },
	{ CID_SLOT_NUMBER, -1, NDIS_STRING_CONST("SlotNumber")},
	{ CID_BUFFER_PHYSICAL_ADDRESS, 0, NDIS_STRING_CONST("BufferPhysicalAddress")},
	{ CID_TXBUFFER_NUMBER, 0x20, NDIS_STRING_CONST("XmitBuffer")},
	{ CID_RXBUFFER_NUMBER, 0x10, NDIS_STRING_CONST("RecvBuffer")},
	{ CID_ADAPTER_NUMBER, 0, NDIS_STRING_CONST("AdapterNumber")},
	{ CID_MEM_BASE_ADDRESS, 0x300, NDIS_STRING_CONST("MemBaseAddress")},
	{ CID_VENDOR_ID, 0x1, NDIS_STRING_CONST("VendorID")},
	{ CID_PRODUCT_ID, 0x1, NDIS_STRING_CONST("ProductID")},
	{ CID_MEM_RANGE, 0x10, NDIS_STRING_CONST("MemRange")},
	{ CID_IRQ_NUMBER, 3, NDIS_STRING_CONST("IrqNumber")},
	{ -1,-1,NULL}
};

//------------------------------------------------------------------------------
//! \fn PCONFIG_PARAMETER C_EMACB::DeviceConfigureParameters(void)
//!
//! \brief This function return default configuration parameter
//! 
//! \return		The default configuration
//------------------------------------------------------------------------------
PCONFIG_PARAMETER	C_EMACB::DeviceConfigureParameters(void)
{
	return (PCONFIG_PARAMETER)&g_szEMACBConfigParams[0];
}


//------------------------------------------------------------------------------
//! \fn void C_EMACB::EDeviceValidateConfigurations(void)
//!
//! \brief     This function validate the configuration
//------------------------------------------------------------------------------
void	C_EMACB::EDeviceValidateConfigurations(void)
{
	NDIS_HANDLE		hndis = m_pUpper->GetNdisHandle();

	// validate slot number
	if( 
		(m_szConfigures[CID_MEM_BASE_ADDRESS] == -1) ||
		(m_szConfigures[CID_IRQ_NUMBER] == -1) ) 
		THROW(());

	m_szCurrentSettings[SID_GEN_TRANSMIT_BUFFER_SPACE] = 
		m_szConfigures[CID_TXBUFFER_NUMBER]
		* ETH_MAX_FRAME_SIZE;
	m_szCurrentSettings[SID_GEN_RECEIVE_BUFFER_SPACE] = 
		m_szConfigures[CID_RXBUFFER_NUMBER]
		* ETH_MAX_FRAME_SIZE;

	m_szConfigures[CID_CHECK_FOR_HANG_PERIOD] = 3;
	m_szConfigures[CID_IRQ_GEN_TYPE] = NdisInterruptLatched;
	m_szConfigures[CID_IRQ_SHARED] = TRUE;
	m_szConfigures[CID_IRQ_LEVEL] = 0x0F;
	m_szConfigures[CID_INTERFACE_TYPE] = NdisInterfaceIsa;
	m_szConfigures[CID_BUS_MASTER] = FALSE;

	// set receive mode
	// <5> discard long packet
	// <4> discard CRC error packet
	// <0> rx enable
	m_szCurrentSettings[SID_OP_MODE] = MAKE_MASK3(5,4,0);

	m_szCurrentSettings[SID_802_3_MAXIMUM_LIST_SIZE] = EMAC_MULTICAST_LIST;
}


/*******************************************************************************
 *
 * Device access routines
 *
 ********************************************************************************/
#define	ENTER_CRITICAL_SECTION	m_spinAccessToken.Lock();
#define	LEAVE_CRITICAL_SECTION	m_spinAccessToken.Release();
#define	VALIDATE_ADDR_PORT(p) \
	if(m_uLastAddressPort != (p)) \
		NdisRawWritePortUchar( \
		m_szCurrentSettings[SID_PORT_BASE_ADDRESS] + EMACB_ADDR_OFFSET,  \
		(U8) (m_uLastAddressPort=(U32(p))) )

//------------------------------------------------------------------------------
//! \fn U16 C_EMACB::DeviceReadPhy(U32 uRegister, U32 uOffset)
//! \brief     This function read an offset of a register on the PHY
//! 
//! \param uRegister	Register wanted to read
//!
//! \param uOffset		Offset of the register wanted to read
//!
//! \return		Value read
//------------------------------------------------------------------------------
U16	C_EMACB::DeviceReadPhy(
	U32		uRegister,
	U32		uOffset)
{
	m_pEmac->EMAC_MAN = AT91C_EMAC_PHY_BASE_WORD | AT91C_EMAC_READ_PHY | ((m_ucPhyAddr & 0x1f) << 23) | (uRegister << 18);

	// Wait until IDLE bit in Network Status register is cleared
	while (!(m_pEmac->EMAC_NSR & AT91C_EMAC_IDLE));
	return (m_pEmac->EMAC_MAN & AT91C_EMAC_DATA);

}

//------------------------------------------------------------------------------
//! \fn U16	C_EMACB::DeviceWritePhy(U32 uRegister, U32 uOffset, U16 uValue)
//! \brief     This function write specified value at an offset of a register
//! 
//! \param uRegister     Register wanted to write  
//!
//! \param uOffset       Offset of the register wanted to write
//!
//! \param uValue		 Value to write
//!
//! \return		Writed value
//------------------------------------------------------------------------------
U16	C_EMACB::DeviceWritePhy(
	U32		uRegister,
	U32		uOffset,
	U16		uValue)
{
	m_pEmac->EMAC_MAN = AT91C_EMAC_PHY_BASE_WORD | AT91C_EMAC_WRITE_PHY | ((m_ucPhyAddr & 0x1f) << 23) | (uRegister << 18) | (uValue & 0xFFFF);

	// Wait until IDLE bit in Network Status register is cleared
	while (!(m_pEmac->EMAC_NSR & AT91C_EMAC_IDLE));
	return (m_pEmac->EMAC_MAN & AT91C_EMAC_DATA);

}

//------------------------------------------------------------------------------
//! \fn U32	C_EMACB::DeviceReadData(void)
//! \brief		Not implemented
//!
//! \return		Always 0
//------------------------------------------------------------------------------
U32		C_EMACB::DeviceReadData(void)
{
	return 0;
}
	
//------------------------------------------------------------------------------
//! \fn U32	C_EMACB::DeviceReadDataWithoutIncrement(void)
//! \brief		Not implemented
//!
//! \return		Always 0
//------------------------------------------------------------------------------
U32		C_EMACB::DeviceReadDataWithoutIncrement(void)
{
	return 0;
}

//------------------------------------------------------------------------------
//! \fn C_EMACB::DeviceReadString(PU8 ptrBuffer,int nLength)
//! \brief		Not implemented 
//! 
//! \param ptrBuffer       Not used
//!
//! \param nLength		   Not used
//!
//! \return		Always 0
//------------------------------------------------------------------------------
PU8		C_EMACB::DeviceReadString(
	PU8		ptrBuffer,
	int		nLength)
{
	return 0;
}

//------------------------------------------------------------------------------
//! \fn PU8	C_EMACB::DeviceWriteString(PU8 ptrBuffer, int nLength)
//! \brief		Not implemented 
//! 
//! \param ptrBuffer       Not used
//!
//! \param nLength		   Not used
//!
//! \return		Always 0
//------------------------------------------------------------------------------
PU8		C_EMACB::DeviceWriteString(
	PU8		ptrBuffer,
	int		nLength)
{
	return 0;
}

//------------------------------------------------------------------------------
//! \fn void C_EMACB::DeviceEnableInterrupt(void)
//! \brief   This function enable interrupt (write in IER register)  
//------------------------------------------------------------------------------
void	C_EMACB::DeviceEnableInterrupt(void)
{
	m_pEmac->EMAC_IER = 0x00003CFE;
}

//------------------------------------------------------------------------------
//! \fn void C_EMACB::DeviceDisableInterrupt(void)
//! \brief    Not implemented
//------------------------------------------------------------------------------
void	C_EMACB::DeviceDisableInterrupt(void)
{

}

//------------------------------------------------------------------------------
//! \fn void C_EMACB::DeviceEnableReceive(void)
//! \brief     Not implemented
//------------------------------------------------------------------------------
void 	C_EMACB::DeviceEnableReceive(void)
{

}

//------------------------------------------------------------------------------
//! \fn void C_EMACB::DeviceDisableReceive(void)
//! \brief     Not implemented
//------------------------------------------------------------------------------
void 	C_EMACB::DeviceDisableReceive(void)
{

}

//------------------------------------------------------------------------------
//! \fn U32 C_EMACB::DeviceGetInterruptStatus(void)
//! \brief      This function return the interrupt status (ISR & IMR register)
//!
//! \return		The interrupt status 
//------------------------------------------------------------------------------
U32	C_EMACB::DeviceGetInterruptStatus(void)
{
	U32 test = m_pEmac->EMAC_ISR;
	U32 mask = m_pEmac->EMAC_IMR | IMR_MASK;
	test &= ~mask;
		
	return test;
}

//------------------------------------------------------------------------------
//! \fn U32 C_EMACB::DeviceSetInterruptStatus(U32 uValue)
//! \brief     Not implemented
//!
//! \return		Always 0
//------------------------------------------------------------------------------
U32 C_EMACB::DeviceSetInterruptStatus(U32 uValue)
{
	return 0;
}

//------------------------------------------------------------------------------
//! \fn U32 C_EMACB::DeviceGetReceiveStatus(void)
//! \brief     Not implemented
//! 
//! \return		Always 0
//------------------------------------------------------------------------------
U32	C_EMACB::DeviceGetReceiveStatus(void)
{
	return 0;
}

//------------------------------------------------------------------------------
//! \fn void C_EMACB::DeviceStart(void)
//! \brief     This function start device by enabling interrupt
//------------------------------------------------------------------------------
void	C_EMACB::DeviceStart(void)
{
	DeviceEnableInterrupt();
}

//------------------------------------------------------------------------------
//! \fn void C_EMACB::DeviceReset(void)
//! \brief     This function reset the device
//------------------------------------------------------------------------------
void	C_EMACB::DeviceReset(void)
{
//	C_Exception	*pexp;

	RETAILMSG(1, (L"-->EMACB::DeviceReset\r\n"));

#ifdef	IMPL_RESET
	// announce shutdown
	m_bShutdown = 1;
#endif	
	
	/*TRY
	{
		EDeviceInitialize(++m_nResetCounts);
		FI;
	}
	CATCH(pexp){
		// nothing to do
		CLEAN(pexp);
	}*/

	// dequeue for all objects in waiting and standby queue
	PCQUEUE_GEN_HEADER	pcurr;
	for(;(pcurr=m_TQWaiting.Dequeue());)
	{
		m_mutexTxValidate.Lock();
		DeviceSendCompleted(pcurr, NDIS_STATUS_FAILURE);
		m_mutexTxValidate.Release();
	}	

#ifdef	IMPL_RESET
	m_bShutdown = 0;
#endif

	RETAILMSG(1, (L"<--EMACB::DeviceReset\r\n"));
}

//------------------------------------------------------------------------------
//! \fn BOOL C_EMACB::CheckCable()
//! \brief		This function check if cable is connected
//!
//! \return		TRUE if cable attacted, FALSE else.
//------------------------------------------------------------------------------
BOOL C_EMACB::CheckCable(void)
{
	BOOL	bRet = TRUE;
	DWORD	dwValue;

	m_pEmac->EMAC_NCR |= AT91C_EMAC_MPE;
	dwValue = DeviceReadPhy(DM9161A_STATUS_REG, 0);

	if(!(dwValue & DM9161A_STATUS_REG_LINK))
	{
		bRet = FALSE;
	}
	m_pEmac->EMAC_NCR &= ~AT91C_EMAC_MPE;
	return bRet;
}

//------------------------------------------------------------------------------
//! \fn void C_EMACB::EDeviceInitialize(int nResetCounts)
//! \brief     This function initialize device
//! 
//! \param nResetCounts    Number of reset already executed
//!
//! This function begin by map io and initialize PMC if necessary.
//! Then the hardware controller are initialize (by writing in correct register)
//! To finish, TX and RX buffers are initialized
//------------------------------------------------------------------------------
void C_EMACB::EDeviceInitialize(int nResetCounts)
{
	DWORD mac_cfg;

//	RETAILMSG(1, (L"-->EDeviceInitialize\r\n"));
	
	// reset member varialbes
	m_uLastAddressPort = (U32)-1;
		
	PHYSICAL_ADDRESS	PA_PhysicalAddr;
	if(nResetCounts == 0)
	{
		PA_PhysicalAddr.HighPart = 0;
		PA_PhysicalAddr.LowPart = EMACBProcSpecificGetMacbBaseAddress();
		m_pEmac =  (AT91PS_EMAC)MmMapIoSpace(PA_PhysicalAddr, sizeof(AT91S_EMAC), FALSE);		
		
		PIOConfiguration();
		EMACBProcSpecificActivatePMC();
	}
	
	if(PhyConfiguration() == TRUE)
	{
		m_pEmac->EMAC_NCR  = 0;
		// Update the MAC with the new information 
		mac_cfg = m_pEmac->EMAC_NCFGR & ~(AT91C_EMAC_SPD | AT91C_EMAC_FD);
		
		if (m_PhyCfg.dwSpeed == SPEED_100) 
		{
			mac_cfg |= AT91C_EMAC_SPD;
		}
		else if (m_PhyCfg.dwSpeed == SPEED_10) 
		{
			//Nothing to do here
		}
		else
		{
			RETAILMSG(1,(TEXT("Invalid network speed\r\n")));
		}
		
		if (m_PhyCfg.bFullDuplex== TRUE)	
		{
			mac_cfg |= AT91C_EMAC_FD;
		}
		
		m_pEmac->EMAC_NCFGR = mac_cfg | AT91C_EMAC_DRFCS;
		m_pEmac->EMAC_RSR  = 0xFFFFFFFF;	// reset all status register
		m_pEmac->EMAC_TSR  = 0xFFFFFFFF;
		m_pEmac->EMAC_IDR = 0xFFFFFFFF;		// disable all interrupts
		m_pEmac->EMAC_NCR  |= AT91C_EMAC_CLRSTAT | AT91C_EMAC_DRFCS; // Clear the statistics
		m_pEmac->EMAC_USRIO  = (m_PhyCfg.bRMII ? AT91C_EMAC_RMII : 0) | AT91C_EMAC_CLKEN;
		m_pEmac->EMAC_NCR  |= (AT91C_EMAC_TE | AT91C_EMAC_RE);
		
		// write Mac Address in Mac Register
		m_pEmac->EMAC_SA1L = ((int)m_MacAddr[3] << 24) | ((int)m_MacAddr[2] << 16) | ((int)m_MacAddr[1] << 8) | m_MacAddr[0];
		m_pEmac->EMAC_SA1H = ((int)m_MacAddr[5] << 8) | m_MacAddr[4];


		// Buffer init
		//TX Buffer
		DWORD TabAddr;
//		RETAILMSG(1,(TEXT("Init TX Buffer\r\n")));
		m_Xmitdesc = (DMA_DESC *)(m_pUpper->m_VirtAddrTxDesc);
		
		TabAddr = m_pUpper->m_PhysAddrTxBuffer ;
//		RETAILMSG(1, (L"nbbuff %d\r\n",m_szConfigures[CID_TXBUFFER_NUMBER]));
		for(int i=0; i<(int)(m_szConfigures[CID_TXBUFFER_NUMBER]); i++)
		{
			
			m_Xmitdesc[i].addr = TabAddr + i * TX_BUFFER_SIZE;
//			RETAILMSG(1, (L"Desc addr 0x%08x\r\n", &(m_Xmitdesc[i])));
			m_Xmitdesc[i].ctrl = EMAC_TX_BIT_USED;
//			RETAILMSG(1, (L"addr m_Xmitdesc[i].ctrl 0x%08x\r\n", &(m_Xmitdesc[i].ctrl)));
			ASSERT((m_Xmitdesc[i].addr & 0x3) == 0);//Address must be 4-byte aligned
		}
		m_Xmitdesc[m_szConfigures[CID_TXBUFFER_NUMBER] - 1].ctrl |= EMAC_TX_BIT_WRAP;
		m_pEmac->EMAC_TBQP = m_pUpper->m_PhysAddrTxDesc;
		

		// RX Buffer
//		RETAILMSG(1,(TEXT("Init RX Buffer\r\n")));
		m_ReceiveDesc = (DMA_DESC *)(m_pUpper->m_VirtAddrRxBuffer);
		m_VirtAddrRxDesc = m_pUpper->m_VirtAddrRxBuffer;	
		m_VirtAddrRxData = (UCHAR *)(m_pUpper->m_VirtAddrRxBuffer) + m_szConfigures[CID_RXBUFFER_NUMBER] * RX_DESC_SIZE;
		
		TabAddr = m_pUpper->m_PhysAddrRxBuffer + m_szConfigures[CID_RXBUFFER_NUMBER] * RX_DESC_SIZE;
		for(int i=0; i<(int)(m_szConfigures[CID_RXBUFFER_NUMBER]); i++)
		{
			m_ReceiveDesc[i].addr = TabAddr + i * RX_BUFFER_SIZE;
			ASSERT((m_ReceiveDesc[i].addr & 0x3) == 0);//Address must be 4-byte aligned
		}
		m_ReceiveDesc[m_szConfigures[CID_RXBUFFER_NUMBER] - 1].addr |= EMAC_RX_BIT_WRAP;
		
		m_pEmac->EMAC_RBQP = m_pUpper->m_PhysAddrRxBuffer;
	}
		
//		RETAILMSG(1, (L"<--EDeviceInitialize\r\n"));
}

//------------------------------------------------------------------------------
//! \fn void C_EMACB::DeviceResetPHYceiver(void)
//! \brief	Not implemented
//------------------------------------------------------------------------------
void	C_EMACB::DeviceResetPHYceiver(void)
{

}

#ifdef	IMPL_DEVICE_ISR
//------------------------------------------------------------------------------
//! \fn void C_EMACB::DeviceIsr(U32 uState)
//! \brief	Device handler routines
//------------------------------------------------------------------------------
void	C_EMACB::DeviceIsr(
	U32		uState)
{
}
#endif

#ifdef	IMPL_STORE_AND_INDICATION
void	C_EMACB::DeviceOnTimer(void)
{
	int	val = m_RQStandby.Size();
	
	PCQUEUE_GEN_HEADER	pcurr;
	
	for(;(pcurr=m_RQStandby.Dequeue());m_RQueue.Enqueue(pcurr))
	{
		DeviceReceiveIndication(
			0,CQueueGetUserPointer(pcurr),pcurr->nLength);
		
	} // of for RQStandby loop
	
}
#endif

//------------------------------------------------------------------------------
//! \fn C_EMACB::DeviceOnSetupFilter(U32 uFilter)
//! \brief     Not implemented
//! 
//! \param uFilter		Not used       
//!
//! \return		Always 0
//------------------------------------------------------------------------------
int	C_EMACB::DeviceOnSetupFilter(
	U32		uFilter)
{
	return 0;
}

//------------------------------------------------------------------------------
//! \fn void C_EMACB::DeviceInterruptEventHandler(U32 uValue)
//! \brief     The interrupt event Handler
//! 
//! \param uValue       Value of the interrupt status
//!
//! This function do correct action coresponding to the interrupt source
//!
//------------------------------------------------------------------------------
void C_EMACB::DeviceInterruptEventHandler(
										  U32	uValue)
{
	DWORD XmitStatus, RcvStatus;
	PCQUEUE_GEN_HEADER	pcurr;
	
	if(m_Cable == TRUE)
	{
		XmitStatus = m_pEmac->EMAC_TSR;
		RcvStatus = m_pEmac->EMAC_RSR;
		if(uValue & AT91C_EMAC_ROVR)
		{
			RETAILMSG(1, (L"%d IT ROVR\r\n", GetTickCount()));
		}
		if((uValue & AT91C_EMAC_HRESP))
		{
			RETAILMSG(1, (L"%d IT HRESP but not COMP\r\n", GetTickCount()));
		}
		
		if(uValue & AT91C_EMAC_PFRE)
		{
			RETAILMSG(1, (L"%d IT PFRE\r\n", GetTickCount()));
		}
		
		if(uValue & AT91C_EMAC_PTZ)
		{
			RETAILMSG(1, (L"%d IT PTZ\r\n", GetTickCount()));
		}
		
		if(uValue & AT91C_EMAC_TXERR)
		{
			RETAILMSG(1, (L"%d IT TXERR\r\n", GetTickCount()));
		}
		if(uValue & AT91C_EMAC_RLEX)
		{
			RETAILMSG(1, (L"%d IT RELX\r\n", GetTickCount()));
		}
		if((uValue & AT91C_EMAC_TUNDR))
		{
			RETAILMSG(1, (L"%d IT TUND\r\n", GetTickCount()));
		}
		if(uValue & AT91C_EMAC_RXUBR)
		{
			RETAILMSG(1, (L"%d IT RXUBR\r\n", GetTickCount()));
		}
		if(uValue & AT91C_EMAC_TXUBR)
		{
			//RETAILMSG(1, (L"%d IT TXUBR\r\n", GetTickCount()));
		}
		if(uValue & AT91C_EMAC_MFD)
		{
			RETAILMSG(1, (L"%d IT MFD\r\n", GetTickCount()));
		}
		
		if(uValue & AT91C_EMAC_RCOMP) 
		{
//			RETAILMSG(1,(L"IT RCOMP\r\n"));
			if((uValue & AT91C_EMAC_ROVR) || (RcvStatus & AT91C_EMAC_OVR))
			{
				RETAILMSG(1, (L"Error Overrun\r\n"));
				m_pEmac->EMAC_RSR = AT91C_EMAC_OVR;
			}
			if(RcvStatus & AT91C_EMAC_BNA)
			{
				RETAILMSG(1, (L"LookupRxBuffers : Error BNA!!\r\n"));
				m_pEmac->EMAC_NCR &= ~AT91C_EMAC_RE;
				LookupRxBuffers();
				m_pEmac->EMAC_RSR = AT91C_EMAC_BNA;
				m_pEmac->EMAC_NCR |= AT91C_EMAC_RE;
				m_LastRxEOFBuffer = 0;
				ReleaseBuffer(0,m_szConfigures[CID_RXBUFFER_NUMBER] - 1);
			}
			else if(RcvStatus & AT91C_EMAC_REC)
			{
				LookupRxBuffers();
			}
		}
		
		// EMAC interruption for transmission complete
		if(uValue & AT91C_EMAC_TCOMP)
		{
			//RETAILMSG(1,(L"IT TCOMP \r\n"));			
			// If COMP STATUS bit in transmit status register is set 
			if (XmitStatus & AT91C_EMAC_COMP)
			{
				m_pEmac->EMAC_TSR = AT91C_EMAC_COMP;
			}
			// If UND STATUS bit in transmis status register is set
			if (XmitStatus & AT91C_EMAC_UND)
			{
				// UNDERRUN treatment 
				RETAILMSG(1,(L"UND\r\n"));
				// reset UNDERRUN STATUS bit
				m_pEmac->EMAC_TSR = AT91C_EMAC_UND;

				m_mutexTxValidate.Lock();
				DWORD ctrl, SizeTQ;
				SizeTQ = m_TQWaiting.Size();

				// Dequeue all descriptors in Waiting queue
				while (pcurr = m_TQWaiting.Dequeue())
				{
					
					ctrl = ((DMA_DESC*)(pcurr->pvVirtAddrDesc))->ctrl;
					m_mutexTxValidate.Release();					
					
					// If UND bit in descriptor is set 
					if(ctrl & EMAC_TX_BIT_UND)
					{
						// indicate FAILURE to NDIS layer
						DeviceSendCompleted(pcurr, NDIS_STATUS_FAILURE);
					}
					// If BIT USED is set in the descriptor
					else if(ctrl & EMAC_TX_BIT_USED)
					{
						// indicate SUCESS to NDIS layer
						DeviceSendCompleted(pcurr, NDIS_STATUS_SUCCESS);
					}
					else
					{
						// indicate FAILURE to NDIS layer
						DeviceSendCompleted(pcurr, NDIS_STATUS_FAILURE);
					}
					
					m_mutexTxValidate.Lock();
				}

				// TBQP is reset when an UNDERRUN occur -> synchronization of the waiting queue and the TBQP
				while (m_pUpper->m_TQueue.GetHead()->dwPhysAddrDesc != m_pEmac->EMAC_TBQP)
				{
					m_pUpper->m_TQueue.Enqueue(m_pUpper->m_TQueue.Dequeue());
				}

				// Set all bit used
				for (DWORD m=0; m<m_szConfigures[CID_TXBUFFER_NUMBER] ; m++)
				{	
					m_Xmitdesc[m].ctrl |= EMAC_TX_BIT_USED;
			}

				m_mutexTxValidate.Release();
				m_pEmac->EMAC_TUND = 0;
				// Start transmission
				m_pEmac->EMAC_NCR |= AT91C_EMAC_TSTART;

			}
			// If complete occur without UNDERRUN
			else
			{
			m_mutexTxValidate.Lock();
			DWORD ctrl;
				// While a descriptor is in the queue
				while (pcurr = m_TQWaiting.GetHead())
			{

				ctrl = ((DMA_DESC*)(pcurr->pvVirtAddrDesc))->ctrl;
				m_mutexTxValidate.Release();
					// If the Bit Used of the descriptor is set
				if(ctrl & EMAC_TX_BIT_USED)
				{
						// This descriptor is dequeue
					m_TQWaiting.Dequeue();
						// The transfert is complete -> indicate to the NDIS layer that the transmission is complete
					DeviceSendCompleted(pcurr, NDIS_STATUS_SUCCESS);
				}
					// If the bit used is not set, the TCOMP is not for a start of frame -> end TCOMP test
				else
				{

					break;
				}
				m_mutexTxValidate.Lock();
			}
			m_mutexTxValidate.Release();
			DeviceSend(NULL);		
		}
	}
	}
}

//------------------------------------------------------------------------------
//! \fn U32	C_EMACB::DeviceHardwareStatus(void)
//! \brief     Not implemented
//! 
//! \return		Always 0
//------------------------------------------------------------------------------
U32	C_EMACB::DeviceHardwareStatus(void)
{
	return 0;
}


//------------------------------------------------------------------------------
//! \fn void DumpEtherFrame( BYTE *pFrame, WORD cwFrameLength )
//! \brief     This function dump a frame to the debug output
//! 
//! \param pFrame         The frame to decode
//!
//! \param cwFrameLength  The frame length
//------------------------------------------------------------------------------
void DumpEtherFrame( BYTE *pFrame, WORD cwFrameLength )
{
    int i;

    RETAILMSG(1,( L"Frame Buffer Address: 0x%x\r\n", pFrame ));
    RETAILMSG(1,( L"To: %x:%x:%x:%x:%x:%x  From: %x:%x:%x:%x:%x:%x  Type: 0x%x  Length: %u\r\n",
        pFrame[0], pFrame[1], pFrame[2], pFrame[3], pFrame[4], pFrame[5],
        pFrame[6], pFrame[7], pFrame[8], pFrame[9], pFrame[10], pFrame[11],
        ntohs(*((UINT16 *)(pFrame + 12))), cwFrameLength ));

	for( i = 0; i < cwFrameLength % 16; i++ )
	{
		  RETAILMSG(1,( L" %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x\r\n", 
			pFrame[i*16 + 0], pFrame[i*16 + 1], pFrame[i*16 + 2], pFrame[i*16 + 3], 
			pFrame[i*16 + 4], pFrame[i*16 + 5], pFrame[i*16 + 6], pFrame[i*16 + 7],
			pFrame[i*16 + 8], pFrame[i*16 + 9], pFrame[i*16 + 10], pFrame[i*16 + 11],
			pFrame[i*16 + 12], pFrame[i*16 + 13], pFrame[i*16 + 14], pFrame[i*16 + 15]));
	}
    RETAILMSG(1,( L"\r\n" ));
}
				
//------------------------------------------------------------------------------
//! \fn int	C_EMACB::DeviceSend(PCQUEUE_GEN_HEADER pObject)
//! \brief     Send a frame
//! 
//! \param pObject       
//!
//! \return		Always 0
//!
//! This function test if cable is attached, and then try to send the frame
//!
//------------------------------------------------------------------------------
int	C_EMACB::DeviceSend(
	PCQUEUE_GEN_HEADER	pObject)
{
//	RETAILMSG(1, (L"-->DeviceSend\r\n"));
	
	if(m_Cable == TRUE)
	{
		if(pObject) 
		{
			m_mutexTxValidate.Lock();
			m_TQWaiting.Enqueue(pObject);
			((DMA_DESC*)(pObject->pvVirtAddrDesc))->ctrl = (((DMA_DESC*)(pObject->pvVirtAddrDesc))->ctrl & EMAC_TX_BIT_WRAP) | (pObject->nLength &0x7ff) | (EMAC_BIT_EOF);
			m_mutexTxValidate.Release();
		}
		m_pEmac->EMAC_NCR |= AT91C_EMAC_TSTART;			
	}
	
	return 0;
}

//------------------------------------------------------------------------------
//! \fn int	C_EMACB::LookupRxBuffers(void)
//! \brief		Search and signal all received frame
//!
//! \return		TRUE if there are frame arrived
//!
//! This function take all received buffer and search if there are some frame
//! completely arrived. All complete frame are indicate with IndicateFrame() function
//! and the buffer are release.
//!
//------------------------------------------------------------------------------
int	C_EMACB::LookupRxBuffers(void)
{
//	RETAILMSG(1, (L"LookupRxBuffers\r\n\r\n"));
	if(!m_mutexRxValidate.TryLock()) return 0;
	
	DWORD	begin = -1;
	DWORD	end = -1;
	BOOL	bRet = FALSE;
	
	// Erase status value
	m_pEmac->EMAC_RSR = AT91C_EMAC_REC;
	
	do
	{
		// Find a frame
		bRet = FindFrame(&begin, &end);

		if (bRet)
		{
			//				RETAILMSG(1, (L"LookupRxBuffers : FrameFound begin %d end %d\r\n", begin, end));
			IndicateFrame( begin, end);
			ReleaseBuffer( m_LastRxEOFBuffer, end);
			m_LastRxEOFBuffer = (end + 1) % m_szConfigures[CID_RXBUFFER_NUMBER];
		}
		if((begin == -1) && (end != -1))
		{
			//			RETAILMSG(1, (L"Begin = -1\r\n"));
			m_LastRxEOFBuffer = 0;
			ReleaseBuffer(0, m_szConfigures[CID_RXBUFFER_NUMBER] - 1);
			bRet = FALSE;
			m_pEmac->EMAC_RBQP = m_pUpper->m_PhysAddrRxBuffer;
		}
		
	}
	while (bRet);

	m_mutexRxValidate.Release();
	
	return TRUE;
}

//------------------------------------------------------------------------------
//! \fn BOOL C_EMACB::FindFrame(DWORD * pSof, DWORD * pEof)
//! \brief   Find all recevied frame available in buffer.
//! 
//! \param pSof       Buffer id on start of the frame find
//!
//! \param pEof       Buffer id on end of the frame find
//!
//! \return		TRUE if there is a complete frame, FALSE else
//------------------------------------------------------------------------------
BOOL C_EMACB::FindFrame(DWORD * pSof, DWORD * pEof)
{
	DWORD	i, cnt = 0;
	*pSof = -1;
	*pEof = -1;

	i = m_LastRxEOFBuffer;

	while( (*pEof == -1) && (cnt < m_szConfigures[CID_RXBUFFER_NUMBER]) && (m_ReceiveDesc[i].addr & EMAC_RX_BIT_USED))
	{
		if(m_ReceiveDesc[i].ctrl & EMAC_BIT_SOF)
		{
			*pSof = i;
		}
		
		if(m_ReceiveDesc[i].ctrl & EMAC_BIT_EOF)
		{
			if(*pSof != -1)
			{
				*pEof = i;
			}
		}
		i = ((i + 1) % m_szConfigures[CID_RXBUFFER_NUMBER]);
		cnt++;
	}

	if(*pEof != -1)
	{
		return	TRUE;
	}
	else
	{
		return	FALSE;
	}
}

//------------------------------------------------------------------------------
//! \fn void C_EMACB::ReleaseBuffer(DWORD begin, DWORD end)
//! \brief     Release the specifier buffer
//! 
//! \param begin	Buffer ID of frame start to release
//!
//! \param end		Buffer ID of frame end to release 
//------------------------------------------------------------------------------
void C_EMACB::ReleaseBuffer(DWORD begin, DWORD end)
{
	DWORD i;
	for (i=begin;i!=end;i = (i + 1) % m_szConfigures[CID_RXBUFFER_NUMBER])
	{
		m_ReceiveDesc[i].addr &= ~EMAC_RX_BIT_USED;
	}
	m_ReceiveDesc[end].addr &= ~EMAC_RX_BIT_USED;
}

//------------------------------------------------------------------------------
//! \fn void C_EMACB::IndicateFrame(DWORD begin, DWORD end)
//! \brief     Copy the complete received frame to the upper layer memory
//! 
//! \param begin	Buffer ID of the buffer start
//!
//! \param end		Buffer ID of the buffer end
//------------------------------------------------------------------------------
void C_EMACB::IndicateFrame(DWORD begin, DWORD end)
{
	DWORD	j = 0;
	DWORD	i = begin;
	U8		Buffer[ETH_MAX_FRAME_SIZE];
	DWORD	dwPacketLength = m_ReceiveDesc[end].ctrl & EMAC_FLENGTH;
	DWORD	dwNbBuffer = dwPacketLength % RX_BUFFER_SIZE;
	DWORD	dwRxCopied = 0;
	DWORD	dwRxNotCopied = dwPacketLength;
	DWORD	dwSize;
	DWORD	dwIndex = begin;

	if (begin <= end)
	{
		DeviceReceiveIndication(
			0,
			(UCHAR*)(m_VirtAddrRxData) + begin * RX_BUFFER_SIZE,
			m_ReceiveDesc[end].ctrl & EMAC_FLENGTH);
	}
	else
	{
		while (dwRxNotCopied !=0)
		{
			if(dwRxNotCopied < RX_BUFFER_SIZE)
			{
				dwSize = dwRxNotCopied;
			}
			else
			{
				dwSize = RX_BUFFER_SIZE;
			}
			memcpy(Buffer + dwRxCopied,
				(UCHAR*)(m_VirtAddrRxData) + dwIndex * RX_BUFFER_SIZE,
				dwSize);

			dwIndex = (dwIndex +1) % m_szConfigures[CID_RXBUFFER_NUMBER];
			dwRxCopied +=dwSize;
			dwRxNotCopied -=dwSize;
		}

		DeviceReceiveIndication(0,
			(PVOID)Buffer,
			m_ReceiveDesc[end].ctrl & EMAC_FLENGTH);
	}

}


/**********************************************************************
 *
 *	Phy configuration
 *
 ***********************************************************************/


//------------------------------------------------------------------------------
//! \fn BOOL C_EMACB::PHY_Reset()
//! \brief    Not implemented 
//!
//! \return		Always TRUE
//------------------------------------------------------------------------------
BOOL C_EMACB::PHY_Reset(void)
{
	return TRUE;
}

//------------------------------------------------------------------------------
//! \fn BOOL C_EMACB::PHY_StartAutoNegociation(void)
//! \brief     This function start the auto negociation by writing correct value in phy register
//! 
//! \return		Always TRUE
//------------------------------------------------------------------------------
BOOL C_EMACB::PHY_StartAutoNegociation(void)
{
	DeviceWritePhy(DM9161A_CONTROL_REG, 
		0,
		DM9161A_CONTROL_REG_AUTONEGOCIATION_ENABLE | DM9161A_CONTROL_REG_RESTART_AUTONEGOCIATION);
	return TRUE;
}

//------------------------------------------------------------------------------
//! \fn BOOL C_EMACB::PHY_WaitForLink(DWORD dwTimeout)
//! \brief  Wait the a link is established (with a max timeout value)
//! 
//! \param dwTimeout	Maximum time to wait for established link
//!
//! \return		TRUE if link is established, FALSE else
//------------------------------------------------------------------------------
BOOL C_EMACB::PHY_WaitForLink(DWORD dwTimeout)
{
	DWORD dwValue;
	DWORD dwEndOfWait = GetTickCount() + dwTimeout;	
	do
	{
		// Link status is latched, so read twice to get current value 
		dwValue = DeviceReadPhy(DM9161A_STATUS_REG, 0);
		dwValue = DeviceReadPhy(DM9161A_STATUS_REG, 0);
		if (dwValue & DM9161A_STATUS_REG_LINK)
		{
			break;
		}
	}
	while (GetTickCount() < dwEndOfWait);

	if ((dwValue & DM9161A_STATUS_REG_LINK)==0)
	{
		return FALSE;
	}

	return TRUE;
}

//------------------------------------------------------------------------------
//! \fn BOOL C_EMACB::PHY_WaitForAutonegociationComplete(DWORD dwTimeout)
//! \brief     Wait for autonegociation completed (with a max timeout value)
//! 
//! \param dwTimeout Maximum time to wait for auto neg process
//!
//! \return		TRUE if auto neg complete, FALSE else
//------------------------------------------------------------------------------
BOOL C_EMACB::PHY_WaitForAutonegociationComplete(DWORD dwTimeout)
{

	U32 dwValue;
	DWORD dwEndOfWait = GetTickCount() + dwTimeout;	
	do
	{
		// Link status is latched, so read twice to get current value 
		dwValue = DeviceReadPhy(DM9161A_STATUS_REG, 0);
		dwValue = DeviceReadPhy(DM9161A_STATUS_REG, 0);
		Sleep(500);
		if (dwValue & DM9161A_STATUS_REG_AUTONEGOCIATION_COMPLETE)
		{
			break;
		}
	}
	while (GetTickCount() < dwEndOfWait);

	if ((dwValue & DM9161A_STATUS_REG_AUTONEGOCIATION_COMPLETE)==0)
	{		
		RETAILMSG(1, (L"PHY_WaitForAutonegociationComplete Autoneg not complete\r\n"));
		return FALSE;
	}
	
	return TRUE;
}

//------------------------------------------------------------------------------
//! \fn BOOL C_EMACB::PHY_GetID(DWORD* pdwID)
//! \brief     Function permtting to retreive the PHY ID
//! 
//! \param pdwID       The phy id find
//!
//! \return		TRUE if an id find, FALSE else
//------------------------------------------------------------------------------
BOOL C_EMACB::PHY_GetID(DWORD* pdwID)
{
	DWORD dwID,dwValue;
	dwValue = DeviceReadPhy(DM9161A_ID1_REG,0);
	dwID = dwValue << 16;
	
	dwValue = 0;
	dwValue = DeviceReadPhy(DM9161A_ID2_REG,0);
	dwID |= dwValue;	

	if (pdwID)
	{
		*pdwID = dwID;
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

//------------------------------------------------------------------------------
//! \fn BOOL C_EMACB::PHY_CheckID(void)
//! \brief     Check if ID retreive by PHY_GetID() is correct
//!
//! \return		TRUE if ID is correct, FALSE else
//------------------------------------------------------------------------------
BOOL C_EMACB::PHY_CheckID(void)
{
	#define ID_MASK	0xFFFFF800

	DWORD dwID,dwID2;
	int i =0;
	PHY_GetID(&dwID);
	PHY_GetID(&dwID2);
	
	for(i=0;i<200 && dwID==dwID2;i++)
		PHY_GetID(&dwID);
	
	if(dwID!=dwID2)
		 RETAILMSG(1,(TEXT("PHY ID instable 1: %d, 2: %d.\r\n"),dwID,dwID2));
	else
		RETAILMSG(1,(TEXT("PHY ID : %d\r\n"),dwID));
	PHY_GetID(&dwID);

	if ((dwID & ID_MASK) != (MII_DM9161A_ID & ID_MASK))
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

//------------------------------------------------------------------------------
//! \fn BOOL C_EMACB::PHY_SetConfiguration()
//! \brief      Not implemented
//! 
//! \return		Always TRUE
//------------------------------------------------------------------------------
BOOL C_EMACB::PHY_SetConfiguration(void)
{	
	return TRUE;
}

//------------------------------------------------------------------------------
//! \fn BOOL C_EMACB::PhyConfiguration(void)
//! \brief		Configure the PHY
//! 
//! \return		TRUE if PHY correctly configured, FALSE else
//------------------------------------------------------------------------------
BOOL C_EMACB::PhyConfiguration(void)
{
	BOOL	bRet = TRUE;
	
	m_pEmac->EMAC_NCR |= AT91C_EMAC_MPE;	// enable management port
	m_pEmac->EMAC_IER = AT91C_EMAC_MFD;
	
	m_PhyCfg.bAutoNegociation = FALSE;
	FindPhy();

	if(PHY_GetConfiguration() == FALSE)
	{
		if (m_PhyCfg.bAutoNegociation == TRUE) 
		{
			// Autonegociation is started but not complete yet
		}
		else
		{	 // Autonegocitaion is not selected
			PHY_StartAutoNegociation();
		}
		
		Sleep(1000);
			
		if (PHY_WaitForAutonegociationComplete(GET_LINK_SPEED_TIMEOUT) == FALSE)
		{
			RETAILMSG(1,(TEXT("Autonegociation failed\r\n")));
			bRet = FALSE;
		}
	}

	if(bRet == TRUE)
	{
		if (PHY_WaitForLink(GET_LINK_SPEED_TIMEOUT) == FALSE)
		{
			RETAILMSG(1,(TEXT("No Link\r\n")));
		}
			
		if(PHY_GetConfiguration() == FALSE)
		{
			RETAILMSG(1,(TEXT("Unable to get the network configuration from the PHY\r\n")));
		}
			
		m_bPhyConfigured = TRUE;
		RETAILMSG(1,(TEXT("\n\r EMAC Init : %d Mbit/s %s DUPLEX (%s)\r\n"), m_PhyCfg.dwSpeed, m_PhyCfg.bFullDuplex ? L"FULL" : L"HALF", m_PhyCfg.bRMII ? L"RMII" : L"MII"));
	}

	m_pEmac->EMAC_NCR &= ~AT91C_EMAC_MPE;
	return bRet;

}

//------------------------------------------------------------------------------
//! \fn BOOL C_EMACB::PHY_GetConfiguration(void)
//! \brief		Get the PHY configuration and set it into m_PhyCfg variable
//!
//! \return		TRUE if all it's clear, FALSE if phy not configured
//------------------------------------------------------------------------------
BOOL C_EMACB::PHY_GetConfiguration(void)
{

	U32 dwCtrlReg;
	U32 dwStatusReg;
	U32 dwLinkPartnerReg;
	U32 dwDavicomSpecifiedConfReg;

	dwCtrlReg = DeviceReadPhy(DM9161A_CONTROL_REG, 0);
	dwStatusReg = DeviceReadPhy(DM9161A_STATUS_REG, 0);
	dwStatusReg = DeviceReadPhy(DM9161A_STATUS_REG, 0);

//	RETAILMSG(1, (L"CtrlReg %x StatusReg %x\r\n", dwCtrlReg, dwStatusReg)); 

	if (dwCtrlReg & DM9161A_CONTROL_REG_AUTONEGOCIATION_ENABLE) 
	{	
		m_PhyCfg.bAutoNegociation = TRUE;	
		
				// AutoNegotiation is enabled 
		if (!(dwStatusReg & DM9161A_STATUS_REG_AUTONEGOCIATION_COMPLETE)) 
		{
			RETAILMSG(1, (L"PHY_GetConfiguration : autoneg not complete\r\n"));
			return FALSE;		// auto-negotitation in progress 
		}

		dwLinkPartnerReg = DeviceReadPhy(DM9161A_LINK_PARTNER_REG, 0);
		if ((dwLinkPartnerReg & DM9161A_LINK_PARTNER_100FULL) || (dwLinkPartnerReg & DM9161A_LINK_PARTNER_100HALF)) 
		{
			m_PhyCfg.dwSpeed  = SPEED_100;
		}
		else 
		{
			m_PhyCfg.dwSpeed = SPEED_10;
		}
		
		if ((dwLinkPartnerReg & DM9161A_LINK_PARTNER_100FULL) || (dwLinkPartnerReg & DM9161A_LINK_PARTNER_10FULL)) 
		{
			m_PhyCfg.bFullDuplex = TRUE;
		}		
		else
		{
			m_PhyCfg.bFullDuplex = FALSE;
		}		
	} 
	else 
	{
		m_PhyCfg.bAutoNegociation = FALSE;
		if (dwCtrlReg & DM9161A_CONTROL_REG_SPEED_SELECT)
		{
			m_PhyCfg.dwSpeed = SPEED_100;
		}
		else
		{	
			m_PhyCfg.dwSpeed = SPEED_10;
		}
		if (dwCtrlReg & DM9161A_CONTROL_REG_FULL_DUPLEX)
		{
			m_PhyCfg.bFullDuplex = TRUE;
		}
		else
		{
			m_PhyCfg.bFullDuplex = FALSE;
		}
	}

	dwDavicomSpecifiedConfReg = DeviceReadPhy(DM9161A_DAVICOM_SPEC_CONF_REG, 0);
		
	if (dwDavicomSpecifiedConfReg & DM9161A_DAVICOM_SPEC_CONF_RMII_ENABLED)
	{
		m_PhyCfg.bRMII = TRUE;		
	}
	else
	{
		m_PhyCfg.bRMII = FALSE;
	}

	return TRUE;
}

//------------------------------------------------------------------------------
//! \fn void C_EMACB::FindPhy(void)
//! \brief		Find the phy and set it into m_ucPhyAddr
//------------------------------------------------------------------------------
void C_EMACB::FindPhy(void)
{
	#define MAX_PHY_ADDRESS		16
		
	for (m_ucPhyAddr=0;m_ucPhyAddr<MAX_PHY_ADDRESS;(m_ucPhyAddr)++)
	{
		if (PHY_CheckID())
		{
			// RETAILMSG(1,(L"Phy found addr %d\r\n", m_ucPhyAddr));
			break;
		}
	}
}

//! @}
//! @}
