//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x/INC/LCDC/ddgpeusr.h
//!
//! \brief		Some useful defines 
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/LCDC/ddgpeusr.h $
//!   $Author: pblanchard $
//!   $Revision: 993 $
//!   $Date: 2007-06-12 08:36:50 -0700 (Tue, 12 Jun 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	LCDC
//! @{
//!
#ifndef __GPEDDHALUSER_H__
#define __GPEDDHALUSER_H__

//! \addtogroup	DirectDraw
//! @{

// some macros to help in debugging

#define DEBUGENTER(func)                                                        \
{                                                                               \
    DEBUGMSG(GPE_ZONE_ENTER,(TEXT("Entering function %s\r\n"),TEXT(#func)));    \
}

#define DEBUGLEAVE(func)                                                        \
{                                                                               \
    DEBUGMSG(GPE_ZONE_ENTER,(TEXT("Leaving function %s\r\n"),TEXT( #func )));   \
}


// HARDWARE-SPECIFIC Required #defines
#define IN_VBLANK   ( ((DDGPE *)g_pGPE)->InVBlank() )
#define IS_BUSY     ( ((DDGPE *)g_pGPE)->IsBusy()   )

#endif //__GPEDDHALUSER_H__

//! @}

//! @}


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/LCDC/ddgpeusr.h $
////////////////////////////////////////////////////////////////////////////////
//
//! @}
