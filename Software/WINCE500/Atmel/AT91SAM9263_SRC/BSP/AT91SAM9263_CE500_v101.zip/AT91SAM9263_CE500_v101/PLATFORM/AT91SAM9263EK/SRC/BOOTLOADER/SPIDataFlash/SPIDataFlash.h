//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!  
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9263EK/SRC/BOOTLOADER/SPIDataFlash/SPIDataFlash.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/BOOTLOADER/SPIDataFlash/SPIDataFlash.h $
//!   $Author: amlimonet $
//!   $Revision: 889 $
//!   $Date: 2007-05-28 10:42:57 +0200 (lun., 28 mai 2007) $
//! \endif
//!
//! Header for SPIDataFlash Library
//-----------------------------------------------------------------------------
//! \addtogroup	SPI_DataFlash
//! @{
//!

#ifndef __SPIDATAFLASH_H__
#define __SPIDATAFLASH_H__


//----------------------------------------------------------------------
// Defines					
//----------------------------------------------------------------------
#define AT45DB161		0x2c //status : 1011xx
#define AT45DB321		0x34 //status : 1101xx
#define AT45DB642		0x3c //status : 1111xx
#define AT45DB128		0x10 //status : 1000xx

#define AT91C_DATAFLASH_TIMEOUT			2000	// For AT91F_DataFlashWaitReady in ms

// DataFlash return value
#define AT91C_DATAFLASH_BUSY			0x00
#define AT91C_DATAFLASH_OK				0x01
#define AT91C_DATAFLASH_ERROR			0x02
#define AT91C_DATAFLASH_MEMORY_OVERFLOW	0x03
#define AT91C_DATAFLASH_BAD_COMMAND		0x04
#define AT91C_DATAFLASH_BAD_ADDRESS		0x05

// Driver State
#define IDLE		0x0
#define BUSY		0x1

// DataFlash Driver State
#define GET_STATUS	0x0F

#define AT91C_SPI_CLK 10000000  //Hz
#define AT91C_SPI_PCS0_SERIAL_DATAFLASH		0xE     // Chip Select 0 : NPCS0 %1110
#define AT91C_SPI_PCS1_SERIAL_DATAFLASH		0xD     // Chip Select 0 : NPCS1 %1101
#define CFG_DATAFLASH_LOGIC_ADDR_CS0	0xC0000000
#define CFG_DATAFLASH_LOGIC_ADDR_CS1	0xD0000000


//-------------------------------------------------------------------------------------------------
// Command Definition										   
//-------------------------------------------------------------------------------------------------

// READ COMMANDS
#define DB_CONTINUOUS_ARRAY_READ	0xE8	// Continuous array read
#define DB_BURST_ARRAY_READ			0xE8	// Burst array read
#define DB_PAGE_READ				0xD2	// Main memory page read
#define DB_BUF1_READ				0xD4	// Buffer 1 read
#define DB_BUF2_READ				0xD6	// Buffer 2 read
#define DB_STATUS					0xD7	// Status Register

// PROGRAM and ERASE COMMANDS
#define DB_BUF1_WRITE				0x84	// Buffer 1 write
#define DB_BUF2_WRITE				0x87	// Buffer 2 write
#define DB_BUF1_PAGE_ERASE_PGM		0x83	// Buffer 1 to main memory page program with built-In erase
#define DB_BUF1_PAGE_ERASE_FASTPGM	0x93	// Buffer 1 to main memory page program with built-In erase, Fast program
#define DB_BUF2_PAGE_ERASE_PGM		0x86	// Buffer 2 to main memory page program with built-In erase
#define DB_BUF2_PAGE_ERASE_FASTPGM	0x96	// Buffer 1 to main memory page program with built-In erase, Fast program
#define DB_BUF1_PAGE_PGM			0x88	// Buffer 1 to main memory page program without built-In erase
#define DB_BUF1_PAGE_FASTPGM		0x98	// Buffer 1 to main memory page program without built-In erase, Fast program
#define DB_BUF2_PAGE_PGM			0x89	// Buffer 2 to main memory page program without built-In erase
#define DB_BUF2_PAGE_FASTPGM		0x99	// Buffer 1 to main memory page program without built-In erase, Fast program
#define DB_PAGE_ERASE				0x81	// Page Erase
#define DB_BLOCK_ERASE				0x50	// Block Erase
#define DB_PAGE_PGM_BUF1			0x82	// Main memory page through buffer 1
#define DB_PAGE_FASTPGM_BUF1		0x92	// Main memory page through buffer 1, Fast program
#define DB_PAGE_PGM_BUF2			0x85	// Main memory page through buffer 2
#define DB_PAGE_FastPGM_BUF2		0x95	// Main memory page through buffer 2, Fast program

// ADDITIONAL COMMANDS
#define DB_PAGE_2_BUF1_TRF			0x53	// Main memory page to buffer 1 transfert
#define DB_PAGE_2_BUF2_TRF			0x55	// Main memory page to buffer 2 transfert
#define DB_PAGE_2_BUF1_CMP			0x60	// Main memory page to buffer 1 compare
#define DB_PAGE_2_BUF2_CMP			0x61	// Main memory page to buffer 2 compare
#define DB_AUTO_PAGE_PGM_BUF1		0x58	// Auto page rewrite throught buffer 1
#define DB_AUTO_PAGE_PGM_BUF2		0x59	// Auto page rewrite throught buffer 2

//----------------------------------------------------------------------
// DataFlash Structures	& Types						
//----------------------------------------------------------------------

typedef unsigned int AT91S_DataFlashStatus;


/*! \brief DataFlash Descriptor Structure Definition
*/
typedef struct _AT91S_DataflashDesc {
	unsigned char 			*tx_cmd_pt;     //!<Pointer to the transmit command buffer
	unsigned int 			tx_cmd_size;    //!<Command buffer size
	unsigned char 			*rx_cmd_pt;     //!<Pointer to the receive command buffer
	unsigned int 			rx_cmd_size;    //!<Command buffer size
	unsigned char 			*tx_data_pt;    //!<Pointer to the transmit data buffer
	unsigned int 			tx_data_size;   //!<Data buffer size
	unsigned char 			*rx_data_pt;    //!<Pointer to the receive data buffer
	unsigned int 			rx_data_size;   //!<Data buffer size
	volatile unsigned char 	state;          //!<Status of the driver
	volatile unsigned char 	DataFlash_state;//!<Status of the Data Flash
	unsigned char 			command[8];     //!<Command buffer
} AT91S_DataflashDesc, *AT91PS_DataflashDesc;


/*! \brief  DataFlash Device Definition
*/     
typedef struct _AT91S_DataflashFeatures {
	int pages_number;			//!<dataflash page number
	int pages_size;				//!<dataflash page size
	int page_offset;			//!<page offset in command
	int byte_mask;				//!<byte mask in command
} AT91S_DataflashFeatures, *AT91PS_DataflashFeatures;


/*! \brief  DataFlash Structure Definition
*/  
typedef struct _AT91S_DataFlash {
	AT91PS_DataflashDesc pDataFlashDesc;	//!<Pointer on a dataflash descriptor
	AT91PS_DataflashFeatures pDevice;		//!<Pointer on a dataflash features array
} AT91S_DataFlash, *AT91PS_DataFlash;

/*! \brief  DataFlash Info Definition
*/  
typedef struct _AT91S_DATAFLASH_INFO {

	AT91S_DataflashDesc 	Desc;               //!<Pointer on a DataFlash Descriptor Structure
	AT91S_DataflashFeatures Device;				//!<Pointer on a DataFlash Device Structure
	unsigned long 			logical_address;    //!<Logical address of the data flash
	unsigned int 			id;					//!<Device id
} AT91S_DATAFLASH_INFO, *AT91PS_DATAFLASH_INFO;


//----------------------------------------------------------------------
// Prototypes					
//----------------------------------------------------------------------
int AT91F_DataflashInit(DWORD dwChipSelect);
void AT91F_DataflashPrintInfo(void);
int AT91F_MemoryDisplay(unsigned int addr, unsigned int size, unsigned int length);
int read_dataflash(unsigned long addr, unsigned long size, PVOID bufferOut);
int write_dataflash(unsigned long addr_dest, PVOID addr_src, unsigned int size);


//----------------------------------------------------------------------
// Globals					
//----------------------------------------------------------------------
AT91S_DATAFLASH_INFO gDataflashInfo;

#endif //__SPIDATAFLASH_H__

// End of Doxygen group DataFlash
//! @}

//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/BOOTLOADER/SPIDataFlash/SPIDataFlash.h $
//-----------------------------------------------------------------------------
