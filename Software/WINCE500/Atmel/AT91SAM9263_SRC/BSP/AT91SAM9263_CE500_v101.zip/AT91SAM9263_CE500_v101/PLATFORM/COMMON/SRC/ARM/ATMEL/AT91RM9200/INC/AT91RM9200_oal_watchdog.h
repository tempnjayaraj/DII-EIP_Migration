//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91RM9200_oal_watchdog.h
//!
//! \brief		watchdog management header file
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/INC/AT91RM9200_oal_watchdog.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//!
//-----------------------------------------------------------------------------

#ifndef AT91RM9200_OALWATCHDOG_H
#define AT91RM9200_OALWATCHDOG_H

#define DEFAULT_WATCHDOG_PERIOD	10000 //10s

DWORD OEMInitWatchDogTimer (DWORD dwWatchdogPeriod);

#endif /*AT91RM9200_OALWATCHDOG_H*/

//! @}
