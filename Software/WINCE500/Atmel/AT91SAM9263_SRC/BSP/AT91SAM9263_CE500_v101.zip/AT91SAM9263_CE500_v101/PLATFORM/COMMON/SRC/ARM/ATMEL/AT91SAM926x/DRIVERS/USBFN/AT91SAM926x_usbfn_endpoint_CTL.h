//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x_usbfn_endpoint_ctl.h
//!
//! \brief		declaration for the OUT endpoint
//! 
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/USBFN/AT91SAM926x_usbfn_endpoint_CTL.h $
//!   $Author: pblanchard $
//!   $Revision: 984 $
//!   $Date: 2007-06-11 09:19:22 -0700 (Mon, 11 Jun 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------
//! \addtogroup	USBFN
//! @{
//!
#include <csync.h>
#include <cmthread.h>
//#include <CRegEdit.h>
#include <CRefCon.h>
#include <usbfn.h>





#define EP0_MAX_PACKET_SIZE 0x8 

class AT91SAMEndpoint;

class AT91SAMEndpointCtrl : public AT91SAMEndpoint 
{
public:
    AT91SAMEndpointCtrl(AT91SAMUsbDevice * const pUsbDevice) 
        : AT91SAMEndpoint(pUsbDevice, 0) 
    {
		m_bIgnoreNextHandshakeFromMDD = TRUE;
    }
    BOOL Init(PUSB_ENDPOINT_DESCRIPTOR pEndpointDesc,
            BYTE bConfigurationValue, BYTE bInterfaceNumber, BYTE bAlternateSetting);   
//    virtual BOOL ReInit();
    //DWORD IssueTransfer(PSTransfer pTransfer );
    DWORD SendControlStatusHandshake(CtrlCallBackInfo* pCallBackInfo = NULL) ;
    DWORD   IST(DWORD dwIRBit);
	void SetAddressCompleted(DWORD dwParam);
	void SetConfigurationCompleted(DWORD dwParam);
protected:
    BOOL  ContinueTransfer();
private:    
};





AT91SAMUsbDevice * CreateAT91SAMUsbDevice(LPCTSTR lpActivePath);





//! @}
//! @}