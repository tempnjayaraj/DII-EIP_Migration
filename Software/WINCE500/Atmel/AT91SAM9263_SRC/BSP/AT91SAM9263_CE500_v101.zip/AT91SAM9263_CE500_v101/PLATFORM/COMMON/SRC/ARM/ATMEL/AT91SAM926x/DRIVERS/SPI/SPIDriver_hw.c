///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		SPIDriver_hw.c
//!
//! \brief This file implements the hardware dependent part of the SPI driver (it's platform independent)
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/SPI/SPIDriver_hw.c $
//!   $Author: pblanchard $
//!   $Revision: 984 $
//!   $Date: 2007-06-11 09:19:22 -0700 (Mon, 11 Jun 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	SPI
//! @{
//!

#include <windows.h>
#include <ceddk.h>
#include "at91sam926x.h"
#include "lib_at91sam926x.h"
#include "AT91SAM926x_spi.h"
#include "AT91SAM926x_spi_ioctl.h"
#include "spidriver.h"


//-----------------------------------------------------------------------------
//! \fn			BOOL setDevicePower(DWORD dwDevID,BOOL bPowerUp)
//!
//! \brief		This functions is used to turn on or off the SPI controller
//!
//! \param		dwDevID		
//! \param		bPowerUp	1 Enable, 0 Disable
//!
//! \return		\e TRUE indicates success.
//! \return		\e FALSE indicates failure.
//!
//!	This functions is used to turn on or off the SPI controller
//-----------------------------------------------------------------------------
BOOL setDevicePower(DWORD dwDevID,BOOL bPowerUp)
{
	PHYSICAL_ADDRESS PhysAddr;
	AT91PS_PMC pPMC;

	PhysAddr.LowPart = (DWORD) AT91C_BASE_PMC;
	PhysAddr.HighPart = 0;
	pPMC = (AT91PS_PMC) MmMapIoSpace(PhysAddr,sizeof(AT91S_PMC),FALSE);
	if (pPMC == NULL)
	{
		return FALSE;
	}

	if (bPowerUp)
	{
		pPMC->PMC_PCER = 1 << dwDevID;
	}
	else
	{
		pPMC->PMC_PCDR = 1 << dwDevID;
	}

	MmUnmapIoSpace(pPMC,sizeof(AT91S_PMC));

	return TRUE;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL HWSPIControllerInit(T_SPI_CONTROLLER_STRUCTURE* pSPICtrl)
//!
//! \brief		Initial configuration of the SPI controler
//!
//! \param		pSPICtrl	SPI Device		
//!
//! \return		\e TRUE indicates success.
//!	\return		\e FALSE indicates failure.
//!
//!	Initial configuration of the SPI controler
//-----------------------------------------------------------------------------
BOOL HWSPIControllerInit(T_SPI_CONTROLLER_STRUCTURE* pSPICtrl)
{
	// Power up the SPI controller
	if (setDevicePower(pSPICtrl->dwIDIRQ,TRUE) == FALSE)
	{
		return FALSE;
	}

	// Reset the SPI
	pSPICtrl->pSPI->SPI_CR = AT91C_SPI_SWRST;

	//disable PDC and initialize PDC SPI registers
	
	pSPICtrl->pSPI->SPI_PTCR = AT91C_PDC_RXTDIS | AT91C_PDC_TXTDIS;	//disable SPI PDC
	pSPICtrl->pSPI->SPI_RCR=0;
	pSPICtrl->pSPI->SPI_RPR=0;
	pSPICtrl->pSPI->SPI_TCR=0;
	pSPICtrl->pSPI->SPI_TPR=0;
	pSPICtrl->pSPI->SPI_RNCR=0;
	pSPICtrl->pSPI->SPI_RNPR=0;
	pSPICtrl->pSPI->SPI_TNCR=0;
	pSPICtrl->pSPI->SPI_TNPR=0;


	// Configure SPI according to the registry settings
	AT91F_SPI_CfgMode(pSPICtrl->pSPI, 
		AT91C_SPI_MSTR					|		// MasterMode only
		AT91C_SPI_PS_FIXED 				|		// Fixed Peripheral Selection only
		((pSPICtrl->SPI_ChipSelectDecode)?AT91C_SPI_PCSDEC:0) |		// Chip Select Decode
		((pSPICtrl->SPI_ModeFaultDetection)?AT91C_SPI_MODFDIS:0) |	// Mode Fault Detection
		((pSPICtrl->SPI_LoopBackEnable)?AT91C_SPI_LLB:0)	|		// Local LoopBack
		(pSPICtrl->SPI_DelayBetweenChipSelects << 24) );			//Delay Between Chip Selects 

	
	// Enable the SPI
	pSPICtrl->pSPI->SPI_CR = AT91C_SPI_SPIEN;

	return TRUE;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL HWSPIControllerDeinit(T_SPI_CONTROLLER_STRUCTURE* pSPICtrl)
//!
//! \brief		This function deactivates the SPI controller
//!
//! \param		pSPICtrl	SPI Device		
//!
//! \return		\e TRUE indicates success.
//! \return		\e FALSE indicates failure.
//!
//!	This function deactivates the SPI controller
//-----------------------------------------------------------------------------
BOOL HWSPIControllerDeinit(T_SPI_CONTROLLER_STRUCTURE* pSPICtrl)
{
	// Disable the SPI
	pSPICtrl->pSPI->SPI_CR = AT91C_SPI_SPIDIS;

	// Power down the SPI controller
	return setDevicePower(pSPICtrl->dwIDIRQ,FALSE);
}

//-----------------------------------------------------------------------------
//! \fn			BOOL HWSPICSConfigure(T_SPI_INIT_STRUCTURE* pSPIInit)
//!
//! \brief		This functions sets the configuration of the selected Chip Select
//!
//! \param		pSPIInit	SPI Device		
//!
//! \return		\e TRUE indicates success.
//! \return		\e FALSE indicates failure.
//!
//! This functions sets the configuration of the selected Chip Select
//-----------------------------------------------------------------------------
BOOL HWSPICSConfigure(T_SPI_INIT_STRUCTURE* pSPIInit)
{
	pSPIInit->pSPIControllerInfo->pSPI->SPI_CSR[pSPIInit->wCS] = pSPIInit->dwCSCfg;
	return TRUE;
}

//-----------------------------------------------------------------------------
// \fn			static selectChipSelect(AT91PS_SPI pSPI, DWORD dwCSNumber, DWORD dwChipSelectDecode)
//!
//! \brief		This function is used to select the default Chip Select (Fixed Chip Select Mode)
//!
//! \param		pSPI								SPI Device		
//! \param		dwCSNumber					The Chip select ID
//! \param		dwChipSelectDecode	A flag telling if chip select lines are used to drive a decoder
//!
//! This function is used to select the default Chip Select (Fixed Chip Select Mode)
//-----------------------------------------------------------------------------
static selectChipSelect(AT91PS_SPI pSPI, DWORD dwCSNumber, DWORD dwChipSelectDecode)
{
	DWORD dwChipSelect;

	dwChipSelect = ((~( 1 << dwCSNumber)) << 16) & AT91C_SPI_PCS;

	pSPI->SPI_MR = pSPI->SPI_MR & ~AT91C_SPI_PCS | dwChipSelect;
	return TRUE;
}
#define MIN(x,y) ((x)<(y)? (x):(y))

unsigned long HWSPIGetStatus(AT91PS_SPI pSPI)
{
	return (unsigned int)(pSPI->SPI_SR);
}

int HWSPITxBusy (AT91PS_SPI pSPI)
{
	return (!(HWSPIGetStatus(pSPI) & AT91C_SPI_TDRE));
}

int HWSPIRxBusy (AT91PS_SPI pSPI)
{
	return ((HWSPIGetStatus(pSPI) & AT91C_SPI_RDRF));
}

void HWSPIWriteWord(AT91PS_SPI pSPI, unsigned __int16 *iWord)
{
    pSPI->SPI_TDR = (*iWord & 0xFFFF);
}

unsigned __int16 HWSPIReadWord(AT91PS_SPI pSPI)
{
	return (unsigned __int16)((pSPI->SPI_RDR) & 0xFFFF);
}


//-----------------------------------------------------------------------------
//! \fn			BOOL DoSPITransaction(T_SPI_OPEN_STRUCTURE* pOpenContext,T_SPI_TRANSACTION_ELEMENT_PARAM* pTransactionArray,DWORD dwNbTransaction)
//! 
//!	\brief		This function performs a spi transaction
//!
//! \param		pOpenContext		SPI Device	
//! \param		pTransactionArray	Transaction	descriptor
//! \param		dwNbTransaction		Number of transactions	
//!
//! \return		\e TRUE indicates success.
//! \return		\e FALSE indicates failure.
//!
//! This function performs a spi transaction
//-----------------------------------------------------------------------------
BOOL DoSPITransaction(T_SPI_OPEN_STRUCTURE* pOpenContext,T_SPI_TRANSACTION_ELEMENT_PARAM* pTransactionArray,DWORD dwNbTransaction)
{
	BOOL bRetVal = TRUE;

	AT91PS_SPI  pSPI = pOpenContext->pSPIInfo->pSPIControllerInfo->pSPI;
	T_SPI_CONTROLLER_STRUCTURE* pSPIControllerInfo = pOpenContext->pSPIInfo->pSPIControllerInfo;
	DWORD nextBufferIndex;
	DWORD dwTransacCounter;
	UCHAR* previousRxBuffer;
	DWORD previousRxBufferSize;
	DWORD dwDummy;
	DWORD dwSizeOfData;
	volatile DWORD debug = 1;

	// Check if the structure pointers are right initialized
	if((pSPI==NULL) || (pSPIControllerInfo == NULL))
	{
		bRetVal = FALSE;
		return bRetVal;
	}
	
	// Check if the Transaction Array is not empty
	if(pTransactionArray == NULL)
	{
		bRetVal = FALSE;
		return bRetVal;
	}

	// The Transaction is protected by a critical section
	// we must get the SPI controller for ourselves.
	EnterCriticalSection(&pSPIControllerInfo->csSPIAccess);

	if ((pSPI->SPI_CSR[pOpenContext->pSPIInfo->wCS] & AT91C_SPI_BITS) == AT91C_SPI_BITS_8)
	{
		dwSizeOfData = 1; // 1 byte per sample
	}
	else
	{
		dwSizeOfData = 2; // 2 bytes per sample
	}
	// The transaction descriptor tells which Chip Select must be used, so we select this one	
	if(pSPIControllerInfo->SPI_ChipSelectDecode)
	{
		selectChipSelect(pSPI, pOpenContext->pSPIInfo->wCSRIndex, pSPIControllerInfo->SPI_ChipSelectDecode);
	}
	else
	{
		selectChipSelect(pSPI, pOpenContext->pSPIInfo->wCS, pSPIControllerInfo->SPI_ChipSelectDecode);
	}


	// The data transfer is done by the PDC. Disable the PDCs before programming them
	pSPI->SPI_PTCR = AT91C_PDC_RXTDIS | AT91C_PDC_TXTDIS;
	
	// reset the pdcs
	pSPI->SPI_RPR = 0;
	pSPI->SPI_RCR = 0;
	pSPI->SPI_TPR = 0;
	pSPI->SPI_TCR = 0;	
	pSPI->SPI_RNCR =0;
	pSPI->SPI_RNPR =0;
	pSPI->SPI_TNCR =0;
	pSPI->SPI_TNPR =0;

	previousRxBuffer = NULL;
	previousRxBufferSize = 0;
	nextBufferIndex = 0;

	/// \bug A bug in the earlier version of the SPI controller for AT91SAM9261 makes the CSAAT feature unavailable.
	
	for (dwTransacCounter = 0;dwTransacCounter < dwNbTransaction; dwTransacCounter++)
	{
		//Check if it's a valid transfer ....
		if ( (pTransactionArray[dwTransacCounter].dwSize == 0) || 
			((pTransactionArray[dwTransacCounter].pRxBuffer == NULL) && (pTransactionArray[dwTransacCounter].pTxBuffer == NULL)))
		{
			bRetVal= FALSE;
			continue;
		}

		//if required Copy the transmited data from in the tranmit buffer
		if (pTransactionArray[dwTransacCounter].pTxBuffer)
		{
			memcpy(pSPIControllerInfo->pVirtTxBuffer[nextBufferIndex], pTransactionArray[dwTransacCounter].pTxBuffer, MIN(pSPIControllerInfo->dwTxBufferSize,pTransactionArray[dwTransacCounter].dwSize * dwSizeOfData));
		}		
		
		// Setup the PDC
		if (pTransactionArray[dwTransacCounter].pRxBuffer)
		{
			pSPI->SPI_RNPR = pSPIControllerInfo->dwRxBufferPhysicalAddress[nextBufferIndex];
		}
		else
		{
			pSPI->SPI_RNPR = 0;
		}
		if (pTransactionArray[dwTransacCounter].pRxBuffer)
		{
			pSPI->SPI_RNCR = MIN(pSPIControllerInfo->dwRxBufferSize,pTransactionArray[dwTransacCounter].dwSize);
		}
		else
		{
			pSPI->SPI_RNCR = 0;
		}
		if (pTransactionArray[dwTransacCounter].pTxBuffer)
		{
			pSPI->SPI_TNPR = pSPIControllerInfo->dwTxBufferPhysicalAddress[nextBufferIndex];
		}
		else
		{
			pSPI->SPI_TNPR = pSPIControllerInfo->dwRxBufferPhysicalAddress[nextBufferIndex];
		}
		
		//Clear the CS line if needed (see "CSUsePIO" in registry)
		if (pOpenContext->pSPIInfo->pCSPio)
		{
			pOpenContext->pSPIInfo->pCSPio->PIO_CODR = pOpenContext->pSPIInfo->dwCSPioPin;
		}
		// Writing the Transmit Counter actually starts the transfer
		if (pTransactionArray[dwTransacCounter].pTxBuffer)
		{
			pSPI->SPI_TNCR = MIN(pSPIControllerInfo->dwTxBufferSize,pTransactionArray[dwTransacCounter].dwSize);
		}
		else
		{
			pSPI->SPI_TNCR = MIN(pSPIControllerInfo->dwRxBufferSize,pTransactionArray[dwTransacCounter].dwSize);
		}
				


		// Setup the interrupt for trigerring whenever the ReceiveNext and TransmitNext are free
		pSPI->SPI_IDR = 0xFFFFFFFF;
		pSPI->SPI_IER = AT91C_SPI_ENDTX | AT91C_SPI_ENDRX;

		dwDummy = pSPI->SPI_RDR;
		//enable the PDC
		pSPI->SPI_PTCR = AT91C_PDC_RXTEN | AT91C_PDC_TXTEN;


		if (dwTransacCounter) //First time doesn't count... 
		{
			while ((pSPI->SPI_SR & (AT91C_SPI_ENDTX | AT91C_SPI_ENDRX)) != (AT91C_SPI_ENDTX | AT91C_SPI_ENDRX))
			{		
				WaitForSingleObject(pSPIControllerInfo->hInterruptEvent,INFINITE);
				InterruptDone(pSPIControllerInfo->dwSysintr);
			}
		}

		//if required Copy the received data in the buffer (the one previously used because here we're initalizing the buffer for the NEXT transfer)
		if (previousRxBuffer && previousRxBufferSize)
		{
			memcpy(previousRxBuffer,pSPIControllerInfo->pVirtRxBuffer[1-nextBufferIndex],previousRxBufferSize * dwSizeOfData);
		}

		//Toogle the next buffer index (0 -> 1 -> 0 -> ...)
		nextBufferIndex = 1 - nextBufferIndex; 
		
		previousRxBuffer = pTransactionArray[dwTransacCounter].pRxBuffer;
		previousRxBufferSize = pTransactionArray[dwTransacCounter].dwSize;
	}
	

	
	// Setup the interrupt for trigerring when receive and transmit are empty.
	pSPI->SPI_IDR = 0xFFFFFFFF;
	pSPI->SPI_IER = AT91C_SPI_RXBUFF | AT91C_SPI_TXBUFE;

	while ((pSPI->SPI_SR & (AT91C_SPI_RXBUFF | AT91C_SPI_TXBUFE)) != (AT91C_SPI_RXBUFF | AT91C_SPI_TXBUFE))
	{
		WaitForSingleObject(pSPIControllerInfo->hInterruptEvent,INFINITE);
		InterruptDone(pSPIControllerInfo->dwSysintr);
	}

	// Tell the controller that the transfer is complete (bring the NPCSx line back to 1)
	pSPI->SPI_CR = AT91C_SPI_LASTXFER;
	
	// Stop the PDCs
	pSPI->SPI_PTCR = AT91C_PDC_RXTDIS | AT91C_PDC_TXTDIS;
	
			
	if (pTransactionArray[dwTransacCounter-1].pRxBuffer == NULL)
	{
		DWORD dwStatus;
		DWORD dwTimeout;
		volatile DWORD dwDelay;
		
#define TX_TIMEOUT	1000
#ifdef DEBUG
#define CS_DELAY_MULTIPLIER	5
#else		
#define CS_DELAY_MULTIPLIER	8
#endif

		// Wait that the transmit register is emptied before raising the CS line
		dwTimeout = TX_TIMEOUT;
		do
		{
			dwStatus = pSPI->SPI_SR;
		}while ((dwTimeout--) &&((dwStatus & AT91C_SPI_TDRE) == 0));

		dwDelay = CS_DELAY_MULTIPLIER * ((pSPI->SPI_CSR[pOpenContext->pSPIInfo->wCS] >> 8) & 0xFF) ;
		while (dwDelay--);

	}	
				
	


	//Set the CS line if needed (see "CSUsePIO" in registry)
	if (pOpenContext->pSPIInfo->pCSPio)
	{
		pOpenContext->pSPIInfo->pCSPio->PIO_SODR = pOpenContext->pSPIInfo->dwCSPioPin;
	}


	//if required Copy the last received data in the buffer
	if (previousRxBuffer && previousRxBufferSize)
	{	
		memcpy(previousRxBuffer,pSPIControllerInfo->pVirtRxBuffer[1-nextBufferIndex],previousRxBufferSize * dwSizeOfData);
	}

	//We can now release the access to the SPI controller

	LeaveCriticalSection(&pSPIControllerInfo->csSPIAccess);
	return bRetVal;
}

//! @}

//! @}

////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/SPI/SPIDriver_hw.c $
////////////////////////////////////////////////////////////////////////////////
//
