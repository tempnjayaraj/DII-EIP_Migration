//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//! \addtogroup	EMAC
//! @{
//
//! \addtogroup EMACBNDIS
//! @{
//
//  All rights reserved ADENEO SAS 2005
//
//! \file		at91sam9263ek_emacbndis.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/EmacbNDIS/at91sam9263ek_emacbndis.h $
//!   $Author: ltourlonias $
//!   $Revision: 684 $
//!   $Date: 2007-04-13 14:35:48 +0200 (ven., 13 avr. 2007) $
//! \endif
//		TODO
//
//-----------------------------------------------------------------------------
#include "device.h"
#include "driver.h"
#include "cemacb.h"

class C_SAM9263EK_EMACBNDIS : public C_EMACB
{
public :
	C_SAM9263EK_EMACBNDIS ::C_SAM9263EK_EMACBNDIS (NIC_DRIVER_OBJECT	*pUpper,PVOID pVoid) 
		: C_EMACB(pUpper,pVoid){};

protected:
	virtual void PIOConfiguration(void);
};
//! @}
//! @}
//! @}
