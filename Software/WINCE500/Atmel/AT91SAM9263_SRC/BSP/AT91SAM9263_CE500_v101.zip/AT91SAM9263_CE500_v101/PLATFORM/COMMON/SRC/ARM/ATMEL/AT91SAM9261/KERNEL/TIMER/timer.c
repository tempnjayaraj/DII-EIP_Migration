//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/SOC/ATMEL/AT91SAM9261/KERNEL/TIMER/timer.c
//!
//! \brief		AT91SAM9261 processor's timer
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK20/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9261/KERNEL/TIMER/timer.c $
//!   $Author: ltourlonias $
//!   $Revision: 563 $
//!   $Date: 2007-03-14 16:23:47 +0100 (mer., 14 mars 2007) $
//! \endif
//-----------------------------------------------------------------------------

//! \addtogroup	TIMER
//! @{

#include <windows.h>

#include "at91sam926x.h"

//-----------------------------------------------------------------------------
//! \fn       DWORD TimerProcSpecificGetPMCBaseAddress(void)
//!
//!	\brief    This function returns the base address of the PMC controller
//!
//!
//!
//! \return		base address of the PMC controller
//-----------------------------------------------------------------------------
DWORD TimerProcSpecificGetPMCBaseAddress(void)
{
	return (DWORD) AT91C_BASE_PMC;
}

//-----------------------------------------------------------------------------
//! \fn       DWORD TimerProcSpecificGetPITCBaseAddress(void)
//!
//!	\brief    This function returns the base address of the PITC controller
//!
//!
//!
//! \return		base address of the PITC controller
//-----------------------------------------------------------------------------
DWORD TimerProcSpecificGetPITCBaseAddress(void)
{
	return (DWORD) AT91C_BASE_PITC;
}

//-----------------------------------------------------------------------------
//! \fn       DWORD TimerProcSpecificGetSYSId(void)
//!
//!	\brief    This function returns System peripheral ID
//!
//!
//!
//! \return		System peripheral ID
//-----------------------------------------------------------------------------
DWORD TimerProcSpecificGetSYSId(void)
{
	return (DWORD) AT91C_ID_SYS;
}

//! @} end of subgroup TIMER

//! @} end of group OAL


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9261/KERNEL/TIMER/timer.c $
////////////////////////////////////////////////////////////////////////////////
//
