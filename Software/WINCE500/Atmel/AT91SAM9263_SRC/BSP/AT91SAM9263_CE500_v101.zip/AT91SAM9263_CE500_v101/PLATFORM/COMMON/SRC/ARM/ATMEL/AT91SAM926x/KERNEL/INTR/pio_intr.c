//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		pio_intr.c
//!
//! \brief		implements the PIO interrupt engine
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/INTR/pio_intr.c $
//!   $Author: pblanchard $
//!   $Revision: 1058 $
//!   $Date: 2007-07-05 01:34:39 -0700 (Thu, 05 Jul 2007) $
//! \endif
//-----------------------------------------------------------------------------

//! \addtogroup	INTR
//! @{

#include <windows.h>
#include <nkintr.h>
#include <oal_memory.h>
#include "AT91SAM926x.h"
#include "AT91SAM926x_oal_intr.h"
#include "pio_intr.h"

//-----------------------------------------------------------------------------
//! \fn			  DWORD pioGetLogintr(DWORD pioBankNumber)
//!
//! \brief		This functions checks for the status of the pio bank to determine if a pio has triggered an interrupt
//!				
//! \note     If more than one PIO has triggered and interrupt this functions make sure that the second interrupt 
//!       will not be lost by forcing another PIO Bank interrupt
//!
//! \param    pioBankNumber: number of the pio bank to check
//!
//! \return   Irq of the PIO
//-----------------------------------------------------------------------------
DWORD pioGetLogintr(DWORD pioBankNumber)
{
	unsigned int logintr;	
	DWORD AIC_IMR;	
	DWORD currentPin;
	static AT91PS_AIC pAIC = 0;
	AT91PS_PIO vBasePio;
	PIOBANKDESCRIPTION* pPioBank;

	// DMR : Optimization
	DWORD dwMaskedStatus, dwDeviceIDMask;

	// We traduce PA to VA only once
	if (!pAIC)
	{
		pAIC = (AT91PS_AIC) OALPAtoVA((DWORD)AT91C_BASE_AIC,FALSE);

		//Sanity Check
		if (pAIC == NULL)
		{
			RETAILMSG(1, (L"+%s OALPAtoVA((DWORD)AT91C_BASE_AIC,FALSE) failed \r\n",__FUNCTION__ ));
			return LOGINTR_UNDEFINED;
		}
	}

	// TODO : Add an VA in the struct to avoid AOLPAtoVA :)
	pPioBank = &(g_PioBankDescTab[pioBankNumber]);
	vBasePio = pPioBank->vPioBase;

	// Following code should not be interrupted by another pio interrupt of the same bank.
	// since critical sections doesn't work here. 
	// just disable the current Pio bank interrupt.
	// (keep trace of the mask register first)

	// Save the Mask register
	AIC_IMR = pAIC->AIC_IMR;

	// Disable current interrupt
	dwDeviceIDMask = (1<<pPioBank->deviceID);
	pAIC->AIC_IDCR = dwDeviceIDMask;

	//Set the new 'persistent' status for the pio bank (we don't keep the status for interrupt that are not yet enabled)
	pPioBank->status |= (vBasePio->PIO_ISR & vBasePio->PIO_IMR); 

	//Look for a pin that has been triggered
	logintr = LOGINTR_UNDEFINED;

///////////////////////////////////////////////////////////////////////////// 2.5s

	dwMaskedStatus = pPioBank->status & vBasePio->PIO_IMR;

	
	for (currentPin = 0; currentPin < pPioBank->nbPin; currentPin++)
	{
		if (dwMaskedStatus & (1<<currentPin))
		{
			logintr = pPioBank->logintrBase + currentPin;
			break;
		}
	}

	
	

/*
	// DMR : Optimized code V2.0
	{
		oldStatus = pPioBank->status;

		// Dichotomia
		if (oldStatus > 0x00008000)
		{
			if (oldStatus > 0x00800000)
			{
				if (oldStatus > 0x08000000)
				{
					if (oldStatus > 0x20000000)
					{
						if (oldStatus & 0x80000000)
						{
							i = 0x80000000;
							currentPin = 31;
						} else {
							i = 0x40000000;
							currentPin = 30;
						}
					} else {
						if (oldStatus & 0x20000000)
						{
							i = 0x20000000;
							currentPin = 29;
						} else {
							i = 0x10000000;
							currentPin = 28;
						}
					}
				} else {
					if (oldStatus > 0x02000000)
					{
						if (oldStatus & 0x08000000)
						{
							i = 0x08000000;
							currentPin = 27;
						} else {
							i = 0x04000000;
							currentPin = 26;
						}
					} else {
						if (oldStatus & 0x02000000)
						{
							i = 0x02000000;
							currentPin = 25;
						} else {
							i = 0x01000000;
							currentPin = 24;
						}
					}
				}
			} else {
				if (oldStatus > 0x00080000)
				{
					if (oldStatus > 0x00200000)
					{
						if (oldStatus & 0x00800000)
						{
							i = 0x00800000;
							currentPin = 23;
						} else {
							i = 0x00400000;
							currentPin = 22;
						}
					} else {
						if (oldStatus & 0x00200000)
						{
							i = 0x00200000;
							currentPin = 21;
						} else {
							i = 0x00100000;
							currentPin = 20;
						}
					}
				} else {
					if (oldStatus > 0x00020000)
					{
						if (oldStatus & 0x00080000)
						{
							i = 0x00080000;
							currentPin = 19;
						} else {
							i = 0x00040000;
							currentPin = 18;
						}
					} else {
						if (oldStatus & 0x00020000)
						{
							i = 0x00020000;
							currentPin = 17;
						} else {
							i = 0x00010000;
							currentPin = 16;
						}
					}
				}
			}
		} else {
			if (oldStatus > 0x00000080)
			{
				if (oldStatus > 0x00000800)
				{
					if (oldStatus > 0x00002000)
					{
						if (oldStatus & 0x00008000)
						{
							i = 0x00008000;
							currentPin = 15;
						} else {
							i = 0x00004000;
							currentPin = 14;
						}
					} else {
						if (oldStatus & 0x00002000)
						{
							i = 0x00002000;
							currentPin = 13;
						} else {
							i = 0x00001000;
							currentPin = 12;
						}
					}
				} else {
					if (oldStatus > 0x00000200)
					{
						if (oldStatus & 0x00000800)
						{
							i = 0x00000800;
							currentPin = 11;
						} else {
							i = 0x00000400;
							currentPin = 10;
						}
					} else {
						if (oldStatus & 0x00000200)
						{
							i = 0x00000200;
							currentPin = 9;
						} else {
							i = 0x00000100;
							currentPin = 8;
						}
					}
				}
			} else {
				if (oldStatus > 0x00000008)
				{
					if (oldStatus > 0x00000020)
					{
						if (oldStatus & 0x00000080)
						{
							i = 0x00000080;
							currentPin = 7;
						} else {
							i = 0x00000040;
							currentPin = 6;
						}
					} else {
						if (oldStatus & 0x00000020)
						{
							i = 0x00000020;
							currentPin = 5;
						} else {
							i = 0x00000010;
							currentPin = 4;
						}
					}
				} else {
					if (oldStatus > 0x00000002)
					{
						if (oldStatus & 0x00000008)
						{
							i = 0x00000008;
							currentPin = 3;
						} else {
							i = 0x00000004;
							currentPin = 2;
						}
					} else {
						if (oldStatus & 0x00000002)
						{
							i = 0x00000002;
							currentPin = 1;
						} else {
							i = 0x00000001;
							currentPin = 0;
						}
					}
				}
			}
		}

		logintr = pPioBank->logintrBase + currentPin;
	}
*/

	if (logintr != LOGINTR_UNDEFINED)
	{
		//Mask the pio interrupt for this particular pin, it'll be re-enabled by the user when calling interruptDone.
		vBasePio->PIO_IDR = (1<<currentPin);

		//Since we're going to serve this particular interrupt we remove it from the status
		pPioBank->status &= ~(1<<currentPin); 

		// check if the status indicates that another PIO interrupt should be served
		if (pPioBank->status & vBasePio->PIO_IMR) 
		{
			//There is still a pio state change pending, force the interrupt to be trigged again
			pAIC->AIC_ISCR = dwDeviceIDMask;
		}
	}        

	// re-Enable the interrupt if it was previously enabled
	pAIC->AIC_IECR = (dwDeviceIDMask & AIC_IMR);

	return logintr;
}

//-----------------------------------------------------------------------------
//! \fn			  BOOL SOCEnablePioIrq(DWORD logintr)
//!
//! \brief		This functions enables the interrupt
//!				
//! \param    logintr Logintr to be enabled
//!
//! \return   TRUE indicates success
//! \return   FALSE indicates failure
//-----------------------------------------------------------------------------
BOOL SOCEnablePioIrq(DWORD logintr)
{
	DWORD pioBankNumber;
	DWORD mask;

   	//RETAILMSG(1, ( L"+SOCEnablePioIrq(%d)\r\n", logintr ));
	for (pioBankNumber=0;pioBankNumber<g_dwOalPioBankNumber;pioBankNumber++)
	{
		if ((logintr >= g_PioBankDescTab[pioBankNumber].logintrBase) && (logintr < (g_PioBankDescTab[pioBankNumber].logintrBase + g_PioBankDescTab[pioBankNumber].nbPin)))
		{
			mask = 1<<(logintr - g_PioBankDescTab[pioBankNumber].logintrBase); // 1 << pin_number

			g_PioBankDescTab[pioBankNumber].vPioBase->PIO_ODR = mask; //Output disable
			g_PioBankDescTab[pioBankNumber].vPioBase->PIO_PER = mask; //PIO enable (disable peripheral multiplexing)
			g_PioBankDescTab[pioBankNumber].vPioBase->PIO_IER = mask; //Interrupt enable
			return TRUE;
		}
	}
	return FALSE;
}


//-----------------------------------------------------------------------------
//! \fn			  BOOL SOCDisablePioIrq(DWORD logintr, BOOL* pOldState)
//!
//! \brief		This functions disables the interrupt
//!				
//! \param    logintr Logintr to be enabled
//! \param    pOldState returns the previous state opf the IRQ
//!
//! \return   TRUE indicates success
//! \return   FALSE indicates failure
//-----------------------------------------------------------------------------
BOOL SOCDisablePioIrq(DWORD logintr, BOOL* pOldState)
{
	DWORD pioBankNumber;
	DWORD mask;

   	//RETAILMSG(1, ( L"+SOCDisablePioIrq(%d)\r\n", logintr ));
	for (pioBankNumber=0;pioBankNumber<g_dwOalPioBankNumber;pioBankNumber++)
	{
		if ((logintr >= g_PioBankDescTab[pioBankNumber].logintrBase) && (logintr < (g_PioBankDescTab[pioBankNumber].logintrBase + g_PioBankDescTab[pioBankNumber].nbPin)))
		{
			mask = (1<<(logintr - g_PioBankDescTab[pioBankNumber].logintrBase));

			//RETAILMSG(1, ( L"+SOCDisablePioIrq(%d) bank %d pin %d\r\n", logintr,pioBankNumber, (logintr - g_PioBankDescTab[pioBankNumber].logintrBase)));
			if (pOldState!=NULL)
			{
				*pOldState = (DWORD)(g_PioBankDescTab[pioBankNumber].vPioBase->PIO_IDR & mask);
			}

			g_PioBankDescTab[pioBankNumber].vPioBase->PIO_IDR = mask;
			return TRUE;
		}
	}
	return FALSE;
}

//-----------------------------------------------------------------------------
//! \fn			  DWORD SOCIntrActiveIrq(DWORD nIrq)
//!
//! \brief		This function gives the Hardware Interrupt Identifier (LOGINTR)
//!				
//! \note     It checks if the interrupt is a PIO interrupt. If so it computes 
//!    the associated LOGINTR, otherwise leaves the parameter unchanged
//!
//! \param    nIrq physical interrupt number
//!
//! \return   physical interrupt number
//-----------------------------------------------------------------------------
DWORD SOCIntrActiveIrq(DWORD nIrq)
{		
	DWORD i;
	DWORD nNewIrq = LOGINTR_UNDEFINED;

	for(i=0;i<g_dwOalPioBankNumber;i++)
	{				
		if (nIrq == (g_PioBankDescTab[i].deviceID))
		{			
			nNewIrq = pioGetLogintr(i);			
			

			if (nNewIrq != LOGINTR_UNDEFINED)
			{
				nIrq = nNewIrq;
				//RETAILMSG(1, ( L"+found IRQ Source %d\r\n",nNewIrq));
				break;
			}
		}
	}
	
	return nIrq;
}

//-----------------------------------------------------------------------------
//! \fn			  void SOCPioControllerIntrEnable()
//!
//! \brief		This function enables the interrupt of the PIO banks at AIC level
//!				
//!
//!
//!
//-----------------------------------------------------------------------------
void SOCPioControllerIntrEnable()
{
	DWORD i;
	AT91PS_AIC pAIC;
		
	pAIC = (AT91PS_AIC) OALPAtoVA((DWORD)AT91C_BASE_AIC,FALSE);
	//Sanity Check
	if (pAIC == NULL)
	{
		RETAILMSG(1, (L"+%s OALPAtoVA((DWORD)AT91C_BASE_AIC,FALSE) failed \r\n",__FUNCTION__ ));
		return;
	}

   	RETAILMSG(1, ( L"+SOCPioControllerIntrEnable()\r\n"));
	
	for (i=0;i<g_dwOalPioBankNumber;i++)
	{
		pAIC->AIC_IECR = (1<<g_PioBankDescTab[i].deviceID); //eanble AIC interrupt for this controller
	}
}

//-----------------------------------------------------------------------------
//! \fn			  void SOCPioIntrInit()
//!
//! \brief		This function initializes the PIO interrupt engine
//!				
//!
//!
//!
//-----------------------------------------------------------------------------
void SOCPioIntrInit()
{
	DWORD i;
	volatile DWORD garbage;
	AT91PS_AIC pAIC;
	AT91PS_SYS pSYS;
	
	RETAILMSG(1, ( L"+SOCPioIntrInit()\r\n"));

	pAIC = (AT91PS_AIC) OALPAtoVA((DWORD)AT91C_BASE_AIC,FALSE);
	//Sanity Check
	if (pAIC == NULL)
	{
		RETAILMSG(1, (L"+%s OALPAtoVA((DWORD)AT91C_BASE_AIC,FALSE) failed \r\n",__FUNCTION__ ));
		return;
	}
	
	pSYS = (AT91PS_SYS) OALPAtoVA((DWORD)AT91C_BASE_SYS,FALSE);
	//Sanity Check
	if (pSYS == NULL)
	{
		RETAILMSG(1, (L"+%s OALPAtoVA((DWORD)AT91C_BASE_SYS,FALSE) failed \r\n",__FUNCTION__));
		return;
	}
   	
		
	for (i=0;i<g_dwOalPioBankNumber;i++)
	{
		

		AT91PS_PIO vPioBase;

		vPioBase = (AT91PS_PIO) OALPAtoVA((DWORD)g_PioBankDescTab[i].pBase,FALSE);
		
		//Sanity Check
		if (vPioBase == NULL)
		{
			RETAILMSG(1, (L"+%s OALPAtoVA((DWORD)g_PioBankDescTab[i].pBase (=0x%x),FALSE) failed \r\n",__FUNCTION__,g_PioBankDescTab[i].pBase ));
			return;
		}

		g_PioBankDescTab[i].vPioBase = vPioBase;

#ifndef NO_PMC			
		pSYS->SYS_PMC_PCER = (1 << g_PioBankDescTab[i].deviceID);//power up the controller
#endif		
		vPioBase->PIO_IDR = 0xFFFFFFFF; //disable all interrupts from this bank		
		garbage = vPioBase->PIO_ISR; //clear any pending pio interrupt		
		pAIC->AIC_IECR = (1<<g_PioBankDescTab[i].deviceID); //eanble AIC interrupt for this controller		
	}

	RETAILMSG(1, ( L"-SOCPioIntrInit()\r\n"));
}

//-----------------------------------------------------------------------------
//! \fn			  void SOCPioSaveAndDisableAllIntrBeforeSuspend()
//!
//! \brief		This function saves PIOs interrupts mask and turn all interrupt sources off for every pio bank
//!				
//!
//!
//!
//-----------------------------------------------------------------------------
void SOCPioSaveAndDisableAllIntrBeforeSuspend()
{

	DWORD i;
   	RETAILMSG(1, ( L"SOCPioSaveAndDisableAllIntrBeforeSuspend()\r\n"));
	for (i=0;i<g_dwOalPioBankNumber;i++)
	{
		AT91PS_PIO vPioBase = g_PioBankDescTab[i].vPioBase;
		g_PioBankDescTab[i].resumeMask = vPioBase->PIO_IMR; //save the mask
		vPioBase->PIO_IDR = 0xFFFFFFFF; //disable all interrupts of this bank
	}
}

//-----------------------------------------------------------------------------
//! \fn			  void SOCPioRestoreAllIntrAfterSuspend()
//!
//! \brief		This function restores the previously backed-up interrupt mask for  every pio bank
//!    (SOCSaveAndDisableAllIntrBeforeSuspend). It is called juste before leaving suspend mode by SOCRestoreAllIntrAfterSuspend
//!				
//!
//!
//!
//-----------------------------------------------------------------------------
void SOCPioRestoreAllIntrAfterSuspend()
{

	DWORD i;
   	RETAILMSG(1, ( L"+SOCPioRestoreAllIntrAfterSuspend()\r\n"));
	
	for (i=0;i<g_dwOalPioBankNumber;i++)
	{
		AT91PS_PIO vPioBase = g_PioBankDescTab[i].vPioBase;
		vPioBase->PIO_IER = g_PioBankDescTab[i].resumeMask; //enable interrupts of this bank according to the mask
	}
	
}

//! @} end of subgroup INTR

//! @} end of group OAL

//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/INTR/pio_intr.c $
//-----------------------------------------------------------------------------
// 
// 
