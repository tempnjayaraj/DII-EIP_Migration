//-----------------------------------------------------------------------------
//! \addtogroup   SPI
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				AT91RM9200_SPIDriver_IOCTL.h
//!
//! \brief				IOCTL for SPI driver
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/INC/IOCTL/AT91RM9200_SPIDriver_ioctl.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

#include "at91rm9200.h"

#ifdef __cplusplus
extern "C" {
#endif
//! \struct T_SPI_TRANSACTION_PARAM
//! \brief this strcuture is used to pass parameters to SPI_IOControl
typedef struct {
	PVOID pRxBuffer;	/*! < \brief location of the destination data */
	PVOID pTxBuffer;	/*! < \brief location of the source data */
	DWORD dwSize;		/*! < \brief size of the buffer*/	
} T_SPI_TRANSACTION_ELEMENT_PARAM;


// Functions
#define SPI_TRANSACTION_CMD	1
#define SPI_TRANSACTION_ADS7843_CMD	2

/*! \def IOCTL_SPI_TRANSACTION	
	\brief Command code for performing a SPI transaction
*/

#define IOCTL_SPI_TRANSACTION	CTL_CODE(FILE_DEVICE_SERIAL_PORT, SPI_TRANSACTION_CMD, METHOD_BUFFERED, FILE_ANY_ACCESS)

#ifdef __cplusplus
}
#endif


//! @}
