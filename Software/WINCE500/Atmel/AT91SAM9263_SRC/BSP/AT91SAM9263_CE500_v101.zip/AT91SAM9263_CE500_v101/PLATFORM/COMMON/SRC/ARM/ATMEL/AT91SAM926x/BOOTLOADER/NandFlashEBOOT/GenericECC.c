//-----------------------------------------------------------------------------
//! \addtogroup	DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/NandFlashEBOOT/GenericECC.c
//!
//! \brief		A set of generic ECC functions
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/NandFlashEBOOT/GenericECC.c $
//!   $Author: ltourlonias $
//!   $Revision: 657 $
//!   $Date: 2007-04-10 16:52:09 +0200 (mar., 10 avr. 2007) $
//! \endif
//!
//! 
//-----------------------------------------------------------------------------
//! \addtogroup	NandFlash
//! @{
//!

#include <windows.h>
#include <ecc.h>


#include "genericECC.h"

//! \addtogroup GenericECC
//! @{

//-----------------------------------------------------------------------------
//! \fn			BOOL ComputeECC(LPBYTE pData, DWORD dwDataBuffLen, LPBYTE pECC, DWORD dwECCBuffLen)
//!
//! \brief		Computes the error correcting code for the specified data.
//!
//! \param		pData Buffer to compute the ECC from
//! \param		dwDataBuffLen Size of the data (must be a multiple of 512)
//! \param		pECC Buffer where the ECC is going to be stored
//! \param		dwECCBuffLen maximum size of the ECC buffer
//!
//! \result		TRUE if success
//!				FALSE otherwise
//-----------------------------------------------------------------------------
BOOL ComputeECC(LPBYTE pData, DWORD dwDataBuffLen, LPBYTE pECC, DWORD dwECCBuffLen)
{	
	DWORD i;


	if ((dwDataBuffLen % ECC_BLOCK_SIZE) != 0)
	{
		//! \Note dwDataBuffLen must be a multiple of 512
		RETAILMSG(1,(TEXT("ComputeECC : The size of data must be a multiple of 512\r\n")));
		return FALSE;
	}
	if (((dwDataBuffLen / ECC_BLOCK_SIZE) * ECC_RESULT_SIZE) > dwECCBuffLen)
	{
		RETAILMSG(1,(TEXT("ComputeECC : The ECC buffer is not big enough for this size of data\r\n")));
		return FALSE;
	}
	
	for (i=0;i<dwDataBuffLen;i += ECC_BLOCK_SIZE)
	{
		if (ECC_ComputeECC(&pData[i],ECC_BLOCK_SIZE,pECC,dwECCBuffLen) == FALSE)
		{
			return FALSE;
		}
		dwECCBuffLen -= ECC_RESULT_SIZE;
		pECC += ECC_RESULT_SIZE;
	}
	
	return TRUE;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL IsECCDataValid(LPBYTE pData, DWORD dwDataBuffLen, LPBYTE pExistingECC)
//!
//! \brief		Determines if the specfied buffer of data is valid.  
//!
//!
//! \param		pData Buffer to compute the ECC from
//! \param		dwDataBuffLen Size of the data (must be a multiple of 512)
//! \param		pExistingECC Buffer where the refrence ECC is stored
//!
//! \note		To determine if the data is valid, new ECC information is 
//!				generated for the specified data and then compared to the  
//!				specified (a.k.a. existing) ECC information.  For now, we assume
//!				that the input data buffer is a multiple of 512 bytes and less than 8192 bytes.
//!
//! \result		Boolean indicating success.
//-----------------------------------------------------------------------------

BOOL IsECCDataValid(LPBYTE pData, DWORD dwDataBuffLen, LPBYTE pExistingECC)
{
	DWORD i;
	if ((dwDataBuffLen % ECC_BLOCK_SIZE) != 0)
	{
		//! \Note dwDataBuffLen must be a multiple of 512
		RETAILMSG(1,(TEXT("ComputeECC : The size of data must be a multiple of 512\r\n")));
		return FALSE;
	}
	
	for (i=0;i<dwDataBuffLen;i += ECC_BLOCK_SIZE)
	{
		if (ECC_IsDataValid(&pData[i],ECC_BLOCK_SIZE,pExistingECC,ECC_RESULT_SIZE) == FALSE)
		{
			return FALSE;
		}		
		pExistingECC += ECC_RESULT_SIZE;
	}
	
	return TRUE;
}

//-----------------------------------------------------------------------------
//! \fn:		BOOL CorrectData(LPBYTE pData, DWORD dwDataBuffLen, LPBYTE pExistingECC)
//!
//! \brief		Corrects any errors (if possible) in the specified data.
//!				Furthermore, only single bit errors can be corrected for every 256 bytes of data.
//!
//!
//! \param		pData Buffer to compute the ECC from
//! \param		dwDataBuffLen Size of the data (must be a multiple of 512)
//! \param		pECC Buffer where the refrence ECC is stored
//!
//! \note		This implemention uses 3 bytes of ECC info for every 256 bytes of data
//!				generated for the specified data and then compared to the  
//!				specified (a.k.a. existing) ECC information.  For now, we assume
//!				that the input data buffer is a multiple of 512 bytes and less than 8192 bytes.
//!
//! \result		Boolean indicating success.
//-----------------------------------------------------------------------------


BOOL CorrectData(LPBYTE pData, DWORD dwDataBuffLen, LPBYTE pExistingECC)
{
	DWORD i;


	if ((dwDataBuffLen % ECC_BLOCK_SIZE) != 0)
	{
		//! \Note dwDataBuffLen must be a multiple of 512
		RETAILMSG(1,(TEXT("ComputeECC : The size of data must be a multiple of 512\r\n")));
		return FALSE;
	}
	
	for (i=0;i<dwDataBuffLen;i += ECC_BLOCK_SIZE)
	{
		if (ECC_CorrectData(&pData[i],ECC_BLOCK_SIZE,pExistingECC,ECC_RESULT_SIZE) == FALSE)
		{
			return FALSE;
		}
		pExistingECC += ECC_RESULT_SIZE;
	}
	
	return TRUE;
}

// End of Doxygen group GenericECC
//! @}

//! @}



// End of Doxygen group NandFlash Driver
//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/NandFlashEBOOT/GenericECC.c $
//-----------------------------------------------------------------------------
//

//! @}
