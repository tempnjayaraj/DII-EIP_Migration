//-----------------------------------------------------------------------------
//! \addtogroup	DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/NandFlash/GenericFMD.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/NandFlash/GenericFMD.h $
//!   $Author: cchary $
//!   $Revision: 805 $
//!   $Date: 2007-05-09 16:15:56 +0200 (mer., 09 mai 2007) $
//! \endif
//! 
//! Header for the generic FMD
//-----------------------------------------------------------------------------
//!
//! \addtogroup	NandFlash
//! @{

#ifndef __GENERICFMD_H__
#define __GENERICFMD_H__

// Make a Doxygen group
//! \addtogroup GenericFMD
//! @{

#define AT91SAM9261EK_FMD_MAPPING	0x80050000	// Base RAM address for malloc/free emulation

// Specific IOCTL for image flashing from application
#define IOCTL_DISK_USER_WRITE	IOCTL_DISK_USER(0)
#define IOCTL_DISK_USER_READ	IOCTL_DISK_USER(1)
#define IOCTL_DISK_USER_DELETE	IOCTL_DISK_USER(2)

//! \brief	All structures, typedefs & consts for mapping and locking
typedef struct _FMDBlocksInfo
{
	WORD wPhysicalNumber;		//!< Physical number for a specified Logical number
	WORD wStatus;				//!< Status word for the block
} FMDBlocksInfo, *pFMDBlocksInfo;


#endif /*__GENERICFMD_H__*/

// End of Doxygen group GenericFMD
//! @}

//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/NandFlash/GenericFMD.h $
//-----------------------------------------------------------------------------
//

//! @}
