//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x/INC/LCDC/mode.h
//!
//! \brief		Specific declaration used to support different resolutions
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/LCDC/mode.h $
//!   $Author: pblanchard $
//!   $Revision: 993 $
//!   $Date: 2007-06-12 08:36:50 -0700 (Tue, 12 Jun 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	LCDC
//! @{
//!

#ifndef __MODE_LCDC__
#define ___MODE_LCDC__

// Modes array
GPEMode aModes[8] = {
					0,  320, 240,  4, 50, gpe4Bpp,	// Mode 0
					1,  240, 320,  8, 60, gpe8Bpp,	// Mode 1
					2,  320, 240, 16, 60, gpe16Bpp,	// Mode 2
					3,  640, 480, 16, 60, gpe16Bpp,	// Mode 3
					4, 1024, 768, 16, 60, gpe16Bpp,	// Mode 4
					5,  240, 320, 16, 60, gpe16Bpp, // Mode 5
					6,  240, 320, 24, 60, gpe24Bpp,  // Mode 6
					7,  240, 320, 32, 60, gpe32Bpp,  // Mode 7
					};
					

// Mode 0 :
ulong gBitMasks4Bpp[] = { 0xFF, 0xFF, 0xFF };
PALETTEENTRY g_LUT4Bpp[] =
{
	{0X00, 0X00, 0X00, 0},	
	{0X7F, 0X7F, 0X7F, 0},
	{0X87, 0X87, 0X87, 0},
	{0X8F, 0X8F, 0X8F, 0},
	{0X97, 0X97, 0X97, 0},
	{0X9F, 0X9F, 0X9F, 0},
	{0XA7, 0XA7, 0XA7, 0},
	{0XAF, 0XAF, 0XAF, 0},
	{0XB7, 0XB7, 0XB7, 0},
	{0XBF, 0XBF, 0XBF, 0},
	{0XC7, 0XC7, 0XC7, 0},
	{0XCF, 0XCF, 0XCF, 0},
	{0XD7, 0XD7, 0XD7, 0},
	{0XDF, 0XDF, 0XDF, 0},
	{0XE7, 0XE7, 0XE7, 0},
	{0XFF, 0XFF, 0XFF, 0}
};
ulong gBitMasks8Bpp[] = { 0xFF, 0xFF, 0xFF };
ulong gBitMasks16Bpp5551RGBX[] = { 0xF800, 0x07C0, 0x003E };
ulong gBitMasks16Bpp1555XRGB[] = { 0x7C00, 0x003E0, 0x001F };
ulong gBitMasks16Bpp1555XBGR[] = { 0x001F, 0x03E0,  0x7C00};
ulong gBitMasks16Bpp565RGB[] = { 0xF800, 0x07E0,  0x001F};
ulong gBitMasks16Bpp565BGR[] = { 0x001F, 0x07E0, 0xF800 };
ulong gBitMasks24Bpp888BGR[] = { 0x0000FF, 0x00FF00, 0xFF0000 };
ulong gBitMasks24Bpp888RGB[] = { 0xFF0000, 0x00FF00, 0x0000FF };
ulong gBitMasks32Bpp888BGR[] = { 0x0000FF, 0x00FF00, 0xFF0000 };
ulong gBitMasks32Bpp888RGB[] = { 0xFF0000, 0x00FF00, 0x0000FF };

#endif /*__MODE_LCDC__*/

//! @}

////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/LCDC/mode.h $
////////////////////////////////////////////////////////////////////////////////
//
//! @}
