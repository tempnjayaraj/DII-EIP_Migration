//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{	
//
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		PhyInterface.h
//!
//! \brief		declaration for the Common PHY Interface 
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/Emacb/PhyInterface.h $
//!   $Author: ltourlonias $
//!   $Revision: 684 $
//!   $Date: 2007-04-13 14:35:48 +0200 (ven., 13 avr. 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	EMAC
//! @{

//! \addtogroup	PHY
//! @{	

#define SPEED_100	100
#define SPEED_10	10

/// MAC information structure needed by the PHY
typedef struct {
	void (*read_phy)(PVOID pDeviceLocation, unsigned char phy_addr, unsigned char address, DWORD *dwValue); //!< \brief function to read a PHY register
	void (*write_phy)(PVOID pDeviceLocation, unsigned char phy_addr, unsigned char address, DWORD dwValue); //!< \brief function to write a PHY register
	PVOID pDeviceLocation;	//!< \brief MAC's base address
} T_MAC_INFO;

/// PHY configuration structure
typedef struct {
	DWORD	dwSpeed; 	//!< \brief Link Speed
	BOOL bFullDuplex;	//!< \brief Full or Half Duplex
	BOOL bAutoNegociation;	//!< \brief indicates if Autonegociation is active or not
	BOOL bRMII;				//!< \brief indicates wether the PHY is used in RMII mode
} T_PHY_CONFIGURATION;

typedef struct {
	BOOL (*PHY_Reset)				(T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr);
	BOOL (*PHY_SetConfiguration)	(T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr, T_PHY_CONFIGURATION* pPhyCfg);
	BOOL (*PHY_GetConfiguration)	(T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr, T_PHY_CONFIGURATION* pPhyCfg);
	BOOL (*PHY_StartAutoNegociation)(T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr);
	BOOL (*PHY_WaitForLink)			(T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr, DWORD dwTimeout);
	BOOL (*PHY_WaitForAutonegociationComplete) (T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr, DWORD dwTimeout);
	BOOL (*PHY_GetID)				(T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr,DWORD* pdwID);
	BOOL (*PHY_CheckID)				(T_MAC_INFO *pMacInfo,unsigned char ucPhyAddr);
	const WCHAR* wzName;
}T_PHY_INTERFACE;




static __inline T_PHY_INTERFACE* FindPhy(T_MAC_INFO *pMacInfo, T_PHY_INTERFACE *PhyList[], DWORD dwNbEntries, UCHAR *pucPhyAddress)
{
#define MAX_PHY_ADDRESS		16
	DWORD i;
	T_PHY_INTERFACE** pCurrentPhy = &(PhyList[0]);
	
	if (pucPhyAddress == NULL)
	{
		return NULL;
	}
		
	for (i=0;i<dwNbEntries;i++)
	{
		for (*pucPhyAddress=0;*pucPhyAddress<MAX_PHY_ADDRESS;(*pucPhyAddress)++)
		{
			if (pCurrentPhy[i]->PHY_CheckID(pMacInfo,*pucPhyAddress))
			{
				return pCurrentPhy[i];
			}
			
		}		
	}
	return FALSE;
}


//! @}
//! @}
//! @}