//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9263/DRIVERS/LCDC/LCDC2DGE.cpp
//!
//! \brief		Implementation of LCDC2DGE class
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/DRIVERS/LCDC/lcdc2dge.cpp $
//!   $Author: pblanchard $
//!   $Revision: 1021 $
//!   $Date: 2007-06-20 08:50:46 -0700 (Wed, 20 Jun 2007) $
//! \endif
//!
//-----------------------------------------------------------------------------
//! \addtogroup	LCDC
//! @{
//
//! \addtogroup LCDC63
//! @{	
//
//! \addtogroup	2DGE
//! @{
#include "lcdc2dge.h"

//-----------------------------------------------------------------------------
//! \brief		Class constructor
//-----------------------------------------------------------------------------
LCDC2DGE::LCDC2DGE(AT91PS_LCDC pLCDC, BOOL bUseInterrupt)
{
	PHYSICAL_ADDRESS PhysicalAddress_2DGE;
	PHYSICAL_ADDRESS PhysicalAddress_PMC;

	DEBUGMSG(1, (TEXT("-> LCDC2DGE constructor")));

	InitializeCriticalSection(&m_CriticalSection);

	m_pLCDC = pLCDC;
	m_pPMC = NULL;
	m_p2DGE = NULL;
	m_dwSysintr = 0;
	m_hHWFifoEmptyEvent = NULL;
	

	PhysicalAddress_PMC.LowPart = (DWORD) AT91C_BASE_PMC;
	PhysicalAddress_PMC.HighPart = 0;
	m_pPMC = (AT91PS_PMC) MmMapIoSpace(PhysicalAddress_PMC,sizeof(AT91S_PMC),FALSE);

	if (m_pPMC == NULL)
	{
		RETAILMSG(1,(TEXT("Unable to remap PMC ! Hardware Acceleration is disabled\r\n")));
		return;
	}
	m_pPMC->PMC_PCER =  1 << AT91C_ID_2DGE;
	
	PhysicalAddress_2DGE.LowPart = (DWORD) AT91C_BASE_2DGE;
	PhysicalAddress_2DGE.HighPart = 0;
	m_p2DGE = (AT91PS_2DGE) MmMapIoSpace(PhysicalAddress_2DGE,sizeof(AT91S_2DGE),FALSE);

	if (m_p2DGE == NULL)
	{
		RETAILMSG(1,(TEXT("Unable to remap 2DGE ! Hardware Acceleration is disabled\r\n")));
		return;
	}

	if (bUseInterrupt)
	{
		DWORD dwLogintr = AT91C_ID_2DGE;			
		bUseInterrupt = FALSE;

		// Mapping LogIntr to SysIntr
		if (KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &dwLogintr, sizeof(dwLogintr), &m_dwSysintr, sizeof(m_dwSysintr), 0))
		{
			//Create the IST's event
			if ((m_hHWFifoEmptyEvent = CreateEvent(NULL,FALSE,FALSE,NULL)) != NULL)
			{
				// Initialize Inteerupt
				if (InterruptInitialize(m_dwSysintr, m_hHWFifoEmptyEvent, 0, 0))
				{
					bUseInterrupt = TRUE;
				}
				else
				{				
					RETAILMSG(1,(TEXT("Failed to initialize LCDC interrupt!\r\n")));					
				}
			}
			else
			{
				RETAILMSG(1,(TEXT("Unable to create event for LCDC interrupt!\r\n")));
			}
		}
		else
		{
			RETAILMSG(1,(TEXT("Unable to request Sysintr for LCDC !\r\n")));
		}

		if (bUseInterrupt == FALSE) // If there was a problem, deallocate everything
		{

			if (m_dwSysintr)
			{
				m_dwSysintr = 0;
				InterruptDisable(m_dwSysintr);
				KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, &m_dwSysintr, sizeof(m_dwSysintr), NULL,0,0);				
			}
			if (m_hHWFifoEmptyEvent)
			{
				m_hHWFifoEmptyEvent = NULL;
				CloseHandle(m_hHWFifoEmptyEvent);
			}
		}

	}

	m_EstimatedFifoFreeSpace = HW_FIFO_MAX_SIZE;

	DEBUGMSG(1, (TEXT("<- LCDC2DGE constructor")));
}

//-----------------------------------------------------------------------------
//! \brief		Class destructor
//-----------------------------------------------------------------------------
LCDC2DGE::~LCDC2DGE()
{

	if (m_dwSysintr)
	{
		m_dwSysintr = 0;
		InterruptDisable(m_dwSysintr);
		KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, &m_dwSysintr, sizeof(m_dwSysintr), NULL,0,0);				
	}
	if (m_hHWFifoEmptyEvent)
	{
		m_hHWFifoEmptyEvent = NULL;
		CloseHandle(m_hHWFifoEmptyEvent);
	}

	if (m_p2DGE != NULL)
	{
		MmUnmapIoSpace(m_p2DGE,sizeof(AT91S_2DGE));
	}
	if (m_pPMC != NULL)
	{
		MmUnmapIoSpace(m_pPMC,sizeof(AT91S_PMC));
	}

}

//-----------------------------------------------------------------------------
//! \brief	We do not use the FIFO: The current design does not allow FIFO writes to clip registers.
//!         check the buffer empty AND line/blit engine busy status if you are toggling
//          between direct write and command queue write. You have to be careful not to write
//          directly to the registers until any previous commands in the queue have been completed.
//-----------------------------------------------------------------------------
BOOL LCDC2DGE::ClipSet( WORD minclipx, WORD minclipy, WORD maxclipx, WORD maxclipy)
{
	m_p2DGE->CXMINR = minclipx;
	m_p2DGE->CXMAXR = maxclipx;
	m_p2DGE->CYMINR = minclipy;
	m_p2DGE->CYMAXR = maxclipy;

	return TRUE;
}

//-----------------------------------------------------------------------------
//! \brief	Clipping is not deactivated after each use
//-----------------------------------------------------------------------------
BOOL LCDC2DGE::ClipActivated( BOOL On)
{
	if (On)
		m_p2DGE->CCR = CLIPPING_ON;
	else
		m_p2DGE->CCR = CLIPPING_OFF;

	return TRUE;
}

//-----------------------------------------------------------------------------
//! \brief		This functions allow the configuration of the 2D Engine 
//! \param bpp	pixel depth
//! \param dwVideoMemWidthInPixels	Width of the video mempry in pixels
//! \param dwVideoMemBusWidth	Width of the bus of the video mempry (8 bits, 16 bits or 32 bits)
//! \param dwVisibleSurfaceAddr Base address of the video memory (MUST be 1MByte-aligned)
//-----------------------------------------------------------------------------
void LCDC2DGE::Configure(T_BPP_2DGE bpp,DWORD dwVideoMemWidthInPixels,DWORD dwVideoMemBusWidth, DWORD dwVisibleSurfaceAddr)
{
	DWORD dwVSize = 0xFFFFFFFF;
	if (bpp == BPP_24)
	{
		RETAILMSG(1,(TEXT("24 BPP format selected !!! not yet implemented !\r\n")));
	}

	m_p2DGE->BPPR = bpp;
	m_p2DGE->DFR = LITTLE_ENDIAN_2DGE_FMT;
	if (dwVisibleSurfaceAddr & ((1<<20)-1))
	{
		RETAILMSG(1,(TEXT("LCDC2DGE::Configure !!! WARNING !!! Video RAM should be 1 MB aligned \r\n")));
	}
	
	if(bpp == BPP_24)
	{
		m_p2DGE->VOR = (dwVisibleSurfaceAddr >> 20);
	}
	else 
	{
		m_p2DGE->VOR = (dwVisibleSurfaceAddr >> 20);
	}

	
	switch (dwVideoMemWidthInPixels)
	{
		case 512 : dwVSize = 0; break;
		case 1024 : dwVSize = 1; break;
		case 2048 : dwVSize = 2; break;
		case 256 : dwVSize = 3; break;
	}
	switch (dwVideoMemBusWidth)
	{
		case 8 : dwVSize += 0; break;
		case 16 : dwVSize += 4; break;
		case 32  : dwVSize += 8; break;		
	}


	if (dwVSize != 0xFFFFFFFF)
	{
		m_p2DGE->VSR = dwVSize;
	}
	else
	{
		RETAILMSG(1,(TEXT("Invalid 2DGE configuration ! Review Bus Width and Video Mem width\r\n")));
	}

	if (m_hHWFifoEmptyEvent)
	{
		m_p2DGE->GIMR = QUEUE_EMPTY;
	}
}

//-----------------------------------------------------------------------------
//! \brief		Push a command struct in the queue
//!
//! \param		pData Pointer to data that we are going to push into the swFifo
//! \param		NbWord Nb of word (2 Bytes) that the method should push on the swFifo
//! \param		bUseInterrupt TODO
//! \return		TRUE indicates success, FALSE indicates failure
//-----------------------------------------------------------------------------
BOOL LCDC2DGE::Push(WORD* pData, DWORD NbWord,BOOL bUseInterrupt)
{
	if (m_p2DGE == NULL)
	{
		return FALSE;
	}

	if (!( (NbWord==sizeof(T_BLT_CMD)/2) || (NbWord==sizeof(T_LINE_CMD)/2) ))
	{
		RETAILMSG(1, (TEXT("FIFO::Push : Unknown CMD!\r\n")));
		return FALSE;
	}
		
	EnterCriticalSection(&m_CriticalSection);

	if (m_p2DGE->CQSR & QUEUE_EMPTY)
	{
		m_EstimatedFifoFreeSpace = HW_FIFO_MAX_SIZE;
	}
	if (m_EstimatedFifoFreeSpace < NbWord)
	{
		// wait for the fifo to be empty
		if (WaitForHWFifoEmpty(bUseInterrupt) == FALSE)
		{	
			LeaveCriticalSection(&m_CriticalSection);	
			return FALSE;
		}
		m_EstimatedFifoFreeSpace = HW_FIFO_MAX_SIZE;
	}
	
	for (DWORD i=0;i<NbWord;i++)
	{
		m_p2DGE->CQR = pData[i];		// do the push in the fifo...	
	}
	m_EstimatedFifoFreeSpace -= NbWord;

	LeaveCriticalSection(&m_CriticalSection);	
	return TRUE;
}

//-----------------------------------------------------------------------------
//! \brief		Blocking call, return when the HW pipeline is empty
//-----------------------------------------------------------------------------
BOOL LCDC2DGE::WaitForHWFifoEmpty(BOOL bUseInterrupt)
{
	DWORD dwDate;
	if (m_p2DGE == NULL)
		return FALSE;

	dwDate = GetTickCount() + HW_FIFO_TIMEOUT;
	while (((m_p2DGE->CQSR & QUEUE_EMPTY) == 0) && (dwDate > GetTickCount())) // Wait for HW Fifo empty
	{
		if (m_hHWFifoEmptyEvent && bUseInterrupt)
		{
			WaitForSingleObject(m_hHWFifoEmptyEvent, HW_FIFO_TIMEOUT);
			m_p2DGE->GIR = QUEUE_EMPTY; // Clear the interrupt
			InterruptDone(m_dwSysintr);
		}			
	}
	if ((m_p2DGE->CQSR & QUEUE_EMPTY) == 0)
	{
		DEBUGMSG(1, (TEXT("WaitForHWFifoEmpty: FIFO not empty even after the interrupt !")));
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

BOOL LCDC2DGE::WaitForOperationComplete(DWORD dwFlags,DWORD dwTimeout)
{
	DWORD dwEndDate = GetTickCount() + dwTimeout;
	
	dwFlags &= (BLT_OP | LINE_OP);
	
	while ((m_p2DGE->GSR & dwFlags) && ((INT32) (dwEndDate - GetTickCount()) > 0))
	{
		Sleep(0);
	};
	return TRUE;
}
// Doxygen End of group 2DGE
//! @} 
// Doxygen End of group LCDC63
//! @}
// Doxygen End of group LCDC
//! @}
// Doxygen End of group Driver
//! @}

////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/DRIVERS/LCDC/lcdc2dge.cpp $
////////////////////////////////////////////////////////////////////////////////
//
