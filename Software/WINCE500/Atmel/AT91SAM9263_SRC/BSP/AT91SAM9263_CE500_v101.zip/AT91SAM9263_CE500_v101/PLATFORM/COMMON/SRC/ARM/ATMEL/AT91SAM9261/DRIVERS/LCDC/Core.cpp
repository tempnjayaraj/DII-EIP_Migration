//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//
//!	\file		AT91SAM9261/DRIVERS/LCDC/core.cpp
//
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9261EK/SRC/DRIVERS/NandFlash/LLD_K9F1G08U0A.c $
//!   $Author: pgal $
//!   $Revision: 493 $
//!   $Date: 2007-03-02 16:28:38 +0100 (ven., 02 mars 2007) $
//! \endif
//  All rights reserved ADENEO SAS 2005
//
//-----------------------------------------------------------------------------
//! \addtogroup	LCDC
//! @{

//! \addtogroup	LCDC61
//! @{

//! \addtogroup Core
//! @{

// System include
#include <windows.h>
#include <oal.h>

// Local include
#include "at91sam926x.h"
#include "lib_at91sam926x.h"

#define LCDC_HCLK_ENABLE    (1 << 17)
#define LCDC_CORECLK_ENABLE (1 << 12)
#define LCDC_PCKR_ID        4

void LCDCProcSpecificInitPMC(void)
{	
	AT91PS_PMC	pPMC;
	PHYSICAL_ADDRESS PhysicalAddress;

	PhysicalAddress.HighPart = 0;
	PhysicalAddress.LowPart = (DWORD) AT91C_BASE_PMC;
	pPMC = (AT91PS_PMC ) MmMapIoSpace(PhysicalAddress,sizeof(AT91S_PMC),FALSE);

	//Initialize the clock management
	pPMC->PMC_SCER = LCDC_HCLK_ENABLE;
	pPMC->PMC_PCKR[LCDC_PCKR_ID] = (AT91C_PMC_CSS_PLLA_CLK | 4);
	pPMC->PMC_SCER = LCDC_CORECLK_ENABLE;
	pPMC->PMC_PCER = ((unsigned int) 1 << AT91C_ID_LCDC);

	MmUnmapIoSpace((PVOID) pPMC, sizeof(AT91S_PMC));

}

void LCDCProcSpecificActivatePMC(void)
{
	AT91PS_PMC	pPMC;
	PHYSICAL_ADDRESS PhysicalAddress;

	PhysicalAddress.HighPart = 0;
	PhysicalAddress.LowPart = (DWORD) AT91C_BASE_PMC;
	pPMC = (AT91PS_PMC ) MmMapIoSpace(PhysicalAddress,sizeof(AT91S_PMC),FALSE);
	
	// Enable the clock to the LCDC
	pPMC->PMC_PCER = ((unsigned int) 1 << AT91C_ID_LCDC);
	
	MmUnmapIoSpace((PVOID) pPMC, sizeof(AT91S_PMC));
}

void LCDCProcSpecificDeactivatePMC(void)
{
	AT91PS_PMC	pPMC;
	PHYSICAL_ADDRESS PhysicalAddress;

	PhysicalAddress.HighPart = 0;
	PhysicalAddress.LowPart = (DWORD) AT91C_BASE_PMC;
	pPMC = (AT91PS_PMC ) MmMapIoSpace(PhysicalAddress,sizeof(AT91S_PMC),FALSE);
	
	// Disable the clock to the LCDC
	pPMC->PMC_PCDR = ((unsigned int) 1 << AT91C_ID_LCDC);
	
	MmUnmapIoSpace((PVOID) pPMC, sizeof(AT91S_PMC));
}

DWORD LCDCProcSpecificGetLCDCBaseAddress(void)
{
	return (DWORD)AT91C_BASE_LCDC;
}


DWORD LCDCProcSpecificGetLCDCID(void)
{
	return (DWORD)AT91C_ID_LCDC;
}

//!@}

//! @}
//
//!@}
//
//!@}
