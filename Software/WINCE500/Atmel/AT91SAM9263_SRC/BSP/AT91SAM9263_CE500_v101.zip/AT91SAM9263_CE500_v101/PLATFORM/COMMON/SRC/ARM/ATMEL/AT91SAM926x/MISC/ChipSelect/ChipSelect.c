//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		ChipSelect.c
//!
//! \brief		ChipSelect management for the AT91SAM926x processors
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/MISC/ChipSelect/ChipSelect.c $
//!   $Author: pblanchard $
//!   $Revision: 1058 $
//!   $Date: 2007-07-05 01:34:39 -0700 (Thu, 05 Jul 2007) $
//! \endif
//-----------------------------------------------------------------------------


#include <windows.h>
#include <nkintr.h>
#include <oal.h>
#include "AT91SAM926x.h"
#include "AT91SAM926x_interface.h"
#include "AT91SAM926x.h"
#include "lib_AT91SAM926x.h"



#define MAX(x,y) ((x) > (y) ? (x):(y))
#define MIN(x,y) ((x) < (y) ? (x):(y))
#define ROUND_UP_TO_NEAREST_MULTIPLE(x,y) ((((x) + (y) - 1) / (y)) * (y))
#define ROUND_TO_NEAREST_MULTIPLE(x,y)    ((((x) + ((y)/2)) / (y)) * (y))

//-----------------------------------------------------------------------------
//! \brief		This function sets the chipselect timing in ns
//!
//! \param	pSMC
//! \param	dwChipSelect		ChipSelect
//! \param	dwMasterClock		Master clock frequency
//! \param	dwNWE_SETUP		NWE_SETUP Timing wanted
//! \param	dwNCS_WR_SETUP		NCS_WR_SETUP Timing wanted
//! \param	dwNRD_SETUP		NRD_SETUP Timing wanted
//! \param	dwNCS_RD_SETUP		NCS_RD_SETUP Timing wanted
//! \param	dwNWE_PULSE		NWE_PULSE Timing wanted
//! \param	dwNCS_WR_PULSE		NCS_WR_PULSE Timing wanted
//! \param	dwNRD_PULSE		NRD_PULSE Timing wanted
//! \param	dwNCS_RD_PULSE		NCS_RD_PULSE Timing wanted
//! \param	dwNRD_CYCLE		NRD_CYCLE Timing wanted
//! \param	dwNWE_CYCLE		NWE_CYCLE Timing wanted
//!
//! \return	always TRUE
//!
//-----------------------------------------------------------------------------
BOOL AT91SAM926x_SetChipSelectTimingIn_ns(	AT91PS_SMC pSMC			,
											DWORD dwChipSelect		,
											DWORD dwMasterClock		,
											DWORD dwNWE_SETUP		,
											DWORD dwNCS_WR_SETUP	,
											DWORD dwNRD_SETUP		,
											DWORD dwNCS_RD_SETUP	,
											DWORD dwNWE_PULSE		,										
											DWORD dwNCS_WR_PULSE	,
											DWORD dwNRD_PULSE		,
											DWORD dwNCS_RD_PULSE	,
											DWORD dwNRD_CYCLE		,
											DWORD dwNWE_CYCLE		)
{

	DWORD dwClockPeriod_ns	;

	DWORD temp				;

	DWORD dw_r_SETUP		;
	DWORD dw_r_NWE_SETUP	;
	DWORD dw_r_NCS_WR_SETUP	;
	DWORD dw_r_NRD_SETUP	;
	DWORD dw_r_NCS_RD_SETUP	;

	DWORD dw_r_PULSE		;
	DWORD dw_r_NWE_PULSE	;
	DWORD dw_r_NCS_WR_PULSE	;
	DWORD dw_r_NRD_PULSE	;
	DWORD dw_r_NCS_RD_PULSE	;

	DWORD dw_r_CYCLE		;
	DWORD dw_r_NRD_CYCLE	;
	DWORD dw_r_NWE_CYCLE	;

	AT91_REG* pSMC_SETUP	;
	AT91_REG* pSMC_PULSE	;	
	AT91_REG* pSMC_CYCLE	;
	AT91_REG* pSMC_CTRL		;

	

	// Compute the HOLD time
	/*
	dwNWE_HOLD		= dwNWE_CYCLE - dwNWE_SETUP		- dwNWE_PULSE;
	if ((int)dwNWE_HOLD <0)
	{
		dwNWE_HOLD = 0;
	}
	dwNCS_WR_HOLD		= dwNWE_CYCLE - dwNCS_WR_SETUP	- dwNCS_WR_PULSE;
	if ((int)dwNCS_WR_HOLD <0)
	{
		dwNCS_WR_HOLD = 0;
	}
	dwNDR_HOLD		= dwNRD_CYCLE - dwNRD_SETUP		- dwNRD_PULSE;
	if ((int)dwNDR_HOLD <0)
	{
		dwNDR_HOLD = 0;
	}
	dwNCS_RD_HOLD		= dwNRD_CYCLE - dwNCS_RD_SETUP	- dwNCS_RD_PULSE;
	if ((int)dwNCS_RD_HOLD <0)
	{
		dwNCS_RD_HOLD = 0;
	}
	*/


	pSMC_SETUP	= &(pSMC->SMC_SETUP0) + 4*dwChipSelect;
	pSMC_PULSE	= &(pSMC->SMC_PULSE0) + 4*dwChipSelect;
	pSMC_CYCLE	= &(pSMC->SMC_CYCLE0) + 4*dwChipSelect;
	pSMC_CTRL		= &(pSMC->SMC_CTRL0 ) + 4*dwChipSelect;

	DEBUGMSG(1,(TEXT("---------------------------------------\r\n")));
	DEBUGMSG(1,(TEXT("--- Configuring Chip Select %d       ---\r\n"),dwChipSelect));
	DEBUGMSG(1,(TEXT("---------------------------------------\r\n")));
	DEBUGMSG(1,(TEXT("---         Desired timings         ---\r\n")));
	DEBUGMSG(1,(TEXT("---------------------------------------\r\n")));
	DEBUGMSG(1,(TEXT("dwNWE_SETUP      %d\r\n"), dwNWE_SETUP		));
	DEBUGMSG(1,(TEXT("dwNCS_WR_SETUP   %d\r\n"), dwNCS_WR_SETUP	));
	DEBUGMSG(1,(TEXT("dwNRD_SETUP      %d\r\n"), dwNRD_SETUP		));
	DEBUGMSG(1,(TEXT("dwNCS_RD_SETUP   %d\r\n"), dwNCS_RD_SETUP	));
	DEBUGMSG(1,(TEXT("dwNWE_PULSE      %d\r\n"), dwNWE_PULSE		));
	DEBUGMSG(1,(TEXT("dwNCS_WR_PULSE   %d\r\n"), dwNCS_WR_PULSE	));
	DEBUGMSG(1,(TEXT("dwNRD_PULSE      %d\r\n"), dwNRD_PULSE		));
	DEBUGMSG(1,(TEXT("dwNCS_RD_PULSE   %d\r\n"), dwNCS_RD_PULSE	));
	DEBUGMSG(1,(TEXT("dwNRD_CYCLE      %d\r\n"), dwNRD_CYCLE		));
	DEBUGMSG(1,(TEXT("dwNWE_CYCLE      %d\r\n"), dwNWE_CYCLE		));

	// Getting Clock period frequency
	dwMasterClock = ROUND_TO_NEAREST_MULTIPLE(dwMasterClock,1000000);
	dwClockPeriod_ns = (1000000000 + dwMasterClock - 1) / dwMasterClock; // round up 1000000000 / dwMasterClock

	DEBUGMSG(1,(TEXT("dwClockPeriod_ns %d\r\n"), dwClockPeriod_ns	));

	// Verify that value are dwClockPeriod_ns compatible (round them to the integer clock value)
		dwNWE_SETUP = ROUND_UP_TO_NEAREST_MULTIPLE(dwNWE_SETUP, dwClockPeriod_ns);
	dwNWE_PULSE = ROUND_UP_TO_NEAREST_MULTIPLE(dwNWE_PULSE, dwClockPeriod_ns);
	dwNWE_CYCLE = ROUND_UP_TO_NEAREST_MULTIPLE(dwNWE_CYCLE, dwClockPeriod_ns);
		
		dwNCS_WR_SETUP = ROUND_UP_TO_NEAREST_MULTIPLE(dwNCS_WR_SETUP, dwClockPeriod_ns);
		dwNCS_WR_PULSE = ROUND_UP_TO_NEAREST_MULTIPLE(dwNCS_WR_PULSE, dwClockPeriod_ns);

	dwNWE_CYCLE = MAX(dwNWE_CYCLE,dwNWE_SETUP + dwNWE_PULSE);	
	dwNWE_CYCLE = MAX(dwNWE_CYCLE,dwNCS_WR_SETUP + dwNCS_WR_PULSE);

		dwNRD_SETUP = ROUND_UP_TO_NEAREST_MULTIPLE(dwNRD_SETUP, dwClockPeriod_ns);
	dwNRD_PULSE = ROUND_UP_TO_NEAREST_MULTIPLE(dwNRD_PULSE, dwClockPeriod_ns);
	dwNRD_CYCLE = ROUND_UP_TO_NEAREST_MULTIPLE(dwNRD_CYCLE, dwClockPeriod_ns);

		dwNCS_RD_SETUP = ROUND_UP_TO_NEAREST_MULTIPLE(dwNCS_RD_SETUP, dwClockPeriod_ns);
		dwNCS_RD_PULSE = ROUND_UP_TO_NEAREST_MULTIPLE(dwNCS_RD_PULSE, dwClockPeriod_ns);


	dwNRD_CYCLE = MAX(dwNRD_CYCLE,dwNRD_SETUP + dwNRD_PULSE);
	dwNRD_CYCLE = MAX(dwNRD_CYCLE,dwNCS_RD_SETUP + dwNCS_RD_PULSE);


	// Compute differents register value
	
	//-------------------------------------------------------------------------
	//
	// NWE setup length = (128* NWE_SETUP[5] + NWE_SETUP[4:0]) clock cycles
	temp = dwNWE_SETUP / dwClockPeriod_ns;
	if (temp >= 0x20)
	{
		temp = MAX(0x80,temp);
		temp = MIN(temp,0x9F);
		temp = ((temp>>7) << 5)  | (temp & 0x1F);
	}
	dw_r_NWE_SETUP		= temp;

	// NCS setup length = (128* NCS_WR_SETUP[5] + NCS_WR_SETUP[4:0]) clock cycles
	temp = dwNCS_WR_SETUP / dwClockPeriod_ns;
	if (temp >= 0x20)
	{
		temp = MAX(0x80,temp);
		temp = MIN(temp,0x9F);
		temp = ((temp>>7) << 5)  | (temp & 0x1F);
	}
	dw_r_NCS_WR_SETUP	= temp;

	// NRD setup length = (128* NRD_SETUP[5] + NRD_SETUP[4:0]) clock cycles
	temp = dwNRD_SETUP /dwClockPeriod_ns;
	if (temp >= 0x20)
	{
		temp = MAX(0x80,temp);
		temp = MIN(temp,0x9F);
		temp = ((temp>>7) << 5)  | (temp & 0x1F);
	}
	dw_r_NRD_SETUP		= temp;

	// NCS setup length = (128* NCS_RD_SETUP[5] + NCS_RD_SETUP[4:0]) clock cycles
	temp = dwNCS_RD_SETUP / dwClockPeriod_ns;
	if (temp >= 0x20)
	{
		temp = MAX(0x80,temp);
		temp = MIN(temp,0x9F);
		temp = ((temp>>7) << 5)  | (temp & 0x1F);
	}
	dw_r_NCS_RD_SETUP	= temp;
	
	// SETUP Register
	dw_r_SETUP = (dw_r_NCS_RD_SETUP<<24) | (dw_r_NRD_SETUP<<16) | (dw_r_NCS_WR_SETUP<<8) | (dw_r_NWE_SETUP<<0);

	//-------------------------------------------------------------------------
	//
	// NWE pulse length = (256* NWE_PULSE[6] + NWE_PULSE[5:0]) clock cycles
	temp = dwNWE_PULSE / dwClockPeriod_ns;
	if (temp >= 0x40)
	{
		temp = MAX(0x100,temp);
		temp = MIN(temp,0x13F);
		temp = ((temp>>8) << 6)  | (temp & 0x3F);
	}
	dw_r_NWE_PULSE		= temp;
	

	// NCS pulse length = (256* NCS_WR_PULSE[6] + NCS_WR_PULSE[5:0]) clock cycles
	temp = dwNCS_WR_PULSE / dwClockPeriod_ns;	
	if (temp >= 0x40)
	{
		temp = MAX(0x100,temp);
		temp = MIN(temp,0x13F);
		temp = ((temp>>8)<< 6)  | (temp & 0x3F);
	}
	dw_r_NCS_WR_PULSE		= temp;

	// NRD pulse length = (256* NRD_PULSE[6] + NRD_PULSE[5:0]) clock cycles
	temp = dwNRD_PULSE / dwClockPeriod_ns;
	if (temp >= 0x40)
	{
		temp = MAX(0x100,temp);
		temp = MIN(temp,0x13F);
		temp = ((temp>>8) << 6)  | (temp & 0x3F);
	}
	dw_r_NRD_PULSE		= temp;
	
	

	// NCS pulse length = (256* NCS_RD_PULSE[6] + NCS_RD_PULSE[5:0]) clock cycles
	temp = dwNCS_RD_PULSE / dwClockPeriod_ns;
	if (temp >= 0x40)
	{
		temp = MAX(0x100,temp);
		temp = MIN(temp,0x13F);
		temp = ((temp>>8) << 6)  | (temp & 0x3F);
	}
	dw_r_NCS_RD_PULSE	= temp;
	
	
	// PULSE Register
	dw_r_PULSE = (dw_r_NCS_RD_PULSE<<24) | (dw_r_NRD_PULSE<<16) | (dw_r_NCS_WR_PULSE<<8) | (dw_r_NWE_PULSE<<0);

	//-------------------------------------------------------------------------
	//
	// Write cycle length = (NWE_CYCLE[8:7]*256 + NWE_CYCLE[6:0]) clock cycles
	temp = dwNWE_CYCLE / dwClockPeriod_ns;
	if (temp >= 0x80)
	{
		temp = MAX(0x100,temp);
		temp = MIN(temp,0x37F);
		temp = ((temp>>8) << 7)  | (temp & 0x7F);
	}
	dw_r_NWE_CYCLE		= temp;

	// Read cycle length = (NRD_CYCLE[8:7]*256 + NRD_CYCLE[6:0]) clock cycles
	temp = dwNRD_CYCLE / dwClockPeriod_ns;
	if (temp >= 0x80)
	{
		temp = MAX(0x100,temp);
		temp = MIN(temp,0x37F);
		temp = ((temp>>8) << 7)  | (temp & 0x7F);
	}
	dw_r_NRD_CYCLE		= temp;

	// CYCLE Register
	dw_r_CYCLE = (dw_r_NRD_CYCLE<<16) | (dw_r_NWE_CYCLE<<0);

	// Writing all registers 
	*pSMC_SETUP = dw_r_SETUP;
	*pSMC_PULSE = dw_r_PULSE;
	*pSMC_CYCLE = dw_r_CYCLE;

	// Display small message resuming the changes:
	DEBUGMSG(1,(TEXT("---------------------------------------\r\n")));
	DEBUGMSG(1,(TEXT("---           Real timings          ---\r\n")));
	DEBUGMSG(1,(TEXT("---------------------------------------\r\n")));
	DEBUGMSG(1,(TEXT("dwNWE_SETUP      %d\r\n"), (((dw_r_NWE_SETUP		&0x0020)>>5)*128 + (dw_r_NWE_SETUP		&0x1F))*dwClockPeriod_ns));
	DEBUGMSG(1,(TEXT("dwNCS_WR_SETUP   %d\r\n"), (((dw_r_NCS_WR_SETUP	&0x0020)>>5)*128 + (dw_r_NCS_WR_SETUP	&0x1F))*dwClockPeriod_ns));
	DEBUGMSG(1,(TEXT("dwNRD_SETUP      %d\r\n"), (((dw_r_NRD_SETUP		&0x0020)>>5)*128 + (dw_r_NRD_SETUP		&0x1F))*dwClockPeriod_ns));
	DEBUGMSG(1,(TEXT("dwNCS_RD_SETUP   %d\r\n"), (((dw_r_NCS_RD_SETUP	&0x0020)>>5)*128 + (dw_r_NCS_RD_SETUP	&0x1F))*dwClockPeriod_ns));
	DEBUGMSG(1,(TEXT("dwNWE_PULSE      %d\r\n"), (((dw_r_NWE_PULSE		&0x0040)>>6)*256 + (dw_r_NWE_PULSE		&0x3F))*dwClockPeriod_ns));
	DEBUGMSG(1,(TEXT("dwNCS_WR_PULSE   %d\r\n"), (((dw_r_NCS_WR_PULSE	&0x0040)>>6)*256 + (dw_r_NCS_WR_PULSE	&0x3F))*dwClockPeriod_ns));
	DEBUGMSG(1,(TEXT("dwNRD_PULSE      %d\r\n"), (((dw_r_NRD_PULSE		&0x0040)>>6)*256 + (dw_r_NRD_PULSE		&0x3F))*dwClockPeriod_ns));
	DEBUGMSG(1,(TEXT("dwNCS_RD_PULSE   %d\r\n"), (((dw_r_NCS_RD_PULSE	&0x0040)>>6)*256 + (dw_r_NCS_RD_PULSE	&0x3F))*dwClockPeriod_ns));
	DEBUGMSG(1,(TEXT("dwNRD_CYCLE      %d\r\n"), (((dw_r_NRD_CYCLE		&0x0180)>>7)*256 + (dw_r_NRD_CYCLE		&0x7F))*dwClockPeriod_ns));
	DEBUGMSG(1,(TEXT("dwNWE_CYCLE      %d\r\n"), (((dw_r_NWE_CYCLE		&0x0180)>>7)*256 + (dw_r_NWE_CYCLE		&0x7F))*dwClockPeriod_ns));


	return TRUE;
}


//------------------------------------------------------------------------------
//! @}


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/MISC/ChipSelect/ChipSelect.c $
////////////////////////////////////////////////////////////////////////////////
//
