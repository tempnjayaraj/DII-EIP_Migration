//-----------------------------------------------------------------------------
//! \addtogroup   Serial
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				AT91RM9200_SerialDriver.h
//!
//! \brief				Header for Serial driver
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/DRIVERS/Serial/AT91RM9200_SerialDriver.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------



#ifndef __AT91RM9200_SERIALDRIVER_H__
#define __AT91RM9200_SERIALDRIVER_H__

#include "AT91RM9200_serial.h"


// PDC mamagement
#define RX_BUFFERS				4

#define SIZE_OF_PDC_TX_BUFFER	128

#define SIZE_OF_PDC_FIRST		1
#define SIZE_OF_PDC_NEXT		2047
#define FIFO_THRESOLD			(SIZE_OF_PDC_FIRST + SIZE_OF_PDC_NEXT)
#define SIZE_OF_PDC_FIFO		RX_BUFFERS * FIFO_THRESOLD

#define GET_RCR_SIZE			SIZE_OF_PDC_FIRST //((pInitContext->pUSARTRegs->US_RPR == pInitContext->pDMACommonRxBuffer[pHWHead->dwCurrentRxBuffer].LowPart) ? SIZE_OF_PDC_FIRST : SIZE_OF_PDC_NEXT)
#define GET_RNCR_SIZE			SIZE_OF_PDC_NEXT //((pInitContext->pUSARTRegs->US_RPR == pInitContext->pDMACommonRxBuffer[pHWHead->dwNextRxBuffer].LowPart) ? SIZE_OF_PDC_FIRST : SIZE_OF_PDC_NEXT)


// Buffer usage : 
// The first byte of the buffer, is assign to the pdc first buffer register. And the size minus une byte is 
// assign to the pdc next buffer.



// Timeouts management
#define DEFAULT_READINTERVALTIMEOUT				0	
#define DEFAULT_READTOTALTIMEOUTMULTIPLIER		0
#define DEFAULT_READTOTALTIMEOUTCONSTANT		0
#define DEFAULT_WRITETOTALTIMEOUTMULTIPLIER		0
#define DEFAULT_WRITETOTALTIMEOUTCONSTANT		0



// Structures
/*! \struct T_SERIALINIT_STRUCTURE
\brief Init context structure
*/
typedef struct {
	PVOID pMDDContext;				//!< First arg to mdd callback
	PHWOBJ pHWObj;
	
	// Device specific
	DWORD dwDeviceIndex;			//!< Software uart device index
	DWORD dwDeviceId;				//!< Internal peripheral ID (PMC usage)
	PVOID pHardwareContext;			//!< Hardware context sent in parameter of each sepcific hardware function
	DWORD dwIntMask;					//!< INterrupt Mask
	LPCLEARRTS pfnClearRTS;			//!< Device specific RTS management
	LPSETRTS pfnSetRTS;				//!< Device specific RTS management

	LPCLEARDTR pfnClearDTR;			//!< Device specific DTR management
	LPSETDTR pfnSetDTR;				//!< Device specific DTR management

	LPCLEARBREAK pfnClearBreak;		//!< Device specific Break management
	LPSETBREAK pfnSetBreak;			//!< Device specific Break management
	DWORD dwBufferedCSR;

	// Registers
	volatile AT91PS_PMC		pPMCReg;		//!< Access to PMC registers
	volatile AT91PS_USART	pUSARTReg;		//!< Access to USART registers
	volatile AT91PS_PDC		pPDCReg;		//!< Access to PDC registers

	// Properties
	COMMPROP    commProp;			//!< CommProp structure.
	DMA_ADAPTER_OBJECT dmaAdapter;	//!< DMA object for DMA buffers allocation
    COMMTIMEOUTS commTimeouts;		//!< Copy of CommTimeouts structure
	DCB	dcb;						//!< 

	// Status and Error
	COMSTAT lpStat ;
	DWORD dwErrors;


	// Buffers
	PVOID vDMACommonTxBuffer;							//!< Virtual Tx Buffer
	PVOID vDMACommonRxBuffer[RX_BUFFERS];				//!< Virtual Rx Buffers
	PHYSICAL_ADDRESS pDMACommonTxBuffer;				//!< Physical Tx Buffer
	PHYSICAL_ADDRESS pDMACommonRxBuffer[RX_BUFFERS];	//!< Physical Rx Buffers

	DWORD dwCurrentRxBuffer;

	// Critical sections
	CRITICAL_SECTION	csUsartReg;	//!< USART register access control

	DWORD dwIntRemModemStatus;		//!< Modem status backup for IT modem handler
	DWORD dwOpenCount;				//!< Opened device count
} T_SERIALINIT_STRUCTURE, *PT_SERIALINIT_STRUCTURE;


/*
// Public interfaces
PHWOBJ GetSerialObject(DWORD dwDeviceArrayIndex);
*/


// Internal usage

// Hardware Specific intialisation
extern DWORD HWSerialInit (DWORD dwDeviceIndex, LPCTSTR pContext, T_SERIAL_HW* pSerialHW);
extern BOOL HWSerialDeInit (PVOID pContext);
extern BOOL HWSerialInitPIO (PVOID pContext);

// Defines
// Registry keys
#define REG_SERIALPORTINDEX_VAL_NAME	TEXT("SerialPortIndex") 
#define REG_SERIALPORTINDEX_VAL_LEN		sizeof( DWORD )


// Extracted from com_mdd2\mmd.c
#ifdef DEBUG
    #define DBG_INIT    0x0001
    #define DBG_OPEN    0x0002
    #define DBG_READ    0x0004
    #define DBG_WRITE   0x0008
    #define DBG_CLOSE   0x0010
    #define DBG_IOCTL   0x0020
    #define DBG_THREAD  0x0040
    #define DBG_EVENTS  0x0080
    #define DBG_CRITSEC 0x0100
    #define DBG_FLOW    0x0200
    #define DBG_IR      0x0400
    #define DBG_NOTHING 0x0800
    #define DBG_ALLOC   0x1000
    #define DBG_FUNCTION 0x2000
    #define DBG_WARNING 0x4000
    #define DBG_ERROR   0x8000
#endif


#endif // #define __AT91RM9200_SERIALDRIVER_H__

//! @}
