//------------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//   All rights reserved ADENEO SAS 2005
//!
//------------------------------------------------------------------------------
//! \file		Serial_SAM926X_DbgZones.h
//!
//! \if subversion
//!   @URL: $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/Serial/Serial_SAM926X_DbgZones.h $
//!   @author $Author: pgal $
//!   @version $Revision: 916 $
//!   @date $Date: 2007-05-31 06:54:57 -0700 (Thu, 31 May 2007) $
//! \endif
//------------------------------------------------------------------------------
//! \addtogroup	Serial
//! @{
    
#ifndef __SERIAL_DBG_H_
#define __SERIAL_DBG_H_

//------------------------------------------------------------------------------
//                                                             Defines and types
//------------------------------------------------------------------------------
	#define DBG_INIT    0x0001
    #define DBG_OPEN    0x0002
    #define DBG_READ    0x0004
    #define DBG_WRITE   0x0008
    #define DBG_CLOSE   0x0010
    #define DBG_IOCTL   0x0020
    #define DBG_THREAD  0x0040
    #define DBG_EVENTS  0x0080
    #define DBG_CRITSEC 0x0100
    #define DBG_FLOW    0x0200
    #define DBG_IR      0x0400
    #define DBG_NOTHING 0x0800
    #define DBG_ALLOC   0x1000
    #define DBG_FUNCTION 0x2000
    #define DBG_WARNING 0x4000
    #define DBG_ERROR   0x8000

#endif	// __SERIAL_DBG_H

//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/Serial/Serial_SAM926X_DbgZones.h $
//------------------------------------------------------------------------------
//

//
//! @}
//
//! @}
