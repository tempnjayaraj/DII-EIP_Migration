//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//!
//! \brief		Custom PWMC IOCTLs declaration file
//
//! \file	AT91SAM9263_pwmc_ioctl.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/INC/IOCTL/AT91SAM9263_pwmc_ioctl.h $
//!   $Author: pblanchard $
//!   $Revision: 1058 $
//!   $Date: 2007-07-05 01:34:39 -0700 (Thu, 05 Jul 2007) $
//! \endif
//!
//! IOControl used by application for interaction with the PWMC driver
//-----------------------------------------------------------------------------
//! \addtogroup	PWMC
//! @{


#ifndef __AT91SAM9263_PWMC_IOCTL_H__
#define __AT91SAM9263_PWMC_IOCTL_H__

// Functions
#define PWC_CONFIG_CMD		(2048 + 1)
#define IOCTL_PWC_START_CMD	(2048 + 2)
#define IOCTL_PWC_STOP_CMD	(2048 + 3)

#define IOCTL_PWC_CONFIG	CTL_CODE(FILE_DEVICE_SERIAL_PORT, PWC_CONFIG_CMD, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_PWC_START		CTL_CODE(FILE_DEVICE_SERIAL_PORT, IOCTL_PWC_START_CMD, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_PWC_STOP		CTL_CODE(FILE_DEVICE_SERIAL_PORT, IOCTL_PWC_STOP_CMD, METHOD_BUFFERED, FILE_ANY_ACCESS)

typedef struct
{
	DWORD dwFrequency;
	DWORD dwDutyCycle;
} T_IOCTLPWC_CONFIG;


#endif // __AT91SAM9263_PWMC_IOCTL_H__

// End of Doxygen group PWMC
//! @}
//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/INC/IOCTL/AT91SAM9263_pwmc_ioctl.h $
//-----------------------------------------------------------------------------
//


