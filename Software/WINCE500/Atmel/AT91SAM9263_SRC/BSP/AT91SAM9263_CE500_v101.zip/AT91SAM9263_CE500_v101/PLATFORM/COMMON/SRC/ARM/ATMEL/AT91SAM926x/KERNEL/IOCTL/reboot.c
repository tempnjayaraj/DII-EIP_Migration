//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		reboot.c
//!
//! \brief		AT91SAM926x's reboot feature
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/IOCTL/reboot.c $
//!   $Author: pblanchard $
//!   $Revision: 1058 $
//!   $Date: 2007-07-05 01:34:39 -0700 (Thu, 05 Jul 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

//! \addtogroup	IOCTL
//! @{

#include <windows.h>
#include <oal.h>

#include "at91sam926x.h"
#include "at91sam926x_oal_ioctl.h"

extern void OEMCacheRangeFlush(VOID *pAddress, DWORD length, DWORD flags);
extern void performSoftReboot(UINT32 pFunc);
extern void StartUp(void);
extern void NKForceCleanBoot(void);
extern DWORD g_dwSoftRebootMagic;
extern DWORD IOCTLProcSpecificGetRSTCBaseAddress(void);

//-----------------------------------------------------------------------------
//! \fn			static BOOL coldReboot()
//!
//! \brief		This functions triggers a cold reboot : Clean boot and assertion of the nRST pin
//!
//!
//!
//! \return		TRUE indicates success
//! \return		FALSE indicates failure (bad parameters)
//-----------------------------------------------------------------------------
static BOOL coldReboot()
{
#define RESET_LENGTH  1 //in number of slow clock period


	AT91PS_RSTC pResetCtrl = (AT91PS_RSTC) OALPAtoVA(IOCTLProcSpecificGetRSTCBaseAddress(),FALSE);

	if (pResetCtrl == NULL)
	{
		return FALSE;
	}

	//Force a clean boot next time (empty the object store)
	NKForceCleanBoot();
	//Set up the length of the nRST pin assertion.
	pResetCtrl->RSTC_RMR = (pResetCtrl->RSTC_RMR & AT91C_RSTC_URSTEN & AT91C_RSTC_URSTIEN) | (0xA5 << 24 ) | (RESET_LENGTH << 8);

	//Assert the nRST pin
	pResetCtrl->RSTC_RCR = (0xA5 << 24 ) | AT91C_RSTC_EXTRST | AT91C_RSTC_PROCRST | AT91C_RSTC_PERRST;

	return TRUE;
}

//-----------------------------------------------------------------------------
//! \fn			static BOOL softReboot()
//!
//! \brief		This functions triggers a soft reboot : only a jump at the beginning of the OS image
//!
//!
//!
//! \return		always FALSE
//-----------------------------------------------------------------------------
static BOOL softReboot()
{
	g_dwSoftRebootMagic = SOFT_REBOOT_MAGIC;
	RETAILMSG(1,(TEXT("g_dwSoftRebootMagic %x \r\n"),g_dwSoftRebootMagic));
	OEMCacheRangeFlush (0, 0, CACHE_SYNC_WRITEBACK);
	RETAILMSG(1,(TEXT("g_dwSoftRebootMagic %x \r\n"),g_dwSoftRebootMagic));
	g_dwSoftRebootMagic = SOFT_REBOOT_MAGIC;
	RETAILMSG(1,(TEXT("g_dwSoftRebootMagic %x \r\n"),g_dwSoftRebootMagic));
	performSoftReboot(OALVAtoPA(StartUp));
	return FALSE;
}

//-----------------------------------------------------------------------------
//! \fn			static BOOL warmReboot()
//!
//! \brief		This functions triggers a warm reboot : Internal reset (the nRST pin is not asserted)
//!
//!
//!
//! \return		TRUE indicates success
//! \return		FALSE indicates failure (bad parameters)
//-----------------------------------------------------------------------------
static BOOL warmReboot()
{
	AT91PS_RSTC pResetCtrl = (AT91PS_RSTC) OALPAtoVA(IOCTLProcSpecificGetRSTCBaseAddress(),FALSE);

	if (pResetCtrl == NULL)
	{
		return FALSE;
	}

	OEMCacheRangeFlush (0, 0, CACHE_SYNC_WRITEBACK);
	//Reset the processor and the internal peripheral
	pResetCtrl->RSTC_RCR = (0xA5 << 24 ) | AT91C_RSTC_PROCRST| AT91C_RSTC_PERRST;

	return TRUE;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL OALIoCtlHalReboot(	UINT32 code, VOID *pInpBuffer, UINT32 inpSize, VOID *pOutBuffer, UINT32 outSize, UINT32 *pOutSize)
//!
//! \brief		This function implements the IOCTL_HAL_REBOOT IOControl
//!				Reboot is not implemented yet
//!
//!	\param		code			not used
//!	\param		pInpBuffer	Reboot type
//!	\param		inpSize		sizeof(DWORD)
//!	\param		pOutBuffer	not used
//!	\param		outSize		not used
//!	\param		pOutSize		not used
//!
//! \return		TRUE indicates success
//! \return		FALSE indicates failure (bad parameters)
//-----------------------------------------------------------------------------
BOOL OALIoCtlHalReboot(UINT32 code, VOID *pInpBuffer, 
                       UINT32 inpSize, VOID *pOutBuffer, 
                       UINT32 outSize, UINT32 *pOutSize)
{	
	BOOL bResult;
	DWORD bootType = SOFT_BOOT;

	RETAILMSG(1, (TEXT("+OALIoCtlHalReboot\r\n")));

	if ((pInpBuffer != NULL) && (inpSize == sizeof(DWORD)))	
	{
		bootType = *(DWORD*) pInpBuffer;		
	}	

	switch (bootType)
	{
		case COLD_BOOT: 
			RETAILMSG(1, (TEXT("coldReboot\r\n")));
			bResult = coldReboot();
			break;
		case WARM_BOOT: 
			RETAILMSG(1, (TEXT("warmReboot\r\n")));
			bResult = warmReboot();
			break;
		case SOFT_BOOT: 
			RETAILMSG(1, (TEXT("softReboot\r\n")));
			bResult = softReboot();
			break;
		default:
			bResult = FALSE;
	}

	RETAILMSG(1, (TEXT("-OALIoCtlHalReboot (result = %s)\r\n"),bResult ? L"TRUE" : L"FALSE"));
    return bResult;
}

//! @} end of subgroup IOCTL

//! @} end of group OAL


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/IOCTL/reboot.c $
////////////////////////////////////////////////////////////////////////////////
//
