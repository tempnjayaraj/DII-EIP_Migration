//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//-----------------------------------------------------------------------------
//! \file		AT91SAM9263EK/SRC/BOOTLOADER/FirstBoot/main.c 
//!
//! \brief		The boot following ROM boot, permitting to copy eboot
//!				from a flash support to the SDRAM
//!
//! \if subversion
///   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/BOOTLOADER/FirstBoot/main.c $
//!   $Author: ltourlonias $
//!   $Revision: 684 $
//!   $Date: 2007-04-13 14:35:48 +0200 (ven., 13 avr. 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	FIRSTBOOT
//! @{
//!

//------------------------------------------------------------------------------
//                                                                      Includes
//------------------------------------------------------------------------------
// Standard includes
#include <windows.h>

// Atmel includes
#include "at91sam926x.h"
#include "AT91SAM9263EK.h"

// Configuration includes
#include "firstboot_cfg.h"	// Firstboot configuration (here for boot type choice)
#include "bootloader_cfg.h" // General bootloader settings
#include "bootloader_struct.h" // General bootloader settings

// Local includes
#include "sdram.h"			// Sdram include
#include "dbgu.h"			// Seriel debug include

#include "SPIDataFlash.h"

//------------------------------------------------------------------------------
//                                                            Imported functions
//------------------------------------------------------------------------------
extern void Jump(UINT32 addr); // Function import from startup.s file
extern unsigned long ComputeCRC32(unsigned char *buffer, int len); // Function import from CRC32.c file on SOC\common\Misc\CRC32 root 
extern DWORD AT91F_TestSdram(void);

//-----------------------------------------------------------------------------
//! \fn			void FIRSTBOOT_LowLevelInit(void)
//!
//! \brief		This function performs very low level HW initialization
//-----------------------------------------------------------------------------
void FIRSTBOOT_LowLevelInit(void)
{
  DWORD dwMasterClock;  
  AT91PS_USART pUSART = (AT91PS_USART) AT91C_BASE_DBGU;
  AT91PS_PDC pPDC = (AT91PS_PDC) &(pUSART->US_RPR);
  AT91PS_PIO pPioC = (AT91PS_PIO) AT91C_BASE_PIOC;

	dwMasterClock = AT91C_MASTER_CLOCK;

	//
	// Init the DBGU
	//
	// Configure PIO controllers to periph mode	
	pPioC->PIO_ASR = AT91C_PC30_DRXD | AT91C_PC31_DTXD ;
	pPioC->PIO_PDR = AT91C_PC30_DRXD | AT91C_PC31_DTXD ; 


	//Configure USART
	// Disable interrupts
    pUSART->US_IDR = (unsigned int) -1;

    // Reset receiver and transmitter
    pUSART->US_CR = AT91C_US_RSTRX | AT91C_US_RSTTX | AT91C_US_RXDIS | AT91C_US_TXDIS ;

	// Define the baud rate divisor register
	{
		unsigned int baud_value = ((dwMasterClock*10)/(DBGU_BAUDRATE * 16));
		if ((baud_value % 10) >= 5)
			baud_value = (baud_value / 10) + 1;
		else
			baud_value /= 10;
		 pUSART->US_BRGR = baud_value;
	}

	// Write the Timeguard Register
	pUSART->US_TTGR = 0;

    // Clear Transmit and Receive Counters

    // Disable the RX and TX PDC transfer requests
	pPDC->PDC_PTCR = AT91C_PDC_RXTDIS;
	pPDC->PDC_PTCR = AT91C_PDC_TXTDIS;

	// Reset all Counter register Next buffer first
	pPDC->PDC_TNPR = 0;
	pPDC->PDC_TNCR = 0;
	pPDC->PDC_RPR = 0;
	pPDC->PDC_RCR = 0;
	pPDC->PDC_RPR = 0;
	pPDC->PDC_RCR = 0;
	pPDC->PDC_TPR = 0;
	pPDC->PDC_TCR = 0;

    // Enable the RX and TX PDC transfer requests
	pPDC->PDC_PTCR = AT91C_PDC_RXTEN;
	pPDC->PDC_PTCR = AT91C_PDC_TXTEN;

    // Define the USART mode
    pUSART->US_MR = AT91C_US_ASYNC_MODE  ;

	// Enable Transmitter
	pUSART->US_CR = AT91C_US_RXEN;
	pUSART->US_CR = AT91C_US_TXEN;

	DbgPrint("\r\nINFO : Low Level Init : OK\r\n");

	//
	// Init SDRAM
	//
	AT91F_InitSdram();
}

//-----------------------------------------------------------------------------
//! \fn			void FIRSTBOOT_StartBoot(void)
//!
//! \brief		This function loads the second level bootloader (Eboot) to SDRAM
//-----------------------------------------------------------------------------
void FIRSTBOOT_StartBoot(void)
{
	UINT32 SizeToDownload = 0;
	UINT32 i = 0;

	volatile T_BOOTLOADER_FLASH_CONFIG *pBootFlashConfig = (T_BOOTLOADER_FLASH_CONFIG*)(BOOTLOADER_FLASH_CONFIG_ADDR);

	// Set flash configuration
	pBootFlashConfig->dwEbootCodeFlashAddr = EBOOT_FLASH_CODE_ADDR;
	pBootFlashConfig->dwEbootSettingsFlashAddr = EBOOT_FLASH_SETTINGS_ADDR;
	pBootFlashConfig->dwSize = sizeof(T_BOOTLOADER_FLASH_CONFIG);
	pBootFlashConfig->dwCrc32 = ComputeCRC32((UCHAR*)pBootFlashConfig, sizeof(T_BOOTLOADER_FLASH_CONFIG)-sizeof(DWORD));

	if (read_dataflash(EBOOT_FLASH_CODE_ADDR, EBOOT_MAX_SIZE, (unsigned char*)EBOOT_SDRAM_ADDR) <= 0)
	{
		DbgPrint("ERROR : Reading Eboot from DATAFLASH");
		while(1);
	}

	if(*(EBOOT_SDRAM_ADDR) == 0xFFFFFFFF)
	{
		DbgPrint("ERROR : Eboot Image is not valid...\n\r");
		while(1);	
	}

}

//-----------------------------------------------------------------------------
//! \fn			void main(void)
//!
//! \brief		This function is the entry point after the assembler file
//-----------------------------------------------------------------------------
void main(void) 
{
	AT91PS_PITC		pPITC			= AT91C_BASE_PITC;

	// Init low level
 	FIRSTBOOT_LowLevelInit(); 

	// Enable PIT for tempo
	pPITC->PITC_PIMR=0x010FFFFF;

	//Init Data flash
	DbgPrint("Init Data flash\r\n");
	AT91F_DataflashInit();

	//Load EBoot
	FIRSTBOOT_StartBoot();

	DbgPrint("Starting eboot ...\r\n");

	//Jump at start of EBoot
	Jump((UINT32)EBOOT_SDRAM_ADDR);

	while(1);
}


//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/BOOTLOADER/FirstBoot/main.c $
//------------------------------------------------------------------------------

//
//! @}
//

//! @}