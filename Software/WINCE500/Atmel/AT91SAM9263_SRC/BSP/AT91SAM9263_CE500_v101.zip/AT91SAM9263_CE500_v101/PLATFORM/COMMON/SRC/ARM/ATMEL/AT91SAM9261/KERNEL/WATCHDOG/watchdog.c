//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9261/KERNEL/WATCHDOG/watchdog.c
//!
//! \brief		AT91SAM9261 processor's watchdog
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9261/KERNEL/WATCHDOG/watchdog.c $
//!   $Author: ltourlonias $
//!   $Revision: 1030 $
//!   $Date: 2007-06-22 05:09:32 -0700 (Fri, 22 Jun 2007) $
//! \endif
//-----------------------------------------------------------------------------


#include <windows.h>

#include "at91sam926x.h"


//-----------------------------------------------------------------------------
//! \fn			DWORD WatchdogProcSpecificGetWDTCBaseAddress(void)
//!
//! \brief		This function returns the WDTC base adress
//!
//! \return		WDTC base adress
//!
//-----------------------------------------------------------------------------
DWORD WatchdogProcSpecificGetWDTCBaseAddress(void)
{
	return (DWORD) AT91C_BASE_WDTC;
}

//-----------------------------------------------------------------------------
//! \fn			DWORD WatchdogProcSpecificGetClockFrequency(void)
//!
//! \brief		This function returns the clock frequency
//!
//! \return		clock frequency
//!
//-----------------------------------------------------------------------------
DWORD WatchdogProcSpecificGetClockFrequency(void)
{
	return (DWORD) SLOW_CLOCK_FREQUENCY;
}

//------------------------------------------------------------------------------

//! @}


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9261/KERNEL/WATCHDOG/watchdog.c $
////////////////////////////////////////////////////////////////////////////////
//
