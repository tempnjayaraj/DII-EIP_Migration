//-----------------------------------------------------------------------------
//! \addtogroup	MISC
//! @{
//
//  All rights reserved ADENEO SAS 2005
//! \file		atmel_gpio.h
//!
//! \brief		Header description
//!
//-----------------------------------------------------------------------------
//!
//! \if subversion
///   @URL: $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/atmel_gpio.h $
//!   @author $Author: ltourlonias $
//!   @version $Revision: 657 $
//!   @date $Date: 2007-06-07 16:52:09 +0200 (mar., 10 avr. 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	GPIO
//! @{

#ifndef __ATMEL_GPIO_H__
#define __ATMEL_GPIO_H__

//------------------------------------------------------------------------------
//                                                                      Includes
//------------------------------------------------------------------------------
// Project includes
#include "at91sam926x.h"


//------------------------------------------------------------------------------
//                                                               Defines & Types
//------------------------------------------------------------------------------
/* I/O type */
enum  pio_type {
	PIO_PERIPH_A,
	PIO_PERIPH_B,
	PIO_INPUT,
	PIO_OUTPUT,
	PIO_UNDEFINED
};
/* I/O attributes */
#define PIO_DEFAULT   (0 << 0)
#define PIO_PULLUP    (1 << 0)
#define PIO_DEGLITCH  (1 << 1)
#define PIO_OPENDRAIN (1 << 2)

struct pio_desc {
	const char *pin_name;   /* Pin Name */
	unsigned int pin_num;   /* Pin number */
	unsigned int dft_value; /* Default value for outputs */
	unsigned char attribute;
	enum pio_type type;
};

typedef struct {
	AT91PS_PIO pBase;
	DWORD nbPin; //Not every PIO controller support the same number of pin.
	DWORD currentPin;//This is used to maintain a round robin priority system within the same PIO bank
	DWORD status; // this is use to maintain the value of PIO_ISR because it's cleared after each reading
	DWORD logintrBase; //This is the logintr associated with pin 0 of the bank
	DWORD deviceID; //this is to configure the AIC
	AT91PS_PIO vPioBase;
	DWORD resumeMask;
} T_PIO_BANK_DESCRIPTION;

#define END_OF_PIO {NULL, 0, 0, 0, PIO_UNDEFINED}

//------------------------------------------------------------------------------
//                                                            Exported functions
//------------------------------------------------------------------------------

#ifdef __cplusplus
extern "C" int pio_setup (const struct pio_desc *pio_desc, int nb_pio);
extern "C" void pio_set_value (unsigned pin, int value);
extern "C" int pio_get_value (unsigned pin);
#else
/* pio_device_pio_setup: Configure PIO in periph mode according to the platform informations */
extern int pio_setup (const struct pio_desc *pio_desc, int nb_pio);
extern void pio_set_value (unsigned pin, int value);
extern int pio_get_value (unsigned pin);
#endif


#endif /* __ATMEL_GPIO_H__*/
//! @}
//! @}
