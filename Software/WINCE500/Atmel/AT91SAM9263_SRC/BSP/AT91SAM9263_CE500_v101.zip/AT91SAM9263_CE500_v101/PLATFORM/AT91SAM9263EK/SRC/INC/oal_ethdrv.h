//-----------------------------------------------------------------------------
//! \addtogroup	EMACB
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		oal_ethdrv.h
//!
//! \brief		Header file defining the EMACB ethdbg interface
//!
//! \if subversion
//!   $URL: http://centaure/svn/thales_navigation-bsp_nadia2ek/TRUNK/WINCE500/PLATFORM/nadia2EK/SRC/INC/oal_ethdrv.h $
//!   $Author: jjhiblot $
//!   $Revision: 18 $
//!   $Date: 2005-12-19 15:16:58 +0100 (lun., 19 déc. 2005) $
//! \endif
//-----------------------------------------------------------------------------

#ifndef __OAL_ETHDRV_H__
#define __OAL_ETHDRV_H__

//------------------------------------------------------------------------------
// Prototypes for EMACB functions

BOOL   EMACInit(UINT8 *pAddress, UINT32 offset, UINT16 mac[3]);
UINT16 EMACSendFrame(UINT8 *pBuffer, UINT32 length);
UINT16 EMACGetFrame(UINT8 *pBuffer, UINT16 *pLength);
VOID   EMACEnableInts();
VOID   EMACDisableInts();
VOID   EMACCurrentPacketFilter(UINT32 filter);
BOOL   EMACMulticastList(UINT8 *pAddresses, UINT32 count);
// This function doesn't belong to the standard MS API
void   EMACSetAddressMac(UINT8 *pAddress, UINT16 mac[3]);

#define OAL_ETHDRV_EMACB   { \
    EMACInit, NULL, NULL, EMACSendFrame, EMACGetFrame, \
    EMACEnableInts, EMACDisableInts, \
    NULL, NULL,  EMACCurrentPacketFilter, EMACMulticastList \
}

#endif

//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/thales_navigation-bsp_nadia2ek/TRUNK/WINCE500/PLATFORM/nadia2EK/SRC/INC/oal_ethdrv.h $
//-----------------------------------------------------------------------------
//