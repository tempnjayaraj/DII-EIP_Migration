//-----------------------------------------------------------------------------
//! \addtogroup   SDMMC
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				AT91RM9200_diskio.c
//!
//! \brief				Windows CE SDMMC Card driver
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/DRIVERS/Sdcard/AT91RM9200_diskio.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//-----------------------------------------------------------------------------

#include <windows.h>
#include <nkintr.h>
#include <diskio.h>
#include <storemgr.h>
#include <devload.h>

#include "AT91RM9200.h"
#include "lib_AT91RM9200.h"
#include "AT91RM9200_MCI_Device.h"
#include "AT91RM9200_sdmmc.h"

#define WRITING_THREAD_PRIORITY 20

#define REG_PROFILE_KEY     TEXT("Profile")
#define DEFAULT_PROFILE     TEXT("Default")
#define	MAX_SECTORS		1

char dataBuffer[1024];

extern BOOL SDMMC_ControllerBoardSpecificPIOInitialization(void);
extern BOOL SDMMC_IsWriteProtected(void);

AT91PS_MCI g_pMCI = NULL;
AT91PS_PDC g_pPDC = NULL;
AT91PS_PMC g_pPMC = NULL;

//------------------------------------------------------------------------------
//
// Function to open the driver key specified by the active key
//
// The caller is responsible for closing the returned HKEY
//
//------------------------------------------------------------------------------
HKEY
OpenDriverKey(
    LPTSTR ActiveKey
    )
{
    TCHAR DevKey[256];
    HKEY hDevKey;
    HKEY hActive;
    DWORD ValType;
    DWORD ValLen;
    DWORD status;

    //
    // Get the device key from active device registry key
    //
    status = RegOpenKeyEx(
                HKEY_LOCAL_MACHINE,
                ActiveKey,
                0,
                0,
                &hActive);
    if (status) {
        DEBUGMSG(ZONE_INIT|ZONE_ERROR, (TEXT("RAM:OpenDriverKey RegOpenKeyEx(HLM\\%s) returned %d!!!\r\n"), ActiveKey, status));
        return NULL;
    }

    hDevKey = NULL;

    ValLen = sizeof(DevKey);
    status = RegQueryValueEx(
                hActive,
                DEVLOAD_DEVKEY_VALNAME,
                NULL,
                &ValType,
                (PUCHAR)DevKey,
                &ValLen);
    if (status != ERROR_SUCCESS) 
    {
        DEBUGMSG(ZONE_INIT|ZONE_ERROR, (TEXT("RAM:OpenDriverKey - RegQueryValueEx(%s) returned %d\r\n"), DEVLOAD_DEVKEY_VALNAME, status));
        goto odk_fail;
    }

    //
    // Get the geometry values from the device key
    //
    status = RegOpenKeyEx(
                HKEY_LOCAL_MACHINE,
                DevKey,
                0,
                0,
                &hDevKey);
    if (status) 
    {
        hDevKey = NULL;
        DEBUGMSG(ZONE_INIT|ZONE_ERROR, (TEXT("RAM:OpenDriverKey RegOpenKeyEx - DevKey(HLM\\%s) returned %d!!!\r\n"), DevKey, status));
    }

odk_fail:
    RegCloseKey(hActive);
    return hDevKey;
}   // OpenDriverKey


//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
BOOL GetDeviceInfo(PDISK pDisk, PSTORAGEDEVICEINFO pInfo)
{
    BOOL fRet = FALSE;
    HKEY hKeyDriver;
    DWORD dwBytes;
    DWORD dwStatus;
    DWORD dwValType;

    if(pDisk && pInfo)
    {
        _tcsncpy(pInfo->szProfile, DEFAULT_PROFILE, PROFILENAMESIZE);
        __try
        {
            hKeyDriver = OpenDriverKey(pDisk->d_ActivePath);
            if(hKeyDriver)
            {
                // read the profile string from the active reg key if it exists
                dwBytes = sizeof(pInfo->szProfile);
                dwStatus = RegQueryValueEx(hKeyDriver, REG_PROFILE_KEY, NULL, &dwValType, (PBYTE)&pInfo->szProfile, &dwBytes);
                
                // if this fails, szProfile will contain the default string
            }

            // set our class, type, and flags
            pInfo->dwDeviceClass = STORAGE_DEVICE_CLASS_BLOCK;
       		pInfo->dwDeviceType = STORAGE_DEVICE_TYPE_UNKNOWN | STORAGE_DEVICE_TYPE_REMOVABLE_MEDIA;


			if (SDMMC_IsWriteProtected())
			{
				pInfo->dwDeviceFlags = STORAGE_DEVICE_FLAG_READONLY;
			}
			else
			{
				pInfo->dwDeviceFlags = STORAGE_DEVICE_FLAG_READWRITE;
			}           
            fRet = TRUE;
        }
        __except(EXCEPTION_EXECUTE_HANDLER)
        {
            SetLastError(ERROR_INVALID_PARAMETER);
            fRet = FALSE;
        }
    }
    return fRet;
}

//------------------------------------------------------------------------------
//
// Function to retrieve the folder name value from the driver key. The folder name is
// used by FATFS to name this disk volume.
//
//------------------------------------------------------------------------------
BOOL
GetFolderName(
    PDISK pDisk,
    LPWSTR FolderName,
    DWORD cBytes,
    DWORD * pcBytes
    )
{
    HKEY DriverKey;
    DWORD ValType;
    DWORD status;

    DriverKey = OpenDriverKey(pDisk->d_ActivePath);
    if (DriverKey)
	{
        *pcBytes = cBytes;
        status = RegQueryValueEx(
                    DriverKey,
                    TEXT("Folder"),
                    NULL,
                    &ValType,
                    (PUCHAR)FolderName,
                    pcBytes);
        if (status != ERROR_SUCCESS)
		{
            DEBUGMSG(ZONE_INIT|ZONE_ERROR,(TEXT("RAM:GetFolderName - RegQueryValueEx(Folder) returned %d\r\n"), status));
            *pcBytes = 0;
        }
		else
		{
            DEBUGMSG(ZONE_INIT|ZONE_ERROR, (TEXT("RAM:GetFolderName - FolderName = %s, length = %d\r\n"), FolderName, *pcBytes));
           *pcBytes += sizeof(WCHAR); // account for terminating 0.
        }

        RegCloseKey(DriverKey);
        if (status || (*pcBytes == 0))
		{
            // Use default
            return FALSE; 
        }

        return TRUE;
    }
    
    return FALSE;
}

//------------------------------------------------------------------------------
//
// DeallocateVirtual - deallocate virtual memory required for this driver
//
//------------------------------------------------------------------------------
VOID DeallocateVirtual()
{
	DEBUGMSG(ZONE_INIT, (TEXT("+SDMMC: DeallocateVirtual entered\r\n")));
	
	if (g_pMCI) 
	{
		MmUnmapIoSpace(g_pMCI, sizeof(AT91S_MCI));
	}
	g_pMCI = NULL;
	
	if (g_pPDC) 
	{
		MmUnmapIoSpace(g_pPDC, sizeof(AT91S_PDC));
	}
	g_pPDC = NULL;

	if (g_pPMC) 
	{
		MmUnmapIoSpace(g_pPMC, sizeof(AT91S_PMC));
	}
	g_pPMC = NULL;

	DEBUGMSG(ZONE_INIT, (TEXT("-SDMMC: DeallocateVirtual done\r\n")));
}

//------------------------------------------------------------------------------
//
// AllocateVirtual - allocate virtual memory required for this driver
//
//------------------------------------------------------------------------------
BOOL AllocateVirtual()
{

	PHYSICAL_ADDRESS PA_MCIReg, PA_PDCReg, PA_PMCReg;

	DEBUGMSG(ZONE_INIT, (TEXT("+SDMMC: AllocateVirtual entered\r\n")));

	PA_MCIReg.QuadPart	= (LONGLONG) AT91C_BASE_MCI;
	g_pMCI = (AT91PS_MCI) MmMapIoSpace(PA_MCIReg, sizeof(AT91S_MCI), FALSE);

	PA_PDCReg.QuadPart	= (LONGLONG) AT91C_BASE_PDC_MCI ;
	g_pPDC = (AT91PS_PDC) MmMapIoSpace(PA_PDCReg, sizeof(AT91S_PDC), FALSE);

	PA_PMCReg.QuadPart	= (LONGLONG) AT91C_BASE_PMC;
	g_pPMC = (AT91PS_PMC) MmMapIoSpace(PA_PMCReg, sizeof(AT91S_PMC), FALSE);


	if (g_pMCI == NULL ||	g_pPDC == NULL || g_pPMC == NULL)
	{
		DeallocateVirtual();
		return FALSE;
	}

	DEBUGMSG(ZONE_INIT, (TEXT("-SDMMC: AllocateVirtual done\r\n")));

	return TRUE;
}


//----------------------------------------------------------------------------
// 
// ConfigPMC Enable Peripheral clock in PMC for  MCI
//
//----------------------------------------------------------------------------
VOID ConfigPMC (VOID)
{
	AT91F_PMC_EnablePeriphClock(g_pPMC, ((unsigned int) 1 << AT91C_ID_MCI));
}


//----------------------------------------------------------------------------
//
// ConfigPDC - Disable TX and RX reset transfer descriptors, re-enable RX and TX
//
//----------------------------------------------------------------------------
VOID ConfigPDC (VOID)
{
//	AT91F_PDC_Open (g_pPDC);

	//* Disable the RX and TX PDC transfer requests
	AT91F_PDC_DisableRx(g_pPDC);
	AT91F_PDC_DisableTx(g_pPDC);
	AT91F_PDC_SetTx(g_pPDC, (char *) 0, 0);
	AT91F_PDC_SetRx(g_pPDC, (char *) 0, 0);


	vDMACommonTxBuffer = NULL;
	vDMACommonRxBuffer = NULL;

	dmaAdapterObject.ObjectSize = sizeof(DMA_ADAPTER_OBJECT);
    dmaAdapterObject.InterfaceType = PCIBus ;
    dmaAdapterObject.BusNumber = 0 ;

	vDMACommonTxBuffer=HalAllocateCommonBuffer(&dmaAdapterObject,SIZE_OF_PDC_TX_BUFFER,&(pDMACommonTxBuffer),FALSE);
    if (vDMACommonTxBuffer == NULL)
	{
		DEBUGMSG(ZONE_IO, (TEXT("ConfigPDC:HalAllocateCommonBuffer failed")));
	}


	vDMACommonRxBuffer=HalAllocateCommonBuffer(&dmaAdapterObject, SIZE_OF_PDC_RX_BUFFER,&(pDMACommonRxBuffer),FALSE);
    if (vDMACommonRxBuffer == NULL)
	{
		DEBUGMSG(ZONE_IO, (TEXT("ConfigPDC:HalAllocateCommonBuffer failed")));
	}

}

//------------------------------------------------------------------------------
//
// InitDisk - allocate resources associated with the specified disk
//			- initialize the hardware
//			- fill the structure describing the disk
//------------------------------------------------------------------------------
BOOL InitDisk(PDISK pDisk)
{
	RETAILMSG(1, (TEXT("SDMMC:InitDisk with pDisk 0x%x\r\n"), pDisk));
				
    DEBUGMSG(ZONE_INIT, (TEXT("SDMMC:InitDisk with pDisk 0x%x\r\n"), pDisk));
	
	// Allocate the memory area that will be used to access the hard drive
	// hint : see virtualalloc and virtualcopy (using PAGE_PHYSICAL flag)

	if (AllocateVirtual())
	{
	
		SDMMC_ControllerBoardSpecificPIOInitialization(); 
		AT91F_MCI_Configure(
			g_pMCI, 
			AT91C_MCI_DTOR_1MEGA_CYCLES,    //DTOR
			0x838F,							//MR - CLKDIV = 0x8F
			AT91C_MCI_MMC_SLOTA	); 
		ConfigPMC();						//enable clock for MCI
		ConfigPDC();						//initialize PDC
	// wait for AT91C_MCI_NOTBUSY flag to be set.
//	AT91F_MCIDeviceWaitReady(pDisk->MciDevice,AT91C_MCI_TIMEOUT,pDisk);
		

		// Disable all the interrupts
	    g_pMCI->MCI_IDR = 0xFFFFFFFF;
	

		if (pDisk)
		{		
			DWORD dwLogIntr;
			//Allocate a Sysintr for our driver
			dwLogIntr = AT91C_ID_MCI;
			if (!KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &dwLogIntr, sizeof(dwLogIntr), &pDisk->dwSysIntr, sizeof(pDisk->dwSysIntr), NULL))
			{
				RETAILMSG(1, (TEXT("ERROR: Failed to request the serial sysintr for MCI controller (logintr :%d).\r\n"),dwLogIntr));
				pDisk->dwSysIntr = SYSINTR_UNDEFINED;
				return FALSE;
			}
			else
			{
				pDisk->hInterruptEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
				if (pDisk->hInterruptEvent == NULL)
					return FALSE;
				if (!InterruptInitialize(pDisk->dwSysIntr,pDisk->hInterruptEvent,0,0) ) 
				{
					return FALSE;
				}
			}

			
			if(AT91F_MCI_SDCard_Init(pDisk->MciDevice,pDisk) != AT91C_INIT_OK)
			{
				RETAILMSG(1, (TEXT("SDCard Initialisation failed\n\r")));
				return FALSE;	
			}
			RETAILMSG(1, (TEXT("SDCard Initialisation Successful 2\n\r")));
				
	

			
			
            pDisk->d_DiskInfo.di_total_sectors = (pDisk->MciDevice->pMCI_DeviceFeatures->Memory_Capacity) / SD_BYTES_PER_SECTOR;
			pDisk->d_DiskInfo.di_bytes_per_sect = 	SD_BYTES_PER_SECTOR;

				//pDisk->MciDevice->pMCI_DeviceFeatures->Sector_Size;
			pDisk->d_DiskInfo.di_cylinders = 0; //
			pDisk->d_DiskInfo.di_heads = 0;		//CHS not used for FAT FS
			pDisk->d_DiskInfo.di_sectors = 0;	//
			pDisk->d_DiskInfo.di_flags = DISK_INFO_FLAG_CHS_UNCERTAIN;
			pDisk->d_DiskInfo.di_flags |= DISK_INFO_FLAG_PAGEABLE;
			

			DEBUGMSG(ZONE_IO,(TEXT("SDMMC:DiskInfo TotalSec:%d SecSize:%d Cyls:%d Hds:%d EstSecs:%d\r\n"),
				pDisk->d_DiskInfo.di_total_sectors,
				pDisk->d_DiskInfo.di_bytes_per_sect,
				pDisk->d_DiskInfo.di_cylinders,
				pDisk->d_DiskInfo.di_heads,
				pDisk->d_DiskInfo.di_sectors));
		}
		else return FALSE;
	}
	else
	{
		RETAILMSG(1, (TEXT("InitDisk : AllocateVirtual failed.\n\r")));
		return FALSE;
	}


	AT91F_MCI_Configure(
		g_pMCI, 
		AT91C_MCI_DTOR_1MEGA_CYCLES,    //DTOR
		0x8300,							//MR - CLKDIV = 2
		AT91C_MCI_MMC_SLOTA	); 


	pDisk->MciDevice->pMCI_DeviceDesc->state = AT91C_MCI_IDLE;

return TRUE;
}

//------------------------------------------------------------------------------
//
// DeinitDisk - free all resources associated with the specified disk
//
//------------------------------------------------------------------------------
VOID DeinitDisk(PDISK pDisk)
{
	DEBUGMSG(ZONE_IO, (TEXT("+SDMMC:DeinitDisk entered\r\n")));
	
	if (pDisk->hInterruptEvent)
	{
		CloseHandle(pDisk->hInterruptEvent);
	}
	if (pDisk->dwSysIntr != SYSINTR_UNDEFINED)
	{
		DWORD dummy;		
		InterruptDisable(pDisk->dwSysIntr);
		KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, (PVOID)&pDisk->dwSysIntr,sizeof(pDisk->dwSysIntr), NULL, 0, &dummy);
	}

	AT91F_PMC_DisablePeriphClock(g_pPMC, ((unsigned int) 1 << AT91C_ID_MCI));
	DeallocateVirtual();

	if (vDMACommonTxBuffer )
	{
		HalFreeCommonBuffer(&dmaAdapterObject,SIZE_OF_PDC_TX_BUFFER,pDMACommonTxBuffer,vDMACommonTxBuffer,FALSE);
	}
	if (vDMACommonRxBuffer )
	{
		HalFreeCommonBuffer(&dmaAdapterObject,2*SIZE_OF_PDC_RX_BUFFER,pDMACommonRxBuffer,vDMACommonRxBuffer,FALSE);
	}

    DEBUGMSG(ZONE_IO, (TEXT("-SDMMC:DeinitDisk with pDisk 0x%x done\r\n"), pDisk));
}



//------------------------------------------------------------------------------
//
// DoDiskIO - Perform requested I/O.
//            This function is called from DSK_IOControl.
//
// Requests are serialized using the disk's critical section.
//
//------------------------------------------------------------------------------
DWORD
DoDiskIO(
    PDISK pDisk,
    DWORD Opcode,
    PSG_REQ pSgr)
{
    DWORD status = ERROR_SUCCESS;

    pSgr->sr_status = ERROR_IO_PENDING;

    if (pSgr->sr_num_sg > MAX_SG_BUF)
	{
        status = ERROR_INVALID_PARAMETER;
    }
    else if ((pSgr->sr_start + pSgr->sr_num_sec - 1) > pDisk->d_DiskInfo.di_total_sectors)
	{
        status = ERROR_SECTOR_NOT_FOUND; // request exceeded the disk
    }
	else
	{
		status = ERROR_SUCCESS;

		EnterCriticalSection(&(pDisk->d_DiskCardCrit));

		if (pDisk->d_DiskCardState != STATE_OPENED)
		{
			DEBUGMSG(ZONE_IO, (TEXT("SDMMC:DoDiskIO - Disk state != STATE_OPENED\r\n")));
		}
		else
		{
			//
			// Read or write sectors from/to disk.
			// NOTE: Multiple sectors may go in one scatter/gather buffer or one
			// sector may fit in multiple scatter/gather buffers.
			//
			if (Opcode == DISK_IOCTL_READ)
			{
				if (ReadData(pDisk, pSgr) == 0)
				{
					//RETAILMSG(1,(TEXT("SDMMC:DoDiskIO - ReadData failed\r\n")));
					status = ERROR_READ_FAULT;
				}
				//else
				//	RETAILMSG(1,(TEXT("SDMMC:DoDiskIO - ReadData OK")));
				
			}
			else 
			{
				if (Opcode == DISK_IOCTL_WRITE)
				{
					if (WriteData(pDisk, pSgr) == 0)
					{
						RETAILMSG(1,(TEXT("SDMMC:DoDiskIO - WriteData failed\r\n")));
						status = ERROR_WRITE_FAULT;
					}
					//else
					//	RETAILMSG(1,(TEXT("SDMMC:DoDiskIO - WriteData OK")));
				}

			}
		}

		LeaveCriticalSection(&(pDisk->d_DiskCardCrit));

		if (pDisk->d_DiskCardState != STATE_OPENED) {
			//
			// Disk probably closed due to suspend/resume.
			//
			status = GetDiskStateError(pDisk->d_DiskCardState);
		}
	}

    pSgr->sr_status = status;
    return status;
}   // DoDiskIO


//------------------------------------------------------------------------------
//
// Function to format this disk volume.
//
//------------------------------------------------------------------------------
DWORD 
FormatDisk(
	PDISK pDisk, 
	PDISK_INFO pInfo)
{
	return ERROR_SUCCESS;
}   // FormatDisk


//------------------------------------------------------------------------------
//
// GetDiskInfo - return disk info in response to DISK_IOCTL_GETINFO
//
//------------------------------------------------------------------------------
DWORD
GetDiskInfo(
    PDISK pDisk,
    PDISK_INFO pInfo
    )
{
    *pInfo = pDisk->d_DiskInfo;
    pInfo->di_flags |= DISK_INFO_FLAG_CHS_UNCERTAIN;
	pInfo->di_flags |= DISK_INFO_FLAG_PAGEABLE;
    return ERROR_SUCCESS;
}   // GetDiskInfo



//------------------------------------------------------------------------------
//
// SetDiskInfo - store disk info in response to DISK_IOCTL_SETINFO
//
//------------------------------------------------------------------------------
DWORD
SetDiskInfo(
    PDISK pDisk,
    PDISK_INFO pInfo
    )
{
    pDisk->d_DiskInfo = *pInfo;
    return ERROR_SUCCESS;
}   // SetDiskInfo


//------------------------------------------------------------------------------
//
// WriteData - Write a block of data
//
//------------------------------------------------------------------------------

unsigned long WriteData(PDISK pDisk, PSG_REQ pSgr)
{
	unsigned long ulBytesWritten = 0;
	unsigned long ulStartSector = pSgr->sr_start;
	unsigned long ulTotalSectors = pSgr->sr_num_sec;
	unsigned long ulNumSectors = 0;
	unsigned long ulNumSGs = pSgr->sr_num_sg;
	char          *pcPtr = 0;
	unsigned long ulTotalBytes = SD_BYTES_PER_SECTOR * ulTotalSectors;
	PSG_BUF       pSg = 0;
	unsigned long ulCurrentSG = 0;
	long          lBytesLeftSG = pSgr->sr_sglist[ulCurrentSG].sb_len;
	unsigned long size2write = 0;
	unsigned long indexSGbuf = 0;
	unsigned int  error;
	HANDLE currentThread = GetCurrentThread();
	DWORD oldThreadPriority=CeGetThreadPriority(currentThread);

	CeSetThreadPriority(currentThread,WRITING_THREAD_PRIORITY);

	DEBUGMSG(ZONE_IO, (TEXT("SDMMC:WriteData (2)- writing %d sectors starting at 0x%x; %d scatter/gather buffs\r\n"), pSgr->sr_num_sec,ulStartSector, pSgr->sr_num_sg));


	pcPtr = (char *) MapPtrToProcess((LPVOID) pSgr->sr_sglist[ulCurrentSG].sb_buf, GetCallerProcess());

	
	//
	// reading ulNumSectors into ulNumSGs
	//
	while (ulBytesWritten < ulTotalBytes)
	{
		if (!(lBytesLeftSG % SD_BYTES_PER_SECTOR)) 
			size2write = SD_BYTES_PER_SECTOR;
		else
			size2write = lBytesLeftSG;

		endianExchangeMemcpy(vDMACommonTxBuffer, (pcPtr + indexSGbuf), size2write);
					//           dest				     src
		lBytesLeftSG = lBytesLeftSG - size2write;
		indexSGbuf = indexSGbuf + size2write;
		error =	AT91F_MCI_WriteBlock(pDisk->MciDevice, ulStartSector*SD_BYTES_PER_SECTOR, (unsigned int*)pDMACommonTxBuffer.LowPart, size2write,pDisk);
		if(error != AT91C_WRITE_OK)
		{
			pDisk->MciDevice->pMCI_DeviceDesc->state = AT91C_MCI_IDLE;
			RETAILMSG(1,(TEXT("WriteData_error -> 0x%x"),error));
			return 0;
		}
		DEBUGMSG(ZONE_IO, (TEXT("SDMMC:WriteData - writing to %d sectors starting at %d\r\n"), ulNumSectors, ulStartSector));

		ulStartSector++;
		ulBytesWritten = ulBytesWritten + size2write;



			//
			// wait for drive before each sector
			//
		AT91F_MCIDeviceWaitReady(pDisk->MciDevice,AT91C_MCI_TIMEOUT,pDisk);
		pDisk->MciDevice->pMCI_DeviceDesc->state = AT91C_MCI_IDLE;

		//
		// check this SG buffer for data remaining
		//
		if (lBytesLeftSG <= 0)
		{
			if (++ulCurrentSG >= ulNumSGs) // no more scatter/gather buffers
				break;

			//
			// get next SG buffer and its length
			//
			pSg = &(pSgr->sr_sglist[ulCurrentSG]);
			pcPtr = (char *) MapPtrToProcess((LPVOID) pSg->sb_buf, GetCallerProcess());
			lBytesLeftSG = pSg->sb_len;
			indexSGbuf = 0;

			DEBUGMSG(ZONE_IO, (TEXT("SDMMC:WriteData -   writing from SG %d of %d, %ld bytes\r\n"), ulNumSGs - ulCurrentSG + 1, ulNumSGs, lBytesLeftSG));
			//if (lBytesLeftSG <= 0) // this buffer has no room
			//	continue;
		}

		

	}//while

	DEBUGMSG(ZONE_IO, (TEXT("SDMMC:WriteData (2)- Done")));

	CeSetThreadPriority(currentThread,oldThreadPriority);

	return ulBytesWritten;
}


//------------------------------------------------------------------------------
//
// ReadData - Read a block of data
//
//------------------------------------------------------------------------------
unsigned long ReadData(PDISK pDisk, PSG_REQ pSgr)
{
	unsigned long ulStartSector = pSgr->sr_start;
	unsigned long ulTotalSectors = pSgr->sr_num_sec;
	unsigned long ulNumSectors = 0;
	unsigned long ulNumSGs = pSgr->sr_num_sg;
	unsigned long ulBytesRead = 0;
	char          *pcPtr = 0;
	unsigned long ulTotalBytes = SD_BYTES_PER_SECTOR * ulTotalSectors;
	PSG_BUF		  pSg = 0;
	unsigned long ulCurrentSG = 0;
	long		  lBytesLeftSG = pSgr->sr_sglist[ulCurrentSG].sb_len;
	unsigned long size2read = 0;
	unsigned long indexSGbuf = 0;

	DEBUGMSG(ZONE_IO , (TEXT("SDMMC:ReadData - reading %d sectors starting at 0x%x %d scatter/gather buffs\r\n"), pSgr->sr_num_sec,ulStartSector, pSgr->sr_num_sg));

	pcPtr = (char *) MapPtrToProcess((LPVOID) pSgr->sr_sglist[ulCurrentSG].sb_buf, GetCallerProcess());


	//
	// reading ulNumSectors into ulNumSGs
	//
	while (ulBytesRead < ulTotalBytes)
	{
		if (!(lBytesLeftSG % SD_BYTES_PER_SECTOR)) 
			size2read = SD_BYTES_PER_SECTOR;
		else
			size2read = lBytesLeftSG;

		if(AT91F_MCI_ReadBlock (pDisk->MciDevice, ulStartSector*SD_BYTES_PER_SECTOR, (unsigned int*)pDMACommonRxBuffer.LowPart, size2read,pDisk) != AT91C_READ_OK)
		{
			pDisk->MciDevice->pMCI_DeviceDesc->state = AT91C_MCI_IDLE;
			return 0;
		}


		ulStartSector++;

		//
		// wait for drive before each sector
		//
		AT91F_MCIDeviceWaitReady(pDisk->MciDevice,AT91C_MCI_TIMEOUT,pDisk);
		pDisk->MciDevice->pMCI_DeviceDesc->state = AT91C_MCI_IDLE;
	


		endianExchangeMemcpy( (pcPtr + indexSGbuf), vDMACommonRxBuffer, size2read );
								//dest                    src
		lBytesLeftSG = lBytesLeftSG - size2read;
		indexSGbuf = indexSGbuf + size2read;
		ulBytesRead = ulBytesRead + size2read;


		
		//
		// make sure this SG buffer is not full
		//
		if (lBytesLeftSG <= 0)  
		{
			if (++ulCurrentSG >= ulNumSGs) // no more scatter/gather buffers
				break;


			//
			// get next SG buffer and its length
			//
			
			pSg = &(pSgr->sr_sglist[ulCurrentSG]);
			pcPtr = (char *) MapPtrToProcess((LPVOID) pSg->sb_buf, GetCallerProcess());
			lBytesLeftSG = pSg->sb_len;
			indexSGbuf = 0;

			DEBUGMSG(ZONE_IO, (TEXT("SDMMC:ReadData -   reading to SG %d of %d, %ld bytes\r\n"), ulNumSGs - ulCurrentSG + 1, ulNumSGs, lBytesLeftSG));
		}

	} //while

	
	DEBUGMSG(ZONE_IO, (TEXT("SDMMC:ReadData (2)- Done")));
	return ulBytesRead;
}



/**************************************************************************
* Name: endianExchangeMemcpy
*
* Description: 
*       this function convert the endianess (little to big endian, and thus big ito little as well)
*       of a buffer. Data are supposed to be 32 bits wide.
*
*
**************************************************************************/
void endianExchangeMemcpy(char * charDestBuffer, char* charSrcBuffer,  unsigned int length)
 {
	unsigned int max = length / 4; // length MUST be a multiple of  4, otherwise not all the data will be converted. (however it would be  misuse of this function to convert a non-multiple of 4 number of bytes)
	unsigned int i;
	register unsigned int src,dest;
	unsigned int *srcBuffer = (unsigned int *) charSrcBuffer;
	unsigned int *destBuffer = (unsigned int *) charDestBuffer;
	unsigned int size = sizeof(unsigned int);


	if (((DWORD)charSrcBuffer % size ==0)&&((DWORD)charDestBuffer  % size ==0)) //if our buffers are aligned
	{
		for (i=0;i<max;i++)
		{
			src = srcBuffer[i];
			dest  = (src & 0x000000FF) << 24;
			dest |= (src & 0x0000FF00) << 8;
			dest |= (src & 0x00FF0000) >> 8;
			dest |= (src & 0xFF000000) >> 24;
			destBuffer[i] = dest;
		}
	}
	else
	{
		unsigned int exchange;

		for (i=0;i<max;i++)
		{
			memcpy(&exchange,charSrcBuffer +  size*i,size);

			src = exchange;
			dest  = (src & 0x000000FF) << 24;
			dest |= (src & 0x0000FF00) << 8;
			dest |= (src & 0x00FF0000) >> 8;
			dest |= (src & 0xFF000000) >> 24;
			exchange = dest;
			memcpy(charDestBuffer +  size*i,&exchange,size);
		}
	}
}
//! @}
