//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//!	\file		sdmem_loader.c
//!
//! \brief		Implementation of the SDMemeory Driver Loader.
//!
//! \if cvs
//!   $RCSfile: sdmem_loader.c,v $
//!   $Author: jjhiblot $
//!   $Revision: 1.3 $
//!   $Date: 2005/11/18 15:16:48 $
//! \endif
//! 
//-----------------------------------------------------------------------------
//! \addtogroup	SDMEMORY
//! @{
//
//! \addtogroup	LOADER
//! @{

#include <windows.h>
#include <ceddk.h>

#include "at91sam9263_gpio.h"

#define MASK_SLOT_A	(1<<0)
#define MASK_SLOT_B	(1<<1)


// Global variables.
HANDLE  gSDMMCDetectThread;

//-----------------------------------------------------------------------------
//! \fn			BOOL IsInsertedOnSlotA()
//!
//! \brief		Indicates if an SD card is inserted in slot A
//!
//! \return		\e TRUE if a card is there
//!	\return		\e FALSE else
//-----------------------------------------------------------------------------
BOOL IsInsertedOnSlotA()
{
	return (pio_get_value(AT91C_PIN_PE(18))) ? FALSE : TRUE;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL IsInsertedOnSlotB()
//!
//! \brief		Indicates if an SD card is inserted in slot B
//!
//! \return		\e TRUE if a card is there
//!	\return		\e FALSE else
//-----------------------------------------------------------------------------
BOOL IsInsertedOnSlotB()
{
	return (pio_get_value(AT91C_PIN_PE(16))) ? FALSE : TRUE;
}



//-----------------------------------------------------------------------------
//! \fn			void SDMMCDetectThread(void)
//!
//! \brief		This function is the main thread that looks for the card insertion event
//!				Since there's no card detect PIO on this board, it simply looks for a value in the registry.
//!				This value can be written by any application or even remotely by a desktop machine
//!				The detection is only available on slotA due to hardware limitation
//!
//-----------------------------------------------------------------------------

void SDMMCDetectThread(void)
{
	static volatile int cardInserted = 0;
	BOOLEAN pollingMode = FALSE;
	HANDLE hDeviceA = NULL, hDeviceB = NULL;
	DWORD dwSDCARDAlreadyDetected = 0;

	pollingMode = TRUE;


	while(1)	
	{	
		DWORD dwDiff = cardInserted ^ dwSDCARDAlreadyDetected;
   		if (dwDiff & (MASK_SLOT_A | MASK_SLOT_B))
		{
			if (dwDiff & cardInserted & MASK_SLOT_A)
			{
				dwSDCARDAlreadyDetected |= MASK_SLOT_A;
				RETAILMSG(1, (TEXT("SD/MMC card insertion detected on Slot A\r\n")));			
				hDeviceA = ActivateDevice( TEXT("Drivers\\sdmemSlotA"), 0);
			}
			else if (dwDiff & dwSDCARDAlreadyDetected & MASK_SLOT_A)
			{
				dwSDCARDAlreadyDetected &= ~MASK_SLOT_A;
				RETAILMSG(1, (TEXT("SD/MMC card removal detected on Slot A\r\n")));			
				DeactivateDevice( hDeviceA );
			}
			
			
			if (dwDiff & cardInserted & MASK_SLOT_B)
			{
				dwSDCARDAlreadyDetected |= MASK_SLOT_B;
				RETAILMSG(1, (TEXT("SD/MMC card insertion detected on Slot B\r\n")));			
				hDeviceB = ActivateDevice( TEXT("Drivers\\sdmemSlotB"), 0);
			}
			else if (dwDiff & dwSDCARDAlreadyDetected & MASK_SLOT_B)
			{
				dwSDCARDAlreadyDetected &= ~MASK_SLOT_B;
				RETAILMSG(1, (TEXT("SD/MMC card removal detected on Slot B\r\n")));			
				DeactivateDevice( hDeviceB );
			}		
		}
	
		if (pollingMode)
		{
			Sleep(1000);
		}
		else
		{			
			Sleep(1000); //WaitForsingleObject(....)
		}

		if (IsInsertedOnSlotA())
		{
			cardInserted |= MASK_SLOT_A;
		}
		else
		{
			cardInserted &= ~MASK_SLOT_A;
		}

		// Remove the detection on slotB due to hardware limitation
		if (IsInsertedOnSlotB())
		{
			cardInserted |= MASK_SLOT_B;
		}
		else
		{
			cardInserted &= ~MASK_SLOT_B;
		}

	}
}

//-----------------------------------------------------------------------------
//! \fn			BOOL WINAPI SML_Init()
//!
//! \brief		This function is the entry point of this pseudo-driver.
//!				It simply creates the thread that'll look for a change in the card detection status
//!
//! \return		TRUE in success, FALSE in failure
//-----------------------------------------------------------------------------
BOOL WINAPI SML_Init()
{

   	SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_NORMAL);
	
	gSDMMCDetectThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE) SDMMCDetectThread, NULL, 0, NULL);
		
	if ( gSDMMCDetectThread == NULL ) 
	{
        RETAILMSG(1, (TEXT("Fatal Error!  Failed to create MMC card detect thread.\r\n")));
        return (FALSE);
	}
		
	return TRUE;
}


BOOL WINAPI SML_DllEntry( HANDLE  hInstDll,
						  DWORD   dwReason,
						  LPVOID  lpvReserved
						)
{
    switch ( dwReason ) 
	{
		case DLL_PROCESS_ATTACH:								
		break;

		case DLL_PROCESS_DETACH:
		break;
    }

    return TRUE;
}

// The following functions are all stubbed out. They are not required but are provided for the sake 
// of code completion.

DWORD SML_Open (DWORD dwData, DWORD dwAccess, DWORD dwShareMode) 
{
	return (4);
}

BOOL  SML_Close(DWORD dwData) 
{
	return (TRUE);
}

DWORD SML_Read (DWORD dwData,  LPVOID pBuf, DWORD Len) 
{
	return (0);
}

DWORD SML_Write(DWORD dwData, LPCVOID pBuf, DWORD Len) 
{
	return (0);
}

DWORD SML_Seek (DWORD dwData, long pos, DWORD type) 
{
	return (DWORD)-1;
}


VOID  SML_PowerUp  (VOID) 
{
}

BOOL  SML_PowerDown(VOID) 
{
	return (TRUE);
}

BOOL  SML_Deinit(DWORD dwData) 
{
	return (TRUE);
}

BOOL  SML_IOControl(DWORD p1, DWORD p2, PBYTE p3, DWORD p4, PBYTE p5, 
                    DWORD p6, PDWORD p7) 
{
	return (TRUE);
}

//! @}
//! @}

//! @}
