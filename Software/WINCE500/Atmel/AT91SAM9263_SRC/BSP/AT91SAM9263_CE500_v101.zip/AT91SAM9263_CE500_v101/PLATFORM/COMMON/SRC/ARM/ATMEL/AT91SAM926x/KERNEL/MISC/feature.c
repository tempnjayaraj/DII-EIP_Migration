//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		feature.c
//!
//! \brief		AT91SAM926x's processor's feature query
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/MISC/feature.c $
//!   $Author: pblanchard $
//!   $Revision: 1058 $
//!   $Date: 2007-07-05 01:34:39 -0700 (Thu, 05 Jul 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------


//! \addtogroup	FEATURE
//! @{

#include <windows.h>
#include <winnt.h>
#include <oal.h>


//-----------------------------------------------------------------------------
//! \fn			BOOL OALIsProcessorFeaturePresent(DWORD feature)
//!
//! \brief		Called to determine the processor's supported feature set
//!
//! \param		feature tested
//!
//! \return		TRUE if processor support feature, FALSE if not
//!
//-----------------------------------------------------------------------------
BOOL OALIsProcessorFeaturePresent(DWORD feature)
{
    BOOL rc;

    switch (feature)
    {
        
        case PF_ARM_V4:               //ARM architecture v4 
        case PF_ARM_JAZELLE:          //ARM Jazelle technology 
        case PF_ARM_ITCM:                     //Tightly-coupled data memory 
        case PF_ARM_DTCM:                     //Tightly-coupled data memory 
        case PF_ARM_UNIFIED_CACHE:            //Unified cache 
        case PF_ARM_WRITE_BACK_CACHE:         //Writeback cache 
        case PF_ARM_CACHE_CAN_BE_LOCKED_DOWN: //Cache can be locked down
            rc = TRUE;
        break;
					
        
        case PF_ARM_THUMB:            //Thumb instruction set 
        case PF_ARM_V5:               //ARM architecture v5 
        case PF_ARM_V6:               //ARM architecture v6 
        case PF_ARM_V7:               //ARM architecture v7 
        case PF_ARM_DSP:              //'E' DSP instructions  This flag is deprecated, but no additional flag is required because this is covered by ARMv5 and later.       
        case PF_ARM_MOVE_CP:          //ARM MOVE coprocessor 
        case PF_ARM_VFP10:            //VFP10 floating-point unit (FPU)  This flag is deprecated. For the correct flags to use, please see the other VFP flags.      
        case PF_ARM_MPU:              //Support for memory protection unit (MPU) is available 
        case PF_ARM_WRITE_BUFFER:     //Writeback buffer 
        case PF_ARM_MBX:              //ARM MBX technology 
        case PF_ARM_L2CACHE:          //Level 2 cache controller This flag is deprecated. For the correct flags to use, see the other L2 cache flags.       
        case PF_ARM_PHYSICALLY_TAGGED_CACHE:  //Cache is, or can be, physically tagged 
        case PF_ARM_VFP_SINGLE_PRECISION:     //Single precision vectored floating-point unit 
        case PF_ARM_VFP_DOUBLE_PRECISION:     //Double precision vectored floating-point unit  
        case PF_ARM_L2CACHE_MEMORY_MAPPED:    //Level 2 cache controller implemented as a memory-mapped peripheral 
        case PF_ARM_L2CACHE_COPROC:           //Level 2 cache controller implemented as a coprocessor 
        case PF_ARM_INTEL_XSCALE:             //Intel XScale processor  This can be used to determine if the processor supports operations where src==dest.     
        case PF_ARM_INTEL_PMU:                //Performance Monitor Unit (PMU) 
        case PF_ARM_INTEL_WMMX:               //WMMX support   
            rc = FALSE;
        break;
        
        default:
            rc = FALSE;
        break;            
    }
    return rc;
}

//! @} end of subgroup FEATURE

//! @} end of group OAL

////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/MISC/feature.c $
////////////////////////////////////////////////////////////////////////////////
//
