//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//-----------------------------------------------------------------------------
//! \file		init_at91sam9263.c 
//!
//! \brief		The specific init bootlaoder part
//!
//! \if subversion
///  $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/BOOTLOADER/EBOOT/init_at91sam9263.c $
//!   $Author: jjhiblot $
//!   $Revision: 860 $
//!   $Date: 2007-05-22 10:33:20 +0200 (mar., 22 mai 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	EBOOT
//! @{
//!


//------------------------------------------------------------------------------
//                                                                      Includes
//------------------------------------------------------------------------------
// Standard includes
#include <windows.h>
#include <blcommon.h>
#include <nkintr.h>
#include <oal_memory.h>


// Atmel includes
#include "at91sam9263.h"
#include "AT91SAM9263EK.h"
#include "AT91SAM926x_interface.h"

// Local includes
#include "drv_glob.h"
#include "bsp_cfg.h"
#include "bootloader_struct.h"
#include "bootloader_cfg.h"

//void EBOOT_SwitchOnLed(void);
//void EBOOT_SwitchOffLed(void);

//------------------------------------------------------------------------------
//                                                            Imported functions
//------------------------------------------------------------------------------
// Debug serial port init
extern void		AT91SAM926x_SetDebugSerialInterface(AT91PS_DBGU pDBGU);
// Clocks settings
extern BOOL		AT91SAM926x_SetProcessorAndMasterClocks(AT91PS_PMC pPMC,
												DWORD dwProcessorClockInMHz,
												DWORD dwBusClockRatio);
extern VOID*	OALPAtoVA(UINT32 pa, BOOL cached);			//< Mapping function
extern UINT32	OALVAtoPA(VOID *pVA);						//< Mapping function


//------------------------------------------------------------------------------
//                                                            Exported variables
//------------------------------------------------------------------------------
// The platform string used when sending BOOTME frame
CHAR * g_pPlatformString = BSP_DEVICE_PREFIX;
UCHAR  g_BspVersionMajor = EBOOT_VERSION_MAJOR;
UCHAR  g_BspVersionMinor = EBOOT_VERSION_MINOR;

//------------------------------------------------------------------------------
//                                                            Exported functions
//------------------------------------------------------------------------------


//----------------------------------------------------------------------------
// \fn    AT91F_LowLevelInit
// \brief This function performs very low level HW initialization
//        - Set a default pocessor and master clock (for eboot life)
//		  - Configure PLL
//----------------------------------------------------------------------------
#define			EBOOT_CORE_FREQUENCY_MHZ	200
#define			EBOOT_DIVIDER				4

void EBOOT_LowLevelInit()
{
    AT91PS_PMC			pPMC = (AT91PS_PMC) OALPAtoVA((DWORD) AT91C_BASE_PMC, FALSE);

	// need to be sure that SetProcessorAndMasterClocks method passed
	//SetDebugSerialInterface(NULL);
	AT91SAM926x_SetDebugSerialInterface((AT91PS_DBGU) OALPAtoVA((DWORD) AT91C_BASE_DBGU,FALSE));
	OEMInitDebugSerial();

	// Set a default pocessor and master clock (just for bootloader life time)
	AT91SAM926x_SetProcessorAndMasterClocks(pPMC, EBOOT_CORE_FREQUENCY_MHZ, EBOOT_DIVIDER);

	OEMInitDebugSerial();
}

//----------------------------------------------------------------------------
// \fn    EBOOT_GetFlashConfig(void)
// \brief \return the flash configuration (pointer on T_BOOTLOADER_FLASH_CONFIG
//		  set by firstboot).
//----------------------------------------------------------------------------
T_BOOTLOADER_FLASH_CONFIG * EBOOT_GetFlashConfig(void)
{
	return (T_BOOTLOADER_FLASH_CONFIG*)(BOOTLOADER_FLASH_CONFIG_ADDR);
}

//----------------------------------------------------------------------------
// \fn    EBOOT_SerialDebugInitInterface
// \brief Init the serial debug interface
//----------------------------------------------------------------------------
void EBOOT_SerialDebugInitInterface(void)
{
	AT91SAM926x_SetDebugSerialInterface((AT91PS_DBGU) OALPAtoVA((DWORD) AT91C_BASE_DBGU,FALSE));
}


//----------------------------------------------------------------------------
// \fn    EBOOT_SitchOnLed
// \brief Switch on Ek Led
//----------------------------------------------------------------------------
/*void EBOOT_SwitchOnLed(void)
{
	AT91PS_PIO			pPIOA		= (AT91PS_PIO) OALPAtoVA((DWORD) AT91C_BASE_PIOA, FALSE);

	pPIOA->PIO_PER = AT91C_PIO_PA13 | AT91C_PIO_PA14;
	pPIOA->PIO_OER = AT91C_PIO_PA13 | AT91C_PIO_PA14;
	pPIOA->PIO_CODR = AT91C_PIO_PA14;
	pPIOA->PIO_CODR = AT91C_PIO_PA13;
}

//----------------------------------------------------------------------------
// \fn    EBOOT_SitchOffLed
// \brief Switch off Ek Led
//----------------------------------------------------------------------------
void EBOOT_SwitchOffLed(void)
{
	AT91PS_PIO			pPIOA		= (AT91PS_PIO) OALPAtoVA((DWORD) AT91C_BASE_PIOA, FALSE);

	pPIOA->PIO_PER = AT91C_PIO_PA13 | AT91C_PIO_PA14;
	pPIOA->PIO_OER = AT91C_PIO_PA13 | AT91C_PIO_PA14;
	pPIOA->PIO_SODR = AT91C_PIO_PA14;
	pPIOA->PIO_SODR = AT91C_PIO_PA13;
}
*/

//----------------------------------------------------------------------------
// \fn    EBOOT_InitArgs
// \brief Initialize bsp args and return a pointer on kitl args
//----------------------------------------------------------------------------
OAL_KITL_ARGS * EBOOT_InitArgs(void)
{
	PDRIVER_GLOBALS pTmp = OALPAtoVA((DWORD)DRIVER_GLOBALS_PHYSICAL_MEMORY_START,FALSE);

	//Tell the kernel that the bootloader has been executed (the kernel can start without any bootloader)
	pTmp->bEboot = TRUE;

	memset( &(pTmp->BSPArgs), 0x00, sizeof(BSP_ARGS) );
    pTmp->BSPArgs.header.signature  = OAL_ARGS_SIGNATURE;
    pTmp->BSPArgs.header.oalVersion = OAL_ARGS_VERSION;
    pTmp->BSPArgs.header.bspVersion = BSP_ARGS_VERSION;

	return &(pTmp->BSPArgs.kitl);
}

//----------------------------------------------------------------------------
// \fn    EBOOT_SetDeviceId
// \brief This function must set the deviceId in correct args structure.
//----------------------------------------------------------------------------
void EBOOT_SetArgs(UINT8 deviceId[16], DWORD dwCoreFrequency, DWORD dwBusDivider)
{
	PDRIVER_GLOBALS pTmp = OALPAtoVA((DWORD)DRIVER_GLOBALS_PHYSICAL_MEMORY_START,FALSE);
	memcpy(&(pTmp->BSPArgs.deviceId), deviceId, 16);
	pTmp->BSPArgs.dwCoreFrequency = dwCoreFrequency;
	pTmp->BSPArgs.dwBusFreqDivider = dwBusDivider;
}


//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/BOOTLOADER/EBOOT/init_at91sam9263.c $
//------------------------------------------------------------------------------

//
//! @}
//
//! @}
