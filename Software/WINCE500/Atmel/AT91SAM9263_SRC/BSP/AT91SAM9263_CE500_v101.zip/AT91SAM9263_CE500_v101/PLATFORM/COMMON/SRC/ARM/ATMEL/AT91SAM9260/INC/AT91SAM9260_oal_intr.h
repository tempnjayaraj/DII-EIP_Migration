//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9260_oal_intr.h
//!
//! \brief		Definitions of the interrupt constants
//-----------------------------------------------------------------------------

#ifndef AT91SAM9260_OALINTR_H
#define AT91SAM9260_OALINTR_H


// the following values are used to compute the LOGINTR associated with a PIO pin.
// For example LOGINTR for PIOA pin 4 is LOGINTR_BASE_PIOA + 4
#define LOGINTR_BASE_PIOA			64
#define LOGINTR_BASE_PIOB			96                           
#define LOGINTR_BASE_PIOC			128                          

//////////////////////////////////////////////////////////////////////
//                          
// SYSINTR values
//
#define SYSINTR_SYS			    (SYSINTR_FIRMWARE+0)
#define SYSINTR_ETHER			(SYSINTR_FIRMWARE+1)


#endif

//! @}
