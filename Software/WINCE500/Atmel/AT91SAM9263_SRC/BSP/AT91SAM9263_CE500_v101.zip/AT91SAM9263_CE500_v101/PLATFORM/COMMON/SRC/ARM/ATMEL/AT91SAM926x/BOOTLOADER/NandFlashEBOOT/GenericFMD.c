//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/NandFlashEBOOT/GenericFMD.c
//!
//! \brief		A generic modular FMD for NAND Flash memory
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/NandFlashEBOOT/GenericFMD.c $
//!   $Author: cchary $
//!   $Revision: 811 $
//!   $Date: 2007-05-10 15:33:51 +0200 (jeu., 10 mai 2007) $
//! \endif
//!
//! Implements a sector mapping and a sector locking system witch interface
//! with WinCE Std block driver and also with BootPart. cf the graph below.
//! 
//-----------------------------------------------------------------------------
//! \addtogroup	NandFlash
//! @{
//!

// -------------------------
// |      Application      |
// -------------------------
//       |             |
//       V             |
// --------------      |        ---------------
// | FileSystem |      |        |  Bootloader |
// --------------      |        ---------------
//       |             |               |
//       V             V               V
// --------------------------   ---------------
// | WinCE Std Block Driver |   |   BootPart  |
// --------------------------   ---------------
//             |                       |
// ---- L o g i c a l -- A d d r e s s e s ----
//             |                       |
//             V                       V
// --------------------------------------------
// |                  F M D                   |
// --------------------------------------------
// |                    |                     |
// |                    V                     |
// | ---------------------------------------- |
// | |    BTL : Block Translation Layer     | |
// | ---------------------------------------- |
// |                    |                     |
// | - P h y s i c a l  | A d d r e s s e s - |
// |                    V                     |
// | ---------------------------------------- |
// | |   WPS : Write protection system      | |
// | ---------------------------------------- |
// |                    |                     |
// |                    V                     |
// | ---------------------------------------- |
// | |   LLD : Low Level Driver             | |
// | ---------------------------------------- |
// |--------------------|---------------------|
//                      V
// --------------------------------------------
// |             Hardware device              |
// --------------------------------------------

// System specific include
#include <windows.h>
#include <nkintr.h>
#include <oal.h>
#include <fmd.h>

#include "GenericFMD.h"
#include "NandFlash.h"
#include "Mem.h"

//#define USE_ECC
#ifdef USE_ECC
#include <ecc.h>
#include "GenericECC.h"
#endif


// Make a Doxygen group
//! \addtogroup GenericFMD
//! @{

//! \brief	Called by init to select a specific HW device
static void ConfigChip	();

//! \brief	BlocksInfo should be hardcoded, or extracted from flash
static BOOL	LoadBlocksInfo	();

static NandChip *pChip;
static MapSectionList *pMapPlan;

//! \brief	Sector buffer for read & write transaction
static BYTE* g_pSectorBuffer = NULL;

//! \brief	Array for block informations
static FMDBlocksInfo* g_pBlocksInfo = NULL;

static BOOL Spares2Info(PBYTE pSpares, PSectorInfo pSectorInfoBuff);
static BOOL Info2Spares(PSectorInfo pSectorInfoBuff, PBYTE pSpares);

static struct _FlashSize
{
	DWORD dwDataNbBytes		;	//!< Nb of bytes in data section
	DWORD dwSpareNbBytes	;	//!< Nb of bytes in spare section
	DWORD dwSectorNbBytes	;	//!< Total nb of bytes in a sector

	DWORD dwBlockNbSectors	;	//!< Nb of sector in a block
	DWORD dwBlockNbData		;	//!< Nb of DataBytes in a block
	DWORD dwBlockNbSpares	;	//!< Nb of SpareBytes in a block
	DWORD dwBlockNbBytes	;	//!< Total nb of bytes in a block

	DWORD dwNbBlocks		;	//!< Nb of blocks in device
	DWORD dwNbSectors		;	//!< Total nb of sectors in device
	DWORD dwNbData			;	//!< Nb of DataBytes in device
	DWORD dwNbSpares		;	//!< Nb of SpareBytes in device
	DWORD dwNbBytes			;	//!< Total nb of bytes in device

	DWORD dwReserveArea		;	//!< Nb of block reserved for image storage

} g_FlashSize;


//-----------------------------------------------------------------------------
//! \fn			PVOID FMD_Init(LPCTSTR lpActiveReg, PPCI_REG_INFO pRegIn, PPCI_REG_INFO pRegOut)
//!
//! \brief		This function initializes the flash memory of a device.
//!
//! \param		lpActiveReg	Registry key given by Windows
//! \param		pRegIn		Registry key given by Windows
//! \param		pRegOut		Registry key given by Windows
//!
//! \return		Handle to the specific device on success, you must pass this value to FMD_Deinit
//!	\return		-1 on error
//!
//! This function call LLD_Init, choose a configuration from DevID's and load
//! per block informations.
//-----------------------------------------------------------------------------
PVOID FMD_Init(LPCTSTR lpActiveReg, PPCI_REG_INFO pRegIn, PPCI_REG_INFO pRegOut)
{
	DWORD	dwRet	= 0;
	int		i		= 0;
	DWORD	MemBase	= 0x40000000;

	// In
	DEBUGMSG(1, (TEXT("->FMD_Init\n\r")));

	MemBase = (DWORD) pRegIn;

	pChip = NandFlash_Alloc();
	if(!pChip)
	{
		dwRet = -1;
		goto exit;
	}

	pChip->dwPhyNandBaseAddr = MemBase;
	if(!NandFlash_LowLevelInit(pChip))
	{
		dwRet = -1;
		goto exit;
	}
	DEBUGMSG(1, (TEXT("FMD_Init::FMD Low Level Init ok\n\r")             ));
	
	ConfigChip();
	
	// Allocate sufficient memory space to save blocks informations
	g_pBlocksInfo = (FMDBlocksInfo*)StaticMalloc(g_FlashSize.dwNbBlocks*sizeof(FMDBlocksInfo));

	// Allocate one-sector buffer
	g_pSectorBuffer = (BYTE*)StaticMalloc(g_FlashSize.dwSectorNbBytes);

	// Load Nand locking and mapping informations
	if (!LoadBlocksInfo())
	{
		dwRet = -1;
		DEBUGMSG(1, (TEXT("FMD_Init::Error loading block informations\n\r")));
		goto exit;
	}

exit:

	// Free dynamic memory
	if (dwRet && g_pBlocksInfo)
	{
		StaticFree(g_pBlocksInfo);
	}

	if (dwRet && g_pSectorBuffer)
	{
		StaticFree(g_pSectorBuffer);
	}

	if (dwRet && pChip)
	{
		NandFlash_Release(pChip);
	}

	// Init successfull
	if (!dwRet)
	{
		dwRet = 1;
	}

	// Out
	DEBUGMSG(1, (TEXT("<-FMD_Init\n\r")));

	return (PVOID)dwRet;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL FMD_Deinit(PVOID hFMD)
//!
//! \brief		This function de-initializes the flash chip.
//!
//! \param		hFMD Handle to an FMD, given by FMD_Init
//!
//! \return		\e TRUE when all is good
//!	\return		\e FALSE when all is bad
//-----------------------------------------------------------------------------
BOOL FMD_Deinit(PVOID hFMD)
{
	// In
	DEBUGMSG(1, (TEXT("->FMD_Deinit\n\r")));

	NandFlash_Release(pChip);

	// Release memory allocated
	if (g_pBlocksInfo)
		StaticFree(g_pBlocksInfo);

	if (g_pSectorBuffer)
		StaticFree(g_pSectorBuffer);

	// Out
	DEBUGMSG(1, (TEXT("<-FMD_Deinit\n\r")));

	return TRUE;
}

//-----------------------------------------------------------------------------
//! \fn			static void  ConfigChip()
//!
//! \brief		Called by init to select a specific HW device
//!
//-----------------------------------------------------------------------------
static void ConfigChip()
{
	// In
	DEBUGMSG(1, (TEXT("->ConfigChip\n\r")));

	// Compute all number. (Blocks, Sectors,...)
	g_FlashSize.dwDataNbBytes	= pChip->pFlashDev->dwDataNbBytes;
	g_FlashSize.dwSpareNbBytes	= pChip->pFlashDev->dwSpareNbBytes;
	g_FlashSize.dwBlockNbSectors= pChip->pFlashDev->dwBlockNbSectors;
	g_FlashSize.dwNbBlocks		= pChip->pFlashDev->dwNbBlocks;

	g_FlashSize.dwSectorNbBytes	= g_FlashSize.dwDataNbBytes + g_FlashSize.dwSpareNbBytes;

	g_FlashSize.dwBlockNbData	= g_FlashSize.dwBlockNbSectors * g_FlashSize.dwDataNbBytes;
	g_FlashSize.dwBlockNbSpares	= g_FlashSize.dwBlockNbSectors * g_FlashSize.dwSpareNbBytes;
	g_FlashSize.dwBlockNbBytes	= g_FlashSize.dwBlockNbSectors * g_FlashSize.dwSectorNbBytes;

	g_FlashSize.dwNbSectors		= g_FlashSize.dwNbBlocks * g_FlashSize.dwBlockNbSectors;
	g_FlashSize.dwNbData		= g_FlashSize.dwNbBlocks * g_FlashSize.dwBlockNbData;
	g_FlashSize.dwNbSpares		= g_FlashSize.dwNbBlocks * g_FlashSize.dwBlockNbSpares;
	g_FlashSize.dwNbBytes		= g_FlashSize.dwNbBlocks * g_FlashSize.dwBlockNbBytes;

	pMapPlan = pChip->pFlashDev->pMapping;

	DEBUGMSG(1, (TEXT("ConfigChip::FMD will use these parameters :\n\r")             ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwDataNbBytes    : %d\n\r"), g_FlashSize.dwDataNbBytes    ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwSpareNbBytes   : %d\n\r"), g_FlashSize.dwSpareNbBytes   ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwBlockNbSectors : %d\n\r"), g_FlashSize.dwBlockNbSectors ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwNbBlocks       : %d\n\r"), g_FlashSize.dwNbBlocks       ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwSectorNbBytes  : %d\n\r"), g_FlashSize.dwSectorNbBytes  ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwBlockNbData    : %d\n\r"), g_FlashSize.dwBlockNbData    ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwBlockNbSpares  : %d\n\r"), g_FlashSize.dwBlockNbSpares  ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwBlockNbBytes   : %d\n\r"), g_FlashSize.dwBlockNbBytes   ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwNbSectors      : %d\n\r"), g_FlashSize.dwNbSectors      ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwNbData         : %d\n\r"), g_FlashSize.dwNbData         ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwNbSpares       : %d\n\r"), g_FlashSize.dwNbSpares       ));
	DEBUGMSG(1, (TEXT("ConfigChip::g_FlashSize.dwNbBytes        : %d\n\r"), g_FlashSize.dwNbBytes        ));

	// Out
	DEBUGMSG(1, (TEXT("<-ConfigChip\n\r")));
}


//-----------------------------------------------------------------------------
//! \fn			BOOL LoadBlocksInfo()
//!
//! \brief		This function load per-block informations (mapping & lock) for the device
//!
//! \return		\e TRUE When all is good
//!	\return		\e FALSE When there is an error during LoadBlocksInfo
//-----------------------------------------------------------------------------
BOOL LoadBlocksInfo()
{	// To do : Save Blocks information in flash :)
	
	BOOL bRet = TRUE;
	DWORD i,j;

	// In
	RETAILMSG(1, (TEXT("->LoadBlocksInfo\n\r")));

	// Debug only
	RETAILMSG(1, (TEXT("LoadBlocksInfo::g_pBlocksInfo : 0x%X\n\r"), g_pBlocksInfo));

	// Create an array for each block (valid or not) and fill it with
	// static block info. Currently all blocks are accessible, and there
	// is no mapping

	// Parsing map plan
	for (i=0; i<pMapPlan->dwNbElements; i++)
	{
		// Set all blocks for this map section
		for (j=0; j<pMapPlan->MapSectionArray[i].dwSizeInBlock; j++)
		{
			g_pBlocksInfo[pMapPlan->MapSectionArray[i].dwLogBlock + j].wPhysicalNumber	= (WORD)(pMapPlan->MapSectionArray[i].dwPhyBlock + j); // Only 16bits are revelant
			g_pBlocksInfo[pMapPlan->MapSectionArray[i].dwLogBlock + j].wStatus			= (WORD)(pMapPlan->MapSectionArray[i].dwStatus); // Only 16bits are revelant
		}
	}

	// Out
	RETAILMSG(1, (TEXT("<-LoadBlocksInfo\n\r")));

	return bRet;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL IsValidBlock_Sect(DWORD dwSector)
//!
//! \brief		Called to check if the block at a given offset is valid
//!
//! \param		dwSector Sector to be checked
//!
//! \return		\e TRUE When all is good
//!	\return		\e FALSE When not good
//-----------------------------------------------------------------------------
BOOL IsValidBlock_Sect(DWORD dwSector)
{
	DWORD dwFirstSectorOfBlock;
	SectorInfo SecInfo;	
	BOOL bRet = FALSE;

	dwFirstSectorOfBlock = ( dwSector / g_FlashSize.dwBlockNbSectors) * g_FlashSize.dwBlockNbSectors;

	if (LLD_READSECTOR(pChip, ZONE_INFO, dwFirstSectorOfBlock, g_pSectorBuffer))
	{
		//RETAILMSG(1, (TEXT("Read Spares sector 0x%X BadBlock =0x%X \r\n"),dwCurrentSector, SecInfo.bBadBlock));
		if (Spares2Info(&g_pSectorBuffer[g_FlashSize.dwDataNbBytes], &SecInfo))
		{ 
			if ((UCHAR)SecInfo.bBadBlock == 0xFF) // test if the block is correct
			{
				bRet = TRUE;
			}
			else
			{
				RETAILMSG(1, (L"IsValidBlock_Sect : Invalid block"));
			}
		}
		else
		{
			RETAILMSG(1, (L"IsValidBlock_Sect : Error Converting Spares"));
		}
	}
	else
	{
		RETAILMSG(1, (L"IsValidBlock_Sect : Error Reading Spares"));
	}
		
	return bRet;

}
//-----------------------------------------------------------------------------
//! \fn			BOOL IsValidBlock_Off(DWORD dwOffset)
//!
//! \brief		Called to check if the block of a given  sector is valid
//!
//! \param		dwOffset offset to be checked
//!
//! \return		\e TRUE When all is good
//!	\return		\e FALSE When not good
//-----------------------------------------------------------------------------
BOOL IsValidBlock_Off(DWORD dwOffset)
{
		
	return IsValidBlock_Sect((dwOffset / g_FlashSize.dwDataNbBytes) * g_FlashSize.dwDataNbBytes);

}

//-----------------------------------------------------------------------------
//! \fn			BOOL	FMD_DirectWrite(DWORD	dwOffset,	UCHAR* srcBuffer, DWORD dwLen)
//!
//! \brief		Called to write datas on the nand flash memory during eboot
//!
//! \param		dwOffset : Address in byte where we will write (must be sector aligned)
//! \param		srcBuffer : buffer of the datas
//! \param		dwLen : length of the buffer
//!
//!	\return		\e FALSE on error, TRUE otherwise
//-----------------------------------------------------------------------------
BOOL	FMD_DirectWrite(DWORD dwOffset, UCHAR* srcBuffer, DWORD dwLen)
{	
	DWORD dwCurrentSector;
	DWORD dwSectorsInBlock;
	BOOL bResult = TRUE;

//	RETAILMSG(1,(TEXT("FMD_DirectWrite from 0x%x to @%x %d bytes\r\n"),srcBuffer,dwOffset, dwLen));

	if (dwLen == 0)
	{
		return TRUE;
	}

	// check sector alignment
	if (dwOffset % g_FlashSize.dwDataNbBytes)
	{
		RETAILMSG(1,(TEXT("FMD_DirectWrite : Offset must be sector aligned !!\r\n")));
		return FALSE;
	}

	// compute start sector and sectors remaining in the first written block
	dwCurrentSector = dwOffset / g_FlashSize.dwDataNbBytes;
	dwSectorsInBlock = g_FlashSize.dwBlockNbSectors - (dwCurrentSector % g_FlashSize.dwBlockNbSectors);

	do {
		// check that we are not out of our device
		if (dwCurrentSector >= g_FlashSize.dwNbSectors)
		{
			bResult = FALSE;
			break;
		}

		// if block is not valid, move at the begining of the next one
		if (!IsValidBlock_Sect(dwCurrentSector))
		{
			dwCurrentSector += dwSectorsInBlock;
		}
		// else fill it
		else
		{
			while (dwSectorsInBlock && dwLen >= g_FlashSize.dwDataNbBytes)
			{
				bResult = LLD_WRITESECTOR(pChip, ZONE_DATA, dwCurrentSector, srcBuffer);
				if (!bResult)
				{
					break;
				}

				srcBuffer += g_FlashSize.dwDataNbBytes;
				dwLen -= g_FlashSize.dwDataNbBytes;
				dwCurrentSector++;
				dwSectorsInBlock--;
			}
		}

		if (dwLen < g_FlashSize.dwDataNbBytes || !bResult)
		{
			break;
		}
		dwSectorsInBlock = g_FlashSize.dwBlockNbSectors;
	} while (TRUE);

	if (dwLen > 0 && bResult)
	{
		// less than a sector size needed, if unlikely we are at the begining of a block
		if (dwSectorsInBlock == 0)
		{
			while (TRUE)
			{
				if (dwCurrentSector >= g_FlashSize.dwNbSectors)
				{
					bResult = FALSE;
					break;
				}

				if (IsValidBlock_Sect(dwCurrentSector))
				{
					break;
				}
				dwCurrentSector += g_FlashSize.dwBlockNbSectors;
			}
		}

		if (bResult)
		{
			bResult = LLD_READSECTOR(pChip, ZONE_DATA, dwCurrentSector, g_pSectorBuffer);
			if (bResult)
			{
				memcpy(g_pSectorBuffer, srcBuffer, dwLen);
				bResult = LLD_WRITESECTOR(pChip, ZONE_DATA, dwCurrentSector, g_pSectorBuffer);
			}
		}
	}

	return bResult;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL	FMD_DirectRead(DWORD	dwOffset,	UCHAR* destBuffer, DWORD dwLen)
//!
//! \brief		Called to read datas on the nand flash memory during eboot
//!
//! \param		dwOffset : Address in byte where we will read (must be sector aligned !!)
//! \param		destBuffer : buffer of the datas
//! \param		dwLen : length of the buffer
//!
//!	\return		\e FALSE on error, TRUE otherwise
//-----------------------------------------------------------------------------
BOOL	FMD_DirectRead(DWORD dwOffset, UCHAR* destBuffer, DWORD dwLen)
{
	DWORD dwCurrentSector;
	DWORD dwSectorsInBlock;
	BOOL bResult = TRUE;

//	RETAILMSG(1,(TEXT("FMD_DirectRead to 0x%x from @%x %d bytes\r\n"),destBuffer,dwOffset, dwLen));

	if (dwLen == 0)
	{
		return TRUE;
	}

	// check sector alignment
	if (dwOffset % g_FlashSize.dwDataNbBytes)
	{
		RETAILMSG(1,(TEXT("FMD_DirectRead : Offset must be sector aligned !!\r\n")));
		return FALSE;
	}

	// compute start sector and sectors remaining in the first read block
	dwCurrentSector = dwOffset / g_FlashSize.dwDataNbBytes;
	dwSectorsInBlock = g_FlashSize.dwBlockNbSectors - (dwCurrentSector % g_FlashSize.dwBlockNbSectors);

	do {
		// check that we are not out of our device
		if (dwCurrentSector >= g_FlashSize.dwNbSectors)
		{
			bResult = FALSE;
			break;
		}

		// if block is not valid, move at the begining of the next one
		if (!IsValidBlock_Sect(dwCurrentSector))
		{
			dwCurrentSector += dwSectorsInBlock;
		}
		// else read it
		else
		{
			while (dwSectorsInBlock && dwLen >= g_FlashSize.dwDataNbBytes)
			{
				bResult = LLD_READSECTOR(pChip, ZONE_DATA, dwCurrentSector, destBuffer);
				if (!bResult)
				{
					break;
				}

				destBuffer += g_FlashSize.dwDataNbBytes;
				dwLen -= g_FlashSize.dwDataNbBytes;
				dwCurrentSector++;
				dwSectorsInBlock--;
			}
		}

		if (dwLen < g_FlashSize.dwDataNbBytes || !bResult)
		{
			break;
		}
		dwSectorsInBlock = g_FlashSize.dwBlockNbSectors;
	} while (TRUE);

	if (dwLen > 0 && bResult)
	{
		// less than a sector size wanted, if unlikely we are at the begining of a block
		if (dwSectorsInBlock == 0)
		{
			while (TRUE)
			{
				if (dwCurrentSector >= g_FlashSize.dwNbSectors)
				{
					bResult = FALSE;
					break;
				}

				if (IsValidBlock_Sect(dwCurrentSector))
				{
					break;
				}
				dwCurrentSector += g_FlashSize.dwBlockNbSectors;
			}
		}

		if (bResult)
		{
			bResult = LLD_READSECTOR(pChip, ZONE_DATA, dwCurrentSector, g_pSectorBuffer);
			if (bResult)
			{
				memcpy(destBuffer, g_pSectorBuffer, dwLen);
			}
		}
	}

	return bResult;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL	FMD_EraseChip
//!
//! \brief		Erase the nandflash memory during eboot 
//!
//! \return		\e TRUE When all is good
//!	\return		\e FALSE When there is an error during IsStartSector
//-----------------------------------------------------------------------------

BOOL	FMD_EraseChip(void)
{	
	//possible arguments
	//(DWORD	dwOffset,DWORD dwLen)
	DWORD dwOffset, dwLen;

	
	BOOL bResult = TRUE;
	DWORD dwStartBlock,dwEndBlock,dwCurrentBlock;
	DWORD dwBytesPerBlock;
	
	// Disable this tw0 lines if the function have arguments
	dwOffset = 0;
	dwLen = g_FlashSize.dwNbBlocks * g_FlashSize.dwDataNbBytes * g_FlashSize.dwBlockNbSectors;

	if (dwLen==0)
	{
		return TRUE;
	}
	
//	RETAILMSG(1,(TEXT("FMD_EraseChip @%x %d bytes\r\n"),dwOffset,dwLen));
	// How much bytes in a block ? (we don't count the spare part)
	dwBytesPerBlock = (g_FlashSize.dwDataNbBytes) * g_FlashSize.dwBlockNbSectors;
	
	dwStartBlock = dwOffset / dwBytesPerBlock; //First block to be erased 
	dwEndBlock = (dwOffset + dwLen -1)  / dwBytesPerBlock; //Last block to be erased

	dwCurrentBlock = dwStartBlock;

//	RETAILMSG(1,(TEXT("FMD_EraseChip : dwStartBlock 0x%x dwEndBlock 0x%x dwBytesPerBlock = 0x%x\r\n"),dwStartBlock,dwEndBlock, dwBytesPerBlock));

	do
	{
		LLD_ERASEBLOCK(pChip, dwCurrentBlock);
		dwCurrentBlock++;
	} while (dwCurrentBlock < dwEndBlock);
	
//	RETAILMSG(1,(TEXT("FMD_EraseChip : done\r\n")));

	return bResult;
}

static BOOL CheckSector(UCHAR*  pBuffer, UCHAR ucPattern)
{
	BOOL bResult = TRUE;
	DWORD j;
	for (j= 0; j< g_FlashSize.dwDataNbBytes; j++)
	{
		if (pBuffer[j] != ucPattern)
		{
			bResult = FALSE;			
		}
	}		
	return bResult;
}

//-----------------------------------------------------------------------------
//! \fn			BOOL	FMD_DirectErase(DWORD	dwOffset,DWORD dwLen)
//!
//! \brief		Erase a part of the nandflash memory during eboot
//!
//! \param		dwOffset : Address of the first byte to be erased
//! \param		dwLen : number of byte to be erased
//!
//! \return		\e TRUE When all is good
//!	\return		\e FALSE When there is an error during IsStartSector
//-----------------------------------------------------------------------------

BOOL	FMD_DirectErase(DWORD	dwOffset,DWORD dwLen)
{	
	BOOL bResult = TRUE;
	
	DWORD dwCurrentBlock,dwStartBlock;
	DWORD dwCurrentSector,dwStartSectorOfCurrentBlock;
	int iRemaining = (int) dwLen;
	DWORD i;
	

	dwCurrentBlock =  dwOffset / g_FlashSize.dwDataNbBytes;	
	dwStartBlock = dwCurrentBlock / g_FlashSize.dwBlockNbSectors;
	dwStartSectorOfCurrentBlock = dwStartBlock * g_FlashSize.dwBlockNbSectors;
	
	dwCurrentBlock = dwStartBlock;

	while (iRemaining > 0)
	{
		BOOL bBadBlock = FALSE;
//		RETAILMSG(1,(TEXT("LLD_ERASEBLOCK : dwCurrentBlock 0x%x\r\n"),dwCurrentBlock));
//		RETAILMSG(1,(TEXT("iRemaining : %d\r\n"),iRemaining));

		//Erase the current block
		LLD_ERASEBLOCK(pChip, dwCurrentBlock);

		
		dwCurrentSector = dwStartSectorOfCurrentBlock;
		//Then test every sector of this block
		for (i=0;i<g_FlashSize.dwBlockNbSectors;i++)
		{			
//			RETAILMSG(1,(TEXT("LLD_READSECTOR : dwCurrentSector 0x%x dwCurrentBlock 0x%x\r\n"),dwCurrentSector,dwCurrentBlock));
			LLD_READSECTOR(pChip, ZONE_DATA, dwCurrentSector, g_pSectorBuffer);
				
			if (CheckSector(g_pSectorBuffer,0xFF) == FALSE) // No nee to try the other sectors if this one is bad
			{
				//RETAILMSG(1,(TEXT("LLD_READSECTOR : dwCurrentSector 0x%x dwCurrentBlock 0x%x\r\n"),dwCurrentSector,dwCurrentBlock));
				LLD_READSECTOR(pChip, ZONE_DATA, dwCurrentSector, g_pSectorBuffer);
				
				if (CheckSector(g_pSectorBuffer,0xFF) == FALSE) // No nee to try the other sectors if this one is bad
				{
					//RETAILMSG(1,(TEXT("bad block (not 0xFF)\r\n")));
					bBadBlock = TRUE;
					//RETAILMSG(1,(TEXT("sector %d\r\n"),dwCurrentSector));
					
					break;
				}
				else
				{
					//RETAILMSG(1,(TEXT("second check OK (after erase)!\r\n")));
				}
			}
			dwCurrentSector++;
		}

		
		
		if (bBadBlock == FALSE)
		{
			UCHAR ucPattern = 0;	

			dwCurrentSector = dwStartSectorOfCurrentBlock;

			// Write a pattern in every sector
			for (i=0;i<g_FlashSize.dwBlockNbSectors;i++)
			{			

				memset(g_pSectorBuffer,ucPattern,g_FlashSize.dwDataNbBytes);
				//Write
	//			RETAILMSG(1,(TEXT("LLD_WRITESECTOR : dwCurrentSector 0x%x dwCurrentBlock 0x%x\r\n"),dwCurrentSector,dwCurrentBlock));
				LLD_WRITESECTOR(pChip, ZONE_DATA, dwCurrentSector, g_pSectorBuffer);
				//Read back
	//			RETAILMSG(1,(TEXT("LLD_READSECTOR : dwCurrentSector 0x%x dwCurrentBlock 0x%x\r\n"),dwCurrentSector,dwCurrentBlock));
				LLD_READSECTOR(pChip, ZONE_DATA, dwCurrentSector, g_pSectorBuffer);
				// verify
				if (CheckSector(g_pSectorBuffer,ucPattern) == FALSE) // No nee to try the other sectors if this one is bad
				{
					//RETAILMSG(1,(TEXT("bad block (not 0x%x)\r\n"),ucPattern));
					//RETAILMSG(1,(TEXT("sector %d\r\n"),dwCurrentSector));

					//RETAILMSG(1,(TEXT("LLD_READSECTOR : dwCurrentSector 0x%x dwCurrentBlock 0x%x\r\n"),dwCurrentSector,dwCurrentBlock));
					LLD_READSECTOR(pChip, ZONE_DATA, dwCurrentSector, g_pSectorBuffer);
					// verify										
					if (CheckSector(g_pSectorBuffer,ucPattern) == FALSE) // No nee to try the other sectors if this one is bad
					{
						//RETAILMSG(1,(TEXT("second check bad block (not 0x%x)\r\n"),ucPattern));
						bBadBlock = TRUE;
						//RETAILMSG(1,(TEXT("second check sector %d\r\n"),dwCurrentSector));
						
						break;
					}
					else
					{
	//					RETAILMSG(1,(TEXT("second check OK \r\n")));
					}										
				}
				dwCurrentSector++;
			}			
		}

		//Finaly erase the current block again ...		
		LLD_ERASEBLOCK(pChip, dwCurrentBlock);				
		


		// ... and mark it bad or good
		if (bBadBlock)
		{
			SectorInfo SecInfo;
			memset(&SecInfo,0xFF,sizeof(SecInfo));
			SecInfo.bBadBlock = 0;	
			//RETAILMSG(1,(TEXT("block %d is BAD !!\r\n"),dwCurrentBlock));	
			
			if (Info2Spares(&SecInfo, &g_pSectorBuffer[g_FlashSize.dwDataNbBytes]))
			{
				if (!LLD_WRITESECTOR(pChip, ZONE_INFO, dwStartSectorOfCurrentBlock, g_pSectorBuffer))
				{
					RETAILMSG(1, (L"FMD_SetBlockStatus : Error Writing Spares\r\n"));
				}
			}
		}

		dwStartSectorOfCurrentBlock += g_FlashSize.dwBlockNbSectors;
		dwCurrentBlock++;
		iRemaining -= (g_FlashSize.dwDataNbBytes*g_FlashSize.dwBlockNbSectors);

	}
		
	RETAILMSG(1,(TEXT("FMD_DirectErase done\r\n")));
	return bResult;
}

static BOOL Spares2Info(PBYTE pSpares, PSectorInfo pSectorInfoBuff) {
	BOOL bRet = TRUE;

	// Test if we got enough spares to store SectorInfo
	if (g_FlashSize.dwSpareNbBytes < sizeof(SectorInfo))
	{
		bRet = FALSE;
		RETAILMSG(1, (TEXT("Spares2Info::Not enought spares byte to store SectorInfo\n\r")));
		goto exit;
	}

	// Translation is just a copy :)
	memcpy(pSectorInfoBuff, pSpares, sizeof(SectorInfo));

exit:

	return bRet;
}

static BOOL Info2Spares(PSectorInfo pSectorInfoBuff, PBYTE pSpares) {
	BOOL bRet = TRUE;
	DWORD i;

	// Test if we got enough spares to store SectorInfo
	if (g_FlashSize.dwSpareNbBytes < sizeof(SectorInfo))
	{
		bRet = FALSE;
		RETAILMSG(1, (TEXT("Info2Spares::Not enought spares byte to store SectorInfo\n\r")));
		goto exit;
	}

	// Translation is just a copy :)
	memcpy(pSpares, pSectorInfoBuff, sizeof(SectorInfo));

	// We fill other spares bytes with 0xFF
	for (i=sizeof(SectorInfo); i<g_FlashSize.dwSpareNbBytes; i++)
	{
		pSpares[i] = 0xFF;
	}

exit:

	return bRet;
}

// End of Doxygen group GenericFMD
//! @}

//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/NandFlashEBOOT/GenericFMD.c $
//-----------------------------------------------------------------------------
//

//! @}
