//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!  
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		sdram.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/BOOTLOADER/FirstBoot/sdram.h $
//!   $Author: ltourlonias $
//!   $Revision: 684 $
//!   $Date: 2007-04-13 14:35:48 +0200 (ven., 13 avr. 2007) $
//! \endif
//!
//! Header for SDRAM Library
//-----------------------------------------------------------------------------
//! \addtogroup	FIRSTBOOT
//! @{
//!  
#ifndef __SDRAM_H__
#define __SDRAM_H__

extern void AT91F_InitSdram(void);

#endif //__SDRAM_H__


//! @}

//! @}
