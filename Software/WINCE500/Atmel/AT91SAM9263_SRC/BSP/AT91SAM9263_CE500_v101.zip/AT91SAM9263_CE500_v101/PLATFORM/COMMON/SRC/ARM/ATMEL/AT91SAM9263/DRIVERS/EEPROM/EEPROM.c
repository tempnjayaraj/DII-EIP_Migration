//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//! \addtogroup	EEPROM
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM9263/DRIVERS/EEPROM/EEPROM.c
//!
//! \brief		EEPROM driver for AT91SAM9263's chipset
//!
//! \if cvs
//!   $Author: edaniel $
//!   $Revision: 710 $
//!   $Date: 2007-04-16 16:17:13 +0200 (lun., 16 avr. 2007) $
//! \endif
//!
//! Description of the driver on multi lines
//-----------------------------------------------------------------------------


// System include
#include <windows.h>
#include <memory.h>
#include <nkintr.h>
#include <CEDDK.h>

// Local include
#include "at91sam926x.h"
#include "AT91SAM9263_gpio.h"
#include "atmel_gpio.h"

//-----------------------------------------------------------------------------
//! \fn			VOID EEPROM_Reset(VOID)
//!
//! \brief		This function resets the EEPROM memory configuring PIO controllers
//!
//-----------------------------------------------------------------------------
VOID EEPROM_Reset(VOID)
{
	int i;

	const struct pio_desc hw_pio_periph[] = 
	{
		{"TWD", AT91C_PIN_PB(4), 0, PIO_PULLUP, PIO_PERIPH_A},
		{"TWCK", AT91C_PIN_PB(5), 0, PIO_PULLUP, PIO_PERIPH_A},
	};
	const struct pio_desc hw_pio_out[] = 
	{
		{"TWD", AT91C_PIN_PB(4), 0, PIO_PULLUP, PIO_OUTPUT},
		{"TWCK", AT91C_PIN_PB(5), 0, PIO_PULLUP, PIO_OUTPUT},
	};

	// Configure PIO controllers in output
	pio_setup(hw_pio_out, sizeof(hw_pio_out)/sizeof(struct pio_desc));
	
	for (i=0;i<9;i++)
	{
		Sleep(1);
		pio_set_value(AT91C_PIN_PB(5),0);
		Sleep(1);
		pio_set_value(AT91C_PIN_PB(5),1);
	}

	// Configure PIO controllers to periph mode
	pio_setup(hw_pio_periph, sizeof(hw_pio_periph)/sizeof(struct pio_desc));

	Sleep(100);

}


// End of Doxygen group EEPROM Driver
//! @}
//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/DRIVERS/EEPROM/EEPROM.c $
//-----------------------------------------------------------------------------
//
