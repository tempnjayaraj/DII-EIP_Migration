//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//! \addtogroup	ATAPIEBI
//! @{
//
//! All rights reserved ADENEO SAS 2005
//-----------------------------------------------------------------------------
//!
//! \file		atapiebi.cpp
//!
//! \brief		IDE ATAPI hard disk driver on EBI bus\n
//!             based on atapipcmcia.cpp file\n
//!             The ATAPIEBI driver is a DLL loaded by IDE driver, named DSK.\n
//!             It is a block driver, interrupt driven, without IST.\n
//!             It can be unloaded / reloaded
//!
//! \if cvs
//!   $RCSfile: atapiebi.cpp,v $
//!   $Author: jjhiblot $
//!   $Revision: 195 $
//!   $Date: 2006-04-11 15:36:05 +0200 (mar., 11 avr. 2006) $
//! \endif
//-----------------------------------------------------------------------------

// System include
//#include <atapiebi.h>
#include <windows.h>
#include <ceddk.h>
#include <giisr.h>
#include <atamain.h>

// Platform specific includes
#include "AT91SAM926x.h"
#include "at91sam9263_gpio.h"
#include "atmel_gpio.h"
#include "lib_AT91SAM926x.h"
#include "AT91SAM926x_oal_ioctl.h"

#include "AT91SAM926x_interface.h"


// Platform specific defines
// Chip select timings for PIO mode 0

#define AT91C_IDE_CHIPSELECT	4	//!< Num for IDE chip select

#define AT91C_IDE_NWE_SETUP		10	// timing for IDE in ns
#define AT91C_IDE_NRD_SETUP		10
#define AT91C_IDE_NCS_WR_SETUP	0 
#define AT91C_IDE_NCS_RD_SETUP	0
#define AT91C_IDE_NWE_PULSE 	40
#define AT91C_IDE_NRD_PULSE		40
#define AT91C_IDE_NCS_RD_PULSE	100
#define AT91C_IDE_NCS_WR_PULSE	100
#define AT91C_IDE_NRD_CYCLE		120
#define AT91C_IDE_NWE_CYCLE		120


// Global variables
static BOOL						g_IDEInitialized	= FALSE; //!< Tell if IDE registers are already initialized
static volatile	AT91PS_MATRIX	g_pMatrix			= NULL;  //!< Matrix register
static volatile	AT91PS_SMC		g_pSMC				= NULL;  //!< SMC register


//-----------------------------------------------------------------------------
//! \fn			BOOL AT91_IDEConfigure()
//!
//! \brief		Initialize SMC, EBI and PIO HW blocks from AT91SAM926x for IDE usage
//!
//! \return		TRUE  When it is the first initialization
//!	\return		FALSE For subsequent initializations
//!
//-----------------------------------------------------------------------------
BOOL AT91_IDEConfigure()
{
	BOOL bRet = TRUE;
	DWORD dwMasterClock;
	PHYSICAL_ADDRESS pa;
	
	const struct pio_desc hw_pio[] = {
		{"RESET",		AT91C_PIN_PA(30), 0, PIO_DEFAULT, PIO_OUTPUT},
		{"EBI0_CFCE1",	AT91C_PIN_PD(8), 0, PIO_DEFAULT, PIO_PERIPH_A},
		{"EBI0_CFCE2",	AT91C_PIN_PD(9), 0, PIO_DEFAULT, PIO_PERIPH_A},
		{"PB11",		AT91C_PIN_PB(11), 0, PIO_DEFAULT, PIO_INPUT},
		{"PB10",		AT91C_PIN_PB(10), 0, PIO_DEFAULT, PIO_INPUT},
	};

	// In
	DEBUGMSG(1, (TEXT("->AT91_IDEConfigure\n\r")));
	if (g_IDEInitialized)
	{
		DEBUGMSG(1, (TEXT("->IDE registers were already initialized. It is done a new time\n\r")));
		bRet = FALSE;
	}

	// Init registers addresses
	pa.QuadPart		= (LONGLONG)		AT91C_BASE_MATRIX;
	g_pMatrix		= (AT91PS_MATRIX)	MmMapIoSpace(pa, sizeof(AT91S_MATRIX), FALSE);
	pa.QuadPart		= (LONGLONG)		AT91C_BASE_SMC0;
	g_pSMC			= (AT91PS_SMC)		MmMapIoSpace(pa, sizeof(AT91S_SMC), FALSE);
	

	//////// EBI configuration ////////
	// EBI_CSA register programmed with CS4A = 1 (CFCS0 mapped on NCS4/CFCS0 pin)
	// Enable the Chip Select 4 for CF Controller
	g_pMatrix->MATRIX_EBI0 |= AT91C_MATRIX_CS4A_CF;

	//////// SMC configuration ////////
	// SMC timings for NWE, NRD
	KernelIoControl(IOCTL_HAL_MASTERCLOCK, NULL, 0, &dwMasterClock, sizeof(dwMasterClock), 0);

	AT91SAM926x_SetChipSelectTimingIn_ns(	g_pSMC					,  // SMC register
											AT91C_IDE_CHIPSELECT	,  // Chip Select
											dwMasterClock			,  // Master Clock value
											AT91C_IDE_NWE_SETUP		,  // NWE_SETUP
											AT91C_IDE_NCS_WR_SETUP	,  // NCS_WR_SETUP
											AT91C_IDE_NRD_SETUP		,  // NRD_SETUP
											AT91C_IDE_NCS_RD_SETUP	,  // NCS_RD_SETUP
											AT91C_IDE_NWE_PULSE		,  // NWE_PULSE		
											AT91C_IDE_NCS_WR_PULSE	,  // NCS_WR_PULSE
											AT91C_IDE_NRD_PULSE		,  // NRD_PULSE
											AT91C_IDE_NCS_RD_PULSE	,  // NCS_RD_PULSE
											AT91C_IDE_NRD_CYCLE		,  // NRD_CYCLE
											AT91C_IDE_NWE_CYCLE		); // NWE_CYCLE

	// Configure SMC CS4 6X/61
	// NWAIT disabled, Byte select access mode, Data on 16b 
	// Byte select means : Write controled by ncs, nbs0, nbs1, nbs2, nbs3. Read controled by ncs, nrd, nbs0, nbs1, nbs2, nbs3.
	//JJH g_pSMC->SMC_CTRL4 = (AT91C_SMC_READMODE | AT91C_SMC_WRITEMODE | AT91C_SMC_NWAITM_NWAIT_DISABLE | AT91C_SMC_BAT_BYTE_SELECT | AT91C_SMC_DBW_WIDTH_SIXTEEN_BITS);

	g_pSMC->SMC_CTRL4 = (AT91C_SMC_READMODE | AT91C_SMC_WRITEMODE | AT91C_SMC_NWAITM_NWAIT_DISABLE | AT91C_SMC_BAT_BYTE_SELECT | AT91C_SMC_DBW_WIDTH_SIXTEEN_BITS);

	// Configure the PIO to Drive the HDD
	pio_setup(hw_pio, sizeof(hw_pio)/sizeof(struct pio_desc));

	Sleep(10); // wait 10 ms

	pio_set_value(AT91C_PIN_PA(30), 1);

	// Out
	DEBUGMSG(1, (TEXT("<-AT91_IDEConfigure\n\r")));
	g_IDEInitialized = bRet;

	return bRet;

}


//-----------------------------------------------------------------------------
//! \fn			VOID AT91_IDEDeInit()
//!
//! \brief		DeInitialize SMC, EBI and PIO HW blocks from AT91SAM926x for IDE usage
//!
//-----------------------------------------------------------------------------
VOID AT91_IDEDeInit()
{

	// Deinit registers addresses
	MmUnmapIoSpace((LPVOID) g_pMatrix, sizeof(AT91S_MATRIX));
	MmUnmapIoSpace((LPVOID) g_pSMC, sizeof(AT91S_SMC));
	
	g_pMatrix = NULL;
	g_pSMC    = NULL;	
}


//! @}
//-----------------------------------------------------------------------------
// End of $RCSfile: atapiebi.cpp,v $
//-----------------------------------------------------------------------------
//! @}

