//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file	Pwmc_DbgZones.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/DRIVERS/PwmC/Pwmc_DbgZones.h $
//!   $Author: pblanchard $
//!   $Revision: 1021 $
//!   $Date: 2007-06-20 08:50:46 -0700 (Wed, 20 Jun 2007) $
//! \endif
//! 
//! Debug zones masks and declaration
//-----------------------------------------------------------------------------
//! \addtogroup	PWMC
//! @{

#ifndef __PWMC_DBGZONES_H__
#define __PWMC_DBGZONES_H__

#include <DBGAPI.H>

#define DEBUGMASK(n) (0x00000001<<n)

#define MASK_INIT    DEBUGMASK(0)
#define MASK_DEINIT  DEBUGMASK(1)
#define MASK_OPEN    DEBUGMASK(2)
#define MASK_CLOSE   DEBUGMASK(3)
#define MASK_READ    DEBUGMASK(4)
#define MASK_WRITE   DEBUGMASK(5)
#define MASK_SEEK    DEBUGMASK(6)
#define MASK_IOCTL   DEBUGMASK(7)
#define MASK_ZONE8   DEBUGMASK(8)
#define MASK_ZONE9   DEBUGMASK(9)
#define MASK_ZONE10  DEBUGMASK(10)
#define MASK_ZONE11  DEBUGMASK(11)
#define MASK_ZONE12  DEBUGMASK(12)
#define MASK_INFO    DEBUGMASK(13)
#define MASK_WARN    DEBUGMASK(14)
#define MASK_ERROR   DEBUGMASK(15)


#define ZONE_INIT    DEBUGZONE(0)
#define ZONE_DEINIT  DEBUGZONE(1)
#define ZONE_OPEN    DEBUGZONE(2)
#define ZONE_CLOSE   DEBUGZONE(3)
#define ZONE_READ    DEBUGZONE(4)
#define ZONE_WRITE   DEBUGZONE(5)
#define ZONE_SEEK    DEBUGZONE(6)
#define ZONE_IOCTL   DEBUGZONE(7)
#define ZONE_ZONE8   DEBUGZONE(8)
#define ZONE_ZONE9   DEBUGZONE(9)
#define ZONE_ZONE10  DEBUGZONE(10)
#define ZONE_ZONE11  DEBUGZONE(11)
#define ZONE_ZONE12  DEBUGZONE(12)
#define ZONE_INFO    DEBUGZONE(13)
#define ZONE_WARN    DEBUGZONE(14)
#define ZONE_ERROR   DEBUGZONE(15)

#endif /*__PWMC_DBGZONES_H__*/

// End of Doxygen group Pwmc
//! @}
// End of Doxygen group Driver
//! @}

//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/DRIVERS/PwmC/Pwmc_DbgZones.h $
//-----------------------------------------------------------------------------
//
