//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9263_oal_hmatrix.h
//!
//! \brief		Definitions of the HMATRIX type
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/INC/AT91SAM9263_oal_hmatrix.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//-----------------------------------------------------------------------------


#ifndef AT91SAM9263_OALHMATRIX_H
#define AT91SAM9263_OALHMATRIX_H


#define UNDEFINED_BURST_LENGTH_NOT_SPLIT						0x0
#define UNDEFINED_BURST_LENGTH_SPLIT_IN_1_BEAT_BURST			0x1
#define UNDEFINED_BURST_LENGTH_SPLIT_IN_4_BEAT_BURST			0x2
#define UNDEFINED_BURST_LENGTH_SPLIT_IN_8_BEAT_BURST			0x3
#define UNDEFINED_BURST_LENGTH_SPLIT_IN_16_BEAT_BURST			0x4

#define AT91SAM9263_NB_MASTER	9
#define AT91SAM9263_NB_SLAVES	8


typedef enum {
	RoundRobin,
	Priority
} T_ARBITRATION_TYPE;

typedef enum {
	NoDefaultMaster,
	LastMaster,
	FixedMaster,
} T_MASTER_TYPE;


typedef struct {
	T_ARBITRATION_TYPE eArbitrationType; //<! Arbitration type. It can be RoundRobin or priority based	
	T_MASTER_TYPE eDefaultMasterType; //<! Default Master Type. I can be "No default master", "Last Master" or "Fixed Master"
	UCHAR ucFixedDefaultMasterID; //<<! Fixed Default Master ID. In case we're using the Fiwed Master type, this is its ID.
	UCHAR ucMaximumNumberOfAllowedCyclesForABurst;
	UCHAR ucMasterPriority[AT91SAM9263_NB_MASTER]; //<<! For each master; It gives its priority (in case we're using priority-base arbitration.
} T_SLAVE_CONFIG;



#define MAX_CYCLE_FOR_A_BURST	0x255
#define MAX_MASTER_PRIORITY		0x3

extern BOOL AT91SAM926x_ConfigureHMatrix(AT91PS_MATRIX pMatrix,T_SLAVE_CONFIG * pSlaveCfg, DWORD dwNbSlaves,DWORD * pMasterCfg, DWORD dwNbMaster);

#endif

//! @}


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/INC/AT91SAM9263_oal_hmatrix.h $
////////////////////////////////////////////////////////////////////////////////
//
