//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//! All rights reserved ADENEO SAS 2005
//!
//! \brief		Stream driver for the Keypad embedded on the AT91SAM9263EK EvalBoard
//
//! \file 	custom_keypad.hpp
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/KeyPad/custom_keypad.hpp $
//!   $Author: jjhiblot $
//!   $Revision: 879 $
//!   $Date: 2007-05-24 15:41:06 +0200 (jeu., 24 mai 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

//! \addtogroup	Keypad
//! @{
//!
#ifndef __CUSTOM_KEYPAD_H__
#define __CUSTOM_KEYPAD_H__


////////////////////////////////////////////////////////////////////////////////
//                                                                      Includes
////////////////////////////////////////////////////////////////////////////////
// Local include
#include "keypad.hpp"


class CustomKeyPad: public KeyPad
{
public:

	CustomKeyPad();
	
// To be implemented or overrided
	// 
	BOOL CustomInitialize(LPCTSTR pContext);
	BOOL CustomDeinitialize(void);
	
	// Power Management
	BOOL KeyPadPowerOff(void);
	BOOL KeyPadPowerOn(void);

	// Get the keypad keys state (1 bit for each key)
	DWORD GetKeypadState(void);

private:
	BOOL RegQueryDword (HKEY hKey, LPWSTR lpKeyName, DWORD *pdwValue);
	
	void GetKeysAssignement(HKEY hKey);
	BOOL GetGPIOAssignement(HKEY hKey);

	void GPiosInit();

	BOOL m_bExitIST;

	// Variables
	DWORD m_dwKeysGPio[KEYPAD_MAX_KEY_NUMBER];

	DWORD *m_dwKeysStates;
};

#endif // __CUSTOM_KEYPAD_H__

//! @}

//! @}
