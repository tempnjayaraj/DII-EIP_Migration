//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//  
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		Pwmc.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/DRIVERS/PwmC/Pwmc.h $
//!   $Author: pblanchard $
//!   $Revision: 1021 $
//!   $Date: 2007-06-20 08:50:46 -0700 (Wed, 20 Jun 2007) $
//! \endif
//!
//! Header for Pwmc driver
//-----------------------------------------------------------------------------
//! \addtogroup	PWMC
//! @{

#ifndef __PWMC_H__
#define __PWMC_H__

#define MAX_PWMC_CHANNEL	3  //there's 4 channels : 0,1,2 and 3
#define MAX_DIVIDER			1024 
#define PWMC_PRECISION_FACTOR  100  //Precision factor = (pwm frequency) / min(duty cycle)
#define MAX_CPRD				0xFFFF
/*! \brief Initialization context
	this structure contains the information needed by the driver to manage the hardware that is common to all of its instances
*/
typedef struct {
	AT91PS_PMC	pPMC_VirtualBase;	//!<Base Address of PMC
	AT91PS_PWMC	pPWMC_VirtualBase;	//!<Base Address of the PWM controller
	DWORD		dwIndex;			//!<Index of the peripheral	
	HKEY		hKey;				//!<Registry Key
} T_PWMC_INIT_STRUCTURE;

/*! \brief Initialization context
	this structure contains the information needed by the driver to manage the hardware that is specific to a particular instance
*/
typedef struct {
	T_PWMC_INIT_STRUCTURE * pDeviceContext;	//!<Pointer on a device context
	DWORD dwConfiguredAtLeastOneTime;		//!<Flag to know if the PWM is configured
} T_PWMC_OPEN_STRUCTURE;

extern BOOL ConfigurePioForPWM(DWORD dwIndex);

#endif /*__PWMC_H__*/

//! @}
//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/DRIVERS/PwmC/Pwmc.h $
//-----------------------------------------------------------------------------
