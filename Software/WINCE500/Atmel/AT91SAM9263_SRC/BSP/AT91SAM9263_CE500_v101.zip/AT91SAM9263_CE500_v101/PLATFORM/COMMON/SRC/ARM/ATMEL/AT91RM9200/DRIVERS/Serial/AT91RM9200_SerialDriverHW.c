//-----------------------------------------------------------------------------
//! \addtogroup   Serial
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				AT91RM9200_SerialDriverHW.c
//!
//! \brief				Serial driver for AT91RM9200 chipset
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/DRIVERS/Serial/AT91RM9200_SerialDriverHW.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------


// System include
#include <windows.h>
#include <memory.h>
#include <nkintr.h>
#include <CEDDK.h>
#include <devload.h>
#include <Serhw.h>

// Local include
#include "AT91RM9200.h"
#include "lib_AT91RM9200.h"
#include "AT91RM9200_Serial_DbgZones.h"
#include "AT91RM9200_SerialDriver.h" 

extern DWORD g_dwMasterClock;

#define CSRINTS	0xFFFFF

//-----------------------------------------------------------------------------
//! \fn		BOOL AT91SERIAL_SetBreak(T_SERIALINIT_STRUCTURE *pInitContext)
//!
//! 
//-----------------------------------------------------------------------------
VOID AT91SERIAL_SetBreak(T_SERIALINIT_STRUCTURE *pInitContext)
{
	if (pInitContext == NULL)
		return ;

	DEBUGMSG(DBG_FUNCTION, (TEXT("+AT91SERIAL_SetBreak (STTBRK) 0x%X\r\n"), pInitContext));

	EnterCriticalSection(&pInitContext->csUsartReg);

	// Enable Break and tx clock
	pInitContext->pUSARTReg->US_CR = AT91C_US_STTBRK | AT91C_US_TXEN;

	LeaveCriticalSection(&pInitContext->csUsartReg);

	DEBUGMSG(DBG_FUNCTION, (TEXT("-AT91SERIAL_SetBreak (STTBRK) 0x%X\r\n"), pInitContext));
	
}

//-----------------------------------------------------------------------------
//! \fn		BOOL AT91SERIAL_ClearBreak(T_SERIALINIT_STRUCTURE *pInitContext)
//!
//! 
//-----------------------------------------------------------------------------
VOID AT91SERIAL_ClearBreak(T_SERIALINIT_STRUCTURE *pInitContext)
{
	if (pInitContext == NULL)
		return ;

	DEBUGMSG(DBG_FUNCTION, (TEXT("+AT91SERIAL_ClearBreak (STPBRK) 0x%X\r\n"), pInitContext));

	EnterCriticalSection(&pInitContext->csUsartReg);

	// Clear break and tx clock
	pInitContext->pUSARTReg->US_CR = AT91C_US_STPBRK | AT91C_US_TXDIS;

	LeaveCriticalSection(&pInitContext->csUsartReg);

	DEBUGMSG(DBG_FUNCTION, (TEXT("-AT91SERIAL_ClearBreak (DTRDIS) 0x%X\r\n"), pInitContext));
	
}


//-----------------------------------------------------------------------------
//! \fn		BOOL AT91SERIAL_SetRTS(T_SERIALINIT_STRUCTURE *pInitContext)
//!
//! 
//-----------------------------------------------------------------------------
VOID AT91SERIAL_SetDTR(T_SERIALINIT_STRUCTURE *pInitContext)
{
	if (pInitContext == NULL)
		return ;

	DEBUGMSG(DBG_FUNCTION, (TEXT("+AT91SERIAL_SetDTR (DTREN) 0x%X\r\n"), pInitContext));

	EnterCriticalSection(&pInitContext->csUsartReg);

	pInitContext->pUSARTReg->US_CR = AT91C_US_DTREN;

	LeaveCriticalSection(&pInitContext->csUsartReg);

	DEBUGMSG(DBG_FUNCTION, (TEXT("-AT91SERIAL_SetDTR (DTREN) 0x%X\r\n"), pInitContext));
	
}

//-----------------------------------------------------------------------------
//! \fn		VOID AT91SERIAL_ClearDTR(T_SERIALINIT_STRUCTURE *pInitContext)
//!
//! 
//-----------------------------------------------------------------------------
VOID AT91SERIAL_ClearDTR(T_SERIALINIT_STRUCTURE *pInitContext)
{
	if (pInitContext == NULL)
		return ;

	DEBUGMSG(DBG_FUNCTION, (TEXT("+AT91SERIAL_ClearDTR (DTRDIS) 0x%X\r\n"), pInitContext));

	EnterCriticalSection(&pInitContext->csUsartReg);

	pInitContext->pUSARTReg->US_CR = AT91C_US_DTRDIS;

	LeaveCriticalSection(&pInitContext->csUsartReg);

	DEBUGMSG(DBG_FUNCTION, (TEXT("-AT91SERIAL_ClearDTR (DTRDIS) 0x%X\r\n"), pInitContext));
	
}


//-----------------------------------------------------------------------------
//! \fn		BOOL AT91SERIAL_SetRTS(T_SERIALINIT_STRUCTURE *pInitContext)
//!
//! 
//-----------------------------------------------------------------------------
VOID AT91SERIAL_SetRTS(T_SERIALINIT_STRUCTURE *pInitContext)
{
	if (pInitContext == NULL)
		return ;

	pInitContext->pUSARTReg->US_CR = AT91C_US_RTSEN;

}

//-----------------------------------------------------------------------------
//! \fn		BOOL AT91SERIAL_ClearRTS(T_SERIALINIT_STRUCTURE *pInitContext)
//!
//!
//! 
//-----------------------------------------------------------------------------
VOID AT91SERIAL_ClearRTS(T_SERIALINIT_STRUCTURE *pInitContext)
{
	if (pInitContext == NULL)
		return ;

	pInitContext->pUSARTReg->US_CR = AT91C_US_RTSDIS;
	
}

//-----------------------------------------------------------------------------
//! \fn		BOOL AT91SERIAL_SetParity(T_SERIALINIT_STRUCTURE *pInitContext, DWORD dwStopBits)
//!
//! 
//! 
//-----------------------------------------------------------------------------
BOOL AT91SERIAL_SetParity(T_SERIALINIT_STRUCTURE *pInitContext, DWORD dwParity)
{
	BOOL bRet = TRUE;
	DWORD dwUS_MR = 0x00000000;

	if (pInitContext == NULL)
		return FALSE;

	EnterCriticalSection(&pInitContext->csUsartReg);

	dwUS_MR = pInitContext->pUSARTReg->US_MR & ~AT91C_US_PAR;

	switch (dwParity)
	{
		case EVENPARITY:
			dwUS_MR |= AT91C_US_PAR_EVEN;
			break;

		case MARKPARITY:
			dwUS_MR |= AT91C_US_PAR_MARK;
			break;

		case NOPARITY:
			dwUS_MR |= AT91C_US_PAR_NONE;
			break;

		case ODDPARITY:
			dwUS_MR |= AT91C_US_PAR_ODD;
			break;

		case SPACEPARITY:
			dwUS_MR |= AT91C_US_PAR_SPACE;
			break;

		default:
			bRet = FALSE;
	}

	if (bRet)
	{
		pInitContext->pUSARTReg->US_MR = dwUS_MR;
	}

	LeaveCriticalSection(&pInitContext->csUsartReg);

	DEBUGMSG(DBG_FUNCTION, (TEXT("-AT91SERIAL_SetParity 0x%X, PAR = 0x%08X\r\n"), pInitContext, dwUS_MR));



	return bRet;
}



//-----------------------------------------------------------------------------
//! \fn		BOOL AT91SERIAL_SetStopBits(T_SERIALINIT_STRUCTURE *pInitContext, DWORD dwStopBits)
//!
//!
//-----------------------------------------------------------------------------
BOOL AT91SERIAL_SetStopBits(T_SERIALINIT_STRUCTURE *pInitContext, DWORD dwStopBits)
{
	
	
	BOOL bRet = TRUE;
	DWORD dwUS_MR = 0x00000000;

	if (pInitContext == NULL)
		return FALSE;

	EnterCriticalSection(&pInitContext->csUsartReg);

	dwUS_MR = pInitContext->pUSARTReg->US_MR & ~AT91C_US_NBSTOP;

	switch (dwStopBits)
	{
		case ONESTOPBIT:
			dwUS_MR |= AT91C_US_NBSTOP_1_BIT;
			break;

		case ONE5STOPBITS:
			dwUS_MR |= AT91C_US_NBSTOP_15_BIT;
			break;

		case TWOSTOPBITS:
			dwUS_MR |= AT91C_US_NBSTOP_2_BIT;
			break;

		default:
			bRet = FALSE;
	}

	if (bRet)
	{
		pInitContext->pUSARTReg->US_MR = dwUS_MR;
	}

	LeaveCriticalSection(&pInitContext->csUsartReg);

	DEBUGMSG(DBG_FUNCTION, (TEXT("-AT91SERIAL_SetByteSize 0x%X, NBSTOP = 0x%08X\r\n"), pInitContext, dwUS_MR));



	return bRet;
}



//-----------------------------------------------------------------------------
//! \fn		BOOL AT91SERIAL_SetByteSize(T_SERIALINIT_STRUCTURE *pInitContext, DWORD dwByteSize)
//!
//!
//-----------------------------------------------------------------------------
BOOL AT91SERIAL_SetByteSize(T_SERIALINIT_STRUCTURE *pInitContext, DWORD dwByteSize)
{
	BOOL bRet = TRUE;
	DWORD dwUS_MR = 0x00000000;

	if (pInitContext == NULL)
		return FALSE;

	EnterCriticalSection(&pInitContext->csUsartReg);

	dwUS_MR = pInitContext->pUSARTReg->US_MR & ~AT91C_US_CHRL;

	switch (dwByteSize)
	{
		case 5:
			dwUS_MR |= AT91C_US_CHRL_5_BITS;
			break;

		case 6:
			dwUS_MR |= AT91C_US_CHRL_6_BITS;
			break;

		case 7:
			dwUS_MR |= AT91C_US_CHRL_7_BITS;
			break;

		case 8:
			dwUS_MR |= AT91C_US_CHRL_8_BITS;
			break;

		default:
			bRet = FALSE;
	}

	if (bRet)
	{
		pInitContext->pUSARTReg->US_MR = dwUS_MR;
	}

	LeaveCriticalSection(&pInitContext->csUsartReg);

	DEBUGMSG(DBG_FUNCTION, (TEXT("-AT91SERIAL_SetByteSize 0x%X, CHRL = 0x%08X\r\n"), pInitContext, dwUS_MR));

	return bRet;

}

//-----------------------------------------------------------------------------
//! \fn		BOOL AT91SERIAL_SetMode(T_SERIALINIT_STRUCTURE *pInitContext, DWORD dwfRtsControl, DWORD dwfDtrControl)
//!
//!
//-----------------------------------------------------------------------------
BOOL AT91SERIAL_SetMode(T_SERIALINIT_STRUCTURE *pInitContext, DWORD dwfRtsControl, DWORD dwfDtrControl)
{
	BOOL bRet = TRUE;
	DWORD dwUSMode = (pInitContext->pUSARTReg->US_MR & AT91C_US_USMODE);
	
	DEBUGMSG(DBG_FUNCTION, (TEXT("+AT91SERIAL_SetMode 0x%X, Current mode = 0x%08X\r\n"), pInitContext, dwUSMode));
		
	if (dwUSMode == AT91C_US_USMODE_NORMAL ||
		dwUSMode == AT91C_US_USMODE_HWHSH  ||
		dwUSMode == AT91C_US_USMODE_MODEM)
	{

		// Normal mode no CTS/RTS and no DSR/DTR control
		if (dwfRtsControl != RTS_CONTROL_HANDSHAKE && dwfDtrControl != DTR_CONTROL_HANDSHAKE)
		{
			pInitContext->pUSARTReg->US_MR &= ~AT91C_US_USMODE;
			pInitContext->pUSARTReg->US_MR |= AT91C_US_USMODE_NORMAL;
			
			DEBUGMSG(DBG_FUNCTION, (TEXT(".AT91SERIAL_SetMode 0x%X, Set new Usart mode NORMAL\r\n"), pInitContext));
		}
		// Hardware Handshaking mode only CTS/RTS control
		else if (dwfRtsControl == RTS_CONTROL_HANDSHAKE && dwfDtrControl != DTR_CONTROL_HANDSHAKE)
		{
			pInitContext->pUSARTReg->US_MR &= ~AT91C_US_USMODE;
			///////////// IF RTS doesn't work try to change the value from MODEM to HardwareHandshake
			pInitContext->pUSARTReg->US_MR |= AT91C_US_USMODE_MODEM;//AT91C_US_USMODE_HWHSH;

			DEBUGMSG(DBG_FUNCTION, (TEXT(".AT91SERIAL_SetMode 0x%X, Set new Usart mode MODEM (not HARDWARE HANDSHAKING)\r\n"), pInitContext));
		}
		// Modem mode no CTS/RTS and DSR/DTR control
		else if (dwfRtsControl == RTS_CONTROL_HANDSHAKE && dwfDtrControl == DTR_CONTROL_HANDSHAKE)
		{
			pInitContext->pUSARTReg->US_MR &= ~AT91C_US_USMODE;
			pInitContext->pUSARTReg->US_MR |= AT91C_US_USMODE_MODEM;

			DEBUGMSG(DBG_FUNCTION, (TEXT(".AT91SERIAL_SetMode 0x%X, Set new Usart mode MODEM\r\n"), pInitContext));

		}
		// Unsupported configuration
		else if (dwfRtsControl != RTS_CONTROL_HANDSHAKE && dwfDtrControl == DTR_CONTROL_HANDSHAKE)
		{
			DEBUGMSG(DBG_FUNCTION, (TEXT(".AT91SERIAL_SetMode 0x%X, Unsupported mode check the DCB flags\r\n"), pInitContext));
			bRet = FALSE;
		}
		
	}
	
	DEBUGMSG(DBG_FUNCTION, (TEXT("-AT91SERIAL_SetMode 0x%X\r\n"), pInitContext));

	return bRet;
}

//-----------------------------------------------------------------------------
//! \fn		DWORD AT91SERIAL_ReadCSR(T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//!
//-----------------------------------------------------------------------------
DWORD AT91SERIAL_ReadCSR(T_SERIALINIT_STRUCTURE *pInitContext)
{
	pInitContext->dwBufferedCSR = pInitContext->pUSARTReg->US_CSR | (pInitContext->dwBufferedCSR & CSRINTS);
	return pInitContext->dwBufferedCSR;
}

//-----------------------------------------------------------------------------
//! \fn		DWORD AT91SERIAL_ClearCSR(T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//!
//-----------------------------------------------------------------------------
VOID AT91SERIAL_ClearCSR(T_SERIALINIT_STRUCTURE *pInitContext)
{
	pInitContext->dwBufferedCSR &= ~CSRINTS;
}


//-----------------------------------------------------------------------------
//! \fn		VOID AT91SERIAL_SetCommTimeouts(T_SERIALINIT_STRUCTURE *pInitContext, LPCOMMTIMEOUTS lpCommTimeouts)
//!
//!
//-----------------------------------------------------------------------------
VOID AT91SERIAL_SetCommTimeouts(T_SERIALINIT_STRUCTURE *pInitContext, LPCOMMTIMEOUTS lpCommTimeouts)
{
	DWORD dwBitsPeriod;

	if (pInitContext == NULL)
		return ;


	// OK, first check for any changes and act upon them
	// Now that we have done the right thing, store this DCB
	pInitContext->commTimeouts = *lpCommTimeouts;

	dwBitsPeriod = ((lpCommTimeouts->ReadIntervalTimeout * pInitContext->dcb.BaudRate ) / 1000);
	
	// When nb_bit_period=0, we get an infinite timeout.
	// Due to the integer division, this value can be obtained, 
	// even if lpCommTimeouts->ReadIntervalTimeout is not 0.
	
	if ((lpCommTimeouts->ReadIntervalTimeout != 0) && (dwBitsPeriod == 0))
	{
		dwBitsPeriod = 0x0001;
	}


	if (dwBitsPeriod > 0xFFFF)
	{
		dwBitsPeriod = 0xFFFF;		
	}
	
	EnterCriticalSection(&pInitContext->csUsartReg);

	pInitContext->pUSARTReg->US_RTOR = dwBitsPeriod;

	LeaveCriticalSection(&pInitContext->csUsartReg);
	

	DEBUGMSG(DBG_FUNCTION,(TEXT("-AT91SERIAL_SetCommTimeouts 0x%X, RTOR = 0x%08X\r\n"), pInitContext, dwBitsPeriod));
}

//-----------------------------------------------------------------------------
//! \fn		BOOL AT91SERIAL_SetBaudRate (T_SERIALINIT_STRUCTURE *pInitContext, DWORD dwBaudRate)
//!
//!
//-----------------------------------------------------------------------------
BOOL AT91SERIAL_SetBaudRate (T_SERIALINIT_STRUCTURE *pInitContext, DWORD dwBaudRate)
{

	BOOL bRet = TRUE;

	if (pInitContext == NULL || dwBaudRate == 0)
		return FALSE;

	EnterCriticalSection(&pInitContext->csUsartReg);
	
	pInitContext->pUSARTReg->US_BRGR = AT91F_US_Baudrate(g_dwMasterClock, dwBaudRate);

	//The baudrate has changed, so the Interval Timeout clipping has changed as well, set the right timeout
	AT91SERIAL_SetCommTimeouts(pInitContext, &pInitContext->commTimeouts);


	LeaveCriticalSection(&pInitContext->csUsartReg);

	// Store new baud rate
	pInitContext->dcb.BaudRate = dwBaudRate;


	DEBUGMSG(DBG_FUNCTION,(TEXT("-AT91SERIAL_SetBaudRate 0x%X, BaudRate = %d\r\n"), pInitContext, dwBaudRate));

	return bRet;
}

//! @}
