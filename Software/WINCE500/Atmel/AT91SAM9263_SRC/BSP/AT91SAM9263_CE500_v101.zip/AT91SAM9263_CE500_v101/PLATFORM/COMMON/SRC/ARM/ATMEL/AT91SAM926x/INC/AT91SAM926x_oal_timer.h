//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x_oal_timer.h
//!
//! \brief		Timer Interrupt management header file
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/AT91SAM926x_oal_timer.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//!
//! The API is a bit different from the 
//! usual OALTimerIntrHandler. The parameter is the value of the counter when the
//! ionterrupt handler is entered
//-----------------------------------------------------------------------------



#ifndef AT91SAM926X_OALTIMER_H
#define AT91SAM926X_OALTIMER_H

UINT32 OALTimerIntrHandlerWithILTSupport(DWORD);

UINT32 OALTimerEnterIdle(UINT32 period, UINT32 margin);

UINT32 OALTimerExitFromIdle(UINT32 period, UINT32 margin);

#endif /*AT91SAM926X_OALTIMER_H*/

//! @}
