//-----------------------------------------------------------------------------
//! \addtogroup   OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				map.c
//!
//! \brief				The file implement simple table/array based mapping between IRQ and SYSINTR
//!  which is suitable for most OAL implementations. It is a derivative of the Microsoft's implementation, only with more IRQ entries
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/KERNEL/INTR/map.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

#include <windows.h>
#include <nkintr.h>
#include <oal_intr.h>
#include <oal_log.h>

//------------------------------------------------------------------------------
//table of translation SysIntr -> IRQ
extern UINT32 g_oalSysIntr2Irq[];

//table of translation IRQ -> SysIntr
extern UINT32 g_oalIrq2SysIntr[];

//Max size of g_oalIrq2SysIntr (ie max physical interrupt number)
extern const DWORD oal_intr_irq_maximum; 


//-----------------------------------------------------------------------------
//! \fn			VOID OALIntrMapInit()
//!
//! \brief		This function must be called from OALInterruptInit to initialize mapping
//!				between IRQ and SYSINTR. It simply initialize mapping arrays.
//!
//-----------------------------------------------------------------------------
VOID OALIntrMapInit()
{
    UINT32 i;
    
    RETAILMSG(1, (L"+OALIntrMapInit\r\n"));

    // Initialize interrupt maps
    for (i = 0; i < SYSINTR_MAXIMUM; i++) {
        g_oalSysIntr2Irq[i] = OAL_INTR_IRQ_UNDEFINED;
    }
    for (i = 0; i < oal_intr_irq_maximum; i++) {
        g_oalIrq2SysIntr[i] = SYSINTR_UNDEFINED;
    }

    RETAILMSG(1, (L"-OALIntrMapInit\r\n"));
}


//-----------------------------------------------------------------------------
//! \fn			VOID OALIntrStaticTranslate(UINT32 sysIntr, UINT32 irq)
//!
//! \brief		This function sets static translation between IRQ and SYSINTR. In most
//!				cases it should not be used. Only exception is mapping for 
//!				SYSINTR_RTC_ALARM and obsolete device drivers.
//!
//! \param		sysIntr	sysIntr to associate
//! \param		irq	irq to associate
//!
//-----------------------------------------------------------------------------
VOID OALIntrStaticTranslate(UINT32 sysIntr, UINT32 irq)
{
    RETAILMSG(1, (
        L"+OALIntrStaticTranslate(%d, %d)\r\n", sysIntr, irq
    ));
    if (irq < oal_intr_irq_maximum && sysIntr < SYSINTR_MAXIMUM) {
        g_oalSysIntr2Irq[sysIntr] = irq;
        g_oalIrq2SysIntr[irq] = sysIntr;
    }        
    RETAILMSG(1, (L"-OALIntrStaticTranslate\r\n"));
}


//-----------------------------------------------------------------------------
//! \fn			BOOL OALIntrTranslateSysIntr(UINT32 sysIntr, UINT32 *pCount, const UINT32 **ppIrqs)
//!
//! \brief		This function maps a SYSINTR to its corresponding IRQ. It is typically used
//!				in OEMInterruptXXX to obtain IRQs for given SYSINTR.
//!
//! \param		sysIntr	sysIntr requested
//! \param		pCount Number of IRQs associated with sysIntr
//! \param		ppIrqs Pointer to table of IRQs associated with sysIntr
//!
//! \return		TRUE if SysIntr is valid, FALSE if not
//!
//-----------------------------------------------------------------------------
BOOL OALIntrTranslateSysIntr(
    UINT32 sysIntr, UINT32 *pCount, const UINT32 **ppIrqs
) {
    BOOL rc;
    
    // Valid SYSINTR?
    if (sysIntr >= SYSINTR_MAXIMUM) {
        rc = FALSE;
    }
    else
	{
		*pCount = 1;
		*ppIrqs = &g_oalSysIntr2Irq[sysIntr];
		rc = TRUE;
	}

    return rc;
}



 
//-----------------------------------------------------------------------------
//! \fn			UINT32 OALIntrTranslateIrq(UINT32 irq)
//!
//! \brief		This function maps a IRQ to its corresponding SYSINTR.
//!
//! \param		irq irq requested
//!
//! \return		SysIntr associated with irq in parameter
//!
//-----------------------------------------------------------------------------
UINT32 OALIntrTranslateIrq(UINT32 irq)
{
    UINT32 sysIntr = SYSINTR_UNDEFINED;
    

    if (irq < oal_intr_irq_maximum)
	{
	    sysIntr = g_oalIrq2SysIntr[irq];
	}

    return sysIntr;
}


//-----------------------------------------------------------------------------
//! \fn			UINT32 OALIntrRequestSysIntr(UINT32 count, const UINT32 *pIrqs, UINT32 flags)
//!
//! \brief		This function allocate new SYSINTR for given IRQ and it there isn't
//!				static mapping for this IRQ it will create it.
//!
//! \param		count	Number of irqs in pIrqs
//!	\param		pIrqs	Table of Irqs wich request SysIntr
//!	\param		flags	Flags for the request
//!
//! \return		SysIntr associated with irqs in pIrqs
//!
//-----------------------------------------------------------------------------
UINT32 OALIntrRequestSysIntr(UINT32 count, const UINT32 *pIrqs, UINT32 flags)
{
    int i;
    UINT32 irq, sysIntr = SYSINTR_UNDEFINED;

    RETAILMSG(1, (
        L"+OALIntrRequestSysIntr(%d, 0x%08x , 0x%08x)\r\n", count, pIrqs, flags
    ));
    
    // Valid IRQ?
    if (count != 1 || pIrqs[0] >= oal_intr_irq_maximum) {
        sysIntr = SYSINTR_UNDEFINED;            
        return sysIntr;
    }
  
    irq = pIrqs[0];

    // If there is mapping for given irq check for special cases
    if (g_oalIrq2SysIntr[irq] != SYSINTR_UNDEFINED) {
        // If static mapping is requested we fail
        if ((flags & OAL_INTR_STATIC) != 0) {
            RETAILMSG(1, (L"ERROR: OALIntrRequestSysIntr: "
               L"Static mapping for IRQ %d already assigned\r\n", irq
            ));
            sysIntr = SYSINTR_UNDEFINED;            
			return sysIntr;
        }
        // If we should translate, return existing SYSINTR
        if ((flags & OAL_INTR_TRANSLATE) != 0) {
            sysIntr = g_oalIrq2SysIntr[irq];
            return sysIntr;
        }
    }

    // Find next available SYSINTR value...
    for (sysIntr = SYSINTR_FIRMWARE; sysIntr < SYSINTR_MAXIMUM; sysIntr++) {
        if (g_oalSysIntr2Irq[sysIntr] == OAL_INTR_IRQ_UNDEFINED) break;
    }
    
    // Any available SYSINTRs left?
    if (sysIntr >= SYSINTR_MAXIMUM) {
        RETAILMSG(1, (L"ERROR: OALIntrRequestSysIntr: "
            L"No avaiable SYSINTR found\r\n"
        ));            
        sysIntr = SYSINTR_UNDEFINED;
        return sysIntr;
    }
    
    
   // Free IRQ? this is not mandatory because in some case we may want different SYINTR associated with the same physical IRQ
   //This check is more to help the developper not to intialize the same physical interrupt more than oncewithout knowing it,
   // than to test a failure case.
    for (i = SYSINTR_FIRMWARE;i < SYSINTR_MAXIMUM;i++) {
        if (g_oalSysIntr2Irq[i] == pIrqs[0])
        {
        	//There is another sysintr associated with this IRQ, attract the developper's attention toward this fact.
    	   	RETAILMSG(1, ( L"+OALIntrRequestSysIntr IRQ (%d) already used by SYSINTR (%d)\r\n", pIrqs[0],i));       
	       	DEBUGCHK(0);
	       	break;
        }
    }

    // Make SYSINTR -> IRQ association.
    g_oalSysIntr2Irq[sysIntr] = irq;
    
    // Make IRQ -> SYSINTR association if required
    if ((flags & OAL_INTR_DYNAMIC) != 0) 
	{
		return sysIntr;
	}

    if (
        g_oalIrq2SysIntr[irq] == SYSINTR_UNDEFINED ||
        (flags & OAL_INTR_FORCE_STATIC) != 0
    ) {
        g_oalIrq2SysIntr[irq] = sysIntr;
    }

    RETAILMSG(1, (
        L"-OALIntrRequestSysIntr(sysIntr = %d)\r\n", sysIntr
    ));
    return sysIntr;
}



//-----------------------------------------------------------------------------
//! \fn			BOOL OALIntrReleaseSysIntr(UINT32 sysIntr)
//!
//! \brief		This function release given SYSINTR and remove static mapping if exists.
//!
//! \param		sysIntr		SysIntr to realesed
//!
//! \return		FALSE if sysIntr is already released, TRUE if not
//!
//-----------------------------------------------------------------------------
BOOL OALIntrReleaseSysIntr(UINT32 sysIntr)
{
    BOOL rc = FALSE;
    UINT32 irq;

    RETAILMSG(1, (L"+OALIntrReleaseSysIntr(%d)\r\n", sysIntr));

    // Is the SYSINTR already released?
    if (g_oalSysIntr2Irq[sysIntr] != OAL_INTR_IRQ_UNDEFINED)
	{
		// Remove the SYSINTR -> IRQ mapping
		irq = g_oalSysIntr2Irq[sysIntr];
		g_oalSysIntr2Irq[sysIntr] = OAL_INTR_IRQ_UNDEFINED;

		// If we're releasing the SYSINTR directly mapped in the IRQ mapping, 
		// remove the IRQ mapping also
		if (g_oalIrq2SysIntr[irq] == sysIntr) {
			g_oalIrq2SysIntr[irq] = SYSINTR_UNDEFINED;
		}
		rc = TRUE;
	}

    RETAILMSG(1, (L"-OALIntrReleaseSysIntr(rc = %d)\r\n", rc));
    return rc;
}

//! @}
