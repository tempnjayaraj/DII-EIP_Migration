//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x_interface.h
//!
//! \brief		AT91SAM926x API declaration
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/AT91SAM926x_interface.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//-----------------------------------------------------------------------------

#include "at91sam926x.h"

#ifdef __cplusplus
extern "C" {
#endif

///////////////////////////////////////////// PLL ////////////////////////////////////////////////////////


//------------------------------------------------------------------------------
//
//  Function:     GetMasterClock
//
//  This function is called by the kernel to retreive the value of the master clock in Hz
//

DWORD AT91SAM926x_GetMasterClock(BOOL bUseShadowedValue);

//------------------------------------------------------------------------------
//
//  Function:     GetPLLAClock
//
//  This function is called by the kernel to retreive the value of the PLLA clock in Hz
//

DWORD AT91SAM926x_GetPLLAClock(BOOL bUseShadowedValue);

//------------------------------------------------------------------------------
//
//  Function:     GetPLLBClock
//
//  This function is called by the kernel to retreive the value of the PLLB clock in Hz
//

DWORD AT91SAM926x_GetPLLBClock(BOOL bUseShadowedValue);

//------------------------------------------------------------------------------
//
//  Function:     GetProcessorClock
//
//  This function is called by the kernel to retreive the value of the Processor clock in Hz
//

DWORD AT91SAM926x_GetProcessorClock(BOOL bUseShadowedValue);



//------------------------------------------------------------------------------
//
//  Function:     GetMainClock
//
//  This function is called by the kernel to retreive the value of the main clock in Hz
//

DWORD AT91SAM926x_GetMainClock(BOOL bUseShadowedValue);

//------------------------------------------------------------------------------
//
//  Function:     AT91SAM926x_TurnProcessorClockOff
//
//  This function is called by the kernel to stop the processor clock
//

void AT91SAM926x_TurnProcessorClockOff();

//------------------------------------------------------------------------------
//
//  Function:     AT91SAM926x_WaitForInterrupt
//
//  This function is called by the kernel to stop the processor clock and enter the WaitForInterrupt mode.
//
void AT91SAM926x_WaitForInterrupt(volatile DWORD*);
void AT91SAM926x_SuspendWaitForInterrupt(volatile DWORD*);

DWORD AT91SAM926x_SetPLLBFreq(AT91PS_PMC pPMC,DWORD dwFreqInMHz, DWORD dwUSBDivider);

BOOL AT91SAM926x_SetProcessorAndMasterClocks(	AT91PS_PMC pPMC				,
												DWORD dwProcessorClockInMHz	,
												DWORD dwBusClockRatio		);

BOOL AT91SAM926x_SetChipSelectTimingIn_ns(	AT91PS_SMC pSMC			,
											DWORD dwChipSelect		,
											DWORD dwMasterClock		,
											DWORD dwNWE_SETUP		,
											DWORD dwNCS_WR_SETUP	,
											DWORD dwNRD_SETUP		,
											DWORD dwNCS_RD_SETUP	,
											DWORD dwNWE_PULSE		,										
											DWORD dwNCS_WR_PULSE	,
											DWORD dwNRD_PULSE		,
											DWORD dwNCS_RD_PULSE	,
											DWORD dwNRD_CYCLE		,
											DWORD dwNWE_CYCLE		);


///////////////////////////////////////////// System Timer ////////////////////////////////////////////////

//------------------------------------------------------------------------------
// in EBoot, the default system timer frequency is 1000 Hz (period = 1 ms)
// BUT if you set timer to 1ms, your timer will loop back to 0 every 4095 ms.
// AND IT's aren't used during bootloader, so we can set period to 200ms
// This trick extend looping back to 200 * 4096 ms = 819.2 s = 13.6 min
#define EBOOT_TIMER_PERIOD 200

#define AT91C_PITC_CPIVMASK	(0x000FFFFF)

//-----------------------------------------------------------------------------
// AT91SAM926x_Read_Interrupt_Counter
//
// Return the value of 12 high bits witch inc on each interrupt without reseting
// the 12 bits counter
//
DWORD AT91SAM926x_Read_Interrupt_Counter();

//-----------------------------------------------------------------------------
// AT91SAM926x_Read_MCKdiv16_Counter
//
// Return the value of 20 low bits witch inc on MCK/16 without reseting any counter
//
DWORD AT91SAM926x_Read_MCKdiv16_Counter();

//-----------------------------------------------------------------------------
// AT91SAM926x_Get_MSec_SinceLastSysTick
//
// Return number of milliseconds elapsed since last SysTick
//
DWORD AT91SAM926x_Get_MSec_SinceLastSysTick();

//------------------------------------------------------------------------------
//
//  Function:     AT91SAM926x_InitSystemTimer
//
//  This is called to initialize the system timer with a given period. Second parameter specifies if the period is in ms or in clk div 16 unit. Third parameter is here to enable or disable the interrupt
//
void AT91SAM926x_InitSystemTimer(DWORD period,BOOL periodIsMs, BOOL bUseInterrupt);


///////////////////////////////////////////// Serial //////////////////////////////////////////////////////
//------------------------------------------------------------------------------
//
//  Variable:     g_pDBGU
//
//  This variable is used by the AT91SAM926x API to know the base address of the DBGU controller.
// It must be initialized before the initialization code is used. otherwise the default value for the processor is used instead
//
extern AT91PS_DBGU g_pDBGU;
//------------------------------------------------------------------------------
//
//  Function:     AT91SAM926x_SetDebugSerialInterface
//
//  This function is called to set the value of g_pDBGU in a proper way
//

void AT91SAM926x_SetDebugSerialInterface(AT91PS_DBGU pDBGU);

#ifdef __cplusplus
 }
#endif

//! @}


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/AT91SAM926x_interface.h $
////////////////////////////////////////////////////////////////////////////////
//
