///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x_oal_profiler.h
//!
//! \brief		Profiler Timer header file. This is used to customize the profiler's timer
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/AT91SAM926x_oal_profiler.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//-----------------------------------------------------------------------------


#ifndef AT91SAM926X_OALPROFILER_H
#define AT91SAM926X_OALPROFILER_H

/*! \struct T_PROFILER_TIMER_DESCRIPTION
*  \brief This tye is used to describe a profiler's timer-counter. It contains its ID and its base address.
*/
typedef struct
{
	DWORD IdIrq; /*!< \brief ID of the Timer-counter \note ID and IRQ number are always the same...*/
	AT91PS_TC pTC;/*!< \brief physical base-address of the timer-counter*/
} T_PROFILER_TIMER_DESCRIPTION;

/*! \var T_PROFILER_TIMER_DESCRIPTION* pProfilerDesc 
	\brief pointer to the current timer-counter used for profiling 
*/
extern const T_PROFILER_TIMER_DESCRIPTION* pProfilerDesc; 
#endif /*AT91SAM926X_OALPROFILER_H*/


//! @}