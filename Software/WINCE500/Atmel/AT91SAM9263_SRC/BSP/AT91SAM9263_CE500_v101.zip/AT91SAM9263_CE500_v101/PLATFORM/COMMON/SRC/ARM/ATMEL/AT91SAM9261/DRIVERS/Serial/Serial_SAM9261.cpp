//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		Serial_SAM9261.cpp
//!
//! \brief		Serial driver functions specific to the AT91SAM9261 chipset
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9261/DRIVERS/Serial/Serial_SAM9261.cpp $
//!   $Author: pblanchard $
//!   $Revision: 984 $
//!   $Date: 2007-06-11 09:19:22 -0700 (Mon, 11 Jun 2007) $
//! \endif
//!
//! 
//-----------------------------------------------------------------------------
//! \addtogroup	Serial
//! @{
//!

//------------------------------------------------------------------------------
//                                                                      Includes
//------------------------------------------------------------------------------
// Standard includes
#include <windows.h>
#include <memory.h>
#include <CEDDK.h>

// Controller includes
#include "AT91SAM9261.h"
#include "lib_AT91SAM9261.h"

// Project include
#include "Serial_SAM926X.h"

//------------------------------------------------------------------------------
//                                                            Exported functions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//!	\fn				BOOL BSPGetSerialID (T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Get the device ID of the USART
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//!
//! \return			device ID if success;
//! \return	\e		False if error
//------------------------------------------------------------------------------
BOOL	BSPGetSerialID (T_SERIAL_INIT_STRUCTURE *pInitContext)
{
	BOOL RetVal = TRUE;

	switch (pInitContext->dwDeviceIndex)
	{
		case 0 :
			pInitContext->dwDeviceID = AT91C_ID_US0;
			break;
		case 1 :
			pInitContext->dwDeviceID = AT91C_ID_US1;
			break;
		case 2 :
			pInitContext->dwDeviceID = AT91C_ID_US2;
			break;
		default :
			RetVal = FALSE;
			break;
	}

	return RetVal;
}

//------------------------------------------------------------------------------
//!	\fn				BOOL BSPGetSerialBaseAddress (T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Get the Base address of the USART
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//!
//! \return			Base address if success;
//! \return	\e		False if error
//------------------------------------------------------------------------------
BOOL	BSPGetSerialBaseAddress (T_SERIAL_INIT_STRUCTURE *pInitContext)
{
	BOOL RetVal = TRUE;

	switch (pInitContext->dwDeviceID)
	{
		case AT91C_ID_US0 :
			pInitContext->dwBaseAddress = (DWORD)AT91C_BASE_US0;
			break;
		case AT91C_ID_US1 :
			pInitContext->dwBaseAddress = (DWORD)AT91C_BASE_US1;
			break;
		case AT91C_ID_US2 :
			pInitContext->dwBaseAddress = (DWORD)AT91C_BASE_US2;
			break;
		default :
			RetVal = FALSE;
			break;
	}

	return RetVal;
}

//------------------------------------------------------------------------------
//!	\fn				BOOL BSPGetSerialPdcBaseAddress (T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Get the PDC Base address of the USART
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//!
//! \return			PDC Base address if success;
//! \return	\e		False if error
//------------------------------------------------------------------------------
BOOL	BSPGetSerialPdcBaseAddress (T_SERIAL_INIT_STRUCTURE *pInitContext)
{
	BOOL RetVal = TRUE;

	switch (pInitContext->dwDeviceID)
	{
		case AT91C_ID_US0 :
			pInitContext->dwPDCBaseAddress = (DWORD)AT91C_BASE_PDC_US0;
			break;
		case AT91C_ID_US1 :
			pInitContext->dwPDCBaseAddress = (DWORD)AT91C_BASE_PDC_US1;
			break;
		case AT91C_ID_US2 :
			pInitContext->dwPDCBaseAddress = (DWORD)AT91C_BASE_PDC_US2;
			break;
		default :
			RetVal = FALSE;
			break;
	}

	return RetVal;
}

//------------------------------------------------------------------------------
//!	\fn				BOOL BSPGetSerialPmcBaseAddress (T_SERIAL_INIT_STRUCTURE *pInitContext)
//!
//! \brief			Get the PMC Base address of the USART
//! 
//! \param pInitContext	Context pointer returned from COM_Init.
//!
//! \return			PMC Base address if success;
//! \return	\e		False if error
//------------------------------------------------------------------------------
BOOL	BSPGetSerialPmcBaseAddress (T_SERIAL_INIT_STRUCTURE *pInitContext)
{
	pInitContext->dwPMCBaseAddress = (DWORD)AT91C_BASE_PMC;
	return TRUE;
}

//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9261/DRIVERS/Serial/Serial_SAM9261.cpp $
//------------------------------------------------------------------------------

//
//! @}
//
//! @}