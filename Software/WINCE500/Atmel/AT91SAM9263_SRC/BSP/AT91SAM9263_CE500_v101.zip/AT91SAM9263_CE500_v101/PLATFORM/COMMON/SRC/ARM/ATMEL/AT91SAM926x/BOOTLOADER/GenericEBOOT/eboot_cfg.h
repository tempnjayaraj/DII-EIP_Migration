
//------------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!
//   All rights reserved ADENEO SAS 2005
//!
//------------------------------------------------------------------------------
//! \file		eboot_cfg.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/GenericEBOOT/eboot_cfg.h $
//!   $Author: ltourlonias $
//!   $Revision: 657 $
//!   $Date: 2007-04-10 16:52:09 +0200 (mar., 10 avr. 2007) $
//! \endif
//------------------------------------------------------------------------------
//! \addtogroup	EBOOT
//! @{

#ifndef EBOOT_CFG_H
#define EBOOT_CFG_H

//------------------------------------------------------------------------------
//                                                                      Includes
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
//                                                            Exported functions
//------------------------------------------------------------------------------


BOOL EBOOT_SaveConfigToFlash(EBOOT_CFG *pEbootCFG);
BOOL EBOOT_LoadConfigFromFlash(EBOOT_CFG *pEbootCFG);

void EBOOT_SetDefaultEBootCFG(EBOOT_CFG *pEbootCFG);
void EBOOT_SetDelay(EBOOT_CFG *pEbootCFG);
void EBOOT_SetBootMe(EBOOT_CFG *pEbootCFG);
void EBOOT_SetMacAddress(EBOOT_CFG *pEbootCFG);
void EBOOT_SetMask(EBOOT_CFG *pEbootCFG);
void EBOOT_SetFrequency(EBOOT_CFG *pEbootCFG);
void EBOOT_SetIP(EBOOT_CFG *pEbootCFG);
void EBOOT_InvertDhcpState(EBOOT_CFG *pEbootCFG);
void EBOOT_InvertAutoDownloadState(EBOOT_CFG *pEbootCFG);
void EBOOT_InvertDownloadImgToFlash(EBOOT_CFG *pEbootCFG);

#endif  // EBOOT_CFG_H

//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/GenericEBOOT/eboot_cfg.h $
//------------------------------------------------------------------------------
//

//
//! @}
//

//
//! @}
//