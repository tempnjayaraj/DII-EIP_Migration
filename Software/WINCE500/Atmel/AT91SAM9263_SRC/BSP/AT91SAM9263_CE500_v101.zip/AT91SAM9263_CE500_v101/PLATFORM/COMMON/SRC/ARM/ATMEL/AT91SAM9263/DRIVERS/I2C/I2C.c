//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//! \addtogroup	I2C
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9263/DRIVERS/I2C/I2C.c
//!
//! \brief		I2C driver for AT91SAM926x's chipset
//!
//! \if subversion
///   @URL: $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/DRIVERS/I2C/I2C.c $
//!   @author $Author: edaniel $
//!   @version $Revision: 695 $
//!   @date $Date: 2007-04-13 16:16:40 +0200 (ven., 13 avr. 2007) $
//! \endif
//!
//! Description of the driver on multi lines
//-----------------------------------------------------------------------------


// System include
#include <windows.h>
#include <memory.h>
#include <nkintr.h>
#include <CEDDK.h>

// Local include
#include "at91sam926x.h"
#include "at91sam926x_i2c_ioctl.h"
#include "I2CDriver.h"

//-----------------------------------------------------------------------------
//! \fn			BOOL InitI2CVirtualAddresses(T_I2CINIT_STRUCTURE * pDeviceContext)
//!
//! \brief		This function initializes I2C virtual adress
//!
//! \param		pDeviceContext		pointer to the context structure
//!
//! \return		TRUE in success, FALSE in failure
//!
//-----------------------------------------------------------------------------
BOOL InitI2CVirtualAddresses(T_I2CINIT_STRUCTURE * pDeviceContext)
{
	BOOL bRet = TRUE;
	PHYSICAL_ADDRESS    PhysicalBase;
  	

	PhysicalBase.QuadPart = (LONGLONG)AT91C_BASE_PMC;
	pDeviceContext->pPMCReg = (AT91PS_PMC)MmMapIoSpace(PhysicalBase, sizeof(AT91S_PMC), FALSE);
	
	PhysicalBase.QuadPart = (LONGLONG)AT91C_BASE_TWI;
	pDeviceContext->pTWIReg = (AT91PS_TWI)MmMapIoSpace(PhysicalBase, sizeof(AT91S_TWI), FALSE);
	
	if( (pDeviceContext->pTWIReg == INVALID_HANDLE_VALUE) || 
		(pDeviceContext->pPMCReg == INVALID_HANDLE_VALUE)  )
	{
		bRet = FALSE;
	}

	return bRet;
}

//-----------------------------------------------------------------------------
//! \fn			void DeinitI2CVirtualAddresses(T_I2CINIT_STRUCTURE * pDeviceContext)
//!
//! \brief		This function deinitializes I2C virtual adress
//!
//! \param		pDeviceContext		pointer to the context structure
//!
//-----------------------------------------------------------------------------
void DeinitI2CVirtualAddresses(T_I2CINIT_STRUCTURE * pDeviceContext)
{
	MmUnmapIoSpace(pDeviceContext->pTWIReg, sizeof(AT91PS_TWI));
	MmUnmapIoSpace(pDeviceContext->pPMCReg, sizeof(AT91PS_PMC));
}

//-----------------------------------------------------------------------------
//! \fn			DWORD I2CProcSpecificGetBaseAddress(void)
//!
//! \brief		This function returns the base adress
//!
//! \return		Base adress
//!
//-----------------------------------------------------------------------------
DWORD I2CProcSpecificGetBaseAddress(void)
{
	return ((DWORD) 1 << AT91C_ID_TWI);
}



// End of Doxygen group I2C Driver
//! @}
//! @}
//-----------------------------------------------------------------------------
// End of $RCSfile: I2C.c,v $
//-----------------------------------------------------------------------------
//

