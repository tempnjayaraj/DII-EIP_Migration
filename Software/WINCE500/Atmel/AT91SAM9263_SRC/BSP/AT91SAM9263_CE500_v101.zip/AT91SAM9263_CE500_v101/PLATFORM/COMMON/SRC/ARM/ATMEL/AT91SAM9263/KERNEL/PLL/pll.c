//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9263/KERNEL/PLL/pll.c
//!
//! \brief		AT91SAM9263's processor specific PLL configuration
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/KERNEL/PLL/pll.c $
//!   $Author: amlimonet $
//!   $Revision: 890 $
//!   $Date: 2007-05-28 10:44:17 +0200 (lun., 28 mai 2007) $
//! \endif
//-----------------------------------------------------------------------------


#include <windows.h>
#include "at91sam926x.h"

// PLL A & B min input frequency in Hz
#define PLL_IN_RANGE_MIN			1000000		// 1 MHz

// PLL A output frequencies in Hz
#define PLLA_OUT_RANGE_MIN			80000000	// 80 MHz
#define PLLA_OUT_RANGE_LIMIT		195000000	// 195 MHz
#define PLLA_OUT_RANGE_MAX			300000000	// 300 MHz

// PLL B output frequencies in Hz
#define PLLB_OUT_RANGE_MIN			80000000	// 80 MHz
#define PLLB_OUT_RANGE_LIMIT		195000000	// 195 MHz
#define PLLB_OUT_RANGE_MAX			300000000	// 300 MHz

// PLL A & B max divider and multiplier (w/o unit)
#define PLL_DIVIDER_MAX				 255
#define PLL_MULTIPLIER_MAX			2047 	// input frequency multiplied by (MUL + 1)

//-----------------------------------------------------------------------------
//! \fn       DWORD PLLProcSpecificGetPLLInRangeMin(void)
//!
//!	\brief    This function returns the min frequency for PLL A & B input
//!
//! \return		PLL input minimum frequency
//-----------------------------------------------------------------------------
DWORD PLLProcSpecificGetPLLInRangeMin(void)
{
	return (DWORD) PLL_IN_RANGE_MIN;
}

//-----------------------------------------------------------------------------
//! \fn       DWORD PLLProcSpecificGetPLLAOutRangeMin(void)
//!
//!	\brief    This function returns the min frequency for PLL A & B output
//!
//! \return		PLL output minimum frequency
//-----------------------------------------------------------------------------
DWORD PLLProcSpecificGetPLLAOutRangeMin(void)
{
	return (DWORD) PLLA_OUT_RANGE_MIN;
}

//-----------------------------------------------------------------------------
//! \fn       DWORD PLLProcSpecificGetPLLAOutRangeMax(void)
//!
//!	\brief    This function returns the max frequency for PLL A & B output
//!
//! \return		PLL output maximum frequency
//-----------------------------------------------------------------------------
DWORD PLLProcSpecificGetPLLAOutRangeMax(void)
{
	return (DWORD) PLLA_OUT_RANGE_MAX;
}

//-----------------------------------------------------------------------------
//! \fn       DWORD PLLProcSpecificGetPLLAOutRangeLimit(void)
//!
//!	\brief    This function returns the limit frequency for PLL A output
//!
//! \return		PLL A output intermediate frequency
//-----------------------------------------------------------------------------
DWORD PLLProcSpecificGetPLLAOutRangeLimit(void)
{
	return (DWORD) PLLA_OUT_RANGE_LIMIT;
}

//-----------------------------------------------------------------------------
//! \fn       DWORD PLLProcSpecificGetPLLBOutRangeLimit(void)
//!
//!	\brief    This function returns the limit frequency for PLL B output
//!
//! \return		PLL B output intermediate frequency
//-----------------------------------------------------------------------------
DWORD PLLProcSpecificGetPLLBOutRangeLimit(void)
{
	return (DWORD) PLLB_OUT_RANGE_LIMIT;
}

//-----------------------------------------------------------------------------
//! \fn       DWORD PLLProcSpecificGetPLLBOutFieldInf(void)
//!
//!	\brief    This function returns the inferior value for OUT field of CKGR_PLL register
//!
//! \return		PLL B out field inf value
//-----------------------------------------------------------------------------
DWORD PLLProcSpecificGetPLLBOutFieldInf(void)
{
	return (DWORD) AT91C_CKGR_OUTB_0;
}

//-----------------------------------------------------------------------------
//! \fn       DWORD PLLProcSpecificGetPLLBOutFieldSup(void)
//!
//!	\brief    This function returns the superior value for OUT field of CKGR_PLL register
//!
//! \return		PLL B out field sup value
//-----------------------------------------------------------------------------
DWORD PLLProcSpecificGetPLLBOutFieldSup(void)
{
	return (DWORD) AT91C_CKGR_OUTB_2;
}

//-----------------------------------------------------------------------------
//! \fn       DWORD PLLProcSpecificGetPLLDividerMax(void)
//!
//!	\brief    This function returns the max divider for PLL A & B
//!
//! \return		PLL max divider
//-----------------------------------------------------------------------------
DWORD PLLProcSpecificGetPLLDividerMax(void)
{
	return (DWORD) PLL_DIVIDER_MAX;
}

//-----------------------------------------------------------------------------
//! \fn       DWORD PLLProcSpecificGetPLLMultiplierMax(void)
//!
//!	\brief    This function returns the max multiplier for PLL A & B
//!
//! \return		PLL max multiplier
//-----------------------------------------------------------------------------
DWORD PLLProcSpecificGetPLLMultiplierMax(void)
{
	return (DWORD) PLL_MULTIPLIER_MAX;
}

//------------------------------------------------------------------------------

//! @}


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/KERNEL/PLL/pll.c  $
////////////////////////////////////////////////////////////////////////////////
//
