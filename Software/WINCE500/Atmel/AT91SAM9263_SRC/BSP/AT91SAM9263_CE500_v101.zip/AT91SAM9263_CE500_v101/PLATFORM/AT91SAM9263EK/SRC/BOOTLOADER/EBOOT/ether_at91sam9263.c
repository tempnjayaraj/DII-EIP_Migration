//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//
//  All rights reserved ADENEO SAS 2005
//-----------------------------------------------------------------------------
//! \file		ether_at91sam9263.c 
//!
//! \brief		This file is specific part for ethernet in bootloader
//!
//! \if subversion
///  $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/BOOTLOADER/EBOOT/ether_at91sam9263.c $
//!   $Author: amlimonet $
//!   $Revision: 889 $
//!   $Date: 2007-05-28 10:42:57 +0200 (lun., 28 mai 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	EBOOT
//! @{
//


//------------------------------------------------------------------------------
//                                                                      Includes
//------------------------------------------------------------------------------
// Standard includes
#include <windows.h>
#include <oal.h>
#include <ethdbg.h>

// Atmel includes
#include "at91sam9263.h"
#include "AT91SAM9263EK.h"
#include "AT91SAM926x_interface.h"

#include "emac.h"
#include "oal_ethdrv.h"

//------------------------------------------------------------------------------
//                                                                      Variable
//------------------------------------------------------------------------------
 const UCHAR g_DefaultMacAddress[] = {0x00,0x12,0x72,0x72,0x20,0x20};

//------------------------------------------------------------------------------
//                                                   Internal functions prototype
//------------------------------------------------------------------------------
static void ethChipSelectConfiguration(void);

//------------------------------------------------------------------------------
//                                                            Imported functions
//------------------------------------------------------------------------------
extern VOID*			OALPAtoVA(UINT32 pa, BOOL cached);			//< Mapping function
extern UINT32			OALVAtoPA(VOID *pVA);						//< Mapping function
extern void EmacSetMAcAddress(UCHAR * pMacAddress);

//------------------------------------------------------------------------------
//                                                            Exported functions
//------------------------------------------------------------------------------

//--------------------------------------------------------------------------------
//! \fn BOOL EBOOT_EtherInitHW(UCHAR targetMacAddress[6], OAL_KITL_ARGS *pKITLArgs)
//! 
//! This function initialize the ethernet debug interface
//!
//! \return \e TRUE if succeed
//! \return \e FALSE if failed
//--------------------------------------------------------------------------------
BOOL EBOOT_EtherInitHW(UCHAR targetMacAddress[6], OAL_KITL_ARGS *pKITLArgs)
{
	BOOL bRetVal = TRUE;
    UINT32 SlotAddress = 0;
    UINT32 EbootDeviceAddress = 0;
	AT91PS_PIO pPIOC	= (AT91PS_PIO)	OALPAtoVA((DWORD)AT91C_BASE_PIOC,FALSE);	
	AT91PS_RSTC pRSTC	= (AT91PS_RSTC)	OALPAtoVA((DWORD)AT91C_BASE_RSTC,FALSE);	
	
	SlotAddress = (UINT32)AT91C_BASE_MACB;

	// Put PHY adress Pio in Low Level 
	pPIOC->PIO_PER = AT91C_PIO_PE25 | AT91C_PIO_PE26;
	pPIOC->PIO_OER = AT91C_PIO_PE25 | AT91C_PIO_PE26;
	pPIOC->PIO_CODR = AT91C_PIO_PE25 | AT91C_PIO_PE26;

	pPIOC->PIO_PER = AT91C_PIO_PC25;
	pPIOC->PIO_OER = AT91C_PIO_PC25;
	pPIOC->PIO_CODR = AT91C_PIO_PC25;

	// Reset all external chip
	pRSTC->RSTC_RCR = (0xA5 << 24 ) | AT91C_RSTC_EXTRST;

    EbootDeviceAddress = (SlotAddress);

	EmacSetMAcAddress(targetMacAddress);
	
    if (EMACInit((UINT8 *) OALPAtoVA(EbootDeviceAddress, FALSE), 0, pKITLArgs->mac))
    {
        // Save the device location information for later use.
        //
        pKITLArgs->devLoc.IfcType     = Internal;
        pKITLArgs->devLoc.BusNumber   = 0;
        pKITLArgs->devLoc.PhysicalLoc = (PVOID)(EbootDeviceAddress);
        pKITLArgs->devLoc.LogicalLoc  = (DWORD)pKITLArgs->devLoc.PhysicalLoc;

        RETAILMSG(1,(L"INFO: EMACB Ethernet controller initialized.\r\n"));
		bRetVal = TRUE;
	}
    else
    {
         RETAILMSG(1,(L"ERROR: Failed to initialize EMACB Ethernet controller.\r\n"));
		bRetVal = FALSE;
    }
	return bRetVal;
}

//--------------------------------------------------------------------------------
//! \fn BOOL EBOOT_EtherGetFrame(BYTE *pData, UINT16 *pwLength)
//! 
//! This function get frame over the debug Ethernet adapter. 
//! 
//! \param pData OUT - Receives frame data
//!
//! \param pwLength IN  - Length of Rx buffer
//!
//! \return \e TRUE if succeed
//! \return \e FALSE if failed
//--------------------------------------------------------------------------------
BOOL EBOOT_EtherGetFrame(BYTE *pData, UINT16 *pwLength)
{
	return EMACGetFrame(pData, pwLength);
}

//--------------------------------------------------------------------------------
//! BOOL EBOOT_EtherSendFrame(BYTE *pData, DWORD dwLength)
//! 
//! This function send frame over the debug Ethernet adapter. 
//! 
//! \param pData IN - Data buffer
//!
//! \param dwLength IN - Length of buffer
//!
//! \return \e TRUE if succeed
//! \return \e FALSE if failed
//--------------------------------------------------------------------------------
BOOL EBOOT_EtherSendFrame(BYTE *pData, DWORD dwLength)
{
	return EMACSendFrame(pData, dwLength);
}

//------------------------------------------------------------------------------
//                                                            Internal functions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/BOOTLOADER/EBOOT/ether_at91sam9263.c $
//------------------------------------------------------------------------------

//
//! @}
//

//! @}
