//-----------------------------------------------------------------------------
//! \addtogroup   SPI
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				AT91RM9200_SPIDriver.c
//!
//! \brief				This file implements the system interface of the SPI driver
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/DRIVERS/SPI/AT91RM9200_SPIDriver.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------
#include <windows.h>
#include <ceddk.h>
#include "AT91RM9200.h"
#include "lib_AT91RM9200.h"
#include "AT91RM9200_SPIDriver_IOCTL.h"
#include "AT91RM9200_SPIDriver.h"


#define DEBUGSPI 0 /*DEBUG */

#define NB_SPI_CONTROLLER 1

static T_SPI_CONTROLLER_STRUCTURE	g_SPIControllerTable[NB_SPI_CONTROLLER];

typedef struct {
	AT91PS_SPI	pBase;
	DWORD		dwID;
} T_CONTROLLER_INFO;

T_CONTROLLER_INFO g_SPIControllerList[NB_SPI_CONTROLLER] =
{
	{AT91C_BASE_SPI,AT91C_ID_SPI},	
};



//Platform specific (this is implemented in the BSP)
extern BOOL HWSPIControllerBoardSpecificPIOInitialization(DWORD dwDevID, WORD wCS);
extern BOOL HWSPIControllerBoardSpecificPIODeinitialization(DWORD dwDevID);

extern BOOL HWSPICSBoardSpecificPIOInitialization(DWORD dwPIOBankNumber,DWORD dwPinNumber,AT91PS_PIO* ppPioBank,DWORD* pPioMask);
extern BOOL HWSPICSBoardSpecificPIODeinitialization(AT91PS_PIO pPioBank,DWORD dwPinNumber);

extern BOOL HWSPIControllerBoardSpecificInit();
extern BOOL HWSPIControllerBoardSpecificGetBus();
extern BOOL HWSPIControllerBoardSpecificReleaseBus();

extern void HWSPIControllerBoardSpecificDeInit();

///////////////////////////////////////////////////////////////////////////////
// 
///////////////////////////////////////////////////////////////////////////////
BOOL APIENTRY DllMain( HANDLE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved )
{
    switch(ul_reason_for_call) {
        case DLL_PROCESS_ATTACH:
            DEBUGMSG(DEBUGSPI,(L"SPIDriver - DLL_PROCESS_ATTACH\n"));
        break;
        case DLL_PROCESS_DETACH:
            DEBUGMSG(DEBUGSPI,(L"SPIDriver - DLL_PROCESS_DETACH\n"));
        break;
        case DLL_THREAD_ATTACH:
            DEBUGMSG(DEBUGSPI,(L"SPIDriver - DLL_THREAD_ATTACH\n"));
        break;
        case DLL_THREAD_DETACH:
            DEBUGMSG(DEBUGSPI,(L"SPIDriver - DLL_THREAD_DETACH\n"));
        break;
        default:
        break;
    }
return TRUE;
}

//-----------------------------------------------------------------------------
//!
//! \brief		This function release every ressources kept for the use of an SPI controller
//!
//! \param		pSPIControllerInfo	A pointer to a structure containing all the controller's ressource
//!
//-----------------------------------------------------------------------------
static void ReleaseSPIControllerDescriptor(T_SPI_CONTROLLER_STRUCTURE* pSPIControllerInfo)
{
	PHYSICAL_ADDRESS PhysAddr;
	DMA_ADAPTER_OBJECT dmaAdapterObject;

	pSPIControllerInfo->wInitCount = 0;

	if (pSPIControllerInfo->pSPI)
	{
		MmUnmapIoSpace(pSPIControllerInfo->pSPI,sizeof(AT91S_SPI));
	}

	dmaAdapterObject.ObjectSize = sizeof(DMA_ADAPTER_OBJECT);
	dmaAdapterObject.InterfaceType = PCIBus ;
	dmaAdapterObject.BusNumber = 0;

	if (pSPIControllerInfo->dwRxBufferPhysicalAddress[0])
	{
		PhysAddr.HighPart = 0;
		PhysAddr.LowPart = pSPIControllerInfo->dwRxBufferPhysicalAddress[0];
		HalFreeCommonBuffer(&dmaAdapterObject,2*pSPIControllerInfo->dwRxBufferSize,PhysAddr,pSPIControllerInfo->pVirtRxBuffer[0],FALSE);
	}

	if (pSPIControllerInfo->dwTxBufferPhysicalAddress[0])
	{
		PhysAddr.HighPart = 0;
		PhysAddr.LowPart = pSPIControllerInfo->dwTxBufferPhysicalAddress[0];			
		HalFreeCommonBuffer(&dmaAdapterObject,2*pSPIControllerInfo->dwTxBufferSize,PhysAddr,pSPIControllerInfo->pVirtTxBuffer[0],FALSE);
	}

	InterruptDisable(pSPIControllerInfo->dwSysintr);

	KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, &pSPIControllerInfo->dwSysintr, sizeof(pSPIControllerInfo->dwSysintr), NULL, 0, 0);
	
	CloseHandle(pSPIControllerInfo->hInterruptEvent);			
}


//-----------------------------------------------------------------------------
//!
//! \brief		This function initializes the structure required to use the SPI controler and initalizes the hardware.
//!
//! \param		pContext : Pointer to a string containing the registry path to the active key for the stream interface driver. 
//! \param		lpvBusContext : Potentially process-mapped pointer passed as the fourth 
//!				parameter to ActivateDeviceEx. If this driver was loaded through legacy 
//!				mechanisms, then lpvBusContext is zero. This pointer, if used, has only
//!				been remapped as it passes through the protected server library (PSL). 
//!				The XXX_Init function is responsible for performing all protection 
//!				checking. In addition, any pointers referenced through lpvBusContext 
//!				must be remapped with the MapCallerPtr function before they can be 
//!				dereferenced.
//!
//!	\return Returns a handle to the device context created if successful. 
//!			Returns zero if not successful. This handle is passed to 
//!			the XXX_Open, XXX_PowerDown, XXX_PowerUp, and XXX_Deinit functions.
//!
//-----------------------------------------------------------------------------

DWORD SPI_Init( LPCTSTR pContext, LPCVOID lpvBusContext)
{	
	PHYSICAL_ADDRESS PhysAddr;
	T_SPI_INIT_STRUCTURE* pSPIInfo;
	
  	RETAILMSG(1,(L"SPIDriver - SPI_Init - Context: %s\r\n", pContext));

	// Allocate for our main data structure and one of it's fields.
	pSPIInfo = (T_SPI_INIT_STRUCTURE*)LocalAlloc( LMEM_ZEROINIT|LMEM_FIXED,	sizeof(T_SPI_INIT_STRUCTURE) );

	if ( !pSPIInfo )
	{
		RETAILMSG(1,(L"SPI_Init - Failed to allocate memory\r\n"));
		goto errorInit;		
	}
	
	// Initialize the specific platform
	HWSPIControllerBoardSpecificInit();

	// Get CS configuration from registry
	if (!SPI_GetRegistryData(pSPIInfo, pContext))
	{
		RETAILMSG(1,(L"SPI_Init - Failed to load registry (CS)\r\n"));
		goto errorInit;
	}
	
	//Reset the open counter
	pSPIInfo->wOpenCount = 0;
	//Set the pointer to the SPI controller structure
	pSPIInfo->pSPIControllerInfo = &(g_SPIControllerTable[pSPIInfo->dwDevIndex]);
	
	//Fill the SPI controller structure if needed
	if (pSPIInfo->pSPIControllerInfo->wInitCount == 0)
	{
		DMA_ADAPTER_OBJECT dmaAdapterObject;
		dmaAdapterObject.ObjectSize = sizeof(DMA_ADAPTER_OBJECT);
		dmaAdapterObject.InterfaceType = PCIBus ;
		dmaAdapterObject.BusNumber = 0;

		// The SPI controller has been initialized yet .... do it now
		pSPIInfo->pSPIControllerInfo->wInitCount = 1;

		// Get Controller configuration from registry
		if (!SPI_GetControlerRegistryData(pSPIInfo->pSPIControllerInfo, pSPIInfo->dwDevIndex))
		{
			RETAILMSG(1,(L"SPI_Init - Failed to load registry (Controller)\r\n"));
			ReleaseSPIControllerDescriptor(pSPIInfo->pSPIControllerInfo);
			goto errorInit;
		}

		//Remap the register in the process's address space
		PhysAddr.HighPart = 0;
		PhysAddr.LowPart = (DWORD) g_SPIControllerList[pSPIInfo->dwDevIndex].pBase;		
		pSPIInfo->pSPIControllerInfo->pSPI = (AT91PS_SPI) MmMapIoSpace(PhysAddr,sizeof(AT91S_SPI),FALSE);
		if (pSPIInfo->pSPIControllerInfo->pSPI == NULL)
		{
			RETAILMSG(1,(L"SPI_Init - Failed to remap the registrers\r\n"));
			ReleaseSPIControllerDescriptor(pSPIInfo->pSPIControllerInfo);
			goto errorInit;
		}
		
		pSPIInfo->pSPIControllerInfo->dwIDIRQ = g_SPIControllerList[pSPIInfo->dwDevIndex].dwID;
		if (KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &pSPIInfo->pSPIControllerInfo->dwIDIRQ, sizeof(pSPIInfo->pSPIControllerInfo->dwIDIRQ), &pSPIInfo->pSPIControllerInfo->dwSysintr, sizeof(pSPIInfo->pSPIControllerInfo->dwSysintr), 0) == FALSE)
		{
			RETAILMSG(1,(L"SPI_Init - IOCTL_HAL_REQUEST_SYSINTR failed\r\n"));
			ReleaseSPIControllerDescriptor(pSPIInfo->pSPIControllerInfo);
			goto errorInit;
		}

		pSPIInfo->pSPIControllerInfo->hInterruptEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
		if (pSPIInfo->pSPIControllerInfo->hInterruptEvent == NULL)
		{
			RETAILMSG(1,(L"SPI_Init - CreateEvent failed\r\n"));
			ReleaseSPIControllerDescriptor(pSPIInfo->pSPIControllerInfo);
			goto errorInit;
		}
		
		
		if (InterruptInitialize(pSPIInfo->pSPIControllerInfo->dwSysintr,pSPIInfo->pSPIControllerInfo->hInterruptEvent,NULL,0) == FALSE)
		{
			RETAILMSG(1,(L"SPI_Init - InterruptInitialize failed\r\n"));
			ReleaseSPIControllerDescriptor(pSPIInfo->pSPIControllerInfo);
			goto errorInit;
		}
		

		// Initialize critical section
		InitializeCriticalSection(&(pSPIInfo->pSPIControllerInfo->csSPIAccess));
		
		
		// Allocate Tx Buffers
		pSPIInfo->pSPIControllerInfo->pVirtTxBuffer[0] = HalAllocateCommonBuffer(&dmaAdapterObject,2*pSPIInfo->pSPIControllerInfo->dwTxBufferSize,&PhysAddr,FALSE);		
		pSPIInfo->pSPIControllerInfo->dwTxBufferPhysicalAddress[0] = PhysAddr.LowPart;
		if (pSPIInfo->pSPIControllerInfo->pVirtTxBuffer[0] == NULL)
		{
			RETAILMSG(1,(L"SPI_Init - pVirtTxBuffer allocation failed\r\n"));
			ReleaseSPIControllerDescriptor(pSPIInfo->pSPIControllerInfo);
			goto errorInit;
		}
		pSPIInfo->pSPIControllerInfo->pVirtTxBuffer[1] = pSPIInfo->pSPIControllerInfo->pVirtTxBuffer[0] + pSPIInfo->pSPIControllerInfo->dwTxBufferSize;
		pSPIInfo->pSPIControllerInfo->dwTxBufferPhysicalAddress[1] = pSPIInfo->pSPIControllerInfo->dwTxBufferPhysicalAddress[0] + pSPIInfo->pSPIControllerInfo->dwTxBufferSize;
		

		// Allocate Rx buffers
		pSPIInfo->pSPIControllerInfo->pVirtRxBuffer[0] = HalAllocateCommonBuffer(&dmaAdapterObject,2*pSPIInfo->pSPIControllerInfo->dwRxBufferSize,&PhysAddr,FALSE);		
		pSPIInfo->pSPIControllerInfo->dwRxBufferPhysicalAddress[0] = PhysAddr.LowPart;
		if (pSPIInfo->pSPIControllerInfo->pVirtRxBuffer[0] == NULL)
		{
			RETAILMSG(1,(L"SPI_Init - pVirtRxBuffer allocation failed\r\n"));
			ReleaseSPIControllerDescriptor(pSPIInfo->pSPIControllerInfo);
			goto errorInit;
		}
		pSPIInfo->pSPIControllerInfo->pVirtRxBuffer[1] = pSPIInfo->pSPIControllerInfo->pVirtRxBuffer[0] + pSPIInfo->pSPIControllerInfo->dwRxBufferSize;
		pSPIInfo->pSPIControllerInfo->dwRxBufferPhysicalAddress[1] = pSPIInfo->pSPIControllerInfo->dwRxBufferPhysicalAddress[0] + pSPIInfo->pSPIControllerInfo->dwRxBufferSize;
		

		// Initialize the Controller
		HWSPIControllerInit(pSPIInfo->pSPIControllerInfo);


		// Configure PIOs (This is platform specific ....		
		if (HWSPIControllerBoardSpecificPIOInitialization(pSPIInfo->dwDevIndex, pSPIInfo->wCS) == FALSE)
		{
			RETAILMSG(1,(L"SPI_Init - HWSPIBoardSpecificPIOInitialization\r\n"));
			ReleaseSPIControllerDescriptor(pSPIInfo->pSPIControllerInfo);
			goto errorInit;		
		}

	}
	else
	{
		pSPIInfo->pSPIControllerInfo->wInitCount++;
	}

	HWSPICSBoardSpecificPIOInitialization(pSPIInfo->dwCSPIOBankNumber,pSPIInfo->dwCSPioPin,&pSPIInfo->pCSPio,&pSPIInfo->dwCSPioPin);
	

	// Initialize the Chip Select
	HWSPICSConfigure(pSPIInfo);


	return (DWORD) pSPIInfo;

errorInit:

//	HWSPIDeinit(pSPIInfo);
	
	if (pSPIInfo)
	{
		LocalFree(pSPIInfo);
	}

	return (DWORD) NULL;
}

//-----------------------------------------------------------------------------
//!
//! \brief		This function de-initializes the device.
//!
//! \param		hDeviceContext Handle to the device context. The XXX_Init function
//!				creates and returns this identifier. 
//!
//! \return		\e TRUE when all is good (ie. every Opened instance was closed)
//!	\return		\e FALSE when all is bad  (ie. at least one instance is still open)
//-----------------------------------------------------------------------------

BOOL SPI_Deinit( DWORD hDeviceContext )
{
	T_SPI_INIT_STRUCTURE* pSPIInfo;

	RETAILMSG(1,(L"SPIDriver - SPI_Deinit\n"));
	
	pSPIInfo = (T_SPI_INIT_STRUCTURE*)hDeviceContext;

	//If someone hasn't closed its instance then do not deinit
	if (pSPIInfo->wOpenCount)
	{
		RETAILMSG(1,(L"SPI_Deinit Failed. Open Count is not 0\r\n"));
		return FALSE;
	}

	pSPIInfo->pSPIControllerInfo->wInitCount--;

	HWSPICSBoardSpecificPIODeinitialization(pSPIInfo->pCSPio,pSPIInfo->dwCSPioPin);
	HWSPIControllerBoardSpecificPIODeinitialization(pSPIInfo->dwDevIndex);
	HWSPIControllerBoardSpecificDeInit();
	if (pSPIInfo->pSPIControllerInfo->wInitCount == 0)
	{
		HWSPIControllerDeinit(pSPIInfo->pSPIControllerInfo);
		ReleaseSPIControllerDescriptor(pSPIInfo->pSPIControllerInfo);	
	}

	if (pSPIInfo)
	{
		LocalFree(pSPIInfo);
	}
	
	return TRUE;
}


//-----------------------------------------------------------------------------
//!
//! \brief		DWORD SPI_Open( DWORD hDeviceContext, DWORD AccessCode, DWORD ShareMode )
//!
//!	\param		hDeviceContext : Handle to the device context. The XXX_Init function
//!				creates and returns this handle.
//!
//! \param AccessCode : Not Used
//!
//! \param ShareMode : Not Used
//!
//! \return This function returns a handle that identifies the open context 
//!				 of the device to the calling application. If your device can be 
//!				 opened multiple times, use this handle to identify each open context.
//!				 This identifier is passed into the XXX_Read, XXX_Write, XXX_Seek, 
//!				 and XXX_IOControl functions. Returns zero if the device cannot be 
//!				 opened.
//!
//! An application indirectly invokes this function when it calls the CreateFile function to 
//! open special device file names.
//!
//-----------------------------------------------------------------------------

DWORD SPI_Open( DWORD hDeviceContext, DWORD AccessCode, DWORD ShareMode )
{
	
	T_SPI_INIT_STRUCTURE* pSPIInit;
	T_SPI_OPEN_STRUCTURE* pSPIOpen;
	
	DEBUGMSG(DEBUGSPI,(L"SPIDriver - SPI_Open\n"));
	
	pSPIInit= (T_SPI_INIT_STRUCTURE*)hDeviceContext;
	pSPIOpen= (T_SPI_OPEN_STRUCTURE*) LocalAlloc( LMEM_ZEROINIT|LMEM_FIXED,	sizeof(T_SPI_OPEN_STRUCTURE) );
	
	if (pSPIOpen == NULL)
	{
		RETAILMSG(1,(L"SPIDriver - SPI_Open Failed.  Unable to allocate memory\r\n"));
		return (DWORD) NULL;
	}
	
	pSPIOpen->pSPIInfo = pSPIInit;

	// increment the open count
 	pSPIOpen->pSPIInfo->wOpenCount++;	

	return (DWORD)pSPIOpen;
}

//-----------------------------------------------------------------------------
//!
//! \brief		This function closes a device context created by the hOpenContext parameter.
//!
//! \param		hOpenContext : Handle returned by the XXX_Open function, used to 
//!				identify the open context of the device.
//!
//! \return		\e TRUE indicates success.
//!	\return		\e FALSE indicates failure.
//-----------------------------------------------------------------------------

BOOL SPI_Close( DWORD hOpenContext )
{
	T_SPI_OPEN_STRUCTURE* pSPIOpen;
	
	DEBUGMSG(DEBUGSPI,(L"SPIDriver - SPI_Close\n"));
	
	pSPIOpen= (T_SPI_OPEN_STRUCTURE*) hOpenContext;
	
	if (pSPIOpen == NULL)
	{
		RETAILMSG(1,(L"SPIDriver - SPI_Close Failed.  Invalid pointer\r\n"));
		return FALSE;
	}
	
	// decrement the open count
 	pSPIOpen->pSPIInfo->wOpenCount--;
 	
 	//Free the memory
 	LocalFree(pSPIOpen);
 	
	return TRUE;
}




//-----------------------------------------------------------------------------
//!
//! \brief		This function sends a command to a device.
//!
//! \param		hOpenContext : Handle to the open context of the device. The XXX_Open
//!				function creates and returns this identifier. 
//!
//! \param		dwCode : I/O control operation to perform. These codes are 
//!				device-specific and are usually exposed to developers through a 
//!				header file. 
//!
//! \param		pBufIn : Pointer to the buffer containing data to transfer to the device. 
//!
//! \param		dwLenIn : Number of bytes of data in the buffer specified for pBufIn. 
//!
//! \param		pBufOut : Pointer to the buffer used to transfer the output data from 
//!				the device. 
//!
//! \param		dwLenOut : Maximum number of bytes in the buffer specified by pBufOut. 
//!
//! \param		pdwActualOut : Pointer to the DWORD buffer that this function uses to 
//!				return the actual number of bytes received from the device. 
//!
//! \return		\e TRUE indicates success.
//!	\return		\e FALSE indicates failure.
//-----------------------------------------------------------------------------

BOOL SPI_IOControl(DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut )
{
	BOOL bResult=TRUE;
	T_SPI_OPEN_STRUCTURE* pSPIOpen;
	T_SPI_INIT_STRUCTURE* pSPIInfo;

	pSPIOpen= (T_SPI_OPEN_STRUCTURE*) hOpenContext;
	pSPIInfo = (T_SPI_INIT_STRUCTURE*)pSPIOpen->pSPIInfo;

	HWSPIControllerBoardSpecificGetBus();
	HWSPIControllerBoardSpecificPIOInitialization(pSPIInfo->dwDevIndex, pSPIInfo->wCS);

	// Perform the action ....
	switch (dwCode)
	{
		case IOCTL_SPI_TRANSACTION:
			{
				T_SPI_TRANSACTION_ELEMENT_PARAM* pTransactionArray = (T_SPI_TRANSACTION_ELEMENT_PARAM*) pBufIn;

				// Allocate the buffer where the parameters will be copied
				T_SPI_TRANSACTION_ELEMENT_PARAM* pTemp = (T_SPI_TRANSACTION_ELEMENT_PARAM*) LocalAlloc(LMEM_ZEROINIT|LMEM_FIXED,dwLenIn);
	
				AT91PS_SPI  pSPI = pSPIInfo->pSPIControllerInfo->pSPI;

				DWORD dwSizeOfData;


								
				if ((pSPI->SPI_MR & AT91C_SPI_BITS) == AT91C_SPI_BITS_8)
				{
					dwSizeOfData = 1; // 1 byte per sample
				}
				else
				{
					dwSizeOfData = 2; // 2 bytes per sample
				}


				if (pTemp == NULL)
				{
					bResult = FALSE;
				}
				else
				{
					DWORD dwNbTransaction = dwLenIn / sizeof (T_SPI_TRANSACTION_ELEMENT_PARAM);
					DWORD i;

					//Remap every pointers of the copy parameters in our process's space
					for (i = 0;i<dwNbTransaction;i++)
					{
						if (pTransactionArray[i].pRxBuffer && pTransactionArray[i].dwSize)
						{
							pTemp[i].pRxBuffer = MapCallerPtr(pTransactionArray[i].pRxBuffer, pTransactionArray[i].dwSize * dwSizeOfData);
						}
						if (pTransactionArray[i].pTxBuffer && pTransactionArray[i].dwSize)
						{
							pTemp[i].pTxBuffer = MapCallerPtr(pTransactionArray[i].pTxBuffer, pTransactionArray[i].dwSize * dwSizeOfData);
						}
						pTemp[i].dwSize = pTransactionArray[i].dwSize;
					}

					// Play the SPI transactions
					bResult = DoSPITransaction((T_SPI_OPEN_STRUCTURE *)hOpenContext,pTransactionArray,dwNbTransaction);

					//Unmap the pointers
					for (i = 0;i<dwNbTransaction;i++)
					{
						if (pTemp[i].pRxBuffer)
						{
							UnMapPtr(pTemp[i].pRxBuffer);
						}
						if (pTemp[i].pTxBuffer)
						{
							UnMapPtr(pTemp[i].pTxBuffer);
						}						
					}
					//And free the copy of the parameters
					LocalFree(pTemp);					
				}
			}
			break;	

		
		default: 
			bResult = FALSE;
			break;
	}
	HWSPIControllerBoardSpecificReleaseBus();
	return bResult;
}

//! @}

