//-----------------------------------------------------------------------------
//! \addtogroup	MISC
//! @{
//
//  All rights reserved ADENEO SAS 2005
//! \file		atmel_gpio.c
//!
//! \brief		Header description
//!
//-----------------------------------------------------------------------------
//!
//! \if subversion
///   @URL: $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/MISC/GPIO/atmel_gpio.c $
//!   @author $Author: pblanchard $
//!   @version $Revision: 936 $
//!   @date $Date: 2007-06-05 11:26:58 +0200 (mar., 05 juin 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	GPIO
//! @{


#include <windows.h>
#include <oal.h>
#include "atmel_gpio.h"

// Controllers includes
#include "AT91SAM926x.h"

extern T_PIO_BANK_DESCRIPTION g_PioBankDescTab[];
extern DWORD g_dwOalPioBankNumber;

//-----------------------------------------------------------------------------
//! \fn			BOOL InitPioTable(void)
//!
//! \brief		This function initializes PIO Table
//!
//! \return  		True in success, False in failure
//-----------------------------------------------------------------------------
BOOL InitPioTable(void)
{
	BOOL bRet = TRUE;
	DWORD i ;
	PHYSICAL_ADDRESS	pa;

	pa.HighPart = 0;

	for(i = 0; i < g_dwOalPioBankNumber; i++)
	{
		pa.LowPart = (DWORD)g_PioBankDescTab[i].pBase;
		g_PioBankDescTab[i].vPioBase = (AT91PS_PIO)MmMapIoSpace(pa, sizeof(AT91S_PIO), FALSE);		
		if(g_PioBankDescTab[i].vPioBase == INVALID_HANDLE_VALUE)
		{
			bRet = FALSE;
		}
	}
	
    return bRet;
}

//-----------------------------------------------------------------------------
//! \fn			void DeinitPioTable(void)
//!
//! \brief		This function deinitializes PIO Table
//!
//-----------------------------------------------------------------------------
void DeinitPioTable(void)
{
	DWORD i ;
	

	for(i = 0; i < g_dwOalPioBankNumber; i++)
	{
		MmUnmapIoSpace(g_PioBankDescTab[i].vPioBase, sizeof(AT91PS_PIO));
	}
	
}

//-----------------------------------------------------------------------------
//! \fn			AT91PS_PIO pin_to_controller(unsigned pin)
//!
//! \brief		This function converts Pin Number into PIO controller physical address
//!
//! \param		pin 	pin number
//!
//! \return		NULL if bad parameter, else physical adress of pin
//-----------------------------------------------------------------------------
AT91PS_PIO pin_to_controller(unsigned pin)
{
	if (pin >= (32 * g_dwOalPioBankNumber))
	{
		return NULL;
	}
	return  g_PioBankDescTab[pin/32].vPioBase;
}

//-----------------------------------------------------------------------------
//! \fn			unsigned pin_to_mask(unsigned pin)
//!
//! \brief		This function converts Pin Number into I/O line index
//!
//! \param		pin	 pin number
//!
//! \return		0 if bad parameter, else Pin Number into I/O line index
//-----------------------------------------------------------------------------
unsigned pin_to_mask(unsigned pin)
{
	if (pin >= (32* g_dwOalPioBankNumber))
	{
		return 0;
	}
	return 1 << ((pin) % 32);
}
//-----------------------------------------------------------------------------
//! \fn			void pio_set_periph(unsigned pin, int use_pullup, int periph)
//!
//! \brief		This function sets the pin to the "A" internal peripheral role
//!
//! \param		pin 			pin number
//! \param		use_pullup 	Null if no pull-up
//! \param		periph	 	indicates if "A" or "B" inernal peripheral is used
//!
//-----------------------------------------------------------------------------
void pio_set_periph(unsigned pin, int use_pullup, int periph)
{
	AT91PS_PIO pPIO = pin_to_controller(pin);
	DWORD dwMask = pin_to_mask(pin);

	if (pPIO == NULL)
		return;

	pPIO->PIO_IDR = dwMask;

	if (use_pullup)
	{
		pPIO->PIO_PPUER = dwMask;
	}
	else
	{
		pPIO->PIO_PPUDR = dwMask;
	}

	if (periph == PIO_PERIPH_A)
	{
		pPIO->PIO_ASR = dwMask;
	}
	else
	{
		pPIO->PIO_BSR = dwMask;
	}

	pPIO->PIO_PDR = dwMask;
}

//-----------------------------------------------------------------------------
//! \fn			void pio_set_gpio(unsigned pin, int use_pullup, int direction)
//!
//! \brief		This function sets the pin to the gpio controller (instead of "A" or "B" peripheral) and configure it for an input.
//!
//! \param		pin 			pin number
//! \param		use_pullup 	Null if no pull-up
//! \param		direction	 	indicates if input or output mode is used
//!
//-----------------------------------------------------------------------------
void pio_set_gpio(unsigned pin, int use_pullup, int direction)
{
	AT91PS_PIO pPIO = pin_to_controller(pin);
	DWORD dwMask = pin_to_mask(pin);

	if (pPIO == NULL)
		return;

	pPIO->PIO_IDR = dwMask;

	if (use_pullup)
	{
		pPIO->PIO_PPUER = dwMask;
	}
	else
	{
		pPIO->PIO_PPUDR = dwMask;
	}

	if (direction == PIO_INPUT)
	{
		pPIO->PIO_ODR = dwMask;
	}
	else
	{
		pPIO->PIO_OER = dwMask;
	}

	pPIO->PIO_PER = dwMask;
}

//-----------------------------------------------------------------------------
//! \fn			void pio_set_deglitch(unsigned pin, int is_on)
//!
//! \brief		This function enables/disables the glitch filter; mostly used with IRQ handling.
//!
//! \param		pin 			pin number
//! \param		is_on 		Indicates what operation has to be done : enable or disable
//!
//-----------------------------------------------------------------------------
void pio_set_deglitch(unsigned pin, int is_on)
{
	AT91PS_PIO pPIO = pin_to_controller(pin);
	DWORD dwMask = pin_to_mask(pin);

	if (pPIO == NULL)
		return;

	if (is_on)
	{
		pPIO->PIO_IFER = dwMask;
	}
	else
	{
		pPIO->PIO_IFDR = dwMask;
	}
}

//-----------------------------------------------------------------------------
//! \fn			void pio_set_multi_drive(unsigned pin, int is_on)
//!
//! \brief		This function enables/disables the multi-driver; This is only valid for output and
//!				allows the output pin to run as an open collector output.
//!
//! \param		pin 			pin number
//! \param		is_on 		Indicates what operation has to be done : enable or disable
//!
//-----------------------------------------------------------------------------
void pio_set_multi_drive(unsigned pin, int is_on)
{
	AT91PS_PIO pPIO = pin_to_controller(pin);
	DWORD dwMask = pin_to_mask(pin);

	if (pPIO == NULL)
		return;

	if (is_on)
	{
		pPIO->PIO_MDER = dwMask;
	}
	else
	{
		pPIO->PIO_MDDR = dwMask;
	}	
}

//-----------------------------------------------------------------------------
//! \fn			void pio_set_value(unsigned pin, int value)
//!
//! \brief		This function sets the pin value assuming it is muxed as a gpio output
//!
//! \param		pin 			pin number
//! \param		value 		value to be set
//!
//-----------------------------------------------------------------------------
void pio_set_value(unsigned pin, int value)
{
	AT91PS_PIO pPIO = pin_to_controller(pin);
	DWORD dwMask = pin_to_mask(pin);

	if (pPIO == NULL)
		return;

	if (value)
	{
		pPIO->PIO_SODR = dwMask;
	}
	else
	{
		pPIO->PIO_CODR = dwMask;
	}	
}

//-----------------------------------------------------------------------------
//! \fn			int pio_get_value(unsigned pin)
//!
//! \brief		This function reads the pin's value (works even if it's not muxed as a gpio)
//!				!!! PIO Clock must be enabled in the PMC !!!	
//!
//! \param		pin 			pin number
//!
//! \return		-1 if error, else value of the pin (0 or 1)
//!
//-----------------------------------------------------------------------------
int pio_get_value(unsigned pin)
{
	AT91PS_PIO pPIO = pin_to_controller(pin);
	DWORD dwMask = pin_to_mask(pin);

	if (pPIO == NULL)
		return -1;

	if (pPIO->PIO_PDSR & dwMask)
	{
		return 1;
	}
	else
	{
		return 0;
	}	
}

 __declspec(dllexport) void truc()
{
}

//-----------------------------------------------------------------------------
//! \fn			int pio_setup (const struct pio_desc *pio_desc, int nb_pio)
//!
//! \brief		This function configures PIO in periph mode according to the platform informations
//!
//! \param		pio_desc 			pointer to a structure pio_desc
//! \param		nb_pio 			number of pio
//!
//! \return		0 if error, else pin number (= nb_pio)
//!
//-----------------------------------------------------------------------------
int pio_setup (const struct pio_desc *pio_desc, int nb_pio)
{
        unsigned        pin = 0;
		AT91PS_PIO pPIO;

		if(!pio_desc) 
		{
			return 0;
        }

        /* Sets all the pio muxing of the corresponding device as defined in its platform_data struct */
        do
		{
			    pPIO = pin_to_controller( pio_desc->pin_num);
				if (pPIO == NULL)
				{
				//	RETAILMSG(1,(TEXT("Could not configure PIO %s. Aborting PIO config\r\n"),pio_desc->pin_name));
                	return 0;
				}
                else if ((pio_desc->type == PIO_PERIPH_A) || (pio_desc->type == PIO_PERIPH_B))
				{						
						pio_set_multi_drive(pio_desc->pin_num, (pio_desc->attribute & PIO_OPENDRAIN) ? 1 : 0);
                        pio_set_periph(pio_desc->pin_num,(pio_desc->attribute & PIO_PULLUP) ? 1 : 0, pio_desc->type);
				}
                else if (pio_desc->type == PIO_INPUT) {
                        pio_set_deglitch(pio_desc->pin_num,
                                (pio_desc->attribute & PIO_DEGLITCH)? 1 : 0);
                        pio_set_gpio(pio_desc->pin_num,
                                (pio_desc->attribute & PIO_PULLUP) ? 1 : 0,
								PIO_INPUT);
                }
                else if(pio_desc->type == PIO_OUTPUT) {
						pio_set_value(pio_desc->pin_num, pio_desc->dft_value);
                        pio_set_multi_drive(pio_desc->pin_num, (pio_desc->attribute & PIO_OPENDRAIN) ? 1 : 0);
                        pio_set_gpio(pio_desc->pin_num, (pio_desc->attribute & PIO_PULLUP) ? 1 : 0, PIO_OUTPUT);						
                }
                else
                         return 0;
                ++pin;
                ++pio_desc;
        }
		while(pin != nb_pio);
        return pin;
}
//! @}
//! @}
