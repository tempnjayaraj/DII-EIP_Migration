//-----------------------------------------------------------------------------
//! \addtogroup   OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file			profiler.c
//!
//! \brief			AT91RM9200's profiler feature
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/KERNEL/PROFILER/profiler.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

#include <windows.h>
#include <nkintr.h>
#include <oal.h>
#include <intr.h>
#include "at91rm9200.h"
#include "AT91RM9200_interface.h"
#include "AT91RM9200_oal_profiler.h"

#ifndef OAL_PROFILER_TIMER_NUMBER
/// This defines the TimerCounter controller that's going to be used for the profiler
///
/// \note Do not change the default Timer Counter value in the code.
/// If you want to select another timer counter for profiling then set the environment variable
/// OAL_PROFILER_TIMER_NUMBER to the correct value
#define OAL_PROFILER_TIMER_NUMBER	1	
#endif


const T_PROFILER_TIMER_DESCRIPTION ProfilerDesc = {
#if   (OAL_PROFILER_TIMER_NUMBER == 0)
AT91C_ID_TC0, AT91C_BASE_TC0
#elif (OAL_PROFILER_TIMER_NUMBER == 1)
AT91C_ID_TC1, AT91C_BASE_TC1
#elif (OAL_PROFILER_TIMER_NUMBER == 2)
AT91C_ID_TC2, AT91C_BASE_TC2
#else
#error Invalid timer number
#endif 
};

const T_PROFILER_TIMER_DESCRIPTION *g_pProfilerDesc =  &ProfilerDesc;

//For similarity with at91sam BSP
#define 	AT91C_TC_CLKS_TIMER_DIV3_CLOCK     ((unsigned int) 0x2) // (TC) Clock selected: TIMER_DIV3_CLOCK

//------------------------------------------------------------------------------
/*! \var PFN_PROFILER_ISR g_pProfilerISR
*	\brief	This variable contains a pointer to the Profiler's interrupt handler.
			It's used in the main interrupt handler whenever a profiler interrupt is detected.
*/
PFN_PROFILER_ISR g_pProfilerISR;
/*! \var PFN_PROFILER_ISR g_dwProfilerIRQ
*	\brief	This variable contains the interrupt number (IRQ not SYSINTR) used by the profiler's timer-counter.
			It's used in the main interrupt handler to detect whether an interrupt is used forprofiling or not.
*/
DWORD g_dwProfilerIRQ;


//------------------------------------------------------------------------------
// Internal Variables 

//Pointer to the virtual address of the current profiler's timer-counter.
static AT91PS_TC pTCInHandler = NULL;

//-----------------------------------------------------------------------------
//! \fn static void SetupTimer(AT91PS_TC pPhysTC,DWORD interval)
//!
//!	\brief This function sets up the hardware (a timer-counter) so that it triggers an interrupt every xxx microseconds.
//!
//!	\param pPhysTC the physical address of the timer-counter
//!	\param interval the period of the interrupt in micro-seconds
//! 
//-----------------------------------------------------------------------------
static void SetupTimer(AT91PS_TC pPhysTC,DWORD interval)
{

	BOOL bTooShort = FALSE;
	BOOL bTooBig = FALSE;
	DWORD intervalInMasterClkPeriod;
	AT91PS_TC pTC;	
	UINT64 temp;

	pTC = (AT91PS_TC) OALPAtoVA((DWORD)pPhysTC,FALSE);	
	pTCInHandler = pTC;
	if (pTC == NULL)
	{
		RETAILMSG(1,(TEXT("OAL Profiler : SetupTimer. Unable to remap TC pointer\r\n")));
		return;
	}
/*! \note The interval is given in micro-seconds. It's converted in (masterClock / 32) periods because the timer-counter is configured to run on Master Clock DIV 32 (TIMER_CLOCK3). This value is then clipped between 1 and 0xFFFF.
*/
  temp = ((UINT64)interval * (AT91RM9200_GetMasterClock(TRUE)/32)) / 1000000;
	if (temp == 0)
	{
		RETAILMSG(1,(TEXT("OAL Profiler : SetupTimer. interval is too short (interval = %d us)\r\n"),interval));
		intervalInMasterClkPeriod = 1;
	}
	else if (temp > 0xFFFF)
	{
		RETAILMSG(1,(TEXT("OAL Profiler : SetupTimer. interval is too big (interval = %d us)\r\n"),interval));
		intervalInMasterClkPeriod = 0xFFFF;
	}
	else
	{
		intervalInMasterClkPeriod = (DWORD) (temp & 0xFFFFFFFF);
	}
	

	//First of all, disable the TC.
	pTC->TC_CCR = AT91C_TC_CLKDIS;

/*! \note The timer is set up to use TIMER_CLOCK3, to be in Waveform mode and to trigger automatically on Rc compare.
*/	
	pTC->TC_CMR = AT91C_TC_CLKS_TIMER_DIV3_CLOCK | AT91C_TC_WAVE | AT91C_TC_WAVESEL_UP_AUTO;

/*! \note Rc is loaded with newly converted interval.
*/		
	pTC->TC_RA = 0;
	pTC->TC_RB = 0;
	pTC->TC_RC = intervalInMasterClkPeriod;

/*! \note An interrupt is fired when RC compare occurs
*/
	pTC->TC_IER = AT91C_TC_CPCS | AT91C_TC_CPAS | AT91C_TC_CPBS;

	// Enable the timer and reset it
	pTC->TC_CCR = AT91C_TC_CLKEN | AT91C_TC_SWTRG;
}


//------------------------------------------------------------------------------
//! \fn UINT32 OALProfileIntrHandler(UINT32 ra)
//!
//!	\brief This function is called by the main interrupt handler when a profiler interrupt occurs. It acknowledges the Timer-Counter and signals the hit to the Profiling engine.
//!
//!	\param ra This is the value of PC when the execution was interrupted.
//!
//!	\return This function always return SYSINTR_NOP
//!
//------------------------------------------------------------------------------
UINT32 OALProfileIntrHandler(UINT32 ra)
{
	//First acknowledge the interrupt
	if (pTCInHandler->TC_SR & AT91C_TC_CPCS)
	{
		// First call profiler
		ProfilerHit(ra);
	}

    return SYSINTR_NOP; 
}


//------------------------------------------------------------------------------
//! \fn VOID OEMProfileTimerEnable(DWORD interval)
//!
//!	\brief This function is called by the Kernel to enable the profiling interrupt. This function calls SetupTimer
//!
//!	\param interval This is the period of the profiling interrupt.
//!
//------------------------------------------------------------------------------

VOID OEMProfileTimerEnable(DWORD interval)
{
    AT91PS_PMC pPMC;
        
    OALMSG(TRUE, (L"+OEMProfileTimerEnable(%d)\r\n", interval));    	

	// Power up the TC controller    
	pPMC = (AT91PS_PMC) OALPAtoVA((DWORD) AT91C_BASE_PMC,FALSE);
    pPMC->PMC_PCER = (1<<g_pProfilerDesc->IdIrq);
	pPMC->PMC_PCER = (1<<g_pProfilerDesc->IdIrq);
	
	//Setup the TC controller to trigger an interrupt every "interval" us
    SetupTimer(g_pProfilerDesc->pTC,interval);
	
	// Enable the IRQ and give a pointer toward the handler. also give the IRQ number
	g_dwProfilerIRQ = g_pProfilerDesc->IdIrq;
	g_pProfilerISR = OALProfileIntrHandler;

	RETAILMSG(1,(TEXT("--g_dwProfilerIRQ %d g_pProfilerISR 0x%x\r\n"),g_dwProfilerIRQ,g_pProfilerISR));

    OALIntrEnableIrqs(1,&g_dwProfilerIRQ);

    OALMSG(TRUE, (L"-OEMProfileTimerEnable\r\n"));
}


//------------------------------------------------------------------------------
//! \fn VOID OEMProfileTimerDisable()
//!
//!	\brief This function is called by kernel to stop kernel profiling timer.
//!
//------------------------------------------------------------------------------

VOID OEMProfileTimerDisable()
{  
	AT91PS_PMC pPMC;

    OALMSG(TRUE, (L"+OEMProfileTimerDisable()\r\n"));
    
	//Disable the IRQ
    OALIntrDisableIrqs(1,&g_dwProfilerIRQ);

	//Power down the TC controller
	pPMC = (AT91PS_PMC) OALPAtoVA((DWORD) AT91C_BASE_PMC,FALSE);    
	pPMC->PMC_PCER = (1<<g_pProfilerDesc->IdIrq);
	
	// Remove information about the handler
    g_dwProfilerIRQ = 0xFFFFFFFF;
    g_pProfilerISR = NULL;
    
    OALMSG(TRUE, (L"-OEMProfileTimerDisable\r\n"));
}

//! @}

