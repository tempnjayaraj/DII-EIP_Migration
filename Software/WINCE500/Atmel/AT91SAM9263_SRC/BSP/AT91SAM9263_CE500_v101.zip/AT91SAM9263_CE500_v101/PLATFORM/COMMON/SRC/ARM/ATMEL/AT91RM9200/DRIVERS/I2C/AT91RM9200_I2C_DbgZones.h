//-----------------------------------------------------------------------------
//! \addtogroup	I2C
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file	AT91RM9200_I2C_DbgZones.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/DRIVERS/I2C/AT91RM9200_I2C_DbgZones.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//! Debug zones masks and declaration
//-----------------------------------------------------------------------------

#ifndef __AT91RM9200_I2C_DBGZONES_H__
#define __AT91RM9200_I2C_DBGZONES_H__

#include <DBGAPI.H>

#define DEBUGMASK(n) (0x00000001<<n)

#define MASK_INIT    DEBUGMASK(0)
#define MASK_DEINIT  DEBUGMASK(1)
#define MASK_OPEN    DEBUGMASK(2)
#define MASK_CLOSE   DEBUGMASK(3)
#define MASK_READ    DEBUGMASK(4)
#define MASK_WRITE   DEBUGMASK(5)
#define MASK_SEEK    DEBUGMASK(6)
#define MASK_IOCTL   DEBUGMASK(7)
#define MASK_ZONE8   DEBUGMASK(8)
#define MASK_ZONE9   DEBUGMASK(9)
#define MASK_ZONE10  DEBUGMASK(10)
#define MASK_ZONE11  DEBUGMASK(11)
#define MASK_ZONE12  DEBUGMASK(12)
#define MASK_INFO    DEBUGMASK(13)
#define MASK_WARN    DEBUGMASK(14)
#define MASK_ERROR   DEBUGMASK(15)

#ifdef DEBUG
// These macros are used as the first arg to DEBUGMSG.
#define ZONE_INIT    DEBUGZONE(0)
#define ZONE_DEINIT  DEBUGZONE(1)
#define ZONE_OPEN    DEBUGZONE(2)
#define ZONE_CLOSE   DEBUGZONE(3)
#define ZONE_READ    DEBUGZONE(4)
#define ZONE_WRITE   DEBUGZONE(5)
#define ZONE_SEEK    DEBUGZONE(6)
#define ZONE_IOCTL   DEBUGZONE(7)
#define ZONE_ZONE8   DEBUGZONE(8)
#define ZONE_ZONE9   DEBUGZONE(9)
#define ZONE_ZONE10  DEBUGZONE(10)
#define ZONE_ZONE11  DEBUGZONE(11)
#define ZONE_ZONE12  DEBUGZONE(12)
#define ZONE_INFO    DEBUGZONE(13)
#define ZONE_WARN    DEBUGZONE(14)
#define ZONE_ERROR   DEBUGZONE(15)
#else
  // For release configurations, these conditionals are always 0.
#define ZONE_INIT    0
#define ZONE_DEINIT  0
#define ZONE_OPEN    0
#define ZONE_CLOSE   0
#define ZONE_READ    0
#define ZONE_WRITE   0
#define ZONE_SEEK    0
#define ZONE_IOCTL   0
#define ZONE_ZONE8   0
#define ZONE_ZONE9   0
#define ZONE_ZONE10  0
#define ZONE_ZONE11  0
#define ZONE_ZONE12  0
#define ZONE_INFO    0
#define ZONE_WARN    0
#define ZONE_ERROR   0
#endif // DEBUG


#endif //__AT91RM9200_I2C_DBGZONES_H__

//! @}
