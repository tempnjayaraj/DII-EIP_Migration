//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/IOCTL/procinfo.c
//!
//! \brief		This file implements the IOCTL_PROCESSOR_INFORMATION handler
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/IOCTL/procinfo.c $
//!   $Author: pblanchard $
//!   $Revision: 1090 $
//!   $Date: 2007-07-13 07:07:28 -0700 (Fri, 13 Jul 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

//! \addtogroup	IOCTL
//! @{

#include <windows.h>
#include <oal.h>
#include "at91sam926x.h"
#include "at91sam926x_interface.h"


extern const T_PROC_INFO *MiscSpecificGetProcInfo();

//-----------------------------------------------------------------------------
//! \fn			BOOL OALIoCtlProcessorInfo(UINT32 code, VOID *pInpBuffer, UINT32 inpSize, VOID *pOutBuffer, UINT32 outSize, UINT32 *pOutSize)
//!
//! \brief		Implements the IOCTL_PROCESSOR_INFORMATION handler.
//!				Returns information about the processor (vendor, Instruction set, frequency, etc ...)
//!
//!	\param		code			not used
//!	\param		pInpBuffer	not used
//!	\param		inpSize		not used
//!	\param		pOutBuffer	Information returned
//!	\param		outSize		Size of pOutBuffer
//!	\param		pOutSize		Size of pOutBuffer used
//!
//! \return		TRUE indicates success
//! \return		FALSE indicates failure (bad parameters)
//-----------------------------------------------------------------------------
BOOL OALIoCtlProcessorInfo(
    UINT32 code, VOID *pInpBuffer, UINT32 inpSize, VOID *pOutBuffer, 
    UINT32 outSize, UINT32 *pOutSize
) {
    BOOL rc = TRUE;
    PROCESSOR_INFO *pInfo = (PROCESSOR_INFO*)pOutBuffer;
    UINT32 length1, length2, length3, length4;
	const T_PROC_INFO *sProcInfo;

    OALMSG(OAL_FUNC, (L"+OALIoCtlProcessorInfo(...)\r\n"));

    // Set required/returned size if pointer isn't NULL
    if (pOutSize != NULL) *pOutSize = sizeof(PROCESSOR_INFO);
    
    // Validate inputs
    if (pOutBuffer == NULL && outSize > 0) {
        NKSetLastError(ERROR_INVALID_PARAMETER);
        OALMSG(OAL_WARN, (
            L"WARN: OALIoCtlProcessorInfo: Invalid output buffer\r\n"
        ));
        return FALSE;
    }

    if (pOutBuffer == NULL || outSize < sizeof(PROCESSOR_INFO)) {
        NKSetLastError(ERROR_INSUFFICIENT_BUFFER);
        OALMSG(OAL_WARN, (
            L"WARN: OALIoCtlProcessorInfo: Buffer too small\r\n"
        ));
        return FALSE;
    }

	sProcInfo = MiscSpecificGetProcInfo();

    // Verify OAL lengths
    length1 = (NKwcslen(sProcInfo->cCore) + 1) * sizeof(WCHAR);
    if (length1 > sizeof(pInfo->szProcessCore)) {
        OALMSG(OAL_ERROR, (
            L"ERROR:OALIoCtlProcessorInfo: Core value too big\r\n"
        ));
        rc = FALSE;
    }

    length2 = (NKwcslen(sProcInfo->cProcessor) + 1) * sizeof(WCHAR);
    if (length2 > sizeof(pInfo->szProcessorName)) {
        OALMSG(OAL_ERROR, (
            L"ERROR:OALIoCtlProcessorInfo: Name value too big\r\n"
        ));
        rc = FALSE;
    }

    length3 = (NKwcslen(sProcInfo->cManufacturer) + 1) * sizeof(WCHAR);
    if (length3 > sizeof(pInfo->szVendor)) {
        OALMSG(OAL_ERROR, (
            L"ERROR:OALIoCtlProcessorInfo: Vendor value too big\r\n"
        ));
        rc = FALSE;
    }

	length4 = (NKwcslen(sProcInfo->cCatalogNumber) + 1) * sizeof(WCHAR);
	if (length4 > sizeof(pInfo->szCatalogNumber)) {
        OALMSG(OAL_ERROR, (
            L"ERROR:OALIoCtlProcessorInfo: Catalog number value too big\r\n"
        ));
        rc = FALSE;
    }

	if(rc)
	{
    memset(pInfo, 0, sizeof(PROCESSOR_INFO));

		// Copy in processor information
		pInfo->wVersion = 1; // required with value 1
		memcpy(pInfo->szProcessCore, sProcInfo->cCore, length1);
		memcpy(pInfo->szProcessorName, sProcInfo->cProcessor, length2);
		memcpy(pInfo->szVendor, sProcInfo->cManufacturer, length3);
		memcpy(pInfo->szCatalogNumber, sProcInfo->cCatalogNumber, length4);
		pInfo->wCoreRevision = sProcInfo->wCoreRevision;
		pInfo->wProcessorRevision = sProcInfo->wProcessorRevision;
		pInfo->dwInstructionSet = sProcInfo->dwInstructionSet;
		pInfo->dwClockSpeed  = sProcInfo->dwClockSpeed;
	}
	else
	{
		OALMSG(OAL_FUNC, (L"-OALIoCtlAT91RM9200ProcessorInfo(rc = %d)\r\n", rc));
	}
    return rc;
}

//! @} end of subgroup IOCTL

//! @} end of group OAL


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/IOCTL/procinfo.c $
////////////////////////////////////////////////////////////////////////////////
//
