//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x_oal_ioctl.h
//!
//! \brief		Custom kernel IOCTLs declaration file
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/IOCTL/AT91SAM926x_oal_ioctl.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//-----------------------------------------------------------------------------

#ifndef AT91SAM926X_OALIOCTL_H
#define AT91SAM926X_OALIOCTL_H

#define SOFT_REBOOT_MAGIC 0xA5CAFE5A

#define COLD_BOOT	1
#define WARM_BOOT	2
#define SOFT_BOOT	3

#define HAL_SHUTDOWN_CMD		1
#define HAL_MASTERCLOCK_CMD		2
#define HAL_PLLACLOCK_CMD		3
#define HAL_PLLBCLOCK_CMD		4
#define HAL_PROCESSORCLOCK_CMD	5
#define HAL_KITLARGS_CMD		6

#define IOCTL_HAL_SHUTDOWN			CTL_CODE(FILE_DEVICE_HAL, IOCTL_KLIB_USER + HAL_SHUTDOWN_CMD, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_HAL_MASTERCLOCK		CTL_CODE(FILE_DEVICE_HAL, IOCTL_KLIB_USER + HAL_MASTERCLOCK_CMD, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_HAL_PLLACLOCK			CTL_CODE(FILE_DEVICE_HAL, IOCTL_KLIB_USER + HAL_PLLACLOCK_CMD, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_HAL_PLLBCLOCK			CTL_CODE(FILE_DEVICE_HAL, IOCTL_KLIB_USER + HAL_PLLBCLOCK_CMD, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_HAL_PROCESSORCLOCK	CTL_CODE(FILE_DEVICE_HAL, IOCTL_KLIB_USER + HAL_PROCESSORCLOCK_CMD, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_HAL_GET_KITL_ARGS		CTL_CODE(FILE_DEVICE_HAL, IOCTL_KLIB_USER + HAL_KITLARGS_CMD, METHOD_BUFFERED, FILE_ANY_ACCESS)

BOOL OALIoCtlHalShutdown(UINT32 code, VOID *pInpBuffer, 
                       UINT32 inpSize, VOID *pOutBuffer, 
                       UINT32 outSize, UINT32 *pOutSize);

BOOL OALIoCtlHalGetMasterClock(	UINT32 code, VOID *pInpBuffer, 
								UINT32 inpSize, VOID *pOutBuffer, 
								UINT32 outSize, UINT32 *pOutSize);

BOOL OALIoCtlHalGetPLLAClock(	UINT32 code, VOID *pInpBuffer, 
								UINT32 inpSize, VOID *pOutBuffer, 
								UINT32 outSize, UINT32 *pOutSize);

BOOL OALIoCtlHalGetPLLBClock(	UINT32 code, VOID *pInpBuffer, 
								UINT32 inpSize, VOID *pOutBuffer, 
								UINT32 outSize, UINT32 *pOutSize);

BOOL OALIoCtlHalGetProcessorClock(	UINT32 code, VOID *pInpBuffer, 
								UINT32 inpSize, VOID *pOutBuffer, 
								UINT32 outSize, UINT32 *pOutSize);

BOOL OALIoCtlHalGetKitlArgs(	UINT32 code, VOID *pInpBuffer, 
								UINT32 inpSize, VOID *pOutBuffer, 
								UINT32 outSize, UINT32 *pOutSize);


extern BOOL (*g_pfnBSPIoCtlHalShutdown)(UINT32 code, VOID *pInpBuffer,		
									UINT32 inpSize, VOID *pOutBuffer,
									UINT32 outSize, UINT32 *pOutSize);

#endif

//! @}

/* The file has been moved, this is the historique before the movement

// History : Revision 1.8  2006/03/16 14:36:56  ngocel
// History : Add IOCTL to get PLLA, PLLB, and processor clock
// History :
// History : Revision 1.7  2006/03/08 16:32:35  jjhiblot
// History : moved some defines where they belong (.h file)
// History :
// History : Revision 1.6  2006/02/15 10:37:21  jjhiblot
// History : Added real shutdwon support
// History : Added BSP specific shutdwon entry point
// History :
// History : Revision 1.5  2005/11/18 15:18:44  jjhiblot
// History : Enhanced and fixed doxygen support
// History :
// History : Revision 1.4  2005/07/21 09:07:45  dmartin
// History : DMR : Doxy+CVS
// History :
// History : Revision 1.3  2005/07/19 08:02:35  jjhiblot
// History : Modified CVS headers to work with dOxygen
// History :
// History : Revision 1.2  2005/07/11 12:45:44  dmartin
// History : DMR : ChipSelect support extracted from PLL lib
// History :
// History : Revision 1.1  2005/07/06 17:16:51  jjhiblot
// History : *** empty log message ***
// History :
*/

////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/IOCTL/AT91SAM926x_oal_ioctl.h $
////////////////////////////////////////////////////////////////////////////////
//
