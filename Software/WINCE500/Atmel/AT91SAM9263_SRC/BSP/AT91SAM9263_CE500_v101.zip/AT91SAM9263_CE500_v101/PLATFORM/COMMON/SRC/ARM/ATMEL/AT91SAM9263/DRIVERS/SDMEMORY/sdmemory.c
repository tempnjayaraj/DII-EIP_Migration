//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//! \addtogroup	SDMEMORY
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM9263/DRIVERS/SDMEMORY/sdmemory.c
//!
//! \brief		SD memory driver for AT91SAM9263's chipset
//!
//! \if cvs
//!   $Author: edaniel $
//!   $Revision: 704 $
//!   $Date: 2007-04-16 14:09:03 +0200 (lun., 16 avr. 2007) $
//! \endif
//!
//! Description of the driver on multi lines
//-----------------------------------------------------------------------------


// System include
#include <windows.h>
#include <oal.h>

// Local include
#include "at91sam9263.h"

extern DWORD SDMemoryBoardSpecificGetMCIID(DWORD dwSlotNumber);

//-----------------------------------------------------------------------------
//! \fn			void SDMemoryProcSpecificActivatePMC(DWORD dwSlotNumber)
//!
//! \brief		This function activates the clock for SDMemory controller in PMC
//!
//! \param		dwSlotNumber	Slot number
//!
//-----------------------------------------------------------------------------
void SDMemoryProcSpecificActivatePMC(DWORD dwSlotNumber)
{
	AT91PS_PMC	pPMC;
	PHYSICAL_ADDRESS pa;

	pa.LowPart = (DWORD)AT91C_BASE_PMC;
	pPMC =  (AT91PS_PMC)MmMapIoSpace(pa, sizeof(AT91S_PMC), FALSE);		
		// Enable Peripheral clock in PMC for  EMAC

	pPMC->PMC_PCER = 1 << SDMemoryBoardSpecificGetMCIID(dwSlotNumber);

	MmUnmapIoSpace(pPMC, sizeof(AT91S_PMC));
}

//-----------------------------------------------------------------------------
//! \fn			void SDMemoryProcSpecificDeactivatePMC(DWORD dwSlotNumber)
//!
//! \brief		This function deactivates the clock for SDMemory controller in PMC
//!
//! \param		dwSlotNumber	Slot number
//!
//-----------------------------------------------------------------------------
void SDMemoryProcSpecificDeactivatePMC(DWORD dwSlotNumber)
{
	AT91PS_PMC	pPMC;
	PHYSICAL_ADDRESS pa;

	pa.LowPart = (DWORD)AT91C_BASE_PMC;
	pPMC =  (AT91PS_PMC)MmMapIoSpace(pa, sizeof(AT91S_PMC), FALSE);		
		// Enable Peripheral clock in PMC for  EMAC		

	pPMC->PMC_PCDR = 1 << SDMemoryBoardSpecificGetMCIID(dwSlotNumber);

	MmUnmapIoSpace(pPMC, sizeof(AT91S_PMC));		

}

//! @}
//! @}
