///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9263_oal_ioctl_tab.h 
//!
//! \brief		This file contains part of global IOCTL handler table for codes which must (or should) be implemented on all AT91SAM926x-based platforms. 
//!
//! This file is included by the platform's IOCTL table, g_oalIoCtlTable[].
//! Therefore, this file may ONLY define OAL_IOCTL_HANDLER entries. 
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/INC/AT91SAM9263_oal_ioctl_tab.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//-----------------------------------------------------------------------------



//------------------------------------------------------------------------------
// IOCTL CODE,                          Flags   Handler Function
//------------------------------------------------------------------------------


//! @}

////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/INC/AT91SAM9263_oal_ioctl_tab.h $
////////////////////////////////////////////////////////////////////////////////
//