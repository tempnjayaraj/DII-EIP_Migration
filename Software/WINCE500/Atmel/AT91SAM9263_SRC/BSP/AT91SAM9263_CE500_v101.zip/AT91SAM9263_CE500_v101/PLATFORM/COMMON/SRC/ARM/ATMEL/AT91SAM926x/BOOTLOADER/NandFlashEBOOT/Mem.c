//-----------------------------------------------------------------------------
//! addtogroup	BOOTLOADER
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/NandFlashEBOOT/Mem.c
//!
//! \brief		StaticMalloc & StaticMemcpy (We can't link to malloc during bootloader, so we use static 64kB space)
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/NandFlashEBOOT/NandIds.c $
//!   $Author: ltourlonias $
//!   $Revision: 657 $
//!   $Date: 2007-04-10 16:52:09 +0200 (mar., 10 avr. 2007) $
//! \endif
//!
//! 
//-----------------------------------------------------------------------------
//! \addtogroup	NandFlash
//! @{
//!

#include "Mem.h"

// All statically allocated memory
static DWORD dwMemoryUsed = 0;

// Statically allocate memory in RAM
void* StaticMalloc(DWORD dwSizeInBytes)
{
	void* pVoid = (void*)(AT91SAM926XEK_FMD_MAPPING + dwMemoryUsed);

	// Compute total used memory, keep it aligned on dword
	dwMemoryUsed = (dwMemoryUsed + dwSizeInBytes + 4) & 0xFFFFFFFC;

	// If we ran out memory
	if (dwMemoryUsed>0xFFFF)
		RETAILMSG(1, (TEXT("StaticMalloc::Out of memory\n\r")));

	return pVoid;
}

// Our own memcpy
void* StaticMemcpy(void* dest, const void* src, size_t count)
{
	DWORD i;

	for (i=0; i<count; i++)
	{
		*(((BYTE*)dest)++) = *(((BYTE*)src)++);
	}

	return ((BYTE*)dest)-count;
}

void StaticFree(void *ptr) {
	
}

//! @}
//! @}
