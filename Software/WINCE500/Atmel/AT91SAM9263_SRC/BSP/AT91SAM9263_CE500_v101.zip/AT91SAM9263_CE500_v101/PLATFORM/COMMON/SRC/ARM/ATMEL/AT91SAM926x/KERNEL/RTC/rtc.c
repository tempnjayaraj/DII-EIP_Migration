//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x/KERNEL/RTC/rtc.c
//!
//! \brief		RTC management implementation (OEMSetAlarmTime is not implemented yet)
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/RTC/rtc.c $
//!   $Author: pblanchard $
//!   $Revision: 990 $
//!   $Date: 2007-06-12 01:19:53 -0700 (Tue, 12 Jun 2007) $
//! \endif
//-----------------------------------------------------------------------------


//! \addtogroup	RTC
//! @{

#include <windows.h>
#include <oal.h>
#include <nkintr.h>


//#define RTC_IS_BASED_ON_RTT
#ifdef RTC_IS_BASED_ON_RTT

#include "at91sam926x.h"
#include "at91sam926x_timebomb.h"

#define RTT_RESTART_THRESOLD	0x0FFFFFFF //If the RTT timer gose over this value, then we restart it

static volatile DWORD *g_pGeneralPurPoseBackupRegister = NULL;
static AT91PS_RTTC pRTT = NULL;

extern DWORD RTCProcSpecificGetGPBR(void);
extern DWORD RTCProcSpecificGetRTTCBaseAddress(void);
extern DWORD RTCProcSpecificGetClockFrequency(void);
extern DWORD RTCProcSpecificGetRSTCBaseAddress(void);
extern DWORD RTCProcSpecificGetRTTPeriod(void);

//-----------------------------------------------------------------------------
//! \fn     UINT64 GetAndUpdateRTCValue(BOOL bForceTimerRestart)
//!
//!	\brief  This function gets the current RTC value
//!
//!	\param  bForceTimerRestart Indicates if the timer must be reset
//!
//!
//! 
//-----------------------------------------------------------------------------
UINT64 GetAndUpdateRTCValue(BOOL bForceTimerRestart)
{
	BOOL	enabled = FALSE;
	UINT64 time;
	UINT64 elapsed;
	BOOL bInterruptsEnabled;
	DWORD dwRTVR;	
	
	if (g_pGeneralPurPoseBackupRegister == NULL)
	{
		g_pGeneralPurPoseBackupRegister = OALPAtoVA(RTCProcSpecificGetGPBR(),FALSE);
	}

	if (pRTT == NULL)
	{
		pRTT = (AT91PS_RTTC) OALPAtoVA(RTCProcSpecificGetRTTCBaseAddress(),FALSE);	
	}
	
	if ((pRTT == NULL) || (g_pGeneralPurPoseBackupRegister==NULL))
	{
		return (UINT64)-1;
	}

	
	bInterruptsEnabled = INTERRUPTS_ENABLE(FALSE);

	time = ((UINT64) g_pGeneralPurPoseBackupRegister[1]) << 32 | g_pGeneralPurPoseBackupRegister[0];
	//Get the counter of the RTT
	{
		DWORD dwTemp;		
		do
		{
			dwRTVR = pRTT->RTTC_RTVR;
			dwTemp = pRTT->RTTC_RTVR;
			if (dwRTVR != dwTemp)
			{
				if ((dwRTVR+1) != dwTemp)
				{
					RETAILMSG(1,(TEXT("RTC Went backward !! (%u)  -  (%u) = %d (!!!!!!!!!!!!!)\r\n"),dwRTVR,dwTemp,dwRTVR-dwTemp));
				}
			}
			
		}while (dwTemp != dwRTVR);
	}
	elapsed = ((UINT64)  dwRTVR * 1000 *	(UINT64)(pRTT->RTTC_RTMR & AT91C_RTTC_RTPRES)) / RTCProcSpecificGetClockFrequency();
	
	//Compute the new RTC time ...
    time = time + elapsed;

	
	
	if ((dwRTVR > RTT_RESTART_THRESOLD) || (bForceTimerRestart))
	{
		
		RETAILMSG(1,(TEXT("resetting RTT to delay rollover\r\n")));
		//restart the RTT
		pRTT->RTTC_RTMR = AT91C_RTTC_RTTRST | RTCProcSpecificGetRTTPeriod();		
		// ... and store the time in the general purpose backup register
		g_pGeneralPurPoseBackupRegister[0] = (DWORD) (time & 0xFFFFFFFF);
		g_pGeneralPurPoseBackupRegister[1] = (DWORD) (time >> 32);
		g_pGeneralPurPoseBackupRegister[2] = ~(g_pGeneralPurPoseBackupRegister[0] ^ g_pGeneralPurPoseBackupRegister[1]);

	}

		INTERRUPTS_ENABLE(bInterruptsEnabled);

	return time;
}

//-----------------------------------------------------------------------------
//! \fn		BOOL OALIoCtlHalInitRTC(UINT32 code, void* pInpBuffer, UINT32 inpSize, void* pOutBuffer, UINT32 outSize, UINT32* pOutSize)
//!
//! \brief		This function implements the IOCTL_HAL_INITRTC IOControl
//!				This function is called by WinCE OS to initialize the time after boot.
//!				Input buffer contains SYSTEMTIME structure with default time value.
//!				If hardware has persistent real time clock it will ignore this value
//!				(or all call).
//!
//!	\param		code		not used
//!	\param		pInpBuffer	Initial time
//!	\param		inpSize		sizeof(SYSTEMTIME)
//!	\param		pOutBuffer	not used
//!	\param		outSize		not used
//!	\param		pOutSize	not used
//!
//! \return		TRUE indicates success
//! \return		FALSE indicates failure (bad parameters)
//! 
//-----------------------------------------------------------------------------
BOOL OALIoCtlHalInitRTC(UINT32 code, void* pInpBuffer, UINT32 inpSize, void* pOutBuffer, UINT32 outSize, UINT32* pOutSize)
{
	BOOL bUsePersistentRealTimeClock = FALSE;
	UINT64 timeFromBackup = 0;
    BOOL rc = FALSE;
    SYSTEMTIME *pTime = (SYSTEMTIME*)pInpBuffer;
	

	RETAILMSG(1, (L"+OALIoCtlHalInitRTC(...)\r\n"));
    OALMSG(OAL_IOCTL&&OAL_FUNC, (L"+OALIoCtlHalInitRTC(...)\r\n"));

	
	if (g_pGeneralPurPoseBackupRegister == NULL)
	{
		g_pGeneralPurPoseBackupRegister = OALPAtoVA(RTCProcSpecificGetGPBR(),FALSE);
	}
 

	// In case we have a real RTC, we don't want to use the default system time
	if (g_pGeneralPurPoseBackupRegister[2] == ~(g_pGeneralPurPoseBackupRegister[0] ^ g_pGeneralPurPoseBackupRegister[1]))
	{
		bUsePersistentRealTimeClock = TRUE;
	}
	

	if (bUsePersistentRealTimeClock == FALSE)
	{
		// Validate inputs
		if (pInpBuffer == NULL || inpSize < sizeof(SYSTEMTIME)) {
			NKSetLastError(ERROR_INVALID_PARAMETER);
			OALMSG(OAL_ERROR, (
				L"ERROR: OALIoCtlHalInitRTC: Invalid parameter\r\n"
			));
			goto cleanUp;
		}
		rc = OEMSetRealTime(pTime);	
	}
	
    
cleanUp:
	RETAILMSG(1, (L"-OALIoCtlHalInitRTC(rc = %d)\r\n", rc));
    OALMSG(OAL_IOCTL&&OAL_FUNC, (L"-OALIoCtlHalInitRTC(rc = %d)\r\n", rc));
    return rc;
}

//-----------------------------------------------------------------------------
//! \fn BOOL OEMGetRealTime(SYSTEMTIME *pTime)
//!
//!	\brief This function is called by the kernel to retrieve the time from the real-time clock.
//!
//!	\param  SYSTEMTIME* pTime Pointer to return current time from the real-time clock
//! 
//!	\return TRUE indicates success
//!	\return FALSE indicates failure
//-----------------------------------------------------------------------------
BOOL OEMGetRealTime(SYSTEMTIME *pTime)
{
    BOOL rc;
    ULARGE_INTEGER time;
    FILETIME fileTime;
    UINT64 ticks;
	BOOL bInterruptsEnabled;

	TIMEBOMB_INIT_ONCE(DEFAULT_TIME_BOMB);
	TIMEBOMB_CHECK(L"RTC");

    OALMSG(OAL_RTC&&OAL_FUNC, (L"+OEMGetRealTime\r\n"));

	bInterruptsEnabled = INTERRUPTS_ENABLE(FALSE);

    ticks = GetAndUpdateRTCValue(FALSE);
    
    // Convert time to appropriate format
    time.QuadPart = ticks * 10000;

    fileTime.dwLowDateTime = time.LowPart;
    fileTime.dwHighDateTime = time.HighPart;

    rc = KFileTimeToSystemTime(&fileTime, pTime);

	INTERRUPTS_ENABLE(bInterruptsEnabled);

    OALMSG(OAL_RTC&&OAL_FUNC, (
        L"-OEMGetRealTime(rc = %d %d/%d/%d %d:%d:%d.%03d)\r\n", rc, 
        pTime->wYear, pTime->wMonth, pTime->wDay, pTime->wHour, pTime->wMinute,
        pTime->wSecond, pTime->wMilliseconds
    ));
    return rc;
}

//-----------------------------------------------------------------------------
//! \fn       BOOL OEMSetRealTime(SYSTEMTIME *pTime)
//!
//!	\brief This function is called by the kernel to set the real-time clock.
//!
//!	\param pTime Pointer to time to set in the real-time clock
//!
//!	\return   TRUE indicates success
//!	\return   FALSE indicates failure
//-----------------------------------------------------------------------------
BOOL OEMSetRealTime(SYSTEMTIME *pTime)
{
    BOOL rc = FALSE;
    ULARGE_INTEGER time;
    FILETIME fileTime;
	BOOL bInterruptsEnabled;
	DEBUGMSG(1, (_T("OEMSetRealTime-------------------\r\n")));

    OALMSG(OAL_RTC&&OAL_FUNC, (
        L"+OEMSetRealTime(%d/%d/%d %d:%d:%d.%03d)\r\n", 
        pTime->wYear, pTime->wMonth, pTime->wDay, pTime->wHour, pTime->wMinute,
        pTime->wSecond, pTime->wMilliseconds
    ));

	bInterruptsEnabled = INTERRUPTS_ENABLE(FALSE);	

    if (!KSystemTimeToFileTime(pTime, &fileTime)) goto cleanUp;

    // Convert time to miliseconds since Jan 1, 1601
    time.LowPart = fileTime.dwLowDateTime;
    time.HighPart = fileTime.dwHighDateTime;
    time.QuadPart /= 10000;

	
    
	//store the time in the general purpose backup register
	g_pGeneralPurPoseBackupRegister[0] = (DWORD) (time.LowPart);
	g_pGeneralPurPoseBackupRegister[1] = (DWORD) (time.HighPart);
	//store a verification number
	g_pGeneralPurPoseBackupRegister[2] = ~((DWORD) (time.LowPart) ^ (DWORD) (time.HighPart));
	
	
	//restart the RTT
	pRTT->RTTC_RTMR = AT91C_RTTC_RTTRST | RTCProcSpecificGetRTTPeriod();
	
	RETAILMSG(1,(TEXT("setrealtime %u \r\n"),time));
	
	INTERRUPTS_ENABLE(bInterruptsEnabled);

    rc = TRUE;
    
cleanUp:
    OALMSG(OAL_RTC&&OAL_FUNC, (L"-OEMSetRealTime(rc = %d)\r\n", rc));
    return rc;
}

//-----------------------------------------------------------------------------
//! \fn BOOL OEMSetAlarmTime(SYSTEMTIME *pTime)
//!
//!	\brief This function is called by the kernel to set the real-time clock alarm.
//!
//!	\param pTime Pointer to alarm time
//!
//!	\return   TRUE indicates success
//!	\return   FALSE indicates failure
//-----------------------------------------------------------------------------
BOOL OEMSetAlarmTime(SYSTEMTIME *pTime)
{
    BOOL rc = FALSE;
    /*
	ULARGE_INTEGER time;
    FILETIME fileTime;
    BOOL enabled;
*/

	DEBUGMSG(1, (_T("OEMSetAlarmTime----------- NOT SUPPORTED !!--------\r\n")));

    OALMSG(OAL_RTC&&OAL_FUNC, (
        L"+OEMSetAlarmTime(%d/%d/%d %d:%d:%d.%03d)\r\n", 
        pTime->wYear, pTime->wMonth, pTime->wDay, pTime->wHour, pTime->wMinute,
        pTime->wSecond, pTime->wMilliseconds
    ));
/*

    // Convert time to miliseconds since Jan 1, 1601
    if (!KSystemTimeToFileTime(pTime, &fileTime)) goto cleanUp;
    time.LowPart = fileTime.dwLowDateTime;
    time.HighPart = fileTime.dwHighDateTime;
    time.QuadPart /= 10000;

    enabled = INTERRUPTS_ENABLE(FALSE);
	g_oalRTCAlarm = time.QuadPart - g_oalRTCTicks;
    INTERRUPTS_ENABLE(enabled);

    // We are done
    rc = TRUE;
      
cleanUp:
    OALMSG(OAL_RTC&&OAL_FUNC, (L"-OEMSetAlarmTime(rc = %d)\r\n", rc));
    return rc;*/
	
	return rc;
}


#else // RTC_IS_BASED_ON_RTT
//------------------------------------------------------------------------------
//
//  Global: g_oalRTCTicks/g_pOALRTCTicks
//
//  This variable in increment by one in timer interrupt handler. It contains
//  relative time in miliseconds since January 1, 1601.
//
UINT64 g_oalRTCTicks = 12685896000000;

//------------------------------------------------------------------------------
//
//  Global: g_oalRTCAlarm
//
//  This variable contains number of miliseconds till next SYSINTR_ALARM. It
//  is zero when alarm isn't active.
//
UINT64 g_oalRTCAlarm = 0;



//-----------------------------------------------------------------------------
//! \fn void UpdateTimer()
//!
//!	\brief    This function updates actual time, updates timer using SC_GetTickCount
//!			Each time you can try to call this function
//! 
//!
//! 
//!
//-----------------------------------------------------------------------------
void UpdateTimer()
{
	BOOL	enabled = FALSE;
	static	DWORD dwOldTime = 0;
	static	DWORD dwActualTime = 0;
	int		i=0;

	if (dwOldTime==0 && dwActualTime==0)
	{
		dwOldTime = CurMSec;
		for (;i<100000;i++);
	}

//	DEBUGMSG( 1,(TEXT("UpdateTimer, seconds from start:%d\n\r"), CurMSec/1000));

	dwActualTime = CurMSec;

    enabled = INTERRUPTS_ENABLE(FALSE);
	g_oalRTCTicks += dwActualTime - dwOldTime;
    INTERRUPTS_ENABLE(enabled);

	dwOldTime = dwActualTime;
}

//-----------------------------------------------------------------------------
//! \fn		BOOL OALIoCtlHalInitRTC(UINT32 code, void* pInpBuffer, UINT32 inpSize, void* pOutBuffer, UINT32 outSize, UINT32* pOutSize)
//!
//! \brief		This function implements the IOCTL_HAL_INITRTC IOControl
//!				This function is called by WinCE OS to initialize the time after boot.
//!				Input buffer contains SYSTEMTIME structure with default time value.
//!				If hardware has persistent real time clock it will ignore this value
//!				(or all call).
//!
//!	\param		code		not used
//!	\param		pInpBuffer	Initial time
//!	\param		inpSize		sizeof(SYSTEMTIME)
//!	\param		pOutBuffer	not used
//!	\param		outSize		not used
//!	\param		pOutSize	not used
//!
//! \return		TRUE indicates success
//! \return		FALSE indicates failure (bad parameters)
//-----------------------------------------------------------------------------
BOOL OALIoCtlHalInitRTC(UINT32 code, void* pInpBuffer, UINT32 inpSize, void* pOutBuffer, UINT32 outSize, UINT32* pOutSize)
{
    BOOL rc = FALSE;
    SYSTEMTIME *pTime = (SYSTEMTIME*)pInpBuffer;

	RETAILMSG(1, (L"+OALIoCtlHalInitRTC(...)\r\n"));
    OALMSG(OAL_IOCTL&&OAL_FUNC, (L"+OALIoCtlHalInitRTC(...)\r\n"));

	// Update timer value
	UpdateTimer();

    // Validate inputs
    if (pInpBuffer == NULL || inpSize < sizeof(SYSTEMTIME)) {
        NKSetLastError(ERROR_INVALID_PARAMETER);
        OALMSG(OAL_ERROR, (
            L"ERROR: OALIoCtlHalInitRTC: Invalid parameter\r\n"
        ));
        
    }
	else
	{
		rc = OEMSetRealTime(pTime);
	}   
    OALMSG(OAL_IOCTL&&OAL_FUNC, (L"-OALIoCtlHalInitRTC(rc = %d)\r\n", rc));
	RETAILMSG(1, (L"-OALIoCtlHalInitRTC(rc = %d)\r\n", rc));
    return rc;
}

//-----------------------------------------------------------------------------
//! \fn BOOL OEMGetRealTime(SYSTEMTIME *pTime)
//!
//!	\brief This function is called by the kernel to retrieve the time from the real-time clock.
//!
//!	\param pTime Pointer to return current time from the real-time clock
//!
//! \return		TRUE indicates success
//! \return		FALSE indicates failure
//-----------------------------------------------------------------------------
BOOL OEMGetRealTime(SYSTEMTIME *pTime)
{
    BOOL rc;
    ULARGE_INTEGER time;
    FILETIME fileTime;
    UINT64 ticks;
    BOOL enabled;

    OALMSG(OAL_RTC&&OAL_FUNC, (L"+OEMGetRealTime\r\n"));

	UpdateTimer();

    enabled = INTERRUPTS_ENABLE(FALSE);
	ticks = g_oalRTCTicks;
    INTERRUPTS_ENABLE(enabled);

    // Convert time to appropriate format
    time.QuadPart = ticks * 10000;

    fileTime.dwLowDateTime = time.LowPart;
    fileTime.dwHighDateTime = time.HighPart;

    rc = KFileTimeToSystemTime(&fileTime, pTime);

    OALMSG(OAL_RTC&&OAL_FUNC, (
        L"-OEMGetRealTime(rc = %d %d/%d/%d %d:%d:%d.%03d)\r\n", rc, 
        pTime->wYear, pTime->wMonth, pTime->wDay, pTime->wHour, pTime->wMinute,
        pTime->wSecond, pTime->wMilliseconds
    ));
    return rc;
}


//-----------------------------------------------------------------------------
//! \fn       BOOL OEMSetRealTime(SYSTEMTIME *pTime)
//!
//!	\brief This function is called by the kernel to set the real-time clock.
//!
//!	\param pTime Pointer to time to set in the real-time clock
//!
//! \return		TRUE indicates success
//! \return		FALSE indicates failure
//-----------------------------------------------------------------------------
BOOL OEMSetRealTime(SYSTEMTIME *pTime)
{
    BOOL rc = FALSE;
    ULARGE_INTEGER time;
    FILETIME fileTime;
    BOOL enabled;

	DEBUGMSG(1, (_T("OEMSetRealTime-------------------\r\n")));

    OALMSG(OAL_RTC&&OAL_FUNC, (
        L"+OEMSetRealTime(%d/%d/%d %d:%d:%d.%03d)\r\n", 
        pTime->wYear, pTime->wMonth, pTime->wDay, pTime->wHour, pTime->wMinute,
        pTime->wSecond, pTime->wMilliseconds
    ));

	UpdateTimer();

    if (!KSystemTimeToFileTime(pTime, &fileTime))
	{
		// Convert time to miliseconds since Jan 1, 1601
		time.LowPart = fileTime.dwLowDateTime;
		time.HighPart = fileTime.dwHighDateTime;
		time.QuadPart /= 10000;

		enabled = INTERRUPTS_ENABLE(FALSE);

		g_oalRTCTicks = time.QuadPart;

		INTERRUPTS_ENABLE(enabled);
    
		rc = TRUE;
	}
    OALMSG(OAL_RTC&&OAL_FUNC, (L"-OEMSetRealTime(rc = %d)\r\n", rc));
    return rc;
}

//-----------------------------------------------------------------------------
//! \fn BOOL OEMSetAlarmTime(SYSTEMTIME *pTime)
//!
//!	\brief This function is called by the kernel to set the real-time clock alarm.
//!
//!	\param pTime Pointer to alarm time
//!
//! \return		TRUE indicates success
//! \return		FALSE indicates failure
//-----------------------------------------------------------------------------
BOOL OEMSetAlarmTime(SYSTEMTIME *pTime)
{
    BOOL rc = FALSE;
    ULARGE_INTEGER time;
    FILETIME fileTime;
    BOOL enabled;

	DEBUGMSG(1, (_T("OEMSetAlarmTime-------------------\r\n")));

    OALMSG(OAL_RTC&&OAL_FUNC, (
        L"+OEMSetAlarmTime(%d/%d/%d %d:%d:%d.%03d)\r\n", 
        pTime->wYear, pTime->wMonth, pTime->wDay, pTime->wHour, pTime->wMinute,
        pTime->wSecond, pTime->wMilliseconds
    ));

	UpdateTimer();

    // Convert time to miliseconds since Jan 1, 1601
    if (!KSystemTimeToFileTime(pTime, &fileTime))
	{
		time.LowPart = fileTime.dwLowDateTime;
		time.HighPart = fileTime.dwHighDateTime;
		time.QuadPart /= 10000;

		enabled = INTERRUPTS_ENABLE(FALSE);
		g_oalRTCAlarm = time.QuadPart - g_oalRTCTicks;
		INTERRUPTS_ENABLE(enabled);

		// We are done
		rc = TRUE;
	}
      
    OALMSG(OAL_RTC&&OAL_FUNC, (L"-OEMSetAlarmTime(rc = %d)\r\n", rc));
    return rc;
}
#endif

//! @} end of subgroup RTC

//! @} end of group OAL

////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/RTC/rtc.c $
////////////////////////////////////////////////////////////////////////////////
//
