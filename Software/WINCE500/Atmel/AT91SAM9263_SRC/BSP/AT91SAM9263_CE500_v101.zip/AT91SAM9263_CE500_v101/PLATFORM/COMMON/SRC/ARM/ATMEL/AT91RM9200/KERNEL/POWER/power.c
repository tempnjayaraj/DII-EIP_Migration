//-----------------------------------------------------------------------------
//! \addtogroup   OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file			power.c
//!
//! \brief			AT91RM9200's power-related (suspend-related) features
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/KERNEL/POWER/power.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

#include <windows.h>
#include <nkintr.h>
#include <oal.h>
#include "AT91RM9200_oal_intr.h"
#include "at91RM9200_interface.h"

//-----------------------------------------------------------------------------
//! \fn			DWORD OEMPowerManagerInit(void)
//!
//! \brief		This function handles the initialization routines used by the kernel's suspend code
//!
//! \return		0
//!
//! 
//-----------------------------------------------------------------------------
DWORD OEMPowerManagerInit(void)
{
    DWORD sysIntr;

    RETAILMSG(1,(TEXT("+OEMPowerManagerInit\r\n")));
    //Clear the wakeup sources' list
    for (sysIntr = SYSINTR_FIRMWARE; sysIntr < SYSINTR_MAXIMUM; sysIntr++) 
    {		
        OALIoCtlHalDisableWake(0,&sysIntr,sizeof(sysIntr),0,0,0);
    }	
	RETAILMSG(1,(TEXT("-OEMPowerManagerInit\r\n")));
	return 0;
}


extern UINT64 GetAndUpdateRTCValue(BOOL);

//-----------------------------------------------------------------------------
//! \fn			void OEMPowerOff()
//!
//! \brief		Called when the system is to transition to it's lowest power mode (off)
//!				TODO : Specific functions is not implemented and not called yet
//! 
//-----------------------------------------------------------------------------
void OEMPowerOff()
{     
	DWORD sysIntr;
	
	INTERRUPTS_OFF();
    
    // First do platform specific actions TODO
   // BSPPowerOff();
  
    // Switch off power for KITL device TODO
    //OALKitlPowerOff();
    
    
    //This takes care of saving the AIC and PIOs interrupt mask and disable every interrupt
    SOCSaveAndDisableAllIntrBeforeSuspend();

    //Enable wake-up sources interrupts
    for (sysIntr = SYSINTR_FIRMWARE; sysIntr < SYSINTR_MAXIMUM; sysIntr++) {
        // Skip if sysIntr isn't allowed as wake source
        if (OALPowerWakeSource(sysIntr))
        {
            // Enable it as interrupt
            OEMInterruptEnable(sysIntr, NULL, 0);
        }        
    }
    
    
    // Go to power off mode
    OALCPUPowerOff();

    //This takes care of restoring the AIC and PIOs interrupt mask
    SOCRestoreAllIntrAfterSuspend();

    // Switch on power for KITL device TODO
    //OALKitlPowerOn();  
    
    // Complete platform specific actions TODO
    //BSPPowerOn();    
    
    INTERRUPTS_ON();
}

extern void AT91RM9200_LowPowerMode(void);

//-----------------------------------------------------------------------------
//! \fn			void OALCPUPowerOff()
//!
//! \brief		Called to stopp the processor execution
//! 
//-----------------------------------------------------------------------------
void OALCPUPowerOff()
{
    extern volatile UINT32 g_oalLastSysIntr;
    INTERRUPTS_ON();
    
	do
    {
        
#ifdef FAKE_IDLE    
        // Wait until interrupt handler set interrupt flag
        while (g_oalLastSysIntr == SYSINTR_NOP);
#else
        while (g_oalLastSysIntr == SYSINTR_NOP)
		{
			AT91RM9200_TurnProcessorClockOff();
//			AT91RM9200_LowPowerMode();
		}
#endif  
        OEMInterruptDone(g_oalLastSysIntr);

    } while (OALPowerWakeSource(g_oalLastSysIntr) == FALSE);    

    INTERRUPTS_OFF();
    g_oalWakeSource = g_oalLastSysIntr;
}

    
//-----------------------------------------------------------------------------
//! \fn		BOOL OALIoCtlHalPresuspend(	UINT32 code, VOID *pInpBuffer, 
//!								UINT32 inpSize, VOID *pOutBuffer, 
//!								UINT32 outSize, UINT32 *pOutSize)
//!
//! \brief		This function implements the IOCTL_HAL_SUSPEND IOControl
//!				Suspend is not implemented yet
//!
//!	\param		code		not used
//!	\param		pInpBuffer	not used
//!	\param		inpSize		not used
//!	\param		pOutBuffer	not used
//!	\param		outSize		not used
//!	\param		pOutSize	not used
//!
//! \return		TRUE indicates success
//! \return		FALSE indicates failure (bad parameters)
//!
//! 
//-----------------------------------------------------------------------------
BOOL OALIoCtlHalPresuspend(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer, 
    UINT32 outSize, UINT32 *pOutSize
) {
    return TRUE;
}


//! @}

