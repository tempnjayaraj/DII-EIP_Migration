//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//-----------------------------------------------------------------------------
//! \file		menu.c 
//!
//! \brief		Display eboot menu
//!
//! \if subversion
///   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/GenericEBOOT/menu.c $
//!   $Author: ltourlonias $
//!   $Revision: 985 $
//!   $Date: 2007-06-12 09:30:21 +0200 (mar., 12 juin 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	EBOOT
//! @{
//!


//------------------------------------------------------------------------------
//                                                                      Includes
//------------------------------------------------------------------------------

// Standard includes
#include <windows.h>
#include <nkintr.h>
#include <oal_memory.h>
#include <oal.h>

// Local includes
#include "bootloader_struct.h"
#include "eboot_msg.h"
#include "eboot_cfg.h"
#include "key_code.h"

//------------------------------------------------------------------------------
//                                                            Imported functions
//------------------------------------------------------------------------------

extern DWORD			EBOOT_GetCurrentSec(void);
extern UCHAR*			macAddr_toa(UCHAR* pMacAddress);
extern unsigned int		AsciiToHex(char *s, unsigned int *val);

extern BOOL				EBOOT_InitFlash(DWORD dwAddress);
extern BOOL				EBOOT_ReadFlash(DWORD dwAddressDst, DWORD dwAddressSrc, DWORD dwLen);
extern BOOL				EBOOT_WriteFlash(DWORD dwAddressDst, DWORD dwAddressSrc, DWORD dwLen);
extern BOOL				EBOOT_EraseFlash(DWORD dwAddress, DWORD dwLen);
extern BOOL				EBOOT_EraseAllFlash(DWORD dwAddress);
extern int				EBOOT_ReadDebugByte(void);

extern DWORD			EBOOT_GetFlashImageLogicalAddress(void);

//------------------------------------------------------------------------------
//                                                            Internal functions
//------------------------------------------------------------------------------

static void  DisplayNandFlashMenu(EBOOT_CFG * pEbootCFG);
static void  GetParameters(DWORD* pImageStart,DWORD* pImageLaunch,DWORD* pImageLength);
static DWORD WaitForDWORD();

//------------------------------------------------------------------------------
//                                                            Exported functions
//------------------------------------------------------------------------------




BYTE EBOOT_DisplayPreMenu(EBOOT_CFG * pEbootCFG)
{
	DWORD i;
	DWORD dwStartTime = 0;
	DWORD dwCurrentTime = 0;
	DWORD dwTime = pEbootCFG->delaySec;
	DWORD dwTimeElapsed = 0;
	BYTE  selection;
	BOOL  bContinue = TRUE;

	dwStartTime = EBOOT_GetCurrentSec();

	// If no boot delay, 
	if (pEbootCFG->delaySec == 0)
	{
		selection = EBOOT_ReadDebugByte();
		if (selection != KEY_SPACE)
		{
			selection = KEY_ENTER;
		}
	}
	else	// If boot delay not equals to 0
	{
		if (pEbootCFG->autoDownloadImage == TRUE)
		{
			RETAILMSG (1,(EMSG_CRLF));
			RETAILMSG (1,(EMSG_DOWNLOAD_NOW_OR_CANCEL));
			RETAILMSG (1,(EMSG_CRLF));
			RETAILMSG (1,(L"Initiating image download in %3d seconds", dwTime));
		}
		else
		{
			RETAILMSG (1,(EMSG_CRLF));
			RETAILMSG (1,(EMSG_LAUNCH_NOW_OR_CANCEL));
			RETAILMSG (1,(EMSG_CRLF));
			RETAILMSG (1,(L"Initiating image launch in %3d seconds ", dwTime));
		}

		while(bContinue == TRUE)
		{
			dwCurrentTime = EBOOT_GetCurrentSec();

			selection = EBOOT_ReadDebugByte(); 
			if ((selection == KEY_ENTER) || (selection == KEY_SPACE))
			{
				bContinue = FALSE;
			}

			if ((dwCurrentTime-dwStartTime) != dwTimeElapsed)
			{
				dwTimeElapsed = (dwCurrentTime-dwStartTime);
				
				if (dwTime == 0)
				{
					// Like if user want download or launch now
					selection = KEY_ENTER;
					bContinue = FALSE;
				}
				else
				{
					dwTime--;

					// Erase old second counter
					for (i=0;i<11;i++)
					{
						OEMWriteDebugByte((BYTE)0x08); // print back space
					}
					RETAILMSG (1,( L"%3d seconds", dwTime));
				}
			}
		}
	}
	RETAILMSG (1,( EMSG_CRLF ));

	return selection;
}


BYTE EBOOT_DisplayMenu(EBOOT_CFG * pEbootCFG)
{
	BYTE  selection = NO_KEY;
	BOOL  bInvalidChoice = FALSE;
	BOOL  bStartNow = FALSE;
	BOOL  bSaveToFlash = FALSE;

	do
	{
		RETAILMSG (1,(EMSG_CRLF));
		RETAILMSG (1,(EMSG_EBOOTCONFIG_HEADER));
		RETAILMSG (1,(EMSG_CRLF));
		RETAILMSG (1,(EMSG_CRLF));

		RETAILMSG (1,(L"%c) Mac address .......... (%S)\r\n"						, KEY_0, macAddr_toa(pEbootCFG->macAddress)));
		RETAILMSG (1,(L"%c) Ip address ........... (%S)\r\n"						, KEY_1, inet_ntoa(pEbootCFG->ipAddress)));
		RETAILMSG (1,(L"%c) Subnet Mask address .. (%S)\r\n"						, KEY_2, inet_ntoa(pEbootCFG->subnetMask)));
		RETAILMSG (1,(L"%c) DHCP ................. (%S)\r\n"						, KEY_3, (pEbootCFG->dhcpEnable == TRUE?"Enabled":"Disabled")));
		RETAILMSG (1,(L"%c) Boot delay (seconds).. (%d)\r\n"						, KEY_4, pEbootCFG->delaySec));
		RETAILMSG (1,(L"%c) Frequency settings ... (core at %d, bus divider %d)\r\n", KEY_5, pEbootCFG->dwCoreFrequency,pEbootCFG->dwBusFreqDivider));
		RETAILMSG (1,(L"%c) Download image to %S\r\n"								, KEY_6, pEbootCFG->bImgToFlash?"Flash":"SDRAM"));
		RETAILMSG (1,(L"%c) %S image at startup\r\n"								, KEY_7, pEbootCFG->autoDownloadImage?"Download new":"Launch existing flash resident"));
		RETAILMSG (1,(EMSG_CRLF));
		RETAILMSG (1,(L"%c) Launch flash resident image now\r\n"					, KEY_L));
		RETAILMSG (1,(L"%c) Download from ethernet now\r\n"							, KEY_D));
		RETAILMSG (1,(L"%c) Save configuration now\r\n"								, KEY_S));
		RETAILMSG (1,(L"%c) Restore default configuration and save now\r\n"			, KEY_R));
		RETAILMSG (1,(L"%c) Image flash menu\r\n"									, KEY_N));
		RETAILMSG (1,(L">"));
		
		do
		{
			bInvalidChoice = FALSE;

			// Read key hit on serial debug interface
			selection = EBOOT_ReadDebugByte();

			switch (selection)
			{
			case KEY_0:	// Mac address
				EBOOT_SetMacAddress(pEbootCFG);
				bSaveToFlash = TRUE;
				break;
			case KEY_1:	// Ip Address
				EBOOT_SetIP(pEbootCFG);
				bSaveToFlash = TRUE;
				break;
			case KEY_2:	// Subnet mask
				EBOOT_SetMask(pEbootCFG);
				bSaveToFlash = TRUE;
				break;
			case KEY_3: // DHCP state
				EBOOT_InvertDhcpState(pEbootCFG);
				bSaveToFlash = TRUE;
				break;
			case KEY_4: // Boot delay
				EBOOT_SetDelay(pEbootCFG);
				bSaveToFlash = TRUE;
				break;
			case KEY_5: // Frequency
				EBOOT_SetFrequency(pEbootCFG);
				bSaveToFlash = TRUE;
				break;
			case KEY_6: // Download destiniation
				EBOOT_InvertDownloadImgToFlash(pEbootCFG);
				bSaveToFlash = TRUE;
				break;
			case KEY_7: // Download or launch at startup
				EBOOT_InvertAutoDownloadState(pEbootCFG);
				bSaveToFlash = TRUE;
				break;
			case KEY_L:
				bStartNow = TRUE;
				break;
			case KEY_D:
				bStartNow = TRUE;
				break;
			case KEY_S: // Save configuration
				EBOOT_SaveConfigToFlash(pEbootCFG);
				bSaveToFlash = FALSE;
				break;
			case KEY_R:	// Restore default configuration and save
				EBOOT_SetDefaultEBootCFG(pEbootCFG);
				EBOOT_SaveConfigToFlash(pEbootCFG);
				break;
			case KEY_N:
				DisplayNandFlashMenu(pEbootCFG);
				bSaveToFlash = TRUE;
				break;
			default:

				bInvalidChoice = TRUE;
			}
		}
		while (bInvalidChoice == TRUE);

	}
	while (bStartNow == FALSE);

	// If configuration change, save it
	if (bSaveToFlash == TRUE)
	{
		EBOOT_SaveConfigToFlash(pEbootCFG);
	}

	return selection;
}


//-----------------------------------------------------------------------------
//! \fn			static void DisplayNandFlashMenu(EBOOT_CFG * pEbootCFG)
//!
//! \param  pEbootCFG
//!
//! \brief		Display the nand Flash menu in eboot
//!
//-----------------------------------------------------------------------------
static void DisplayNandFlashMenu(EBOOT_CFG * pEbootCFG)
{
	BOOL		bDoLoop1 = TRUE;
	UINT32		Selection;
    int			Address;	

	// Init the NandFlash Memory
	if (EBOOT_InitFlash(pEbootCFG->imgBootDesc.dwFlashLogicalAddress) == FALSE)
	{
		RETAILMSG(1,(L"Error on image flash initialization"));
		RETAILMSG (1,(EMSG_CRLF));
	}

	while (bDoLoop1)
    {
		Selection = 0;
		Address = 0;

        // Show menu
        RETAILMSG(1,(L"\r\nImage Flash Menu :\r\n"));				
		RETAILMSG(1,(L"1) Erase all sectors \r\n"));
		RETAILMSG(1,(L"2) Enter manually the image parameters\r\n"));
		RETAILMSG(1,(L"3) Quit...\r\n"));
		RETAILMSG(1,(L">"));

        while (!((Selection >= '1') && (Selection <= '3')))
        {
            Selection = EBOOT_ReadDebugByte();
        }
		EdbgOutputDebugString ( "%c\r\n", Selection);

		switch (Selection)
        {
			case '1':	// erase the chip without testing the spares
				EBOOT_EraseAllFlash(pEbootCFG->imgBootDesc.dwFlashLogicalAddress);
				break;
			case'2':
				{					
					DWORD dwStart,dwLength,dwLaunch;

					dwLength = pEbootCFG->imgBootDesc.dwPhysLen;
					dwStart =  pEbootCFG->imgBootDesc.dwPhysStart;
					dwLaunch = pEbootCFG->imgBootDesc.dwLaunchAddr;
					
					GetParameters(&dwStart,&dwLaunch,&dwLength);					
					
					if (dwLength != pEbootCFG->imgBootDesc.dwPhysLen	||
						dwStart  != pEbootCFG->imgBootDesc.dwPhysStart  ||
						dwLaunch != pEbootCFG->imgBootDesc.dwLaunchAddr )					
					{
						pEbootCFG->imgBootDesc.dwPhysLen			 = dwLength;
						pEbootCFG->imgBootDesc.dwPhysStart			 = dwStart;
						pEbootCFG->imgBootDesc.dwLaunchAddr			 = dwLaunch;
						pEbootCFG->imgBootDesc.dwFlashLogicalAddress = EBOOT_GetFlashImageLogicalAddress();
						EBOOT_SaveConfigToFlash(pEbootCFG);
						RETAILMSG(1,(L"New Image parameters : Start 0x%x Entry 0x%x Length 0x%x\r\n",pEbootCFG->imgBootDesc.dwPhysStart,pEbootCFG->imgBootDesc.dwLaunchAddr,pEbootCFG->imgBootDesc.dwPhysLen));
					}
				}
				break;
	
			case '3':
				bDoLoop1	= FALSE;
				break;

			default:

				break;
		}
	}
}

void GetParameters(DWORD* pImageStart,DWORD* pImageLaunch,DWORD* pImageLength)
{
	DWORD dwTemp;
	RETAILMSG(1,(TEXT("Enter the information found in the build report of the 'Make Image'. [entering 0 keeps present value]\r\n")));
	RETAILMSG(1,(TEXT("Physical Start Address : (0x%x) : 0x"),*pImageStart));
	dwTemp = WaitForDWORD();
	if (dwTemp)
	{
		*pImageStart = dwTemp;
	}
	RETAILMSG(1,(TEXT("\r\n")));

	RETAILMSG(1,(TEXT("Starting ip : (0x%x) : 0x"),*pImageLaunch));
	dwTemp = WaitForDWORD();
	if (dwTemp)
	{
		*pImageLaunch = dwTemp;
	}
	RETAILMSG(1,(TEXT("\r\n")));

	RETAILMSG(1,(TEXT("Total ROM size : (0x%x) : 0x"),*pImageLength));	
	dwTemp = WaitForDWORD();
	if (dwTemp)
	{
		*pImageLength = dwTemp;
	}	
	RETAILMSG(1,(TEXT("\r\n")));	
}

DWORD WaitForDWORD(void)
{
	char tempo[10];
	DWORD dwResult;
	char Selection;
	int index = 0;

	do 
	{
		do 
		{
			Selection = EBOOT_ReadDebugByte();
			if ((Selection >= 'A') && (Selection<='F'))
			{
				Selection = Selection - 'A' + 'a';
			}
		} while (!(((Selection>='0') && (Selection<='9')) || ((Selection>='a') && (Selection<='f')) || (Selection == 8) || (Selection == '\r')));
		
		if (Selection == '\r')
		{
			break;
		}

		if (Selection != 8)
		{
			if (index<8)
			{
				tempo[index++] = Selection;
				OEMWriteDebugByte(Selection);
			}
		}
		else
		{
			if (index>0)
			{
				index--;
				OEMWriteDebugByte(8);
				OEMWriteDebugByte(' ');
				OEMWriteDebugByte(8);
			}
		}
		
	} while (1);
	tempo[index]=0;
	AsciiToHex(tempo,&dwResult);
	return dwResult;
}


//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/GenericEBOOT/menu.c $
//------------------------------------------------------------------------------

//
//! @}
//
//! @}

//
