//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x_ioctl_tab.h
//!
//! \brief		some of the ioctl supported by the kernel
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/AT91SAM926x_ioctl_tab.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//-----------------------------------------------------------------------------


#ifndef AT91SAM926X_H
#define AT91SAM926X_H

#if   defined   PROC_AT91SAM9260
#include "AT91SAM9260_oal_ioctl_tab.h"
#elif   defined   PROC_AT91SAM9261
#include "AT91SAM9261_oal_ioctl_tab.h"
#elif defined   PROC_AT91SAM9262
#include "AT91SAM9262_oal_ioctl_tab.h"
#elif defined   PROC_AT91SAM9263
#include "AT91SAM9263_oal_ioctl_tab.h"
#else
#error A Processor must be defined
#endif



#ifdef OAL_ILTIMING
	{ IOCTL_HAL_ILTIMING,                       0,	OALIoCtlHalILTiming         },
#endif
	{ IOCTL_HAL_INIT_RTC,                       0,	OALIoCtlHalInitRTC          },
	{ IOCTL_HAL_SHUTDOWN,                       0,	OALIoCtlHalShutdown         },
	{ IOCTL_HAL_MASTERCLOCK,                    0,	OALIoCtlHalGetMasterClock   },
	{ IOCTL_HAL_PLLACLOCK,						0,	OALIoCtlHalGetPLLAClock   },
	{ IOCTL_HAL_PLLBCLOCK,						0,	OALIoCtlHalGetPLLBClock   },
	{ IOCTL_HAL_PROCESSORCLOCK,                 0,	OALIoCtlHalGetProcessorClock   },
	{ IOCTL_HAL_PRESUSPEND,                     0,  OALIoCtlHalPresuspend      },
	{ IOCTL_PROCESSOR_INFORMATION,              0,  OALIoCtlProcessorInfo },
	{ IOCTL_HAL_GET_KITL_ARGS,					0,	OALIoCtlHalGetKitlArgs},





#endif //AT91SAM926X_H

//! @}


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/AT91SAM926x_ioctl_tab.h $
////////////////////////////////////////////////////////////////////////////////
//
