//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//  All rights reserved ADENEO SAS 2005
//
//! \file		EmacbNDIS.cpp
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/EmacbNDIS/EmacbNDIS.cpp $
//!   $Author: pgal $
//!   $Revision: 932 $
//!   $Date: 2007-06-04 14:28:50 +0200 (lun., 04 juin 2007) $
//! \endif
//		TODO
//
//-----------------------------------------------------------------------------
// EmacbNDIS.cpp : Defines the entry point for the DLL application.
//
//! \addtogroup	EMAC
//! @{
//
//! \addtogroup EMACBNDIS
//! @{

#include <windows.h>

// Controller includes
#include "at91sam926x.h"

// Driver includes
#include "at91sam9263ek_emacbndis.h"


//------------------------------------------------------------------------------
//! \fn BOOL DllEntry(HANDLE hInstDll, DWORD dwOp, LPVOID lpvReserved)
//! \brief Dll entry point for emacb NDIS driver.
//!
//! \return Entry status (TRUE if success, FALSE else)
//------------------------------------------------------------------------------
BOOL DllEntry(
    HANDLE    hInstDll,
    DWORD     dwOp,
    LPVOID    lpvReserved)
{
    switch (dwOp)
    {
        case DLL_PROCESS_ATTACH:
          DisableThreadLibraryCalls ((HMODULE)hInstDll);
          break;

        case DLL_PROCESS_DETACH:
        default:
            break;
    }

    return (TRUE); 
}

/*******************************************************************
 *
 * Device Entry
 *
 *******************************************************************/

//------------------------------------------------------------------------------
//! \fn NIC_DEVICE_OBJECT * DeviceEntry(NIC_DRIVER_OBJECT *pDriverObject, PVOID pVoid)
//! \brief Driver entry point
//!
//! \return New EmacbNDIS object
//------------------------------------------------------------------------------
extern "C" NIC_DEVICE_OBJECT	*DeviceEntry(
	NIC_DRIVER_OBJECT	*pDriverObject,
	PVOID				pVoid)
{
	return new C_SAM9263EK_EMACBNDIS(pDriverObject,pVoid);
}
//! @}
//! @}
//! @}
