//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		pio_intr.h
//!
//! \brief		PIO Interrupt function header file
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/INC/pio_intr.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//!
//-----------------------------------------------------------------------------

typedef struct {
	AT91PS_PIO pBase;
	DWORD nbPin; //Not every PIO controller support the same number of pin.
	DWORD currentPin;//This is used to maintain a round robin priority system within the same PIO bank
	DWORD status; // this is use to maintain the value of PIO_ISR because it's cleared after each reading
	DWORD logintrBase; //This is the logintr associated with pin 0 of the bank
	DWORD deviceID; //this is to configure the AIC
	AT91PS_PIO vPioBase;
	DWORD resumeMask;
} PIOBANKDESCRIPTION;

extern const DWORD oal_pio_bank_number;
extern PIOBANKDESCRIPTION g_PioBankDescTab[];
extern DWORD g_dwOalPioBankNumber;


DWORD SOCIntrActiveIrq(DWORD nIrq);
void SOCPioIntrInit();
BOOL SOCDisablePioIrq(DWORD logintr, BOOL* pOldState);
BOOL SOCEnablePioIrq(DWORD logintr);
void SOCPioRestoreAllIntrAfterSuspend();
void SOCPioSaveAndDisableAllIntrBeforeSuspend();
void SOCPioControllerIntrEnable();



//! @}

