//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		wavepdd.c
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/DRIVERS/WAVEDEV/wavepdd.c $
//!   $Author: ltourlonias $
//!   $Revision: 978 $
//!   $Date: 2007-06-11 10:34:14 +0200 (lun., 11 juin 2007) $
//! \endif
//!
//! Implementation of the generic part of the WAVDEV driver PDD.
//!
//! \note shadowed registers are not yet implemented
//!
//-----------------------------------------------------------------------------
//! \addtogroup	WAVEDEV
//! @{
//!

#include <windows.h>
#include <types.h>
#include <memory.h>
#include <excpt.h>
#include <wavepdd.h>
#include <waveddsi.h>
#include <wavedbg.h>
#include <nkintr.h>
#include <ceddk.h>
#include <devload.h>
#include <wavedbg.h>
#include "aclink.h"
#include "AC97.H"
#include "at91sam926x.h"
#include "wavedev_ioctl.h"

//-----------------------------------------------------------------
// MACROS
//-----------------------------------------------------------------

#define BITS_8_TO_16(x)      (short) ( ( (LONG) ( (UINT8)(x) - 128) ) << 8 )
#define BITS_16_TO_8(x)       ( (UINT8) (( (x) >> 8 ) +128))
#define INC_MODULO(x,y) (((x)+1) < (y) ? ((x)+1) : 0)


//-----------------------------------------------------------------
// DEFINES
//-----------------------------------------------------------------

#define LOOPBACK_MASK 0x40
#define RESET_CODEC_MASK 0x04 //bit 2 0 origin

#define  MHZ11_980 11980000
#define  KHZ08_000 8000
#define  KHZ11_025 11025
#define  KHZ12_000 12000
#define  KHZ16_000 16000
#define  KHZ22_050 22050
#define  KHZ24_000 24000
#define  KHZ32_000 32000
#define  KHZ44_100 44100
#define  KHZ48_000 48000



#define NB_XMIT_PAGE 4
#define NB_RCV_PAGE	4
#define NUM_DMA_AUDIO_BUFFERS    (NB_XMIT_PAGE + NB_RCV_PAGE)

#define NUM_API_DIRS          2
#define DEFAULT_CAPTURE_LATENCY	20



//-----------------------------------------------------------------
// LOCAL FUNCTIONS
//-----------------------------------------------------------------
static BOOL        MapDeviceRegisters(void);
static BOOL        UnmapDeviceRegisters(void);
static BOOL        AC97_SetOutVolume(ULONG uVolume);
static short int   AC97SetSampleRate(unsigned short int SampleRate, WAPI_INOUT apidir );
static BOOL        AudioInMute(   BOOL mute   );
static BOOL        AudioOutMute(   BOOL mute   );
static void        AudioPowerOff();
static BOOL        AudioPowerOn();
void        PowerDownUnit(unsigned short int Unit,BOOL ShutDown);
void        private_WaveStandby(WAPI_INOUT apidir);
short int   ShadowReadAC97(BYTE Offset, unsigned short int *Data);
short int   ShadowWriteAC97(BYTE Offset, unsigned short int Data);
BOOL        StopDmac(int);
VOID        private_WaveOutStop();
VOID		private_WaveInStop(PWAVEHDR pwh);



//-----------------------------------------------------------------
// CONSTANTS AND VARIABLES
//-----------------------------------------------------------------
static  DWORD g_dwCodecType=GENERIC_AC97;
static unsigned short int LastSampleRateIn=KHZ48_000;
static unsigned short int LastSampleRateOut=KHZ48_000;

static int sample_rate_out = KHZ44_100;        //define sample rate globally
static int sample_rate_in  = KHZ44_100;        //define sample rate globally

static DWORD g_dwXmitComplete; //Number of byte already played by the codec

VOID (*g_pfnFillBuffer) (PINT16 pDstBuffer, PVOID pSrcBuffer, DWORD dwSamples);
VOID (*g_pfnGetBuffer) (PVOID pDstBuffer, PINT16 pSrcBuffer, DWORD dwSamples);

//! \brief point to the AC97 read function based on the needs for the power handler
BOOL (*g_pfnReadAc97)  (BYTE Offset, UINT16 * Data);
//! \brief point to the AC97 read function based on the needs for the power handler
BOOL (*g_pfnWriteAc97) (BYTE Offset, UINT16 Data);


static VOID FillBufferM08toS16 (PINT16 pDstBuffer, PBYTE pSrcBuffer, DWORD dwSamples);
static VOID FillBufferS08toS16 (PINT16 pDstBuffer, PBYTE pSrcBuffer, DWORD dwSamples);
static VOID FillBufferM16toS16 (PINT16 pDstBuffer, PINT16 pSrcBuffer, DWORD dwSamples);
static VOID FillBufferS16toS16 (PINT16 pDstBuffer, PINT16 pSrcBuffer, DWORD dwSamples);

static VOID GetBufferM08fromM16 (PBYTE pDstBuffer, PINT16 pSrcBuffer, DWORD dwSamples);
static VOID GetBufferS08fromM16 (PBYTE pDstBuffer, PINT16 pSrcBuffer, DWORD dwSamples);
static VOID GetBufferM16fromM16 (PINT16 pDstBuffer, PINT16 pSrcBuffer, DWORD dwSamples);
static VOID GetBufferS16fromM16 (PINT16 pDstBuffer, PINT16 pSrcBuffer, DWORD dwSamples);



static UINT16 g_VolMatrix[0x64];
volatile PBYTE   dma_page[NUM_DMA_AUDIO_BUFFERS];
DWORD   dma_page_physical[NUM_DMA_AUDIO_BUFFERS];

static void Test_Read_AC97(void);

static ULONG         v_nVolume=0xeeeeeeee; //default to volume

DWORD gIntrAudio = SYSINTR_UNDEFINED;
AT91PS_AC97C		g_pAC97C	= NULL;
static AT91PS_PMC	g_pPMC		= NULL;
static BOOL			v_fMoreData[2];
static CRITICAL_SECTION g_csCAMR;

DWORD g_dwCaptureLatency; // capture buffers will hold this much data (in milliseconds)


typedef struct {
	WORD	wSrcBitsPerSample;
	WORD	wDstBitsPerSample;
	WORD	wSrcNbChannels;
	WORD	wDstNbChannels;
	BOOL	bInUse;		// is apidir in use? if so, fail Open calls
	DWORD	dwDMASize; // Size in bytes
} T_CHANNEL_DESC;


T_CHANNEL_DESC g_ChannelDesc[NUM_API_DIRS];
typedef enum
{
	CODEC_WARM_RESET,
		CODEC_COLD_RESET
} T_CODEC_RESET_TYPE;


typedef struct {
	PVOID pData;
	DWORD dwPhysAddr;
	DWORD dwSize;
	DWORD ID;
} T_BUFFER;

typedef struct {
	DWORD dwListMaxSize;
	DWORD dwNbBufferInList;
	DWORD dwFirstBufferIndex;
	DWORD dwNextBufferIndex;
	CRITICAL_SECTION cs;
	T_BUFFER **pBufferArray;
} T_BUFFER_FIFO;


//! Fifo used to keep track of free emission buffer
T_BUFFER_FIFO	FreeOutBufferFifo;
//! Fifo used to keep track of buffers ready to be played
T_BUFFER_FIFO   BufferToPlayFifo;
//! Fifo used to keep track of buffers being played (already in the DMA list)
T_BUFFER_FIFO   BufferBeingPlayedFifo;

T_BUFFER		XmitBuffers[NB_XMIT_PAGE];

//! Fifo used to keep track of buffer available for recording
T_BUFFER_FIFO	FreeInBufferFifo;
//! Fifo used to keep track of recorded buffers (after DMA)
T_BUFFER_FIFO   BufferRecordedFifo;
//! Fifo used to keep track of buffers being recorded (already in the DMA list)
T_BUFFER_FIFO   BufferBeingRecordedFifo;


T_BUFFER		RcvBuffers[NB_RCV_PAGE];


//-----------------------------------------------------------------------------
//! \brief		This function creates a new Fifo
//! \param		dwNbBuffer the number of buffer that the fifo can handle
//! \param		pFifo	   a pointer to the fifo structure that will be initialized
//-----------------------------------------------------------------------------
BOOL CreateNewBufferFifo(DWORD dwNbBuffer,T_BUFFER_FIFO* pFifo)
{
	if (pFifo == NULL)
	{
		return FALSE;
	}
	
	pFifo->dwListMaxSize = dwNbBuffer;
	pFifo->pBufferArray = (T_BUFFER **) malloc(dwNbBuffer*sizeof(T_BUFFER*));
	if (pFifo->pBufferArray == NULL)
	{
		return FALSE;
	}
	InitializeCriticalSection(&pFifo->cs);
	
	pFifo->dwNbBufferInList = 0;
	pFifo->dwFirstBufferIndex = 0;
	pFifo->dwNextBufferIndex = 0;
	
	return TRUE;
}
//-----------------------------------------------------------------------------
//! \brief		This function resets a fifo
//! \param		pFifo	   a pointer to the fifo structure that will be reset
//!
//! The fifo is emptied. There's no need to create the fifo again. It's still ready to use
//-----------------------------------------------------------------------------
BOOL ResetFifo(T_BUFFER_FIFO* pFifo)
{
	if (pFifo == NULL)
	{
		return FALSE;
	}
	
	EnterCriticalSection(&pFifo->cs);
	pFifo->dwNbBufferInList = 0;
	pFifo->dwFirstBufferIndex = 0;
	pFifo->dwNextBufferIndex = 0;
	LeaveCriticalSection(&pFifo->cs);
	
	return TRUE;
}


//-----------------------------------------------------------------------------
//! \brief		This function deletes a fifo
//! \param		pFifo	   a pointer to the fifo structure that will be deleted
//!
//! The fifo is emptied. All allocations are released.
//-----------------------------------------------------------------------------
BOOL DeleteBufferFifo(T_BUFFER_FIFO* pFifo)
{
	if (pFifo == NULL)
	{
		return FALSE;
	}
	
	EnterCriticalSection(&pFifo->cs);
	free(pFifo->pBufferArray);	
	pFifo->pBufferArray = NULL;
	pFifo->dwNbBufferInList = 0;
	pFifo->dwFirstBufferIndex = 0;
	pFifo->dwNextBufferIndex = 0;	
	pFifo->dwListMaxSize = 0;
	LeaveCriticalSection(&pFifo->cs);
	DeleteCriticalSection(&pFifo->cs);
	return TRUE;
}


//-----------------------------------------------------------------------------
//! \brief		This function gets the first buffer of the list and remove it from the fifo
//! \param		pFifo	   a pointer to the fifo structure that will be deleted
//!
//! \return  A pointer to the first buffer of the fifo if it's not empty, else NULL
//-----------------------------------------------------------------------------
T_BUFFER* PopBuffer(T_BUFFER_FIFO* pFifo)
{
	T_BUFFER* pResult = NULL;
	
	if (pFifo == NULL)
	{
		return NULL;
	}
	
	EnterCriticalSection(&pFifo->cs);
	
	if (pFifo->dwNbBufferInList != 0)
	{
		pResult = pFifo->pBufferArray[pFifo->dwFirstBufferIndex];		
		pFifo->dwFirstBufferIndex = INC_MODULO(pFifo->dwFirstBufferIndex,pFifo->dwListMaxSize);		
		pFifo->dwNbBufferInList--;
	}
	LeaveCriticalSection(&pFifo->cs);
	
	return pResult;
}

//-----------------------------------------------------------------------------
//! \brief		This function gets the first buffer of the list and remove it from the fifo
//! \param		pFifo	   a pointer to the fifo structure that will be deleted
//! \param		pBuffer		a pointer to the buffer that must be stored in the fifo
//!
//! \return  TRUE indicates success, FALSE indicates failure
//-----------------------------------------------------------------------------
BOOL PushBuffer(T_BUFFER_FIFO* pFifo,T_BUFFER* pBuffer)
{
	BOOL bResult = FALSE;
	if (pFifo == NULL)
	{
		return FALSE;
	}
	
	EnterCriticalSection(&pFifo->cs);
	
	if (pFifo->dwNbBufferInList < pFifo->dwListMaxSize)
	{
		pFifo->pBufferArray[pFifo->dwNextBufferIndex] = pBuffer;
		pFifo->dwNextBufferIndex = INC_MODULO(pFifo->dwNextBufferIndex,pFifo->dwListMaxSize);		
		pFifo->dwNbBufferInList++;
		bResult = TRUE;
	}
	LeaveCriticalSection(&pFifo->cs);
	
	return bResult;
}


//-----------------------------------------------------------------------------
//! \brief		This function resets the AC97 controller
//! \param		resetType	   indicates weither it's warm or a cold reset
//!
//! \note Cold reset also resets the Codec
//-----------------------------------------------------------------------------
static void ResetAC97Controller(T_CODEC_RESET_TYPE resetType)
{
/*
	if (g_pAC97C)
	{
		switch(resetType)
		{
		case CODEC_WARM_RESET:
			g_pAC97C->AC97C_MR |= AT91C_AC97C_WRST;
			Sleep(1);
			g_pAC97C->AC97C_MR &= ~AT91C_AC97C_WRST;
			break;
		case CODEC_COLD_RESET:
			g_pAC97C->AC97C_MR &= ~AT91C_AC97C_ENA;
			AC97CBoardSpecificClearResetLine();
			Sleep(1);
			AC97CBoardSpecificSetResetLine();
			break;
		}
	}
	else
	{
		ASSERT(0);
	}
*/
}

//------------------------------------------------------------------------------------------------------------
//! \brief Process an audio interrupt from the MDD
//!
//! \\return indicates the state of audio playback or record to the MDD
//!
//-------------------------------------------------------------------------------------------------------------
AUDIO_STATE PDD_AudioGetInterruptType(void)
{
	DWORD dwCASR= g_pAC97C->AC97C_CASR & (g_pAC97C->AC97C_CAMR & (AT91C_AC97C_ENDRX | AT91C_AC97C_RXBUFF | AT91C_AC97C_ENDTX | AT91C_AC97C_TXBUFE | AT91C_AC97C_OVRUN | AT91C_AC97C_UNRUN));
    AUDIO_STATE retval=AUDIO_STATE_IGNORE ;
	
    DEBUGMSG(ZONE_VERBOSE, (TEXT( "+PDD_AudioGetInterruptType\r\n" )) );
	
	EnterCriticalSection(&g_csCAMR);
    //
    // An audio interrupt has occured. We need to tell the MDD who owns it
    // and what state that puts us in.
    //
    // Note, that you can return both an input and an output state simultaneously
    // by simply OR'ing the two values together (output and input are held
    // in upper and lower nibbles respectively).
    //
	
    //
    // I N P U T
    //
	if (v_fMoreData[WAPI_IN] == TRUE)
	{
		if (dwCASR & (AT91C_AC97C_ENDRX | AT91C_AC97C_RXBUFF))
		{
			T_BUFFER* pBuffer;
			DWORD dwBothBufferConsummed;
			if (g_pAC97C->AC97C_CASR & AT91C_AC97C_RXBUFF)
			{
				pBuffer = PopBuffer(&BufferBeingRecordedFifo);
				if (pBuffer)
				{										
					PushBuffer(&BufferRecordedFifo,pBuffer);
				}
				dwBothBufferConsummed = TRUE;
				RETAILMSG(ZONE_PDD,(TEXT("ac97 RXBUFF\r\n")));
			}
			else
			{
				dwBothBufferConsummed = FALSE;
				RETAILMSG(ZONE_PDD,(TEXT("ac97 ENDRX\r\n")));
			}
			pBuffer = PopBuffer(&BufferBeingRecordedFifo);
			if (pBuffer)
			{
				PushBuffer(&BufferRecordedFifo,pBuffer);
			}
			
			if (dwBothBufferConsummed)
			{
				T_BUFFER *pBuffer2;
				pBuffer = PopBuffer(&FreeInBufferFifo);				
				pBuffer2 = PopBuffer(&FreeInBufferFifo);
				
				if (pBuffer)
				{
					g_pAC97C->AC97C_RPR = pBuffer->dwPhysAddr;
					g_pAC97C->AC97C_RCR = pBuffer->dwSize /(g_ChannelDesc[WAPI_IN].wSrcBitsPerSample/8);
					
					PushBuffer(&BufferBeingRecordedFifo,pBuffer);
					
					if (pBuffer2)
					{
						RETAILMSG(ZONE_PDD,(TEXT("recording %d puis %d\r\n"),pBuffer->ID,pBuffer2->ID));
						g_pAC97C->AC97C_RNPR = pBuffer2->dwPhysAddr;
						g_pAC97C->AC97C_RNCR = pBuffer2->dwSize /(g_ChannelDesc[WAPI_IN].wSrcBitsPerSample/8);
						PushBuffer(&BufferBeingRecordedFifo,pBuffer2);
					}
					else
					{
						RETAILMSG(ZONE_PDD,(TEXT("recording %d puis ...(C'est tout)\r\n"),pBuffer->ID));
					}
					
					//Enable the Rx interrupt
					g_pAC97C->AC97C_CAMR |= AT91C_AC97C_ENDRX | AT91C_AC97C_RXBUFF | AT91C_AC97C_OVRUN;										
					
					retval |= AUDIO_STATE_IN_RECORDING;
				}	
				else
				{
					RETAILMSG(ZONE_PDD,(TEXT("int handler. No buffer to record in the Fifo\r\n")));
					//disable PDC TX interrupt 
					g_pAC97C->AC97C_CAMR &= ~(AT91C_AC97C_ENDRX | AT91C_AC97C_RXBUFF | AT91C_AC97C_OVRUN);
					retval |= AUDIO_STATE_IN_RECORDING;          //TODO: Does the MDD now send a WPDM_STOP message?
				}
			}
			else
			{
				pBuffer = PopBuffer(&FreeInBufferFifo);
				
				if (pBuffer)
				{
					RETAILMSG(ZONE_PDD,(TEXT("recording seulement %d \r\n"),pBuffer->ID));
					g_pAC97C->AC97C_RNPR = pBuffer->dwPhysAddr;
					g_pAC97C->AC97C_RNCR = pBuffer->dwSize / (g_ChannelDesc[WAPI_IN].wSrcBitsPerSample/8);
					
					//Enable the Tx interrupt
					g_pAC97C->AC97C_CAMR |= AT91C_AC97C_ENDRX | AT91C_AC97C_RXBUFF | AT91C_AC97C_OVRUN;										
					
					PushBuffer(&BufferBeingRecordedFifo,pBuffer);
					
					retval |= AUDIO_STATE_IN_RECORDING;
				}	
				else
				{
					RETAILMSG(ZONE_PDD,(TEXT("int handler. No buffer to record in the Fifo\r\n")));
					//disable PDC TX interrupt 
					g_pAC97C->AC97C_CAMR &= ~(AT91C_AC97C_ENDRX | AT91C_AC97C_RXBUFF | AT91C_AC97C_OVRUN);				
					retval |= AUDIO_STATE_IN_RECORDING;          //TODO: Does the MDD now send a WPDM_STOP message?
				}
			}
			
		}
		if (dwCASR  & AT91C_AC97C_OVRUN)
		{
			RETAILMSG(1, (TEXT( "PDD_AudioGetInterruptType : Receive Overrun\r\n" )) );
			
			retval |= AUDIO_STATE_IN_OVERFLOW;	// \bug the descriptor was loaded but not ready for use
		}
	}
	else
	{
		//disable PDC RX interrupt 
		g_pAC97C->AC97C_CAMR &= ~(AT91C_AC97C_ENDRX | AT91C_AC97C_RXBUFF | AT91C_AC97C_OVRUN);
		
		retval |= AUDIO_STATE_IN_STOPPED;           //JJH TODO: Does the MDD now send a WPDM_STOP message?
	}
		
	//
    // O U T P U T
    //
	if (v_fMoreData[WAPI_OUT] == TRUE)
	{
		if (dwCASR & (AT91C_AC97C_ENDTX | AT91C_AC97C_TXBUFE | AT91C_AC97C_UNRUN)) //if the out channel stopped at the end of a buffer xfer
		{
			BOOL dwBothBufferConsummed;
			T_BUFFER * pBuffer;
			pBuffer = PopBuffer(&BufferBeingPlayedFifo);
			if (pBuffer)
			{
				g_dwXmitComplete += pBuffer->dwSize;
				pBuffer->dwSize = g_ChannelDesc[WAPI_OUT].dwDMASize;
				PushBuffer(&FreeOutBufferFifo,pBuffer);
			}
			if (g_pAC97C->AC97C_CASR & AT91C_AC97C_TXBUFE)
			{
				//RETAILMSG(1,(TEXT("ac97 TXBUF\r\n")));
				pBuffer = PopBuffer(&BufferBeingPlayedFifo);
				if (pBuffer)
				{
					g_dwXmitComplete += pBuffer->dwSize;
					pBuffer->dwSize = g_ChannelDesc[WAPI_OUT].dwDMASize;
					PushBuffer(&FreeOutBufferFifo,pBuffer);
				}
				dwBothBufferConsummed = TRUE;
				RETAILMSG(ZONE_PDD,(TEXT("ac97 TXBUFE\r\n")));
			}
			else if (g_pAC97C->AC97C_CASR & AT91C_AC97C_UNRUN)
			{
				// Underrun is manage as a TXBUFF.
				// When a under IT fired, driver consider all data in DMA as sent.
				g_pAC97C->AC97C_PTCR = AT91C_PDC_TXTDIS;
				pBuffer = PopBuffer(&BufferBeingPlayedFifo);
				if (pBuffer)
				{
					g_dwXmitComplete += pBuffer->dwSize;
					pBuffer->dwSize = g_ChannelDesc[WAPI_OUT].dwDMASize;
					PushBuffer(&FreeOutBufferFifo,pBuffer);
				}
				dwBothBufferConsummed = TRUE;
				g_pAC97C->AC97C_PTCR = AT91C_PDC_TXTEN;
			}
			else
			{
				dwBothBufferConsummed = FALSE;
				RETAILMSG(ZONE_PDD,(TEXT("ac97 ENDTX\r\n")));
			}
			
			if (dwBothBufferConsummed)
			{
				T_BUFFER *pBuffer2;
				pBuffer = PopBuffer(&BufferToPlayFifo);				
				pBuffer2 = PopBuffer(&BufferToPlayFifo);
				
				if (pBuffer)
				{
					g_pAC97C->AC97C_TPR = pBuffer->dwPhysAddr;
					g_pAC97C->AC97C_TCR = pBuffer->dwSize /(g_ChannelDesc[WAPI_OUT].wDstBitsPerSample/8);
					
					PushBuffer(&BufferBeingPlayedFifo,pBuffer);
					
					if (pBuffer2)
					{
						RETAILMSG(ZONE_PDD,(TEXT("playing %d puis %d\r\n"),pBuffer->ID,pBuffer2->ID));
						g_pAC97C->AC97C_TNPR = pBuffer2->dwPhysAddr;
						g_pAC97C->AC97C_TNCR = pBuffer2->dwSize /(g_ChannelDesc[WAPI_OUT].wDstBitsPerSample/8);
						PushBuffer(&BufferBeingPlayedFifo,pBuffer2);
					}
					else
					{
						//RETAILMSG(1,(TEXT("int handler. No secondary buffer\r\n")));
						RETAILMSG(ZONE_PDD,(TEXT("playing %d puis ...(C'est tout)\r\n"),pBuffer->ID));
					}
					//Enable the Tx interrupt
					g_pAC97C->AC97C_CAMR |= (AT91C_AC97C_ENDTX | AT91C_AC97C_TXBUFE | AT91C_AC97C_UNRUN);
					
					retval |= AUDIO_STATE_OUT_PLAYING;
				}	
				else
				{
					RETAILMSG(ZONE_PDD,(TEXT("int handler. No buffer to play in the Fifo\r\n")));
					//disable PDC TX interrupt 
					g_pAC97C->AC97C_CAMR &= ~(AT91C_AC97C_ENDTX | AT91C_AC97C_TXBUFE | AT91C_AC97C_UNRUN);				
					retval |= AUDIO_STATE_OUT_PLAYING;          //TODO: Does the MDD now send a WPDM_STOP message?
				}
				
			}
			else
			{
				
				pBuffer = PopBuffer(&BufferToPlayFifo);
				
				if (pBuffer)
				{
					RETAILMSG(ZONE_PDD,(TEXT("playing seulement %d \r\n"),pBuffer->ID));
					g_pAC97C->AC97C_TNPR = pBuffer->dwPhysAddr;
					g_pAC97C->AC97C_TNCR = pBuffer->dwSize / (g_ChannelDesc[WAPI_OUT].wDstBitsPerSample/8);
					
					//Enable the Tx interrupt
					g_pAC97C->AC97C_CAMR |= (AT91C_AC97C_ENDTX | AT91C_AC97C_TXBUFE | AT91C_AC97C_UNRUN);
					
					PushBuffer(&BufferBeingPlayedFifo,pBuffer);
					
					retval |= AUDIO_STATE_OUT_PLAYING;
				}	
				else
				{
					RETAILMSG(ZONE_PDD,(TEXT("int handler. No buffer to play in the Fifo\r\n")));
					//disable PDC TX interrupt 
					g_pAC97C->AC97C_CAMR &= ~(AT91C_AC97C_ENDTX | AT91C_AC97C_TXBUFE | AT91C_AC97C_UNRUN);				
					retval |= AUDIO_STATE_OUT_PLAYING;          //TODO: Does the MDD now send a WPDM_STOP message?
				}
			}		
		}
		if (dwCASR  & AT91C_AC97C_UNRUN)
		{
			RETAILMSG(1, (TEXT( "PDD_AudioGetInterruptType : Transmit Underrun\r\n" )) );
			//retval |= AUDIO_STATE_OUT_UNDERFLOW;	// Underrun is manage as a TXBUFF. See code below.
		}
    }
	else
	{
		//disable PDC TX interrupt 
		g_pAC97C->AC97C_CAMR &= ~(AT91C_AC97C_ENDTX | AT91C_AC97C_TXBUFE | AT91C_AC97C_UNRUN);
		
		retval |= AUDIO_STATE_OUT_STOPPED;          //TODO: Does the MDD now send a WPDM_STOP message?
	}
	
	
	LeaveCriticalSection(&g_csCAMR);
	
    DEBUGMSG(ZONE_VERBOSE, (TEXT( "-PDD_AudioGetInterruptType\r\n" )) );
	
	
    return retval;
}


//------------------------------------------------------------------------------------------------------------
//! \brief Unmap all allocated virtual memory locations
//-------------------------------------------------------------------------------------------------------------
BOOL PddpAudioDeallocateVm(void)
{
	
    if (dma_page[0])
    {
        VirtualFree ((void*) dma_page[0],  0, MEM_RELEASE);
    }
	
	UnmapDeviceRegisters();
	
	return(TRUE);
}


//------------------------------------------------------------------------------------------------------------
//! brief Initialize Audio controller and codec
//! \return TRUE indicates success. FALSE indicates failure
//-------------------------------------------------------------------------------------------------------------
BOOL PDD_AudioInitialize(DWORD dwIndex)
{
	
    int i;
    BOOL retValue = FALSE;
    DMA_ADAPTER_OBJECT Adapter;
    PHYSICAL_ADDRESS   PA;
    HKEY hConfig = NULL;
    LPWSTR lpRegPath = (LPWSTR)dwIndex;
	DWORD dwLogintrAudio;
	
	
    DEBUGMSG(ZONE_ERROR, (TEXT("+Audio Initialize\r\n")));   
	
    g_pfnReadAc97     = ReadAC97;
    g_pfnWriteAc97    = WriteAC97;
	
	dwLogintrAudio = AT91C_ID_AC97C;
	InitializeCriticalSection(&g_csCAMR);
	
	if (KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &dwLogintrAudio, sizeof(dwLogintrAudio), &gIntrAudio, sizeof(gIntrAudio), 0) == FALSE)
	{
		RETAILMSG(1,(TEXT("AudioInitialize : Cannot get a valid Sysintr ! \r\n")));				
		return FALSE;
	}
	
	
    // Get audio driver parameters from the registry.
    //
	
	//Set the default values first
	g_dwCaptureLatency = DEFAULT_CAPTURE_LATENCY;
	
    hConfig = OpenDeviceKey(lpRegPath);
    if(hConfig == NULL)
    {
        DEBUGMSG(ZONE_ERROR, (TEXT("ERROR: AudioInitialize: OpenDeviceKey('%s') failed.\r\n"), lpRegPath));        
    }
	else
	{
		
		// Read the SYSINTR value from the registry.
		//
		DWORD dwDataSize = sizeof(g_dwCaptureLatency);
		
		if (RegQueryValueEx(hConfig, L"CaptureLatency", NULL, NULL, (LPBYTE)&g_dwCaptureLatency, &dwDataSize) != ERROR_SUCCESS)
		{
			g_dwCaptureLatency = DEFAULT_CAPTURE_LATENCY;
			DEBUGMSG(ZONE_ERROR, (TEXT("ERROR: AudioInitialize: Query registry Capture Latency value failed. Setting default value : %d ms\r\n"),g_dwCaptureLatency));			
		}
		// Close the registry handle.
		//
		RegCloseKey(hConfig);
	}
	
	
    //
    // Map device registers.
    //
    if (!MapDeviceRegisters())
    {
        DEBUGMSG(ZONE_ERROR, (TEXT("ERROR: AudioInitialize: failed to map device register(s).\r\n")));
        return(FALSE);
    }
	
	//
	// Configure the PIOs
	//
	if (!ConfigureAudioPIOs())
	{
        DEBUGMSG(ZONE_ERROR, (TEXT("ERROR: AudioInitialize: failed to configure the PIOs.\r\n")));
        return(FALSE);
	}
	
    // Map both DMA pages into the local address space.
    //
    Adapter.ObjectSize    = sizeof(DMA_ADAPTER_OBJECT);
    Adapter.InterfaceType = Internal;
    Adapter.BusNumber     = 0;
	
	
    dma_page[0] = (BYTE *) HalAllocateCommonBuffer(&Adapter, (AUDIO_BUFFER_SIZE * NUM_DMA_AUDIO_BUFFERS), &PA, FALSE);
    if (!dma_page[0])
    {
        DEBUGMSG(ZONE_ERROR, (TEXT("ERROR: AudioInitialize: failed to allocate DMA buffer(s).\r\n")));
        return(FALSE);
    }
    for (i=1;i<NUM_DMA_AUDIO_BUFFERS;i++)
	{
		dma_page[i]     = dma_page[i-1] + AUDIO_BUFFER_SIZE;
	}
	
    dma_page_physical[0] = PA.LowPart;
    for (i=1;i<NUM_DMA_AUDIO_BUFFERS;i++)
	{
		dma_page_physical[i]     = dma_page_physical[i-1] + AUDIO_BUFFER_SIZE;
	}
    
    DEBUGMSG(ZONE_ALLOC, (TEXT("INFO: AudioInitialize: dmap[0]=0x%x, dmap[1]=0x%x, dmap[2]=0x%x, dmap[3]=0x%x\r\n" ),
		dma_page[0],dma_page[1],dma_page[2],dma_page[3]));
	
    // Compress range of 3f - 0 to 1f - 0 this makes volume adjustment seem intuitive.
    //
    for (i=0; i < sizeof(g_VolMatrix) / sizeof(g_VolMatrix[0]); i+=2)
    {
        g_VolMatrix[i]   = (63 - i) >> 1;
        g_VolMatrix[i+1] = (63 - i) >> 1;
    }
    // Customize lower volume settings to quickly rolloff to neg infinity.
    g_VolMatrix[0] = 0x3f;
    g_VolMatrix[1] = 0x3A;
    g_VolMatrix[2] = 0x35;
    g_VolMatrix[3] = 0x2F;
    g_VolMatrix[4] = 0x2a;
    g_VolMatrix[5] = 0x25;
    g_VolMatrix[6] = 0x1f;
	
	
	
	//Turn on the controller clock;
	g_pPMC->PMC_PCER = (1<<AT91C_ID_AC97C);
	
	//Reset the audio codec 
	ResetAC97Controller(CODEC_COLD_RESET);
	
	//Set up the AC97C registers
	g_pAC97C->AC97C_MR = AT91C_AC97C_ENA | AT91C_AC97C_VRA;
	
	//Selection of the input slot. We only manage Slot 3 (Mono Input only)
	g_pAC97C->AC97C_ICA = AT91C_AC97C_CHID3_CA;
	
	//Selection of the output slot. We only manage Slot 3 & 4 (PCM L and R Front)
	g_pAC97C->AC97C_OCA = AT91C_AC97C_CHID3_CA | AT91C_AC97C_CHID4_CA;
	
	
	
	
	// Initialisation of channel A (used for both input and output)
	// Configuration is : 
	// * PDC (dma) enabled
	// * Channel enabled
	// * Little endian 
	// * data width : 16 bits
	// * interrupts enabled for OVRUN and UNRUN 	 
	EnterCriticalSection(&g_csCAMR);
	g_pAC97C->AC97C_CAMR = AT91C_AC97C_PDCEN | AT91C_AC97C_CEN | AT91C_AC97C_SIZE_16_BITS |  AT91C_AC97C_UNRUN;
	LeaveCriticalSection(&g_csCAMR);
	//Enable the interrupt for Channel A only
	g_pAC97C->AC97C_IDR = 0xFFFFFFFF;
	g_pAC97C->AC97C_IER = AT91C_AC97C_CAEVT;
	
    // Initialize the AClink.
    //
    if (InitializeACLink(FALSE))
    {
        // Power-on the audio controller.
        if (AudioPowerOn())
        {
            retValue = TRUE;
        }
    }
	
    
	
	//Set the default volume 
	AC97_SetOutVolume(v_nVolume);
	
	
	//Setup the buffers 
	for (i=0;i<NB_XMIT_PAGE;i++)
	{
		XmitBuffers[i].pData = dma_page[i];
		XmitBuffers[i].dwPhysAddr = dma_page_physical[i];
		XmitBuffers[i].ID = i;
	}
	for (i=0;i<NB_RCV_PAGE;i++)
	{
		RcvBuffers[i].pData = dma_page[i + NB_XMIT_PAGE];
		RcvBuffers[i].dwPhysAddr = dma_page_physical[i + NB_XMIT_PAGE];
		RcvBuffers[i].ID = i;
	}
		
	// Create the fifos
	CreateNewBufferFifo(sizeof(XmitBuffers) / sizeof(XmitBuffers[0]),&FreeOutBufferFifo);
	CreateNewBufferFifo(sizeof(XmitBuffers) / sizeof(XmitBuffers[0]),&BufferToPlayFifo);
	CreateNewBufferFifo(sizeof(XmitBuffers) / sizeof(XmitBuffers[0]),&BufferBeingPlayedFifo);
	
	CreateNewBufferFifo(sizeof(RcvBuffers) / sizeof(RcvBuffers[0]),&FreeInBufferFifo);
	CreateNewBufferFifo(sizeof(RcvBuffers) / sizeof(RcvBuffers[0]),&BufferRecordedFifo);
	CreateNewBufferFifo(sizeof(RcvBuffers) / sizeof(RcvBuffers[0]),&BufferBeingRecordedFifo);
		
	
    DEBUGMSG(ZONE_ERROR, (TEXT("-Audio Initialize\r\n")));   
	
    return (retValue);
	
}


//------------------------------------------------------------------------------------------------------------
//! \brief This function is responsible for managing the audio hardware during POWER_UP and POWER_DOWN notifications
//-------------------------------------------------------------------------------------------------------------
VOID
PDD_AudioPowerHandler(
					  BOOL power_down
					  )
{
	
	
    //
    // Reset to initial state of SoundCSR inside ASIC, clearing all interrupts.
    // Speaker and CODEC are powered down.
	
    if (!power_down)
    {   
		// We change the pointers so that we use the functions that do NOT perfomr any system calls 
        g_pfnReadAc97  = ReadAC97Raw;
        g_pfnWriteAc97 = WriteAC97Raw;
        AudioPowerOn();
		// Switch back to using the normal functions
        g_pfnReadAc97  = ReadAC97;
        g_pfnWriteAc97 = WriteAC97;
    }
    else
    {   
		// We change the pointers so that we use the functions that do NOT perfomr any system calls 
        g_pfnReadAc97  = ReadAC97Raw;
        g_pfnWriteAc97 = WriteAC97Raw;
        AudioPowerOff();		
		// Switch back to using the normal functions
        g_pfnReadAc97  = ReadAC97;
        g_pfnWriteAc97 = WriteAC97;
    }
}

//------------------------------------------------------------------------------------------------------------
//! \brief Routine for powering on Audio hardware.  Reinit the codec
//!
//! \note This may be called from within power handler, so should not make any system calls.
//-------------------------------------------------------------------------------------------------------------
BOOL
AudioPowerOn()
{	    
    static DWORD VendorId=0;
    unsigned short int VidTemp=0;
	unsigned short int toto;
	
    DEBUGMSG(ZONE_VERBOSE, (TEXT( "+Audio PowerOn\r\n" )) );    
	
	
    //Force VRA (variable rate audio) to be on
    if( !ShadowWriteAC97( EXTENDED_AUDIO_CTRL, VRA_ENABLED_MASK)  )  // Enable Variable Rate Audio
        DEBUGMSG(ZONE_ERROR, (TEXT( "-- Bad VRA Value \r\n")   ) );
	

	ShadowReadAC97(EXTENDED_AUDIO_CTRL, &toto);
	
    if( !ShadowWriteAC97( RECORD_SELECT, 0x0 )  )  // default is AUDIO_MIC_INPUT_MONO
        DEBUGMSG(ZONE_ERROR, (TEXT( "-- Bad RECORD_SELECT \r\n")   ) ); 
	

    //Set the record gain value
    if( !ShadowWriteAC97( RECORD_GAIN, 0x0f0f )  )  //set to a well working value
	{
		DEBUGMSG(3, (TEXT( "-- error setting RECORD_GAIN \r\n")   ) );    
	}

    
	//Mute every input of the mixer line 
    if( !ShadowWriteAC97( MIC_VOLUME, 0x8000 | (1<<6))  )  //Also add the 20db Microphone boost
	{
		DEBUGMSG(3, (TEXT( "-- error setting PC_BEEP_VOLUME\r\n")   ) );    
	}
	
    if( !ShadowWriteAC97( PC_BEEP_VOLUME, 0x8000 )  )  //set to a well working value
	{
		DEBUGMSG(3, (TEXT( "-- error setting PC_BEEP_VOLUME\r\n")   ) );    
	}
    if( !ShadowWriteAC97( PHONE_VOLUME, 0x8000 )  )  //set to a well working value
	{
		DEBUGMSG(3, (TEXT( "-- error setting PHONE_VOLUME\r\n")   ) );    
	}
    if( !ShadowWriteAC97( LINE_IN_VOLUME, 0x8000 )  )  //set to a well working value
	{
		DEBUGMSG(3, (TEXT( "-- error setting LINE_IN_VOLUME\r\n")   ) );    
	}
    if( !ShadowWriteAC97( CD_VOLUME, 0x8000 )  )  //set to a well working value
	{
		DEBUGMSG(3, (TEXT( "-- error setting CD_VOLUME\r\n")   ) );    
	}
    if( !ShadowWriteAC97( VIDEO_VOLUME, 0x8000 )  )  //set to a well working value
	{
		DEBUGMSG(3, (TEXT( "-- error setting VIDEO_VOLUME\r\n")   ) );    
	}
    if( !ShadowWriteAC97( AUX_VOLUME, 0x8000 )  )  //set to a well working value
	{
		DEBUGMSG(3, (TEXT( "-- error setting AUX_VOLUME\r\n")   ) );    
	}
    

        

	
	
	
    //compliant codecs such as LM4549 require the PCM volume
        
    
    ShadowReadAC97(VENDOR_ID1, &VidTemp);  //ucb1400 doesn't use an ascii (that I can tell)
    VendorId= (VidTemp <<16); //ffffffffssssssss // f=first ascii s = second ascii
    ShadowReadAC97(VENDOR_ID2, &VidTemp);
    VendorId |=VidTemp;       //ttttttttrrrrrrrr //t = third ascii, r=rev #
    VendorId &= 0xfffffff0;//trim of version number
	
	
		
	
    //vendor specific
    switch (VendorId)
    {			
		default:		
			g_dwCodecType = GENERIC_AC97;
	
			//Enable 3D Sound ....
			if( !ShadowWriteAC97( GENERAL_PURPOSE, (1<<9) | (1<<13))  )
			{
				DEBUGMSG(3, (TEXT( "-- error setting GENERAL_PURPOSE\r\n")   ) );    
			}
			// Set the PCM out volume (which is not the master volume)
			if( !ShadowWriteAC97( PCM_OUT_VOL, 0x0404)  )
			{
				DEBUGMSG(3, (TEXT( "-- error setting PCM_OUT_VOL\r\n")   ) );    
			}
		break;				
    }
	
    AC97SetSampleRate(LastSampleRateOut,WAPI_OUT);
    AC97SetSampleRate(LastSampleRateIn,WAPI_IN);
	
    return (TRUE);
	
}

//------------------------------------------------------------------------------------------------------------
//! \brief Routine for powering down Audio hardware.
//-------------------------------------------------------------------------------------------------------------
VOID
AudioPowerOff()
{
  
    private_WaveOutStop();
	private_WaveInStop(NULL);
	

    AudioOutMute(TRUE);
    AudioInMute(TRUE);      
	
	PowerDownUnit(PWR_PR1_DAC,TRUE);
	PowerDownUnit(PWR_PR0_ADC,TRUE);
	
}

//------------------------------------------------------------------------------------------------------------
//! \brief Handle any custom WAVEIN or WAVEOUT messages
//! return MMSYSERR_NOERROR if success or  MMSYSERR_NOTSUPPORTED if failure
//
//-------------------------------------------------------------------------------------------------------------
DWORD
PDD_AudioMessage(
				 UINT uMsg,
				 DWORD dwParam1,
				 DWORD dwParam2
				 )
{
	
    unsigned short int MyData=0;
    unsigned short int usTemp;
    switch (uMsg)
    {
	case WPDM_PRIVATE_WRITE_AC97:
		if (!ShadowWriteAC97( (BYTE) dwParam1,(unsigned short int)dwParam2))
			return(MMSYSERR_ERROR);
		
		DEBUGMSG(ZONE_ERROR, (TEXT( "write %x %x \r\n" ),dwParam1,dwParam2 ) );
		return (MMSYSERR_NOERROR);
		break;
		
	case WPDM_PRIVATE_READ_AC97:
		if (!ShadowReadAC97( (BYTE) dwParam1, &MyData))
			return(MMSYSERR_ERROR);
		DEBUGMSG(ZONE_ERROR, (TEXT( "read %x %x \r\n" ),dwParam1,MyData ));
		if (dwParam2 != (unsigned short int) NULL)
			* (unsigned short int *) dwParam2 =  MyData;
		
		return (MMSYSERR_NOERROR);
		break;	

	case WPDM_PRIVATE_GET_INPUT_VOLUME:		
		
		if (!ShadowReadAC97( (BYTE) MIC_VOLUME, &usTemp))
			return(MMSYSERR_ERROR);				

		if (!ShadowReadAC97( (BYTE) RECORD_GAIN, &MyData))
			return(MMSYSERR_ERROR);
				
		
		if (dwParam1 != (unsigned short int) NULL) 
			*(unsigned short *) dwParam1 =  usTemp;		

		if (dwParam2 != (unsigned short int) NULL)
			*(unsigned short *) dwParam2 =  MyData;		

		return (MMSYSERR_NOERROR);

	case WPDM_PRIVATE_SET_INPUT_VOLUME:		
		
		if (!ShadowWriteAC97( (BYTE) MIC_VOLUME, (USHORT) dwParam1 ))
			return(MMSYSERR_ERROR);

		if (!ShadowWriteAC97( (BYTE) RECORD_GAIN, (USHORT) dwParam2 ))
			return(MMSYSERR_ERROR);
		
		return (MMSYSERR_NOERROR);
		break;	

    }
    return(MMSYSERR_NOTSUPPORTED);
}


//------------------------------------------------------------------------------------------------------------
//!   \brief This function turns off and deinitializes the audio hardware
//-------------------------------------------------------------------------------------------------------------
VOID
PDD_AudioDeinitialize(
					  VOID
					  )
{
    
    // Disable DMA input.
    //
    StopDmac(WAPI_IN);
	
    // Disable DMA output.
    //
    StopDmac(WAPI_OUT);
	
	
    // Power-off the audio controller.
    //
    AudioPowerOff();
	
    // De-allocate the AClink.
    //
    DeInitializeACLink(FALSE);
	
	//Turn off the AC97C clock	
	g_pPMC->PMC_PCDR = (1<<AT91C_ID_AC97C);
	
    // Free memory and mapped registers.
    //
    PddpAudioDeallocateVm();
	
	KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, &gIntrAudio, sizeof(gIntrAudio), NULL,0, 0);
	//Delete CAMR critical section
	DeleteCriticalSection(&g_csCAMR);
}


//------------------------------------------------------------------------------------------------------------
//! \brief Quick Mute the output with out effecting the stored volume value
//!
//! \return TRUE indicates success. FALSE indicates failure
//!
//-------------------------------------------------------------------------------------------------------------
BOOL
AudioOutMute(
			 BOOL mute
			 )
{
    BOOL retval = FALSE;
    
    unsigned short int Ac97Data=0;
	
    ShadowReadAC97(HEADPHONE_VOLUME,&Ac97Data);  //read the current hardware volume
	
    if( mute )
    {
        Ac97Data=Ac97Data |   MUTE_MASK;    //set the mute bit
    }
    else
        Ac97Data=Ac97Data & ~ MUTE_MASK;    //clear the mute bit
	
	
    return( ShadowWriteAC97(HEADPHONE_VOLUME, Ac97Data) );
}

//------------------------------------------------------------------------------------------------------------
//! \brief Quick Mute the input with out effecting the stored volume value
//!
//! \return TRUE indicates success. FALSE indicates failure
//!
//-------------------------------------------------------------------------------------------------------------
BOOL
AudioInMute(
			BOOL mute
			)
{
    BOOL retval = FALSE;
    
    unsigned short int Ac97Data=0;
	
    ShadowReadAC97(RECORD_GAIN,&Ac97Data);           //read the current hardware volume
	
    if( mute )
    {
        Ac97Data=Ac97Data |   MUTE_MASK;    //set the mute bit
    }
    else
        Ac97Data=Ac97Data &  ~ MUTE_MASK;   //clear the mute bit
	
	
    return( ShadowWriteAC97(RECORD_GAIN, Ac97Data) );
}

//------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------
VOID
private_AudioComplete(PWAVEHDR pwh, ULONG cbBytesCompleted)
{
    // we've just finished playing another cbDstBytes of data.
    // update the queued headers accordingly
    while ((pwh != NULL) && (cbBytesCompleted > 0)) {
		
        if (pwh->dwBytesRecorded >= pwh->reserved) {
            pwh = pwh->lpNext;
        }
        else {
            ULONG cbBytesLeft = pwh->reserved - pwh->dwBytesRecorded;
            ULONG cbAdvance = min(cbBytesCompleted, cbBytesLeft);
            cbBytesCompleted -= cbAdvance;
            pwh->dwBytesRecorded += cbAdvance;
        }
    }
	
}

VOID
FillBufferM08toS16 (PINT16 pDstBuffer, PBYTE pSrcBuffer, DWORD dwSamples)
{
    while (dwSamples-- > 0) {
        PPCM_SAMPLE pSample = (PPCM_SAMPLE) pSrcBuffer;
        INT16 sample16 = BITS_8_TO_16(pSample->m8.sample);
        pDstBuffer[0] = sample16;
        pDstBuffer[1] = sample16;
        pDstBuffer += 2;
        pSrcBuffer += 1;
    }
}

VOID
FillBufferS08toS16 (PINT16 pDstBuffer, PBYTE pSrcBuffer, DWORD dwSamples)
{
    while (dwSamples-- > 0) {
        PPCM_SAMPLE pSample = (PPCM_SAMPLE) pSrcBuffer;
        pDstBuffer[0] = BITS_8_TO_16(pSample->s8.sample_left);
        pDstBuffer[1] = BITS_8_TO_16(pSample->s8.sample_right);
        pDstBuffer += 2;
        pSrcBuffer += 2;
    }
}

VOID
FillBufferM16toS16 (PINT16 pDstBuffer, PINT16 pSrcBuffer, DWORD dwSamples)
{
    while (dwSamples-- > 0) {
        INT16 sample = * (PINT16) pSrcBuffer;
        pDstBuffer[0] = sample;
        pDstBuffer[1] = sample;
        pDstBuffer += 2;
        pSrcBuffer += 1;
    }
}

VOID
FillBufferS16toS16 (PINT16 pDstBuffer, PINT16 pSrcBuffer, DWORD dwSamples)
{
    memcpy(pDstBuffer, pSrcBuffer, dwSamples * sizeof(DWORD));
}

DWORD g_TotalPlayed=0;

//------------------------------------------------------------------------------------------------------------
//! \brief Copies (plays) audio data to the Xmit buffers from Windows CE application buffers.  
//!
//! The data is reformatted to meet the requirements of the codec.  
//! This function is called in response to the WPDM_START or WPDM_CONTINUE messages where the WAPI_INOUT direction is WAPI_OUT.
//-------------------------------------------------------------------------------------------------------------
DWORD
private_AudioFillBuffer (
						 PWAVEHDR pwh,
						 PVOID pDstBuffer,
						 DWORD dwBufferSize
						 )
{
	
	
	PVOID pOldDstBuffer = pDstBuffer;
    DWORD dwDstSamples = dwBufferSize / ((g_ChannelDesc[WAPI_OUT].wDstBitsPerSample/8)*g_ChannelDesc[WAPI_OUT].wDstNbChannels);
	
	FUNC_VERBOSE("+PDD_AudioFillBuffer");
	
	
    while ((pwh != NULL) && (dwDstSamples > 0)) {
		if (pwh->reserved >= pwh->dwBufferLength) {
			if (pwh->reserved > pwh->dwBufferLength)
			{
				RETAILMSG(1,(TEXT("SHOULD NEVER HAPPEN !!! pwh reserved %d buf length %d\r\n"),pwh->reserved,pwh->dwBufferLength));
			}
            pwh = pwh->lpNext;
        }
        else {
            DWORD dwSrcSamples = (pwh->dwBufferLength - pwh->reserved) / ((g_ChannelDesc[WAPI_OUT].wSrcBitsPerSample/8)*g_ChannelDesc[WAPI_OUT].wSrcNbChannels);
            DWORD dwSamples = min(dwDstSamples, dwSrcSamples);
            g_pfnFillBuffer((PINT16) pDstBuffer, pwh->lpData + pwh->reserved, dwSamples);
            pwh->reserved += dwSamples * ((g_ChannelDesc[WAPI_OUT].wSrcBitsPerSample/8)*g_ChannelDesc[WAPI_OUT].wSrcNbChannels);
			g_TotalPlayed += dwSamples;
            (PUCHAR) pDstBuffer += dwSamples * ((g_ChannelDesc[WAPI_OUT].wDstBitsPerSample/8)*g_ChannelDesc[WAPI_OUT].wDstNbChannels);
            dwDstSamples -= dwSamples;
        }
    }
	
	
	return (DWORD) pDstBuffer- (DWORD) pOldDstBuffer;
}

//------------------------------------------------------------------------------------------------------------
//! \brief Stops output of audio data.
//-------------------------------------------------------------------------------------------------------------
VOID
private_WaveOutEndOfData()
{
    FUNC_WPDD("+PDD_WaveOutEndOfData");
	
    //
    // There is no more data coming...
    //
    v_fMoreData[WAPI_OUT] = FALSE;
	
    StopDmac(WAPI_OUT);
	
    FUNC_WPDD("-PDD_WaveOutEndOfData");
}

//------------------------------------------------------------------------------------------------------------
//! \brief Starts (play or) processing of audio data and initiates PDC (ie DMA) transfer to the codec in response to the WPDM_START message where the WAPI_INOUT direction is WAPI_OUT.
//-------------------------------------------------------------------------------------------------------------
VOID
private_WaveOutStart (
					  PWAVEHDR pwh
					  )
{
	T_BUFFER* pBuffer;
	T_BUFFER* pBuffer2;
    DWORD i;
	
	
	FUNC_WPDD("+PDD_WaveOutStart");
	

	g_TotalPlayed=0;
	
	EnterCriticalSection(&g_csCAMR);


	// Reinit our fifos 
	ResetFifo(&FreeOutBufferFifo);
	ResetFifo(&BufferToPlayFifo);
	ResetFifo(&BufferBeingPlayedFifo);	
	for (i=0;i<NB_XMIT_PAGE;i++)
	{
		XmitBuffers[i].dwSize = g_ChannelDesc[WAPI_OUT].dwDMASize;
		PushBuffer(&FreeOutBufferFifo,&XmitBuffers[i]);
	}
	

	
    
    v_fMoreData[WAPI_OUT] = TRUE;        // we expect to have more data coming...
	
	pBuffer = PopBuffer(&FreeOutBufferFifo);
	if (pBuffer)
	{
		DWORD dwSize = private_AudioFillBuffer(pwh, (PDWORD) pBuffer->pData, pBuffer->dwSize);
		pBuffer->dwSize = dwSize ; 
		PushBuffer(&BufferToPlayFifo,pBuffer);
	}
	pBuffer = PopBuffer(&FreeOutBufferFifo);
	if (pBuffer)
	{
		DWORD dwSize = private_AudioFillBuffer(pwh, (PDWORD) pBuffer->pData, pBuffer->dwSize);
		pBuffer->dwSize = dwSize;
		PushBuffer(&BufferToPlayFifo,pBuffer);
	}
	
	
	pBuffer = PopBuffer(&BufferToPlayFifo);
	pBuffer2 = PopBuffer(&BufferToPlayFifo);
	
	if (pBuffer && pBuffer2)
	{
		g_pAC97C->AC97C_PTCR = AT91C_PDC_TXTDIS;
		g_pAC97C->AC97C_TPR = pBuffer->dwPhysAddr;				
		g_pAC97C->AC97C_TNPR = pBuffer2->dwPhysAddr;
		g_pAC97C->AC97C_TCR = pBuffer->dwSize / (g_ChannelDesc[WAPI_OUT].wDstBitsPerSample/8);			
		g_pAC97C->AC97C_TNCR = pBuffer2->dwSize / (g_ChannelDesc[WAPI_OUT].wDstBitsPerSample/8);			
		g_pAC97C->AC97C_PTCR = AT91C_PDC_TXTEN;
		PushBuffer(&BufferBeingPlayedFifo,pBuffer);
		PushBuffer(&BufferBeingPlayedFifo,pBuffer2);
		
	}		
	
	//Enable the PDC tx interrupt
	g_pAC97C->AC97C_CAMR |= (AT91C_AC97C_ENDTX | AT91C_AC97C_TXBUFE | AT91C_AC97C_UNRUN);
	
	LeaveCriticalSection(&g_csCAMR);
	
    FUNC_WPDD("-PDD_WaveOutStart");
	
}

//------------------------------------------------------------------------------------------------------------
//! \brief Continues (play or) processing of audio data and DMA output to the codec in response to the WPDM_CONTINUE message where the WAPI_INOUT direction is WAPI_OUT.
//-------------------------------------------------------------------------------------------------------------
VOID
private_WaveOutContinue (
						 PWAVEHDR pwh
						 )
{
	T_BUFFER * pBuffer;
	BOOL bLoop = TRUE;
    FUNC_VERBOSE("+PDD_WaveOutContinue");

	EnterCriticalSection(&g_csCAMR);
	private_AudioComplete(pwh, (g_dwXmitComplete * g_ChannelDesc[WAPI_OUT].wSrcBitsPerSample * g_ChannelDesc[WAPI_OUT].wSrcNbChannels) / (g_ChannelDesc[WAPI_OUT].wDstBitsPerSample* g_ChannelDesc[WAPI_OUT].wDstNbChannels));
	g_dwXmitComplete = 0;
	
	do
	{		
		pBuffer = PopBuffer(&FreeOutBufferFifo);
		if (pBuffer)
		{
			DWORD dwSize;						
			
			dwSize = private_AudioFillBuffer(pwh, (PDWORD) pBuffer->pData, pBuffer->dwSize);
			RETAILMSG(ZONE_PDD,(TEXT("ID %d : %d / %d\r\n"),pBuffer->ID, pBuffer->dwSize,dwSize));
			if (pBuffer->dwSize != dwSize) //Is the buffer entirely filled ?			
			{				
				//The buffer hasn't filled entirely, then we have no more data available
				bLoop = FALSE;
			}
			
				
			if (dwSize)
			{
				pBuffer->dwSize = dwSize;
				PushBuffer(&BufferToPlayFifo,pBuffer);
			}
			else
			{
				PushBuffer(&FreeOutBufferFifo,pBuffer);
			}
		}
	} while (bLoop && pBuffer);
	
	//Enable the PDC tx interrupt .. just in case it had been disabled (no more data available)
	g_pAC97C->AC97C_CAMR |= (AT91C_AC97C_ENDTX | AT91C_AC97C_TXBUFE | AT91C_AC97C_UNRUN);
	LeaveCriticalSection(&g_csCAMR);
	FUNC_VERBOSE("-PDD_WaveOutContinue");
}

//------------------------------------------------------------------------------------------------------------
//! \brief continues playback of paused data in response to WPDM_RESET
//! return MMSYSERR_NOERROR
//-------------------------------------------------------------------------------------------------------------
MMRESULT
private_WaveOutRestart (
						PWAVEHDR pwh
						)
{
    FUNC_VERBOSE("+PDD_WaveOutRestart");
	
    private_WaveOutStart (pwh);
	
    FUNC_VERBOSE("-PDD_WaveOutRestart");
    return(MMSYSERR_NOERROR);
}



//------------------------------------------------------------------------------------------------------------
//! \brief Pause playback of audio data in response to WPDM_PAUSE
//! return MMSYSERR_NOERROR
//-------------------------------------------------------------------------------------------------------------
MMRESULT
private_WaveOutPause (
					  VOID
					  )
{
    FUNC_VERBOSE("+PDD_WaveOutPause");
	
    private_WaveOutEndOfData();
	
	
    FUNC_VERBOSE("-PDD_WaveOutPause");
    return(MMSYSERR_NOERROR);
}


//------------------------------------------------------------------------------------------------------------
//! \brief Stop the playback of audio data in response to WPDM_STOP
//-------------------------------------------------------------------------------------------------------------
VOID
private_WaveOutStop()
{
    FUNC_WPDD("+private_WaveOutStop");
	
    v_fMoreData[WAPI_OUT] = FALSE;
	
    StopDmac(WAPI_OUT);
	
    FUNC_WPDD("-private_WaveOutStop");
}


VOID
GetBufferM08fromM16 (PBYTE pDstBuffer, PINT16 pSrcBuffer, DWORD dwSamples)
{
    while (dwSamples-- > 0) {
        *pDstBuffer = (BYTE) BITS_16_TO_8(pSrcBuffer[0]);
        pSrcBuffer += 1;
        pDstBuffer += 1;
    }
}

VOID
GetBufferS08fromM16 (PBYTE pDstBuffer, PINT16 pSrcBuffer, DWORD dwSamples)
{
	register INT8 i8Value;
    while (dwSamples-- > 0) {
		i8Value = (BYTE) BITS_16_TO_8(pSrcBuffer[0]);
        pDstBuffer[0] = i8Value;
        pDstBuffer[1] = i8Value;
        pSrcBuffer += 1;
        pDstBuffer += 2;
    }
}


VOID
GetBufferM16fromM16 (PINT16 pDst, PINT16 pSrcBuffer, DWORD dwSamples)
{
	memcpy(pDst, pSrcBuffer, dwSamples * sizeof(INT16));
}


VOID
GetBufferS16fromM16 (PINT16 pDstBuffer, PINT16 pSrcBuffer, DWORD dwSamples)
{
	register INT16 i16Value;
    while (dwSamples-- > 0) {
		i16Value = pSrcBuffer[0];
        pDstBuffer[0] = i16Value;
        pDstBuffer[1] = i16Value;
        pSrcBuffer += 1;
        pDstBuffer += 2;
    }
}


DWORD
private_AudioGetBuffer (
						PWAVEHDR pwh,
						PVOID pSrcBuffer,
						DWORD dwBufferSize
						)
{
	PVOID pOldSrcBuffer = pSrcBuffer;
	DWORD dwSrcSamples = dwBufferSize / ((g_ChannelDesc[WAPI_IN].wSrcBitsPerSample/8)*g_ChannelDesc[WAPI_IN].wSrcNbChannels);
    FUNC_VERBOSE("+PDD_AudioGetBuffer");
	
    while ((pwh != NULL) && (dwSrcSamples > 0)) {
        if (pwh->dwBytesRecorded >= pwh->dwBufferLength) {
            pwh = pwh->lpNext;
        }
        else {
            DWORD dwDstSamples = (pwh->dwBufferLength - pwh->dwBytesRecorded) / ((g_ChannelDesc[WAPI_IN].wDstBitsPerSample/8)*g_ChannelDesc[WAPI_IN].wDstNbChannels);
            DWORD dwSamples = min(dwSrcSamples, dwDstSamples);
            g_pfnGetBuffer(pwh->lpData + pwh->dwBytesRecorded, pSrcBuffer, dwSamples);
            pwh->dwBytesRecorded += dwSamples * ((g_ChannelDesc[WAPI_IN].wDstBitsPerSample/8)*g_ChannelDesc[WAPI_IN].wDstNbChannels);
            (DWORD) pSrcBuffer += dwSamples * ((g_ChannelDesc[WAPI_IN].wSrcBitsPerSample/8)*g_ChannelDesc[WAPI_IN].wSrcNbChannels);
            dwSrcSamples -= dwSamples;
        }
    }
	
    FUNC_VERBOSE("+PDD_AudioGetBuffer");
	return (DWORD) pSrcBuffer - (DWORD) pOldSrcBuffer;
}

//------------------------------------------------------------------------------------------------------------
//! \brief the WPDM_START message where the WAPI_INOUT direction is WAPI_IN.
//-------------------------------------------------------------------------------------------------------------
VOID
private_WaveInStart (PWAVEHDR pwh)
{    	
	T_BUFFER* pBuffer;
	T_BUFFER* pBuffer2;
	DWORD i;


    FUNC_WPDD("+PDD_WaveInStart");
	
	EnterCriticalSection(&g_csCAMR);
	
	ResetFifo(&FreeInBufferFifo);
	ResetFifo(&BufferRecordedFifo);
	ResetFifo(&BufferBeingRecordedFifo);
	
	
	for (i=0;i<NB_XMIT_PAGE;i++)
	{
		RcvBuffers[i].dwSize = g_ChannelDesc[WAPI_IN].dwDMASize;
		PushBuffer(&FreeInBufferFifo,&RcvBuffers[i]);
	}
	
    
    //clear the mute
    AudioInMute(FALSE);     
	
	
    v_fMoreData[WAPI_IN]  = TRUE;        // we expect to have more data coming...
	
	
	
	pBuffer = PopBuffer(&FreeInBufferFifo);
	pBuffer2 = PopBuffer(&FreeInBufferFifo);
	
	if (pBuffer && pBuffer2)
	{
		g_pAC97C->AC97C_PTCR = AT91C_PDC_RXTDIS;
		g_pAC97C->AC97C_RPR = pBuffer->dwPhysAddr;				
		g_pAC97C->AC97C_RNPR = pBuffer2->dwPhysAddr;
		g_pAC97C->AC97C_RCR = pBuffer->dwSize / (g_ChannelDesc[WAPI_IN].wDstBitsPerSample/8);			
		g_pAC97C->AC97C_RNCR = pBuffer2->dwSize / (g_ChannelDesc[WAPI_IN].wDstBitsPerSample/8);			
		g_pAC97C->AC97C_PTCR = AT91C_PDC_RXTEN;		
		PushBuffer(&BufferBeingRecordedFifo,pBuffer);
		PushBuffer(&BufferBeingRecordedFifo,pBuffer2);
	}		
	
	
	
	//Enable the Rx interrupt
	g_pAC97C->AC97C_CAMR |= AT91C_AC97C_ENDRX | AT91C_AC97C_RXBUFF | AT91C_AC97C_OVRUN;
	LeaveCriticalSection(&g_csCAMR);
    FUNC_WPDD("+PDD_WaveInStart");
	
}

//------------------------------------------------------------------------------------------------------------
//! \brief  instruct the audio PDD to continue with the data pointed to by the wave header
//-------------------------------------------------------------------------------------------------------------
VOID private_WaveInContinue(PWAVEHDR pwh)
{    
	T_BUFFER * pBuffer;
    DWORD dwSize;
	BOOL bLoop = TRUE;
	
	FUNC_VERBOSE("+PDD_WaveInContinue");
	EnterCriticalSection(&g_csCAMR);
	
	do
	{
		pBuffer = PopBuffer(&BufferRecordedFifo);
		if (pBuffer)
		{			
			RETAILMSG(ZONE_PDD,(TEXT("getting buffer %d\r\n"),pBuffer->ID));
			dwSize = private_AudioGetBuffer(pwh, pBuffer->pData, pBuffer->dwSize);
			
			PushBuffer(&FreeInBufferFifo,pBuffer);			
		}
		bLoop = FALSE;
	} while (pBuffer && bLoop);
    
	//Enable the Rx interrupt
	g_pAC97C->AC97C_CAMR |= AT91C_AC97C_ENDRX | AT91C_AC97C_RXBUFF | AT91C_AC97C_OVRUN;
	LeaveCriticalSection(&g_csCAMR);
	
    FUNC_VERBOSE("-PDD_WaveInContinue");
}

//------------------------------------------------------------------------------------------------------------
//! \brief stop recording immediately
//-------------------------------------------------------------------------------------------------------------
VOID
private_WaveInStop(
				   PWAVEHDR pwh
				   )
{
	T_BUFFER * pBuffer;
    FUNC_WPDD("+PDD_WaveInStop");
	
    v_fMoreData[WAPI_IN] = FALSE;
	
    StopDmac(WAPI_IN);
	
    AudioInMute(TRUE);      
	
	do
	{
		pBuffer = PopBuffer(&BufferRecordedFifo);
		if (pBuffer)
		{
			private_AudioGetBuffer(pwh, pBuffer->pData, pBuffer->dwSize);
			PushBuffer(&FreeInBufferFifo,pBuffer);
		}
	} while (pBuffer);
    
	
	
    FUNC_WPDD("-PDD_WaveInStop");
	
}

//------------------------------------------------------------------------------------------------------------
//! \brief power up or power down a dac, adc, or other devices
//-------------------------------------------------------------------------------------------------------------
void PowerDownUnit(unsigned short int Unit,BOOL ShutDown)
{
	
	register unsigned short int usiMask,usiMaskedValue;
	unsigned short int PowerDownCtrlStat=0;
    
    if( !ShadowReadAC97( POWERDOWN_CTRL_STAT, &PowerDownCtrlStat)  )  // Enable Variable Rate Audio
		DEBUGMSG(ZONE_ERROR, (TEXT( "-- read of PwrDnCtrl failed \r\n")   ) );
	
	usiMask = Unit;
	if (ShutDown)
	{
		usiMaskedValue = Unit;
	}
	else
	{
		usiMaskedValue = 0;
	}
	
	if ((PowerDownCtrlStat & usiMask) != usiMaskedValue)
	{
		PowerDownCtrlStat = (PowerDownCtrlStat & ~usiMask) | usiMaskedValue;
		
		if( !ShadowWriteAC97( POWERDOWN_CTRL_STAT, PowerDownCtrlStat)  )  // Enable Variable Rate Audio
        {
			DEBUGMSG(ZONE_ERROR, (TEXT( "-- write of PwrDnCtrl failed \r\n")   ) );
		}
	}
    
}



//------------------------------------------------------------------------------------------------------------
//! \brief instruct the audio PDD to put the audio circuitry in standby mode.
//-------------------------------------------------------------------------------------------------------------
VOID
private_WaveStandby(
					WAPI_INOUT apidir
					)
{
    static BOOL PowerDownIn=TRUE;
    static BOOL PowerDownOut=TRUE;
	
	
    //TODO: this function doesn't seem to get called under PB 3.0
    switch(apidir)
    {
	case WAPI_IN:
		DEBUGMSG(ZONE_TEST,(TEXT("wavestandby PowerDownIn: %x WAPI_INOUT: %x\r\n"),PowerDownIn,apidir));
		PowerDownUnit(PWR_PR0_ADC,PowerDownIn);  //turn
		//JJH : Somehow it seems that this functions is called only to power down the unit.
		//PowerDownIn=!PowerDownIn;
		break;
		
	case WAPI_OUT:
		DEBUGMSG(ZONE_TEST,(TEXT("wavestandby PowerDownOut: %x WAPI_INOUT: %x\r\n"),PowerDownOut,apidir));
		PowerDownUnit(PWR_PR1_DAC,PowerDownOut);  //turn
		//JJH : Somehow it seems that this functions is called only to power down the unit.
		//PowerDownOut=!PowerDownOut;
		break;
		
	default:
		DEBUGMSG(ZONE_TEST,(TEXT("bad param in wavestandby\r\n")));
		DEBUGCHK(FALSE);
    }
	
}

//------------------------------------------------------------------------------------------------------------
//! \brief return the capabilities of the audio hardware
//! return MMSYSERR_NOERROR if success or  MMSYSERR_NOTSUPPORTED if failure
//-------------------------------------------------------------------------------------------------------------
MMRESULT
private_WaveGetDevCaps(
					   WAPI_INOUT apidir,
					   PVOID pCaps,
					   UINT  wSize
					   )
{
	
	
    PWAVEINCAPS pwic = pCaps;
    PWAVEOUTCAPS pwoc = pCaps;
	
    MMRESULT mmRet = MMSYSERR_NOERROR;
	
    FUNC_WPDD("+PDD_WaveGetDevCaps");
	
	if (pCaps == NULL)  {
        //
        // If pCaps == NULL, we are requesting if the driver PDD is capable of
        // this mode at all. In other words, if APIDIR == WAPI_IN,  we return
        // no error if input is supported, and MMSYSERR_NOTSUPPORTED otherwise.
        // Since UCB1400 has both, we return MMSYSERR_NOERROR regardless.
        //
        if( WAPI_IN == apidir)
            return( MMSYSERR_NOERROR );
        else // ( WAPI_OUT == apidir)
            return( MMSYSERR_NOERROR );
    }
    //
    // Fill in the DevCaps here.
    //
    if (apidir == WAPI_OUT)
    {
        DEBUGMSG(ZONE_VERBOSE, (TEXT("API_OUT\r\n"  )) );
		
        pwoc->wMid = MM_MICROSOFT;
        pwoc->wPid = (apidir == WAPI_OUT ? 24 : 23);  // generic in or out...
        pwoc->vDriverVersion = 0x0001;
        wsprintf (pwoc->szPname, TEXT("AC '97  Stereo (%hs)"), __DATE__);
        pwoc->dwFormats =   WAVE_FORMAT_1M08 |
			WAVE_FORMAT_1M16 |
			WAVE_FORMAT_1S08 |
			WAVE_FORMAT_1S16 |
			WAVE_FORMAT_2M08 |
			WAVE_FORMAT_2M16 |
			WAVE_FORMAT_2S08 |
			WAVE_FORMAT_2S16 |
			WAVE_FORMAT_4M08 |
			WAVE_FORMAT_4M16 |
			WAVE_FORMAT_4S08 |
			WAVE_FORMAT_4S16;
		
		
        pwoc->wChannels = 2;
		
        //pwoc->dwSupport = WAVECAPS_VOLUME | WAVECAPS_SYNC  ;
		
    }
    else
    {
        DEBUGMSG(ZONE_VERBOSE, (TEXT("API_IN\r\n"  )) );
        pwic->wMid = MM_MICROSOFT;  //TODO: this says microsoft wrote this driver, change to intel
        pwic->wPid = (apidir == WAPI_OUT ? 24 : 23);  // generic in or out...
        pwic->vDriverVersion = 0x0001;
        wsprintf (pwoc->szPname, TEXT("AC '97  Stereo (%hs)"), __DATE__);
        pwic->dwFormats =   WAVE_FORMAT_1M08 |
			WAVE_FORMAT_1M16 |
			WAVE_FORMAT_1S08 |
			WAVE_FORMAT_1S16 |
			WAVE_FORMAT_2M08 |
			WAVE_FORMAT_2M16 |
			WAVE_FORMAT_2S08 |
			WAVE_FORMAT_2S16 |
			WAVE_FORMAT_4M08 |
			WAVE_FORMAT_4M16 |
			WAVE_FORMAT_4S08 |
			WAVE_FORMAT_4S16;
		
		
		
        pwic->wChannels = 2;
		
        //pwic->dwSupport = WAVECAPS_VOLUME | WAVECAPS_SYNC  ;
		
	}
	
    FUNC_WPDD("-PDD_WaveGetDevCaps");;
	
    return(mmRet);
}

//------------------------------------------------------------------------------------------------------------
//! \brief prepare to either send or receive audio data (based on WAPI_INOUT direction flag)
//! return MMSYSERR_NOERROR if success or  MMSYSERR_NOTSUPPORTED if failure
//-------------------------------------------------------------------------------------------------------------
MMRESULT
private_WaveOpen(
				 WAPI_INOUT apidir,
				 LPWAVEFORMATEX lpFormat,
				 BOOL fQueryFormatOnly
				 )
{
	
    MMRESULT mmRet = MMSYSERR_NOERROR;
	
    FUNC_VERBOSE("+PDD_WaveOpen");
	
    switch (g_dwCodecType)
    {
	case GENERIC_AC97:
	default:
		if ((lpFormat->wFormatTag         != WAVE_FORMAT_PCM)  ||
			(  lpFormat->nChannels         != 1 &&
			lpFormat->nChannels         != 2)             ||
			(  lpFormat->nSamplesPerSec    != KHZ08_000 &&
			lpFormat->nSamplesPerSec    != KHZ11_025 &&
			lpFormat->nSamplesPerSec    != KHZ16_000 &&
			lpFormat->nSamplesPerSec    != KHZ22_050 &&
			lpFormat->nSamplesPerSec    != KHZ32_000 &&
			lpFormat->nSamplesPerSec    != KHZ44_100 &&
			lpFormat->nSamplesPerSec    != KHZ48_000
			)         ||
			(  lpFormat->wBitsPerSample    != 16 &&
			lpFormat->wBitsPerSample    != 8))
		{
			DEBUGMSG(ZONE_ERROR, (TEXT( "return bad format\r\n " )) );
			return WAVERR_BADFORMAT;
		}
    } // end switch
	
    //if they only want a query format, then we can return success.
    if (fQueryFormatOnly) {
        DEBUGMSG( ZONE_VERBOSE, (TEXT( "Format Query\r\n " )) );
        return MMSYSERR_NOERROR;
    }
	
	if (apidir >= NUM_API_DIRS)
	{
		DEBUGMSG( ZONE_VERBOSE, (TEXT( "Invalid Direction\r\n " )) );
		return WAVERR_BADFORMAT;
	}
	
    if (g_ChannelDesc[apidir].bInUse) {
        DEBUGMSG(ZONE_ERROR, (TEXT("channel already in use\r\n")));
        return MMSYSERR_ALLOCATED;
    }
	
	g_ChannelDesc[apidir].bInUse = TRUE;
	
	if (apidir == WAPI_OUT)
	{
		g_ChannelDesc[apidir].wSrcBitsPerSample = lpFormat->wBitsPerSample;
		g_ChannelDesc[apidir].wDstBitsPerSample = 16;
		g_ChannelDesc[apidir].wSrcNbChannels = lpFormat->nChannels;
		g_ChannelDesc[apidir].wDstNbChannels = 2;
	}
	else
	{
		g_ChannelDesc[apidir].wSrcBitsPerSample = 16;
		g_ChannelDesc[apidir].wDstBitsPerSample = lpFormat->wBitsPerSample;
		g_ChannelDesc[apidir].wSrcNbChannels = 1;
		g_ChannelDesc[apidir].wDstNbChannels = lpFormat->nChannels;
	}
	
	
    //ENABLE VRA
    if( !ShadowWriteAC97( EXTENDED_AUDIO_CTRL, VRA_ENABLED_MASK)  )  // Enable Variable Rate Audio
        DEBUGMSG(ZONE_ERROR, (TEXT( "-- Bad VRA Value \r\n")   ) );
    
    //set the sample rate
    if (AC97SetSampleRate((unsigned short int)lpFormat->nSamplesPerSec,apidir) == FALSE)
    {
		DEBUGMSG( 1, (TEXT( "return bad sample rate:\r\n " )) );
		return MMSYSERR_NOTSUPPORTED;
    }   
	
	
	
	
	
    if (apidir == WAPI_OUT) {
        if (lpFormat->wBitsPerSample == 8) {
            if (lpFormat->nChannels == 1) {
                g_pfnFillBuffer = FillBufferM08toS16;
            }
            else {
                g_pfnFillBuffer = FillBufferS08toS16;
            }
        }
        else {
            if (lpFormat->nChannels == 1) {
                g_pfnFillBuffer = FillBufferM16toS16;
            }
            else {
                g_pfnFillBuffer = FillBufferS16toS16;
            }
        }
		g_ChannelDesc[apidir].dwDMASize = AUDIO_BUFFER_SIZE;
    }
    else {

	

        if (lpFormat->wBitsPerSample == 8) {
            if (lpFormat->nChannels == 1) {
                g_pfnGetBuffer = GetBufferM08fromM16;
            }
            else {
                g_pfnGetBuffer = GetBufferS08fromM16;
            }
        }
        else {
            if (lpFormat->nChannels == 1) {
                g_pfnGetBuffer = GetBufferM16fromM16;
            }
            else {
                g_pfnGetBuffer = GetBufferS16fromM16;
            }
        }
		
		
        
		// Support Low-latency Capture
        // Adjust the effective DMA buffer size, based on the requested sample rate.
        // The idea is that we want our DMA capture buffers to represent a fixed amount of time,
        // regardless of the sample rate.
        // This means that if the application buffers are small (as is the case with VoIP or DirectSoundCapture)
        // then we still can return the buffer very soon after we have enough captured data to fill it.
        // The way this used to work (fixed-size capture buffers) meant that at low sample rates
        // we would wait for hundreds of milliseconds, then turn around and discover that the application
        // had only given us 80 milliseconds of wave headers, so we would be forced to drop samples on the floor.
        
		g_ChannelDesc[WAPI_IN].dwDMASize = ((DWORD) g_ChannelDesc[apidir].wSrcBitsPerSample / 8 * (DWORD) g_ChannelDesc[apidir].wSrcNbChannels * (DWORD)lpFormat->nSamplesPerSec * (DWORD) g_dwCaptureLatency /1000);
        if (g_ChannelDesc[WAPI_IN].dwDMASize > AUDIO_BUFFER_SIZE) 
		{
			g_ChannelDesc[WAPI_IN].dwDMASize = AUDIO_BUFFER_SIZE;
        }
		
		
    }
	
    ResetAC97Controller(CODEC_WARM_RESET);

	//Enable DAC or ADC
	if(apidir == WAPI_OUT)
	{
		PowerDownUnit(PWR_PR1_DAC,FALSE);
		AudioOutMute(FALSE);
	}
	else
	{
	    AudioInMute(FALSE);   
		PowerDownUnit(PWR_PR0_ADC,FALSE);
		Sleep(100); //Give the Codec some time to settle
	}

	
    FUNC_VERBOSE("-PDD_WaveOpen");
	
    return MMSYSERR_NOERROR;
}


//------------------------------------------------------------------------------------------------------------
//! \brief process WPDM_xxx messages from the MDD.  This is the main message handler for the PDD.
//! return MMSYSERR_NOERROR if success or  MMSYSERR_NOTSUPPORTED if failure
//-------------------------------------------------------------------------------------------------------------
MMRESULT
PDD_WaveProc(
			 WAPI_INOUT apidir,
			 DWORD      dwCode,
			 DWORD      dwParam1,
			 DWORD      dwParam2
			 )
{
    MMRESULT mmRet = MMSYSERR_NOERROR;
    DEBUGMSG( ZONE_VERBOSE, (TEXT( "PDD_WaveProc: " )) );
	
    switch (dwCode) {
	case WPDM_CLOSE:
		if (apidir == WAPI_IN && g_ChannelDesc[apidir].bInUse) {
			// if app never send WODM_RESET, the capture DMA is still running. Stop it now.
			private_WaveInStop(NULL);
		}
		if (apidir == WAPI_IN)
		{
			AudioInMute(TRUE);
			PowerDownUnit(PWR_PR0_ADC,TRUE);
		}
		else
		{
			AudioOutMute(TRUE);
			PowerDownUnit(PWR_PR1_DAC,TRUE);
		}

		if (apidir < NUM_API_DIRS) g_ChannelDesc[apidir].bInUse = FALSE;
		DEBUGMSG( ZONE_VERBOSE, (TEXT( "....close %s\r\n" ),(apidir == WAPI_IN)?L"in":L"out") );
		break;
		
	case WPDM_CONTINUE:
		DEBUGMSG( ZONE_VERBOSE, (TEXT( "....continue %s\r\n" ),(apidir == WAPI_IN)?L"in":L"out") );
		if (apidir == WAPI_IN)
			private_WaveInContinue((PWAVEHDR) dwParam1);
		else
			private_WaveOutContinue((PWAVEHDR) dwParam1);
		break;
		
	case WPDM_GETDEVCAPS:
        DEBUGMSG( ZONE_VERBOSE, (TEXT( "....getdevcaps\r\n" )) );
		mmRet = private_WaveGetDevCaps(apidir, (PVOID) dwParam1, (UINT) dwParam2);
		break;
		
	case WPDM_OPEN:
        DEBUGMSG( ZONE_VERBOSE, (TEXT( "....open %s\r\n" ),(apidir == WAPI_IN)?L"in":L"out") );
		
		mmRet = private_WaveOpen(apidir, (LPWAVEFORMATEX) dwParam1, (BOOL) dwParam2);
		break;
		
	case WPDM_STANDBY:
        DEBUGMSG( ZONE_VERBOSE, (TEXT( "....standby\r\n" )) );
		private_WaveStandby (apidir);
		break;
		
	case WPDM_START:
        DEBUGMSG( ZONE_VERBOSE, (TEXT( "....start %s\r\n" ),(apidir == WAPI_IN)?L"in":L"out") );
		if (apidir == WAPI_IN)
			private_WaveInStart((PWAVEHDR) dwParam1);
		else
			private_WaveOutStart((PWAVEHDR) dwParam1);
		break;
		
	case WPDM_STOP:
        DEBUGMSG( ZONE_VERBOSE, (TEXT( "....stop  %s\r\n" ),(apidir == WAPI_IN)?L"in":L"out") );
		if (apidir == WAPI_IN)
			private_WaveInStop((PWAVEHDR) dwParam1);
		else
			private_WaveOutStop();
		break;
		
	case WPDM_PAUSE:
        DEBUGMSG( ZONE_VERBOSE, (TEXT( "....pause\r\n" )) );
		if (apidir == WAPI_OUT)
			private_WaveOutPause();
		else
			mmRet = MMSYSERR_NOTSUPPORTED;
		break;
		
	case WPDM_ENDOFDATA:
        DEBUGMSG( ZONE_VERBOSE, (TEXT( "....endofdata\r\n" )) );
		if (apidir == WAPI_OUT)
			private_WaveOutEndOfData();
		else
			mmRet = MMSYSERR_NOTSUPPORTED;
		break;
		
	case WPDM_RESTART:
        DEBUGMSG( ZONE_VERBOSE, (TEXT( "....restart\r\n" )) );
		if (apidir == WAPI_OUT)
			private_WaveOutRestart((PWAVEHDR) dwParam1);
		else
			mmRet = MMSYSERR_NOTSUPPORTED;
		break;
		
	case WPDM_GETVOLUME: //TODO:  use L3 to get volume
        DEBUGMSG( ZONE_VERBOSE, (TEXT( "....getvolume\r\n" )) );
		*((PULONG) dwParam1) = v_nVolume;
		break;
		
	case WPDM_SETVOLUME: //TODO:  use L3 to set volume
        DEBUGMSG( ZONE_VERBOSE, (TEXT( "....setvolume %d\r\n" ),(ULONG) dwParam1 ) );
		v_nVolume = (ULONG) dwParam1;
		AC97_SetOutVolume(v_nVolume);		
		break;
		
	default :
        DEBUGMSG( ZONE_VERBOSE, (TEXT( "....unsupported\r\n" )) );
		mmRet = MMSYSERR_NOTSUPPORTED;
		break;
    }
	
    return(mmRet);
			 }
			 
			 
//------------------------------------------------------------------------------------------------------------
//! \brief Convert the Windows Volume to an AC 97 volume and set it
//!
//! \return TRUE indicates success. FALSE indicates failure
//!
//-------------------------------------------------------------------------------------------------------------

BOOL AC97_SetOutVolume(ULONG uVolume)
{
    unsigned short int ucAC97VolL;
    unsigned short int ucAC97VolR;
    unsigned short int ucAC97VolBoth;
    unsigned short int ucAC97VolCur;
	
    // Windows Volume is 16 bits of Left and 16 bits of right (0xRRRRLLLL)
	
    ucAC97VolR=(unsigned short) (uVolume & 0x0000FFFF) >> 10; // six bits of volume
    ucAC97VolR=g_VolMatrix[ucAC97VolR];
	
    ucAC97VolL=(unsigned short) ((uVolume & 0xFFFF0000)>>16) >> 10;  //six bits of volume
    ucAC97VolL=g_VolMatrix[ucAC97VolL];
	
    ucAC97VolBoth=(ucAC97VolL<<8) | ucAC97VolR;
	
    ShadowReadAC97( HEADPHONE_VOLUME, &ucAC97VolCur );
	
    ucAC97VolCur &= 0xC0C0;  //only keep the upper 2 bits of each byte
    ucAC97VolBoth &= ~0xC0C0;  //only keep lower 6 bits of each byte
    ucAC97VolBoth |= ucAC97VolCur;  //add current volume bites
	
	
	return (ShadowWriteAC97(HEADPHONE_VOLUME, ucAC97VolBoth));
    //return TRUE;
	
}
//------------------------------------------------------------------------------------------------------------
//! \brief Convert the Windows Volume to an AC 97 volume and set it
//!
//! \return TRUE indicates success. FALSE indicates failure
//!
//-------------------------------------------------------------------------------------------------------------

BOOL AC97_SetInVolume(ULONG uVolume)
{
    unsigned short int ucAC97VolL;
    unsigned short int ucAC97VolR;
    unsigned short int ucAC97VolBoth;
    unsigned short int ucAC97VolCur;
	
    // Windows Volume is 16 bits of Left and 16 bits of right (0xRRRRLLLL)
	
    ucAC97VolR=(unsigned short) (uVolume & 0x0000FFFF) >> 10; // six bits of volume
    ucAC97VolR=g_VolMatrix[ucAC97VolR];
	
    ucAC97VolL=(unsigned short) ((uVolume & 0xFFFF0000)>>16) >> 10;  //six bits of volume
    ucAC97VolL=g_VolMatrix[ucAC97VolL];
	
    ucAC97VolBoth=(ucAC97VolL<<8) | ucAC97VolR;
	
    ShadowReadAC97( HEADPHONE_VOLUME, &ucAC97VolCur );
	
    ucAC97VolCur &= 0xC0C0;  //only keep the upper 2 bits of each byte
    ucAC97VolBoth &= ~0xC0C0;  //only keep lower 6 bits of each byte
    ucAC97VolBoth |= ucAC97VolCur;  //add current volume bites
	
	
	return (ShadowWriteAC97(HEADPHONE_VOLUME, ucAC97VolBoth));
    //return TRUE;
	
}

//------------------------------------------------------------------------------------------------------------
//! \brief Map the Bulverde device registers required for the audio driver.
//!
//! \return TRUE indicates success. FALSE indicates failure
//!
//-------------------------------------------------------------------------------------------------------------
static BOOL MapDeviceRegisters(void)
{
    PHYSICAL_ADDRESS RegPA;
	
    if (g_pAC97C == NULL)
    {
        RegPA.QuadPart = (UINT64) AT91C_BASE_AC97C;
        g_pAC97C = (AT91PS_AC97C) MmMapIoSpace(RegPA, sizeof(AT91S_AC97C), FALSE);
    }
    if (g_pPMC == NULL)
    {
        RegPA.QuadPart = (UINT64) AT91C_BASE_PMC;
        g_pPMC = (AT91PS_PMC) MmMapIoSpace(RegPA, sizeof(AT91S_PMC), FALSE);
    }
	
	if (!g_pAC97C || !g_pPMC)
    {
        DEBUGMSG(TRUE, (TEXT("ERROR:  Failed to allocate AC Link resources.\r\n")));
        UnmapDeviceRegisters();
        return(FALSE);
    }
	
	
    return(TRUE);
}

//------------------------------------------------------------------------------------------------------------
//! \brief UnMap the Bulverde device registers required for the audio driver.
//! \return TRUE indicates success. FALSE indicates failure
//-------------------------------------------------------------------------------------------------------------
static BOOL UnmapDeviceRegisters(void)
{
	
    if (g_pAC97C)
    {
        VirtualFree((void *)g_pAC97C, 0, MEM_RELEASE);
        g_pAC97C = NULL;
    }
	
    return(TRUE);
}



//------------------------------------------------------------------------------------------------------------
//! \brief Write the sample rate value to the ac97 codec
//-------------------------------------------------------------------------------------------------------------
short int AC97SetSampleRate(unsigned short int SampleRate, WAPI_INOUT apidir )
{
    short int RetVal=FALSE;
	
    switch(SampleRate)
    {
	case 8000:
	case 11025:
	case 16000:
	case 22050:
	case 32000:
	case 44100:
	case 48000:
		RetVal=TRUE;
		break;
	default:
		DEBUGCHK(0);  //we sent a bad rate
		RetVal=FALSE;
		return (RetVal);
		
		
    }
	
    //this write assumes that the
    if (apidir == WAPI_IN)
    {
        RetVal=ShadowWriteAC97((BYTE)AUDIO_ADC_RATE,(unsigned short int)(SampleRate & 0xFFFF)); //set the input sample rate
        LastSampleRateIn=SampleRate;
    }
    else
    {
        RetVal=ShadowWriteAC97((BYTE)AUDIO_DAC_RATE,(unsigned short int)(SampleRate & 0xFFFF)); //set the output sample rate
        LastSampleRateOut=SampleRate;
    }
	
    return (RetVal);
}

//------------------------------------------------------------------------------------------------------------
//! \brief Perform AC97 write and copy the write to a shadow register.  This helps performance by reducing the number of reads over the "slow" ac97 link
//!
//! \returns SUCCESS if there was a successful write to the AC97 codec
//!
//-------------------------------------------------------------------------------------------------------------
#define MAX_NB_TRY	3
short int ShadowWriteAC97(BYTE Offset, unsigned short int Data)
{
    //there are some values which should not be shadowed since the codec is volatile
    //TODO: return failure or warning on attempts to write values that shouldn't be shadowed
    
    BOOL RetVal;
    int i = 0;
	
	do 
	{
		if ((RetVal = g_pfnWriteAc97(Offset, Data)) == TRUE)
		{
			break;
		}
		i++;
	} while (i < MAX_NB_TRY);
	
    return(RetVal);
}


//------------------------------------------------------------------------------------------------------------
//! \brief \return a value from a shadowed ac97 codec register.
//-------------------------------------------------------------------------------------------------------------
short int ShadowReadAC97(BYTE Offset, unsigned short int *pData)
{
	
    BOOL RetVal;
	
    int i = 0;
	
	do 
	{
		if ((RetVal = g_pfnReadAc97(Offset,pData)) == TRUE)
		{
			break;
		}
		i++;
	} while (i < MAX_NB_TRY);
	
    return (RetVal);
}





//------------------------------------------------------------------------------------------------------------
//! \brief stops PDC (DMA) transfer
//-------------------------------------------------------------------------------------------------------------
BOOL  StopDmac(WAPI_INOUT wapidir)
{
    switch(wapidir)
    {
	case WAPI_IN:
		g_pAC97C->AC97C_PTCR = AT91C_PDC_RXTDIS;
		break;
		
	case WAPI_OUT:	
		g_pAC97C->AC97C_PTCR = AT91C_PDC_TXTDIS;
		break;
		
	default:
		return FALSE;
	}
	
    return(TRUE);
}

void Test_Read_AC97(void)
{
	unsigned short dwTemp = 0;

	ShadowReadAC97(RESET,&dwTemp);
	RETAILMSG(1,(TEXT("RESET = 0x%x\r\n"),dwTemp));
	ShadowReadAC97(MASTER_VOLUME,&dwTemp);
	RETAILMSG(1,(TEXT("MASTER_VOLUME = 0x%x\r\n"),dwTemp));
	ShadowReadAC97(HEADPHONE_VOLUME,&dwTemp);
	RETAILMSG(1,(TEXT("HEADPHONE_VOLUME = 0x%x\r\n"),dwTemp));
	ShadowReadAC97(MASTER_VOLUME_MONO,&dwTemp);
	RETAILMSG(1,(TEXT("MASTER_VOLUME_MONO = 0x%x\r\n"),dwTemp));
	ShadowReadAC97(MASTER_TONE_R_L,&dwTemp);
	RETAILMSG(1,(TEXT("MASTER_TONE_R_L = 0x%x\r\n"),dwTemp));
	ShadowReadAC97(PC_BEEP_VOLUME,&dwTemp);
	RETAILMSG(1,(TEXT("PC_BEEP_VOLUME = 0x%x\r\n"),dwTemp));
	ShadowReadAC97(PHONE_VOLUME,&dwTemp);
	RETAILMSG(1,(TEXT("PHONE_VOLUME = 0x%x\r\n"),dwTemp));
	ShadowReadAC97(MIC_VOLUME,&dwTemp);
	RETAILMSG(1,(TEXT("MIC_VOLUME = 0x%x\r\n"),dwTemp));
	ShadowReadAC97(LINE_IN_VOLUME,&dwTemp);
	RETAILMSG(1,(TEXT("LINE_IN_VOLUME = 0x%x\r\n"),dwTemp));
	ShadowReadAC97(CD_VOLUME,&dwTemp);
	RETAILMSG(1,(TEXT("CD_VOLUME = 0x%x\r\n"),dwTemp));
	ShadowReadAC97(VIDEO_VOLUME,&dwTemp);
	RETAILMSG(1,(TEXT("VIDEO_VOLUME = 0x%x\r\n"),dwTemp));
	ShadowReadAC97(AUX_VOLUME,&dwTemp);
	RETAILMSG(1,(TEXT("AUX_VOLUME = 0x%x\r\n"),dwTemp));
	ShadowReadAC97(PCM_OUT_VOL,&dwTemp);
	RETAILMSG(1,(TEXT("PCM_OUT_VOL = 0x%x\r\n"),dwTemp));
	ShadowReadAC97(RECORD_SELECT,&dwTemp);
	RETAILMSG(1,(TEXT("RECORD_SELECT = 0x%x\r\n"),dwTemp));
	ShadowReadAC97(RECORD_GAIN,&dwTemp);
	RETAILMSG(1,(TEXT("RECORD_GAIN = 0x%x\r\n"),dwTemp));
	ShadowReadAC97(GENERAL_PURPOSE,&dwTemp);
	RETAILMSG(1,(TEXT("GENERAL_PURPOSE = 0x%x\r\n"),dwTemp));
	ShadowReadAC97(CONTROL_3D,&dwTemp);
	RETAILMSG(1,(TEXT("CONTROL_3D = 0x%x\r\n"),dwTemp));
	ShadowReadAC97(POWERDOWN_CTRL_STAT,&dwTemp);
	RETAILMSG(1,(TEXT("POWERDOWN_CTRL_STAT = 0x%x\r\n"),dwTemp));
	ShadowReadAC97(EXTENDED_AUDIO_ID,&dwTemp);
	RETAILMSG(1,(TEXT("EXTENDED_AUDIO_ID = 0x%x\r\n"),dwTemp));
	ShadowReadAC97(EXTENDED_AUDIO_CTRL,&dwTemp);
	RETAILMSG(1,(TEXT("EXTENDED_AUDIO_CTRL = 0x%x\r\n"),dwTemp));
	ShadowReadAC97(AUDIO_DAC_RATE,&dwTemp);
	RETAILMSG(1,(TEXT("AUDIO_DAC_RATE = 0x%x\r\n"),dwTemp));
	ShadowReadAC97(AUDIO_ADC_RATE,&dwTemp);
	RETAILMSG(1,(TEXT("AUDIO_ADC_RATE = 0x%x\r\n"),dwTemp));
	ShadowReadAC97(VENDOR_ID1,&dwTemp);
	RETAILMSG(1,(TEXT("VENDOR_ID1 = 0x%x\r\n"),dwTemp));
	ShadowReadAC97(VENDOR_ID2,&dwTemp);
	RETAILMSG(1,(TEXT("VENDOR_ID2 = 0x%x\r\n"),dwTemp));

	return;
}

//! @}

//! @}
