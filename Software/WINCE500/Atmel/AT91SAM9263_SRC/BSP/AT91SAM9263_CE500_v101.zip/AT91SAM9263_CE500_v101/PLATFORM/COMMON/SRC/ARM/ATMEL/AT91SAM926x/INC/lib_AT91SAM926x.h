//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		lib_AT91SAM926x.h
//!
//! \brief		definitions for the AT91SAM926x processors. This file will include the ATMEL's file
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/lib_AT91SAM926x.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//-----------------------------------------------------------------------------


#ifndef LIB_AT91SAM926X_H
#define LIB_AT91SAM926X_H

#if   defined   PROC_AT91SAM9260
#include "lib_at91sam9260.h"
#elif   defined   PROC_AT91SAM9261
#include "lib_at91sam9261.h"
#elif defined   PROC_AT91SAM9262
#include "lib_at91sam9262.h"
#elif defined   PROC_AT91SAM9263
#include "lib_at91sam9263.h"
#else
#error A Processor must be defined
#endif



#endif //LIB_AT91SAM926X_H

//! @}


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/lib_AT91SAM926x.h $
////////////////////////////////////////////////////////////////////////////////
//
