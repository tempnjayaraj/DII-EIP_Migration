//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x/INC/LCDC/Core.h
//!
//! \brief		Declaration of __LCDC62hw__ class, heritating from DDGPE abstract class
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/LCDC/Core.h $
//!   $Author: pblanchard $
//!   $Revision: 993 $
//!   $Date: 2007-06-12 08:36:50 -0700 (Tue, 12 Jun 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	LCDC
//! @{
//!

#ifndef __CoreLCDC6xhw__
#define __CoreLCDC6xhw__


//! \addtogroup Core
//! @{


//__CALLSTATS__ is used to get some statistics about the drawing order used by CE 
//#define __CALLSTATS__ 1
	
// Dependencies
#include "hwSurf.h"

#define MIN(x,y) ((x)<(y) ? (x) :(y))
#define MAX(x,y) ((x)>(y) ? (x) :(y))


// Blt & Line callback format
#define GPEBLT (SCODE (GPE::* )(GPEBltParms *))
#define GPELINE (SCODE (GPE::* )(GPELineParms *))


// CE uses a 32 x 32 pixel cursor.
#define CURSOR_XSIZE		32
#define CURSOR_YSIZE		32
#define CURSOR_SIZE			(CURSOR_XSIZE * CURSOR_YSIZE)



// Class
class LCDC6xhw : public DDGPE
{
public:
	// Constructor / Destructor
	    				LCDC6xhw(DWORD dwVideoMemStartAddress, DWORD dwVideoMemHeight, DWORD dwVideoMemWidth);
	virtual				~LCDC6xhw();

	// Configuration methods
	
	void				ReadRegistryChipConfig();
	void				ChipConfig();
	virtual SCODE		GetModeInfo		(GPEMode* pMode, int modeNo);
	virtual int			NumModes		();
	virtual SCODE		SetMode			(int modeId, HPALETTE* pPaletteHandle);
			ULONG*		GetMasks		();
	virtual	DWORD		QueryMode		(DWORD dwDefaultMode);
	virtual void Config2DEngine(void) {};
	// Blit methods
	virtual SCODE		BltPrepare		(GPEBltParms *pBltParms);
	virtual SCODE		DoBlt			(GPEBltParms *pBltParms);
	virtual	SCODE		DrawBlt			(GPEBltParms *pBltParms);
	virtual SCODE		BltComplete		(GPEBltParms *pBltParms);

	virtual SCODE		Line			(GPELineParms *pLineParms, EGPEPhase phase = gpeSingle);
	virtual	SCODE       CursorsWrappedDrawLine  (GPELineParms *pParms);	
	virtual SCODE		DrawLine			(GPELineParms *pLineParms);

	// Surface creation method
	virtual SCODE		AllocSurface	(GPESurf **ppSurf, int width, int height, EGPEFormat format, int surfaceFlags);
	virtual SCODE		AllocSurface	(DDGPESurf **ppSurf, int width, int height, EGPEFormat format, EDDGPEPixelFormat pixelFormat, int surfaceFlags);

	// Cursor methods
	virtual SCODE		SetPointerShape	(GPESurf* pMask, GPESurf* pColorSurf, int xHot, int yHot, int cx, int cy);
	virtual SCODE		MovePointer		(int x, int y);

	// Palette methods
	virtual SCODE		SetPalette		(const PALETTEENTRY* src, unsigned short firstEntry, unsigned short numEntries);

	// Timing method
	virtual int			InVBlank		();
	virtual void		WaitForVBlank(BOOL bWaitForendOfVBlank = FALSE);

	// Access to frame buffer
	void GetVirtualVideoMemory			(DWORD* pMem, DWORD* Size){*pMem = (DWORD)m_pPrimarySurface->Buffer(); *Size = (m_VidMemSizeInPxl * m_pMode->Bpp)/8	;};
	void GetPhysicalVideoMemory			(DWORD *pPhysicalMemoryBase,DWORD *pVideoMemorySize);
	void SetVisibleSurface				(GPESurf *pTempSurf);
	void SetVisibleSurface				(GPESurf *pTempSurf, BOOL bWaitForVBlank);

	int					GetBpp();

	virtual void		CursorOff();
	virtual void		CursorOn();

	int GetRotateModeFromReg();
    void SetRotateParams();
	LONG DynRotate( int angle);
	virtual ULONG DrvEscape(SURFOBJ *pso, ULONG    iEsc, ULONG    cjIn, PVOID    pvIn, ULONG    cjOut, PVOID    pvOut);
	// Friend
	friend void			buildDDHALInfo	(LPDDHALINFO lpddhi, DWORD modeidx);
	friend DWORD CStyleThreadProcCursor(void* Parm);
	
	int LcdlErrorHandler(void);	

	virtual void ApplyPowerState(CEDEVICE_POWER_STATE m_Dx);

	// Some public variables :
	bool				m_InDDraw;

	// Video memory managment
	Node2D				*m_pAllVidMem;
	void*				m_pVirtVidMemAddr;
	DWORD				m_pPhyVidMemAddr;
	DWORD				m_VidMemStrideByte;		// All VidMem got the same Stride & Bpp
	DWORD				m_VidMemSizeInPxl;
	DWORD				m_VidMemBpp;

	// Chip Configuration
	DWORD	m_dwUpperMargin;
	DWORD	m_dwLowerMargin;
	DWORD	m_dwLeftMargin;
	DWORD	m_dwRightMargin;
	DWORD	m_dwPixelClock;
	DWORD	m_dwVsync;
	DWORD	m_dwHsync;

protected:

	// Variables
	AT91PS_LCDC		m_pLCDC;
	CRITICAL_SECTION	m_CursorCs;

    BOOL            m_CursorDisabled;
    BOOL            m_CursorVisible;
    BOOL            m_CursorForcedOff;
    POINTL          m_CursorSize;
    RECTL           m_CursorRect;

    

	RECT			gCursorRect;	

	DWORD			m_xHot;
	DWORD			m_yHot;
	
	//WORD	        m_CursorBackingStore[CURSOR_SIZE];
	//WORD			gCursorData[CURSOR_SIZE];
	//WORD			gCursorMask[CURSOR_SIZE];

	GPESurf*		pSurfCursorColor;
	GPESurf*		pSurfCursorMask;
	GPESurf*		pSurfCursorXOR;
	GPESurf*		pSurfBackingStore;

	DWORD			dwSysIntr;
	HANDLE			hEvent;

	// Functions
	void			CheckDisableCursor(GPEBltParms* pBltParms);

private:
	// Variables
	HANDLE			hLCDCIntrEvent;
	HANDLE			hLCDCThreadIntr;
	BOOL			m_bForceRGB;
	BOOL			m_bFBisCached;
	CEDEVICE_POWER_STATE m_Dx;
		
	// Functions
	void InitLut();
	void ChangeFramePointer(DWORD PhysicalAddress);
	BOOL AdvertisePowerInterface(HMODULE hInst);
	BOOL  ConvertStringToGuid (LPCTSTR pszGuid, GUID *pGuid);
	void InitCursor();
};



#endif //__CoreLCDC6xhw__

//! @}


//! @}


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/LCDC/Core.h $
////////////////////////////////////////////////////////////////////////////////
//
//! @}
