//------------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//   All rights reserved ADENEO SAS 2005
//!
//------------------------------------------------------------------------------
//! \file		Serial_SAM926X_HW.h
//!
//! \if subversion
//!   @URL: $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/Serial/Serial_SAM926X_HW.h $
//!   @author $Author: pblanchard $
//!   @version $Revision: 1097 $
//!   @date $Date: 2007-07-16 04:59:19 -0700 (Mon, 16 Jul 2007) $
//! \endif
//------------------------------------------------------------------------------
//! \addtogroup	Serial
//! @{
    
#ifndef __SERIAL_SAM926X_HW_H_
#define __SERIAL_SAM926X_HW_H_

//------------------------------------------------------------------------------
//                                                                      Includes
//------------------------------------------------------------------------------
// Only project includes
#include "Serial_SAM926X.h"

//------------------------------------------------------------------------------
//                                                             Defines and types
//------------------------------------------------------------------------------
	VOID  HWSetBreak				(T_SERIAL_INIT_STRUCTURE *pInitContext);
	VOID  HWClearBreak				(T_SERIAL_INIT_STRUCTURE *pInitContext);
	VOID  HWSetDTR					(T_SERIAL_INIT_STRUCTURE *pInitContext);
	VOID  HWClearDTR				(T_SERIAL_INIT_STRUCTURE *pInitContext);
	VOID  HWSetRTS					(T_SERIAL_INIT_STRUCTURE *pInitContext);
	VOID  HWClearRTS				(T_SERIAL_INIT_STRUCTURE *pInitContext);
	DWORD HWReadCSR					(T_SERIAL_INIT_STRUCTURE *pInitContext);
	VOID  HWClearCSR				(T_SERIAL_INIT_STRUCTURE *pInitContext);

	// Hardware stream interface
	BOOL  HWInit					(T_SERIAL_INIT_STRUCTURE *pInitContext);
	BOOL  HWDeinit					(T_SERIAL_INIT_STRUCTURE *pInitContext);
	BOOL  HWOpen					(T_SERIAL_INIT_STRUCTURE *pInitContext);
	BOOL  HWClose					(T_SERIAL_INIT_STRUCTURE *pInitContext);	

	// Hardware mode configuration
	BOOL  HWSetParity				(T_SERIAL_INIT_STRUCTURE *pInitContext, DWORD dwParity);
	BOOL  HWSetStopBits				(T_SERIAL_INIT_STRUCTURE *pInitContext, DWORD dwStopBits);
	BOOL  HWSetByteSize				(T_SERIAL_INIT_STRUCTURE *pInitContext, DWORD dwByteSize);
	VOID  HWSetCommTimeouts			(T_SERIAL_INIT_STRUCTURE *pInitContext, LPCOMMTIMEOUTS lpCommTimeouts);
	VOID  HWClearCommTimeouts		(T_SERIAL_INIT_STRUCTURE *pInitContext);
	BOOL  HWSetBaudRate				(T_SERIAL_INIT_STRUCTURE *pInitContext, DWORD dwBaudRate);
	BOOL  HWSetMode					(T_SERIAL_INIT_STRUCTURE *pInitContext, DWORD dwfRtsControl, DWORD dwfDtrControl);
	
	// PDC register access
	VOID  HWSetRxDmaRegisterNextValue(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure, DWORD dwRNPR, DWORD dwRNCR);
	VOID  HWSetTxDmaRegisterNextValue(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure, DWORD dwTNPR, DWORD dwTNCR);
	
	VOID  HWSetRxDmaRegisterValue	(T_SERIAL_INIT_STRUCTURE *pInitContext, DWORD dwRPR, DWORD dwRCR, DWORD dwRNPR, DWORD dwRNCR);
	VOID  HWSetTxDmaRegisterValue	(T_SERIAL_INIT_STRUCTURE *pInitContext, DWORD dwTPR, DWORD dwTCR, DWORD dwTNPR, DWORD dwTNCR);

	//---- Interrupt function
	// Get interrupt status
	DWORD HWGetInterruptStatus				(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);
	
	VOID  HWEnableRxInterrupt				(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);
	VOID  HWEnableTxInterrupt				(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);
	VOID  HWEnableRxENDInterrupt			(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);
	VOID  HWEnableRxBUFFInterrupt			(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);
	VOID  HWEnableTimeOutInterrupt			(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);
	VOID  HWEnableRxBreakInterrupt			(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);
	VOID  HWEnableFrameErrorInterrupt		(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);
	VOID  HWEnableParityErrorInterrupt		(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);
	VOID  HWEnableDataCarrierDetectInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);

	VOID  HWDisableRxInterrupt				(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);
	VOID  HWDisableRxENDInterrupt			(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);
	VOID  HWDisableRxBUFFInterrupt			(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);
	VOID  HWDisableTxENDInterrupt			(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);
	VOID  HWDisableTxEMPTYInterrupt			(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);
	VOID  HWDisableTimeOutInterrupt			(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);
	VOID  HWDisableRxBreakInterrupt			(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);
	VOID  HWDisableFrameErrorInterrupt		(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);
	VOID  HWDisableParityErrorInterrupt		(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);
	VOID  HWDisableDataCarrierDetectInterrupt(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);

	// Receive & transmit enable & disable
	VOID  HWEnableReceive			(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);
	VOID  HWDisableReceive			(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);
	VOID  HWEnableTransmit			(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);
	VOID  HWDisableTransmit			(T_SERIAL_INIT_STRUCTURE *pSerialInitStructure);

	// Hardware apply DCB
	BOOL  HWSetDCB					(T_SERIAL_INIT_STRUCTURE *pInitContext, DCB *pDCB);

	// Hardware purge 
	VOID HWPurgeRxBuffers			(T_SERIAL_OPEN_STRUCTURE *);
	VOID HWPurgeTxBuffers			(T_SERIAL_OPEN_STRUCTURE *);

#endif	// __SERIAL_SAM926X_HW_H_

//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/Serial/Serial_SAM926X_HW.h $
//------------------------------------------------------------------------------
//

//
//! @}
//
//! @}
