//-----------------------------------------------------------------------------
//! \addtogroup   USBFN
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				AT91RM9200_usbfn_endpoint.h
//!
//! \brief				Declaration for the generic endpoint
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/DRIVERS/USBFN/AT91RM9200_usbfn_endpoint.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//! Implementation of the AT91RM9200 USB Device object
//! 
//-----------------------------------------------------------------------------

#include <csync.h>
#include <cmthread.h>
#include <CRegEdit.h>
#include <CRefCon.h>
#include <usbfn.h>
#include "AT91RM9200_usbfn.h"


#define AT91RM9200_END_OF_TRANSFER 1
#define MIN(x,y) ((x)>(y) ? (y) : (x))

typedef void (*T_CTRL_CALLBACK) (AT91RMEndpoint*,DWORD);
class CtrlCallBackInfo
{
public:
	CtrlCallBackInfo(AT91RMEndpoint* pContext,T_CTRL_CALLBACK pFnCallBack,DWORD dwParam)
	{
		m_dwParam = dwParam;
		m_pContext = pContext;
		m_pFnCallBack = pFnCallBack;
	}
public:
	DWORD m_dwParam;
	AT91RMEndpoint* m_pContext;
	T_CTRL_CALLBACK m_pFnCallBack;
};


class AT91RMEndpoint: public CRefObject , public CLockObject 
{
public :
    AT91RMEndpoint(AT91RMUsbDevice * const pUsbDevice, const DWORD dwPipeIndex) 
    :   m_pUsbDevice(pUsbDevice)
    ,   m_dwEndpointIndex(dwPipeIndex)
    {
		m_pCallBackInfo = NULL;
        m_pCurTransfer = NULL;
		m_bIgnoreNextHandshakeFromMDD = FALSE;
    }
    virtual ~AT91RMEndpoint() 
	{
        if (m_pUsbDevice)
            m_pUsbDevice->EnableEndpointInterrupt(m_dwEndpointIndex,FALSE);
    }
    virtual BOOL Init(PUSB_ENDPOINT_DESCRIPTOR pEndpointDesc,
            BYTE bConfigurationValue, BYTE bInterfaceNumber, BYTE bAlternateSetting);
//    virtual BOOL ReInit();
    
    // Supported Function.
    virtual DWORD InitEndpoint(UFN_BUS_SPEED Speed,PUSB_ENDPOINT_DESCRIPTOR pEndpointDesc) 
	{
		
        return Init(pEndpointDesc,0,0,0)?ERROR_SUCCESS:ERROR_GEN_FAILURE;
    }
    virtual DWORD DeinitEndpoint() 
	{
        return (m_pUsbDevice->EnableEndpointInterrupt(m_dwEndpointIndex,FALSE)?ERROR_SUCCESS:ERROR_GEN_FAILURE);
    }
    virtual DWORD StallEndpoint();
    virtual DWORD ClearEndpointStall();
    virtual DWORD ResetEndpoint();
	virtual BOOL ReInitEndpoint();
    virtual DWORD IsEndpointHalted(PBOOL pfHalted );
    virtual DWORD IssueTransfer(PSTransfer pTransfer ) ;
    virtual DWORD AbortTransfer(PSTransfer pTransfer );
	virtual void SetAddressCompleted(DWORD dwParam){}
	virtual void SetConfigurationCompleted(DWORD dwParam){}
    virtual DWORD SendControlStatusHandshake(CtrlCallBackInfo* pCallBackInfo = NULL) { return ERROR_INVALID_PARAMETER; };
    // Attribute.
    USB_ENDPOINT_DESCRIPTOR GetEndpointDescriptor() { return m_epDesc; };
    // IST
    virtual DWORD   IST(DWORD dwIRBit) = 0 ;
	DWORD GetInterruptMask() { return 1<<m_dwEndpointIndex;};
protected:
    AT91RMUsbDevice * const    m_pUsbDevice;
    const DWORD             m_dwEndpointIndex;
    USB_ENDPOINT_DESCRIPTOR m_epDesc;
    PSTransfer      m_pCurTransfer;
	BOOL			m_bIgnoreNextHandshakeFromMDD;
    
	BOOL            m_fZeroPacket;
    BOOL            m_fStalled;
//  Help Function.
    void CompleteTransfer(DWORD dwError);
    void SendFakeFeature(BYTE bReuqest,WORD wFeatureSelector);
    DWORD XmitData(PBYTE pBuffer, DWORD dwLength);
    DWORD ReceiveData(PBYTE pBuffer, DWORD dwLength);
	CtrlCallBackInfo* m_pCallBackInfo;
};


AT91RMUsbDevice * CreateAT91RMUsbDevice(LPCTSTR lpActivePath);




//! @}