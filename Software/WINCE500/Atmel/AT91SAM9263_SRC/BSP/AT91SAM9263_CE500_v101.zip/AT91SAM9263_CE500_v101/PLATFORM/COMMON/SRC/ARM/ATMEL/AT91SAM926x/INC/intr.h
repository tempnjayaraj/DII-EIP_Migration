//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		intr.h
//!
//! \brief		Interrupt management header file
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/intr.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//-----------------------------------------------------------------------------


// Profiler ISR function pointer type.
//
typedef UINT32 (*PFN_PROFILER_ISR)(UINT32 ra);


//! @}


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/intr.h $
////////////////////////////////////////////////////////////////////////////////
//
