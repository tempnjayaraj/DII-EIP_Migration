//-----------------------------------------------------------------------------
//! \addtogroup	PWM_TC
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x_pwm_ioctl.h
//!
//! \brief		IOCTL for the Pwm driver
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/IOCTL/AT91SAM926x_pwm_ioctl.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//-----------------------------------------------------------------------------

#ifndef __AT91SAM926X_PWM_IOCTL_H__
#define __AT91SAM926X_PWM_IOCTL_H__

#define PWM_FUNCTION_CONFIG		2048
#define PWM_FUNCTION_START		2049
#define PWM_FUNCTION_STOP		2050

//! \brief Configuration of PWM signal.
#define IOCTL_PWM_CONFIG			CTL_CODE(FILE_DEVICE_CONTROLLER,PWM_FUNCTION_CONFIG,METHOD_BUFFERED,FILE_ANY_ACCESS)

//! 	\brief Start the PWM.
#define IOCTL_PWM_START				CTL_CODE(FILE_DEVICE_CONTROLLER,PWM_FUNCTION_START,METHOD_BUFFERED,FILE_ANY_ACCESS)

//! 	\brief Stop the PWM.
#define IOCTL_PWM_STOP				CTL_CODE(FILE_DEVICE_CONTROLLER,PWM_FUNCTION_STOP,METHOD_BUFFERED,FILE_ANY_ACCESS)

//! \brief Parameter for the IOCTL_PWM_CONFIG command
typedef struct {
	DWORD dwDutyCycleA; //!<Duty Cycle A in % (from 0 to 100)
	DWORD dwDutyCycleB; //!<Duty Cycle B in % (from 0 to 100)
	DWORD dwFrequency;  //!<Frequency in Hz
} T_IOCTLPWM_CONFIG;

#endif // #ifndef__AT91SAM926X_PWM_IOCTL_H__


/* The file has been moved, this is the historique before the movement
// History : Revision 1.4  2006/01/31 14:18:37  jjhiblot
// History : Mise en forme Doxygen
// History :
// History : Revision 1.3  2005/11/18 15:18:46  jjhiblot
// History : Enhanced and fixed doxygen support
// History :
// History : Revision 1.2  2005/08/03 09:17:19  nbesson
// History : Modified comments
// History :
// History : Revision 1.1  2005/08/02 09:55:31  lvilquin
// History : *** empty log message ***
// History :

*/




//! @}
////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/INC/IOCTL/AT91SAM926x_pwm_ioctl.h $
////////////////////////////////////////////////////////////////////////////////
//
