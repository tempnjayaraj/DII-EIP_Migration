//-----------------------------------------------------------------------------
//! \addtogroup   USBFN
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				AT91RM9200_usbfn_endpoint_out.h
//!
//! \brief				Declaration for the OUT endpoint
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/DRIVERS/USBFN/AT91RM9200_usbfn_endpoint_OUT.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

#include <csync.h>
#include <cmthread.h>
#include <CRegEdit.h>
#include <CRefCon.h>
#include <usbfn.h>

class AT91RMEndpoint;

#define MAX_TRANSFER	10


#define INC_MODULO(x,y) (((x)+1) < (y) ? ((x)+1) : 0)




typedef struct {
	DWORD dwListMaxSize;
	DWORD dwNbTransferInList;
	DWORD dwFirstTransferIndex;
	DWORD dwNextTransferIndex;
	CRITICAL_SECTION cs;
	PSTransfer *pTransferArray;
} T_TRANSFER_FIFO;




typedef struct{
	BOOL bEnableReceive;
	BOOL bDataReceived;
	DWORD dwLength;
	UCHAR buffer[0x3000];
} T_USB_OUT_PACKET;

enum T_BANK_NUMBER {
	BANK_0,
	BANK_1
} ;

class AT91RMEndpointOut : public AT91RMEndpoint  
{
public:
	DWORD IssueTransfer(PSTransfer pTransfer);
	BOOL Init(PUSB_ENDPOINT_DESCRIPTOR pEndpointDesc,
            BYTE bConfigurationValue, BYTE bInterfaceNumber, BYTE bAlternateSetting);   
    AT91RMEndpointOut(AT91RMUsbDevice * const pUsbDevice,DWORD dwEndpointIndex)
        : AT91RMEndpoint(pUsbDevice, dwEndpointIndex ) 
    {
		
		
		CreateNewTransferFifo(MAX_TRANSFER,&InitiatedTransferFifo);
		
		ResetFifo(&InitiatedTransferFifo);
		
		m_CurrentBank = BANK_0;
    }
    DWORD   IST(DWORD dwIRBit) ;
	void CompleteTransfer(DWORD dwError);
private:
	T_BANK_NUMBER m_CurrentBank;


	//! Fifo used to keep track of Transfers being recorded (already in the DMA list)
	
	T_TRANSFER_FIFO   InitiatedTransferFifo;
	T_USB_OUT_PACKET* pOutPacketDesc;

	
	


	
//-----------------------------------------------------------------------------
//! \brief		This function creates a new Fifo
//! \param		dwNbTransfer the number of Transfer that the fifo can handle
//! \param		pFifo	   a pointer to the fifo structure that will be initialized
//-----------------------------------------------------------------------------
BOOL CreateNewTransferFifo(DWORD dwNbTransfer,T_TRANSFER_FIFO* pFifo)
{
	if (pFifo == NULL)
	{
		return FALSE;
	}
	
	pFifo->dwListMaxSize = dwNbTransfer;
	pFifo->pTransferArray = (PSTransfer*) malloc(dwNbTransfer*sizeof(PSTransfer));
	if (pFifo->pTransferArray == NULL)
	{
		return FALSE;
	}
	InitializeCriticalSection(&pFifo->cs);
	
	pFifo->dwNbTransferInList = 0;
	pFifo->dwFirstTransferIndex = 0;
	pFifo->dwNextTransferIndex = 0;
	
	return TRUE;
}
//-----------------------------------------------------------------------------
//! \brief		This function resets a fifo
//! \param		pFifo	   a pointer to the fifo structure that will be reset
//!
//! The fifo is emptied. There's no need to create the fifo again. It's still ready to use
//-----------------------------------------------------------------------------
BOOL ResetFifo(T_TRANSFER_FIFO* pFifo)
{
	if (pFifo == NULL)
	{
		return FALSE;
	}
	
	EnterCriticalSection(&pFifo->cs);
	pFifo->dwNbTransferInList = 0;
	pFifo->dwFirstTransferIndex = 0;
	pFifo->dwNextTransferIndex = 0;
	LeaveCriticalSection(&pFifo->cs);
	
	return TRUE;
}


//-----------------------------------------------------------------------------
//! \brief		This function deletes a fifo
//! \param		pFifo	   a pointer to the fifo structure that will be deleted
//!
//! The fifo is emptied. All allocations are released.
//-----------------------------------------------------------------------------
BOOL DeleteTransferFifo(T_TRANSFER_FIFO* pFifo)
{
	if (pFifo == NULL)
	{
		return FALSE;
	}
	
	EnterCriticalSection(&pFifo->cs);
	free(pFifo->pTransferArray);	
	pFifo->pTransferArray = NULL;
	pFifo->dwNbTransferInList = 0;
	pFifo->dwFirstTransferIndex = 0;
	pFifo->dwNextTransferIndex = 0;	
	pFifo->dwListMaxSize = 0;
	LeaveCriticalSection(&pFifo->cs);
	DeleteCriticalSection(&pFifo->cs);
	return TRUE;
}


//-----------------------------------------------------------------------------
//! \brief		This function gets the first Transfer of the list and remove it from the fifo
//! \param		pFifo	   a pointer to the fifo structure that will be deleted
//!
//! \return  A pointer to the first Transfer of the fifo if it's not empty, else NULL
//-----------------------------------------------------------------------------
PSTransfer PopTransfer(T_TRANSFER_FIFO* pFifo)
{
	PSTransfer pResult = NULL;
	
	if (pFifo == NULL)
	{
		return NULL;
	}
	
	EnterCriticalSection(&pFifo->cs);
	
	if (pFifo->dwNbTransferInList != 0)
	{
		pResult = pFifo->pTransferArray[pFifo->dwFirstTransferIndex];		
		pFifo->dwFirstTransferIndex = INC_MODULO(pFifo->dwFirstTransferIndex,pFifo->dwListMaxSize);		
		pFifo->dwNbTransferInList--;
	}
	LeaveCriticalSection(&pFifo->cs);
	
	return pResult;
}

//-----------------------------------------------------------------------------
//! \brief		This function gets the first Transfer of the list and remove it from the fifo
//! \param		pFifo	   a pointer to the fifo structure that will be deleted
//! \param		pTransfer		a pointer to the Transfer that must be stored in the fifo
//!
//! \return  TRUE indicates success, FALSE indicates failure
//-----------------------------------------------------------------------------
BOOL PushTransfer(T_TRANSFER_FIFO* pFifo,PSTransfer pTransfer)
{
	BOOL bResult = FALSE;
	if (pFifo == NULL)
	{
		return FALSE;
	}
	
	EnterCriticalSection(&pFifo->cs);
	
	if (pFifo->dwNbTransferInList < pFifo->dwListMaxSize)
	{
		pFifo->pTransferArray[pFifo->dwNextTransferIndex] = pTransfer;
		pFifo->dwNextTransferIndex = INC_MODULO(pFifo->dwNextTransferIndex,pFifo->dwListMaxSize);		
		pFifo->dwNbTransferInList++;
		bResult = TRUE;
	}
	LeaveCriticalSection(&pFifo->cs);
	
	return bResult;
}
};

//! @}