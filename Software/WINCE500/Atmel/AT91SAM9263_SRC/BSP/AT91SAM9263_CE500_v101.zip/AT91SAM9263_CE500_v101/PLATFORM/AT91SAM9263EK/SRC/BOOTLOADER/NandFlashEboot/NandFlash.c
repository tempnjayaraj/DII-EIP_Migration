//-----------------------------------------------------------------------------
//! \addtogroup	DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9263EK/SRC/BOOTLOADER/NandFlashEboot/NandFlash.c
//!
//! \brief		NandFlash driver for AT91SAM926x chipset
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/BOOTLOADER/NandFlashEBOOT/NandFlash.c $
//!   $Author: ltourlonias $
//!   $Revision: 657 $
//!   $Date: 2007-04-10 16:52:09 +0200 (mar., 10 avr. 2007) $
//! \endif
//!
//! 
//-----------------------------------------------------------------------------
//! \addtogroup	NandFlash
//! @{
//!

// System specific include
#include <windows.h>
#include <nkintr.h>
#include <oal.h>
#include <fmd.h>

// Platform specific include
#include "at91sam926x_oal_ioctl.h"

#include "at91sam9263_gpio.h"
#include "at91sam926x.h"
#include "at91sam926x_interface.h"

#include "at91sam9263ek.h"
#include "at91sam9263_oal_intr.h"

#include "NandFlash.h"


#define AT91C_NAND_ENABLE_PIN	AT91C_PIO_PC15
#define AT91C_NAND_READY_PIN	AT91C_PIO_PC22
#define AT91C_NAND_ALE			(1<<21)
#define AT91C_NAND_CLE			(1<<22)

static volatile AT91PS_PIO pPIOD = NULL; //!< PIO port C register
static volatile AT91PS_PIO pPIOA = NULL; //!< PIO port A register

static void tempo(volatile DWORD j)
{
	while(j--);
}

static void NandFlash_Enable(NandChip * pChip)
{
	pPIOD->PIO_CODR = AT91C_NAND_ENABLE_PIN;
	tempo(10);
}

static void NandFlash_Disable(NandChip * pChip)
{
	tempo(10);
	pPIOD->PIO_SODR = AT91C_NAND_ENABLE_PIN;
}

static BOOL NandFlash_IsReady(NandChip * pChip)
{
	return (pPIOA->PIO_PDSR & AT91C_NAND_READY_PIN) ? TRUE : FALSE;
}

void NandFlashPlaftorm_PioSetup(NandChip *pChip)
{
	pPIOD = (AT91PS_PIO) OALPAtoVA((DWORD)AT91C_BASE_PIOD, FALSE);
	pPIOA = (AT91PS_PIO) OALPAtoVA((DWORD)AT91C_BASE_PIOA, FALSE);

	// Configure Ready/Busy signal on PIOA 22
	pPIOA->PIO_ODR = AT91C_NAND_READY_PIN;
	pPIOA->PIO_PER = AT91C_NAND_READY_PIN;
	pPIOA->PIO_PPUER = AT91C_NAND_READY_PIN;
	
	// ChipEnable for NAND
	pPIOD->PIO_OER = AT91C_NAND_ENABLE_PIN;
	pPIOD->PIO_PER = AT91C_NAND_ENABLE_PIN;

	pChip->NFIface.Enable = NandFlash_Enable;
	pChip->NFIface.Disable = NandFlash_Disable;
	pChip->NFIface.IsReady = NandFlash_IsReady;
}

void NandFlashPlatform_Init(NandChip *pChip)
{
	/* pChip->dwPhyNandAleAddr is set by FMD, so we can use it */
	pChip->dwPhyNandAleAddr	= pChip->dwPhyNandBaseAddr + AT91C_NAND_ALE;
	pChip->dwPhyNandCleAddr	= pChip->dwPhyNandBaseAddr + AT91C_NAND_CLE;
}

// End of Doxygen group NandFlash Driver
//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/BOOTLOADER/NandFlashEBOOT/NandFlash.c $
//-----------------------------------------------------------------------------
//
//! @}
