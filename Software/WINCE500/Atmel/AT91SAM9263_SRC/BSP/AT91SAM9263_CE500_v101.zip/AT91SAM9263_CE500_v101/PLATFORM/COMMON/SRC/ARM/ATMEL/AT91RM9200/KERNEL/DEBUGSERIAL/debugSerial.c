//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91RM9200\KERNEL\DEBUGSERIAL\debugSerial.c
//!
//! \brief		AT91RM9200's debug serial feature
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/KERNEL/DEBUGSERIAL/debugSerial.c $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------


#include <windows.h>
#include <oal.h>
#include <nkintr.h>

#include "at91RM9200.h"
#include "AT91RM9200_interface.h"
#include "lib_AT91RM9200.h"

#define DBGU_BAUDRATE	(115200)

/// pointer to the Debug Serial controller
AT91PS_DBGU g_pDBGU = NULL;


///This function sets the pointer to the Debug Serial controller
void AT91RM9200_SetDebugSerialInterface(AT91PS_DBGU pDBGU)
{
	g_pDBGU = pDBGU;
}

//-----------------------------------------------------------------------------
//! \fn		void OEMInitDebugSerial ()
//!
//! \brief	This function initializes the debug serial port of the AT91RM9200
//! 
//-----------------------------------------------------------------------------
void OEMInitDebugSerial ()
{
	DWORD			dwMasterClock;
	AT91PS_PIO		pPIOA = OALPAtoVA((DWORD) AT91C_BASE_PIOA,FALSE);	

    if (g_pDBGU == NULL)
    {
        g_pDBGU = OALPAtoVA((DWORD) AT91C_BASE_DBGU,FALSE);
    }
 
	dwMasterClock = AT91RM9200_GetMasterClock(FALSE);

   	// Open PIO for DBGU
	pPIOA->PIO_PDR = (AT91C_PA31_DTXD | AT91C_PA30_DRXD);
	pPIOA->PIO_ASR = (AT91C_PA31_DTXD | AT91C_PA30_DRXD);
	

	// Configure DBGU
	AT91F_US_Configure (
		(AT91PS_USART) g_pDBGU,          // DBGU base address
		dwMasterClock,             // 33.3 MHz
		AT91C_US_ASYNC_MODE,  // mode Register to be programmed
		DBGU_BAUDRATE ,              // baudrate to be programmed
		0);                   // timeguard to be programmed

	// Enable Transmitter
	g_pDBGU->DBGU_CR = AT91C_US_TXEN;
    // Enable receiver
    g_pDBGU->DBGU_CR = AT91C_US_RXEN;  
}

//-----------------------------------------------------------------------------
//! \fn		int OEMReadDebugByte(void)
//!
//! \brief		This function retrieves a byte from the debug serial port
//!
//! \return		OEM_DEBUG_COM_ERROR indicates failure
//!	\return		OEM_DEBUG_READ_NODATA indicates no data has been received
//! \return		Other value is byte received
//!
//! 
//-----------------------------------------------------------------------------
int OEMReadDebugByte(void)
{
	if (g_pDBGU == NULL)
	{
		return OEM_DEBUG_COM_ERROR;
	}

	if (g_pDBGU->DBGU_CSR & AT91C_US_RXRDY) //Did we receive at least one byte ?
	{
		return 	g_pDBGU->DBGU_RHR; //If so return its value
	}
	return OEM_DEBUG_READ_NODATA; //If not so, return the no data flag
	
}


 
//-----------------------------------------------------------------------------
//! \fn		void OEMWriteDebugByte(BYTE ch)
//!
//! \brief		This function outputs a byte to the debug serial port.
//!
//! \param		ch	byte to send
//!
//! 
//-----------------------------------------------------------------------------
void OEMWriteDebugByte(BYTE ch)
{
	if (g_pDBGU == NULL)
		return;

	while (!(g_pDBGU->DBGU_CSR & AT91C_US_TXRDY))
	{
		//do nothing. wait for the controller to be ready
	}
	g_pDBGU->DBGU_THR=ch;
	while (!(g_pDBGU->DBGU_CSR & AT91C_US_TXRDY))
	{
		//do nothing. wait for the controller to be ready
	}
}


//! @}



