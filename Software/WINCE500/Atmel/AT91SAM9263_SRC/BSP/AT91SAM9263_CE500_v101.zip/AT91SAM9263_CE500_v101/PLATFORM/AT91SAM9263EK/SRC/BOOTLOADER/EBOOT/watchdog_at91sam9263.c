//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//-----------------------------------------------------------------------------
//! \file		watchdog_at91sam9263.c 
//!
//! \brief		The specific watchdog part
//!
//! \if subversion
///  $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/BOOTLOADER/EBOOT/watchdog_at91sam9263.c $
//!   $Author: ltourlonias $
//!   $Revision: 874 $
//!   $Date: 2007-05-24 09:03:04 +0200 (jeu., 24 mai 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	EBOOT
//! @{
//!


//------------------------------------------------------------------------------
//                                                                      Includes
//------------------------------------------------------------------------------
// Standard includes
#include <windows.h>

// Atmel includes
#include "AT91SAM9263EK.h"
#include "at91sam9263.h"


//------------------------------------------------------------------------------
//                                                            Improted functions
//------------------------------------------------------------------------------
extern VOID*			OALPAtoVA(UINT32 pa, BOOL cached);			//< Mapping function
extern UINT32			OALVAtoPA(VOID *pVA);						//< Mapping function

//------------------------------------------------------------------------------
//                                                            Exported functions
//------------------------------------------------------------------------------

//--------------------------------------------------------------------------------
//! \brief Refresh watchdog
//!
//--------------------------------------------------------------------------------
void EBOOT_WatchdogRefresh(void)
{
	AT91PS_WDTC pWDT = (AT91PS_WDTC)OALPAtoVA((DWORD)AT91C_BASE_WDTC,FALSE);
	
	// Restart the watchdog
	pWDT->WDTC_WDCR = (0xA5 << 24 ) | AT91C_WDTC_WDRSTT;
}

	
//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/BOOTLOADER/EBOOT/watchdog_at91sam9263.c $
//------------------------------------------------------------------------------

//
//! @}
//

//! @}
