//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		diskio.c
//!
//! \brief		Common part of the SD Memory Card driver
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/SDMEMORY/diskio.c $
//!   $Author: pblanchard $
//!   $Revision: 980 $
//!   $Date: 2007-06-11 07:26:34 -0700 (Mon, 11 Jun 2007) $
//! \endif
//!
//! This driver initializes the MCI peripheral and allows read/write on an SD Card
//-----------------------------------------------------------------------------
//! \addtogroup	SDMEMORY
//! @{
//!

// System include
#include <windows.h>
#include <nkintr.h>
#include <diskio.h>
#include <storemgr.h>
#include <devload.h>

// Local include
#include "sdmmc.h"
#include "AT91C_MCI_Device.h"

#define WRITING_THREAD_PRIORITY		20
#define REG_PROFILE_KEY				TEXT("Profile")
#define DEFAULT_PROFILE				TEXT("Default")
#define	MAX_SECTORS					1

extern void SDMemoryProcSpecificActivatePMC(DWORD dwSlotNumber);
extern void SDMemoryProcSpecificDeactivatePMC(DWORD dwSlotNumber);

//-----------------------------------------------------------------------------
//! \fn			BOOL GetDeviceInfo(PDISK pDisk, PSTORAGEDEVICEINFO pInfo)
//!
//! \brief		This function is the entry point of the Dll driver
//!
//! \param		pDisk	Pointer to a DISK structure (in)
//! \param		pInfo	Pointer to a STORAGEDEVICEINFO structure (out)
//!
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//!
//! This function returns SD Memory Card informations
//-----------------------------------------------------------------------------
BOOL GetDeviceInfo(PDISK pDisk, PSTORAGEDEVICEINFO pInfo)
{
    BOOL fRet = FALSE;
    HKEY hKeyDriver;
    DWORD dwBytes;
    DWORD dwStatus;
    DWORD dwValType;

    if(pDisk && pInfo)
    {
        _tcsncpy(pInfo->szProfile, DEFAULT_PROFILE, PROFILENAMESIZE);
        __try
        {
			hKeyDriver = OpenDeviceKey(pDisk->d_ActivePath);
            if(hKeyDriver)
            {
                // read the profile string from the active reg key if it exists
                dwBytes = sizeof(pInfo->szProfile);
                dwStatus = RegQueryValueEx(hKeyDriver, REG_PROFILE_KEY, NULL, &dwValType, (PBYTE)&pInfo->szProfile, &dwBytes);
                
                // if this fails, szProfile will contain the default string
				RegCloseKey(hKeyDriver);
            }

            // set our class, type, and flags
            pInfo->dwDeviceClass = STORAGE_DEVICE_CLASS_BLOCK;
       		pInfo->dwDeviceType = STORAGE_DEVICE_TYPE_UNKNOWN | STORAGE_DEVICE_TYPE_REMOVABLE_MEDIA;

            if (SDMemoryBoardSpecificIsWriteProtected(pDisk->dwSlotNumber))
			{
				pInfo->dwDeviceFlags = STORAGE_DEVICE_FLAG_READONLY;
			}
			else
			{
				pInfo->dwDeviceFlags = STORAGE_DEVICE_FLAG_READWRITE;
			}

            fRet = TRUE;
        }
        __except(EXCEPTION_EXECUTE_HANDLER)
        {
            SetLastError(ERROR_INVALID_PARAMETER);
            fRet = FALSE;
        }
    }
    return fRet;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL GetFolderName(PDISK pDisk, LPWSTR FolderName, DWORD cBytes, DWORD * pcBytes)
//!
//! \brief		This function returns the disk name from registry
//!
//! \param		pDisk		Pointer to a DISK structure (in)
//! \param		FolderName	Pointer to a string (out)
//! \param		cBytes		Size of the buffer pointed by FolderName (in)
//! \param		pcBytes		Not used
//!
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//!
//! Thi function retrieves the folder name value from the driver key. The folder name is
//! used by FATFS to name this disk volume.
//-----------------------------------------------------------------------------
BOOL GetFolderName(PDISK pDisk, LPWSTR FolderName, DWORD cBytes, DWORD * pcBytes)
{
    HKEY DriverKey;
    DWORD ValType;
    DWORD status;

	DriverKey = OpenDeviceKey(pDisk->d_ActivePath);
    if (DriverKey)
	{
        *pcBytes = cBytes;
        status = RegQueryValueEx(
                    DriverKey,
                    TEXT("Folder"),
                    NULL,
                    &ValType,
                    (PUCHAR)FolderName,
                    pcBytes);
        if (status != ERROR_SUCCESS)
		{
            DEBUGMSG(ZONE_INIT|ZONE_ERROR,(TEXT("RAM:GetFolderName - RegQueryValueEx(Folder) returned %d\r\n"), status));
            *pcBytes = 0;
        }
		else
		{
            DEBUGMSG(ZONE_INIT|ZONE_ERROR, (TEXT("RAM:GetFolderName - FolderName = %s, length = %d\r\n"), FolderName, *pcBytes));
           *pcBytes += sizeof(WCHAR); // account for terminating 0.
        }

        RegCloseKey(DriverKey);
        if (status || (*pcBytes == 0))
		{
            // Use default
            return FALSE; 
        }

        return TRUE;
    }
    
    return FALSE;
}


//-----------------------------------------------------------------------------*
//! \fn			void DeallocateVirtual(PDISK pDisk)
//!
//! \brief		This function deallocates virtual memory required for this driver
//!
//! \param		pDisk	Pointer to the context
//!
//-----------------------------------------------------------------------------
void DeallocateVirtual(PDISK pDisk)
{
	DEBUGMSG(ZONE_INIT, (TEXT("+SDMMC: DeallocateVirtual entered\r\n")));

	if (pDisk->pMCI_VirtualBase != NULL)
	{
		MmUnmapIoSpace(pDisk->pMCI_VirtualBase, sizeof(AT91S_MCI));
		pDisk->pMCI_VirtualBase = NULL;
	}

	if (pDisk->pPDC_VirtualBase != NULL)
	{
		pDisk->pMCI_VirtualBase = NULL;
	}

	
	DEBUGMSG(ZONE_INIT, (TEXT("-SDMMC: DeallocateVirtual done\r\n")));
}


//-----------------------------------------------------------------------------
//! \fn			BOOL AllocateVirtual(PDISK pDisk)
//!
//! \brief		This function allocates virtual memory required for this driver
//!
//! \param		pDisk	Pointer to the context
//!
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//-----------------------------------------------------------------------------
BOOL AllocateVirtual(PDISK pDisk)
{
	PHYSICAL_ADDRESS    MCI_PhysicalBase;
	

	MCI_PhysicalBase.QuadPart = (LONGLONG)SDMemoryBoardSpecificGetMCIBase(pDisk->dwSlotNumber);
	

	DEBUGMSG(ZONE_INIT, (TEXT("+SDMMC: AllocateVirtual entered\r\n")));

	pDisk->pMCI_VirtualBase = (AT91PS_MCI)MmMapIoSpace(MCI_PhysicalBase, sizeof(AT91S_MCI), FALSE);
	if (pDisk->pMCI_VirtualBase == NULL)
	{
		DEBUGMSG(ZONE_INIT|ZONE_ERROR, (TEXT("Allocate MCI : MmMapIoSpace failed !\r\n")));
		DeallocateVirtual(pDisk);
		return FALSE;
	}

	pDisk->pPDC_VirtualBase = (AT91PS_PDC) ((UCHAR*) pDisk->pMCI_VirtualBase + offsetof(AT91S_MCI,MCI_RPR));
	
	DEBUGMSG(ZONE_INIT, (TEXT("-SDMMC: AllocateVirtual done\r\n")));

	return TRUE;
}


//-----------------------------------------------------------------------------
//! \fn			void ConfigPIO(DWORD dwSlotNumber)
//!
//! \param		dwSlotNumber TODO
//!
//! \brief		This function configures PIO using the specific part of the driver
//-----------------------------------------------------------------------------
void ConfigPIO(DWORD dwSlotNumber)
{
	SDMemoryBoardSpecificGetBus(dwSlotNumber);
	SDMemoryBoardSpecificPIOConfiguration(dwSlotNumber);
	SDMemoryBoardSpecificReleaseBus(dwSlotNumber);
}


//-----------------------------------------------------------------------------
//! \fn			void ConfigPMC (PDISK pDisk,BOOL bState)
//!
//! \brief		This function enables or disable MCI peripheral clock
//!
//! \param		pDisk	Pointer to the context
//! \param		bState	Power Managment state
//-----------------------------------------------------------------------------
void ConfigPMC (PDISK pDisk,BOOL bState)
{
	if (bState)
	{
		SDMemoryProcSpecificActivatePMC(pDisk->dwSlotNumber);
	}
	else
	{
		SDMemoryProcSpecificDeactivatePMC(pDisk->dwSlotNumber);
	}
}


//-----------------------------------------------------------------------------
//! \fn			void ConfigPDC (PDISK pDisk)
//!
//! \param 		pDisk Pointer to a DSIK structure
//!
//! \brief		This function initializes the PDC
//-----------------------------------------------------------------------------
void ConfigPDC (PDISK pDisk)
{
	//* Disable the RX and TX PDC transfer requests
	pDisk->pMCI_VirtualBase->MCI_PTCR = AT91C_PDC_RXTDIS | AT91C_PDC_TXTDIS;

	pDisk->pMCI_VirtualBase->MCI_RPR = pDisk->pMCI_VirtualBase->MCI_RCR = 0;
	pDisk->pMCI_VirtualBase->MCI_TPR = pDisk->pMCI_VirtualBase->MCI_TCR = 0;
	pDisk->pMCI_VirtualBase->MCI_RNPR = pDisk->pMCI_VirtualBase->MCI_RNCR = 0;
	pDisk->pMCI_VirtualBase->MCI_TNPR = pDisk->pMCI_VirtualBase->MCI_TNCR = 0;	

	pDisk->vDMACommonTxBuffer = NULL;
	pDisk->vDMACommonRxBuffer = NULL;

	pDisk->dmaAdapterObject.ObjectSize = sizeof(DMA_ADAPTER_OBJECT);
    pDisk->dmaAdapterObject.InterfaceType = PCIBus ;
    pDisk->dmaAdapterObject.BusNumber = 0 ;

	pDisk->vDMACommonTxBuffer = HalAllocateCommonBuffer(&pDisk->dmaAdapterObject, SIZE_OF_PDC_TX_BUFFER, &(pDisk->pDMACommonTxBuffer), FALSE);
    if (pDisk->vDMACommonTxBuffer == NULL)
	{
		DEBUGMSG(ZONE_IO, (TEXT("ConfigPDC:HalAllocateCommonBuffer failed")));
	}

	pDisk->vDMACommonRxBuffer = HalAllocateCommonBuffer(&pDisk->dmaAdapterObject, SIZE_OF_PDC_RX_BUFFER, &(pDisk->pDMACommonRxBuffer), FALSE);
    if (pDisk->vDMACommonRxBuffer == NULL)
	{
		DEBUGMSG(ZONE_IO, (TEXT("ConfigPDC:HalAllocateCommonBuffer failed")));
	}
}




//-----------------------------------------------------------------------------
//! \fn			BOOL ConfigMCI(PDISK pDisk)
//!
//! \brief		This function executes a basic configuration of the MCI
//!
//! \param		pDisk	Pointer to a DSIK structure
//!
//! return		True in success, False in failure
//-----------------------------------------------------------------------------
BOOL ConfigMCI(PDISK pDisk)
{
	pDisk->pMCI_VirtualBase->MCI_CR = AT91C_MCI_SWRST | AT91C_MCI_MCIEN;	//reset the controller
	pDisk->pMCI_VirtualBase->MCI_MR = AT91C_MCI_PDCMODE | AT91C_MCI_CLKDIV;
	pDisk->pMCI_VirtualBase->MCI_DTOR = AT91C_MCI_DTOCYC | AT91C_MCI_DTOMUL;
	switch (SDMemoryBoardSpecificGetSlotID(pDisk->dwSlotNumber))
	{
	case SLOT_A:
	{
		pDisk->pMCI_VirtualBase->MCI_SDCR = 0;//1 bit data path & slot A
	}
	break;
	case SLOT_B:
	{		
		pDisk->pMCI_VirtualBase->MCI_SDCR = 0x1;//1 bit data path & slot B
	}
	break;
	default:
	{
		RETAILMSG(1,(TEXT("Invalid SD Slot ID! \r\n")));
		return FALSE;
	}
	}
	return TRUE;
}


//-----------------------------------------------------------------------------
//! \fn			BOOL InitDisk(PDISK pDisk)
//!
//! \brief		This function : 
//!								- allocates resources associated with the specified disk
//!								- initializes the hardware
//!								- fills the structure describing the disk
//!
//! \param		pDisk	Pointer to a DSIK structure
//!
//! \return		\e TRUE indicates success
//!	\return		\e FALSE indicates failure
//-----------------------------------------------------------------------------
BOOL InitDisk(PDISK pDisk)
{
	RETAILMSG(1, (TEXT("SDMMC:InitDisk with pDisk 0x%x\r\n"), pDisk));
				
    DEBUGMSG(ZONE_INIT, (TEXT("SDMMC:InitDisk with pDisk 0x%x\r\n"), pDisk));
	
	// Allocate the memory area that will be used to access the hard drive
	// hint : see virtualalloc and virtualcopy (using PAGE_PHYSICAL flag)

	if (AllocateVirtual(pDisk))
	{
		if (ConfigMCI(pDisk) == FALSE)
		{
			return FALSE;
		}

		SDMemoryBoardSpecificInit(pDisk->dwSlotNumber);
		ConfigPIO(pDisk->dwSlotNumber);		//configure pio for the MCI periph 		
		ConfigPMC(pDisk,TRUE);		//enable clock for MCI
		ConfigPDC(pDisk);		//initialize PDC

		
		// Disable all the interrupts
	    pDisk->pMCI_VirtualBase->MCI_IDR = 0xFFFFFFFF;

		if (pDisk)
		{		
			DWORD dwLogIntr;
			//Allocate a Sysintr for our driver
			dwLogIntr = SDMemoryBoardSpecificGetMCIID(pDisk->dwSlotNumber);
			if (!KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &dwLogIntr, sizeof(dwLogIntr), &pDisk->dwSysIntr, sizeof(pDisk->dwSysIntr), NULL))
			{
				RETAILMSG(1, (TEXT("ERROR: Failed to request the serial sysintr for MCI controller (logintr :%d).\r\n"),dwLogIntr));
				pDisk->dwSysIntr = SYSINTR_UNDEFINED;
				return FALSE;
			}
			else
			{
				pDisk->hInterruptEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
				if (pDisk->hInterruptEvent == NULL)
				{
					return FALSE;
				}
				if (!InterruptInitialize(pDisk->dwSysIntr, pDisk->hInterruptEvent, 0, 0)) 
				{
					return FALSE;
				}
			}
			
			if(AT91F_MCI_SDCard_Init(&pDisk->MciDevice,pDisk) != AT91C_INIT_OK)
			{
				RETAILMSG(1, (TEXT("SDCard Initialisation failed\n\r")));
				return FALSE;	
			}
			RETAILMSG(1, (TEXT("SDCard Initialisation Successful 2\n\r")));

            pDisk->d_DiskInfo.di_total_sectors = (pDisk->MciDevice.pMCI_DeviceFeatures->Memory_Capacity) / SD_BYTES_PER_SECTOR;
			pDisk->d_DiskInfo.di_bytes_per_sect = SD_BYTES_PER_SECTOR;

			pDisk->d_DiskInfo.di_cylinders = 0; //
			pDisk->d_DiskInfo.di_heads = 0;		//CHS not used for FAT FS
			pDisk->d_DiskInfo.di_sectors = 0;	//
			pDisk->d_DiskInfo.di_flags = DISK_INFO_FLAG_CHS_UNCERTAIN;
			

			DEBUGMSG(ZONE_IO,(TEXT("SDMMC:DiskInfo TotalSec:%d SecSize:%d Cyls:%d Hds:%d EstSecs:%d\r\n"),
				pDisk->d_DiskInfo.di_total_sectors,
				pDisk->d_DiskInfo.di_bytes_per_sect,
				pDisk->d_DiskInfo.di_cylinders,
				pDisk->d_DiskInfo.di_heads,
				pDisk->d_DiskInfo.di_sectors));
		}
		else 
		{
			return FALSE;
		}
	}
	else
	{
		RETAILMSG(1, (TEXT("InitDisk : AllocateVirtual failed.\n\r")));
		return FALSE;
	}

	pDisk->MciDevice.pMCI_DeviceDesc->state = AT91C_MCI_IDLE;

	return TRUE;
}


//-----------------------------------------------------------------------------
//! \fn			void DeinitDisk(PDISK pDisk)
//!
//! \brief		This function free all resources associated with the specified disk
//!
//! \param		pDisk	Pointer to a DSIK structure
//-----------------------------------------------------------------------------
void DeinitDisk(PDISK pDisk)
{
	DEBUGMSG(ZONE_IO, (TEXT("+SDMMC:DeinitDisk entered\r\n")));
	
	if (pDisk->hInterruptEvent)
	{
		CloseHandle(pDisk->hInterruptEvent);
	}
	if (pDisk->dwSysIntr != SYSINTR_UNDEFINED)
	{
		DWORD dummy;		
		InterruptDisable(pDisk->dwSysIntr);
		KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, (PVOID)&pDisk->dwSysIntr,sizeof(pDisk->dwSysIntr), NULL, 0, &dummy);
	}

	SDMemoryProcSpecificDeactivatePMC(pDisk->dwSlotNumber);
	DeallocateVirtual(pDisk);

	if (pDisk->vDMACommonTxBuffer )
	{
		HalFreeCommonBuffer(&pDisk->dmaAdapterObject,SIZE_OF_PDC_TX_BUFFER,pDisk->pDMACommonTxBuffer,pDisk->vDMACommonTxBuffer,FALSE);
	}
	if (pDisk->vDMACommonRxBuffer )
	{
		HalFreeCommonBuffer(&pDisk->dmaAdapterObject,2*SIZE_OF_PDC_RX_BUFFER,pDisk->pDMACommonRxBuffer,pDisk->vDMACommonRxBuffer,FALSE);
	}

	SDMemoryBoardSpecificDeInit(pDisk->dwSlotNumber);
    DEBUGMSG(ZONE_IO, (TEXT("-SDMMC:DeinitDisk with pDisk 0x%x done\r\n"), pDisk));
}


//-----------------------------------------------------------------------------
//! \fn			DWORD DoDiskIO(PDISK pDisk, DWORD dwOpcode, PSG_REQ pSgr)
//!
//! \brief		This function manage I/O in the SD Memory Card
//!
//! \param		pDisk		Pointer to a DISK structure
//! \param		dwOpcode	Type of I/O : Read or Write
//! \param		pSgr		Pointer to a SG_REQ structure
//!
//! \return		Returns the status
//!
//!	This function is called from DSK_IOControl.
//-----------------------------------------------------------------------------
DWORD DoDiskIO(PDISK pDisk, DWORD dwOpcode, PSG_REQ pSgr)
{
    DWORD status = ERROR_SUCCESS;
	
	SDMemoryBoardSpecificGetBus(pDisk->dwSlotNumber);
	SDMemoryBoardSpecificPIOConfiguration(pDisk->dwSlotNumber);
	
    pSgr->sr_status = ERROR_IO_PENDING;

    if ((pSgr->sr_num_sg > MAX_SG_BUF) || (pSgr->sr_num_sec == 0))
	{
        status = ERROR_INVALID_PARAMETER;
    }
    else if ((pSgr->sr_start + pSgr->sr_num_sec - 1) > pDisk->d_DiskInfo.di_total_sectors)
	{
        status = ERROR_SECTOR_NOT_FOUND; // request exceeded the disk
    }
	else
	{
		status = ERROR_SUCCESS;

		EnterCriticalSection(&(pDisk->d_DiskCardCrit));

		if (pDisk->d_DiskCardState != STATE_OPENED)
		{
			DEBUGMSG(ZONE_IO, (TEXT("SDMMC:DoDiskIO - Disk state != STATE_OPENED\r\n")));
		}
		else
		{
			//
			// Read or write sectors from/to disk.
			// NOTE: Multiple sectors may go in one scatter/gather buffer or one
			// sector may fit in multiple scatter/gather buffers.
			//
			if (dwOpcode == DISK_IOCTL_READ)
			{
				if (ReadData(pDisk, pSgr) == 0)
				{
					//RETAILMSG(1,(TEXT("SDMMC:DoDiskIO - ReadData failed\r\n")));
					status = ERROR_READ_FAULT;
				}
				//else
				//	RETAILMSG(1,(TEXT("SDMMC:DoDiskIO - ReadData OK")));
			}
			else 
			{
				if (dwOpcode == DISK_IOCTL_WRITE)
				{
					if (WriteData(pDisk, pSgr) == 0)
					{
						RETAILMSG(1,(TEXT("SDMMC:DoDiskIO - WriteData failed\r\n")));
						status = ERROR_WRITE_FAULT;
					}
					//else
					//	RETAILMSG(1,(TEXT("SDMMC:DoDiskIO - WriteData OK")));
				}

			}
		}

		LeaveCriticalSection(&(pDisk->d_DiskCardCrit));

		if (pDisk->d_DiskCardState != STATE_OPENED)
		{
			//
			// Disk probably closed due to suspend/resume.
			//
			status = GetDiskStateError(pDisk->d_DiskCardState);
		}
	}

	SDMemoryBoardSpecificReleaseBus(pDisk->dwSlotNumber);
	pSgr->sr_status = status;
    return status;
}


//-----------------------------------------------------------------------------
//! \fn			DWORD FormatDisk(PDISK pDisk, PDISK_INFO pInfo)
//!
//! \brief		Dummy function.
//!
//! \param		pDisk	NULL
//! \param		pInfo	NULL
//!
//! \return		Returns status
//-----------------------------------------------------------------------------
DWORD FormatDisk(PDISK pDisk, PDISK_INFO pInfo)
{
	return ERROR_SUCCESS;
}


//-----------------------------------------------------------------------------
//! \fn			DWORD GetDiskInfo(PDISK pDisk, PDISK_INFO pInfo)
//!
//! \brief		This function returns disk info in response to DISK_IOCTL_GETINFO
//!
//! \param		pDisk	Pointer to a DISK structure
//! \param		pInfo	Pointer to a DISK_INFO structure
//!
//! \return		Returns status
//-----------------------------------------------------------------------------
DWORD GetDiskInfo(PDISK pDisk, PDISK_INFO pInfo)
{
    *pInfo = pDisk->d_DiskInfo;
    pInfo->di_flags |= DISK_INFO_FLAG_CHS_UNCERTAIN | DISK_INFO_FLAG_PAGEABLE;
    return ERROR_SUCCESS;
}


//-----------------------------------------------------------------------------
//! \fn			DWORD SetDiskInfo(PDISK pDisk, PDISK_INFO pInfo)
//!
//! \brief		This function stores disk info in response to DISK_IOCTL_SETINFO
//!
//! \param		pDisk	Pointer to a DISK structure
//! \param		pInfo	Pointer to a DISK_INFO structure
//!
//! \return		Returns status
//-----------------------------------------------------------------------------
DWORD SetDiskInfo(PDISK pDisk, PDISK_INFO pInfo)
{
    pDisk->d_DiskInfo = *pInfo;
    return ERROR_SUCCESS;
}


//-----------------------------------------------------------------------------
//! \fn			unsigned long WriteData(PDISK pDisk, PSG_REQ pSG)
//!
//! \brief		This function writes a block of data to the SD Memory Card
//!
//! \param		pDisk	Pointer to a DISK structure
//! \param		pSG		Pointer to a SG_REQ structure
//!
//! \return		Returns the number of bytes written
//-----------------------------------------------------------------------------
unsigned long WriteData(PDISK pDisk, PSG_REQ pSG)
{
    DWORD NumBlocks;
    DWORD StartBlock;
    //PUCHAR pBlockBuffer = NULL;
	PUCHAR pCardDataPtr = NULL;
    PUCHAR pSGBuffer = NULL;
    DWORD status = ERROR_SUCCESS;
    DWORD SGBufNum, SGBufLen, SGBufRemaining;
    DWORD PartialStartBlock;
    DWORD CardDataRemaining;
	ULONG ul;
	HANDLE currentThread = GetCurrentThread();
	DWORD oldThreadPriority = CeGetThreadPriority(currentThread);

	CeSetThreadPriority(currentThread, WRITING_THREAD_PRIORITY);

	DEBUGMSG(ZONE_IO, (TEXT("SDMemory: +SDMemWrite\n")));

    PREFAST_DEBUGCHK(pSG);

	// Validate pointers	
	for (ul = 0; ul < pSG->sr_num_sg; ul += 1) {
		pSG->sr_sglist[ul].sb_buf = (PUCHAR)MapCallerPtr((LPVOID)pSG->sr_sglist[ul].sb_buf, 
			pSG->sr_sglist[ul].sb_len);
		if (pSG->sr_sglist[ul].sb_buf == NULL) {
            status = ERROR_INVALID_PARAMETER;
			goto statusReturn;
		}
	}

    // Validate Scatter request
    if ((pSG->sr_start + pSG->sr_num_sec) > (pDisk->MciDevice.pMCI_DeviceFeatures->Memory_Capacity / SD_BYTES_PER_SECTOR)) {
        status = ERROR_INVALID_PARAMETER;
        goto statusReturn;
    }

     
        // get number of sectors
    StartBlock = pSG->sr_start;
    NumBlocks = pSG->sr_num_sec;

    DEBUGMSG(ZONE_IO, (TEXT("SDMemWrite: Writing blocks %d-%d\r\n"),
            StartBlock,StartBlock+NumBlocks-1));

    SGBufLen = 0;
       // Calculate total buffer space of scatter gather buffers
    for ( SGBufNum=0; SGBufNum < pSG->sr_num_sg; SGBufNum++ ) {
        SGBufLen += pSG->sr_sglist[SGBufNum].sb_len;
    }
        // Check total SG buffer space is enough for reqeusted transfer size
    if( SGBufLen < NumBlocks*SD_BYTES_PER_SECTOR ) {
        DEBUGMSG( ZONE_IO, 
            (TEXT("SDMemWrite: SG Buffer space %d bytes less than block write size %d bytes\r\n"),
                    SGBufLen, NumBlocks*SD_BYTES_PER_SECTOR ));
        status = ERROR_GEN_FAILURE;
        goto statusReturn;
    }

    		// initialise some variables used in data copy
    SGBufNum = 0;
    SGBufRemaining = pSG->sr_sglist[SGBufNum].sb_len;
    pSGBuffer = pSG->sr_sglist[SGBufNum].sb_buf;

        // split the writes into groups of TransferBlockSize in size to avoid
        // hogging the SD Bus with large writes
    for( PartialStartBlock = StartBlock; 
         PartialStartBlock < StartBlock+NumBlocks; 
         PartialStartBlock += 1) {

            // Some variables just used for copying
        DWORD PartialTransferSize;
        DWORD CopySize;
    
        pCardDataPtr = pDisk->vDMACommonTxBuffer;

			// AT91F_MCI_WriteBlock is implemented to write only 1 block 
        PartialTransferSize = 1;

            // copy from pSG buffers to pBlockArray 
        CardDataRemaining = PartialTransferSize*SD_BYTES_PER_SECTOR;

        while ( CardDataRemaining  ) {
                // cet minimum of remaining size in SG buf and data left in pBlockBuffer
            CopySize = MIN( SGBufRemaining, CardDataRemaining );
                // copy that much data to block buffer
            memcpy( pCardDataPtr, pSGBuffer, CopySize );

                // update pointers and counts
            pSGBuffer += CopySize;
            pCardDataPtr += CopySize;
            CardDataRemaining -= CopySize;
            SGBufRemaining -= CopySize;

                // Get the next SG Buffer if needed
            if ( !SGBufRemaining && CardDataRemaining) {
                SGBufNum++;
                SGBufRemaining = pSG->sr_sglist[SGBufNum].sb_len;
                pSGBuffer = pSG->sr_sglist[SGBufNum].sb_buf;
            }
        }
	
		//memcpy(vDMACommonTxBuffer,pBlockBuffer,PartialTransferSize*SD_BYTES_PER_SECTOR);

            // Write the data to the SD Card
		status = AT91F_MCI_WriteBlock(	&pDisk->MciDevice, 
										PartialStartBlock*SD_BYTES_PER_SECTOR, 
										(unsigned int*)pDisk->pDMACommonTxBuffer.LowPart, 
										PartialTransferSize*SD_BYTES_PER_SECTOR, 
										pDisk);

        if( status != AT91C_WRITE_OK ) {
			pDisk->MciDevice.pMCI_DeviceDesc->state = AT91C_MCI_IDLE;
            break;
        }
		else
		{
			status = ERROR_SUCCESS;
		}

			// wait for drive before each sector
		AT91F_MCIDeviceWaitReady(&pDisk->MciDevice, AT91C_MCI_TIMEOUT, pDisk);
		pDisk->MciDevice.pMCI_DeviceDesc->state = AT91C_MCI_IDLE;
    }
 
statusReturn:

        // FATFS wants the status returned in the SG buffers also
    pSG->sr_status = status;

    DEBUGMSG(ZONE_IO, (TEXT("SDMemory: -SDMemWrite\n")));

	CeSetThreadPriority(currentThread, oldThreadPriority);

	// if ok, return nb of bytes written. Else 0;
    return (status == ERROR_SUCCESS ? SD_BYTES_PER_SECTOR : 0);
}


//-----------------------------------------------------------------------------
//! \fn			unsigned long ReadData(PDISK pDisk, PSG_REQ pSG)
//!
//! \brief		This function reads a block of data from SD Memory Card
//!
//! \param		pDisk	Pointer to a DISK structure
//! \param		pSG		Pointer to a SG_REQ structure
//!
//! \return		Returns the number of bytes read
//-----------------------------------------------------------------------------
unsigned long ReadData(PDISK pDisk, PSG_REQ pSG)
{
    DWORD NumBlocks;
    DWORD StartBlock;
    //PUCHAR pBlockBuffer = NULL;
	PUCHAR pCardDataPtr = NULL;
    PUCHAR pSGBuffer = NULL;
    DWORD status = ERROR_SUCCESS;
    DWORD SGBufNum, SGBufLen, SGBufRemaining;
    DWORD PartialStartBlock;
    DWORD CardDataRemaining;
	ULONG ul;

    DEBUGMSG(ZONE_IO, (TEXT("SDMemory: +SDMemRead\n")));

	(pSG);

    // Validate pointers
	for (ul = 0; ul < pSG->sr_num_sg; ul += 1) 
	{
		pSG->sr_sglist[ul].sb_buf = (PUCHAR)MapCallerPtr((LPVOID)pSG->sr_sglist[ul].sb_buf, pSG->sr_sglist[ul].sb_len);

		if (pSG->sr_sglist[ul].sb_buf == NULL) 
		{
            status = ERROR_INVALID_PARAMETER;
			goto statusReturn;
		}
	}

    // Validate Gather request
    if ((pSG->sr_start + pSG->sr_num_sec) > (pDisk->MciDevice.pMCI_DeviceFeatures->Memory_Capacity / SD_BYTES_PER_SECTOR)) {
        status = ERROR_INVALID_PARAMETER;
        goto statusReturn;
    }

        // get number of sectors
    StartBlock = pSG->sr_start;
    NumBlocks = pSG->sr_num_sec;

    DEBUGMSG(ZONE_IO, (TEXT("SDMemRead: Reading blocks %d-%d\r\n"),StartBlock,StartBlock+NumBlocks-1));

    SGBufLen = 0;

       // calculate total buffer space of scatter gather buffers
    for ( SGBufNum=0; SGBufNum < pSG->sr_num_sg; SGBufNum++ ) {
        SGBufLen += pSG->sr_sglist[SGBufNum].sb_len;
    }
        // check total SG buffer space is enough for reqeusted transfer size
    if ( SGBufLen < NumBlocks*SD_BYTES_PER_SECTOR ) {
        DEBUGMSG(ZONE_IO, (TEXT("SDMemRead: SG Buffer space %d bytes less than block read size %d bytes\r\n"),
                    SGBufLen, NumBlocks*SD_BYTES_PER_SECTOR ));
        status = ERROR_GEN_FAILURE;
        goto statusReturn;
    }

    // initialise some variables used in data copy
    SGBufNum = 0;
    SGBufRemaining = pSG->sr_sglist[SGBufNum].sb_len;
    pSGBuffer = pSG->sr_sglist[SGBufNum].sb_buf;
    
        // split the reads into groups of TransferBlockSize in size to avoid
        // hogging the SD Bus with large reads
    for( PartialStartBlock = StartBlock; 
         PartialStartBlock < StartBlock+NumBlocks; 
         PartialStartBlock += 1) {
            // some variables just used for copying
        DWORD PartialTransferSize;
        DWORD CopySize;

        
			// AT91F_MCI_ReadBlock is implemented to read only 1 block 
        PartialTransferSize = 1;

            // read the data from SD Card
		status = AT91F_MCI_ReadBlock(	&pDisk->MciDevice, 
										PartialStartBlock*SD_BYTES_PER_SECTOR, 
										(unsigned int*)pDisk->pDMACommonRxBuffer.LowPart,
										PartialTransferSize*SD_BYTES_PER_SECTOR,
										pDisk);

			//
			// wait for drive before each sector
			//
		AT91F_MCIDeviceWaitReady(&pDisk->MciDevice, AT91C_MCI_TIMEOUT, pDisk);
		pDisk->MciDevice.pMCI_DeviceDesc->state = AT91C_MCI_IDLE;
	

		pCardDataPtr = pDisk->vDMACommonRxBuffer;
		//memcpy(pBlockBuffer,vDMACommonRxBuffer,PartialTransferSize*SD_BYTES_PER_SECTOR);


        if ( status != AT91C_READ_OK) {
			pDisk->MciDevice.pMCI_DeviceDesc->state = AT91C_MCI_IDLE;
            break;
        }
		else
		{
			status = ERROR_SUCCESS;
		}
    
            // copy from pBlockArray to pSG buffers
        CardDataRemaining = PartialTransferSize*SD_BYTES_PER_SECTOR;

        while ( CardDataRemaining  ) {
                // get minimum of remaining size in SG buf and data left in pBlockBuffer
            CopySize = MIN( SGBufRemaining, CardDataRemaining );
                // copy that much data to SG buffer
            memcpy( pSGBuffer, pCardDataPtr, CopySize );

                // update pointers and counts
            pSGBuffer += CopySize;
            pCardDataPtr += CopySize;
            CardDataRemaining -= CopySize;
            SGBufRemaining -= CopySize;

                // Get the next SG Buffer if needed
            if ( !SGBufRemaining && CardDataRemaining ) {
                SGBufNum++;
                SGBufRemaining = pSG->sr_sglist[SGBufNum].sb_len;
				pSGBuffer = pSG->sr_sglist[SGBufNum].sb_buf;
            }
        }
    }
 
statusReturn:

    DEBUGMSG(ZONE_IO, (TEXT("SDMemory: -SDMemRead\n")));
    
        // FATFS wants the status returned in the SG buffers also
    pSG->sr_status = status;

		// if ok, return nb of bytes read. Else 0;
    return (status == ERROR_SUCCESS ? SD_BYTES_PER_SECTOR : 0);
}



//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/SDMEMORY/diskio.c $
//-----------------------------------------------------------------------------
//
//! @}
