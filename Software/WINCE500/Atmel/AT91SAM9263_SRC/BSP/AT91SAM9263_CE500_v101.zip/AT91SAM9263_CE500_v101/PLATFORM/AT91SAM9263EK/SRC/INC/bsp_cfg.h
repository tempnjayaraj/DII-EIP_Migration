//-----------------------------------------------------------------------------
//! \addtogroup	AT91SAM9263EK
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		bsp_cfg.h
//!
//! \brief		System constant specific for the AT91SAM9263EK board
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/INC/bsp_cfg.h $
//!   $Author: ltourlonias $
//!   $Revision: 651 $
//!   $Date: 2007-04-06 17:08:32 +0200 (ven., 06 avr. 2007) $
//! \endif
//-----------------------------------------------------------------------------

#ifndef __BSP_CFG_H
#define __BSP_CFG_H

//------------------------------------------------------------------------------
//
//  Define:  BSP_DEVICE_PREFIX
//
//  Prefix used to generate device name for bootload/KITL
//
#define BSP_DEVICE_PREFIX       "SAM9263_"      // Device name prefix


//------------------------------------------------------------------------------
// Board clock
//------------------------------------------------------------------------------

//
#define OEM_DEFAULT_TICKS           1         // System tick = 1ms
#define OEM_TICK_COUNT_MARGIN		0		  // We don't support this

//------------------------------------------------------------------------------
// NAND Flash Mapping
//------------------------------------------------------------------------------
#define NAND_FIRSTBOOT_SECTOR             0
#define NAND_BOOTLOADER_SECTOR            1
#define NAND_BOOTLOADER_SETTING_SECTOR    2
#define NAND_NK_START_SECTOR              3


//------------------------------------------------------------------------------
// FirstBoot Param !! these values are also defined in cfg.inc. Modify both files if needed !!
//------------------------------------------------------------------------------
#define FIRSTBOOT_MAX_SIZE				0x00001000	// 4 ko
#define	FREE_AREA_SIZE					0x00001000	// 4 ko
#define FIRSTBOOT_RAM_MAX_SIZE			0x00001000	//We used only first 4ko SRAM 
//#define DOWNLOAD_SRAM_ADDRESS			(AT91C_IRAM_1 + FIRSTBOOT_MAX_SIZE + FREE_AREA_SIZE + FIRSTBOOT_RAM_MAX_SIZE)
#define FIRSTBOOT_TIMEOUT_MS			3000
#define FIRSTBOOT_SRAM_ADDR             AT91C_IRAM				

//------------------------------------------------------------------------------
// SPI Dataflash Mapping
//------------------------------------------------------------------------------
#define CFG_DATAFLASH_LOGIC_ADDR_CS0				0xC0000000
#define CFG_DATAFLASH_LOGIC_ADDR_CS1				0xD0000000

#define BOOTLOADER_SETTINGS_LOGICAL_OFFSET			0x00020000
#define BOOTLOADER_CODE_LOGICAL_OFFSET				0x00005000

// SPI Dataflasg CS0
#define BOOTLOADER_SETTINGS_LOGICAL_ADDRESS_CS0		CFG_DATAFLASH_LOGIC_ADDR_CS0 | BOOTLOADER_SETTINGS_LOGICAL_OFFSET
#define BOOTLOADER_CODE_LOGICAL_ADDRESS_CS0			CFG_DATAFLASH_LOGIC_ADDR_CS0 | BOOTLOADER_CODE_LOGICAL_OFFSET

// SPI Dataflasg CS1
#define BOOTLOADER_SETTINGS_LOGICAL_ADDRESS_CS1		CFG_DATAFLASH_LOGIC_ADDR_CS1 | BOOTLOADER_SETTINGS_LOGICAL_OFFSET
#define BOOTLOADER_CODE_LOGICAL_ADDRESS_CS1			CFG_DATAFLASH_LOGIC_ADDR_CS1 | BOOTLOADER_CODE_LOGICAL_OFFSET


//------------------------------------------------------------------------------
// Nor flash Mapping
//------------------------------------------------------------------------------
#define BOOTLOADER_SETTINGS_ADDRESS			0x00020000

//------------------------------------------------------------------------------
// Eboot update
//------------------------------------------------------------------------------
#define AT91C_OFFSET_VECT6			0x14      // Offset for ARM vector 6. This is where is located the size of the eboot binary



//------------------------------------------------------------------------------
// EBoot Param	!! these values are also defined in cfg.inc. Modify both files if needed !!
//------------------------------------------------------------------------------
#define EBOOT_MAX_SIZE					0x00016800	//90ko
//#define EBOOT_SDRAM_ADDR				AT91C_EBI0_SDRAM
#define EBOOT_FLASH_ADDR				0x5000

//-------------------------------------------------------------------------------
// Default MAC Address in case it's programmable
//-------------------------------------------------------------------------------
#define DEFAULT_MAC_ADDRESS {0x02,0x02,0x09,0x04,0x05,0x05}
extern const UCHAR g_DefaultMacAddress[];
#endif

//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/INC/bsp_cfg.h $
//-----------------------------------------------------------------------------
//
