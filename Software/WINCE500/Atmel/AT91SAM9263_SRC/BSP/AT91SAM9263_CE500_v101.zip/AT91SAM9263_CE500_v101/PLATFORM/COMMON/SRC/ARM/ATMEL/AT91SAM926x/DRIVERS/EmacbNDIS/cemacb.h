//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//
//! \file		cemacb.h
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/EmacbNDIS/cemacb.h $
//!   $Author: amlimonet $
//!   $Revision: 685 $
//!   $Date: 2007-04-13 14:39:22 +0200 (ven., 13 avr. 2007) $
//! \endif
//
//-----------------------------------------------------------------------------
//! \addtogroup EMACNDIS
//! @{
//

#ifndef	__EMACB_H__
#define	__EMACB_H__


#include	"common.h"
#include	"driver.h"
#include	"device.h"

#define DM9161A_CONTROL_REG	0
#define DM9161A_CONTROL_REG_RESET					(1<<15)
#define DM9161A_CONTROL_REG_AUTONEGOCIATION_ENABLE	(1<<12)
#define DM9161A_CONTROL_REG_RESTART_AUTONEGOCIATION	(1<<9)
#define DM9161A_CONTROL_REG_FULL_DUPLEX				(1<<8)
#define DM9161A_CONTROL_REG_SPEED_SELECT				(1<<13)

#define DM9161A_STATUS_REG	1
#define DM9161A_STATUS_REG_LINK						(1<<2)
#define DM9161A_STATUS_REG_AUTONEGOCIATION_COMPLETE	(1<<5)

#define DM9161A_ID1_REG	2
#define DM9161A_ID2_REG	3
#define MII_DM9161A_ID   0x0181b880


#define DM9161A_LINK_PARTNER_REG	5
#define DM9161A_LINK_PARTNER_100FULL			(1<<8)
#define DM9161A_LINK_PARTNER_100HALF			(1<<7)
#define DM9161A_LINK_PARTNER_10FULL			(1<<6)
#define DM9161A_LINK_PARTNER_10HALF			(1<<5)

#define DM9161A_DAVICOM_SPEC_CONF_REG	16
#define DM9161A_DAVICOM_SPEC_INTR_REG	21

#define DM9161A_DAVICOM_SPEC_CONF_RMII_ENABLED	(1<<8)

#define EMAC_RX_BIT_USED		(1<<0)
#define EMAC_TX_BIT_USED		(1<<31)
#define	EMAC_RX_BIT_WRAP		(1<<1)
#define	EMAC_TX_BIT_WRAP		(1<<30)
#define EMAC_BIT_SOF		(1<<14)
#define EMAC_BIT_EOF		(1<<15)
#define EMAC_TX_BIT_UND		(1<<28)

#define EMAC_FLENGTH		0x7FF



/******************************************************************************************
 *
 * Definition of C_EMAC
 *
 *******************************************************************************************/
#define	EMAC_MULTICAST_LIST	64
#define SPEED_100	100
#define SPEED_10	10



typedef struct _DMA_Desc
{
	DWORD addr;
	DWORD ctrl;
} DMA_DESC;


typedef struct {
	DWORD	dwSpeed; 	//!< \brief Link Speed
	BOOL bFullDuplex;	//!< \brief Full or Half Duplex
	BOOL bAutoNegociation;	//!< \brief indicates if Autonegociation is active or not
	BOOL bRMII;				//!< \brief indicates wether the PHY is used in RMII mode
} T_PHY_CONFIGURATION;

/*******************************************************************************
 *
 * Device EMAC characteristics
 *
 *******************************************************************************/

class	C_EMACB : public NIC_DEVICE_OBJECT
{
public:
	C_EMACB::C_EMACB(NIC_DRIVER_OBJECT	*pUpper,PVOID pVoid) 
		: NIC_DEVICE_OBJECT(pUpper,pVoid)
	{
		m_uLastAddressPort = (U32)-1;
		m_LastRxEOFBuffer = 0;
		m_Cable = FALSE;
	};

	// overwrite routines with exception
	virtual void	EDeviceInitialize(int);
	
	// Device attributes and characteristics
	virtual U32		DevicePCIID( void) { return 0L; };
	virtual	PCONFIG_PARAMETER	DeviceConfigureParameters(void);
	virtual void	EDeviceValidateConfigurations(void);

	
	// Device access routines
	virtual U16		DeviceReadPhy(U32 nPhy,U32 nOff);
	virtual U16		DeviceWritePhy(U32 nPhy,U32 nOff,U16);
	
	// Device access routines, new 
	virtual	U32		DeviceReadData(void);
	virtual	U32		DeviceReadDataWithoutIncrement(void);
	virtual	PU8		DeviceReadString(PU8,int);
	virtual	PU8		DeviceWriteString(PU8,int);

	// Device control routines
	virtual void	DeviceStart( void);
	virtual void	DeviceReset( void);
	virtual void 	DeviceEnableInterrupt( void);
	virtual void 	DeviceDisableInterrupt( void);
	virtual U32 	DeviceGetInterruptStatus( void);
	virtual U32 	DeviceSetInterruptStatus( U32);
	virtual U32		DeviceGetReceiveStatus( void);
	virtual	U32		DeviceHardwareStatus(void);
	virtual BOOL	CheckCable(void);
	virtual	void 	DeviceEnableReceive(void);
	virtual	void 	DeviceDisableReceive(void);

	// There is no hardware control for transmission,
	// so, need to set one flag to control the tx.
	virtual	void 	DeviceEnableTransmit(void){ m_fTxEnabled=1; };
	virtual	void 	DeviceDisableTransmit(void){ m_fTxEnabled=0; };

	// Device hanlder routines
	virtual int		DeviceOnSetupFilter( U32);
	virtual void 	DeviceInterruptEventHandler( U32);
	virtual void 	DeviceResetPHYceiver(void);
	virtual int 	DeviceSend(PCQUEUE_GEN_HEADER);

  

	// class specific routines
	virtual	int		LookupRxBuffers(void);
	
#ifdef	IMPL_DEVICE_ISR
	virtual	void	DeviceIsr(U32);
#endif
		
	virtual	void	DeviceHalt(void){/* nothing to do */;};
public:

	CSpinlock	m_spinAccessToken;
	U32			m_uLastAddressPort;

	int					m_nIoMode;
	int					m_nIoMaxPad;
	AT91PS_EMAC			m_pEmac; 
	T_PHY_CONFIGURATION m_PhyCfg;
	BOOL				m_bPhyConfigured;

	
	

#ifdef	IMPL_STORE_AND_INDICATION

	virtual	void	DeviceOnTimer(void);

	CQueue	m_RQueue;
	CQueue	m_RQStandby;

#endif

	//
	// 3.2.9 revised
	virtual	int	DeviceQueryTxResources(void)
	{
		return m_pUpper->m_TQueue.IsQueueEmpty();
	}
	


	DMA_DESC*	m_Xmitdesc;
	DMA_DESC*	m_ReceiveDesc;
	
	
	DWORD		m_PhysAddrRxDesc;
	DWORD		m_PhysAddrRxData;

	PVOID		m_VirtAddrRxDesc;
	PVOID		m_VirtAddrRxData;

	UCHAR		m_ucPhyAddr;

	int			m_LastRxEOFBuffer;
	//int	m_nTx;

	BOOL FindFrame(DWORD * pSof, DWORD * pEof);
	void ReleaseBuffer(DWORD begin, DWORD end);
	void IndicateFrame(DWORD begin, DWORD end);
//	void WriteMacAddr( );
	// phy 


protected :
  virtual void PIOConfiguration(void)=0;
  
private :
	BOOL PHY_Reset(void);
	BOOL PHY_StartAutoNegociation(void);
	BOOL PHY_WaitForLink(DWORD dwTimeout);
	BOOL PHY_WaitForAutonegociationComplete(DWORD dwTimeout);
	BOOL PHY_GetID(DWORD* pdwID);
	BOOL PHY_CheckID(void);
	BOOL PHY_SetConfiguration(void);
	BOOL PHY_GetConfiguration(void);
	BOOL PhyConfiguration(void);
	
	
	void FindPhy();


};

#endif	//	__EMACB_H__
//! @}
//! @}
