//-----------------------------------------------------------------------------
//! \addtogroup   USBFN
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				AT91RM9200_usbfn_endpoint_in.h
//!
//! \brief				Declaration for the IN endpoint
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/DRIVERS/USBFN/AT91RM9200_usbfn_endpoint_IN.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

#include <csync.h>
#include <cmthread.h>
#include <CRegEdit.h>
#include <CRefCon.h>
#include <usbfn.h>

class AT91RMEndpoint;

class AT91RMEndpointIn : public AT91RMEndpoint  
{
public:
	BOOL Init(PUSB_ENDPOINT_DESCRIPTOR pEndpointDesc,
            BYTE bConfigurationValue, BYTE bInterfaceNumber, BYTE bAlternateSetting);   
    AT91RMEndpointIn(AT91RMUsbDevice * const pUsbDevice,DWORD dwEndpointIndex)
        : AT91RMEndpoint(pUsbDevice, dwEndpointIndex ) 
    {;
    }	
    DWORD   IST(DWORD dwIRBit) ;
};

//! @}