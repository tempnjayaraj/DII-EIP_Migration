//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//
//! \file		EmacbNDIS/common.cpp
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/EmacbNDIS/common.cpp $
//!   $Author: pgal $
//!   $Revision: 930 $
//!   $Date: 2007-06-04 14:14:24 +0200 (lun., 04 juin 2007) $
//! \endif
//
//-----------------------------------------------------------------------------
//! \addtogroup EMACNDIS
//! @{
//

#include	"common.h"

PEXCEPTION_DATA	_gpExpData;

//! @}
//! @}
