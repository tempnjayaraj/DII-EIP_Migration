//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9263/KERNEL/IOCTL/ioctl.c
//!
//! \brief		AT91SAM926x's processor's Hmatrix configuation
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/KERNEL/IOCTL/ioctl.c $
//!   $Author: edaniel $
//!   $Revision: 736 $
//!   $Date: 2007-04-18 11:46:13 +0200 (mer., 18 avr. 2007) $
//! \endif
//-----------------------------------------------------------------------------


#include <windows.h>

#include "at91sam926x.h"

//-----------------------------------------------------------------------------
//! \fn			DWORD IOCTLProcSpecificGetSHDWCBaseAddress(void)
//!
//! \brief		This function gets back SHDWC base adress
//!
//! \return		SHDWC base adress
//!
//-----------------------------------------------------------------------------
DWORD IOCTLProcSpecificGetSHDWCBaseAddress(void)
{
	return (DWORD) AT91C_BASE_SHDWC;
}

//-----------------------------------------------------------------------------
//! \fn			DWORD IOCTLProcSpecificGetRSTCBaseAddress(void)
//!
//! \brief		This function gets back RSTC base adress
//!
//! \return		RSTC base adress
//!
//-----------------------------------------------------------------------------
DWORD IOCTLProcSpecificGetRSTCBaseAddress(void)
{
	return (DWORD) AT91C_BASE_RSTC;
}

//------------------------------------------------------------------------------

//! @}


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM9263/KERNEL/IOCTL/ioctl.c $
////////////////////////////////////////////////////////////////////////////////
//
