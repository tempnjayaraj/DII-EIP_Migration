//-----------------------------------------------------------------------------
//! \addtogroup   USBFN
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				AT91RM9200_usbfn.cpp
//!
//! \brief				Implementation of the host controller class
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/DRIVERS/USBFN/AT91RM9200_usbfn.cpp $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

#include <windows.h>
#include <ceddk.h>
#include <ddkreg.h>
#include <nkintr.h> // needed for SYSINTR_NOP
#include <Winreg.h>

#include "AT91RM9200_usbfn.h"
#include "AT91RM9200.h"

#include "AT91RM9200_usbfn_endpoint.h"
#include "AT91RM9200_usbfn_endpoint_CTL.h"
#include "AT91RM9200_usbfn_endpoint_IN.h"
#include "AT91RM9200_usbfn_endpoint_OUT.h"



DWORD USBDetection(LPVOID lpvParam)
{
	PREFAST_DEBUGCHK(lpvParam != NULL);
	AT91RMUsbDevice *pUSBDevice = (AT91RMUsbDevice *) lpvParam;	
	return pUSBDevice->USBDetectionThread();
}
DWORD AT91RMUsbDevice::USBDetectionThread()
{
	BOOL fDone = FALSE;
    DWORD dwStatus = 0;
    
	m_bTerminateDetectionThread = FALSE;
    if (InitializeUSBDetectionInterrupt() == FALSE)
	{
		return FALSE;
	}
	InterruptDone(m_dwDetectionSysintr);
	while(!m_bTerminateDetectionThread)
	{
		WaitForSingleObject(m_hDetectionEvent,INFINITE);
		SetEvent(m_hPeriphEvent); //Simulate an interrupt from the controller
		InterruptDone(m_dwDetectionSysintr);
	}	
	DeinitializeUSBDetectionInterrupt();
	
    return dwStatus;
}

//-----------------------------------------------------------------------------
//! \brief		This function creates the device
//!
//! \param		lpActivePath	Path of the registry
//!
//! This function creates the device.
//-----------------------------------------------------------------------------
AT91RMUsbDevice::AT91RMUsbDevice(LPCTSTR lpActivePath)
:   CRegistryEdit(lpActivePath)
,   CMiniThread (0, TRUE)   
{
    m_pUDP = NULL;
    m_hPeriphEvent = NULL;
    m_pvMddContext = NULL;
    m_pfnNotify = NULL;
    m_CurPowerState = PwrDeviceUnspecified ;
    m_hParent = CreateBusAccessHandle(lpActivePath);
	m_USBDetectionThread = 	CreateThread(NULL, 0,USBDetection, this, 0, NULL);
}

//-----------------------------------------------------------------------------
//! \brief		This function destructs the device
//!
//! This function destructs the device.
//-----------------------------------------------------------------------------
AT91RMUsbDevice::~AT91RMUsbDevice()
{
    if (m_hDetectionEvent && m_USBDetectionThread) 
    {
        m_bTerminateDetectionThread=TRUE;        
        SetEvent(m_hDetectionEvent);
		WaitForSingleObject(m_USBDetectionThread,200);
    }
 
    if (m_hPeriphEvent) 
    {
        m_bTerminated=TRUE;
        ThreadStart();
        SetEvent(m_hPeriphEvent);
        ThreadTerminated(1000);
        InterruptDisable(m_dwPeriphSysIntr);         
        CloseHandle(m_hPeriphEvent);
    }
    for (DWORD dwIndex =0 ; dwIndex < MAX_ENDPOINT_NUMBER ; dwIndex ++) 
    {
        RemoveObjectBy( dwIndex );
    }
    
    if (m_pUDP != NULL) 
    {
		m_pUDP->UDP_IDR = 0xFFFFFFFF;
        MmUnmapIoSpace((PVOID)m_pUDP, 0UL);
    }
    if (m_pPMC != NULL) 
    {		
        MmUnmapIoSpace((PVOID)m_pPMC, 0UL);
    }

    if (m_hParent)
	{
        CloseBusAccessHandle(m_hParent);
	}
    
}

//-----------------------------------------------------------------------------
//! \brief		This function inits the device
//!
//! \param		pvMddContext		Pointer to the MDD context
//! \param		pMddInterfaceInfo	Pointer to the MDD info
//! \param		pPddInterfaceInfo	Pointer to the PDD info
//!
//! \return		ERROR_INVALID_DATA	Got a problem
//! \return		ERROR_SUCCESS		No problem
//!
//! This function inits clocks and interrupts and lokks fon additional information in the registry.
//! Calls HardwareInit, ThreadStart.
//-----------------------------------------------------------------------------
DWORD AT91RMUsbDevice::Init(
    PVOID                       pvMddContext,
    PUFN_MDD_INTERFACE_INFO     pMddInterfaceInfo,
    PUFN_PDD_INTERFACE_INFO     pPddInterfaceInfo
    )
{
    m_pvMddContext = pvMddContext;
    m_pfnNotify = pMddInterfaceInfo->pfnNotify;
    pPddInterfaceInfo->pvPddContext = this;
    PHYSICAL_ADDRESS	PhysicalAddress	;

	DWORD dwPeripheralLogintr;

    if ( !IsKeyOpened())
        return ERROR_INVALID_DATA; 

    m_fIsCableAttached = FALSE;

    // Translate to System Address.
	PhysicalAddress.HighPart = 0;
	PhysicalAddress.LowPart = (DWORD) AT91C_BASE_PMC;
	m_pPMC = (AT91PS_PMC ) MmMapIoSpace(PhysicalAddress,sizeof(AT91S_PMC),FALSE);
	 
	
	//Power-up the USB Function Port	
	m_pPMC->PMC_SCER = AT91C_PMC_UDP; // Start the clock here	
	m_pPMC->PMC_PCER = (1 << AT91C_ID_UDP);		
	
	if (m_pUDP == NULL)
	{
		PHYSICAL_ADDRESS ioPhysicalBase;
		ioPhysicalBase.HighPart = 0;  
		ioPhysicalBase.LowPart = (DWORD)AT91C_BASE_UDP;
		m_pUDP = (AT91PS_UDP)MmMapIoSpace(ioPhysicalBase, sizeof(AT91S_UDP), FALSE);
	}
  
	// Set peripheral interrupt configuration information
	dwPeripheralLogintr = AT91C_ID_UDP;
    if(!KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &dwPeripheralLogintr, sizeof(dwPeripheralLogintr), &m_dwPeriphSysIntr, sizeof(m_dwPeriphSysIntr), NULL))
	{
		RETAILMSG(1, (TEXT("ERROR: Failed to request the peripheral sysintr for USB Device (logintr :%d).\r\n"), dwPeripheralLogintr));
		m_dwPeriphSysIntr = SYSINTR_UNDEFINED;
		return ERROR_INVALID_DATA;
	}
    
	m_hPeriphEvent= CreateEvent(0, FALSE, FALSE, NULL);
    if (m_hPeriphEvent != NULL)
	{
        if (!InterruptInitialize(m_dwPeriphSysIntr, m_hPeriphEvent, 0, 0))
		{
			RETAILMSG(1, (TEXT("ERROR: InterruptInitialize Failed for USB Device peripheral controler")));
		}
	}
    else
	{
       return ERROR_INVALID_DATA;
	}
	
	// Configure Ras Entry
#ifdef USE_RAS	
	CreateThread (NULL, 0, RasInitThread, (LPVOID)this, 0, NULL);
#endif

    // Read the IST priority
    DWORD dwDataSize = sizeof(m_dwPriority);
    if (!GetRegValue(AT91RM_USBFUNCTION_PRIORITY_VALNAME,(LPBYTE) & m_dwPriority, dwDataSize)) 
	{
        m_dwPriority = AT91RM_USBFUNCTION_DEFAULT_PRIORITY;
    }
    CeSetPriority(m_dwPriority);
    if (HardwareInit()) 
	{
        ThreadStart();
        return ERROR_SUCCESS;
    }
    else
        return ERROR_INVALID_DATA;
}

//-----------------------------------------------------------------------------
//! \brief		This function inits the hardware
//!
//! \return		TRUE	Always returns TRUE
//!
//! Disables and clears every interrupt.
//-----------------------------------------------------------------------------
BOOL AT91RMUsbDevice::HardwareInit()
{
    BOOL bReturn = TRUE;

    SETFNAME();
    FUNCTION_ENTER_MSG();
    Lock();
    // Disable Hardware
	m_pUDP->UDP_IDR = 0xFFFFFFFF; 
 	m_pUDP->UDP_ICR = 0xFFFFFFFF;
	m_pUDP->UDP_FADDR &= ~AT91C_UDP_FEN;
    Unlock();
    FUNCTION_LEAVE_MSG();
    return bReturn;
}

//-----------------------------------------------------------------------------
//! \brief		This function reinits the hardware
//!
//! \return		FALSE	Always returns FALSE
//!
//! Enables and initializes interrupt
//! Calls HardwareInit, EnableEndpointInterrupt and Start
//-----------------------------------------------------------------------------
BOOL   AT91RMUsbDevice::ReInit() // For Cable Detach & Attach , We have to re-init the Device Controller.
{
    Lock();
    HardwareInit();
    for (DWORD dwIndex=1; dwIndex < MAX_ENDPOINT_NUMBER; dwIndex++)
	{
        AT91RMEndpoint *pEndpoint = RawObjectIndex(dwIndex);
		if (pEndpoint != NULL)  
		{
		    pEndpoint->ReInitEndpoint();
		}
   	}     

    Start();
    
    Unlock();
    return FALSE;
}

#ifdef USE_RAS
DWORD AT91RMUsbDevice::RasInitThread(LPVOID pThreadParam)
{
	AT91RMUsbDevice *pUsbDevice = (AT91RMUsbDevice *)pThreadParam;

	if (pUsbDevice != NULL)
	{
		return pUsbDevice->RasInit();
		
	}
	else
		return ERROR_INVALID_DATA;
}

//-----------------------------------------------------------------------------
//! \brief		This function inits the ras entry for repllog
//!
//!
//! \return		ERROR_INVALID_DATA	Got a problem
//! \return		ERROR_SUCCESS		No problem
//!
//! This function inits the ras entry for repllog
//-----------------------------------------------------------------------------
DWORD AT91RMUsbDevice::RasInit()
{
	HKEY hKey;
	LONG lResult = 0;
	wchar_t lpStrValue[40];
	DWORD dwDataSize;
	LPTSTR lpStrDriverKey = NULL;
	LPTSTR lpStrFriendlyName = NULL;

	LPTSTR lpStrDriverSettings = NULL;
	
	lpStrValue[0] = TEXT('\0');

	// Get the registry entry
	lResult = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
						   AT91RM_USBFUNCTION_DRIVER_VALNAME,
						   0,
						   0,
						   &hKey);
	if (lResult != ERROR_SUCCESS)
	{
		RETAILMSG(1, (TEXT("ERROR: Failed to open registry for USB Device (key : %s).\r\n"), AT91RM_USBFUNCTION_DRIVER_VALNAME));
		return ERROR_INVALID_DATA;
	}

	
	// Get the default client driver used by Windows CE for USB Function
	dwDataSize = sizeof(lpStrValue);

	lResult = ::RegQueryValueEx (hKey,
								AT91RM_USBFUNCTION_DRIVERCLIENT_VALNAME,
								NULL,
								NULL, //AT91RM_USBFUNCTION_DRIVERCLIENT_VALTYPE,
								(LPBYTE)lpStrValue,
								&dwDataSize);
	if (lResult != ERROR_SUCCESS || dwDataSize == 0)
	{
		RETAILMSG(1, (TEXT("ERROR: Failed to get registry value for USB Device (key : %s).\r\n"), AT91RM_USBFUNCTION_DRIVERCLIENT_VALNAME));

		RegCloseKey(hKey);
		return ERROR_INVALID_DATA;
	}


	// Close key
	RegCloseKey (hKey);


	// Generate next key (HKEY_LOCAL_MACHINE\Drivers\USB\FunctionDrivers + lpStrValue)
	lpStrDriverKey = (LPTSTR) LocalAlloc(LPTR, (wcslen(AT91RM_USBFUNCTION_DRIVER_VALNAME) + wcslen((wchar_t *)lpStrValue) + sizeof('\\') + 1)* sizeof(TCHAR)); 
	
	if (lpStrDriverKey == NULL)
	{
		RETAILMSG(1, (TEXT("ERROR: Failed to get registry value for USB Device (key : %s).\r\n"), AT91RM_USBFUNCTION_DRIVERCLIENT_VALNAME));
		return ERROR_INVALID_DATA;
	}

	lpStrDriverKey[0] = TEXT('\0');

	swprintf(lpStrDriverKey, TEXT("%s\\%s"), AT91RM_USBFUNCTION_DRIVER_VALNAME, lpStrValue);


	// Open the new key generated from registry entrie
	// ex: [HKEY_LOCAL_MACHINE\Drivers\USB\FunctionDrivers\Serial_Class]
	lResult = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
						   lpStrDriverKey,
						   0,
						   0,
						   &hKey);
	if (lResult != ERROR_SUCCESS)
	{
		RETAILMSG(1, (TEXT("ERROR: Failed to open registry for USB Device (key : %s).\r\n"), lpStrDriverKey));

		LocalFree(lpStrDriverKey);
		return ERROR_INVALID_DATA;
	}


	// Ras entry needs the frienldy driver name used by Windows CE for USB Function
	dwDataSize = sizeof(lpStrValue);

	lResult = ::RegQueryValueEx (hKey,
								AT91RM_USBFUNCTION_DRIVERNAME_VALNAME,
								NULL,
								NULL, //AT91RM_USBFUNCTION_DRIVERNAME_VALTYPE,
								(LPBYTE)lpStrValue,
								&dwDataSize);
	if (lResult != ERROR_SUCCESS || dwDataSize == 0)
	{
		RETAILMSG(1, (TEXT("ERROR: Failed to get registry value for USB Device (key : %s).\r\n"), AT91RM_USBFUNCTION_DRIVERNAME_VALNAME));

		LocalFree(lpStrDriverKey);
		RegCloseKey(hKey);
		return ERROR_INVALID_DATA;
	}

	// Free memory
	LocalFree(lpStrDriverKey);

	// Close registry key
	RegCloseKey(hKey);

	// Store the friendly name
	lpStrFriendlyName = (LPTSTR) LocalAlloc(LPTR, (wcslen((wchar_t *)lpStrValue) + 1)* sizeof(TCHAR)); 

	if (lpStrFriendlyName == NULL)
	{
		RETAILMSG(1, (TEXT("ERROR: Failed to allocate memory to store USB Device FriendlyName.\r\n")));

		return ERROR_INVALID_DATA;

	}

	lpStrFriendlyName[0] = TEXT('\0');

	wcscpy(lpStrFriendlyName, lpStrValue);

	//
	// Set registry Ras entry to enable automatic connection over USB using ActiveSync (repllog)
	//

	SetUsbFunctionAsDefaultConn (lpStrFriendlyName);


	// Free memory
	LocalFree(lpStrFriendlyName);

	return ERROR_SUCCESS;
}

//
// Find a device ID from a given service provider
//

DWORD AT91RMUsbDevice::FindTSPDevice(
    HLINEAPP hLineApp,
    DWORD dwNumLines,
    DWORD dwAPIVersion,
    DWORD dwExtVersion,
    LPWSTR lpszTSPName,
    LPWSTR lpszTSPLineName
)
{

    DWORD dwFoundDeviceID = 0xffffffff;
    DWORD dwDeviceID;
    LPWSTR lpszProviderInfo;
    LPWSTR lpszLineName;
    BYTE buf[1024];
    LPLINEDEVCAPS lpDevCaps;
    DWORD rc;

    lpDevCaps = (LPLINEDEVCAPS) buf;
    lpDevCaps->dwTotalSize = sizeof (buf);

    DEBUGMSG (1, (TEXT ("%s: FindTSPDevice: %d line devices available\r\n"), AT91RM_USBFUNCTION_DRIVER_NAME, dwNumLines));
    for (dwDeviceID = 0; dwDeviceID < dwNumLines; dwDeviceID++)
	{
	    rc = lineGetDevCaps (
		hLineApp,
		dwDeviceID,
		dwAPIVersion,
		dwExtVersion,
		lpDevCaps
		);
	    if (rc)
		{
		    DEBUGMSG (1, (TEXT ("%s: FindTSPDevice: lineGetDevCaps(%d) returned 0x%x\r\n"), AT91RM_USBFUNCTION_DRIVER_NAME, dwDeviceID, rc));
		    continue;
		}
	    lpszProviderInfo = (LPWSTR) ((DWORD) lpDevCaps + lpDevCaps->dwProviderInfoOffset);
	    lpszLineName = (LPWSTR) ((DWORD) lpDevCaps + lpDevCaps->dwLineNameOffset);

	    DEBUGMSG (1, (TEXT ("%s: FindTSPDevice: Found TSP Device \"%s\", Line Name \"%s\", supporting %d addresses\r\n"), AT91RM_USBFUNCTION_DRIVER_NAME, lpszProviderInfo, lpszLineName, lpDevCaps->dwNumAddresses));

	    if (!(wcsicmp (lpszProviderInfo, lpszTSPName)))
		{
		    if (!(wcsicmp (lpszLineName, lpszTSPLineName)))
			{
			    dwFoundDeviceID = dwDeviceID;
			    break;
			}
		}
	}
    return dwFoundDeviceID;
}


void AT91RMUsbDevice::WaitForReply (HLINEAPP hLineApp)
{
    LINEMESSAGE LineMessage;

    lineGetMessage (hLineApp, &LineMessage, INFINITE);

    if (LineMessage.dwMessageID == LINE_REPLY)
	{
	    DEBUGMSG (1, (TEXT ("%s: WaitForReply got LINE_REPLY %x\r\n"), AT91RM_USBFUNCTION_DRIVER_NAME, LineMessage.dwParam2));
	}
}

LONG AT91RMUsbDevice::ModifyDevConfig (HLINEAPP hLineApp, HLINE hLine, PUNIMDM_CHG_DEVCFG pUCD)
{
    LONG rc;

    rc = lineDevSpecific (hLine, 0, NULL, pUCD, sizeof (*pUCD));

    DEBUGMSG (1, (TEXT ("%s: ModifyDevConfig: lineDevSpecific(%d) returned %x\r\n"), AT91RM_USBFUNCTION_DRIVER_NAME, pUCD->dwOption, rc));

    if (!(rc & 0x80000000))
	{
	    WaitForReply (hLineApp);
	    return 0;
	}

    return -1;
}
	//
	// Get the default DevConfig for this device
	//
LPVARSTRING AT91RMUsbDevice::GetDevConfig (DWORD dwDeviceID, LPWSTR pszDeviceClassName)
{
    DWORD dwLen;
    LPVARSTRING pDevCfg;

    //
    // Find out how big its DevConfig is, then get it.
    //
    dwLen = sizeof (VARSTRING);
    pDevCfg = (LPVARSTRING)LocalAlloc (LPTR, dwLen);

    if (NULL == pDevCfg)
	return NULL;

    pDevCfg->dwTotalSize = dwLen;

    if (lineGetDevConfig (dwDeviceID, pDevCfg, pszDeviceClassName))
	return NULL;

    if (pDevCfg->dwTotalSize < pDevCfg->dwNeededSize)
	{
	    dwLen = pDevCfg->dwNeededSize;
	    LocalFree (pDevCfg);
	    pDevCfg = (LPVARSTRING)LocalAlloc (LPTR, dwLen);

	    if (NULL == pDevCfg)
		return NULL;

	    pDevCfg->dwTotalSize = dwLen;

	    if (lineGetDevConfig (dwDeviceID, pDevCfg, pszDeviceClassName))
		return NULL;
	}
    return pDevCfg;
}

DWORD AT91RMUsbDevice::SetUsbFunctionAsDefaultConn (LPTSTR lpStrFriendlyName)
{
    // wait for various APIs ready
    DEBUGMSG (1, (TEXT ("%s: SetUsbFunctionAsDefaultConn: Waiting for SH_COMM and SH_TAPI APIs\r\n"), AT91RM_USBFUNCTION_DRIVER_NAME));

    while (!IsAPIReady (SH_COMM))
		Sleep (500);

    while (!IsAPIReady (SH_TAPI))
		Sleep (500);

    while (!IsAPIReady (SH_WMGR))
		Sleep (500);

    
	RASENTRY RasEntry;
	LPVARSTRING pDevCfg;

	DEBUGMSG (1, (TEXT ("%s: UsbfDefautlConnThread: Creating USB Connection \"%s\"\r\n"), AT91RM_USBFUNCTION_DRIVER_NAME, lpStrFriendlyName));

	ModifyDefaultRasEntry(lpStrFriendlyName, &RasEntry); // retreive and modify the default Ras Entry
	ModifyRetryTimeout(lpStrFriendlyName, &pDevCfg)	;	// Modify the retry Timeout in the DevCfg
	
	// write the new entry out

	if (RasSetEntryProperties (NULL, AT91RM_USBFUNCTION_DEFAULT_CONNECTION_NAME, &RasEntry, sizeof (RasEntry), (LPBYTE) pDevCfg + sizeof (VARSTRING), pDevCfg->dwUsedSize - sizeof (VARSTRING)))
    {
		DEBUGMSG (1, (TEXT ("%s: Error: %d from RasSetEntryProperties\r\n"), AT91RM_USBFUNCTION_DRIVER_NAME, GetLastError ()));
	}

	// Free memory
	LocalFree (pDevCfg);

	DEBUGMSG (1, (TEXT ("%s: USB Connectoid created\r\n"), AT91RM_USBFUNCTION_DRIVER_NAME));
    

   CreateRegDefaultConnection();
	
/*
	//Launch the connection ... (wait for the device to be connnected)
	if (hConnexionDetectedEvent)
	{
		WaitForSingleObject(hConnexionDetectedEvent,INFINITE);
		if (IsAPIReady (SH_WMGR))
	{
	CeEventHasOccurred (NOTIFICATION_EVENT_RS232_DETECTED, NULL);
			DEBUGMSG (1, (TEXT ("usbFunctionModemRxInterrupt: Signaled RLSD Cable Event\r\n")));

		}
	}
*/	

    return 0;
}

void AT91RMUsbDevice::ModifyDefaultRasEntry (LPTSTR lpStrFriendlyName, RASENTRY *RasEntry)
{
	
	DWORD cb;

	RasEntry->dwSize = sizeof (RASENTRY);
	cb = sizeof (RASENTRY);
	// get a default RAS entry
	if (RasGetEntryProperties (NULL, TEXT (""), RasEntry, &cb, NULL, NULL))
	    {
		DEBUGMSG (1, (TEXT ("%s: UsbfDefautlConnThread: RasGetEntryProperties failed!\r\n")));
	    }

	// Change the friendly name to be the usb cable connection
	wcscpy (RasEntry->szDeviceName, lpStrFriendlyName);

	// Change the device type to direct cable connection
	wcscpy (RasEntry->szDeviceType, RASDT_Direct);

	// negotiate TCP/IP protocol
	RasEntry->dwfNetProtocols = RASNP_Ip;

	// use point to point framing protocol
	RasEntry->dwFramingProtocol = RASFP_Ppp;

	RasEntry->dwfOptions = 0;
	RasEntry->dwCountryID = 0;
	RasEntry->dwCountryCode = 0;
	_tcscpy (RasEntry->szAreaCode, TEXT (""));
	_tcscpy (RasEntry->szLocalPhoneNumber, TEXT (""));

	// words fail me.

	RasEntry->dwAlternateOffset = 0;

	RasEntry->ipaddr.a = 0;
	RasEntry->ipaddr.b = 0;
	RasEntry->ipaddr.c = 0;
	RasEntry->ipaddr.d = 0;
	RasEntry->ipaddrDns.a = 0;
	RasEntry->ipaddrDns.b = 0;
	RasEntry->ipaddrDns.c = 0;
	RasEntry->ipaddrDns.d = 0;
	RasEntry->ipaddrDnsAlt.a = 0;
	RasEntry->ipaddrDnsAlt.b = 0;
	RasEntry->ipaddrDnsAlt.c = 0;
	RasEntry->ipaddrDnsAlt.d = 0;
	RasEntry->ipaddrWins.a = 0;
	RasEntry->ipaddrWins.b = 0;
	RasEntry->ipaddrWins.c = 0;
	RasEntry->ipaddrWins.d = 0;
	RasEntry->ipaddrWinsAlt.a = 0;
	RasEntry->ipaddrWinsAlt.b = 0;
	RasEntry->ipaddrWinsAlt.c = 0;
	RasEntry->ipaddrWinsAlt.d = 0;
	RasEntry->dwFrameSize = 0;

	// negotiate TCP/IP protocol
	RasEntry->dwfNetProtocols = RASNP_Ip;

	// use point to point framing protocol
	RasEntry->dwFramingProtocol = RASFP_Ppp;

	_tcscpy (RasEntry->szScript, TEXT (""));

	// words fail me.

	_tcscpy (RasEntry->szAutodialDll, TEXT (""));
	_tcscpy (RasEntry->szAutodialFunc, TEXT (""));

	_tcscpy (RasEntry->szX25PadType, TEXT (""));
	_tcscpy (RasEntry->szX25Address, TEXT (""));
	_tcscpy (RasEntry->szX25Facilities, TEXT (""));
	_tcscpy (RasEntry->szX25UserData, TEXT (""));

	RasEntry->dwChannels = 1;	// ???

	RasEntry->dwReserved1 = 0;
	RasEntry->dwReserved2 = 0;
}

BOOL AT91RMUsbDevice::ModifyRetryTimeout(LPTSTR lpStrFriendlyName, LPVARSTRING *pDevCfg)
{
	
	HLINEAPP hLineApp;
	HLINE hLine;
	DWORD dwNumLines;
	DWORD dwAPIVersion;
	DWORD dwExtVersion;

	LPWSTR pDevClass;
	LONG rc;
	UNIMDM_CHG_DEVCFG UCD;
	DWORD dwDeviceID;

	LINEINITIALIZEEXPARAMS LineInitializeExParams =
	{
	    sizeof (LINEINITIALIZEEXPARAMS),	//dwTotalSize
	     0,			//dwNeededSize
	     0,			//dwUsedSize
	     LINEINITIALIZEEXOPTION_USEEVENT,	//dwOptions
	     0,			//Handles
	     0			//dwCompletionKey
	};
		
	// Initialize TAPI
	dwAPIVersion = TAPI_CURRENT_VERSION;
	dwExtVersion = 0;

	rc = lineInitializeEx (
	    &hLineApp,
	    NULL /* hInstance */ ,
	    NULL,
	    TEXT ("DEVCFG"),
	    &dwNumLines,
	    &dwAPIVersion,
	    &LineInitializeExParams
	    );

	if (rc)
	    {
		DEBUGMSG (1, (TEXT ("%s: lineInitializeEx failed %x\r\n"), AT91RM_USBFUNCTION_DRIVER_NAME, rc));
		return FALSE;
	    }

	// find the TAPI UNIMODEM USBF serial device
	dwDeviceID = FindTSPDevice (hLineApp, dwNumLines, dwAPIVersion, dwExtVersion, L"UNIMODEM", lpStrFriendlyName);

	// Open unimodem TSP device
	rc = lineOpen (hLineApp, dwDeviceID, &hLine, dwAPIVersion, dwExtVersion, 0, LINECALLPRIVILEGE_OWNER, LINEMEDIAMODE_DATAMODEM, NULL);
	if (rc)
	    {
		DEBUGMSG (1, (TEXT ("%s: lineOpen failed %x\r\n"), AT91RM_USBFUNCTION_DRIVER_NAME, rc));
		return FALSE;
	    }

	// set direct connection class
	// Check platform build documentation for "device class name" to find list of valid names
	pDevClass = TEXT ("comm");

	// Get default line configuration for COMM devices
	*pDevCfg = GetDevConfig (dwDeviceID, pDevClass);
	if (NULL == pDevCfg)
	    {
		DEBUGMSG (1, (TEXT ("%s: GetDevConfig failed\r\n"), AT91RM_USBFUNCTION_DRIVER_NAME));
		return FALSE;
	    }

	// Modify devconfig to change timeout
	UCD.dwCommand = UNIMDM_CMD_CHG_DEVCFG;
	UCD.lpszDeviceClass = pDevClass;
	UCD.lpDevConfig = *pDevCfg;

	UCD.dwOption = UNIMDM_OPT_TIMEOUT;
	UCD.dwValue = AT91RM_USBFUNCTION_DEFAULT_DIRECT_CONNECT_TIMEOUT_SECONDS;
	if (ModifyDevConfig (hLineApp, hLine, &UCD))
	    {
		DEBUGMSG (1, (TEXT ("%s: ModifyDevConfig failed!\r\n"), AT91RM_USBFUNCTION_DRIVER_NAME));
	    }

	lineShutdown (hLineApp);
	
	return TRUE;
}

void AT91RMUsbDevice::CreateRegDefaultConnection()
{
	HKEY hKey;
	DWORD dwDisp;
	TCHAR szDefaultConnectionName[] = AT91RM_USBFUNCTION_DEFAULT_CONNECTION_NAME;

	if (ERROR_SUCCESS == RegCreateKeyEx (HKEY_CURRENT_USER, TEXT("ControlPanel\\Comm"), 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hKey, &dwDisp))
	    {
		::RegSetValueEx (hKey, TEXT("Cnct"), 0, REG_SZ, (LPBYTE) szDefaultConnectionName, sizeof (TCHAR) * (lstrlen (szDefaultConnectionName) + 1));
		RegCloseKey (hKey);
		DEBUGMSG (1, (TEXT ("%s: Default connection set to '%s'\r\n"), AT91RM_USBFUNCTION_DRIVER_NAME, szDefaultConnectionName));
	    }
}
#endif      
	


//-----------------------------------------------------------------------------
//! \brief		This function deletes endpoints
//!
//! \return		TRUE	Always returns TRUE
//!
//-----------------------------------------------------------------------------
BOOL AT91RMUsbDevice::DeleteAllEndpoint()
{
    for (DWORD dwIndex=0; dwIndex<MAX_ENDPOINT_NUMBER; dwIndex++)
        RemoveObjectBy( dwIndex );
    return TRUE;
}

//-----------------------------------------------------------------------------
//! \brief		This function enables or disables endpoints interrupt
//!
//! \param		dwEndpointIndex		Endpoint to enable or disable
//! \param		bEnable				TRUE = enable; FALSE = disable
//!
//! \return		TRUE	Always returns TRUE
//!
//-----------------------------------------------------------------------------
#define UDCIR0_MAX 0x5
BOOL   AT91RMUsbDevice::EnableEndpointInterrupt(DWORD dwEndpointIndex,BOOL bEnable)
{
    
	DEBUGMSG(ZONE_USB_EVENTS, (L"DEVICE::EnableEndpointInterrupt"));
	
	SETFNAME();
    DEBUGMSG(ZONE_USB_EVENTS, (_T("%s Enter. dwEndpoint:0x%x,Enable:0x%x --\r\n"), pszFname,dwEndpointIndex,bEnable));
    
    if (dwEndpointIndex < MAX_ENDPOINT_NUMBER ) 
    {
        Lock();
		
		if (bEnable)
		{
			m_pUDP->UDP_IER = 1<<(dwEndpointIndex);
		}
		else 
		{
			m_pUDP->UDP_IDR = 1<<(dwEndpointIndex);
		}
		
	
        Unlock();
        return TRUE;
    }
	
	
    return FALSE;
}



// Interface Function : Those functions call the endpoint-specific functions.

//-----------------------------------------------------------------------------
//! \brief		This function lookd if the endpoint is supportable
//!
//! \param		dwEndpoint					Identification of the endpoint
//! \param		Speed						Speed supported
//! \param		pEndpointDesc				Descriptor of the endpoint
//! \param		bConfigurationValue			Value of the configuratin
//! \param		bInterfaceNumber			Interface selected
//! \param		bAlternateSetting			Alternate setting
//!
//! \return		ERROR_INVALID_PARAMETER		
//! \return		ERROR_SUCCESS				success
//!
//! Creates a endpoint and inits it.
//-----------------------------------------------------------------------------
DWORD AT91RMUsbDevice::IsEndpointSupportable (DWORD dwEndpoint,UFN_BUS_SPEED Speed,PUSB_ENDPOINT_DESCRIPTOR pEndpointDesc,
            BYTE bConfigurationValue, BYTE bInterfaceNumber, BYTE bAlternateSetting )
{
    DWORD dwError = ERROR_INVALID_PARAMETER;
    SETFNAME();
    DEBUGMSG(ZONE_FUNCTION, (_T("%s Enter. dwEndpoint:0x%x,Speed:0x%x --\r\n"), pszFname,dwEndpoint,Speed));

	
	

    Lock();
    if ((Speed & BS_FULL_SPEED)==BS_FULL_SPEED &&  pEndpointDesc  &&
            dwEndpoint < MAX_ENDPOINT_NUMBER && RawObjectIndex(dwEndpoint)==0 ) 
    {
        AT91RMEndpoint *pEndpoint = NULL;
        if (dwEndpoint == 0 ) // Endpoint Zero.
        {
             pEndpoint = new AT91RMEndpointCtrl(this);
        }
        else 
        {			
            if ( (pEndpointDesc->bEndpointAddress & 0x80)!=0) 
            { 
				//The actual endpoint number is given in the address
                pEndpoint = new AT91RMEndpointIn(this,pEndpointDesc->bEndpointAddress & ~0x80);
            }
            else 
            {
				//The actual endpoint number is given in the address
                pEndpoint = new AT91RMEndpointOut(this,pEndpointDesc->bEndpointAddress & ~0x80);
            }
        }
        if (pEndpoint && pEndpoint->Init(pEndpointDesc,bConfigurationValue,bInterfaceNumber,bAlternateSetting)) 
        {
            dwError = ERROR_SUCCESS;
            InsertObject(dwEndpoint, pEndpoint) ;
        }
        else 
        {
            if (pEndpoint) 
            {
                delete pEndpoint;
            }
        }
    }
    Unlock();
    ASSERT(dwError == ERROR_SUCCESS);
    DEBUGMSG(ZONE_FUNCTION, (_T("%s return errorcode = %d --\r\n"), pszFname,dwError));
    return dwError;
}

//-----------------------------------------------------------------------------
//! \brief		This function inits the endpoint
//!
//! \param		dwEndpoint					Identification of the endpoint
//! \param		Speed						Speed supported
//! \param		pEndpointDesc				Descriptor of the endpoint
//! \param		bConfigurationValue			Value of the configuratin
//! \param		bInterfaceNumber			Interface selected
//! \param		bAlternateSetting			Alternate setting
//!
//! \return		ERROR_INVALID_PARAMETER		
//! \return		ERROR_SUCCESS				success
//!
//! Inits a endpoint.
//-----------------------------------------------------------------------------
DWORD AT91RMUsbDevice::InitEndpoint(DWORD dwEndpoint,UFN_BUS_SPEED Speed,PUSB_ENDPOINT_DESCRIPTOR pEndpointDesc,
            BYTE bConfigurationValue, BYTE bInterfaceNumber, BYTE bAlternateSetting )
{
   DEBUGMSG(ZONE_FUNCTION, (L"DEVICE::InitEndpoint"));
	
	DWORD dwError = ERROR_INVALID_PARAMETER;
    SETFNAME();
    FUNCTION_ENTER_MSG();
    AT91RMEndpoint *pEndpoint = ObjectIndex(dwEndpoint);
    if (pEndpoint) 
    {
        dwError = pEndpoint->InitEndpoint(Speed, pEndpointDesc);
    }
    FUNCTION_LEAVE_MSG();
    return dwError;
};

//-----------------------------------------------------------------------------
//! \brief		This function deinits the endpoint
//!
//! \param		dwEndpoint					Identification of the endpoint
//!
//! \return		ERROR_INVALID_PARAMETER		
//! \return		ERROR_SUCCESS				success
//!
//! Deinits a endpoint.
//-----------------------------------------------------------------------------
DWORD AT91RMUsbDevice::DeinitEndpoint(DWORD dwEndpoint)
{
    DEBUGMSG(ZONE_FUNCTION, (L"DEVICE::DeinitEndpoint"));
	
	DWORD dwError = ERROR_INVALID_PARAMETER;
    SETFNAME();
    FUNCTION_ENTER_MSG();
    AT91RMEndpoint *pEndpoint = ObjectIndex(dwEndpoint);
    if (pEndpoint) 
    {
        dwError = pEndpoint->DeinitEndpoint();
    }
    FUNCTION_LEAVE_MSG();
    return dwError;
    
}

//-----------------------------------------------------------------------------
//! \brief		This function stalls the endpoint
//!
//! \param		dwEndpoint					Identification of the endpoint
//!
//! \return		ERROR_INVALID_PARAMETER		
//! \return		ERROR_SUCCESS				success
//!
//! Stalls a endpoint.
//-----------------------------------------------------------------------------
DWORD AT91RMUsbDevice::StallEndpoint(DWORD dwEndpoint)
{
    DWORD dwError = ERROR_INVALID_PARAMETER;
    SETFNAME();
    FUNCTION_ENTER_MSG();
    AT91RMEndpoint *pEndpoint = ObjectIndex(dwEndpoint);
    if (pEndpoint) 
    {
        dwError = pEndpoint->StallEndpoint();
    }
    FUNCTION_LEAVE_MSG();
    return dwError;
}

//-----------------------------------------------------------------------------
//! \brief		This function clears the stalls on the endpoint
//!
//! \param		dwEndpoint					Identification of the endpoint
//!
//! \return		ERROR_INVALID_PARAMETER		
//! \return		ERROR_SUCCESS				success
//!
//! Clears the stall on a endpoint.
//-----------------------------------------------------------------------------
DWORD AT91RMUsbDevice::ClearEndpointStall(DWORD dwEndpoint)
{
    DWORD dwError = ERROR_INVALID_PARAMETER;
    SETFNAME();
    FUNCTION_ENTER_MSG();
    AT91RMEndpoint *pEndpoint = ObjectIndex(dwEndpoint);
    if (pEndpoint) 
    {
        dwError = pEndpoint->ClearEndpointStall();
    }
    FUNCTION_LEAVE_MSG();
    return dwError;    
}

//-----------------------------------------------------------------------------
//! \brief		This function resets the endpoint
//!
//! \param		dwEndpoint					Identification of the endpoint
//!
//! \return		ERROR_INVALID_PARAMETER		
//! \return		ERROR_SUCCESS				success
//!
//! Resets the endpoint.
//-----------------------------------------------------------------------------
DWORD AT91RMUsbDevice::ResetEndpoint(DWORD dwEndpoint)
{
    DWORD dwError = ERROR_INVALID_PARAMETER;
    SETFNAME();
    FUNCTION_ENTER_MSG();
    AT91RMEndpoint *pEndpoint =  ObjectIndex(dwEndpoint);
    if (pEndpoint) 
    {
        dwError = pEndpoint->ResetEndpoint();
    }
    FUNCTION_LEAVE_MSG();
    return dwError;    
    
}

//-----------------------------------------------------------------------------
//! \brief		This function tests if the endpoint is halted
//!
//! \param		dwEndpoint					Identification of the endpoint
//! \param		pfHalted					Stores the status of the endpoint
//!
//! \return		ERROR_INVALID_PARAMETER		
//! \return		ERROR_SUCCESS				success
//!
//! Clears the stall on a endpoint.
//-----------------------------------------------------------------------------
DWORD AT91RMUsbDevice::IsEndpointHalted( DWORD dwEndpoint, PBOOL pfHalted )
{
    DWORD dwError = ERROR_INVALID_PARAMETER;
    SETFNAME();
    FUNCTION_ENTER_MSG();
    AT91RMEndpoint *pEndpoint =  ObjectIndex(dwEndpoint);
    if (pEndpoint) 
    {
        dwError = pEndpoint->IsEndpointHalted(pfHalted);
    }
    FUNCTION_LEAVE_MSG();
    return dwError;    
}

//-----------------------------------------------------------------------------
//! \brief		This function Issue the Transfer on the endpoint
//!
//! \param		dwEndpoint					Identification of the endpoint
//! \param		pTransfer					Transfer to be issued
//!
//! \return		ERROR_INVALID_PARAMETER		
//! \return		ERROR_SUCCESS				success
//!
//! Issue the Transfer on the endpoint.
//-----------------------------------------------------------------------------
DWORD AT91RMUsbDevice::IssueTransfer(DWORD  dwEndpoint,PSTransfer pTransfer )
{
    DWORD dwError = ERROR_INVALID_PARAMETER;
    SETFNAME();
    FUNCTION_ENTER_MSG();
    AT91RMEndpoint *pEndpoint =  ObjectIndex(dwEndpoint);
    if (pEndpoint) 
    {
        dwError = pEndpoint->IssueTransfer(pTransfer);
    }
    FUNCTION_LEAVE_MSG();
    return dwError;    
}

//-----------------------------------------------------------------------------
//! \brief		This function Abort the Transfer on the endpoint
//!
//! \param		dwEndpoint					Identification of the endpoint
//! \param		pTransfer					Transfer to be aborted
//!
//! \return		ERROR_INVALID_PARAMETER		
//! \return		ERROR_SUCCESS				success
//!
//! Abort the Transfer on the endpoint.
//-----------------------------------------------------------------------------
DWORD AT91RMUsbDevice::AbortTransfer(DWORD dwEndpoint, PSTransfer pTransfer)
{
    DWORD dwError = ERROR_INVALID_PARAMETER;
    SETFNAME();
    FUNCTION_ENTER_MSG();
    if (pTransfer) 
    {
        AT91RMEndpoint *pEndpoint =  ObjectIndex(dwEndpoint);
        if (pEndpoint) 
        {
            dwError = pEndpoint->AbortTransfer(pTransfer);
        }
    }
    FUNCTION_LEAVE_MSG();
    return dwError;    
}
    
//  Endpoint Zero Special

//-----------------------------------------------------------------------------
//! \brief		This function Send Control Status Handshake on the endpoint
//!
//! \param		dwEndpoint					Identification of the endpoint
//!
//! \return		ERROR_INVALID_PARAMETER		
//! \return		ERROR_SUCCESS				success
//!
//-----------------------------------------------------------------------------
DWORD AT91RMUsbDevice::SendControlStatusHandshake(DWORD dwEndpoint)
{
    DWORD dwError = ERROR_INVALID_PARAMETER;
    SETFNAME();
    FUNCTION_ENTER_MSG();
    AT91RMEndpoint *pEndpoint =  ObjectIndex(0);
    if (pEndpoint) 
    {
        dwError = pEndpoint->SendControlStatusHandshake();
    }
    FUNCTION_LEAVE_MSG();
    return dwError;    
}

//  Device Function.

//-----------------------------------------------------------------------------
//! \brief		This function Start the device
//!
//! \return		ERROR_SUCCESS				success
//!
//!Enable Device Interrupt
//-----------------------------------------------------------------------------
DWORD AT91RMUsbDevice::Start()
{
    SETFNAME();
    FUNCTION_ENTER_MSG();
    DWORD dwReturn = ERROR_SUCCESS;
    Lock();
    //ASSERT(m_pvMddContext==NULL);
    // Enable Device Interrupt.
    m_pUDP->UDP_IER = /*AT91C_UDP_RXSUSP | AT91C_UDP_RXRSM | AT91C_UDP_EXTRSM | AT91C_UDP_WAKEUP |*/ AT91C_UDP_ENDBUSRES | AT91C_UDP_EP0;
	m_pUDP->UDP_IDR = AT91C_UDP_RXSUSP | AT91C_UDP_RXRSM | AT91C_UDP_EXTRSM | AT91C_UDP_WAKEUP;
    Unlock();
    FUNCTION_LEAVE_MSG();
    return dwReturn;
}

//-----------------------------------------------------------------------------
//! \brief		This function Stop the device
//!
//! \return		ERROR_SUCCESS				success
//!
//!Disable Device Interrupt
//-----------------------------------------------------------------------------
DWORD AT91RMUsbDevice::Stop()
{
    SETFNAME();
    FUNCTION_ENTER_MSG();
    Lock();
    //ASSERT(m_pvMddContext!=NULL);
    //m_pvMddContext = NULL;
    // Disable Device Interrupt.
	m_pUDP->UDP_IDR = (0xFFFFFFFF);
    Unlock();
    FUNCTION_LEAVE_MSG();
    return ERROR_SUCCESS;
    
}

//-----------------------------------------------------------------------------
//! \brief		This function Set the Address of the device
//!
//! \return		ERROR_SUCCESS				success
//!
//!Just in case we need it
//-----------------------------------------------------------------------------
DWORD  AT91RMUsbDevice::SetAddress( BYTE  bAddress )
{
	// Set the address
	m_pUDP->UDP_FADDR |= (bAddress & AT91C_UDP_FADD); 	
	// Set device in address state
	m_pUDP->UDP_GLBSTATE |= AT91C_UDP_FADDEN;
	// Notify the MDD
	DeviceNotification(UFN_MSG_SET_ADDRESS, (DWORD) bAddress);

    return ERROR_SUCCESS;
}

//-----------------------------------------------------------------------------
//! \brief		This function manage the Power of the device
//!
//! \param		bOff	TRUE = Disable; FALSE = Enable
//!
//-----------------------------------------------------------------------------
void AT91RMUsbDevice::PowerMgr(BOOL bOff)
{
    Lock();
	if (bOff) 
	{
        // Disable Device to simulate remove from bus.
//        m_pUDP->UDP_TXVC |= AT91C_UDP_TXVDIS;
    }
    else 
	{
//		m_pUDP->UDP_TXVC &= ~AT91C_UDP_TXVDIS;
    }
    Unlock();
}

//-----------------------------------------------------------------------------
//! \brief		This function Power Down the device
//!
//-----------------------------------------------------------------------------
void AT91RMUsbDevice::PowerDown() 
{
    if (m_CurPowerState == PwrDeviceUnspecified) {
        PowerMgr(TRUE) ;
    }
}

//-----------------------------------------------------------------------------
//! \brief		This function Power Up the device
//!
//-----------------------------------------------------------------------------
void AT91RMUsbDevice::PowerUp()
{
    if (m_CurPowerState == PwrDeviceUnspecified) {
        PowerMgr(FALSE) ;
    }
}

//-----------------------------------------------------------------------------
//! \brief		This function set the Power state of the device
//!
//! \param		cpsNew	power state to be set
//!
//-----------------------------------------------------------------------------
void AT91RMUsbDevice::SetPowerState( CEDEVICE_POWER_STATE cpsNew )
{
    SETFNAME();
    // JJH : TODO 
}

//-----------------------------------------------------------------------------
//! \brief		This function set the Power state of the device
//!
//! \param		source						source of the IOCTL
//! \param		dwCode						nature of the IOCTL
//! \param		pbIn						buffer In
//! \param		cbIn						Number of bytes in Buffer In
//! \param		pbOut						buffer Out
//! \param		cbOut						Maximum number of bytes in Buffer Out
//! \param		pcbActualOut				Actual number of bytes in Buffer Out
//!
//! \return		ERROR_INVALID_PARAMETER		
//! \return		ERROR_SUCCESS				success
//!
//-----------------------------------------------------------------------------
DWORD AT91RMUsbDevice::IOControl(IOCTL_SOURCE source, DWORD dwCode, PBYTE  pbIn, DWORD cbIn, PBYTE pbOut, DWORD cbOut,PDWORD pcbActualOut)
{
    SETFNAME();
    FUNCTION_ENTER_MSG();

    DWORD dwRet = ERROR_INVALID_PARAMETER;

    switch (dwCode) {
    case IOCTL_UFN_GET_PDD_INFO:
        if ( source != BUS_IOCTL || pbOut == NULL || cbOut != sizeof(UFN_PDD_INFO) ) {
            break;
        }

        // Not currently supported.
        break;

    case IOCTL_BUS_GET_POWER_STATE:
        if (source == MDD_IOCTL) {
            PREFAST_DEBUGCHK(pbIn);
            DEBUGCHK(cbIn == sizeof(CE_BUS_POWER_STATE));

            PCE_BUS_POWER_STATE pCePowerState = (PCE_BUS_POWER_STATE) pbIn;
            PREFAST_DEBUGCHK(pCePowerState->lpceDevicePowerState);

            DEBUGMSG(ZONE_FUNCTION, (_T("%s IOCTL_BUS_GET_POWER_STATE\r\n"), pszFname));

            *pCePowerState->lpceDevicePowerState = m_CurPowerState;

            dwRet = ERROR_SUCCESS;
        }
        break;

    case IOCTL_BUS_SET_POWER_STATE:
        if (source == MDD_IOCTL) {
            PREFAST_DEBUGCHK(pbIn);
            DEBUGCHK(cbIn == sizeof(CE_BUS_POWER_STATE));

            PCE_BUS_POWER_STATE pCePowerState = (PCE_BUS_POWER_STATE) pbIn;

            PREFAST_DEBUGCHK(pCePowerState->lpceDevicePowerState);
            DEBUGCHK(VALID_DX(*pCePowerState->lpceDevicePowerState));

            DEBUGMSG(ZONE_FUNCTION, (_T("%s IOCTL_BUS_GET_POWER_STATE(D%u)\r\n"), pszFname, *pCePowerState->lpceDevicePowerState));
            SetPowerState( *pCePowerState->lpceDevicePowerState );
            dwRet = ERROR_SUCCESS;
        }
        break;
    }
    FUNCTION_LEAVE_MSG();
    return dwRet;
}


//-----------------------------------------------------------------------------
//! \brief		This function is the run thread
//!
//! \return		1
//!
//! This function handle every interrupts occurring in USBDevice and call the function corresponding to it.
//-----------------------------------------------------------------------------
#ifdef DEBUG
const DWORD cISTTimeOut = 2000;
#else
const DWORD cISTTimeOut = INFINITE ;
#endif
DWORD AT91RMUsbDevice::ThreadRun()
{
	DWORD dwUnmaskedStatus;
	DWORD dwMaskedStatus;

    SETFNAME();
    FUNCTION_ENTER_MSG();

	m_fIsCableAttached = FALSE;
	


    while (!m_bTerminated && m_hPeriphEvent!=NULL) 
    {

		// Check Cable...
		if ((m_fIsCableAttached == TRUE) && (IsCableAttached() == FALSE))
		{				
			DEBUGMSG(ZONE_FUNCTION, (_T("%s : Detach Detected\r\n"), pszFname));
			RETAILMSG(1, (_T("%s : Detach Detected\r\n"), pszFname));
			m_fIsCableAttached = FALSE;
			DeviceNotification(UFN_MSG_BUS_EVENTS, UFN_DETACH);					
			InterruptDone(m_dwPeriphSysIntr);
			ReInit();
		}

		dwUnmaskedStatus = m_pUDP->UDP_ISR;
		dwMaskedStatus = dwUnmaskedStatus & (m_pUDP->UDP_IMR | AT91C_UDP_ENDBUSRES);
		
		//Wait for an interesting interrupt. 

		if (dwMaskedStatus == 0)
		{
			if (WaitForSingleObject(m_hPeriphEvent, cISTTimeOut) != WAIT_OBJECT_0)
			{
				DEBUGMSG(ZONE_FUNCTION, (_T("USBFN - timeout (Status Registers : 0x%08X - Gloabal register : 0x%08X\r\n"), 
										m_pUDP->UDP_ISR,
										m_pUDP->UDP_GLBSTATE)); 		
				//RETAILMSG(1,(TEXT("timeout m_pUDP->UDP_ISR 0x%x m_pUDP->UDP_IMR 0x%x"),m_pUDP->UDP_ISR,m_pUDP->UDP_IMR));

				continue;
			}
		}
		
	//	DEBUGMSG(1, (_T("%s : IT (Status Registers : 0x%08X - Global register : 0x%08X, IMR : 0x%08X\r\n"), 
	//								pszFname,
	//								dwUnmaskedStatus,
	//								m_pUDP->UDP_GLBSTATE, 
	//								(m_pUDP->UDP_IMR | AT91C_UDP_ENDBUSRES))); 		

        // Processing Device Interrupt 
		if (dwUnmaskedStatus & AT91C_UDP_WAKEUP) 
		{ // Resume Detected
  //          DEBUGMSG(1, (_T("%s : Reset Wanted\r\n"), pszFname));
			m_pUDP->UDP_ICR = AT91C_UDP_WAKEUP;

			// Set device in non configured state
			m_pUDP->UDP_GLBSTATE &= ~AT91C_UDP_CONFG;
        }
		if (dwUnmaskedStatus & AT91C_UDP_RXRSM) 
		{ // Resume Detected
  //          DEBUGMSG(1, (_T("%s : Resume Detected\r\n"), pszFname));
			m_pUDP->UDP_ICR = AT91C_UDP_RXRSM;
        }
        if (dwUnmaskedStatus & AT91C_UDP_EXTRSM) 
        { // Suspend Detected.
    //        DEBUGMSG(1, (_T("%s : External resume Detected\r\n"), pszFname));
			m_pUDP->UDP_ICR = AT91C_UDP_EXTRSM;
        }
        if (dwUnmaskedStatus & AT91C_UDP_RXSUSP) 
        { // Suspend Detected.
  //          DEBUGMSG(1, (_T("%s : Suspend Detected\r\n"), pszFname));
			m_pUDP->UDP_ICR = AT91C_UDP_RXSUSP;
        }
        if (dwUnmaskedStatus & AT91C_UDP_ENDBUSRES) 
        { // Reset Detected.
      //      DEBUGMSG (1, (_T("%s : Reset Detected\r\n"), pszFname));
			m_pUDP->UDP_ICR = AT91C_UDP_ENDBUSRES;			
			//Go back to default state (actually back to addressed state)
			m_pUDP->UDP_GLBSTATE = 0;
			// Enable device
			m_pUDP->UDP_FADDR |= AT91C_UDP_FEN;

            // After Every Reset Notify MDD of Speed setting.			
			// Check Cable...

			if ((m_fIsCableAttached == FALSE) && (IsCableAttached() == TRUE))
			{				
			
				DEBUGMSG(ZONE_FUNCTION, (_T("%s : Attach Detected\r\n"), pszFname));
				RETAILMSG(1, (_T("%s : Attach Detected\r\n"), pszFname));
				m_fIsCableAttached = TRUE;
				// Set ATTACH. Otherwise received packets could not be treated by the MDD
				DeviceNotification(UFN_MSG_BUS_EVENTS, UFN_ATTACH);
				// This device can only support FULL Speed.
				DeviceNotification(UFN_MSG_BUS_SPEED, BS_FULL_SPEED);
				
			}
			Start();
			m_pUDP->UDP_CSR[0] |= AT91C_UDP_EPEDS;	// enables the endpoints Zero after a bus reset
			
        }

	
        for (DWORD dwIndex =0 ; dwIndex < UDCIR0_MAX ; dwIndex ++ ) 
		{
			AT91RMEndpoint *pEndpoint;
			//Look for the endpoint where the interrupt occurs.
			if ((pEndpoint = RawObjectIndex(dwIndex)) != NULL ) 
			{
				if  (dwMaskedStatus & pEndpoint->GetInterruptMask())
				{
					pEndpoint->IST(dwMaskedStatus);
				}            
			}
		}
        InterruptDone(m_dwPeriphSysIntr);
    }
    FUNCTION_LEAVE_MSG();
    return 1;
}


DWORD
WINAPI
UfnPdd_Deinit(
    PVOID pvPddContext
    )
{
    if (pvPddContext) 
    {
        delete ((AT91RMUsbDevice *)pvPddContext);
        return ERROR_SUCCESS ;
    }
    else
        return ERROR_INVALID_PARAMETER;;
}


DWORD 
WINAPI 
UfnPdd_IsConfigurationSupportable(
    PVOID                       pvPddContext,
    UFN_BUS_SPEED               Speed,
    PUFN_CONFIGURATION          pConfiguration
    )
{
    // TODO: Need to do anything?
    return ERROR_SUCCESS;
}


DWORD
WINAPI
UfnPdd_IsEndpointSupportable(
    PVOID                       pvPddContext,
    DWORD                       dwEndpoint,
    UFN_BUS_SPEED               Speed,
    PUSB_ENDPOINT_DESCRIPTOR    pEndpointDesc,
    BYTE                        bConfigurationValue,
    BYTE                        bInterfaceNumber,
    BYTE                        bAlternateSetting
    )
{
    // TODO: Use extra parameters
    
    DWORD dwError = ERROR_INVALID_PARAMETER;
    if (pvPddContext) 
    {
        dwError =((AT91RMUsbDevice *)pvPddContext)->IsEndpointSupportable( dwEndpoint, Speed, pEndpointDesc ,bConfigurationValue,bInterfaceNumber,bAlternateSetting );
    };
    return dwError;
}

DWORD
WINAPI
UfnPdd_InitEndpoint(
    PVOID                       pvPddContext,
    DWORD                       dwEndpoint,
    UFN_BUS_SPEED               Speed,
    PUSB_ENDPOINT_DESCRIPTOR    pEndpointDesc,
    PVOID                       pvReserved,
    BYTE                        bConfigurationValue,
    BYTE                        bInterfaceNumber,
    BYTE                        bAlternateSetting
    )
{
    DWORD dwError = ERROR_INVALID_PARAMETER;
    if (pvPddContext) 
    {
        dwError =((AT91RMUsbDevice *)pvPddContext)->InitEndpoint( dwEndpoint, Speed, pEndpointDesc, bConfigurationValue,bInterfaceNumber,bAlternateSetting );
    };
    return dwError;
}

DWORD
WINAPI
UfnPdd_RegisterDevice(
    PVOID                           pvPddContext,
    PCUSB_DEVICE_DESCRIPTOR         pHighSpeedDeviceDesc,
    PCUFN_CONFIGURATION             pHighSpeedConfig,
    PCUSB_CONFIGURATION_DESCRIPTOR  pHighSpeedConfigDesc,
    PCUSB_DEVICE_DESCRIPTOR         pFullSpeedDeviceDesc,
    PCUFN_CONFIGURATION             pFullSpeedConfig,
    PCUSB_CONFIGURATION_DESCRIPTOR  pFullSpeedConfigDesc,
    PCUFN_STRING_SET                pStringSets,
    DWORD                           cStringSets
    )
{
    return ERROR_SUCCESS;
}


DWORD
WINAPI
UfnPdd_DeregisterDevice(
    PVOID   pvPddContext
    )
{
    if (pvPddContext) 
    {
        ((AT91RMUsbDevice *)pvPddContext)->DeleteAllEndpoint();
    };
    return ERROR_SUCCESS;
}


DWORD
WINAPI
UfnPdd_Start(
    PVOID        pvPddContext
    )
{
    DWORD dwError = ERROR_INVALID_PARAMETER;
    if (pvPddContext) 
    {
        dwError =((AT91RMUsbDevice *)pvPddContext)->Start();
    };
    return dwError;
}

DWORD
WINAPI
UfnPdd_Stop(
    PVOID        pvPddContext
    )
{
    DWORD dwError = ERROR_INVALID_PARAMETER;
    if (pvPddContext) 
    {
        dwError =((AT91RMUsbDevice *)pvPddContext)->Stop();
    };
    return dwError;
}

DWORD
WINAPI
UfnPdd_IssueTransfer(
    PVOID  pvPddContext,
    DWORD  dwEndpoint,
    PSTransfer pTransfer
    )
{
    DWORD dwError = ERROR_INVALID_PARAMETER;
    if (pvPddContext) 
    {
        dwError =((AT91RMUsbDevice *)pvPddContext)->IssueTransfer(dwEndpoint,pTransfer);
    };
    return dwError;
}

DWORD
WINAPI
UfnPdd_AbortTransfer(
    PVOID           pvPddContext,
    DWORD           dwEndpoint,
    PSTransfer      pTransfer
    )
{
    DWORD dwError = ERROR_INVALID_PARAMETER;
    if (pvPddContext) 
    {
        dwError =((AT91RMUsbDevice *)pvPddContext)->AbortTransfer(dwEndpoint, pTransfer);
    };
    return dwError;
}

DWORD
WINAPI
UfnPdd_DeinitEndpoint(
    PVOID           pvPddContext,
    DWORD           dwEndpoint
    )
{
    DWORD dwError = ERROR_INVALID_PARAMETER;
    if (pvPddContext) 
    {
        dwError =((AT91RMUsbDevice *)pvPddContext)->DeinitEndpoint(dwEndpoint);
    };
    return dwError;
}

DWORD
WINAPI
UfnPdd_StallEndpoint(
    PVOID           pvPddContext,
    DWORD           dwEndpoint
    )
{
    DWORD dwError = ERROR_INVALID_PARAMETER;
    if (pvPddContext) 
    {
        dwError =((AT91RMUsbDevice *)pvPddContext)->StallEndpoint(dwEndpoint);
    };
    return dwError;
}

DWORD
WINAPI
UfnPdd_ClearEndpointStall(
    PVOID           pvPddContext,
    DWORD           dwEndpoint
    )
{
    DWORD dwError = ERROR_INVALID_PARAMETER;
    if (pvPddContext) 
    {
        dwError =((AT91RMUsbDevice *)pvPddContext)->ClearEndpointStall(dwEndpoint);
    };
    return dwError;
}

DWORD
WINAPI
UfnPdd_SendControlStatusHandshake(
    PVOID           pvPddContext,
    DWORD           dwEndpoint
    )
{
    DWORD dwError = ERROR_INVALID_PARAMETER;
    if (pvPddContext) 
    {
        dwError =((AT91RMUsbDevice *)pvPddContext)->SendControlStatusHandshake(dwEndpoint);
    };
    return dwError;
}


DWORD
WINAPI
UfnPdd_IsEndpointHalted(
    PVOID pvPddContext,
    DWORD dwEndpoint,
    PBOOL pfHalted
    )
{
    DWORD dwError = ERROR_INVALID_PARAMETER;
    if (pvPddContext) 
    {
        dwError =((AT91RMUsbDevice *)pvPddContext)->IsEndpointHalted(dwEndpoint,pfHalted);
    };
    return dwError;
}


DWORD
WINAPI
UfnPdd_InitiateRemoteWakeup(
    PVOID pvPddContext
    )
{
    // TODO: Fill in

    return ERROR_SUCCESS;
}


void
WINAPI
UfnPdd_PowerDown(
    PVOID pvPddContext
    )
{
    if (pvPddContext) 
    {
        ((AT91RMUsbDevice *)pvPddContext)->PowerDown();
    };
}

void
WINAPI
UfnPdd_PowerUp(
    PVOID pvPddContext
    )
{
    if (pvPddContext) 
    {
        ((AT91RMUsbDevice *)pvPddContext)->PowerUp();
    };
}


// IOCTLs with a Function value between 0x200 and 0x2FF are reserved 
// for the OEM.
DWORD
WINAPI
UfnPdd_IOControl(
    PVOID           pvPddContext,
    IOCTL_SOURCE    source,
    DWORD           dwCode,
    PBYTE           pbInBuf,
    DWORD           cbInBuf,
    PBYTE           pbOutBuf,
    DWORD           cbOutBuf,
    PDWORD          pcbActualOutBuf
    )
{
    DWORD dwError = ERROR_INVALID_PARAMETER;
    if (pvPddContext) 
    {
        dwError =((AT91RMUsbDevice *)pvPddContext)->IOControl(source, dwCode, pbInBuf, cbInBuf, pbOutBuf,  cbOutBuf, pcbActualOutBuf);
    };
    return dwError;
}


DWORD
WINAPI
UfnPdd_SetAddress(
    PVOID pvPddContext,
    BYTE  bAddress
    )
{
    DWORD dwError = ERROR_INVALID_PARAMETER;
    if (pvPddContext) 
    {
        dwError =((AT91RMUsbDevice *)pvPddContext)->SetAddress(bAddress);
    };
    return dwError;

}


// C- Converter.
extern "C"
DWORD
WINAPI
UfnPdd_Init(
    LPCTSTR                     pszActiveKey,
    PVOID                       pvMddContext,
    PUFN_MDD_INTERFACE_INFO     pMddInterfaceInfo,
    PUFN_PDD_INTERFACE_INFO     pPddInterfaceInfo
    )
{
    static const UFN_PDD_INTERFACE_INFO sc_PddInterfaceInfo = 
    {
        UFN_PDD_INTERFACE_VERSION,
        UFN_PDD_CAPS_SUPPORTS_FULL_SPEED,
        MAX_ENDPOINT_NUMBER,
        NULL,
        
        &UfnPdd_Deinit,
        &UfnPdd_IsConfigurationSupportable,
        &UfnPdd_IsEndpointSupportable,
        &UfnPdd_InitEndpoint,
        &UfnPdd_RegisterDevice,
        &UfnPdd_DeregisterDevice,
        &UfnPdd_Start,
        &UfnPdd_Stop,
        &UfnPdd_IssueTransfer,
        &UfnPdd_AbortTransfer,
        &UfnPdd_DeinitEndpoint,
        &UfnPdd_StallEndpoint,
        &UfnPdd_ClearEndpointStall,
        &UfnPdd_SendControlStatusHandshake,
        &UfnPdd_SetAddress,
        &UfnPdd_IsEndpointHalted,
        &UfnPdd_InitiateRemoteWakeup,
        &UfnPdd_PowerDown,
        &UfnPdd_PowerUp,
        &UfnPdd_IOControl,
    };

    memcpy(pPddInterfaceInfo, &sc_PddInterfaceInfo, sizeof(sc_PddInterfaceInfo));
    
    AT91RMUsbDevice * pDevice = CreateAT91RMUsbDevice(pszActiveKey );
    if (pDevice && pDevice->Init(pvMddContext, pMddInterfaceInfo, pPddInterfaceInfo) == ERROR_SUCCESS) 
    {
        return ERROR_SUCCESS;
    }
    
    if (pDevice!=NULL)
        delete pDevice;

    return ERROR_INVALID_PARAMETER;
}


extern "C"
BOOL
UfnPdd_DllEntry(
    HANDLE hDllHandle,
    DWORD  dwReason, 
    LPVOID lpReserved
    )
{
    return TRUE; // Nothing to do.
}


#ifdef DEBUG
UFN_GENERATE_DPCURSETTINGS(UFN_DEFAULT_DPCURSETTINGS_NAME, 
    _T(""), _T(""), _T(""), _T(""),
    0xF );//| DBG_ERROR | DBG_WARNING | DBG_INIT);
#endif

//! @}
