//-----------------------------------------------------------------------------
//! \addtogroup	DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/NandFlashEBOOT/NandFlash.c
//!
//! \brief		NandFlash driver for AT91SAM926x chipset
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/NandFlashEBOOT/NandFlash.c $
//!   $Author: ltourlonias $
//!   $Revision: 657 $
//!   $Date: 2007-04-10 16:52:09 +0200 (mar., 10 avr. 2007) $
//! \endif
//!
//! 
//-----------------------------------------------------------------------------
//! \addtogroup	NandFlash
//! @{
//!

// System specific include
#include <windows.h>
#include <nkintr.h>
#include <oal.h>	
#include <fmd.h>

// Platform specific include
#include "AT91SAM926x_oal_ioctl.h"
#include "AT91SAM926x_interface.h"

#include "NandFlash.h"
#include "LLD_Generic.h"

extern void NandFlashPlatform_Init(NandChip *);
extern void NandFlashProc_ChipSelect(NandChip *, DWORD);
extern void NandFlashProc_BusWidth16(NandChip *);
extern void NandFlashProc_RegistersInit(NandChip *, DWORD);
extern void NandFlashProc_RegistersRelease(NandChip *, DWORD);
extern void NandFlashPlaftorm_PioSetup(NandChip *);
extern void pio_set_value(unsigned pin, int value);
extern int pio_get_value(unsigned pin);

static void NandFlash_BusWidth16(NandChip *);
static void NandFlash_ChipSelect(NandChip *, DWORD);
static void NandFlash_InteruptsInit(NandChip *);
static void NandFlash_InteruptsRelease(NandChip *);
static void NandFlash_RegistersInit(NandChip *, DWORD);
static void NandFlash_RegistersRelease(NandChip *, DWORD);
static BOOL NandFlash_ConfigureNF(NandChip *pChip, DWORD);
static BOOL NandFlash_ConfigureLLD(NandChip *pChip);
static BOOL NandFlash_Reset(NandChip *pChip);

static void tempo(volatile DWORD j)
{
	while(j--);
}

static BYTE NandFlash_ReadByte(NandChip * pChip)
{
	return *((PBYTE) pChip->pFlashBase);
}

static BYTE NandFlash_ReadByte16(NandChip * pChip)
{
	return (BYTE) *((WORD *) pChip->pFlashBase);
}

static WORD NandFlash_ReadWord(NandChip * pChip)
{
	return *((WORD *) pChip->pFlashBase);
}

static void NandFlash_ReadBuf(NandChip * pChip, BYTE * pOutBuffer, DWORD dwLen)
{
	DWORD i;

	for (i = 0; i < dwLen; i++)
	{
		pOutBuffer[i] = *((volatile BYTE *) pChip->pFlashBase);	
	}
}

static void NandFlash_ReadBuf16(NandChip * pChip, BYTE * pOutBuffer, DWORD dwLen)
{
	DWORD i;
	WORD *pOutBuffer16 = (WORD *) pOutBuffer;
    dwLen /= 2;

    for (i = 0; i < dwLen; i++)
	{
		pOutBuffer16[i] = *((volatile WORD *) pChip->pFlashBase);
	}
}

static void NandFlash_WriteBuf(NandChip * pChip, PBYTE pInBuffer, DWORD dwLen)
{
	DWORD i;

	for (i = 0; i < dwLen; i++)
	{
		*((PBYTE) pChip->pFlashBase) = pInBuffer[i];	
	}
}

static void NandFlash_WriteBuf16(NandChip * pChip, PBYTE pInBuffer, DWORD dwLen)
{
	DWORD i;
	WORD *pInBuffer16 = (WORD *) pInBuffer;
    dwLen /= 2;

    for (i = 0; i < dwLen; i++)
	{
		*((WORD *) pChip->pFlashBase) = pInBuffer16[i];
	}
}

static void NandFlash_WriteCmd(NandChip * pChip, UCHAR cmd)
{
	*(pChip->pFlashCmd) = cmd;
}

static void NandFlash_WriteAddr(NandChip * pChip, UCHAR addr)
{
	*(pChip->pFlashAddr) = addr;
}

static NandChip StaticChip;

NandChip * NandFlash_Alloc()
{
	NandChip *pChip = &StaticChip;
	DEBUGMSG(1, (TEXT("->NandFlash_Alloc\n\r")));
	if(!pChip)
	{
		return NULL;
	}

	memset(pChip, 0, sizeof(*pChip));

	DEBUGMSG(1, (TEXT("<-NandFlash_Alloc\n\r")));
	return pChip;
}


BOOL NandFlash_LowLevelInit(NandChip * pChip)
{
	BOOL	bRet				= TRUE;
	DWORD	dwBW = 8;
	WORD	wManufacturerID	= 0;
	WORD	wDeviceID			= 0;
	DWORD	i					= 0;
	DEBUGMSG(1, (TEXT("->NandFlash_LowLevelInit\n\r")));

	/* Platform specific init */
	NandFlashPlatform_Init(pChip);
	
	/* Low Level Init */
	NandFlash_RegistersInit(pChip, dwBW);
	NandFlashProc_ChipSelect(pChip, dwBW);
	NandFlashPlaftorm_PioSetup(pChip);

	bRet = NandFlash_ConfigureNF(pChip, dwBW); /* Configure NF Interface, we need that for NandFlash_Reset */
	if(!bRet) {
		goto exit;
	}
	
	bRet = NandFlash_Reset(pChip);
	if(!bRet) {
		goto exit;
	}

	/* Get Chip Id */
	NandFlash_RetreiveIDs(pChip, &wManufacturerID, &wDeviceID);

	DEBUGMSG(1, (TEXT("NandFlash_LowLevelInit::Addr : Base 0x%X | Ale 0x%X | Cle 0x%X\n\r"), pChip->dwPhyNandBaseAddr, pChip->dwPhyNandAleAddr, pChip->dwPhyNandCleAddr));
	DEBUGMSG(1, (TEXT("NandFlash_LowLevelInit::DeviceIDs : Man 0x%X | Dev 0x%X\n\r"), wManufacturerID, wDeviceID));

	/* Get the right chip */
	for(i = 0; g_FlashDevIds[i].dwCompleteID; ++i)
	{
		if(g_FlashDevIds[i].wManID == wManufacturerID &&
			g_FlashDevIds[i].wDevID == wDeviceID)
			break;
	}

	if(!g_FlashDevIds[i].dwCompleteID) /* Chip not found */
	{
		DEBUGMSG(1, (TEXT("NandFlash_LowLevelInit::Unknonw device !\n\r")));
		NandFlash_Release(pChip);
		return FALSE;
	}

	/* Set the right FlashDev */
	pChip->pFlashDev = &(g_FlashDevIds[i]);

	/* Set the right BusWidth */
	dwBW = (pChip->pFlashDev->dwFlags & NAND_BUSWIDTH16) ? 16 : 8;
	DEBUGMSG(1, (TEXT("NandFlash_LowLevelInit::Device name : %s\n\r"), pChip->pFlashDev->sFriendlyName));
	DEBUGMSG(1, (TEXT("NandFlash_LowLevelInit::Bus Width %d\n\r"), dwBW));

	/* Reset NF Functions */
	{
		pChip->NFIface.ReadByte = NULL;
		pChip->NFIface.ReadWord = NULL;
		pChip->NFIface.WriteBuf = NULL;
		pChip->NFIface.WriteAddr = NULL;
		pChip->NFIface.WriteCmd = NULL;
	}

	/* Chip Init function (can set specific LLD/NF functions) */
	if(pChip->pFlashDev->Init)
	{
		pChip->pFlashDev->Init(pChip);
	}

	NandFlash_ConfigureNF(pChip, dwBW); /* Reconfigure NF */

	if(pChip->pFlashDev->dwFlags & NAND_BUSWIDTH16) /* We need to set specifics settings */
	{
		NandFlash_BusWidth16(pChip);
		DEBUGMSG(1, (TEXT("NandFlash_LowLevelInit::Bus Width changed to 16\n\r"), dwBW));
	}

	/* Calc the chip size */
	{
		DWORD dwSectorNbBytes	= pChip->pFlashDev->dwDataNbBytes + pChip->pFlashDev->dwSpareNbBytes;
		DWORD dwBlockNbBytes	= pChip->pFlashDev->dwBlockNbSectors * dwSectorNbBytes;
		pChip->dwNbBytes = pChip->pFlashDev->dwNbBlocks * dwBlockNbBytes;
	}

	/* configure LLD Interface */
	bRet = NandFlash_ConfigureLLD(pChip);
	if(!bRet) {
		goto exit;
	}
exit:
	return bRet;
}

static BOOL NandFlash_Reset(NandChip * pChip)
{
	BOOL bRet = TRUE;

	NF_ENABLE(pChip);
	NF_WRITECMD(pChip, NAND_CMD_RESET);

	if (!NandFlash_WaitForReady(pChip, WAIT_POOL,RESET_TIMEOUT))
	{
		bRet = FALSE;
		DEBUGMSG(1, (TEXT("NandFlash_Reset::Timed out waiting for Nand Ready signal\n\r")));
		goto exit;
	}

exit:
	NF_DISABLE(pChip);
	return TRUE;
}

static BOOL NandFlash_ConfigureLLD(NandChip *pChip)
{
	/* Default LLD Interface */
	BOOL bRet = TRUE;
	LLD_Interface *LLDIface = &pChip->LLDIface;

	if(!LLDIface->EraseBlock)
	{
		LLDIface->EraseBlock = LLDGeneric_EraseBlock;
	}
	if(pChip->pFlashDev->dwFlags & NAND_SMALLPAGES)
	{
		DEBUGMSG(1, (TEXT("NandFlash_LowLevelInit::Small Pages\n\r")));
		if(!LLDIface->ReadSector)
		{
			LLDIface->ReadSector = LLDGeneric_ReadSectorSmall;
		}
		if(!LLDIface->WriteSector)
		{
			LLDIface->WriteSector = LLDGeneric_WriteSectorSmall;
		}
	} else {
		DEBUGMSG(1, (TEXT("NandFlash_LowLevelInit::Large Pages\n\r")));
		if(!LLDIface->ReadSector)
		{
			LLDIface->ReadSector = LLDGeneric_ReadSectorLarge;
		}
		if(!LLDIface->WriteSector)
		{
			LLDIface->WriteSector = LLDGeneric_WriteSectorLarge;
		}
	}

	return bRet;
}

static BOOL NandFlash_ConfigureNF(NandChip *pChip, DWORD dwBW) {
	/* Default NF Interface */
	BOOL bRet = TRUE;
	NF_Interface *NFIface = &pChip->NFIface;

	if(!NFIface->Enable || !NFIface->Disable || !NFIface->IsReady)
	{
		DEBUGMSG(1, (TEXT("NandFlash_LowLevelInit::NF_ENABLE, NF_DISABLE or NF_ISREADY is undefined\n\r")));
		bRet = FALSE;
		goto exit;
	}

	if(!NFIface->ReadByte)
	{
		NFIface->ReadByte = (dwBW == 16) ? NandFlash_ReadByte16 : NandFlash_ReadByte;
	}
	if(!NFIface->ReadBuf)
	{
		NFIface->ReadBuf = (dwBW == 16) ? NandFlash_ReadBuf16 : NandFlash_ReadBuf;
	}
	if(!NFIface->ReadWord)
	{
		NFIface->ReadWord = NandFlash_ReadWord;
	}
	if(!NFIface->WriteBuf)
	{
		NFIface->WriteBuf = (dwBW == 16) ? NandFlash_WriteBuf16 : NandFlash_WriteBuf;
	}
	if(!NFIface->WriteAddr)
	{
		NFIface->WriteAddr = NandFlash_WriteAddr;
	}
	if(!NFIface->WriteCmd)
	{
		NFIface->WriteCmd = NandFlash_WriteCmd;
	}

exit:
	return bRet;
}

BOOL NandFlash_Release(NandChip * pChip)
{
	BOOL bRet = TRUE;
	DWORD dwBW = 8;
	
	if(!pChip)
	{
		return bRet;
	}

	NF_DISABLE(pChip);

	if(pChip->pFlashDev)
	{
		dwBW = (pChip->pFlashDev->dwFlags & NAND_BUSWIDTH16) ? 16 : 8;
	}

	NandFlash_RegistersRelease(pChip, dwBW);

	return bRet;
}

static void NandFlash_RegistersInit(NandChip * pChip, DWORD dwBW)
{
	NandFlashProc_RegistersInit(pChip, dwBW);
	
	pChip->pFlashBase	= (PVOID) 			OALPAtoVA(pChip->dwPhyNandBaseAddr, FALSE);
	pChip->pFlashCmd	= (PUCHAR) 			OALPAtoVA(pChip->dwPhyNandCleAddr, FALSE);
	pChip->pFlashAddr	= (PUCHAR) 			OALPAtoVA(pChip->dwPhyNandAleAddr, FALSE);

	pChip->dwMasterClock	= AT91SAM926x_GetMasterClock(FALSE);
}

void NandFlash_BusWidth16(NandChip *pChip)
{
	NandFlashProc_BusWidth16(pChip);
	pChip->pFlashBase = (PVOID) OALPAtoVA(pChip->dwPhyNandBaseAddr, 16);
}

static void NandFlash_RegistersRelease(NandChip * pChip, DWORD dwBW)
{		
	NandFlashProc_RegistersRelease(pChip, dwBW);

	pChip->pFlashAddr = NULL;
	pChip->pFlashCmd = NULL;
	pChip->pFlashBase = NULL;
}

BOOL NandFlash_WaitForReady(NandChip * pChip, DWORD fWaitType, DWORD dwTimeout)
{
	DWORD dwEndDate;
	DWORD dwStartDate;


	BOOL bRet = TRUE;
	BYTE data = 0;
//	DEBUGMSG(1, (TEXT("->NandFlash_WaitForReady\n\r")));
	tempo(100);
	dwStartDate = OALGetTickCount();
	dwEndDate = dwStartDate + dwTimeout;
	
	switch(fWaitType)
	{
	// Interrupt on R/B PIO, not implemented for EBOOT
		// Pool on RDY/BSY instead
		case INTERRUPT_ON_READYBUSY:

		// Pooling on R/B PIO
		case POOL_ON_READYBUSY:

			// Pooling loop
			while ( !NF_ISREADY(pChip) )
			{
				// If we wait more than XXXX ms then the flash has timed out
				if (OALGetTickCount() >= dwEndDate)					
				{
					bRet = FALSE;
					goto exit;
				}
			}
		break;

		

		// Pool on StatusByte.
		case POOL_ON_STATUS:

		// Default mode = Pool on StatusByte
		default:

			// Check status
			do {
				if (OALGetTickCount() >= dwEndDate)					
				{
					bRet = FALSE;
					goto exit;
				}

				NF_WRITECMD(pChip, NAND_CMD_STATUS);
				data = NF_READBYTE(pChip);
				DEBUGMSG(1, (TEXT("NandFlash_WaitForReady:: %x"), data));
			} while(!(data & NAND_STATUS_READY)); // Pooling loop
	}

exit:

//	DEBUGMSG(1, (TEXT("counts : %d \n\r"), counter));
//	DEBUGMSG(1, (TEXT("<-NandFlash_WaitForReady\n\r")));
	return bRet;
}


BOOL NandFlash_RetreiveIDs(NandChip *pChip, WORD* wManufacturerID, WORD* wDeviceID)
{
	// In
	DEBUGMSG(1, (TEXT("->NandFlash_RetreiveIDs\n\r")));

	// Enable chipset
	NF_ENABLE(pChip);

	NF_WRITECMD(pChip, NAND_CMD_READID);
	NF_WRITEADDR(pChip, 0x00);

	*wManufacturerID	= NandFlash_ReadByte(pChip);
    *wDeviceID			= NandFlash_ReadByte(pChip);

	NF_DISABLE(pChip);

	DEBUGMSG(1, (TEXT("<-NandFlash_RetreiveIDs\n\r")));

	return TRUE;
}

// End of Doxygen group NandFlash Driver
//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/NandFlashEBOOT/NandFlash.c $
//-----------------------------------------------------------------------------
//
//! @}
