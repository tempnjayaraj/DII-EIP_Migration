//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM9261/KERNEL/RTC/rtc.c
//!
//! \brief		AT91SAM9261's processor's Hmatrix configuration
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/SOC/ATMEL/AT91SAM9261/KERNEL/RTC/rtc.c $
//!   $Author: jjhiblot $
//!   $Revision: 860 $
//!   $Date: 2007-05-22 10:33:20 +0200 (mar., 22 mai 2007) $
//! \endif
//-----------------------------------------------------------------------------

//! \addtogroup	RTC
//! @{

#include <windows.h>

#include "at91sam926x.h"


#define RTT_PERIOD 328 // The RTT counter is incremented every RTT_PERIOD number of slow clock (around every 1 ms if RTT_PERIOD = 33, 10ms if RTT_PERIOD = 328)

//-----------------------------------------------------------------------------
//! \fn       DWORD RTCProcSpecificGetGPBR(void)
//!
//!	\brief    This function returns the base address of the SYS GBR controller
//!
//!
//!
//! \return		base address of the SYS GBR controller
//-----------------------------------------------------------------------------
DWORD RTCProcSpecificGetGPBR(void)
{
	return (DWORD) AT91C_SYS_GPBR0;
}

//-----------------------------------------------------------------------------
//! \fn       DWORD RTCProcSpecificGetRTTCBaseAddress(void)
//!
//!	\brief    This function returns the base address of the RTT controller
//!
//!
//!
//! \return		base address of the RTT controller
//-----------------------------------------------------------------------------
DWORD RTCProcSpecificGetRTTCBaseAddress(void)
{
	return (DWORD) AT91C_BASE_RTTC;
}

//-----------------------------------------------------------------------------
//! \fn       DWORD RTCProcSpecificGetClockFrequency(void)
//!
//!	\brief    This function returns the slow clock frequency value
//!
//!
//!
//! \return		slow clock frequency value
//-----------------------------------------------------------------------------
DWORD RTCProcSpecificGetClockFrequency(void)
{
	return (DWORD) SLOW_CLOCK_FREQUENCY;
}

//-----------------------------------------------------------------------------
//! \fn       DWORD RTCProcSpecificGetRSTCBaseAddress(void)
//!
//!	\brief    This function returns the base address of the reset controller
//!
//!
//!
//! \return		base address of the Reset controller
//-----------------------------------------------------------------------------
DWORD RTCProcSpecificGetRSTCBaseAddress(void)
{
	return (DWORD) AT91C_BASE_RSTC;
}

//-----------------------------------------------------------------------------
//! \fn       DWORD RTCProcSpecificGetRTTPeriod(void)
//!
//!	\brief    This function returns the base address of the reset controller
//!
//!
//!
//! \return		RTT period
//-----------------------------------------------------------------------------
DWORD RTCProcSpecificGetRTTPeriod(void)
{
	return (DWORD) RTT_PERIOD;
}

//! @} end of subgroup RTC

//! @} end of group OAL


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK60/PLATFORM/COMMON/SRC/SOC/ATMEL/AT91SAM9261/KERNEL/RTC/rtc.c $
////////////////////////////////////////////////////////////////////////////////
//
