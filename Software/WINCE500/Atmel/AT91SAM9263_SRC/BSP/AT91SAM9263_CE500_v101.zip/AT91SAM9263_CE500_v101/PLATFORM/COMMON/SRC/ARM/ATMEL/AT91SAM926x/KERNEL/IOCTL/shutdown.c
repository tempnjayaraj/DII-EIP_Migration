//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		shutdown.c
//!
//! \brief		AT91SAM926x shutdown feature
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/IOCTL/shutdown.c $
//!   $Author: pblanchard $
//!   $Revision: 1058 $
//!   $Date: 2007-07-05 01:34:39 -0700 (Thu, 05 Jul 2007) $
//! \endif
//-----------------------------------------------------------------------------


//! \addtogroup	IOCTL
//! @{

#include <windows.h>
#include <oal.h>
#include <nkintr.h>

#include "at91sam926x.h"


extern void OEMCacheRangeFlush(VOID *pAddress, DWORD length, DWORD flags);
extern UINT64 GetAndUpdateRTCValue(BOOL);
extern void performShutdown(DWORD addrShdwC,UINT32 valueShd,DWORD addrRstC,UINT32 valueRst);
extern DWORD IOCTLProcSpecificGetSHDWCBaseAddress(void);
extern DWORD IOCTLProcSpecificGetRSTCBaseAddress(void);

BOOL (*g_pfnBSPIoCtlHalShutdown)(UINT32 code, VOID *pInpBuffer,UINT32 inpSize, VOID *pOutBuffer,UINT32 outSize, UINT32 *pOutSize) = NULL;



//-----------------------------------------------------------------------------
//! \fn			BOOL OALIoCtlHalShutdown(UINT32 code, VOID *pInpBuffer, UINT32 inpSize, VOID *pOutBuffer, UINT32 outSize, UINT32 *pOutSize)
//!
//! \brief		This function configures the shut down
//!
//!	\param		code			not used
//!	\param		pInpBuffer	not used
//!	\param		inpSize		not used
//!	\param		pOutBuffer	
//!	\param		outSize		Size of pOutBuffer
//!	\param		pOutSize		Size of pOutBuffer used
//!
//! \return		TRUE indictaes success
//! \return		FALSE indictaes failure (bad parameters)
//!
//-----------------------------------------------------------------------------
BOOL OALIoCtlHalShutdown(UINT32 code, VOID *pInpBuffer, 
                       UINT32 inpSize, VOID *pOutBuffer, 
                       UINT32 outSize, UINT32 *pOutSize)
{	

#define MAX_DEBOUNCE	0xF			 //Max debounce is 0xF (= 7.4 ms)
#define WAKEUP_DEBOUNCING_TIME	243 //debouncing time in number of slow clock period


	BOOL bIntFlag;
	DWORD dwDebounce;
	BOOL bResult = TRUE;
	AT91PS_SHDWC pShutdownCtrl = (AT91PS_SHDWC) OALPAtoVA(IOCTLProcSpecificGetSHDWCBaseAddress(),FALSE);
	
	if (pShutdownCtrl == NULL)
	{
		return FALSE;
	}


	RETAILMSG(1, (TEXT("+OALIoCtlHalShutdown\r\n")));
	
		
	bIntFlag = INTERRUPTS_ENABLE(FALSE);

	//Clip deboucing time
	dwDebounce = (WAKEUP_DEBOUNCING_TIME - 3)/16;
	if (dwDebounce > MAX_DEBOUNCE)
	{
		dwDebounce = MAX_DEBOUNCE;
	}

	//Configure the shutdown controller to wake up when the wake-up pin is asserted during xxx slow clock periods.
	pShutdownCtrl->SHDWC_SHMR = (dwDebounce << 4) | AT91C_SHDWC_WKMODE0_ANYLEVEL;

#ifdef RTC_IS_BASED_ON_RTT
	//Refresh the RTC so that the counter is reset
	GetAndUpdateRTCValue(TRUE);
#endif	


	OEMCacheRangeFlush (0, 0, CACHE_SYNC_WRITEBACK);

	// call the Board specific SHUTDOWN handler
	if (g_pfnBSPIoCtlHalShutdown)
	{
		if (g_pfnBSPIoCtlHalShutdown(code, pInpBuffer,inpSize, pOutBuffer,outSize,pOutSize) == FALSE)
		{
			INTERRUPTS_ENABLE(bIntFlag);
			return FALSE;
		}
	}

	//Assert the shutdown pin and reset the processor
	performShutdown((DWORD) &(((AT91PS_SHDWC)IOCTLProcSpecificGetSHDWCBaseAddress())->SHDWC_SHCR),(0xA5 << 24) | AT91C_SHDWC_SHDW,
					(DWORD) &(((AT91PS_RSTC)IOCTLProcSpecificGetRSTCBaseAddress())->RSTC_RCR),(0xA5 << 24 ) | AT91C_RSTC_PROCRST);

	return TRUE;
}

//! @} end of subgroup IOCTL

//! @} end of group OAL


////////////////////////////////////////////////////////////////////////////////
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/KERNEL/IOCTL/shutdown.c $
////////////////////////////////////////////////////////////////////////////////
//
