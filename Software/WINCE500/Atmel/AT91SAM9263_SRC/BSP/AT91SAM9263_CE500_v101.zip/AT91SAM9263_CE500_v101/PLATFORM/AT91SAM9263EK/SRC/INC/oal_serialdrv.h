//-----------------------------------------------------------------------------
//! \addtogroup   OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				oal_serialdrv.h
//!
//! \brief				Header file defining the DBGU serial interface
//!
//-----------------------------------------------------------------------------

#ifndef __OAL_SERIALDRV_H__
#define __OAL_SERIALDRV_H__

// KITL Serial functions-------------------------------------------------------
BOOL SerialInit(KITL_SERIAL_INFO *pInfo);
VOID SerialDeinit();
UINT16 SerialRecv(UINT8 *pData, UINT16 size);
UINT16 SerialSend(UINT8 *pData, UINT16 size);
VOID SerialSendComplete(UINT16 size);
VOID SerialEnableInts();
VOID SerialDisableInts();

//KITL Serial Structure--------------------------------------------------------
#define OAL_SERIALDRV_DBGU   { \
	SerialInit,				   \
    SerialDeinit,			   \
    SerialSend,				   \
    SerialSendComplete,		   \
    SerialRecv,				   \
    SerialEnableInts,		   \
    SerialDisableInts,		   \
    NULL,					   \
    NULL					   \
};


#endif

//! @}