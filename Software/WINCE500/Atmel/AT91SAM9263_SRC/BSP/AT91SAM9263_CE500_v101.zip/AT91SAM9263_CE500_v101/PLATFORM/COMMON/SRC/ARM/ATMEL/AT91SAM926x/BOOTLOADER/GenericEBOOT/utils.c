//-----------------------------------------------------------------------------
//! \addtogroup	BOOTLOADER
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//-----------------------------------------------------------------------------
//! \file		utils.c 
//!
//! \brief		Eboot utils
//!
//! \if subversion
///   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/GenericEBOOT/utils.c $
//!   $Author: ltourlonias $
//!   $Revision: 985 $
//!   $Date: 2007-06-12 09:30:21 +0200 (mar., 12 juin 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	EBOOT
//! @{
//!


//------------------------------------------------------------------------------
//                                                                      Includes
//------------------------------------------------------------------------------
#include <windows.h>
#include <oal_memory.h>
#include <Nkintr.h>

#include "eboot_msg.h"

//------------------------------------------------------------------------------
//                                                            Imported functions
//------------------------------------------------------------------------------
extern void	EBOOT_WatchdogRefresh(void);

//----------------------------------------------------------------------------
// \fn    SpinForever
// \brief do nothing during infinite time ... this function never returned !
//----------------------------------------------------------------------------
void EBOOT_SpinForever(void)
{
	RETAILMSG(1,(EMSG_SPINFOREVER));
	for (;;);
}

//----------------------------------------------------------------------------
// \fn    NibbleHexToA
// \brief Transform uchar to char
//----------------------------------------------------------------------------
static char NibbleHexToA(UCHAR n)
{
	if (n<10)
	{
		return n + '0';
	}
	else
	{
		return n + ('A' - 10);
	}
}

//----------------------------------------------------------------------------
// \fn    NibbleAToHex
// \brief Transform char to uchar
//----------------------------------------------------------------------------
static UCHAR NibbleAToHex(CHAR c)
{
	UCHAR ucResult=0;
	if (!( (c<'0') || (c>'9') ))
	{
		ucResult = c - '0';
	}
	else if (!( (c<'A') || (c>'F') ))
	{
		ucResult = c - 'A' + 10;
	}
	else if (!( (c<'a') || (c>'f') ))
	{
		ucResult = c - 'a' + 10;
	}
	return ucResult;
}

//----------------------------------------------------------------------------
// \fn    macAddr_toa
// \brief Transfor mac address table in string
//----------------------------------------------------------------------------
UCHAR* macAddr_toa(UCHAR* pMacAddress)
{
	int i,j=0;
	static UCHAR pStrDest[18];
	for (i=0;i<6;i++)
	{
		pStrDest[j++] = NibbleHexToA(pMacAddress[i] >> 4);
		pStrDest[j++] = NibbleHexToA(pMacAddress[i] & 0xF);
		pStrDest[j++] = ':';
	}
	pStrDest[j-1] = 0;
	return pStrDest;
}

//----------------------------------------------------------------------------
// \fn    AsciiToMacAddr
// \brief Transfor an ascii mac address into a table � byte
//----------------------------------------------------------------------------
void AsciiToMacAddr(UCHAR* pMacAddress,UCHAR* pSrc)
{
	int i;
	for (i=0;i<6;i++)
	{
		pMacAddress[i] = NibbleAToHex(*(pSrc++)) << 4;
		pMacAddress[i] |= 0xF & NibbleAToHex(*(pSrc++));
		pSrc++;
	}
}


//-----------------------------------------------------------------------------
//! \fn			unsigned int AsciiToHex(char *s, unsigned int *val)
//!
//! \brief		ascii to hexa conversion
//!
//! \param		s	ascii value
//! \param		val	hexa value
//!
//! \return		\e 1 when all is good
//!	\return		\e 0 when all is bad
//-----------------------------------------------------------------------------
unsigned int AsciiToHex(char *s, unsigned int *val)
{
	int n;

	*val=0;
	
	if (s[0] == '0' && ((s[1] == 'x') || (s[1] == 'X')))
	{
		s+=2;
	}
	n = 0;	
	while ((n < 8) && (s[n] !=0))
	{
		*val <<= 4;
		if ( (s[n] >= '0') && (s[n] <='9'))
			*val += (s[n] - '0');
		else	
			if ((s[n] >= 'a') && (s[n] <='f'))
				*val += (s[n] - 0x57);
			else
				if ((s[n] >= 'A') && (s[n] <='F'))
					*val += (s[n] - 0x37);
			else
				return 0;
		n++;
	}
	return 1;				
}

//-----------------------------------------------------------------------------
//! \fn		     int EBOOT_ReadDebugByte(void)
//!
//! \brief		  This function retrieves a byte from the debug serial port and refresh the watchdog
//!
//!
//!
//! \return		 OEM_DEBUG_COM_ERROR indicates failure
//!	\return		 OEM_DEBUG_READ_NODATA indicates no data has been received
//! \return		 Other value is byte received
//-----------------------------------------------------------------------------
int EBOOT_ReadDebugByte(void)
{
	EBOOT_WatchdogRefresh();
	return OEMReadDebugByte();	
}

//------------------------------------------------------------------------------
//! End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/BOOTLOADER/GenericEBOOT/utils.c $
//------------------------------------------------------------------------------

//
//! @}
//
//
//! @}
