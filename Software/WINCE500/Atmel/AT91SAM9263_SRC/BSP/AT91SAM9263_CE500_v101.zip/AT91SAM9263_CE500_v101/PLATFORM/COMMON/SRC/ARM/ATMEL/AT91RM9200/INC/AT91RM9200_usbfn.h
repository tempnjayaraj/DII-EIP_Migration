//-----------------------------------------------------------------------------
//! \addtogroup	USBFN
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91RM9200_usbfn.h
//!
//! \brief		declaration for the USB device (Host controller class)
//! 
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/INC/AT91RM9200_usbfn.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------

#ifndef __AT91RM9200_USBFN_H__
#define  __AT91RM9200_USBFN_H__

#include "at91rm9200.h"
#include <csync.h>
#include <cmthread.h>
#include <CRegEdit.h>
#include <CRefCon.h>
#include <usbfn.h>
// For RAS entry management
#include <notify.h>
#include <ras.h>
#include <Unimodem.h>
#include <Netui.h>



#ifndef SHIP_BUILD
#define STR_MODULE _T("AT91RM9200_usbfn!")
#define SETFNAME() LPCTSTR pszFname = STR_MODULE _T(__FUNCTION__) _T(":")
#else
#define SETFNAME()
#endif

#define MAX_ENDPOINT_NUMBER 0x05
static const WORD g_EndpointMaxSize[MAX_ENDPOINT_NUMBER] = {8,64,64,64,64};


// Registry Value.
#define AT91RM_USBFUNCTION_PRIORITY_VALNAME    TEXT("Priority256")
#define AT91RM_USBFUNCTION_PRIORITY_VALTYPE    REG_DWORD


//
#define AT91RM_USBFUNCTION_DRIVER_VALNAME			TEXT("Drivers\\USB\\FunctionDrivers")
#define AT91RM_USBFUNCTION_DRIVER_VALTYPE			REG_SZ

#define AT91RM_USBFUNCTION_DRIVERCLIENT_VALNAME		TEXT("DefaultClientDriver")
#define AT91RM_USBFUNCTION_DRIVERCLIENT_VALTYPE		REG_SZ

#define AT91RM_USBFUNCTION_DRIVERNAME_VALNAME		TEXT("FriendlyName")
#define AT91RM_USBFUNCTION_DRIVERNAME_VALTYPE		REG_SZ

//
#define AT91RM_USBFUNCTION_DEFAULT_CONNECTION_NAME 			TEXT("USB Cable")
#define AT91RM_USBFUNCTION_DEFAULT_DIRECT_CONNECT_TIMEOUT_SECONDS		5

//
// used only for debug messages
#define AT91RM_USBFUNCTION_DRIVER_NAME		TEXT("USBFunction")



//
#define AT91RM_USBFUNCTION_DEFAULT_PRIORITY    100

class AT91RMEndpoint;

class CEndpointContainer : public CStaticContainer <AT91RMEndpoint, MAX_ENDPOINT_NUMBER>
{
};
class AT91RMUsbDevice :public CEndpointContainer, public CRegistryEdit, public CMiniThread {
public:
    AT91RMUsbDevice(LPCTSTR lpActivePath);
    virtual ~AT91RMUsbDevice();
    virtual DWORD Init(PVOID pvMddContext, PUFN_MDD_INTERFACE_INFO pMddInterfaceInfo, PUFN_PDD_INTERFACE_INFO pPddInterfaceInfo);
//  PDD interface.
    virtual BOOL DeleteAllEndpoint();
// Endpoint Function.
    virtual DWORD IsEndpointSupportable (DWORD dwEndpoint,UFN_BUS_SPEED Speed,PUSB_ENDPOINT_DESCRIPTOR pEndpointDesc,
            BYTE bConfigurationValue=1, BYTE bInterfaceNumber=0, BYTE bAlternateSetting=0 );
    virtual DWORD InitEndpoint(DWORD dwEndpoint,UFN_BUS_SPEED Speed,PUSB_ENDPOINT_DESCRIPTOR pEndpointDesc,
            BYTE bConfigurationValue=1, BYTE bInterfaceNumber=0, BYTE bAlternateSetting=0 );
    virtual DWORD DeinitEndpoint(DWORD dwEndpoint );
    virtual DWORD StallEndpoint(DWORD dwEndpoint );
    virtual DWORD ClearEndpointStall( DWORD dwEndpoint );
    virtual DWORD ResetEndpoint(DWORD dwEndpoint );
    virtual DWORD IsEndpointHalted( DWORD dwEndpoint, PBOOL pfHalted );
    virtual DWORD IssueTransfer(DWORD  dwEndpoint,PSTransfer pTransfer );
    virtual DWORD AbortTransfer(DWORD dwEndpoint, PSTransfer pTransfer);
    
//  Endpoint Ctrl Special
    virtual DWORD SendControlStatusHandshake(DWORD dwEndpoint);
//  Device Function.
    virtual DWORD Start();
    virtual DWORD Stop();
    virtual BOOL IsCableAttached() { return TRUE; };
    virtual DWORD  SetAddress( BYTE  bAddress );
    virtual void PowerDown();
    virtual void PowerUp() ;
    virtual void  SetPowerState( CEDEVICE_POWER_STATE cpsNew ) ;
    virtual DWORD IOControl( IOCTL_SOURCE source, DWORD dwCode, PBYTE  pbInBuf, DWORD cbInBuf, PBYTE pbOutBuf, DWORD cbOutBuf,PDWORD  pcbActualOutBuf );

	
// For Ras enumeration and configuration
	static DWORD RasInitThread(LPVOID pThreadParam);
	DWORD RasInit();
	DWORD FindTSPDevice(HLINEAPP hLineApp, DWORD dwNumLines, DWORD dwAPIVersion, DWORD dwExtVersion, LPWSTR lpszTSPName, LPWSTR lpszTSPLineName);
	void WaitForReply (HLINEAPP hLineApp);
	LONG ModifyDevConfig (HLINEAPP hLineApp, HLINE hLine, PUNIMDM_CHG_DEVCFG pUCD);
	LPVARSTRING GetDevConfig (DWORD dwDeviceID, LPWSTR pszDeviceClassName);
	DWORD SetUsbFunctionAsDefaultConn (LPTSTR lpStrFriendlyName);
	void ModifyDefaultRasEntry (LPTSTR lpStrFriendlyName, RASENTRY *RasEntry);
	BOOL ModifyRetryTimeout(LPTSTR lpStrFriendlyName, LPVARSTRING  *pDevCfg);
	void CreateRegDefaultConnection();

    // Interrupt
    BOOL    EnableEndpointInterrupt(DWORD dwEndpointIndex,BOOL bEnable);


    // 
    void MddTransferComplete(PSTransfer pTransfer) 
	{
        SETFNAME();
        if (m_pvMddContext) 
		{
            DEBUGMSG(ZONE_FUNCTION, (_T("%s MddTransferComplete pTransfer:0x%x"),pszFname,pTransfer));
            m_pfnNotify(m_pvMddContext, UFN_MSG_TRANSFER_COMPLETE, (DWORD) pTransfer);
        }
        else 
            DebugBreak();
    }


    BOOL DeviceNotification( DWORD dwMsg, DWORD dwParam ) 
	{
        SETFNAME();
       if (m_pvMddContext) 
	   {
            DEBUGMSG(ZONE_FUNCTION, (_T("%s DeviceNotification dwMsg:0x%x,dwParam:0x%x"),pszFname,dwMsg,dwParam));
            return m_pfnNotify(m_pvMddContext, dwMsg, dwParam);
        }
        else {
            DebugBreak();
            return FALSE;
        }
    }

	DWORD USBDetectionThread();

	AT91PS_UDP m_pUDP;
	
protected: 
	virtual BOOL InitializeUSBDetectionInterrupt() = 0;
	virtual void DeinitializeUSBDetectionInterrupt() = 0;
    virtual void PowerMgr(BOOL bOff);
    
	BOOL    m_fIsCableAttached;

    // IST
    DWORD       m_dwPriority;


    // Peripheral
    DWORD       m_dwPeriphSysIntr;
    HANDLE      m_hPeriphEvent;


    PVOID       m_pvMddContext;

    // Protected Fucntion
    BOOL        HardwareInit();
    BOOL        ReInit(); // For Cable Detach & Attach , We have to re-init the Device Controller.

    PFN_UFN_MDD_NOTIFY      m_pfnNotify;
    CEDEVICE_POWER_STATE    m_CurPowerState;
    HANDLE                  m_hParent;
	HANDLE m_hDetectionEvent;
	DWORD m_dwDetectionSysintr;



private:
	HANDLE m_USBDetectionThread;
	BOOL m_bTerminateDetectionThread;
    DWORD ThreadRun();
	AT91PS_PMC m_pPMC;
};


AT91RMUsbDevice * CreateAT91RMUsbDevice(LPCTSTR lpActivePath);

#endif
//! @}