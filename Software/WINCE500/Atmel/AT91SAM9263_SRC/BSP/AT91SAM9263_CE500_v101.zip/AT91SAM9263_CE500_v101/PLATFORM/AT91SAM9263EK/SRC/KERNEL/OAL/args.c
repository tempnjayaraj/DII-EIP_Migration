//-----------------------------------------------------------------------------
//! \addtogroup	OAL
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		args.c
//!
//! \brief		OALArgsQuery implementation
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/KERNEL/OAL/args.c $
//!   $Author: jjhiblot $
//!   $Revision: 106 $
//!   $Date: 2006-02-15 14:26:49 +0100 (mer., 15 févr. 2006) $
//! \endif
//-----------------------------------------------------------------------------

//! \addtogroup	ARGS
//! @{

#include <windows.h>
#include <oal.h>
#include "at91sam926x.h"
#include "at91sam9263EK.h"
#include "args.h"
#include "drv_glob.h"

//-----------------------------------------------------------------------------
//! \fn			  VOID* OALArgsQuery(UINT32 type)
//!
//! \brief		This function is called from other OAL modules to return boot arguments.
//!
//! \note     Boot arguments are typically placed in fixed memory location and they are
//!       filled by boot loader. In case that boot arguments can't be located
//!       the function should return NULL. The OAL module then must use default value.
//!
//! \param		type Boot argument type.
//!	\return		This function returns NULL when the specified arguments cannot be found
//-----------------------------------------------------------------------------
VOID* OALArgsQuery(UINT32 type)
{
    VOID *pData = NULL;
	PDRIVER_GLOBALS pDrvGlobalArea = (PDRIVER_GLOBALS) OALPAtoVA((DWORD)DRIVER_GLOBALS_PHYSICAL_MEMORY_START,TRUE);
	BSP_ARGS *pArgs = &(pDrvGlobalArea->BSPArgs);

	static GUID deviceUuid = {0};

    OALMSG(OAL_ARGS&&OAL_FUNC, (L"+OALArgsQuery(%d)\r\n", type));

	// Our UUID generation here is for test purposes only, it needs to be redrawn
	// with a real hardware specific ID.
	if (!deviceUuid.Data1)
	{
		AT91PS_DBGU pDbguReg = (AT91PS_DBGU) OALPAtoVA((DWORD) AT91C_BASE_DBGU, FALSE);
		unsigned int uRegVal = pDbguReg->DBGU_CIDR;

		// 8 first bytes of the sha1 signature of ADENEOUUIDTEST
		deviceUuid.Data1 = 0xed13f206;
		deviceUuid.Data2 = 0x3055;
		deviceUuid.Data3 = 0x16ea;

		deviceUuid.Data4[0] = (uRegVal >> 20) & 0xff; // ARCH
		deviceUuid.Data4[1] = uRegVal & 0xff; // EPROC & VERSION

		if (uRegVal & (0x1 << 31))
		{
			deviceUuid.Data4[2] = ((uRegVal >> 16) & 0x0f) | ((uRegVal >> 24) & 0xf0); // EXT & NVPTYP & SRAMSIZ
			deviceUuid.Data4[3] = (uRegVal >> 8) & 0xff; // NVPSIZ2 & NVPSIZ

			// unique part.
			uRegVal = pDbguReg->DBGU_EXID;
			deviceUuid.Data4[4] = (uRegVal >> 24) & 0xff;
			deviceUuid.Data4[5] = (uRegVal >> 16) & 0xff;
			deviceUuid.Data4[6] = (uRegVal >> 8) & 0xff;
			deviceUuid.Data4[7] = uRegVal & 0xff;
		}
		else
		{
			// if Chip's ID extension register does not exists, hack the UUID from the
			// boot loader's MAC address. Note that this is not really universally unique
			// (really not if you use kitl in serial mode) but we return it for test
			// purpose.
			deviceUuid.Data4[2] = (pArgs->kitl.mac[0] >> 8) & 0Xff;
			deviceUuid.Data4[3] = pArgs->kitl.mac[0] & 0Xff;
			deviceUuid.Data4[4] = (pArgs->kitl.mac[1] >> 8) & 0xff;
			deviceUuid.Data4[5] = pArgs->kitl.mac[1] & 0Xff;
			deviceUuid.Data4[6] = (pArgs->kitl.mac[2] >> 8) & 0Xff;
			deviceUuid.Data4[7] = pArgs->kitl.mac[2] & 0Xff;
		}
	}

    // Check if there is expected signature
    if (
        pArgs->header.signature  != OAL_ARGS_SIGNATURE ||
        pArgs->header.oalVersion != OAL_ARGS_VERSION   ||
        pArgs->header.bspVersion != BSP_ARGS_VERSION
    ) goto cleanUp;

    // Depending on required args
    switch (type) {

    case OAL_ARGS_QUERY_DEVID:
        pData = &pArgs->deviceId;
        break;

	case OAL_ARGS_QUERY_UUID:
		pData = &deviceUuid;
		break;

    case OAL_ARGS_QUERY_KITL:
       
        pArgs->kitl.flags |= (OAL_KITL_FLAGS_ENABLED | OAL_KITL_FLAGS_VMINI);

        // Has the bootloader provided a non-zero IP address and subnet mask?
        // If not, use DHCP to obtain this information.
        //
        if ((pArgs->kitl.ipAddress == 0) || (pArgs->kitl.ipMask == 0))
        {
            pArgs->kitl.flags |= OAL_KITL_FLAGS_DHCP;
        }

        // Has the bootloader provided information about which NIC it was using?
        // If not, choose the MACB as the default (if KITL is over Ethernet, otherwise it uses the serial kitl).
        //
        if (pArgs->kitl.devLoc.LogicalLoc == 0)
        {
            pArgs->kitl.devLoc.IfcType     = Internal;
            pArgs->kitl.devLoc.BusNumber   = 0;
#ifdef KITL_ON_SERIAL
			pArgs->kitl.devLoc.PhysicalLoc = (PVOID)(AT91C_BASE_DBGU);
#else 
            pArgs->kitl.devLoc.PhysicalLoc = (PVOID)(AT91C_BASE_MACB);
#endif       
            pArgs->kitl.devLoc.LogicalLoc  = (DWORD)pArgs->kitl.devLoc.PhysicalLoc;
        }

        pData = &pArgs->kitl;
        
        break;    
    }

cleanUp:
    OALMSG(OAL_ARGS&&OAL_FUNC, (L"-OALArgsQuery(pData = 0x%08x)\r\n", pData));
    return pData;
}

//! @} end of subgroup ARGS

//! @} end of group OAL

//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/AT91SAM9263EK/SRC/KERNEL/OAL/args.c $
//-----------------------------------------------------------------------------
//