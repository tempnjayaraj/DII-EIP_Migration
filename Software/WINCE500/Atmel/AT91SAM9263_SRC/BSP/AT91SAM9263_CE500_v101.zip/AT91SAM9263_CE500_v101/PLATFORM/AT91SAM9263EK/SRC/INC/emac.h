//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//
//! \addtogroup	EMAC
//! @{
//
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		emac.h
//!
//! \brief		Header file for the Emac (Ethernt MAC) controller
//!
//! \if subversion
//!   $URL: http://centaure/svn/thales_navigation-bsp_nadia2ek/TRUNK/WINCE500/PLATFORM/nadia2EK/SRC/INC/emac.h $
//!   $Author: jjhiblot $
//!   $Revision: 28 $
//!   $Date: 2005-12-23 16:31:51 +0100 (ven., 23 déc. 2005) $
//! \endif
//-----------------------------------------------------------------------------


#include <windows.h>
#include <oal.h>
#include "at91sam9263.h"
#include "AT91SAM926x_interface.h"
#include "lib_AT91SAM926x.h"

#define NB_RX_BUFFERS			80			/// Number of receive buffers
#define ETH_RX_BUFFER_SIZE		128         /// cannot be changed (hardcoded in the controller)

#define NB_TX_BUFFERS			40			/// Number of Transmit buffers
#define ETH_TX_BUFFER_SIZE		0x640       /// Size of a transmit buffer (note that because we want to keep the code simple, it's bigger than the max Ethernt MTU and thus a frame will always be stored in a single buffer)

#define AT91C_OWNERSHIP_BIT		0x00000001

//* Receive Transfer descriptor structure
typedef struct _AT91S_RxTdDescriptor {
	unsigned int addr;
	union
	{
		unsigned int status;
		struct {
			unsigned int Length:11;
			unsigned int Res0:1;
			unsigned int Rxbuf_off:2;
			unsigned int StartOfFrame:1;
			unsigned int EndOfFrame:1;
			unsigned int Cfi:1;
			unsigned int VlanPriority:3;
			unsigned int PriorityTag:1;
			unsigned int VlanTag:1;
			unsigned int TypeID:1;
			unsigned int Sa4Match:1;
			unsigned int Sa3Match:1;
			unsigned int Sa2Match:1;
			unsigned int Sa1Match:1;
			unsigned int Res1:1;
			unsigned int ExternalAdd:1;
			unsigned int UniCast:1;
			unsigned int MultiCast:1;
			unsigned int BroadCast:1;
		}S_Status;		
	}U_Status;
}AT91S_RxTdDescriptor, *AT91PS_RxTdDescriptor;


//* Transmit Transfer descriptor structure
typedef struct _AT91S_TxTdDescriptor {
	unsigned int addr;
	union
	{
		unsigned int status;
		struct {
			unsigned int Length:11;
			unsigned int Res0:4;
			unsigned int LastBuff:1;
			unsigned int NoCrc:1;
			unsigned int Res1:10;
			unsigned int BufExhausted:1;
			unsigned int TransmitUnderrun:1;
			unsigned int TransmitError:1;
			unsigned int Wrap:1;
			unsigned int BuffUsed:1;
		}S_Status;		
	}U_Status;
}AT91S_TxTdDescriptor, *AT91PS_TxTdDescriptor;


/* Receive status defintion */
#define AT91C_BROADCAST_ADDR	((unsigned int) (1 << 31))	//* Broadcat address detected
#define AT91C_MULTICAST_HASH 	((unsigned int) (1 << 30))	//* MultiCast hash match
#define AT91C_UNICAST_HASH 	    ((unsigned int) (1 << 29))	//* UniCast hash match
#define AT91C_EXTERNAL_ADDR	    ((unsigned int) (1 << 28))	//* External Address match
#define AT91C_SA1_ADDR	    	((unsigned int) (1 << 26))	//* Specific address 1 match
#define AT91C_SA2_ADDR	    	((unsigned int) (1 << 25))	//* Specific address 2 match
#define AT91C_SA3_ADDR	    	((unsigned int) (1 << 24))	//* Specific address 3 match
#define AT91C_SA4_ADDR	    	((unsigned int) (1 << 23))	//* Specific address 4 match
#define AT91C_TYPE_ID	    	((unsigned int) (1 << 22))	//* Type ID match
#define AT91C_VLAN_TAG	    	((unsigned int) (1 << 21))	//* VLAN tag detected
#define AT91C_PRIORITY_TAG    	((unsigned int) (1 << 20))	//* PRIORITY tag detected
#define AT91C_VLAN_PRIORITY    	((unsigned int) (7 << 17))  //* PRIORITY Mask
#define AT91C_CFI_IND        	((unsigned int) (1 << 16))  //* CFI indicator
#define AT91C_EOF           	((unsigned int) (1 << 15))  //* EOF
#define AT91C_SOF           	((unsigned int) (1 << 14))  //* SOF
#define AT91C_RBF_OFFSET     	((unsigned int) (3 << 12))  //* Receive Buffer Offset Mask
#define AT91C_LENGTH_FRAME     	((unsigned int) 0x07FF)     //* Length of frame

/* Transmit Status definition */
#define AT91C_TRANSMIT_OK		((unsigned int) (1 << 31))	//* 
#define AT91C_TRANSMIT_WRAP		((unsigned int) (1 << 30))	//* Wrap bit: mark the last descriptor
#define AT91C_TRANSMIT_ERR		((unsigned int) (1 << 29))	//* RLE:transmit error
#define AT91C_TRANSMIT_UND		((unsigned int) (1 << 28))	//* Transmit Underrun
#define AT91C_BUF_EX     		((unsigned int) (1 << 27))	//* Buffers exhausted in mid frame
#define AT91C_TRANSMIT_NO_CRC	((unsigned int) (1 << 16))	//* No CRC will be appended to the current frame
#define AT91C_LAST_BUFFER    	((unsigned int) (1 << 15))	//*


//------------------------------------------------------------------------------
// Prototypes for EMAC NIC functions

BOOL   EMACInit(UINT8 *pAddress, UINT32 offset, UINT16 mac[3]);
UINT16 EMACSendFrame(UINT8 *pBuffer, UINT32 length);
UINT16 EMACGetFrame(UINT8 *pBuffer, UINT16 *pLength);
VOID   EMACEnableInts();
VOID   EMACDisableInts();
VOID   EMACCurrentPacketFilter(UINT32 filter);
BOOL   EMACMulticastList(UINT8 *pAddresses, UINT32 count);



//! @}
//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/thales_navigation-bsp_nadia2ek/TRUNK/WINCE500/PLATFORM/nadia2EK/SRC/INC/emac.h $
//-----------------------------------------------------------------------------
//