//-----------------------------------------------------------------------------
//! \addtogroup	MISC
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//! \file		CRC32.c
//!
//! \brief		CRC32 library
//!
//-----------------------------------------------------------------------------
// Make a Doxygen group
//! \addtogroup CRC32
//! @{

#include "crc32.h"

//-----------------------------------------------------------------------------
//! \fn			unsigned long ComputeCRC32(unsigned char *buffer, int len)
//!
//! \brief		This function compute a crc 32 from a pointer for a certain length
//!
//! \param		buffer Pointer on memory you want compute a crc
//! \param  		len Length of zone which you want compute a crc
//!
//! \return  		The CRC32 wanted
//-----------------------------------------------------------------------------
unsigned long ComputeCRC32(unsigned char *buffer, int len)
{
  unsigned long crc;  
  unsigned long temp;
  int j;
 
  crc = 0xFFFFFFFF;
 
  while (len--) 
  {
    temp = (unsigned long)((crc & 0xFF) ^ *buffer++);
    for (j = 0; j < 8; j++) 
    {
      if (temp & 0x1)
        temp = (temp >> 1) ^ 0xEDB88320;
      else
        temp >>= 1;
    }
    crc = (crc >> 8) ^ temp;
  }
  return crc ^ 0xFFFFFFFF;
}

// End of Doxygen group crc32
//! @}
//! @}
//-----------------------------------------------------------------------------
// End of $URL: http://centaure/svn/interne-ce_bsp_atmel/TRUNK50/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/MISC/crc32/crc32.c $
//-----------------------------------------------------------------------------
