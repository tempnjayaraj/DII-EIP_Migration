//-----------------------------------------------------------------------------
//! \addtogroup   WatchDog Driver
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file				AT91RM9200_WatchDog_ioctl.h
//!
//! \brief				IoCtl for WatchDog driver
//!
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91RM9200/INC/IOCTL/AT91RM9200_WatchDog_ioctl.h $
//!   $Author: vbelloir $
//!   $Revision: 176 $
//!   $Date: 2007-02-13 01:34:20 -0800 (Tue, 13 Feb 2007) $
//! \endif
//! 
//-----------------------------------------------------------------------------
#ifndef __AT91RM9200_WATCHDOG_IOCTL_H__
#define __AT91RM9200_WATCHDOG_IOCTL_H__

//-----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------
typedef struct
{
    DWORD    dwTimeOutMs; // timeout in Ms (from 0 to 256000 ms)
} BUFIN_IOCTL_INIT;


//-----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------
#define WATCHDOG_INIT       2048
#define WATCHDOG_REFRESH    2049
#define WATCHDOG_STOP       2050


//-----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------
#define IOCTL_WATCHDOG_INIT             CTL_CODE(FILE_DEVICE_UNKNOWN, WATCHDOG_INIT, METHOD_BUFFERED, FILE_WRITE_ACCESS)
#define IOCTL_WATCHDOG_REFRESH          CTL_CODE(FILE_DEVICE_UNKNOWN, WATCHDOG_REFRESH, METHOD_BUFFERED, FILE_WRITE_ACCESS)
#define IOCTL_WATCHDOG_STOP             CTL_CODE(FILE_DEVICE_UNKNOWN, WATCHDOG_STOP, METHOD_BUFFERED, FILE_READ_ACCESS)


#endif // __AT91RM9200_WATCHDOG_IOCTL_H__

//! @}
