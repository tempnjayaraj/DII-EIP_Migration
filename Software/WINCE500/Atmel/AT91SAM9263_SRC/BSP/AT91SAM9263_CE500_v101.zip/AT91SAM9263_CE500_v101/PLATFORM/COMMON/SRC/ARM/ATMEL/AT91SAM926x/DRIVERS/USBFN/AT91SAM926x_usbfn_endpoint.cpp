//-----------------------------------------------------------------------------
//! \addtogroup DRIVERS
//! @{
//!
//  All rights reserved ADENEO SAS 2005
//!
//-----------------------------------------------------------------------------
//! \file		AT91SAM926x_usbfn_endpoint.cpp
//!
//! \brief		Implementation of a generic endpoint
//!
//! 
//! 
//! \if subversion
//!   $URL: http://centaure/svn/interne-ce_bsp_atmel/TAGS/TAGS50/SAM9263EK_v101/PLATFORM/COMMON/SRC/ARM/ATMEL/AT91SAM926x/DRIVERS/USBFN/AT91SAM926x_usbfn_endpoint.cpp $
//!   $Author: pblanchard $
//!   $Revision: 984 $
//!   $Date: 2007-06-11 09:19:22 -0700 (Mon, 11 Jun 2007) $
//! \endif
//-----------------------------------------------------------------------------
//! \addtogroup	USBFN
//! @{
//!
#include <windows.h>
#include <ceddk.h>
#include <ddkreg.h>
#include "AT91SAM926x_usbfn.h"
#include "AT91SAM926x.h"
#include "AT91SAM926x_oal_intr.h"


#include "AT91SAM926x_USBFN_EndPoint.h"


//-----------------------------------------------------------------------------
//! \brief		This function initializes a endpoint.
//!
//! \param		pEndpointDesc			Endpoint descriptor
//! \param		bConfigurationValue		Configuration value
//! \param		bInterfaceNumber		Interface number
//! \param		bAlternateSetting		Alternate setting
//!
//! \return		Does the init succeed ?
//!
//-----------------------------------------------------------------------------
BOOL AT91SAMEndpoint::Init(PUSB_ENDPOINT_DESCRIPTOR pEndpointDesc,
            BYTE bConfigurationValue, BYTE bInterfaceNumber, BYTE bAlternateSetting)
{
    SETFNAME();
    FUNCTION_ENTER_MSG();
    BOOL bReturn = TRUE;
    Lock();
    m_fStalled = FALSE;
    // Change address according
    if ( pEndpointDesc && m_pUsbDevice!=NULL && m_dwEndpointIndex < MAX_ENDPOINT_NUMBER) 
    {
		m_epDesc = *pEndpointDesc;
		if ((m_epDesc.wMaxPacketSize & 0x3ff) >= g_EndpointMaxSize[m_dwEndpointIndex]) 
		{
            pEndpointDesc->wMaxPacketSize = m_epDesc.wMaxPacketSize = g_EndpointMaxSize[m_dwEndpointIndex];              
        }

		ResetEndpoint();
		// Enable EndPoint
		m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] |= AT91C_UDP_EPEDS;
        pEndpointDesc->bEndpointAddress = (UCHAR)((pEndpointDesc->bEndpointAddress & 0x80) | m_dwEndpointIndex);
    }
    Unlock();
    FUNCTION_LEAVE_MSG();
    return bReturn;
}

BOOL AT91SAMEndpoint::ReInitEndpoint()
{
	return Init(&m_epDesc,0,0,0);
}

//-----------------------------------------------------------------------------
//! \brief		This function forces a stall on the endpoint.
//!
//! \return		Always returns ERROR_SUCCESS
//!
//! Forces a stall and clears the previous one so we can know when this one is done.
//-----------------------------------------------------------------------------
DWORD AT91SAMEndpoint::StallEndpoint()
{

    SETFNAME();
    FUNCTION_ENTER_MSG();
    Lock();
    
    m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] &= ~AT91C_UDP_ISOERROR; // Clear Previous Stall Sent if there is any.	
    m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] |= AT91C_UDP_FORCESTALL; // Force Stall.

    m_fStalled = TRUE;
    Unlock();
    FUNCTION_LEAVE_MSG();
    return ERROR_SUCCESS;
}

//-----------------------------------------------------------------------------
//! \brief		This function clears the stall.
//!
//! \return		Always returns ERROR_SUCCESS
//!
//! Sets the global variable indicating a stall to FALSE
//-----------------------------------------------------------------------------
DWORD AT91SAMEndpoint::ClearEndpointStall()
{
    Lock();
	m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] &= ~AT91C_UDP_FORCESTALL; // Clear Previous Stall Sent if there is any.	
    m_fStalled = FALSE;
    Unlock();
    return ERROR_SUCCESS;
}

//-----------------------------------------------------------------------------
//! \brief		This function resets a endpoint.
//!
//! \return		Always returns ERROR_SUCCESS
//!
//! Resets the endpoint by clearing the transfer bits and flushing the FIFO
//-----------------------------------------------------------------------------
DWORD AT91SAMEndpoint::ResetEndpoint()
{
    SETFNAME();
    FUNCTION_ENTER_MSG();
    DEBUGMSG(ZONE_WARNING, (_T("ResetEndpoint+ (%d), UDCCSR =0x%x"),m_dwEndpointIndex, m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex]));
    
	Lock();

    m_pUsbDevice->m_pUDP->UDP_RSTEP |= ((unsigned int) 0x1 <<  m_dwEndpointIndex);
	Sleep(10);
	m_pUsbDevice->m_pUDP->UDP_RSTEP &= ~((unsigned int) 0x1 <<  m_dwEndpointIndex);

	m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] = 0x0;
    Unlock();
    DEBUGMSG(ZONE_WARNING, (_T("ResetEndpoint- (%d)"),m_dwEndpointIndex));
    FUNCTION_LEAVE_MSG();
    return ERROR_SUCCESS;
}

//-----------------------------------------------------------------------------
//! \brief		This function checks if the endpoint is halted.
//!
//! \param		pfHalted		Stores the status of the endpoint
//!
//! \return		Always returns ERROR_SUCCESS
//!
//! This function checks if the endpoint is halted by looking the stall global variable
//-----------------------------------------------------------------------------
DWORD AT91SAMEndpoint::IsEndpointHalted(PBOOL pfHalted)
{
    Lock();
    if (pfHalted)
        *pfHalted = m_fStalled;
    Unlock();
    return ERROR_SUCCESS;
}

//-----------------------------------------------------------------------------
//! \brief		This function completes the transfer.
//!
//! \param		dwError		
//!
//! \return		No return
//!
//! This function calls the MDD and completes the transfer
//-----------------------------------------------------------------------------
void AT91SAMEndpoint::CompleteTransfer(DWORD dwError)
{
    if (m_pCurTransfer) 
    {
        PSTransfer  pCurTransfer = m_pCurTransfer;
        m_pCurTransfer->dwUsbError= dwError;
        m_pCurTransfer = NULL;
        m_pUsbDevice->MddTransferComplete(pCurTransfer);
    }    
}

//-----------------------------------------------------------------------------
//! \brief		This function issues a transfer on zero endpoint.
//!
//! \param		pTransfer		Transfer to be done
//!
//! \return		ERROR_INVALID_DATA	The data isn't mean to be sent
//! \return		ERROR_SUCCESS		Success
//!
//! This function enables the interrupt
//-----------------------------------------------------------------------------
DWORD AT91SAMEndpoint::IssueTransfer(PSTransfer pTransfer)
{   
    Lock();
    SETFNAME();
    FUNCTION_ENTER_MSG();
    DWORD dwReturn = ERROR_SUCCESS;
    if (pTransfer!=NULL && pTransfer->pvBuffer != NULL && pTransfer->dwFlags == USB_IN_TRANSFER)
	{
		if (m_pCurTransfer == NULL) 
		{
			 // If it is valid.                
			m_pCurTransfer = pTransfer;
			m_pCurTransfer->pvPddTransferInfo = 0;
			m_pCurTransfer->cbTransferred = 0;
			m_pCurTransfer->pvPddData = (PVOID) m_dwEndpointIndex;
         
			DWORD dwTotalData = m_pCurTransfer->cbBuffer - m_pCurTransfer->cbTransferred ;
			
			if (dwTotalData < m_epDesc.wMaxPacketSize)
			{
				// the total amount of data is less than the max fifo size => only one trnasfer is needed so we set the END_OF_TRANSFER bit
				m_pCurTransfer->pvPddTransferInfo = (PVOID) AT91SAM926X_END_OF_TRANSFER;
			}
			else
			{
				dwTotalData = m_epDesc.wMaxPacketSize;
			}

			DWORD dwXmitedData = XmitData((PBYTE)m_pCurTransfer->pvBuffer, dwTotalData );
			//ASSERT(dwXmitedData == dwTotalData);      	
			
			if (dwXmitedData == dwTotalData)
			{
				m_pCurTransfer->cbTransferred = dwTotalData;
			}
			else
			{
				m_pCurTransfer->cbTransferred = 0;
				dwReturn = ERROR_NOT_READY;
			}
			m_pUsbDevice->EnableEndpointInterrupt(m_dwEndpointIndex,TRUE);			
		}
		else
		{
			dwReturn = ERROR_NOT_READY;
		}
	}
 	else if (pTransfer!=NULL && pTransfer->pvBuffer != NULL && pTransfer->dwFlags == USB_OUT_TRANSFER)
	{
		if (m_pCurTransfer == NULL) 
		{
			 // If it is valid.                
			m_pCurTransfer = pTransfer;
			m_pCurTransfer->pvPddTransferInfo = 0;
			m_pCurTransfer->cbTransferred = 0;
			m_pCurTransfer->pvPddData = (PVOID) m_dwEndpointIndex;
         			
			m_pUsbDevice->EnableEndpointInterrupt(m_dwEndpointIndex,TRUE);			
			IST(0);
		}
		else
		{
			dwReturn = ERROR_NOT_READY;
		}
	}
   else 
    {
        dwReturn = ERROR_INVALID_DATA;
    }
    FUNCTION_LEAVE_MSG();
    Unlock();
    return dwReturn;
}

//-----------------------------------------------------------------------------
//! \brief		This function abort a transfer.
//!
//! \param		pTransfer		Transfer to be aborted
//!
//! \return		ERROR_INVALID_DATA	This is not the current transfer
//! \return		ERROR_SUCCESS		Success
//!
//! This function calls ResetEndpoint and CompleteTransfer
//-----------------------------------------------------------------------------
DWORD AT91SAMEndpoint::AbortTransfer(PSTransfer pTransfer)
{
    DWORD dwReturn = ERROR_SUCCESS;
    SETFNAME();
    FUNCTION_ENTER_MSG();
    Lock();
    if (pTransfer == m_pCurTransfer && m_pCurTransfer != NULL) 
    {        
        CompleteTransfer(UFN_CANCELED_ERROR);
    }
    else
        dwReturn = ERROR_INVALID_DATA;
    Unlock();
    FUNCTION_LEAVE_MSG();
    return dwReturn;
}

//-----------------------------------------------------------------------------
//! \brief		This function loads the FIFO for the next transfer.
//!
//! \param		pBuffer		Data to load
//! \param		dwLength	Number of bytes
//!
//! \return		dwLength
//!
//! This function loads the FIFO for the next transfer.
//-----------------------------------------------------------------------------
DWORD AT91SAMEndpoint::XmitData(PBYTE pBuffer, DWORD dwLength)
{
	DWORD dwTimeout = 1500;
	DWORD dwDate;
	SETFNAME();
    DEBUGMSG(ZONE_FUNCTION, (_T("%s pBuffer=0x%x, dwLength= 0x%x\r\n"), pszFname, pBuffer, dwLength));
    
	if (m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] & AT91C_UDP_TXCOMP)
	{
		m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] &= ~AT91C_UDP_TXCOMP;
	}

	dwDate = GetTickCount();
	do
	{
		if ((m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] & AT91C_UDP_TXPKTRDY) == 0)
		{
			dwTimeout = 0;
			break;
		}
	} while (GetTickCount()-dwDate<dwTimeout);
	
	if (dwTimeout)
	{		
		DEBUGMSG(ZONE_TRANSFER | ZONE_WARNING, (_T("%s Timeout !!!!!\r\n"), pszFname));
		return 0xFFFFFFFE;
	}
	
	// Spec 12.4.2

    if (dwLength > m_epDesc.wMaxPacketSize)
	{
        dwLength = m_epDesc.wMaxPacketSize;
		DEBUGMSG(ZONE_TRANSFER, (_T("%s bAutoSend\n"), pszFname));		
    }



	if (dwLength == 0)
	{
        DEBUGMSG(ZONE_TRANSFER, (_T("%s Sending Zero length packet on endpoint %d\n"), pszFname,m_dwEndpointIndex));
    }
	else
	{
		if (pBuffer == NULL)
		{
			DEBUGMSG(ZONE_TRANSFER, (_T("%s Invalid buffer\n"), pszFname));
			return 0xFFFFFFFF;
		}
	}

#ifdef DEBUG
	TCHAR strDump[2048] = L"\0";
#endif

	for (DWORD dwIndex = 0; dwIndex< dwLength; dwIndex++) 
    { 
#ifdef DEBUG
		swprintf(strDump, (TEXT("%s 0x%02X")), strDump, *pBuffer);
#endif
        m_pUsbDevice->m_pUDP->UDP_FDR[m_dwEndpointIndex] = *(pBuffer++);

    };

	
	m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] |= AT91C_UDP_TXPKTRDY;
	
	

	DEBUGMSG(ZONE_TRANSFER, (_T("%s Written Datas on endpoint %d : %s \n"), pszFname, m_dwEndpointIndex,L""));//strDump));

	DEBUGMSG(ZONE_FUNCTION, (_T("%s Complete dwLength = 0x%x\r\n"), pszFname, dwLength));
    return dwLength;
}

//-----------------------------------------------------------------------------
//! \brief		This function reads the data from the FIFO.
//!
//! \param		pBuffer		Buffer to store data
//! \param		dwLength	Number of bytes to be read
//!
//! \return		dwTotalRead	Number of bytes read
//!
//! This function reads the data from the FIFO and decreases the number of bytes left in the FIFO.
//-----------------------------------------------------------------------------
DWORD AT91SAMEndpoint::ReceiveData(PBYTE pBuffer, DWORD dwLength)
{
    SETFNAME();
    DEBUGMSG(ZONE_FUNCTION, (_T("%s pBuffer=0x%x, dwLegnth= 0x%x\r\n"), pszFname, pBuffer, dwLength));
    PREFAST_ASSERT(pBuffer!=NULL);
    // Spec 12.4.2
    BYTE  bData;
    DWORD dwAvailableDataSize = (((m_pUsbDevice->m_pUDP->UDP_CSR[m_dwEndpointIndex] & AT91C_UDP_RXBYTECNT)) >> 16);
    DWORD dwDataRead;
    DWORD dwTotalRead = 0;
    while (dwAvailableDataSize) 
    {
        bData = m_pUsbDevice->m_pUDP->UDP_FDR[m_dwEndpointIndex];
        if (dwAvailableDataSize >= sizeof(BYTE)) 
        {
            dwAvailableDataSize -= sizeof(BYTE);
            dwDataRead = sizeof(BYTE);
        }
        else 
        {
            dwDataRead = dwAvailableDataSize;
            dwAvailableDataSize = 0;
        }
        *(pBuffer++) = bData;
        dwTotalRead ++;

        dwLength --;
    }
    DEBUGMSG(ZONE_FUNCTION, (_T("%s Complete dwTotalRead = 0x%x\r\n"), pszFname, dwTotalRead));
    return dwTotalRead;
}

//-----------------------------------------------------------------------------
//! \brief		This function sends a fake feature.
//!
//! \param		bRequest			Request
//! \param		wFeatureSelector	Value of this request
//!
//! This function sends a fake notification to the Device notification function.
//-----------------------------------------------------------------------------
void AT91SAMEndpoint::SendFakeFeature(BYTE bRequest, WORD wFeatureSelector)
{
    USB_DEVICE_REQUEST udr;
    PREFAST_DEBUGCHK(m_pUsbDevice!=NULL);
    udr.bmRequestType = USB_REQUEST_FOR_ENDPOINT;
    udr.bRequest = bRequest;
    udr.wValue = wFeatureSelector ;
    udr.wIndex = m_epDesc.bEndpointAddress ;
    udr.wLength = 0;
    m_pUsbDevice->DeviceNotification(UFN_MSG_SETUP_PACKET, (DWORD) &udr);
}

//! @}
//! @}
